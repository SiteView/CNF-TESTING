package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalUpdateAddMigrationTableComplexCommand extends CmdbDalClassModelComplexCommand
{
  private String _className = null;
  private Long _classId = null;

  public CmdbDalUpdateAddMigrationTableComplexCommand(String className, Long classId)
  {
    setClassName(className);
    setClassId(classId);
  }

  protected void validateInput() {
    if (getClassName() == null)
      throw new CmdbDalException("Can't update migration table with null class name");
  }

  protected Object perform() throws Exception
  {
    updateMigrationTable();
    return null;
  }

  protected String getCommandName() {
    return "Update migration table for class class [" + getClassName() + "]";
  }

  private void updateMigrationTable() throws SQLException {
    String classFullQualifiedName = getClassName();
    String sql = createInsertMigrationTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Update(sql);

    preparedStatement.setLong(getClassId());
    preparedStatement.setString(getConsolidatedTableNameByClassName(classFullQualifiedName));
    preparedStatement.setString(getCustomerTableNameByClassName(classFullQualifiedName));
    preparedStatement.setInt(getCustomerID().getID());

    preparedStatement.executeUpdate();
    preparedStatement.close();
  }

  private String createInsertMigrationTableSql() {
    List columnsNames = createMigrationTableColumnsNames();

    return createInsertSql("CCM_MIGR_TBL", columnsNames);
  }

  private String getClassName() {
    return this._className;
  }

  private void setClassName(String className) {
    this._className = className;
  }

  private Long getClassId() {
    return this._classId;
  }

  private void setClassId(Long classId) {
    this._classId = classId;
  }
}