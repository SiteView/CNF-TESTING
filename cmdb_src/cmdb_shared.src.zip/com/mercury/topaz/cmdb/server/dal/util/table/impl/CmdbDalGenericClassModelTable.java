package com.mercury.topaz.cmdb.server.dal.util.table.impl;

import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections.IteratorUtils;

public class CmdbDalGenericClassModelTable
{
  private List _columnsNames = null;
  private List _columnsTypes = null;
  private String _rowIdColumnName = null;
  private String _foreignKeyColumnName = null;
  private Map _rows = null;
  private Map _foreignKeyMap = null;

  public CmdbDalGenericClassModelTable(CmdbDalResultSet resultSet, List columnsNames, List columnsTypes, String rowIdColumnName, String foreignKeyColumnName)
  {
    setColumnsNames(columnsNames);
    setColumnsTypes(columnsTypes);
    setRowIdColumnName(rowIdColumnName);
    setForeignKeyColumnName(foreignKeyColumnName);

    init();
    createTable(resultSet);
  }

  public Iterator getRowsIterator()
  {
    if (getRows().values() == null)
      return IteratorUtils.EMPTY_ITERATOR;

    return getRows().values().iterator();
  }

  public Iterator getRowIdsIterator(Long foreignId)
  {
    List rowIds = (List)getForeignKeyMap().get(foreignId);
    if (rowIds == null)
      return IteratorUtils.EMPTY_ITERATOR;

    return rowIds.iterator();
  }

  public Map getRow(Long rowId)
  {
    return ((Map)getRows().get(rowId));
  }

  private void init() {
    setRows(new HashMap());
    if (getForeignKeyColumnName() != null)
      setForeignKeyMap(new HashMap());
  }

  private void createTable(CmdbDalResultSet resultSet)
  {
    try {
      while (resultSet.next()) {
        Long rowId = createRow(resultSet);
        updateForeignKeyMap(resultSet, rowId);
      }
    }
    catch (SQLException e) {
      throw new CmdbDalException("Can't create cmdb dal class model table, due to exception: " + e, e);
    }
  }

  private Long getRowId(CmdbDalResultSet resultSet) throws SQLException {
    if (getRowIdColumnName() != null)
      return resultSet.getLong(getRowIdColumnName());

    return new Long(resultSet.getRow());
  }

  private Long createRow(CmdbDalResultSet resultSet) throws SQLException {
    Long rowId = getRowId(resultSet);
    Map row = new HashMap();
    for (int i = 0; i < getColumnsNames().size(); ++i) {
      Object value = DalTypeUtil.getObject(resultSet, (String)getColumnsNames().get(i), (CmdbType)getColumnsTypes().get(i));
      row.put(getColumnsNames().get(i), value);
    }
    getRows().put(rowId, row);
    return rowId;
  }

  private void updateForeignKeyMap(CmdbDalResultSet resultSet, Long rowId) throws SQLException {
    if (getForeignKeyColumnName() != null) {
      Long foreignKey = resultSet.getLong(getForeignKeyColumnName());
      List rowIds = (List)getForeignKeyMap().get(foreignKey);
      if (rowIds == null) {
        rowIds = new ArrayList();
        getForeignKeyMap().put(foreignKey, rowIds);
      }
      rowIds.add(rowId);
    }
  }

  private String getRowIdColumnName() {
    return this._rowIdColumnName;
  }

  private void setRowIdColumnName(String rowIdColumnName) {
    this._rowIdColumnName = rowIdColumnName;
  }

  private String getForeignKeyColumnName() {
    return this._foreignKeyColumnName;
  }

  private void setForeignKeyColumnName(String foreignKeyColumnName) {
    this._foreignKeyColumnName = foreignKeyColumnName;
  }

  private List getColumnsNames() {
    return this._columnsNames;
  }

  private void setColumnsNames(List columnsNames) {
    this._columnsNames = columnsNames;
  }

  private Map getRows() {
    return this._rows;
  }

  private void setRows(Map rows) {
    this._rows = rows;
  }

  private Map getForeignKeyMap() {
    return this._foreignKeyMap;
  }

  private void setForeignKeyMap(Map foreignKeyMap) {
    this._foreignKeyMap = foreignKeyMap;
  }

  private List getColumnsTypes() {
    return this._columnsTypes;
  }

  private void setColumnsTypes(List columnsTypes) {
    this._columnsTypes = columnsTypes;
  }
}