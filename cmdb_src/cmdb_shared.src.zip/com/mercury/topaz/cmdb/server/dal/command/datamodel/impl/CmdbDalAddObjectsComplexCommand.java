package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.shared.model.object.CmdbModifiableObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class CmdbDalAddObjectsComplexCommand extends CmdbDalAddElementsComplexCommand<CmdbObject>
{
  public CmdbDalAddObjectsComplexCommand(CmdbObjects objects)
  {
    super(objects);
  }

  protected CmdbObject addPropertiesToData(CmdbObject data, CmdbProperties props) {
    CmdbModifiableObject modObj = CmdbObjectFactory.createModifiableObject(data);
    for (ReadOnlyIterator i = props.getPropertiesIterator(); i.hasNext(); )
      modObj.addOrUpdateProperty((CmdbProperty)i.next());

    return modObj;
  }
}