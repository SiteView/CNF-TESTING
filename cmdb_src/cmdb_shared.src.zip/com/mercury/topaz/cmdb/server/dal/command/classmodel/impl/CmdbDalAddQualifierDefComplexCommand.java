package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifierDef;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.util.List;

public abstract class CmdbDalAddQualifierDefComplexCommand extends CmdbDalClassModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalAddQualifierDefComplexCommand.class);
  protected static final String CLASS_QUALIFIER_TYPE = "CLASS";
  protected static final String ATTRIBUTE_QUALIFIER_TYPE = "ATTRIBUTE";
  protected static final String METHOD_QUALIFIER_TYPE = "METHOD";
  protected static final String VALID_LINK_QUALIFIER_TYPE = "VALID_LINK";
  private ClassModelQualifierDef _qualifierDef = null;

  CmdbDalAddQualifierDefComplexCommand(ClassModelQualifierDef qualifierDef)
  {
    setQualifierDef(qualifierDef);
  }

  protected void validateInput() {
    if (getQualifierDef() == null)
      throw new CmdbDalException("Can't add null qualifier definition");
  }

  protected Object perform()
  {
    addQualifierDef(getQualifierDef());

    return null;
  }

  private ClassModelQualifierDef getQualifierDef() {
    return this._qualifierDef;
  }

  private void setQualifierDef(ClassModelQualifierDef qualifierDef) {
    this._qualifierDef = qualifierDef; }

  protected abstract String getQualifierType();

  private void addQualifierDef(ClassModelQualifierDef qualifier) {
    CmdbDalConnection connection;
    try {
      connection = getConnection();

      CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

      String sqlString = createInsertQualifiresDefTableSql();
      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      preparedStatement.setString(qualifier.getName());
      preparedStatement.setString(qualifier.getDescription());
      preparedStatement.setString(qualifier.getDisplayName());
      preparedStatement.setString(getQualifierType());
      preparedStatement.setLong(customerID.getID());
      preparedStatement.setBoolean(qualifier.isCreatedByFactory());
      preparedStatement.setBoolean(qualifier.isModifiedByUser());

      preparedStatement.executeUpdate();
      preparedStatement.close();

      connection.commit();
    }
    catch (Exception e) {
      String errMsg = "Error adding qualifier def [" + qualifier.getName() + "], due to exception: " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }

  private String createInsertQualifiresDefTableSql() {
    List columnsNames = createQualifiresDefTableColumnsNames();

    return createInsertSql("CCM_QUAL_DEF", columnsNames);
  }
}