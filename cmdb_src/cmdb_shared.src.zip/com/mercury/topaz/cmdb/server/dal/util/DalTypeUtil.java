package com.mercury.topaz.cmdb.server.dal.util;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.TypeVisitor;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBytesType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDateType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDoubleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbFloatType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.Numeric;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;
import java.sql.SQLException;
import java.util.Date;

public class DalTypeUtil
{
  public static void setObject(CmdbDalPreparedStatement ps, Object value, CmdbType type)
  {
    setObject(ps, value, type, null);
  }

  public static void setObject(CmdbDalPreparedStatement ps, Object value, CmdbType type, Integer columnSize) {
    type.accept(new PrepareStatementVisitor(ps, value, columnSize));
  }

  public static Object getObject(CmdbDalResultSet rs, String columnName, CmdbType type, Integer columnSize) {
    CmdbDalResultSetVisitor visitor = new CmdbDalResultSetVisitor(rs, columnName, columnSize);
    type.accept(visitor);
    return visitor.getResult();
  }

  public static Object getObject(CmdbDalResultSet rs, String columnName, CmdbType type) {
    return getObject(rs, columnName, type, null); }

  private static class CmdbDalResultSetVisitor
  implements TypeVisitor {
    private final CmdbDalResultSet rs;
    private final String columnName;
    private Object _result = null;
    private final Integer columnSize;

    public CmdbDalResultSetVisitor(CmdbDalResultSet rs, String columnName, Integer columnSize) {
      this.rs = rs;
      this.columnName = columnName;
      this.columnSize = columnSize;
    }

    public void visit(CmdbSimpleType simpleCmdbType) {
    }

    public void visit(Numeric numericType) {
    }

    public void visit(CmdbIntegerType integerType) {
      try {
        setResult(this.rs.getInt(getColumnName()));
      }
      catch (SQLException e) {
        throw new CmdbDalException(e);
      }
    }

    public void visit(CmdbLongType longType) {
      try {
        setResult(this.rs.getLong(getColumnName()));
      }
      catch (SQLException e) {
        throw new CmdbDalException(e);
      }
    }

    public void visit(CmdbFloatType floatType) {
      try {
        setResult(this.rs.getFloat(getColumnName()));
      }
      catch (SQLException e) {
        throw new CmdbDalException(e);
      }
    }

    public void visit(CmdbDoubleType doubleType) {
      try {
        setResult(this.rs.getDouble(getColumnName()));
      }
      catch (SQLException e) {
        throw new CmdbDalException(e);
      }
    }

    public void visit(CmdbStringType stringType) {
      try {
        setResult(this.rs.getString(getColumnName()));
      }
      catch (SQLException e) {
        throw new CmdbDalException(e);
      }
    }

    public void visit(CmdbXmlType xmlType) {
      try {
        setResult(this.rs.getClob(getColumnName()));
      }
      catch (SQLException e) {
        throw new CmdbDalException(e);
      }
    }

    public void visit(CmdbBooleanType cmdbBooleanType) {
      try {
        setResult(this.rs.getBoolean(getColumnName()));
      }
      catch (SQLException e) {
        throw new CmdbDalException(e);
      }
    }

    public void visit(CmdbDateType cmdbDateType) {
      try {
        setResult(this.rs.getDate(getColumnName()));
      }
      catch (SQLException e) {
        throw new CmdbDalException(e);
      }
    }

    public void visit(CmdbBytesType cmdbBytesType)
    {
      try {
        if ((getColumnSize() != null) && (getColumnSize().intValue() > 2000))
          setResult(this.rs.getBlob(getColumnName()));
        else
          setResult(this.rs.getBytes(getColumnName()));
      }
      catch (SQLException e)
      {
        throw new CmdbDalException(e);
      }
    }

    public void visit(CmdbSimpleList cmdbSimpleList) {
      throw new CmdbDalException("Can't use result set to get value from type [cmdbSimpleList] !!!");
    }

    public void visit(CmdbStringListType cmdbStringListType) {
    }

    public void visit(CmdbIntegerListType cmdbIntegerListType) {
    }

    public void visit(CmdbTypeDef typeDef) {
    }

    public void visit(CmdbEnum cmdbEnum) {
      CmdbSimpleTypes.CmdbInteger.accept(this);
    }

    public void visit(CmdbList cmdbList) {
      cmdbList.getType().accept(this);
    }

    public void visit(CmdbExternalResource externalResource) {
      CmdbSimpleTypes.CmdbString.accept(this);
    }

    private String getColumnName()
    {
      return this.columnName;
    }

    public Object getResult() {
      return this._result;
    }

    private void setResult(Object result) {
      this._result = result;
    }

    public Integer getColumnSize() {
      return this.columnSize;
    }
  }

  private static class PrepareStatementVisitor
  implements TypeVisitor
  {
    private final CmdbDalPreparedStatement ps;
    private final Object value;
    private final Integer columnSize;

    public PrepareStatementVisitor(CmdbDalPreparedStatement ps, Object value, Integer columnSize)
    {
      this.ps = ps;
      this.value = value;
      this.columnSize = columnSize;
    }

    public void visit(CmdbSimpleType simpleCmdbType) {
    }

    public void visit(Numeric numericType) {
    }

    public void visit(CmdbIntegerType integerType) {
      try {
        this.ps.setInt((Integer)getValue());
      } catch (Throwable t) {
        throw new CmdbDalException(t);
      }
    }

    public void visit(CmdbLongType longType) {
      try {
        this.ps.setLong((Long)getValue());
      } catch (Throwable t) {
        throw new CmdbDalException(t);
      }
    }

    public void visit(CmdbFloatType floatType) {
      try {
        this.ps.setFloat((Float)getValue());
      } catch (Throwable t) {
        throw new CmdbDalException(t);
      }
    }

    public void visit(CmdbDoubleType doubleType) {
      try {
        this.ps.setDouble((Double)getValue());
      } catch (Throwable t) {
        throw new CmdbDalException(t);
      }
    }

    public void visit(CmdbStringType stringType) {
      try {
        this.ps.setString((String)getValue());
      } catch (Throwable t) {
        throw new CmdbDalException(t);
      }
    }

    public void visit(CmdbXmlType xmlType) {
      try {
        this.ps.setClob((String)getValue());
      } catch (Throwable t) {
        throw new CmdbDalException(t);
      }
    }

    public void visit(CmdbBooleanType cmdbBooleanType) {
      try {
        this.ps.setBoolean((Boolean)getValue());
      } catch (Throwable t) {
        throw new CmdbDalException(t);
      }
    }

    public void visit(CmdbDateType cmdbDateType) {
      try {
        this.ps.setDate((Date)getValue());
      } catch (Throwable t) {
        throw new CmdbDalException(t);
      }
    }

    public void visit(CmdbBytesType cmdbBytesType)
    {
      try {
        if ((getColumnSize() != null) && (getColumnSize().intValue() > 2000))
          this.ps.setBlob((byte[])(byte[])getValue());
        else
          this.ps.setBytes((byte[])(byte[])getValue());
      }
      catch (Throwable t) {
        throw new CmdbDalException(t);
      }
    }

    public void visit(CmdbSimpleList cmdbSimpleList) {
      throw new CmdbDalException("Can't use prepare statement to set value from type [cmdbSimpleList] !!!");
    }

    public void visit(CmdbStringListType cmdbStringListType) {
    }

    public void visit(CmdbIntegerListType cmdbIntegerListType) {
    }

    public void visit(CmdbTypeDef typeDef) {
    }

    public void visit(CmdbEnum cmdbEnum) {
      CmdbSimpleTypes.CmdbInteger.accept(this);
    }

    public void visit(CmdbList cmdbList) {
      cmdbList.getType().accept(this);
    }

    public void visit(CmdbExternalResource externalResource) {
      CmdbSimpleTypes.CmdbString.accept(this);
    }

    private Object getValue() {
      return this.value;
    }

    public Integer getColumnSize() {
      return this.columnSize;
    }
  }
}