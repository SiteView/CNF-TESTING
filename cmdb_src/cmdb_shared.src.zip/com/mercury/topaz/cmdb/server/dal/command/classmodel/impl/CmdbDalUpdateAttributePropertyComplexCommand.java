package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import java.sql.SQLException;

public abstract class CmdbDalUpdateAttributePropertyComplexCommand extends CmdbDalUpdatePropertyComplexCommand
{
  private CmdbAttributeOverride _attribute = null;

  public CmdbDalUpdateAttributePropertyComplexCommand(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass)
  {
    super(cmdbClass);
    setAttribute(attributeOverride);
  }

  protected void validateInput() {
    super.validateInput();
    if (getAttribute() == null)
      throw new CmdbDalException("Can't update null attribute");
  }

  protected String getTableNameToUpdate()
  {
    return "CCM_ATTRIBUTE";
  }

  protected String getRowIdConditionColumnName() {
    return "ATTRIBUTE_ID";
  }

  protected Long getRowId() throws SQLException {
    Long attributeId = getAttributeID(getAttribute().getName(), getCmdbClass().getName(), getConnection());
    return attributeId;
  }

  protected CmdbAttributeOverride getAttribute() {
    return this._attribute;
  }

  private void setAttribute(CmdbAttributeOverride attribute) {
    this._attribute = attribute;
  }
}