package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifierDef;

public class CmdbDalAddAttributeQualifierDefComplexCommand extends CmdbDalAddQualifierDefComplexCommand
{
  public CmdbDalAddAttributeQualifierDefComplexCommand(ClassModelQualifierDef qualifierDef)
  {
    super(qualifierDef);
  }

  protected String getQualifierType() {
    return "ATTRIBUTE";
  }
}