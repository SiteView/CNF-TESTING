package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import java.util.Iterator;

public class CmdbDalAddLinksChange extends AbstractChangeDetailCommand
{
  private final CmdbLinks addedLinks;

  public CmdbDalAddLinksChange(CmdbLinks addedLinks)
  {
    this.addedLinks = addedLinks;
  }

  protected Void perform() throws Exception {
    CmdbDalPreparedStatement statement = createChangeDetailStatement();
    for (Iterator i$ = this.addedLinks.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
      ChangeDetail changeDetail = new ChangeDetail();
      changeDetail.addingLink(link);
      setBindVariables(statement, changeDetail);
      statement.addBatch();
    }
    statement.executeBatch();
    return null;
  }
}