package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;

public class CmdbDalUpdateClassIsFactoryComplexCommand extends CmdbDalUpdateClassPropertyComplexCommand
{
  public CmdbDalUpdateClassIsFactoryComplexCommand(CmdbClass cmdbClass)
  {
    super(cmdbClass);
  }

  protected String getColumnNameToUpdate() {
    return "IS_FACTORY";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long classId) throws SQLException {
    preparedStatement.setBoolean(getCmdbClass().isCreatedByFactory());
    preparedStatement.setBoolean(getCmdbClass().isModifiedByUser());
    preparedStatement.setLong(classId);
  }

  protected String getCommandName() {
    return "Update is factory of class [" + getCmdbClass().getName() + "] to [" + getCmdbClass().isCreatedByFactory() + "]";
  }
}