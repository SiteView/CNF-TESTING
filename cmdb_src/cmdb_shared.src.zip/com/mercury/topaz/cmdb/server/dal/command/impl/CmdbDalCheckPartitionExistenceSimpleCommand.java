package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;

public class CmdbDalCheckPartitionExistenceSimpleCommand extends CmdbDalAbstractCommand<Boolean>
{
  private String _tableName = null;
  private String _partitionName = null;

  public CmdbDalCheckPartitionExistenceSimpleCommand(String partitionName, String tableName)
  {
    setPartitionName(partitionName);
    setTableName(tableName);
  }

  protected void validateInput() {
    if ((getTableName() == null) || (getTableName().length() == 0) || (getPartitionName() == null) || (getPartitionName().length() == 0))
    {
      throw new CmdbDalException("Can't check existence for partition [" + getPartitionName() + "], in table [" + getTableName() + "]");
    }
  }

  protected Boolean perform() throws Exception {
    return Boolean.valueOf(checkPartitionExistence());
  }

  private boolean checkPartitionExistence() throws SQLException
  {
    boolean res = false;

    if (isOracle()) {
      return checkOraclePartitionExistence();
    }

    return res;
  }

  private boolean checkOraclePartitionExistence()
    throws SQLException
  {
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;
    String sqlString = "select 1 from user_tab_partitions where table_name=? and partition_name=?";
    try
    {
      preparedStatement = getConnection().prepareStatement4Select(sqlString);
      preparedStatement.setString(getTableName());
      preparedStatement.setString(getPartitionName());
      resultSet = preparedStatement.executeQuery();

      boolean res = resultSet.next();

      resultSet.close();
      preparedStatement.close();

      boolean bool1 = res;

      return bool1;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private String getTableName()
  {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    this._tableName = tableName;
  }

  private String getPartitionName() {
    return this._partitionName;
  }

  private void setPartitionName(String pratitionName) {
    this._partitionName = pratitionName;
  }
}