package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalObjectsConditionComplexCommand extends CmdbDalConditionComplexCommand
{
  private ModelObjects _modelObjects = null;

  public CmdbDalObjectsConditionComplexCommand(ElementCondition condition, ModelObjects objects)
  {
    super(condition);
    setModelObjects(objects);
  }

  protected Object perform() throws Exception {
    if ((getCondition() == null) || (getCondition().getClassCondition() == null))
      return CmdbObjectIdsFactory.create();

    return performQueryCondition();
  }

  protected Object getResult(CmdbDalResultSet resultSet) throws SQLException {
    return buildCmdbIDs(resultSet);
  }

  protected boolean hasConditionIDs(Object conditionIDs) {
    return (!(isEmptyContainer((CmdbObjectIds)conditionIDs)));
  }

  protected void createCmdbIDTempTable(Object conditionIDs, CmdbDalConnection connection) throws SQLException {
    createCmdbIDTempTable(connection, (CmdbObjectIds)conditionIDs);
  }

  protected CmdbObjectIds buildCmdbIDs(CmdbDalResultSet resultSet) throws SQLException
  {
    int maxResults = getLocalEnvironment().getSettingsReader().getInt("dal.object.condition.max.result.size", 500000);
    int currentResultCount = 0;

    CmdbObjectIds ids = CmdbObjectIdsFactory.create();
    while (resultSet.next())
    {
      ++currentResultCount;
      if (currentResultCount > maxResults) {
        String errMsg = "Number of Object condition results exceeded the maximum allowed (max allowed value is: " + maxResults + ")";
        throw new CmdbDalException(errMsg);
      }

      byte[] idAsBytes = resultSet.getBytes(1);
      CmdbObjectID objectID = restoreObjectID(idAsBytes);

      ids.add(objectID);
    }
    return ids;
  }

  protected int getContainerSize(Object container) {
    if (container instanceof CmdbObjectIds)
      return ((CmdbObjectIds)container).size();

    throw new CmdbDalException("Container from type [" + container.getClass() + "] is not supported !!!");
  }

  protected void addIDsToBindVariables(CmdbIDsCollection<? extends CmdbDataID> conditionIDs, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) {
    ReadOnlyIterator objectIDsIter = conditionIDs.getIdsIterator();
    while (objectIDsIter.hasNext()) {
      CmdbDataID objectID = (CmdbDataID)objectIDsIter.next();

      byte[] objectIDAsBytes = convertCmdbID2Bytes(objectID);
      bindVariables.add(objectIDAsBytes);
      bindVariablesTypes.add(CmdbSimpleTypes.CmdbBytes);
    }
  }

  protected CmdbIDsCollection<? extends CmdbDataID> extractConditionIDs(Object modelElements, ElementCondition condition) {
    if (hasModelElements(modelElements))
      return extractCmdbObjectIds((ModelObjects)modelElements);

    if ((condition.getIdsCondition() != null) && (!(isEmptyContainer(condition.getIdsCondition().getIds())))) {
      return condition.getIdsCondition().getIds();
    }

    return CmdbObjectIdsFactory.create();
  }

  protected boolean hasModelElements(Object modelElements) {
    return (!(isEmptyContainer((ModelObjects)modelElements)));
  }

  protected Object getModelElements() {
    return getModelObjects();
  }

  protected ModelObjects getModelObjects() {
    return this._modelObjects;
  }

  protected void setModelObjects(ModelObjects modelObjects) {
    this._modelObjects = modelObjects;
  }
}