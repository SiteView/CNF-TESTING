package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.dal.dao.CmdbDalDataModelDAO;
import com.mercury.topaz.cmdb.server.dal.dao.impl.CmdbDalDAOFactory;
import com.mercury.topaz.cmdb.server.dal.util.DalDataModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;

public class AddAttributeOverride extends CmdbDalClassModelComplexCommand<Void>
{
  private final CmdbAttributeOverride attributeOverride;
  private final CmdbClass cmdbClass;
  private final Long classId;

  public AddAttributeOverride(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass, Long classId)
  {
    this.attributeOverride = attributeOverride;
    this.cmdbClass = cmdbClass;
    this.classId = classId;
  }

  protected Void perform() throws Exception {
    CmdbDalDataModelDAO dao = CmdbDalDAOFactory.createDataModelDAO(getLocalEnvironment());
    dao.execute(new CmdbDalAddAttributesOverridesComplexCommand(this.attributeOverride, this.cmdbClass, this.classId));

    getConnection().commit();

    DalDataModelUtil.handleQualifiersAddition(this.cmdbClass, this.attributeOverride.getName(), this.attributeOverride.getQualifiers());

    return null;
  }

  protected void validateInput()
  {
  }
}