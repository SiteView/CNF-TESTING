package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import java.util.Iterator;

public class CmdbDalRemoveLinksChange extends AbstractChangeDetailCommand
{
  private final CmdbLinks removedLinks;

  public CmdbDalRemoveLinksChange(CmdbLinks removedLinks)
  {
    this.removedLinks = removedLinks;
  }

  protected Void perform() throws Exception {
    CmdbDalPreparedStatement statement = createChangeDetailStatement();
    for (Iterator i$ = this.removedLinks.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
      ChangeDetail changeDetail = new ChangeDetail();
      changeDetail.removingLink(link);
      setBindVariables(statement, changeDetail);
      statement.addBatch();
    }
    statement.executeBatch();
    return null;
  }
}