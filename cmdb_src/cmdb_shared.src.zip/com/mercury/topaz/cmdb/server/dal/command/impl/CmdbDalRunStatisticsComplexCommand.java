package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import java.sql.SQLException;
import java.util.Properties;

public class CmdbDalRunStatisticsComplexCommand extends CmdbDalAbstractCommand<Void>
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalRunStatisticsComplexCommand.class);

  protected void validateInput()
  {
  }

  protected Void perform()
    throws Exception
  {
    _logger.info("Running DB Statistics!!!");
    runStatistics();
    return null;
  }

  private void runStatistics() throws SQLException {
    String sql = buildRunStatisticsSql();
    executeSql(sql);
  }

  private void executeSql(String sql)
  {
    CmdbDalConnection privateConnection = null;
    Properties properties = new Properties();

    properties.setProperty("SupportLinks", "true");
    try {
      privateConnection = getConnectionPool().getPrivateConnection(properties);
      privateConnection.executeCallableStatement(sql);
    }
    finally {
      try {
        getConnectionPool().releasePrivateConnection(privateConnection);
      }
      catch (Exception e) {
        _logger.error("Can't release private connection due to exception: " + e, e);
      }
    }
  }

  private String buildRunStatisticsSql()
    throws SQLException
  {
    String sql;
    if (getConnectionPool().isUsingOracle10gDB())
      sql = "begin DBMS_STATS.GATHER_SCHEMA_STATS (ownname =>'" + getConnectionPool().getDbContext().getUserName() + "', options=>'GATHER AUTO', no_invalidate=>false); end;";
    else if (getConnectionPool().isUsingOracleDB())
      sql = "begin DBMS_STATS.GATHER_SCHEMA_STATS (ownname =>'" + getConnectionPool().getDbContext().getUserName() + "', cascade=>true); end;";
    else if (getConnectionPool().isUsingMSSqlDB())
      sql = "{CALL sp_updatestats}";
    else
      throw new CmdbDalException("Unknown db type [" + getConnectionPool().getDBType() + "] !!!");

    return sql;
  }
}