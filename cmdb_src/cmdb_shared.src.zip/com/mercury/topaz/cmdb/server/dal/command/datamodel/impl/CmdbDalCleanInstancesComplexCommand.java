package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import java.sql.SQLException;

public class CmdbDalCleanInstancesComplexCommand extends CmdbDalDataModelComplexCommand
{
  private CmdbObjects _objects = null;
  private CmdbLinks _links = null;

  protected void validateInput()
  {
  }

  protected Object perform()
  {
    try
    {
      queryObjects();
      queryLinks();

      CmdbObjects objects = getObjects();
      CmdbLinks links = getLinks();

      if (!(links.isEmpty())) {
        CmdbDalCommand removeLinksComplexCommand = CmdbDalDataModelCommandFactory.createRemoveLinksComplexCommand(links);
        removeLinksComplexCommand.execute();
      }

      if (!(objects.isEmpty())) {
        CmdbDalCommand removeObjectsComplexCommand = CmdbDalDataModelCommandFactory.createRemoveObjectsComplexCommand(objects);
        removeObjectsComplexCommand.execute();
      }
    } catch (Exception e) {
      throw new CmdbDalException("Can't clean instances from db due to exception: " + e, e);
    }
    return null;
  }

  private CmdbLink buildCmdbLink(String type, byte[] idAsBytes, byte[] end1IDAsBytes, byte[] end2IDAsBytes)
  {
    CmdbObjectID end1ID = CmdbObjectID.Factory.restoreObjectID(end1IDAsBytes);
    CmdbObjectID end2ID = CmdbObjectID.Factory.restoreObjectID(end2IDAsBytes);
    CmdbLinkID linkID = CmdbLinkID.Factory.restoreLinkID(idAsBytes);

    return getDataFactory().restoreLink(linkID, type, end1ID, end2ID);
  }

  private CmdbObject buildCmdbObject(byte[] idAsBytes, String type) {
    CmdbObjectID objectID = CmdbObjectID.Factory.restoreObjectID(idAsBytes);

    return getDataFactory().restoreObject(objectID, type);
  }

  private String createObjectsSql()
  {
    StringBuffer sqlString = new StringBuffer();
    sqlString.append("select r.").append("CMDB_ID").append(", r.").append("CLASS").append(" from ").append(getTableNameByClassName("root")).append(" r").append(" where r.").append("CMDB_ID").append(" not in (select ").append("CMDB_ID").append(" from ").append(getTableNameByClassName("link")).append(")");

    if (!(isUpdateClassModelEnabled()))
      sqlString.append(" AND r.").append("CUSTOMER_ID").append("=?");

    return sqlString.toString();
  }

  private String createLinksSql() {
    String sql = "select CMDB_ID, CLASS, END1_ID, END2_ID from " + getTableNameByClassName("link");

    if (!(isUpdateClassModelEnabled()))
      sql = sql + " WHERE CUSTOMER_ID = ?";

    return sql;
  }

  private void queryObjects() throws SQLException {
    CmdbDalConnection connection = null;
    CmdbDalResultSet result = null;
    CmdbDalPreparedStatement preparedStatement = null;
    try {
      connection = getConnection();

      String objectsSql = createObjectsSql();
      preparedStatement = connection.prepareStatement4Select(objectsSql);
      if (!(isUpdateClassModelEnabled()))
        preparedStatement.setInt(getCustomerID().getID());

      result = preparedStatement.executeQuery();
      addObjectsFromResultSet(result);
    } finally {
      if (result != null)
        result.close();

      if (preparedStatement != null)
        preparedStatement.close();

      if (connection != null)
        connection.release();
    }
  }

  private void queryLinks() throws SQLException
  {
    CmdbDalConnection connection = null;
    CmdbDalResultSet result = null;
    CmdbDalPreparedStatement preparedStatement = null;
    try {
      connection = getConnection();

      String linksSql = createLinksSql();
      preparedStatement = connection.prepareStatement4Select(linksSql);
      if (!(isUpdateClassModelEnabled()))
        preparedStatement.setInt(getCustomerID().getID());

      result = preparedStatement.executeQuery();
      addLinksFromResultSet(result);
    } finally {
      if (result != null)
        result.close();

      if (preparedStatement != null)
        preparedStatement.close();

      if (connection != null)
        connection.release();
    }
  }

  private void addLinksFromResultSet(CmdbDalResultSet resultSet)
    throws SQLException
  {
    CmdbLinks links = CmdbLinkFactory.createLinks();

    while (resultSet.next()) {
      byte[] idAsBytes = resultSet.getBytes(1);
      String type = resultSet.getString(2);
      byte[] end1IDAsBytes = resultSet.getBytes(3);
      byte[] end2IDAsBytes = resultSet.getBytes(4);
      CmdbLink cmdbLink = buildCmdbLink(type, idAsBytes, end1IDAsBytes, end2IDAsBytes);

      if (cmdbLink != null)
        links.add(cmdbLink);

    }

    setLinks(links);
  }

  private void addObjectsFromResultSet(CmdbDalResultSet resultSet)
    throws SQLException
  {
    CmdbObjects objects = CmdbObjectFactory.createObjects();

    while (resultSet.next()) {
      byte[] idAsBytes = resultSet.getBytes(1);
      String type = resultSet.getString(2);
      CmdbObject object = buildCmdbObject(idAsBytes, type);
      if (object != null)
        objects.add(object);

    }

    setObjects(objects);
  }

  private CmdbObjects getObjects() {
    return this._objects;
  }

  private void setObjects(CmdbObjects objects) {
    this._objects = objects;
  }

  private CmdbLinks getLinks() {
    return this._links;
  }

  private void setLinks(CmdbLinks links) {
    this._links = links;
  }
}