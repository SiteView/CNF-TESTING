package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;

public class CmdbDalUpdateClassDisplayNameComplexCommand extends CmdbDalUpdateClassPropertyComplexCommand
{
  public CmdbDalUpdateClassDisplayNameComplexCommand(CmdbClass cmdbClass)
  {
    super(cmdbClass);
  }

  protected String getColumnNameToUpdate() {
    return "DISPLAY_NAME";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long classId) throws SQLException {
    preparedStatement.setString(getCmdbClass().getDisplayName());
    preparedStatement.setBoolean(getCmdbClass().isModifiedByUser());
    preparedStatement.setLong(classId);
  }

  protected String getCommandName() {
    return "Update display name of class [" + getCmdbClass().getName() + "] to [" + getCmdbClass().getDisplayName() + "]";
  }
}