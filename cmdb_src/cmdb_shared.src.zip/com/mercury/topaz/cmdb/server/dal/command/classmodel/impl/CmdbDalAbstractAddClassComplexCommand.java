package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;

public abstract class CmdbDalAbstractAddClassComplexCommand extends CmdbDalClassModelComplexCommand
{
  private CmdbClass _cmdbClass;

  public CmdbDalAbstractAddClassComplexCommand(CmdbClass cmdbClass)
  {
    setCmdbClass(cmdbClass);
  }

  protected void validateInput() {
    if (getCmdbClass() == null)
      throw new CmdbDalException("Can't add null cmdb class");
  }

  protected String getCommandName()
  {
    return "Add class [" + getCmdbClass() + "]";
  }

  protected CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass;
  }
}