package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import java.sql.SQLException;

public abstract class CmdbDalUpdateTypeDefListEntryPropertyComplexCommand extends CmdbDalUpdatePropertyComplexCommand
{
  private CmdbList _cmdbList = null;
  private CmdbListEntry _cmdbListEntry = null;
  private Long _cmdbListId = null;

  public CmdbDalUpdateTypeDefListEntryPropertyComplexCommand(CmdbListEntry cmdbListEntry, CmdbList cmdbList, Long cmdbListId)
  {
    super(null);
    setCmdbListEntry(cmdbListEntry);
    setCmdbList(cmdbList);
    setCmdbListId(cmdbListId);
  }

  protected void validateInput() {
    if (getCmdbListEntry() == null)
      throw new CmdbDalException("Can't update null list entry");

    if (getCmdbList() == null)
      throw new CmdbDalException("Can't update null List");
    try
    {
      if (getCmdbListId() == null)
        throw new CmdbDalException("Can't update List with null id");
    }
    catch (SQLException se) {
      throw new CmdbDalException("Can't get List id.", se);
    }
  }

  protected String getTableNameToUpdate() {
    return "CCM_TDEF_ENUM";
  }

  protected String getRowIdConditionColumnName() {
    return "ID";
  }

  protected Long getRowId() throws SQLException {
    Long listEntryID = getListEntryID(getCmdbListId(), getCmdbListEntry(), getCmdbList().getType(), getConnection());
    return listEntryID;
  }

  protected CmdbListEntry getCmdbListEntry() {
    return this._cmdbListEntry;
  }

  private void setCmdbListEntry(CmdbListEntry cmdbListEntry) {
    this._cmdbListEntry = cmdbListEntry;
  }

  protected CmdbList getCmdbList() {
    return this._cmdbList;
  }

  private void setCmdbList(CmdbList cmdbList) {
    this._cmdbList = cmdbList;
  }

  protected Long getCmdbListId() throws SQLException {
    Long typeDefId = this._cmdbListId;
    if (typeDefId == null) {
      typeDefId = getTypeDefID(getConnection(), getCmdbList());
      setCmdbListId(typeDefId);
    }
    return this._cmdbListId;
  }

  private void setCmdbListId(Long cmdbListId) {
    this._cmdbListId = cmdbListId;
  }
}