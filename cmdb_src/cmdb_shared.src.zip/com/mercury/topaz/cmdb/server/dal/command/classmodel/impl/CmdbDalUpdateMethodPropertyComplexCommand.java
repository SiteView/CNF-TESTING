package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import java.sql.SQLException;

public abstract class CmdbDalUpdateMethodPropertyComplexCommand extends CmdbDalUpdatePropertyComplexCommand
{
  private CmdbMethod _method = null;

  public CmdbDalUpdateMethodPropertyComplexCommand(CmdbMethod method, CmdbClass cmdbClass)
  {
    super(cmdbClass);
    setMethod(method);
  }

  protected void validateInput() {
    super.validateInput();
    if (getMethod() == null)
      throw new CmdbDalException("Can't update null method");
  }

  protected String getTableNameToUpdate()
  {
    return "CCM_METHODS";
  }

  protected String getRowIdConditionColumnName() {
    return "METHOD_ID";
  }

  protected Long getRowId() throws SQLException {
    Long methodId = getMethodID(getMethod().getName(), getCmdbClass().getName(), getConnection());
    return methodId;
  }

  protected CmdbMethod getMethod() {
    return this._method;
  }

  private void setMethod(CmdbMethod method) {
    this._method = method;
  }
}