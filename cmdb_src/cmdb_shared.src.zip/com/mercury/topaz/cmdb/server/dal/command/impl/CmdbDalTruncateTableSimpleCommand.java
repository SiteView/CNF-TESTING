package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;

public class CmdbDalTruncateTableSimpleCommand extends CmdbDalAbstractCommand
{
  private String _tableName = null;

  public CmdbDalTruncateTableSimpleCommand(String tableName)
  {
    setTableName(tableName);
  }

  protected void validateInput() {
    if ((getTableName() == null) || (getTableName().length() == 0))
      throw new CmdbDalException("Can't truncate table [" + getTableName() + "]");
  }

  protected Object perform() throws Exception
  {
    truncateTable();

    return null;
  }

  private void truncateTable()
  {
    String sqlString;
    if (isOracle())
    {
      sqlString = "delete from " + getTableName();
    }
    else if (isMsSql()) {
      sqlString = "truncate table #" + getTableName();
    }
    else {
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
    }

    getConnection().executeAdhocSql(sqlString);
  }

  private String getTableName() {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    this._tableName = tableName;
  }
}