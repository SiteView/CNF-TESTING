package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CmdbDalTruncateTempTableComplexCommand extends CmdbDalAbstractCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalTruncateTempTableComplexCommand.class);
  private String _tableName = null;

  public CmdbDalTruncateTempTableComplexCommand(String tableName)
  {
    setTableName(tableName);
  }

  protected void validateInput() {
  }

  protected Object perform() throws Exception {
    if (isOracle())
      truncateTable();
    else if (isMsSql())
      truncateMssqlTempTable();
    else
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");

    return null;
  }

  private void truncateTable() {
    CmdbDalCommand truncateTableCommand = CmdbDalCommandFactory.createTruncateTableSimpleCommand(getTableName());
    truncateTableCommand.execute();
  }

  private void truncateMssqlTempTable() {
    if (checkTableExistence("tempdb.dbo.#" + getTableName()))
      truncateTable();
    else
      createTempTable();
  }

  private void createTempTable()
  {
    if (getTableName().equals("CDM_TMP_OBJID"))
      createCmdbIDTempTable();
    else if (getTableName().equals("CDM_TMP_STR"))
      createStringTempTable();
    else if (getTableName().equals("CDM_TMP_INT"))
      createNumberTempTable();
    else if (getTableName().equals("CCM_TMP_EID"))
      createEntityIDTempTable();
    else if (getTableName().equals("CDM_TMP_OBJID_STR"))
      createCmdbIdStringTempTable();
  }

  private void createIndex(CmdbDalConnection connection, String tableName, String columnName)
  {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("CREATE INDEX ").append("IX1_");
    sqlString.append(tableName);

    sqlString.append(" ON ").append("#").append(tableName).append(" (").append(columnName);
    sqlString.append(")");

    connection.executeAdhocSql(sqlString.toString());
  }

  private void createClusteredIndex(CmdbDalConnection connection, String tableName, String columnName) {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("CREATE CLUSTERED INDEX ").append("IX1_");
    sqlString.append(tableName);

    sqlString.append(" ON ").append("#").append(tableName).append(" (").append(columnName);
    sqlString.append(")");

    connection.executeAdhocSql(sqlString.toString());
  }

  private void createCmdbIDTempTable() {
    List columnsData = new ArrayList();

    columnsData.add("CMDB_ID Varbinary(16)");
    columnsData.add("T_VALUES_INDEX numeric");
    createTempTable("CDM_TMP_OBJID", columnsData);

    createClusteredIndex(getConnection(), "CDM_TMP_OBJID", "CMDB_ID");
  }

  private void createEntityIDTempTable() {
    List columnsData = new ArrayList();

    columnsData.add("ENTITY_ID numeric(28)");
    createTempTable("CCM_TMP_EID", columnsData);

    createIndex(getConnection(), "CCM_TMP_EID", "ENTITY_ID");
  }

  private void createTempTable(String tableName, List columnsData) {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("CREATE TABLE #").append(tableName);
    sqlString.append(" (");

    Iterator columnsDataIter = columnsData.iterator();
    while (columnsDataIter.hasNext()) {
      String columnData = (String)columnsDataIter.next();
      sqlString.append(columnData);
      if (columnsDataIter.hasNext())
        sqlString.append(", ");

    }

    sqlString.append(")");

    getConnection().executeAdhocSql(sqlString.toString());
  }

  private void createNumberTempTable() {
    List columnsData = new ArrayList();

    columnsData.add("T_VALUE numeric(28)");
    columnsData.add("T_VALUES_INDEX numeric");
    createTempTable("CDM_TMP_INT", columnsData);

    createIndex(getConnection(), "CDM_TMP_INT", "T_VALUE");
  }

  private void createStringTempTable() {
    List columnsData = new ArrayList();

    columnsData.add("T_VALUE VARCHAR(2000)");
    columnsData.add("T_VALUES_INDEX numeric");
    createTempTable("CDM_TMP_STR", columnsData);

    createIndex(getConnection(), "CDM_TMP_STR", "T_VALUE");
  }

  private void createCmdbIdStringTempTable() {
    List columnsData = new ArrayList();
    columnsData.add("CMDB_ID RAW(16)");
    columnsData.add("T_VALUE VARCHAR2(200)");
    columnsData.add("T_VALUES_INDEX NUMBER");
    createTempTable("CDM_TMP_OBJID_STR", columnsData);
    createIndex(getConnection(), "CDM_TMP_OBJID_STR", "CMDB_ID");
  }

  private String getTableName() {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    this._tableName = tableName;
  }
}