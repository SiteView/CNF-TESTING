package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.graph.object.EmptyModelObjects;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

public class CmdbDalObjectsConditionGetCmdbObjectsNoModelObjectsComplexCommand extends CmdbDalObjectsConditionComplexCommand
{
  public CmdbDalObjectsConditionGetCmdbObjectsNoModelObjectsComplexCommand(ElementCondition condition)
  {
    super(condition, EmptyModelObjects.getInstance());
  }

  protected Object perform() throws Exception {
    if ((getCondition() == null) || (getCondition().getClassCondition() == null))
      return CmdbObjectFactory.createObjects();

    return performQueryCondition();
  }

  protected Object getResult(CmdbDalResultSet resultSet) throws SQLException {
    return buildCmdbObjects(resultSet);
  }

  private CmdbObjects buildCmdbObjects(CmdbDalResultSet resultSet) throws SQLException
  {
    int maxResults = getLocalEnvironment().getSettingsReader().getInt("dal.object.condition.max.result.size", 500000);
    int currentResultCount = 0;

    CmdbObjects cmdbObjects = CmdbObjectFactory.createObjects();
    while (resultSet.next())
    {
      ++currentResultCount;
      if (currentResultCount > maxResults) {
        String errMsg = "Number of Object condition results exceeded the maximum allowed (max allowed value is: " + maxResults + ")";
        throw new CmdbDalException(errMsg);
      }

      byte[] objectIdAsBytes = resultSet.getBytes(1);
      CmdbObjectID objectID = restoreObjectID(objectIdAsBytes);

      String type = resultSet.getString(2);

      cmdbObjects.add(CmdbObjectFactory.createObject(objectID, type));
    }
    return cmdbObjects;
  }

  protected CmdbIDsCollection<? extends CmdbDataID> extractConditionIDs(Object modelElements, ElementCondition condition) {
    if ((condition.getIdsCondition() != null) && (!(isEmptyContainer(condition.getIdsCondition().getIds()))))
      return condition.getIdsCondition().getIds();

    return CmdbObjectIdsFactory.create();
  }

  protected void addSelectSql(StringBuffer conditionSql, Set<String> participatedClasses, List<Object> bindVariables, List<CmdbType> bindVariablesTypes)
  {
    StringBuffer selectSql = new StringBuffer();
    String conditionClassName = getCondition().getClassCondition().getClassName();
    selectSql.append("SELECT ").append(getDummyClassName(conditionClassName, getClassNameSuffix())).append(".");
    selectSql.append("CMDB_ID");
    selectSql.append(", ");
    selectSql.append(getDummyClassName("root", getClassNameSuffix())).append(".").append("CLASS");

    participatedClasses.add(getDummyClassName("root", getClassNameSuffix()));
    participatedClasses.add(getDummyClassName(conditionClassName, getClassNameSuffix()));

    addFromSql(selectSql, participatedClasses);

    selectSql.append(" WHERE ");
    selectSql.append("1=1");

    addPairsJoinSql(selectSql, participatedClasses, bindVariables, bindVariablesTypes);

    conditionSql.insert(0, selectSql);
  }
}