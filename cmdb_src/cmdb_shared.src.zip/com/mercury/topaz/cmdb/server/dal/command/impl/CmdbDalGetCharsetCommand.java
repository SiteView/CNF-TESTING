package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;

public class CmdbDalGetCharsetCommand extends CmdbDalAbstractCommand<String>
{
  protected String perform()
    throws Exception
  {
    CmdbDalConnection con = null;
    try {
      String sql = "sp_helpsort";
      if (isOracle())
        sql = "select VALUE from nls_database_parameters where parameter ='NLS_CHARACTERSET'";

      con = getConnection();
      JDBCTemplate jdbcTemplate = JDBCTemplate.getInstance(con);
      String str1 = jdbcTemplate.queryForString(sql);

      return str1;
    }
    finally
    {
      if (con != null)
        con.release();
    }
  }

  protected void validateInput()
  {
  }
}