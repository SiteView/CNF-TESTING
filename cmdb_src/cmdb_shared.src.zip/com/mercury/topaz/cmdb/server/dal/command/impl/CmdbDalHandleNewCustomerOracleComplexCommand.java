package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;

public class CmdbDalHandleNewCustomerOracleComplexCommand extends CmdbDalHandleNewCustomerComplexCommand
{
  protected void createDBTables(CmdbDalConnection connection)
    throws SQLException
  {
    super.createDBTables(connection);

    synchronized (CmdbDalHandleNewCustomerOracleComplexCommand.class)
    {
      if (!(checkExistenceOfCombinedIndexOnListOfAttributesTable()))
        createListOfAttributesTableCombinedIndex();
    }
  }

  private void createListOfAttributesTableCombinedIndex()
  {
    StringBuffer sqlString = new StringBuffer();

    String indexName = DalClassModelUtil.fixLongName("IX3_CONCAT_" + getTableNameByClassName("LIST_ATTR_PRIMITIVE"));

    sqlString.append("create index ").append(indexName).append(" on ");
    sqlString.append(getTableNameByClassName("LIST_ATTR_PRIMITIVE"));
    sqlString.append(" (").append("CMDB_ID").append(", ");
    sqlString.append("ATTR_NAME").append(")");

    getConnection().executeAdhocSql(sqlString.toString());
  }

  private boolean checkExistenceOfCombinedIndexOnListOfAttributesTable() throws SQLException {
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;
    try
    {
      StringBuffer sqlString = new StringBuffer();

      sqlString.append("SELECT 1 FROM USER_INDEXES IND WHERE EXISTS ");
      sqlString.append("(SELECT 1 FROM USER_IND_COLUMNS IND1 WHERE IND1.INDEX_NAME=IND.INDEX_NAME ");
      sqlString.append("AND IND1.TABLE_NAME = '").append(getTableNameByClassName("LIST_ATTR_PRIMITIVE"));
      sqlString.append("' AND IND1.COLUMN_NAME='").append("CMDB_ID");
      sqlString.append("' AND IND1.COLUMN_POSITION=1 ) AND EXISTS ");
      sqlString.append("(SELECT 1 FROM USER_IND_COLUMNS IND1 WHERE IND1.INDEX_NAME=IND.INDEX_NAME AND ");
      sqlString.append("IND1.TABLE_NAME = '").append(getTableNameByClassName("LIST_ATTR_PRIMITIVE"));
      sqlString.append("' AND IND1.COLUMN_NAME='").append("ATTR_NAME");
      sqlString.append("' AND IND1.COLUMN_POSITION=2 )");

      preparedStatement = getConnection().prepareStatement4Select(sqlString.toString());
      resultSet = preparedStatement.executeQuery();

      boolean bool = resultSet.next();

      return bool;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }
}