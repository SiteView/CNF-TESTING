package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.cost_estimate;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.CmdbDalDataModelComplexCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import java.sql.SQLException;

class OracleEstimationSupport extends CmdbDalDataModelComplexCommand
{
  protected void validateInput()
  {
  }

  protected Log getLogger()
  {
    return LogFactory.getEasyLog(getClass());
  }

  protected Boolean perform() throws Exception {
    boolean planTableExists = planTableExists();

    return Boolean.valueOf(planTableExists);
  }

  private boolean planTableExists() throws SQLException {
    CmdbDalPreparedStatement preparedStatement = null;
    try
    {
      preparedStatement = createPreparedStatement(getConnection(), OracleEstimationUtil.getPlanTableVerificationSql());

      boolean bool = OracleEstimationUtil.planTableExists(preparedStatement);

      return bool;
    }
    finally
    {
      if (preparedStatement != null)
        preparedStatement.close();
    }
  }
}