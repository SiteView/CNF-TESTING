package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;

public abstract class CmdbDalUpdateClassPropertyComplexCommand extends CmdbDalUpdatePropertyComplexCommand
{
  public CmdbDalUpdateClassPropertyComplexCommand(CmdbClass cmdbClass)
  {
    super(cmdbClass);
  }

  protected String getTableNameToUpdate() {
    return "CCM_CLASSES";
  }

  protected String getRowIdConditionColumnName() {
    return "CLASS_ID";
  }

  protected Long getRowId() throws SQLException {
    Long classId = getClassID(getCmdbClass().getName(), getConnection());
    return classId;
  }
}