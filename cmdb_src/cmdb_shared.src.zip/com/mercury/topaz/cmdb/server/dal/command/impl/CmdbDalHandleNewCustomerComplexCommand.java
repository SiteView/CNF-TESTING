package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.command.classmodel.impl.CmdbDalClassModelCommandFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import java.sql.SQLException;

public class CmdbDalHandleNewCustomerComplexCommand extends CmdbDalAbstractCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalHandleNewCustomerComplexCommand.class);
  public static final String DISABLE_PARTITION_CREATION = "DISABLE_PARTITION_CREATION";

  protected void validateInput()
  {
  }

  protected Object perform()
  {
    initNewCustomer();

    return null;
  }

  private void initNewCustomer()
  {
    CmdbDalConnection connection;
    try {
      connection = getConnection();

      if (_logger.isDebugEnabled()) {
        _logger.debug("Initialize new customer: [" + getLocalEnvironment().getCustomerID() + "]");
      }

      createDBTables(connection);
    }
    catch (Exception e) {
      String errMsg = "Error initialize new customer [" + getLocalEnvironment().getCustomerID() + "], due to exception: " + e;
      _logger.error(errMsg, e);

      throw new CmdbDalException(errMsg, e);
    }
  }

  protected void createDBTables(CmdbDalConnection connection) throws SQLException
  {
    createMigrationTable();
    createListOfAttributesTable();
  }

  private void updateMigrationTableWithListOfAttributesTable() throws SQLException {
    if (!(isMigrationTableUpdatedWithListOfAttributesTable()))
    {
      Long classID = generateAndConfirmSequenceID();
      CmdbDalCommand updateMigrationTableCommand = CmdbDalClassModelCommandFactory.createUpdateAddMigrationTableComplexCommand("LIST_ATTR_PRIMITIVE", classID);
      updateMigrationTableCommand.execute();
    }
  }

  private boolean isMigrationTableUpdatedWithListOfAttributesTable() throws SQLException {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("SELECT 1 FROM ").append("CCM_MIGR_TBL");
    sqlString.append(" WHERE ").append("SEPARATE_NAME").append("=?");

    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString.toString());
    preparedStatement.setString(getCustomerTableNameByClassName("LIST_ATTR_PRIMITIVE"));

    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    boolean res = resultSet.next();

    resultSet.close();
    preparedStatement.close();

    return res;
  }

  private void createListOfAttributesTable() throws SQLException {
    updateMigrationTableWithListOfAttributesTable();

    String tableName = getTableNameByClassName("LIST_ATTR_PRIMITIVE");
    TableDescription table = new TableDescription(tableName);
    table.addColumn("CMDB_ID").ofCmdbType(CmdbSimpleTypes.CmdbBytes).ofSize(16).notNullable();

    if (!(isUpdateClassModelEnabled())) {
      table.addColumn("CUSTOMER_ID").ofCmdbType(CmdbSimpleTypes.CmdbInteger).notNullable();
    }

    table.addColumn("ATTR_NAME").ofCmdbType(CmdbSimpleTypes.CmdbString).ofSize(50).notNullable();

    table.addColumn("ATTR_VALUE").ofCmdbType(CmdbSimpleTypes.CmdbString).ofSize(2000);

    table.addIndex("CMDB_ID").clustered();
    table.addIndex("ATTR_NAME");

    CmdbDalCommand createTableCommand = CmdbDalCommandFactory.createCreateTableComplexCommand(table);
    createTableCommand.execute();
  }

  private void createMigrationTable() {
    String tableName = "CCM_MIGR_TBL";
    TableDescription table = new TableDescription(tableName);
    table.addColumn("CLASS_ID").ofCmdbType(CmdbSimpleTypes.CmdbLong).notNullable();
    table.addColumn("CUSTOMER_ID").ofCmdbType(CmdbSimpleTypes.CmdbInteger).notNullable();
    table.addColumn("UNIFIED_NAME").ofCmdbType(CmdbSimpleTypes.CmdbString).ofSize(30).notNullable();
    table.addColumn("SEPARATE_NAME").ofCmdbType(CmdbSimpleTypes.CmdbString).ofSize(30).notNullable();

    table.setPrimaryKey(new IndexDescription("CLASS_ID"));

    getConnection().setProperty("DISABLE_PARTITION_CREATION", Boolean.TRUE);
    try
    {
      CmdbDalCommand createTableCommand = CmdbDalCommandFactory.createCreateTableComplexCommand(table);
      createTableCommand.execute();
    } finally {
      getConnection().setProperty("DISABLE_PARTITION_CREATION", Boolean.FALSE);
    }
  }

  protected boolean isTableExist(String tableName) {
    CmdbDalCommand command = CmdbDalCommandFactory.createCheckTableExistenceSimpleCommand(tableName);
    CmdbDalCommandResult result = command.execute();
    return ((Boolean)result.getResult()).booleanValue();
  }
}