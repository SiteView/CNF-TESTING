package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CalculatedLinkTripletDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;

public class CmdbDalRemoveCalculatedLinkComplexCommand extends CmdbDalClassModelComplexCommand
{
  private CmdbCalculatedLink _calculatedLink;
  private CmdbClass _cmdbClass;
  private Long _classID;

  public CmdbDalRemoveCalculatedLinkComplexCommand(CmdbCalculatedLink cmdbCalculatedLink, CmdbClass cmdbClass)
  {
    setCalculatedLink(cmdbCalculatedLink);
    setCmdbClass(cmdbClass);
  }

  protected Object perform() {
    removeCalculatedLink(getCalculatedLink());
    return null;
  }

  protected void validateInput()
  {
  }

  private void removeCalculatedLink(CmdbCalculatedLink calculatedLink) {
    try {
      removeCalculatedTriplets(calculatedLink.getTriplets());
      removeClass(getCmdbClass());
    }
    catch (Exception e) {
      String errMsg = "Error remove calculated link [], due to exception: " + e;
      throw new CmdbDalException(errMsg, e);
    }
  }

  private void removeClass(CmdbClass cmdbClass) throws SQLException {
    CmdbDalCommand removeClassCommand = CmdbDalClassModelCommandFactory.createRemoveClassComplexCommand(cmdbClass);
    removeClassCommand.execute();
  }

  private void removeCalculatedTriplets(Collection<CalculatedLinkTripletDefinition> triplets) throws SQLException {
    Long classID = getLinkClassID();
    for (Iterator i$ = triplets.iterator(); i$.hasNext(); ) { CalculatedLinkTripletDefinition triplet = (CalculatedLinkTripletDefinition)i$.next();
      CmdbDalCommand removeCalculatedTripletCommand = CmdbDalClassModelCommandFactory.createRemoveCalculatedLinkTripletComplexCommand(triplet, getCmdbClass(), classID);
      removeCalculatedTripletCommand.execute();
    }
  }

  protected CmdbCalculatedLink getCalculatedLink() {
    return this._calculatedLink;
  }

  private void setCalculatedLink(CmdbCalculatedLink calculatedLink) {
    this._calculatedLink = calculatedLink;
  }

  protected CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass;
  }

  protected Long getLinkClassID() throws SQLException {
    Long classId = this._classID;

    if (classId == null) {
      classId = getClassID(getCmdbClass().getName(), getConnection());
      setLinkClassID(classId);
    }

    return classId;
  }

  private void setLinkClassID(Long classID) {
    this._classID = classID;
  }
}