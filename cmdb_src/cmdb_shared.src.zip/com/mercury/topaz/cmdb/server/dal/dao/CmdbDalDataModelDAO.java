package com.mercury.topaz.cmdb.server.dal.dao;

import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.topaz.cmdb.server.dal.command.CmdbDalDataModelUpdateDAO;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.model.graph.ModelGraph;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrappers;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbUnresolvedDataIDs;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternLinkJoinfParameter;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import com.mercury.topaz.cmdb.shared.tql.result.CmdbAttributeGroupedByCount;
import com.mercury.topaz.cmdb.shared.tql.result.CmdbClassCount;
import java.util.List;
import java.util.Set;

public abstract interface CmdbDalDataModelDAO extends CmdbDalDataModelUpdateDAO
{
  public abstract CmdbObjects getObjectsLayout(ModelObjects paramModelObjects, ElementSimpleLayout paramElementSimpleLayout);

  public abstract CmdbLinks getLinksLayout(ModelLinks paramModelLinks, ElementSimpleLayout paramElementSimpleLayout);

  public abstract ModelLinks getLinks(LinkCondition paramLinkCondition, ModelLinks paramModelLinks);

  public abstract ModelLinks getLinks(ElementCondition paramElementCondition1, LinkCondition paramLinkCondition, ElementCondition paramElementCondition2);

  public abstract ModelLinks getLinksOfObjects(ElementCondition paramElementCondition, LinkCondition paramLinkCondition);

  public abstract int countClassInstances(String paramString, boolean paramBoolean);

  public abstract CmdbClassCount countClassesInstances();

  public abstract CmdbObjects getFunctionsLayout(ModelObjects paramModelObjects1, ModelLinks paramModelLinks, ModelObjects paramModelObjects2, LayoutFunctionWrappers paramLayoutFunctionWrappers);

  public abstract CmdbObjectIds sortObjects(ModelObjects paramModelObjects, CmdbSortCommand paramCmdbSortCommand);

  public abstract CmdbObjectIds sortObjects(ElementCondition paramElementCondition, CmdbSortCommand paramCmdbSortCommand);

  public abstract CmdbLinks sortLinks(ModelLinks paramModelLinks, CmdbSortCommand paramCmdbSortCommand);

  public abstract void startTransaction();

  public abstract void commitTransaction();

  public abstract void rollbackTransaction();

  public abstract ModelGraph loadModelTopology(Set<String> paramSet);

  public abstract CmdbObjectIds getObjectsIDs(ElementCondition paramElementCondition);

  public abstract CmdbObjectIds getObjectsIDs(ElementCondition paramElementCondition, ModelObjects paramModelObjects);

  public abstract CmdbObjects getCmdbObjects(ElementCondition paramElementCondition);

  public abstract CmdbLinks getCmdbLinks(LinkCondition paramLinkCondition);

  public abstract List getJoinObjectIDPairs(ElementCondition paramElementCondition1, ElementCondition paramElementCondition2, PatternLinkJoinfParameter paramPatternLinkJoinfParameter, LinkCondition paramLinkCondition);

  public abstract List getJoinObjectIDPairs(ElementCondition paramElementCondition1, ElementCondition paramElementCondition2, ModelObjects paramModelObjects1, ModelObjects paramModelObjects2, PatternLinkJoinfParameter paramPatternLinkJoinfParameter, LinkCondition paramLinkCondition);

  public abstract CmdbObjectIds getRecursiveDeleteSurvivors(CmdbLinks paramCmdbLinks1, CmdbLinks paramCmdbLinks2, CmdbLinkIds paramCmdbLinkIds);

  /**
   * @deprecated
   */
  public abstract CmdbGraph getCmdbGraph();

  public abstract CmdbAttributeGroupedByCount getObjectsAttributesGroupedByCount(ElementCondition paramElementCondition, ModelObjects paramModelObjects, String paramString);

  public abstract CmdbIDsCollection resolveCmdbIDs(CmdbUnresolvedDataIDs paramCmdbUnresolvedDataIDs);

  public abstract double estimateGettingCIs(ElementCondition paramElementCondition);

  public abstract boolean isCostEstimationSupported();

  public abstract void optimizeStorage();

  public abstract DbContext getDbContext();

  public abstract <T> CmdbDalCommandResult<T> executeQuery(CmdbDalCommand<T> paramCmdbDalCommand);
}