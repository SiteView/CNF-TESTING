package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class CmdbDalGetModelRevision extends CmdbDalAbstractCommand<Long>
{
  protected void validateInput()
  {
  }

  protected Long perform()
    throws Exception
  {
    CmdbDalConnection connection = getConnectionPool().getTransactionalConnection();
    try {
      String selectSql = "SELECT CHANGE_ID FROM TOPOLOGY_CHANGES_MGMT WHERE CUSTOMER_ID= ?";

      Long changeId = JDBCTemplate.getInstance(connection).queryForLong(selectSql, new Object[] { Integer.valueOf(getCustomerID().getID()) });
      if (changeId == null) {
        localLong1 = Long.valueOf(0L);

        return localLong1;
      }
      Long localLong1 = changeId;

      return localLong1;
    }
    finally
    {
      getConnectionPool().releaseConnection(connection);
    }
  }
}