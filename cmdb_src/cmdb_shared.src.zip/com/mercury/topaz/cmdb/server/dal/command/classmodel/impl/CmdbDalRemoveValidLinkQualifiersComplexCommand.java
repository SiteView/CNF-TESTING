package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.CmdbModifiableValidLinkQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.CmdbValidLinkQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.impl.CmdbValidLinkQualifierFactory;
import java.sql.SQLException;

public class CmdbDalRemoveValidLinkQualifiersComplexCommand extends CmdbDalRemoveQualifiersComplexCommand
{
  private CmdbValidLink _cmdbValidLink;

  public CmdbDalRemoveValidLinkQualifiersComplexCommand(CmdbValidLink cmdbValidLink, BasicContainer qualifires, Long entityId)
  {
    super(qualifires, entityId);
    setCmdbValidLink(cmdbValidLink);
  }

  public CmdbDalRemoveValidLinkQualifiersComplexCommand(CmdbValidLink cmdbValidLink, CmdbValidLinkQualifier qualifier, Long entityId) {
    super(null, entityId);
    CmdbModifiableValidLinkQualifiers qualifiers = CmdbValidLinkQualifierFactory.createValidLinkQualifiers();
    qualifiers.add(qualifier);
    setQualifires(qualifiers);
    setCmdbValidLink(cmdbValidLink);
  }

  protected String getCommandName() {
    return "Remove valid link qualifiers [" + getQualifires() + "] of cmdb valid link [" + getCmdbValidLink() + "]";
  }

  protected Long getEntityIdFromDB() throws SQLException {
    return getValidLinkID(getCmdbValidLink(), getConnection());
  }

  private CmdbValidLink getCmdbValidLink() {
    return this._cmdbValidLink;
  }

  private void setCmdbValidLink(CmdbValidLink cmdbValidLink) {
    this._cmdbValidLink = cmdbValidLink;
  }
}