package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.dal.exception.CmdbDalValidationException;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CmdbDalRemoveLinksComplexCommand extends CmdbDalDataModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalRemoveLinksComplexCommand.class);
  private CmdbLinks _cmdbLinks = null;

  public CmdbDalRemoveLinksComplexCommand(CmdbLinks cmdbLinks)
  {
    setCmdbLinks(cmdbLinks);
  }

  protected void validateInput() {
    if ((getCmdbLinks() == null) || (getCmdbLinks().isEmpty()))
      throw new CmdbDalValidationException("Can't remove links - null or empty links");
  }

  protected void postProcess() throws Exception
  {
    truncateCmdbIDTempTable(getConnection());
  }

  protected Object perform() {
    removeLinks(getCmdbLinks());

    return null;
  }

  private CmdbLinks getCmdbLinks() {
    return this._cmdbLinks;
  }

  private void setCmdbLinks(CmdbLinks cmdbLinks) {
    this._cmdbLinks = cmdbLinks;
  }

  private void removeLinks(CmdbLinks links) {
    if (_logger.isDebugEnabled())
      _logger.debug("Remove [" + links.size() + "] links");

    try
    {
      Map elementsFromSameTypeMap = sortElementsToTypesOld(links);

      for (Iterator i$ = elementsFromSameTypeMap.keySet().iterator(); i$.hasNext(); ) { String type = (String)i$.next();
        List linksFromSameTypeList = (List)elementsFromSameTypeMap.get(type);

        removeLinks(linksFromSameTypeList, type, getConnection());
      }
    }
    catch (Exception e) {
      String errMsg = "Error removing cmdb links [" + links + "], due to exception: " + e;
      _logger.error(errMsg);
      throw new CmdbDalException("Error removing cmdb links. Check log for details !!!", e);
    }
  }

  private void removeLinks(List<CmdbLink> links, String type, CmdbDalConnection connection) {
    try {
      if (_logger.isDebugEnabled()) {
        _logger.debug("Remove links from type: " + type);
      }

      CmdbClass leafCmdbClass = ClassModelUtil.getCmdbClassByName(type);
      List cmdbClasses = getCmdbClassAncestors(leafCmdbClass);
      List classesNames = getClassesNames(cmdbClasses);

      classesNames.add("LIST_ATTR_PRIMITIVE");

      List ids = elementsToIDsAsBytes(links);

      if (isCmdbIDTempTableMustNotUsingChunksMechanism(ids.size())) {
        createCmdbIDTempTable(connection, ids);
      }

      for (Iterator i$ = classesNames.iterator(); i$.hasNext(); ) { String className = (String)i$.next();

        String sqlString = createDeleteSql(className, ids.size());
        CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

        if (!(isCmdbIDTempTableMustNotUsingChunksMechanism(ids.size())))
          addIDsToPrepareStatement(preparedStatement, ids);

        if (!(isUpdateClassModelEnabled())) {
          preparedStatement.setInt(getCustomerID().getID());
        }

        preparedStatement.executeUpdate();
        preparedStatement.close();
      }
    }
    catch (Exception e) {
      String errMsg = "Error removing cmdb links from type [" + type + "], due to exception: " + e;
      throw new CmdbDalException(errMsg, e);
    }
  }
}