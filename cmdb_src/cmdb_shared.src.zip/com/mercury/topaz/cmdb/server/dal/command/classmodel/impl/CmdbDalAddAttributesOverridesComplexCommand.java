package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverrides;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributeOverrides;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.impl.CmdbAttributeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalAddAttributesOverridesComplexCommand extends CmdbDalClassModelComplexCommand<Void>
{
  private CmdbAttributeOverrides attributeOverrides;
  private final CmdbClass cmdbClass;
  private Long classId;

  public CmdbDalAddAttributesOverridesComplexCommand(CmdbAttributeOverrides attributeOverrides, CmdbClass cmdbClass, Long classId)
  {
    this.cmdbClass = cmdbClass;
    this.classId = classId;
    this.attributeOverrides = attributeOverrides;
  }

  public CmdbDalAddAttributesOverridesComplexCommand(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass, Long classId) {
    this.cmdbClass = cmdbClass;
    this.classId = classId;

    CmdbModifiableAttributeOverrides attributeOverrides = CmdbAttributeFactory.createAttributeOverrides();
    attributeOverrides.add(attributeOverride);
    this.attributeOverrides = attributeOverrides;
  }

  protected Void perform() throws Exception {
    addAttributeOverrides();
    return null;
  }

  protected void validateInput() {
    if (getCmdbClass() == null)
      throw new CmdbDalException("Can't add attributes overrides of null cmdb class !!!");
  }

  private void addAttributeOverrides() throws SQLException
  {
    if ((this.attributeOverrides == null) || (this.attributeOverrides.isEmpty())) {
      return;
    }

    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalConnection connection = getConnection();
    try
    {
      String sqlString = createInsertAttributesTableSql();
      preparedStatement = connection.prepareStatement4Update(sqlString);

      ReadOnlyIterator iter = this.attributeOverrides.getIterator();
      int attributeIndex = getLastOrderingIndex("ATTRIBUTE_INDEX", "CCM_ATTRIBUTE", "CLASS_ID", getClassId());
      while (iter.hasNext()) {
        CmdbAttributeOverride attributeOverride = (CmdbAttributeOverride)iter.next();
        ++attributeIndex;

        addAttributeOverride(preparedStatement, attributeOverride, attributeIndex);
      }
    } finally {
      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private String createInsertAttributesTableSql()
  {
    List columnsNames = createAttributesTableColumnsNames();

    return createInsertSql("CCM_ATTRIBUTE", columnsNames);
  }

  private void addAttributeOverride(CmdbDalPreparedStatement preparedStatement, CmdbAttributeOverride attributeOverride, int attributeIndex) throws SQLException {
    Long attributeID = generateAndConfirmSequenceID();
    preparedStatement.setLong(attributeID);
    preparedStatement.setLong(getClassId());
    preparedStatement.setString(attributeOverride.getName());
    preparedStatement.setString(null);
    preparedStatement.setString(null);
    preparedStatement.setClob(attributeOverride.getDefaultValue());
    String typeAsString = (attributeOverride.isDefaultValueXmlType()) ? CmdbSimpleTypes.CmdbXml.getName() : null;
    preparedStatement.setString(typeAsString);
    preparedStatement.setInt(null);
    preparedStatement.setInt(1);
    preparedStatement.setBoolean(attributeOverride.isPartiallyOverride());
    preparedStatement.setBoolean(attributeOverride.hasEmptyDefaultValue());
    preparedStatement.setInt(attributeIndex);
    preparedStatement.setBoolean(attributeOverride.isCreatedByFactory());
    preparedStatement.setBoolean(attributeOverride.isModifiedByUser());

    preparedStatement.executeUpdate();

    addQualifiers(attributeOverride, attributeID);
  }

  private void addQualifiers(CmdbAttributeOverride attributeOverride, Long attributeID) {
    CmdbDalCommand addAttributeQualifiersCommand = CmdbDalClassModelCommandFactory.createAddAttributeQualifiersComplexCommand(attributeOverride, getCmdbClass(), attributeOverride.getQualifiers(), attributeID);
    addAttributeQualifiersCommand.execute();
  }

  public CmdbClass getCmdbClass() {
    return this.cmdbClass;
  }

  private Long getClassId() throws SQLException {
    Long classId = this.classId;

    if (classId == null) {
      classId = getClassID(getCmdbClass().getName(), getConnection());
      this.classId = classId;
    }

    return classId;
  }
}