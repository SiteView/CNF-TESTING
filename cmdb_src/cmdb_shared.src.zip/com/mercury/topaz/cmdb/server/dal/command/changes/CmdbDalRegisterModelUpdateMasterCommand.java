package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.am.platform.controller.Server;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class CmdbDalRegisterModelUpdateMasterCommand extends CmdbDalAbstractCommand<Void>
{
  protected Void perform()
    throws Exception
  {
    String updateSql = "UPDATE TOPOLOGY_CHANGES_MGMT SET MASTER= ? WHERE CUSTOMER_ID= ?";

    JDBCTemplate jdbcTemplate = JDBCTemplate.getInstance(getConnection());
    int rowsUpdated = jdbcTemplate.executeUpdate(updateSql, new Object[] { Server.getLocal().getName(), Integer.valueOf(getCustomerID().getID()) });
    if (rowsUpdated == 1) {
      return null;
    }

    String insertSql = "INSERT INTO TOPOLOGY_CHANGES_MGMT(ID,MASTER,CHANGE_ID,CUSTOMER_ID) VALUES (" + jdbcTemplate.GUID() + ",?,?,?)";

    jdbcTemplate.executeUpdate(insertSql, new Object[] { Server.getLocal().getName(), Long.valueOf(0L), Integer.valueOf(getCustomerID().getID()) });

    return null;
  }

  protected void validateInput()
  {
  }
}