package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.tql.result.CmdbModifiableClassCount;
import com.mercury.topaz.cmdb.shared.tql.result.impl.CmdbClassCountFactory;

public class CmdbDalCountClassesInstancesComplexCommand extends CmdbDalDataModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalCountClassesInstancesComplexCommand.class);

  protected void prepare()
    throws Exception
  {
    setUseDirtyRead();
  }

  protected void validateInput() {
  }

  protected Object perform() throws Exception {
    StringBuffer sqlString = new StringBuffer();
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;
    CmdbModifiableClassCount classCount = CmdbClassCountFactory.createClassCount();
    try {
      sqlString.append("SELECT ").append("CLASS").append(",COUNT(*) FROM ").append(getTableNameByClassName("root"));
      if (!(isUpdateClassModelEnabled()))
        sqlString.append(" WHERE ").append("CUSTOMER_ID").append("=?");

      sqlString.append(" GROUP BY ").append("CLASS");
      preparedStatement = getConnection().prepareStatement4Select(sqlString.toString());

      if (!(isUpdateClassModelEnabled()))
        preparedStatement.setInt(getCustomerID().getID());

      resultSet = preparedStatement.executeQuery();

      CmdbClassModel classModel = getSynchronizedClassModel();
      while (resultSet.next()) {
        className = resultSet.getString(1);
        Integer count = resultSet.getInt(2);
        addClassToCount(classModel, classCount, className, count);
      }
      String className = classCount;

      return className;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private void addClassToCount(CmdbClassModel classModel, CmdbModifiableClassCount classCount, String className, Integer count)
  {
    int currentClassCount = classCount.getClassCount(className);
    int newClassCount = currentClassCount + count.intValue();
    classCount.put(className, newClassCount);
    String superClassName = classModel.getClass(className).getResolvedSuperClass().getName();
    if (!("none".equals(superClassName)))
      addClassToCount(classModel, classCount, superClassName, count);
  }

  protected String getCommandName()
  {
    return "Count instances for all cmdb classes";
  }
}