package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.cost_estimate;

import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;

public class EstimateGettingCIs extends CmdbDalAbstractCommand
{
  private ElementCondition condition;

  public EstimateGettingCIs(ElementCondition condition)
  {
    this.condition = condition;
  }

  protected void validateInput() {
  }

  protected Object perform() throws Exception {
    if (getConnectionPool().isUsingMSSqlDB()) {
      throw new UnsupportedOperationException("Cost estimation is not supported for MS-SQL");
    }

    return new OracleEstimate(this.condition).execute();
  }
}