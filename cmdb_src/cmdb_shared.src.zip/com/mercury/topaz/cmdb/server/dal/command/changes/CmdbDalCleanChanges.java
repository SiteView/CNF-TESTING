package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;

public class CmdbDalCleanChanges extends CmdbDalAbstractCommand<Void>
{
  protected Void perform()
    throws Exception
  {
    int oldestGeneration = CmdbDalChangesManagement.getOldestChangeTableGeneration(getConnection());
    String changeDetailsTable = "TOPOLOGY_CHANGES_" + oldestGeneration;
    String cleanChangesDetailsSql = "TRUNCATE TABLE " + changeDetailsTable;
    JDBCTemplate.getInstance(getConnection()).executeUpdate(cleanChangesDetailsSql);
    return null;
  }

  protected void validateInput()
  {
  }
}