package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;

public class CmdbDalUpdateClassParentComplexCommand extends CmdbDalUpdateClassPropertyComplexCommand
{
  public CmdbDalUpdateClassParentComplexCommand(CmdbClass cmdbClass)
  {
    super(cmdbClass);
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long classId) throws SQLException {
    Long parentId = getClassID(getCmdbClass().getSuperClass(), getConnection());
    preparedStatement.setLong(parentId);
    preparedStatement.setBoolean(getCmdbClass().isModifiedByUser());
    preparedStatement.setLong(classId);
  }

  protected String getColumnNameToUpdate() {
    return "PARENT_ID";
  }
}