package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class CmdbDalCreateNewChange extends CmdbDalAbstractCommand<Change>
{
  protected Change perform()
    throws Exception
  {
    return getNextChange();
  }

  private Change getNextChange() {
    CmdbDalConnection connection = getConnectionPool().getTransactionalConnection();
    try {
      int changeTableGeneration = CmdbDalChangesManagement.getCurrentChangeTableGeneration(connection);
      String updateSql = "UPDATE TOPOLOGY_CHANGES_MGMT SET CHANGE_ID=CHANGE_ID + 1 WHERE CUSTOMER_ID= ?";

      JDBCTemplate jdbcTemplate = JDBCTemplate.getInstance(connection);
      int rowsUpdated = jdbcTemplate.executeUpdate(updateSql, new Object[] { Integer.valueOf(getCustomerID().getID()) });

      String selectSql = "SELECT CHANGE_ID FROM TOPOLOGY_CHANGES_MGMT WHERE CUSTOMER_ID= ?";

      long changeId = jdbcTemplate.queryForLong(selectSql, new Object[] { Integer.valueOf(getCustomerID().getID()) }).longValue();
      connection.commit();
      Change localChange = new Change(changeId, changeTableGeneration);

      return localChange;
    }
    finally
    {
      getConnectionPool().releaseConnection(connection);
    }
  }

  protected void validateInput()
  {
  }
}