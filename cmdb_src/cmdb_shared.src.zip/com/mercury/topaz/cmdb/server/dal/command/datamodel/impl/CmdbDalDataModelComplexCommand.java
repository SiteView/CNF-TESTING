package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.util.time.CmdbTime;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.CmdbTopologicalData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbUnresolvedDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbUnresolvedDataIDs;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.link.id.impl.CmdbLinkIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public abstract class CmdbDalDataModelComplexCommand<RESULT> extends CmdbDalAbstractCommand<RESULT>
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalDataModelComplexCommand.class);
  private static final int CMDB_ID_TEMP_TABLE_INIT_VAL = 0;
  private Boolean _isUseStatement = null;
  private final CmdbClassModel classModel;
  private final DataFactory dataFactory;

  protected CmdbDalDataModelComplexCommand()
  {
    this.classModel = ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
    this.dataFactory = DataFactoryCreator.create(this.classModel);
  }

  protected boolean isUseStatement() {
    if (this._isUseStatement == null) {
      SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();
      this._isUseStatement = Boolean.valueOf(settingsReader.getBoolean("dal.use.statement", true));
      if (isMsSql())
        this._isUseStatement = Boolean.valueOf(false);
    }

    return this._isUseStatement.booleanValue();
  }

  protected CmdbClassModel getSynchronizedClassModel() {
    return this.classModel;
  }

  protected DataFactory getDataFactory() {
    return this.dataFactory;
  }

  protected Map<String, CmdbClass> createAttributes2ClassesMap(ReadOnlyIterator<String> attrNameIter, CmdbClass baseClass) {
    Map attributes2ClassesMap = new HashMap();

    while (attrNameIter.hasNext()) {
      String attrName = (String)attrNameIter.next();
      CmdbClass cmdbClass = ClassModelUtil.getAttributeClass(attrName, baseClass);

      attributes2ClassesMap.put(attrName, cmdbClass);
    }
    return attributes2ClassesMap;
  }

  protected List<String> extractPersistentAttrNames(Iterator<String> attrIter, String baseClassName)
  {
    List persistentAttrNames = new ArrayList();
    CmdbAttributes attributes = ClassModelUtil.extractAllPersistentAttributes(ClassModelUtil.getCmdbClassByName(baseClassName));
    while (attrIter.hasNext()) {
      String attrName = (String)attrIter.next();
      if (attributes.hasAttribute(attrName))
        persistentAttrNames.add(attrName);
    }

    return persistentAttrNames;
  }

  protected String getBaseCmdbClass(String referenceClassName, List<String> attributeNamesList)
  {
    CmdbClass referenceCmdbClass = ClassModelUtil.getCmdbClassByName(referenceClassName);

    while (!(referenceCmdbClass.getName().equals("none"))) {
      CmdbAttributes attributes = ClassModelUtil.extractPersistentAttributes(referenceCmdbClass);
      ReadOnlyIterator attributesIter = attributes.getIterator();
      while (attributesIter.hasNext()) {
        CmdbAttributeDefinition attribute = (CmdbAttributeDefinition)attributesIter.next();
        if (attributeNamesList.contains(attribute.getName()))
          return referenceCmdbClass.getName();

      }

      referenceCmdbClass = referenceCmdbClass.getResolvedSuperClass();
    }

    String errMsg = "Can't find base cmdb class for attributes: [" + attributeNamesList + "], with " + "reference class: [" + referenceClassName + "]. Returns lower (root/link) base class !!!";

    _logger.info(errMsg);

    if (isTypeOfLink(referenceClassName))
      return "link";

    return "root";
  }

  protected String createInsert2ListOfAttributesTableSql()
  {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("INSERT INTO ").append(getTableNameByClassName("LIST_ATTR_PRIMITIVE"));
    sqlString.append("(").append("CMDB_ID");
    sqlString.append(", ").append("ATTR_NAME");
    sqlString.append(", ").append("ATTR_VALUE");
    if (!(isUpdateClassModelEnabled())) {
      sqlString.append(", ").append("CUSTOMER_ID");
    }

    sqlString.append(") values (?, ?, ?");
    if (!(isUpdateClassModelEnabled())) {
      sqlString.append(", ?");
    }

    sqlString.append(")");

    return sqlString.toString();
  }

  protected String createInsertSql(String cmdbClassName, CmdbAttributes attributes) {
    int numOfColumns = 1;
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("INSERT INTO ").append(getTableNameByClassName(cmdbClassName)).append("(").append("CMDB_ID");

    if (!(isUpdateClassModelEnabled())) {
      sqlString.append(", ").append("CUSTOMER_ID");
      ++numOfColumns;
    }
    if (cmdbClassName.equalsIgnoreCase("root")) {
      sqlString.append(", ").append("CLASS");
      ++numOfColumns;
    }
    if (cmdbClassName.equalsIgnoreCase("link")) {
      sqlString.append(", ").append("END1_ID");
      ++numOfColumns;
      sqlString.append(", ").append("END2_ID");
      ++numOfColumns;
      sqlString.append(", ").append("CLASS");
      ++numOfColumns;
    }

    if ((attributes != null) && (!(attributes.isEmpty()))) {
      ReadOnlyIterator attributesIter = attributes.getIterator();

      while (attributesIter.hasNext()) {
        CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();
        CmdbType type = attribute.getResolvedType();
        if ((!(CmdbSimpleTypes.CmdbStringList.equals(type))) && (!(CmdbSimpleTypes.CmdbIntegerList.equals(type)))) {
          sqlString.append(", ");
          sqlString.append(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName()));
          ++numOfColumns;
        }
      }
    }

    sqlString.append(") values (?");
    for (int i = 0; i < numOfColumns - 1; ++i)
      sqlString.append(",?");

    sqlString.append(")");

    return sqlString.toString();
  }

  protected String createDeleteSql(String cmdbClassName, int numOfCmdbIDs) {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("DELETE FROM ").append(getTableNameByClassName(cmdbClassName)).append(" WHERE ");

    if (isCmdbIDTempTableMustNotUsingChunksMechanism(numOfCmdbIDs)) {
      sqlString.append(createJoinWithCmdbIDTempTableConditionSql(getTableNameByClassName(cmdbClassName), numOfCmdbIDs));
    }
    else
    {
      sqlString.append(getTableNameByClassName(cmdbClassName)).append(".").append("CMDB_ID");
      sqlString.append(getInSqlString(numOfCmdbIDs));
    }
    if (!(isUpdateClassModelEnabled())) {
      sqlString.append(" AND ").append("CUSTOMER_ID").append("=?");
    }

    return sqlString.toString();
  }

  protected String createDeleteListOfAttribsSql() {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("DELETE FROM ").append(getTableNameByClassName("LIST_ATTR_PRIMITIVE"));
    sqlString.append(" WHERE ").append("CMDB_ID").append("=? AND ");
    sqlString.append("ATTR_NAME").append("=?");
    if (!(isUpdateClassModelEnabled())) {
      sqlString.append(" AND ").append("CUSTOMER_ID").append("=?");
    }

    return sqlString.toString();
  }

  protected String createUpdateSql(String cmdbClassName, Collection<? extends CmdbAttribute> attributes) {
    StringBuffer sqlString = createUpdateSqlWithNoCondition(cmdbClassName, attributes);

    sqlString.append(" WHERE ").append("CMDB_ID").append(" = ?");
    if (!(isUpdateClassModelEnabled())) {
      sqlString.append(" AND ").append("CUSTOMER_ID").append("=?");
    }

    return sqlString.toString();
  }

  protected String createUpdateSql(String cmdbClassName, Collection<? extends CmdbAttribute> attributes, int numOfCmdbIDs) {
    StringBuffer sqlString = createUpdateSqlWithNoCondition(cmdbClassName, attributes);

    sqlString.append(" WHERE ");

    if (isCmdbIDTempTableMustNotUsingChunksMechanism(numOfCmdbIDs)) {
      sqlString.append(createJoinWithCmdbIDTempTableConditionSql(getTableNameByClassName(cmdbClassName), numOfCmdbIDs));
    }
    else
    {
      sqlString.append(getTableNameByClassName(cmdbClassName)).append(".").append("CMDB_ID");
      sqlString.append(getInSqlString(numOfCmdbIDs));
    }

    if (!(isUpdateClassModelEnabled())) {
      sqlString.append(" AND ").append("CUSTOMER_ID").append("=?");
    }

    return sqlString.toString();
  }

  private StringBuffer createUpdateSqlWithNoCondition(String cmdbClassName, Collection<? extends CmdbAttribute> attributes) {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("UPDATE ").append(getTableNameByClassName(cmdbClassName)).append(" SET ");

    String comma = "";
    for (Iterator i$ = attributes.iterator(); i$.hasNext(); ) { CmdbAttribute attribute = (CmdbAttribute)i$.next();
      CmdbType type = attribute.getResolvedType();
      if ((!(CmdbSimpleTypes.CmdbStringList.equals(type))) && (!(CmdbSimpleTypes.CmdbIntegerList.equals(type)))) {
        sqlString.append(comma).append(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName())).append(" = ?");
        comma = ", ";
      }
    }
    return sqlString;
  }

  protected List<CmdbClass> getCmdbClassAncestors(CmdbClass leafCmdbClass)
  {
    List cmdbClasses = new ArrayList();
    CmdbClass cmdbClass = leafCmdbClass;

    while (!(cmdbClass.getName().equals("none"))) {
      cmdbClasses.add(cmdbClass);
      cmdbClass = cmdbClass.getResolvedSuperClass();
    }

    return cmdbClasses;
  }

  protected List<CmdbClass> getCmdbClassAncestors(String leafCmdbClassName) {
    CmdbClass leafCmdbClass = ClassModelUtil.getCmdbClassByName(leafCmdbClassName);

    return getCmdbClassAncestors(leafCmdbClass);
  }

  protected boolean isTypeOfLink(String cmdbClassName) {
    return (!(ClassModelUtil.getCmdbClassByName(cmdbClassName).isTypeOfObject()));
  }

  protected boolean isTypeOfObject(String cmdbClassName) {
    return ClassModelUtil.getCmdbClassByName(cmdbClassName).isTypeOfObject();
  }

  protected List<String> getClassesNames(List<? extends CmdbClass> cmdbClasses) {
    List classesNames = new ArrayList(cmdbClasses.size());
    for (Iterator i$ = cmdbClasses.iterator(); i$.hasNext(); ) { CmdbClass cmdbClass = (CmdbClass)i$.next();
      classesNames.add(cmdbClass.getName());
    }

    return classesNames;
  }

  protected CmdbSimpleType extractSimpleListElementType(CmdbType simpleListType) {
    if (simpleListType instanceof CmdbIntegerListType)
      return CmdbSimpleTypes.CmdbInteger;

    if (simpleListType instanceof CmdbStringListType) {
      return CmdbSimpleTypes.CmdbString;
    }

    throw new CmdbDalException("Can't extract simple simpleListType of simple list element, for list simpleListType " + simpleListType);
  }

  protected CmdbSimpleType extractSimpleType(CmdbType type)
  {
    CmdbSimpleType simpleType;
    if (type instanceof CmdbEnum) {
      simpleType = CmdbSimpleTypes.CmdbInteger;
    } else if (type instanceof CmdbList) {
      CmdbList typeDefList = (CmdbList)type;
      simpleType = typeDefList.getType();
    } else if (type instanceof CmdbExternalResource) {
      simpleType = CmdbSimpleTypes.CmdbString;
    } else {
      simpleType = (CmdbSimpleType)type;
    }
    return simpleType;
  }

  protected void truncateCmdbIDStringTempTable(CmdbDalConnection connection) throws SQLException {
    truncateTempTable(connection, "CDM_TMP_OBJID_STR");
  }

  protected void truncateCmdbIDTempTable(CmdbDalConnection connection) throws SQLException {
    truncateTempTable(connection, "CDM_TMP_OBJID");
  }

  protected void truncateStringTempTable(CmdbDalConnection connection) throws SQLException {
    truncateTempTable(connection, "CDM_TMP_STR");
  }

  protected void truncateNumberTempTable(CmdbDalConnection connection) throws SQLException {
    truncateTempTable(connection, "CDM_TMP_INT");
  }

  protected void insertValuesToTempTable(CmdbType tempTableType, Object valuesIter, int valuesIndex, CmdbDalConnection connection) throws SQLException {
    if (hasNextElement(valuesIter))
    {
      String sqlString = buildInsertValuesToTempTableSql(tempTableType);

      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      while (hasNextElement(valuesIter)) {
        Object value = getNextElement(valuesIter);

        DalTypeUtil.setObject(preparedStatement, value, tempTableType);
        preparedStatement.setInt(valuesIndex);
        preparedStatement.addBatch();
      }

      preparedStatement.executeBatch();
      preparedStatement.close();
    }
  }

  protected String getTempTableNameByType(CmdbType type) {
    String tempTableNamePrefix = (isMsSql()) ? "#" : "";
    if ((CmdbSimpleTypes.CmdbInteger.equals(type)) || (CmdbSimpleTypes.CmdbLong.equals(type)))
      return tempTableNamePrefix + "CDM_TMP_INT";

    if (CmdbSimpleTypes.CmdbString.equals(type))
      return tempTableNamePrefix + "CDM_TMP_STR";

    throw new CmdbDalException("There is no temp table for cmdb type [" + type + "] !!!");
  }

  private String buildInsertValuesToTempTableSql(CmdbType tempTableType) {
    return "insert into " + getTempTableNameByType(tempTableType) + " values(?,?)";
  }

  protected void truncateTempTable(CmdbDalConnection connection, String tableName) {
    CmdbDalCommand truncateTableCommand = CmdbDalCommandFactory.createTruncateTempTableComplexCommand(tableName);
    truncateTableCommand.execute();
  }

  protected void createCmdbIDTempTable(CmdbDalConnection connection, List<byte[]> ids) throws SQLException {
    truncateCmdbIDTempTable(connection);
    fillCmdbIDTempTable(connection, ids);
  }

  private void fillCmdbIDTempTable(CmdbDalConnection connection, List<byte[]> ids) throws SQLException {
    fillCmdbIDTempTable(connection, ids, 0);
  }

  protected void fillCmdbIDTempTable(CmdbDalConnection connection, List<byte[]> ids, int index) throws SQLException {
    if (ids.size() > 0)
    {
      String sqlString;
      if (isOracle())
        sqlString = "insert into CDM_TMP_OBJID values(?, ?)";
      else if (isMsSql())
        sqlString = "insert into #CDM_TMP_OBJID values(?, ?)";
      else {
        throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
      }

      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      for (Iterator i$ = ids.iterator(); i$.hasNext(); ) { byte[] id = (byte[])i$.next();
        preparedStatement.setBytes(id);
        preparedStatement.setInt(index);
        preparedStatement.addBatchSilently();
      }

      preparedStatement.executeBatch();
      preparedStatement.close();
    }
  }

  protected StringBuffer createJoinWithCmdbIDTempTableConditionSql(String tableName, int numOfIds) {
    return createJoinWithCmdbIDTempTableIndexConditionSql(tableName, "CMDB_ID", "0");
  }

  protected StringBuffer createJoinWithCmdbIDTempTableIndexConditionSql(String tableName, int numOfIds) {
    return createJoinWithCmdbIDTempTableIndexConditionSql(tableName, "CMDB_ID", numOfIds);
  }

  protected StringBuffer createJoinWithCmdbIDTempTableIndexConditionSql(String tableName, String columnName, int numOfIds) {
    return createJoinWithCmdbIDTempTableIndexConditionSql(tableName, columnName, "?");
  }

  private StringBuffer createJoinWithCmdbIDTempTableIndexConditionSql(String tableName, String columnName, String valuesIndex) {
    StringBuffer sql = new StringBuffer();

    if (isOracle()) {
      sql.append("EXISTS (SELECT 1 FROM ").append("CDM_TMP_OBJID").append(" WHERE ");
      sql.append("CDM_TMP_OBJID").append(".").append("CMDB_ID").append(" = ");
      sql.append(tableName).append(".").append(columnName).append(" AND ");
      sql.append("CDM_TMP_OBJID").append(".").append("T_VALUES_INDEX").append("=");
      sql.append(valuesIndex).append(")");
    } else if (isMsSql()) {
      sql.append("EXISTS (SELECT 1 FROM #").append("CDM_TMP_OBJID").append(" WHERE #");
      sql.append("CDM_TMP_OBJID").append(".").append("CMDB_ID").append(" = ");
      sql.append(tableName).append(".").append(columnName).append(" AND #");
      sql.append("CDM_TMP_OBJID").append(".").append("T_VALUES_INDEX").append("=");
      sql.append(valuesIndex).append(")");
    } else {
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
    }

    return sql;
  }

  protected boolean isCmdbIDTempTableMustNotUsingChunksMechanism(int numOfCmdbIDs)
  {
    return (getMaxPossibleSizeForInChunk() < numOfCmdbIDs);
  }

  protected boolean isCmdbIDTempTableMustUsingChunksMechanism(int numOfCmdbIDs)
  {
    return (getMaxPossibleSizeForInChunk() * getMaxNumOfInChunks() < numOfCmdbIDs);
  }

  protected void addValuesToPrepareStatement(CmdbDalPreparedStatement preparedStatement, ModelLinks links, List<String> listOfAttribsPropertiesKeys) throws SQLException {
    if (listOfAttribsPropertiesKeys != null)
      for (Iterator i$ = listOfAttribsPropertiesKeys.iterator(); i$.hasNext(); ) { String key = (String)i$.next();
        preparedStatement.setString(key);
      }


    if (!(isCmdbIDTempTableMustUsingChunksMechanism(links.size()))) {
      List ids = elementsToIDsAsBytes(links);
      addIDsToPrepareStatement(preparedStatement, ids);
    }

    if (!(isUpdateClassModelEnabled()))
      preparedStatement.setInt(getCustomerID().getID());
  }

  protected int calcNumOfInChunks(int fullSize)
  {
    return (int)Math.ceil(fullSize / getMaxPossibleSizeForInChunk());
  }

  protected StringBuffer getInSqlString(int numOfElements) {
    return createInSqlString(numOfElements);
  }

  private StringBuffer createInSqlString(int size) {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append(" IN (? ");
    for (int i = 0; i < size - 1; ++i)
      sqlString.append(",? ");

    sqlString.append(")");

    return sqlString;
  }

  protected void addIDsToPrepareStatement(CmdbDalPreparedStatement preparedStatement, List<byte[]> ids) throws SQLException {
    for (Iterator i$ = ids.iterator(); i$.hasNext(); ) { byte[] id = (byte[])i$.next();
      preparedStatement.setBytes(id);
    }
  }

  protected void createCmdbIDTempTable(CmdbDalConnection connection, ModelObjects objects) throws SQLException {
    List ids = elementsToIDsAsBytes(objects);

    createCmdbIDTempTable(connection, ids);
  }

  protected List<byte[]> elementsToIDsAsBytes(ModelObjects objects) {
    List ids = new ArrayList(objects.size());

    ReadOnlyIterator objectsIter = objects.getObjectsIterator();
    while (objectsIter.hasNext()) {
      ModelObject object = (ModelObject)objectsIter.next();
      ids.add(extractCmdbID2Bytes(object));
    }
    return ids;
  }

  protected <E extends CmdbData<? extends CmdbDataID>> List<byte[]> elementsToIDsAsBytes(CmdbDatas<?, E> elements) {
    List ids = new ArrayList(elements.size());
    for (ReadOnlyIterator it = elements.getDatasIterator(); it.hasNext(); )
      ids.add(extractCmdbID2Bytes((CmdbTopologicalData)it.next()));

    return ids;
  }

  protected List<byte[]> elementsToIDsAsBytes(List<? extends CmdbData<? extends CmdbDataID>> cmdbElements) {
    List ids = new ArrayList(cmdbElements.size());
    for (Iterator i$ = cmdbElements.iterator(); i$.hasNext(); ) { CmdbData cmdbElement = (CmdbData)i$.next();
      ids.add(extractCmdbID2Bytes(cmdbElement));
    }
    return ids;
  }

  protected void createCmdbIDTempTable(CmdbDalConnection connection, CmdbObjectIds objectsIDs) throws SQLException {
    List ids = elementsToIDsAsBytes(objectsIDs);
    createCmdbIDTempTable(connection, ids);
  }

  protected void createCmdbIDTempTable(CmdbDalConnection connection, CmdbUnresolvedDataIDs unresolvedDataIDs) throws SQLException {
    List ids = elementsToIDsAsBytes(unresolvedDataIDs);
    createCmdbIDTempTable(connection, ids);
  }

  protected List<byte[]> elementsToIDsAsBytes(CmdbIDsCollection<? extends CmdbDataID> elementsIDs) {
    List ids = new ArrayList(elementsIDs.size());
    for (Iterator i$ = elementsIDs.iterator(); i$.hasNext(); ) { CmdbDataID cmdbDataID = (CmdbDataID)i$.next();
      ids.add(convertCmdbID2Bytes(cmdbDataID));
    }
    return ids;
  }

  protected List<byte[]> elementsToIDsAsBytes(CmdbUnresolvedDataIDs unresolvedDataIDs) {
    List ids = new ArrayList(unresolvedDataIDs.size());
    for (Iterator i$ = unresolvedDataIDs.iterator(); i$.hasNext(); ) { CmdbUnresolvedDataID unresolvedDataID = (CmdbUnresolvedDataID)i$.next();
      ids.add(convertCmdbID2Bytes((AbstractCMDBDigest)unresolvedDataID));
    }
    return ids;
  }

  protected void createCmdbIDTempTable(CmdbDalConnection connection, CmdbLinkIds linkIDs) throws SQLException {
    List ids = elementsToIDsAsBytes(linkIDs);
    createCmdbIDTempTable(connection, ids);
  }

  private byte[] convertCmdbID2Bytes(AbstractCMDBDigest cmdbDigest)
  {
    return AbstractCMDBDigest.toBytes(cmdbDigest);
  }

  protected byte[] convertCmdbID2Bytes(CmdbDataID dataId)
  {
    return convertCmdbID2Bytes((AbstractCMDBDigest)dataId);
  }

  protected byte[] extractCmdbID2Bytes(ModelObject object) {
    return convertCmdbID2Bytes((AbstractCMDBDigest)object.getID());
  }

  protected byte[] extractCmdbID2Bytes(CmdbTopologicalData<? extends CmdbDataID> link) {
    return convertCmdbID2Bytes(extractCmdbID(link));
  }

  protected byte[] extractCmdbID2Bytes(ModelLink link) {
    return convertCmdbID2Bytes(extractCmdbID(link));
  }

  protected CmdbObjectID extractCmdbID(ModelObject object) {
    return object.toCmdbObjectID();
  }

  protected CmdbLinkID extractCmdbID(ModelLink link) {
    return link.getID();
  }

  protected <T extends CmdbDataID> T extractCmdbID(CmdbTopologicalData<T> data) {
    return ((CmdbDataID)data.getID());
  }

  protected void createCmdbIDTempTable(CmdbDalConnection connection, ModelLinks links) throws SQLException {
    List ids = elementsToIDsAsBytes(links);
    createCmdbIDTempTable(connection, ids);
  }

  protected List<byte[]> elementsToIDsAsBytes(ModelLinks links) {
    List ids = new ArrayList(links.size());

    ReadOnlyIterator linksIter = links.getLinksIterator();

    while (linksIter.hasNext()) {
      ModelLink link = (ModelLink)linksIter.next();

      byte[] linkIDAsBytes = extractCmdbID2Bytes(link);
      ids.add(linkIDAsBytes);
    }
    return ids;
  }

  protected CmdbLinkID restoreLinkID(byte[] idAsBytes) {
    return CmdbLinkID.Factory.restoreLinkID(idAsBytes);
  }

  protected CmdbObjectID restoreObjectID(byte[] idAsBytes) {
    return CmdbObjectID.Factory.restoreObjectID(idAsBytes);
  }

  protected String getClassColumnHolder(String className) {
    if (isTypeOfLink(className)) {
      return "link";
    }

    return "root";
  }

  protected boolean isContainLobAttribute(CmdbAttributes attributes)
  {
    for (ReadOnlyIterator attributesIter = attributes.getIterator(); attributesIter.hasNext(); ) {
      CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();

      if (isClobAttribute(attribute)) {
        return true;
      }

      if (isBlobAttribute(attribute))
        return true;

    }

    return false;
  }

  protected boolean isBlobAttribute(CmdbAttribute attribute) {
    return ((attribute.getResolvedType().equals(CmdbSimpleTypes.CmdbBytes)) && (attribute.getSizeLimit() != null) && (attribute.getSizeLimit().intValue() > 2000));
  }

  protected boolean isClobAttribute(CmdbAttribute attribute)
  {
    return attribute.getResolvedType().equals(CmdbSimpleTypes.CmdbXml);
  }

  protected CmdbObjectIds extractCmdbObjectIds(ModelObjects objects) {
    CmdbObjectIds objectIDs = CmdbObjectIdsFactory.create();

    if (objects != null) {
      ReadOnlyIterator objectsIter = objects.getObjectsIterator();
      while (objectsIter.hasNext()) {
        ModelObject object = (ModelObject)objectsIter.next();
        objectIDs.add(object.toCmdbObjectID());
      }
    }

    return objectIDs;
  }

  protected CmdbLinkIds extractCmdbLinkIds(ModelLinks links) {
    CmdbLinkIds linkIDs = CmdbLinkIdsFactory.create();

    if (links != null) {
      ReadOnlyIterator linksIter = links.getLinksIterator();
      while (linksIter.hasNext()) {
        ModelLink link = (ModelLink)linksIter.next();
        linkIDs.add(link.getID());
      }
    }

    return linkIDs;
  }

  protected boolean isEmptyContainer(CmdbObjectIds objectIDs) {
    return ((objectIDs == null) || (objectIDs.size() <= 0));
  }

  protected boolean isEmptyContainer(CmdbLinkIds linkIDs) {
    return ((linkIDs == null) || (linkIDs.isEmpty()));
  }

  protected boolean isEmptyContainer(ModelObjects objects) {
    return ((objects == null) || (objects.size() <= 0));
  }

  protected boolean isEmptyContainer(ModelLinks links) {
    return ((links == null) || (links.size() <= 0));
  }

  protected <ID extends CmdbDataID, DATA extends CmdbData> void mergeCmdbElements(CmdbDatas<? super ID, ? super DATA> srcObjects, CmdbDatas<? extends ID, ? extends DATA> dstObjects)
  {
    ReadOnlyIterator objectsIter = dstObjects.getDatasIterator();

    while (objectsIter.hasNext())
      srcObjects.add((CmdbData)objectsIter.next());
  }

  protected Date getCurrentTime()
  {
    return new Date(CmdbTime.currentTimeMillis());
  }

  protected <E extends CmdbData> Map<String, List<E>> sortElementsToTypes(CmdbDatas<?, E> objects)
  {
    Map elementsFromSameTypeMap = new HashMap();
    sortElementsToTypes(objects, elementsFromSameTypeMap);
    return elementsFromSameTypeMap;
  }

  private <T extends CmdbData> void sortElementsToTypes(CmdbDatas<?, T> datas, Map<String, List<T>> sortedElements) {
    for (ReadOnlyIterator it = datas.getDatasIterator(); it.hasNext(); ) {
      CmdbData cmdbData = (CmdbData)it.next();
      String mainType = cmdbData.getType();
      CmdbClass leafCmdbClass = ClassModelUtil.getCmdbClassByName(mainType);
      List cmdbClasses = getCmdbClassAncestors(leafCmdbClass);
      List classesNames = getClassesNames(cmdbClasses);
      for (Iterator i$ = classesNames.iterator(); i$.hasNext(); ) { String type = (String)i$.next();
        List elementsWithSameTypeContainer = (List)sortedElements.get(type);
        if (elementsWithSameTypeContainer == null) {
          elementsWithSameTypeContainer = new ArrayList();
          sortedElements.put(type, elementsWithSameTypeContainer);
        }
        elementsWithSameTypeContainer.add(cmdbData);
      }
    }
  }

  protected CmdbDalPreparedStatement createPreparedStatement(CmdbDalConnection connection, String sqlString)
    throws SQLException
  {
    CmdbDalPreparedStatement preparedStatement;
    if (isUseStatement())
      preparedStatement = connection.statement4Select(sqlString);
    else {
      preparedStatement = connection.prepareStatement4Select(sqlString);
    }

    return preparedStatement;
  }

  protected CmdbDalPreparedStatement createAndFillPreparedStatement(CmdbDalConnection connection, String sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes)
    throws SQLException
  {
    CmdbDalPreparedStatement preparedStatement;
    if (isUseStatement())
      preparedStatement = connection.statement4Select(sqlString);
    else {
      preparedStatement = connection.prepareStatement4Select(sqlString);
    }

    for (int i = 0; i < bindVariables.size(); ++i)
      DalTypeUtil.setObject(preparedStatement, bindVariables.get(i), (CmdbType)bindVariablesTypes.get(i));

    return preparedStatement;
  }

  protected Map<String, List<CmdbObject>> sortElementsToTypesOld(CmdbObjects objects)
  {
    Map elementsFromSameTypeMap = new HashMap();

    for (ReadOnlyIterator objectsIter = objects.getObjectsIterator(); objectsIter.hasNext(); ) {
      CmdbObject cmdbData = (CmdbObject)objectsIter.next();
      addElementToTypeSortedElementsMap(elementsFromSameTypeMap, cmdbData, cmdbData.getType());
    }

    return elementsFromSameTypeMap;
  }

  protected Map<String, List<CmdbLink>> sortElementsToTypesOld(CmdbLinks links) {
    Map elementsFromSameTypeMap = new HashMap();

    for (ReadOnlyIterator linksIter = links.getLinksIterator(); linksIter.hasNext(); ) {
      CmdbLink cmdbData = (CmdbLink)linksIter.next();
      addElementToTypeSortedElementsMap(elementsFromSameTypeMap, cmdbData, cmdbData.getType());
    }

    return elementsFromSameTypeMap;
  }

  private <T extends CmdbData> void addElementToTypeSortedElementsMap(Map<String, List<T>> elementsFromSameTypeMap, T object, String type) {
    List elementsWithSameTypeContainer = (List)elementsFromSameTypeMap.get(type);
    if (elementsWithSameTypeContainer == null) {
      elementsWithSameTypeContainer = new ArrayList();
      elementsFromSameTypeMap.put(type, elementsWithSameTypeContainer);
    }
    elementsWithSameTypeContainer.add(object);
  }
}