package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbClassQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbModifiableClassQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.impl.CmdbClassQualifierFactory;
import java.sql.SQLException;

public class CmdbDalAddClassQualifiersComplexCommand extends CmdbDalAddClassModelQualifiersComplexCommand
{
  private CmdbClass _cmdbClass = null;

  public CmdbDalAddClassQualifiersComplexCommand(CmdbClass cmdbClass, BasicContainer qualifires, Long entityId)
  {
    super(qualifires, entityId);
    setCmdbClass(cmdbClass);
  }

  public CmdbDalAddClassQualifiersComplexCommand(CmdbClass cmdbClass, CmdbClassQualifier qualifier, Long entityId) {
    super(null, entityId);
    CmdbModifiableClassQualifiers qualifiers = CmdbClassQualifierFactory.createQualifiers();
    qualifiers.add(qualifier);
    setQualifires(qualifiers);
    setCmdbClass(cmdbClass);
  }

  protected String getCommandName() {
    return "Add class qualifiers [" + getQualifires() + "] to cmdb class [" + getCmdbClass().getName() + "]";
  }

  protected Long getEntityIdFromDB() throws SQLException {
    return getClassID(getCmdbClass().getName(), getConnection());
  }

  private CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass;
  }
}