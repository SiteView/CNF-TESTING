package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import java.sql.SQLException;

public class CmdbDalUpdateAttributeTypeComplexCommand extends CmdbDalUpdateAttributePropertyComplexCommand
{
  public CmdbDalUpdateAttributeTypeComplexCommand(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass)
  {
    super(attributeOverride, cmdbClass);
  }

  protected Void perform() throws Exception {
    updateColumnTypeToLong();
    super.perform();

    return null;
  }

  protected void validateInput() {
    super.validateInput();
    String attributeName = getAttribute().getName();
    CmdbType newType = ((CmdbAttribute)getAttribute()).getResolvedType();
    CmdbType prevType = getCmdbClass().getAttributeByName(attributeName).getResolvedType();
    if ((!(prevType.equals(CmdbSimpleTypes.CmdbInteger))) || (!(newType.equals(CmdbSimpleTypes.CmdbLong))))
      throw new UnsupportedOperationException("Can't change attribute type from " + prevType.getDisplayName() + " type to " + newType.getDisplayName());
  }

  private void updateColumnTypeToLong()
  {
    String columnType;
    String tableName = getTableNameByClassName(getCmdbClass().getName());
    String columnName = DalClassModelUtil.getColumnNameByAttributeName(getAttribute().getName());

    StringBuffer sqlString = new StringBuffer();
    sqlString.append("ALTER TABLE ").append(tableName);

    if (isOracle()) {
      sqlString.append(" MODIFY ");
      columnType = "number";
    }
    else if (isMsSql()) {
      sqlString.append(" ALTER COLUMN ");
      columnType = "numeric";
    }
    else {
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
    }

    sqlString.append(columnName).append(" ");
    sqlString.append(columnType).append(" (").append(22).append(")");

    getConnection().executeAdhocSql(sqlString.toString());
    getConnection().commit();
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long attributeId) throws SQLException
  {
    preparedStatement.setString(((CmdbAttribute)getAttribute()).getType());
    preparedStatement.setBoolean(getAttribute().isModifiedByUser());
    preparedStatement.setLong(attributeId);
  }

  protected String getColumnNameToUpdate() {
    return "ATTRIBUTE_TYPE";
  }
}