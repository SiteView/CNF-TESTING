package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.am.platform.controller.Server;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class CmdbDalVerifyModelUpdateMasterCommand extends CmdbDalAbstractCommand<Void>
{
  protected Void perform()
    throws Exception
  {
    String selectSql = "SELECT MASTER FROM TOPOLOGY_CHANGES_MGMT";

    if (isMsSql())
      selectSql = selectSql + " WITH (UPDLOCK)";

    selectSql = selectSql + " WHERE CUSTOMER_ID=?";
    if (isOracle())
      selectSql = selectSql + " FOR UPDATE";

    JDBCTemplate jdbcTemplate = JDBCTemplate.getInstance(getConnection());
    String currentMaster = jdbcTemplate.queryForString(selectSql, new Object[] { Integer.valueOf(getCustomerID().getID()) });
    String myServerName = Server.getLocal().getName();
    if (!(currentMaster.equals(myServerName)))
      throw new CmdbDalException("Mastership is taken from " + myServerName + " by " + currentMaster + ", rolling back the transaction of " + myServerName);

    return null;
  }

  protected void validateInput()
  {
  }
}