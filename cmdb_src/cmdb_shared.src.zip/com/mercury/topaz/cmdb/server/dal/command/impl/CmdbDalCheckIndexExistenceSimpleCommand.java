package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;

public class CmdbDalCheckIndexExistenceSimpleCommand extends CmdbDalAbstractCommand<Boolean>
{
  private String _tableName = null;
  private String _indexName = null;

  public CmdbDalCheckIndexExistenceSimpleCommand(String tableName, String indexName)
  {
    setTableName(tableName);
    setIndexName(indexName);
  }

  protected void validateInput() {
    if ((getTableName() == null) || (getTableName().length() == 0) || (getIndexName() == null) || (getIndexName().length() == 0))
    {
      throw new CmdbDalException("Can't check existence of index [" + getIndexName() + "], in table [" + getTableName() + "]");
    }
  }

  protected Boolean perform() throws Exception {
    return Boolean.valueOf(checkIndexExistence());
  }

  private boolean checkIndexExistence()
    throws SQLException
  {
    String sqlString;
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;

    if (isOracle()) {
      sqlString = "SELECT 1 FROM USER_INDEXES WHERE TABLE_NAME=? AND INDEX_NAME=?";
    }
    else if (isMsSql()) {
      sqlString = "SELECT 1 FROM sysindexes WHERE object_id(?)=id AND name=?";
    }
    else
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");

    try
    {
      preparedStatement = getConnection().prepareStatement4Select(sqlString);
      preparedStatement.setString(getTableName());
      preparedStatement.setString(getIndexName());
      resultSet = preparedStatement.executeQuery();

      boolean res = resultSet.next();

      resultSet.close();
      preparedStatement.close();

      boolean bool1 = res;

      return bool1;
    }
    finally
    {
      if (resultSet != null) resultSet.close();
      if (preparedStatement != null) preparedStatement.close();
    }
  }

  private String getTableName() {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    this._tableName = tableName;
  }

  private String getIndexName() {
    return this._indexName;
  }

  private void setIndexName(String indexName) {
    this._indexName = indexName;
  }
}