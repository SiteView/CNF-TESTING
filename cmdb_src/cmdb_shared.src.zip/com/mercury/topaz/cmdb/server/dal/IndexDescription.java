package com.mercury.topaz.cmdb.server.dal;

import java.util.ArrayList;
import java.util.List;

public class IndexDescription
{
  private List<String> columnNames = new ArrayList();
  private boolean isUnique;
  private boolean isClustered;

  public IndexDescription(String columnName)
  {
    this.columnNames.add(columnName);
  }

  public IndexDescription addColumn(String columnName) {
    this.columnNames.add(columnName);
    return this;
  }

  public IndexDescription clustered() {
    this.isClustered = true;
    return this;
  }

  public IndexDescription unique() {
    this.isUnique = true;
    return this;
  }

  public List<String> getColumnNames() {
    return this.columnNames;
  }

  public boolean isUnique() {
    return this.isUnique;
  }

  public boolean isClustered() {
    return this.isClustered;
  }
}