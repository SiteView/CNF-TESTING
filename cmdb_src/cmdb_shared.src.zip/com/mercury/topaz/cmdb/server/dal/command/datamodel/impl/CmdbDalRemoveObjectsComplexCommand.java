package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.dal.exception.CmdbDalValidationException;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CmdbDalRemoveObjectsComplexCommand extends CmdbDalDataModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalRemoveObjectsComplexCommand.class);
  private CmdbObjects _cmdbObjects = null;

  public CmdbDalRemoveObjectsComplexCommand(CmdbObjects objects)
  {
    setCmdbObjects(objects);
  }

  protected void validateInput() {
    if ((getCmdbObjects() == null) || (getCmdbObjects().isEmpty()))
      throw new CmdbDalValidationException("Can't remove objects - null or empty objects");
  }

  protected void postProcess() throws Exception
  {
    truncateCmdbIDTempTable(getConnection());
  }

  protected Object perform() {
    removeObjects(getCmdbObjects());

    return null;
  }

  private CmdbObjects getCmdbObjects() {
    return this._cmdbObjects;
  }

  private void setCmdbObjects(CmdbObjects cmdbObjects) {
    this._cmdbObjects = cmdbObjects;
  }

  private void removeObjects(CmdbObjects objects) {
    if (_logger.isDebugEnabled())
      _logger.debug("Remove [" + objects.size() + "] objects");

    try
    {
      Map elementsFromSameTypeMap = sortElementsToTypesOld(objects);

      for (Iterator i$ = elementsFromSameTypeMap.keySet().iterator(); i$.hasNext(); ) { String type = (String)i$.next();
        List objectsFromSameTypeList = (List)elementsFromSameTypeMap.get(type);

        removeObjects(objectsFromSameTypeList, type, getConnection());
      }
    }
    catch (Exception e) {
      String errMsg = "Error removing cmdb objects [" + objects + "], due to exception: " + e;
      _logger.error(errMsg);
      throw new CmdbDalException("Error removing cmdb objects. Check log for details !!!", e);
    }
  }

  private void removeObjects(List<CmdbObject> objects, String type, CmdbDalConnection connection) {
    try {
      if (_logger.isDebugEnabled()) {
        _logger.debug("Remove objects from type: " + type);
      }

      CmdbClass leafCmdbClass = ClassModelUtil.getCmdbClassByName(type);
      List cmdbClasses = getCmdbClassAncestors(leafCmdbClass);
      List classesNames = getClassesNames(cmdbClasses);

      classesNames.add("LIST_ATTR_PRIMITIVE");

      List ids = elementsToIDsAsBytes(objects);

      if (isCmdbIDTempTableMustNotUsingChunksMechanism(ids.size())) {
        createCmdbIDTempTable(connection, ids);
      }

      for (Iterator i$ = classesNames.iterator(); i$.hasNext(); ) { String className = (String)i$.next();

        String sqlString = createDeleteSql(className, ids.size());
        CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

        if (!(isCmdbIDTempTableMustNotUsingChunksMechanism(ids.size())))
          addIDsToPrepareStatement(preparedStatement, ids);

        if (!(isUpdateClassModelEnabled())) {
          preparedStatement.setInt(getCustomerID().getID());
        }

        preparedStatement.executeUpdate();
        preparedStatement.close();
      }
    }
    catch (Exception e) {
      String errMsg = "Error removing cmdb objects from type [" + type + "], due to exception: " + e;
      throw new CmdbDalException(errMsg, e);
    }
  }
}