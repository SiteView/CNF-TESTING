package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import java.sql.SQLException;

public abstract class CmdbDalUpdateMethodQualifierPropertyComplexCommand extends CmdbDalUpdateQualifierPropertyComplexCommand
{
  CmdbMethod _method;

  public CmdbDalUpdateMethodQualifierPropertyComplexCommand(ClassModelQualifier qualifier, CmdbClass cmdbClass, CmdbMethod cmdbMethod)
  {
    super(qualifier, cmdbClass);
    setMethod(cmdbMethod);
  }

  protected Long getRowId() throws SQLException {
    Long methodId = getMethodID(getMethod().getName(), getCmdbClass().getName(), getConnection());
    return methodId;
  }

  protected CmdbMethod getMethod() {
    return this._method;
  }

  private void setMethod(CmdbMethod method) {
    this._method = method;
  }
}