package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributeOverrides;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.impl.CmdbAttributeFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;

public class CmdbDalRemoveAttributesOverridesComplexCommand extends CmdbDalClassModelComplexCommand<Void>
{
  private BasicContainer _attributes = null;
  private CmdbClass _cmdbClass = null;
  private Long _classId = null;

  protected CmdbDalRemoveAttributesOverridesComplexCommand(BasicContainer attributes, CmdbClass cmdbClass, Long classId)
  {
    setAttributes(attributes);
    setCmdbClass(cmdbClass);
    setClassId(classId);
  }

  protected CmdbDalRemoveAttributesOverridesComplexCommand(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass, Long classId)
  {
    CmdbModifiableAttributeOverrides attributes = CmdbAttributeFactory.createAttributeOverrides();
    attributes.add(attributeOverride);
    setAttributes(attributes);
    setCmdbClass(cmdbClass);
    setClassId(classId);
  }

  protected void validateInput() {
    if (getCmdbClass() == null)
      throw new CmdbDalException("Can't remove attributes of null cmdb class !!!");
  }

  protected Void perform() throws Exception
  {
    removeAttributes();
    return null;
  }

  protected String getCommandName() {
    return "Remove attributes [" + getAttributes() + "] of cmdb class [" + getCmdbClass().getName() + "]";
  }

  private void removeAttributes() throws SQLException {
    CmdbDalConnection connection = getConnection();
    Long classID = getClassId();
    CmdbClass cmdbClass = getCmdbClass();

    BasicContainer attributes = getAttributes();
    if ((attributes != null) && (!(attributes.isEmpty()))) {
      StringBuffer condition = new StringBuffer();
      condition.append("CLASS_ID").append("=? AND ");
      condition.append("ATTRIBUTE_ID").append("=?");

      String sqlString = createDeleteSql("CCM_ATTRIBUTE", condition.toString());
      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      ReadOnlyIterator attributesIter = attributes.getIterator();
      while (attributesIter.hasNext()) {
        CmdbAttributeOverride attributeOverride = (CmdbAttributeOverride)attributesIter.next();

        Long attributeId = getAttributeID(attributeOverride.getName(), cmdbClass.getName(), connection);
        removeQualifiers(attributeOverride, cmdbClass, attributeId);

        preparedStatement.setLong(classID);
        preparedStatement.setLong(attributeId);
        preparedStatement.addBatch();
      }
      preparedStatement.executeBatch();
      preparedStatement.close();
    }
  }

  private void removeQualifiers(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass, Long attributeId) {
    CmdbDalCommand removeAttributeQualifiersCommand = CmdbDalClassModelCommandFactory.createRemoveAttributeQualifiersComplexCommand(attributeOverride, cmdbClass, attributeOverride.getQualifiers(), attributeId);
    removeAttributeQualifiersCommand.execute();
  }

  protected BasicContainer getAttributes()
  {
    return this._attributes;
  }

  protected void setAttributes(BasicContainer attributes) {
    this._attributes = attributes;
  }

  protected CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass;
  }

  protected Long getClassId() throws SQLException {
    Long classId = this._classId;

    if (classId == null) {
      classId = getClassID(getCmdbClass().getName(), getConnection());
      setClassId(classId);
    }

    return classId;
  }

  private void setClassId(Long classId) {
    this._classId = classId;
  }
}