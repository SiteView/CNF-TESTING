package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import java.sql.SQLException;

public abstract class AbstractChangeDetailCommand extends CmdbDalAbstractCommand<Void>
{
  protected CmdbDalPreparedStatement createChangeDetailStatement()
  {
    int tableGeneration = CmdbDalChangesManagement.getOrCreateNewChange().getTableGeneration();
    CmdbDalConnection connection = getConnection();
    JDBCTemplate jdbcTemplate = JDBCTemplate.getInstance(connection);
    String sql = "INSERT INTO TOPOLOGY_CHANGES_" + tableGeneration + "(" + "ID" + "," + "CUSTOMER_ID" + "," + "CHANGE_ID" + "," + "CMDB_ID" + "," + "CLASS" + "," + "END1_ID" + "," + "END2_ID" + "," + "IS_ADD" + "," + "IS_OBJECT" + ") VALUES(";

    sql = sql + jdbcTemplate.GUID() + ",?,?,?,?,?,?,?,?)";
    return connection.prepareStatement4Update(sql);
  }

  protected void setBindVariables(CmdbDalPreparedStatement preparedStatement, ChangeDetail changeDetail) throws SQLException {
    long changeIndex = CmdbDalChangesManagement.getOrCreateNewChange().getChangeNumber();
    preparedStatement.setInt(getCustomerID().getID());
    preparedStatement.setLong(changeIndex);
    preparedStatement.setBytes(AbstractCMDBDigest.toBytes((AbstractCMDBDigest)changeDetail.getElementID()));
    preparedStatement.setString(changeDetail.getElementType());
    CmdbDataID end1Id = changeDetail.getEnd1Id();
    preparedStatement.setBytes((end1Id != null) ? AbstractCMDBDigest.toBytes((AbstractCMDBDigest)end1Id) : null);
    CmdbDataID end2Id = changeDetail.getEnd2Id();
    preparedStatement.setBytes((end2Id != null) ? AbstractCMDBDigest.toBytes((AbstractCMDBDigest)end2Id) : null);
    preparedStatement.setInt((changeDetail.isAdd()) ? 1 : 0);
    preparedStatement.setInt((changeDetail.isObject()) ? 1 : 0);
  }

  protected void validateInput()
  {
  }
}