package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.ResultSetExtractor;
import com.mercury.topaz.cmdb.server.model.changes.ModelChangeDetails;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CmdbDalGetChanges extends CmdbDalAbstractCommand<List<ModelChangeDetails>>
{
  private final long fromRevision;

  public CmdbDalGetChanges(long fromRevision)
  {
    this.fromRevision = fromRevision;
  }

  protected void validateInput() {
  }

  protected List<ModelChangeDetails> perform() throws Exception {
    String getChangesSql = "SELECT CHANGE_ID,IS_ADD,IS_OBJECT,CMDB_ID,CLASS,END1_ID,END2_ID FROM TOPOLOGY_CHANGES WHERE CHANGE_ID > ? AND CUSTOMER_ID = ?";

    getChangesSql = getChangesSql + " ORDER BY CHANGE_ID";
    JDBCTemplate jdbcTemplate = JDBCTemplate.getInstance(getConnection());
    ResultSetExtractor changesReader = new ResultSetExtractor(this) {
      public List<ModelChangeDetails> extractData() throws SQLException {
        int lastChangeId = -1;
        List detailsList = new ArrayList();
        ModelChangeDetails currentDetails = null;
        while (rs.next()) {
          int changeId = rs.getInt("CHANGE_ID").intValue();
          if (changeId != lastChangeId) {
            currentDetails = new ModelChangeDetails(changeId);
            detailsList.add(currentDetails);
          }
          lastChangeId = changeId;
          boolean isAdd = rs.getInt("IS_ADD").intValue() > 0;
          boolean isObject = rs.getInt("IS_OBJECT").intValue() > 0;
          byte[] idAsBytes = rs.getBytes("CMDB_ID");
          String type = rs.getString("CLASS");
          if (isObject) {
            CmdbObjectID objectID = CmdbObjectID.Factory.restoreObjectID(idAsBytes, false);
            CmdbObject object = CmdbObjectFactory.createObject(objectID, type);
            if (isAdd)
            {
              currentDetails.addedObject(object);
            }
            else
              currentDetails.removedObject(object);
          }
          else {
            byte[] end1IdAsBytes = rs.getBytes("END1_ID");
            byte[] end2IdAsBytes = rs.getBytes("END2_ID");
            CmdbLinkID linkID = CmdbLinkID.Factory.restoreLinkID(idAsBytes);
            CmdbObjectID end1ID = CmdbObjectID.Factory.restoreObjectID(end1IdAsBytes, true);
            CmdbObjectID end2ID = CmdbObjectID.Factory.restoreObjectID(end2IdAsBytes, true);
            CmdbLink link = CmdbLinkFactory.createLink(linkID, end1ID, end2ID, type);
            if (isAdd)
            {
              currentDetails.addedLink(link);
            }
            else
              currentDetails.removedLink(link);
          }
        }

        return detailsList;
      }

    };
    return ((List)jdbcTemplate.executeQuery(getChangesSql, changesReader, new Object[] { Long.valueOf(this.fromRevision), Integer.valueOf(getCustomerID().getID()) }));
  }
}