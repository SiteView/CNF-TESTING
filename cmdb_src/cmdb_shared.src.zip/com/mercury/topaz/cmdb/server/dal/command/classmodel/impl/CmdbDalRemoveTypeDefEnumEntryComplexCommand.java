package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnumEntry;
import java.sql.SQLException;

public class CmdbDalRemoveTypeDefEnumEntryComplexCommand extends CmdbDalAbstractTypeDefComplexCommand
{
  private CmdbEnum _cmdbEnum = null;
  private CmdbEnumEntry _enumEntry = null;
  private Long _cmdbEnumId = null;

  public CmdbDalRemoveTypeDefEnumEntryComplexCommand(CmdbEnumEntry enumEntry, CmdbEnum cmdbEnum, Long cmdbEnumId)
  {
    setCmdbEnum(cmdbEnum);
    setEnumEntry(enumEntry);
    setCmdbEnumId(cmdbEnumId);
  }

  protected void validateInput() {
    if ((getCmdbEnum() == null) || (getEnumEntry() == null))
      throw new CmdbDalException("Can't remove cmdbenum entry. Null cmdbenum or null cmdbenum entry !!!");
  }

  protected Object perform() throws Exception
  {
    removeEnumEntry();
    return null;
  }

  private void removeEnumEntry() throws SQLException {
    CmdbDalConnection connection = getConnection();

    StringBuffer condition = new StringBuffer();
    condition.append("TYPE_DEF_ID").append("=? AND ").append("ENUM_KEY").append("=?");

    String sqlString = createDeleteSql("CCM_TDEFDITEM", condition.toString());
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);
    preparedStatement.setLong(getCmdbEnumId());
    preparedStatement.setInt(getEnumEntry().getEnumKey());
    preparedStatement.executeUpdate();
    preparedStatement.close();

    sqlString = createDeleteSql("CCM_TDEF_ENUM", condition.toString());
    preparedStatement = connection.prepareStatement4Update(sqlString);
    preparedStatement.setLong(getCmdbEnumId());
    preparedStatement.setInt(getEnumEntry().getEnumKey());
    preparedStatement.executeUpdate();
    preparedStatement.close();
  }

  private CmdbEnumEntry getEnumEntry() {
    return this._enumEntry;
  }

  private void setEnumEntry(CmdbEnumEntry enumEntry) {
    this._enumEntry = enumEntry;
  }

  private CmdbEnum getCmdbEnum() {
    return this._cmdbEnum;
  }

  private void setCmdbEnum(CmdbEnum cmdbEnum) {
    this._cmdbEnum = cmdbEnum;
  }

  private Long getCmdbEnumId() throws SQLException {
    Long typeDefId = this._cmdbEnumId;
    if (typeDefId == null) {
      typeDefId = getTypeDefID(getConnection(), getCmdbEnum());
      setCmdbEnumId(typeDefId);
    }
    return this._cmdbEnumId;
  }

  private void setCmdbEnumId(Long cmdbEnumId) {
    this._cmdbEnumId = cmdbEnumId;
  }
}