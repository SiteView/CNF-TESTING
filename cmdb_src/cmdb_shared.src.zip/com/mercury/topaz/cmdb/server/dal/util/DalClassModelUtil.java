package com.mercury.topaz.cmdb.server.dal.util;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.common.qualifiedname.CmdbQualifiedNameFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class DalClassModelUtil
{
  public static int _maxNameLengthAllow = 0;
  public static final String COLUMN_PREFIX = "A_";
  public static final String MAX_NAME_LENGTH_ALLOW_KEY = "dal.datamodel.max.name.length.allow";
  private static final String DATA_MODEL_TABLE_NAME_PREFIX = "CDM_";
  private static final String DATA_MODEL_TABLE_NAME_DELIMITER = "_";

  public static String getColumnNameByAttributeName(String attributeName)
  {
    return fixLongName("A_" + attributeName);
  }

  public static String fixLongName(String longName) {
    String newName = longName;
    if (longName.length() > getMaxNameLengthAllow())
      newName = cutLongName(longName);

    return newName.toUpperCase();
  }

  public static String cutLongName(String longName)
  {
    String newName = longName.substring(0, getMaxNameLengthAllow() - 12) + "_" + String.valueOf(Math.abs(longName.hashCode()));
    return newName;
  }

  public static int getMaxNameLengthAllow() {
    int maxNameLengthAllow = _maxNameLengthAllow;
    if (maxNameLengthAllow == 0) {
      SettingsReader settingsReader = ServerApiFacade.getLocalEnvironment().getSettingsReader();
      maxNameLengthAllow = settingsReader.getInt("dal.datamodel.max.name.length.allow", 30);
      --maxNameLengthAllow;
      setMaxNameLengthAllow(maxNameLengthAllow);
    }
    return maxNameLengthAllow;
  }

  public static synchronized void setMaxNameLengthAllow(int maxNameLengthAllow) {
    _maxNameLengthAllow = maxNameLengthAllow;
  }

  public static ColumnDescription createColumnDescFromAttribute(CmdbAttribute attribute) {
    ColumnDescription columnDescription = new ColumnDescription(getColumnNameByAttributeName(attribute.getName())).ofCmdbType(attribute.getResolvedType());

    if (attribute.getSizeLimit() != null)
      columnDescription.ofSize(attribute.getSizeLimit().intValue());

    if (isNotNullAttribute(attribute))
      columnDescription.notNullable();

    return columnDescription;
  }

  public static boolean isNotNullAttribute(CmdbAttribute attribute)
  {
    return false;
  }

  private static boolean isModelConsolidated(LocalEnvironment env)
  {
    return (!(env.getSystemParameter("dal.update.class.model.enabled", true)));
  }

  public static boolean isModelConsolidated() {
    return isModelConsolidated(ServerApiFacade.getLocalEnvironment());
  }

  public static String getTableNameByClassName(String classFullQualifiedName) {
    if (isModelConsolidated()) {
      return mapClassName2TableName(classFullQualifiedName, 0);
    }

    int customerID = ServerApiFacade.getLocalEnvironment().getCustomerID().getID();
    return mapClassName2TableName(classFullQualifiedName, customerID);
  }

  private static String mapClassName2TableName(String classFullQualifiedName, int customerID) {
    String[] parsedClassName = CmdbQualifiedNameFactory.parseQualifiedName(classFullQualifiedName);
    String nameSpace = parsedClassName[0] + "_";
    String className = parsedClassName[1];

    String tableName = "CDM_" + nameSpace + className + "_" + customerID;

    tableName = fixLongName(tableName);

    return tableName;
  }
}