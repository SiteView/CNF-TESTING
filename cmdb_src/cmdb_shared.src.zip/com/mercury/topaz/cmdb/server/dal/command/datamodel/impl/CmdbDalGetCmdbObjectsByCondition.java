package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.model.graph.object.EmptyModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

public class CmdbDalGetCmdbObjectsByCondition extends CmdbDalObjectsConditionComplexCommand
{
  private int chunkSize;

  public CmdbDalGetCmdbObjectsByCondition(ElementCondition condition)
  {
    super(condition, EmptyModelObjects.getInstance());
    this.chunkSize = -1;
  }

  public CmdbDalGetCmdbObjectsByCondition(ElementCondition condition, int maxCount)
  {
    super(condition, EmptyModelObjects.getInstance());
    this.chunkSize = maxCount;
  }

  protected Object perform() throws Exception {
    if ((getCondition() == null) || (getCondition().getClassCondition() == null))
      return CmdbObjectFactory.createObjects();

    return performQueryCondition();
  }

  public Object getResult(CmdbDalResultSet resultSet) throws SQLException {
    if (this.chunkSize > 0) {
      return buildCmdbObjects(resultSet);
    }

    resultSet.next();
    int count = resultSet.getInt("ci_count").intValue();
    resultSet.close();
    return new Integer(count);
  }

  private CmdbObjectIds buildCmdbObjects(CmdbDalResultSet resultSet)
    throws SQLException
  {
    CmdbObjectIds data = CmdbObjectIdsFactory.create();
    while (resultSet.next())
    {
      byte[] objectIdAsBytes = resultSet.getBytes(1);
      CmdbObjectID objectID = restoreObjectID(objectIdAsBytes);
      data.add(objectID);
    }
    return data;
  }

  protected void addSelectSql(StringBuffer conditionSql, Set<String> participatedClasses, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) {
    StringBuffer selectSql = new StringBuffer();
    String conditionClassName = getCondition().getClassCondition().getClassName();
    if (this.chunkSize < 0) {
      selectSql.append("SELECT COUNT(").append(getDummyClassName(conditionClassName, getClassNameSuffix())).append(".").append("CMDB_ID").append(") AS ci_count ");
    }
    else
    {
      if (isMsSql()) {
        selectSql.append("SELECT TOP ").append(Integer.toString(this.chunkSize)).append(" ");
      }
      else
        selectSql.append("SELECT ");

      selectSql.append(getDummyClassName(conditionClassName, getClassNameSuffix())).append(".");
      selectSql.append("CMDB_ID");
    }

    participatedClasses.add(getDummyClassName("root", getClassNameSuffix()));
    participatedClasses.add(getDummyClassName(conditionClassName, getClassNameSuffix()));
    addFromSql(selectSql, participatedClasses);

    selectSql.append(" WHERE ");
    if (this.chunkSize > 0) {
      if (isOracle()) {
        selectSql.append(" ROWNUM <= ").append(Integer.toString(this.chunkSize)).append(" ");
      }
      else
        selectSql.append("1=1");

    }
    else
      selectSql.append("1=1");

    addPairsJoinSql(selectSql, participatedClasses, bindVariables, bindVariablesTypes);

    conditionSql.insert(0, selectSql);
  }
}