package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.CmdbModifiableLink;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;

public class CmdbDalAddLinksComplexCommand extends CmdbDalAddElementsComplexCommand<CmdbLink>
{
  public CmdbDalAddLinksComplexCommand(CmdbLinks links)
  {
    super(links);
  }

  protected void handleLink(CmdbClass cmdbClass, CmdbLink element, CmdbDalPreparedStatement preparedStatement) throws SQLException {
    if (cmdbClass.getName().equalsIgnoreCase("link")) {
      byte[] end1IdAsBytes = AbstractCMDBDigest.toBytes((AbstractCMDBDigest)element.getEnd1());
      preparedStatement.setBytes(end1IdAsBytes);

      byte[] end2IdAsBytes = AbstractCMDBDigest.toBytes((AbstractCMDBDigest)element.getEnd2());
      preparedStatement.setBytes(end2IdAsBytes);

      preparedStatement.setString(element.getType());
    }
  }

  protected CmdbLink addPropertiesToData(CmdbLink data, CmdbProperties props) {
    CmdbModifiableLink modLink = CmdbLinkFactory.createModifiableLink(data);
    for (ReadOnlyIterator i = props.getPropertiesIterator(); i.hasNext(); )
      modLink.addOrUpdateProperty((CmdbProperty)i.next());

    return modLink;
  }
}