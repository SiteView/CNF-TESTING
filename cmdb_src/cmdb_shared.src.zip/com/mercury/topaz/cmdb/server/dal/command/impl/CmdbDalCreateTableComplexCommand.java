package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.ForeignKeyDescription;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.table.TableUtils;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CmdbDalCreateTableComplexCommand extends AbstractTableManagementCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalCreateTableComplexCommand.class);
  private static Object _lock = new Object();
  public static final int MAX_ROW_SIZE = 8060;
  public static final int FILL_FACTOR_VALUE = 80;
  public static final String PARTITION_NAME_PREFIX = "CUST_";

  public CmdbDalCreateTableComplexCommand(TableDescription tableDescription)
  {
    super(tableDescription);
  }

  protected Void perform() {
    createWholeTable();
    return null;
  }

  protected void createWholeTable()
  {
    synchronized (getLock()) {
      if (!(checkTableExistence(getTableName()))) {
        if (_logger.isDebugEnabled()) {
          _logger.debug("Create table [" + getTableName() + "], with columns [" + getTableDescription().getColumns().keySet() + "]");
        }

        createBasicTable();
        addIndicesAndConstraints();

        commitChanges();
      }
      else {
        validateTableMetaDataWithDBTableMetaData();
      }

    }

    if ((!(isUpdateClassModelEnabled())) && (!(isPartitionExists())))
      createNewPartition();
  }

  private void createNewPartition()
  {
    if ((isOracle()) && 
      (!(isPartitioningDisabled())))
      createBasicPartition();
  }

  private boolean isPartitionExists()
  {
    CmdbDalCommand checkPartitionExistence = CmdbDalCommandFactory.createCheckPartitionExistenceSimpleCommand(getPartitionName(), getTableName());
    CmdbDalCommandResult result = checkPartitionExistence.execute();
    return ((Boolean)result.getResult()).booleanValue();
  }

  private List<String> getDBTableMetaData() {
    CmdbDalCommand getTableMetaData = CmdbDalCommandFactory.createGetTableMetaDataSimpleCommand(getTableName());
    CmdbDalCommandResult result = getTableMetaData.execute();
    return ((List)result.getResult());
  }

  private void validateTableMetaDataWithDBTableMetaData() {
    Collection columnsNames = getTableDescription().getColumns().keySet();
    boolean valid = true;

    if (columnsNames.size() > 0) {
      List dbColumnsNames = getDBTableMetaData();

      for (Iterator i$ = columnsNames.iterator(); i$.hasNext(); ) { String columnName = (String)i$.next();
        if (!(dbColumnsNames.contains(columnName)))
          valid = false;

      }

      if (!(valid)) {
        String errMsg = "Table [" + getTableName() + "] has in db the columns [" + dbColumnsNames + "], but from class model the columns suppose to be [" + columnsNames + "] !!!";

        throw new CmdbDalException(errMsg);
      }
    }
  }

  private void createBasicPartition() {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("ALTER TABLE ").append(getTableName()).append(" ADD PARTITION ");
    sqlString.append(getPartitionName()).append(" VALUES(").append(getCustomerID().getID());
    sqlString.append(") ").append(getDataTableSpaceClause());

    getConnection().executeAdhocSql(sqlString.toString());
  }

  private String getPartitionName() {
    return "CUST_" + getCustomerID().getID();
  }

  protected void addIndicesAndConstraints() {
    if (getTableDescription().getPrimaryKey() != null)
      addTablePrimaryKey(getTableDescription().getPrimaryKey());

    for (Iterator i$ = getTableDescription().getForeignKeys().iterator(); i$.hasNext(); ) { ForeignKeyDescription foreignKeyDescription = (ForeignKeyDescription)i$.next();
      addTableForeignKey(foreignKeyDescription);
    }
    for (i$ = getTableDescription().getIndexes().iterator(); i$.hasNext(); ) { IndexDescription indexDescription = (IndexDescription)i$.next();
      addTableIndex(indexDescription);
    }
  }

  private void createBasicTable() {
    CmdbDalConnection connection = getConnection();
    StringBuffer sqlString = buildCreateBasicTableSql();

    connection.executeAdhocSql(sqlString.toString());
  }

  protected StringBuffer buildCreateBasicTableSql() {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("create table ").append(getTableName()).append(" (");

    String comma = "";
    for (Iterator i$ = getTableDescription().getColumns().values().iterator(); i$.hasNext(); ) { ColumnDescription columnDescription = (ColumnDescription)i$.next();
      sqlString.append(comma);
      sqlString.append(columnDescription.getName()).append(" ");
      sqlString.append(TableUtils.getDBColumnType(columnDescription, getDbType()));
      sqlString.append(TableUtils.getDBColumnSize(columnDescription, getTableName()));

      if (columnDescription.isNullable())
        sqlString.append(" null");
      else
        sqlString.append(" not null");

      comma = ", ";
    }

    sqlString.append(")").append(getDataTableSpaceClause());

    if (!(isUpdateClassModelEnabled()))
      sqlString.append(getPartitionClause());

    return sqlString;
  }

  private void addTablePrimaryKey(IndexDescription primaryKey)
  {
    if (_logger.isDebugEnabled()) {
      _logger.debug("Add primary key on columns [" + primaryKey.getColumnNames() + "] of table [" + getTableName() + "]");
    }

    if ((!(isUpdateClassModelEnabled())) && (isOracle()))
    {
      addTableIndex(primaryKey, buildPrimaryKeyName());
      return;
    }

    StringBuffer sqlString = new StringBuffer();

    sqlString.append("alter table ").append(getTableName());
    sqlString.append(" add constraint ");
    sqlString.append(buildPrimaryKeyName());
    sqlString.append(" primary key (");
    String comma = "";
    for (Iterator i$ = primaryKey.getColumnNames().iterator(); i$.hasNext(); ) { String columnName = (String)i$.next();
      sqlString.append(comma);
      sqlString.append(columnName);
      comma = ", ";
    }

    sqlString.append(")");
    sqlString.append(getPKTableSpaceClause());
    sqlString.append(getFillFactorClause());

    getConnection().executeAdhocSql(sqlString.toString());
  }

  private void addTableForeignKey(ForeignKeyDescription foreignKeyDescription) {
    if (_logger.isDebugEnabled()) {
      _logger.debug("Add foreign key on column [" + foreignKeyDescription.getColumnName() + "], from table [" + getTableName() + "] to table [" + foreignKeyDescription.getReferencedTableName() + "]");
    }

    StringBuffer sqlString = new StringBuffer();

    sqlString.append("alter table ").append(getTableName());
    sqlString.append(" add constraint ");
    sqlString.append(buildForeignKeyName());
    sqlString.append(" foreign key (").append(foreignKeyDescription.getColumnName()).append(") references ");
    sqlString.append(foreignKeyDescription.getReferencedTableName());
    sqlString.append("(").append(foreignKeyDescription.getReferencedColumnName()).append(")");

    getConnection().executeAdhocSql(sqlString.toString());
  }

  protected String buildUniqueIndexName(String tableName, String columnName) {
    return buildConstraintName(tableName, columnName, "UIX1_");
  }

  private String buildForeignKeyName() {
    String name = "FK1_" + getTableName() + "_id";

    name = DalClassModelUtil.fixLongName(name);

    return name;
  }

  private String buildPrimaryKeyName() {
    String name = "PK_" + getTableName();

    name = DalClassModelUtil.fixLongName(name);

    return name;
  }

  private String getPartitionClause() {
    if (isPartitioningDisabled()) {
      return "";
    }

    if (isOracle())
      return " partition by list(CUSTOMER_ID) (partition CUST_0 values(0))";

    if (isMsSql())
      return "";

    throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
  }

  private String getDataTableSpaceClause()
  {
    if (isOracle())
      return " tablespace " + getConnectionPool().getDataTableSpaceName();
    if (isMsSql())
      return "";

    throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
  }

  private String getPKTableSpaceClause()
  {
    if (isOracle())
      return " using index tablespace " + getConnectionPool().getIndexTableSpaceName();
    if (isMsSql())
      return "";

    throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
  }

  protected static Object getLock()
  {
    return _lock;
  }
}