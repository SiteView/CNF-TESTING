package com.mercury.topaz.cmdb.server.dal.util.table;

import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.DBColumnType;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalUpdateTableAddColumnsComplexCommand;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.TransactionManager;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class TableUtils
{
  private static Log _logger = LogFactory.getEasyLog(TableUtils.class);
  public static final int MAX_STRING_COLUMN_SIZE = 4000;
  public static final int DEFAULT_STRING_COLUMN_SIZE = 50;
  public static final int DEFAULT_RAW_COLUMN_SIZE = 16;
  public static final int DEFAULT_NUMBER_COLUMN_SIZE = 11;
  public static final int DEFAULT_LONG_COLUMN_SIZE = 22;

  public static boolean isColumnExist(String tableName, String columnName)
  {
    CmdbDalCommand checkColumnExistenceCommand = CmdbDalCommandFactory.createCheckColumnExistenceSimpleCommand(tableName, columnName);
    CmdbDalCommandResult result = checkColumnExistenceCommand.execute();
    return ((Boolean)result.getResult()).booleanValue();
  }

  public static String getDBColumnType(ColumnDescription columnDescription, DBType dbType) {
    DBColumnType dbColumnType = columnDescription.getType();
    if (DBType.isOracle(dbType))
      return getOracleTypeFromDBType(dbColumnType);
    if (DBType.isMsSql(dbType))
      return getMSSqlTypeFromDBType(dbColumnType);

    throw new CmdbDalException("Unknown db type [" + dbType + "] !!!");
  }

  public static String getOracleTypeFromDBType(DBColumnType type)
  {
    switch (1.$SwitchMap$com$mercury$topaz$cmdb$server$dal$DBColumnType[type.ordinal()])
    {
    case 1:
      return "number";
    case 2:
      return "number";
    case 3:
      return "number";
    case 4:
      return "number";
    case 5:
      return "number";
    case 6:
      return "date";
    case 7:
      return "raw";
    case 8:
      return "varchar2";
    case 9:
      return "blob";
    case 10:
      return "clob";
    }
    throw new RuntimeException("Unreachable statement - DBColumnType = " + type);
  }

  public static String getMSSqlTypeFromDBType(DBColumnType type)
  {
    switch (1.$SwitchMap$com$mercury$topaz$cmdb$server$dal$DBColumnType[type.ordinal()])
    {
    case 1:
      return "numeric";
    case 2:
      return "numeric";
    case 3:
      return "numeric";
    case 4:
      return "float";
    case 5:
      return "float";
    case 6:
      return "datetime";
    case 7:
      return "varbinary";
    case 8:
      return "varchar";
    case 9:
      return "image";
    case 10:
      return "text";
    }
    throw new RuntimeException("Unreachable statement - DBColumnType = " + type);
  }

  public static String getDBColumnSize(ColumnDescription columnDescription, String tableName)
  {
    return getDBColumnSizeFromCmdbSize(columnDescription.getType(), columnDescription.getSize(), tableName, columnDescription.getName());
  }

  public static String getDBColumnSizeFromCmdbSize(DBColumnType type, Integer cmdbSize, String tableName, String columnName) {
    int numOfDigits;
    String columnSize = "";

    switch (1.$SwitchMap$com$mercury$topaz$cmdb$server$dal$DBColumnType[type.ordinal()])
    {
    case 1:
      columnSize = "(1)";
      break;
    case 7:
      columnSize = "(" + ((cmdbSize == null) ? String.valueOf(16) : cmdbSize.toString()) + ")";
      break;
    case 2:
      if (cmdbSize == null) {
        columnSize = String.valueOf(11);
      } else {
        numOfDigits = getNumOfDigits(cmdbSize);
        columnSize = String.valueOf(numOfDigits);
      }

      columnSize = String.valueOf(11);

      columnSize = "(" + columnSize + ")";
      break;
    case 3:
      if (cmdbSize == null) {
        columnSize = String.valueOf(22);
      } else {
        numOfDigits = getNumOfDigits(cmdbSize);
        columnSize = String.valueOf(numOfDigits);
      }

      columnSize = String.valueOf(22);

      columnSize = "(" + columnSize + ")";
      break;
    case 8:
      String sizeLimitString = String.valueOf(50);
      if ((cmdbSize != null) && (cmdbSize.intValue() > 4000)) {
        _logger.error("Cmdb table [" + tableName + "] - cmdb column [" + columnName + "] : Can't create column with size greater than " + String.valueOf(4000) + ". Create column with size " + String.valueOf(4000));

        sizeLimitString = String.valueOf(4000);
      } else if ((cmdbSize != null) && (cmdbSize.intValue() == 0)) {
        _logger.error("Cmdb table [" + tableName + "] - cmdb column [" + columnName + "] : Can't create column with size 0" + ". Create column with size " + String.valueOf(50));

        sizeLimitString = String.valueOf(50);
      } else if (cmdbSize != null) {
        sizeLimitString = String.valueOf(cmdbSize.intValue()); }
      columnSize = "(" + sizeLimitString + ")";
    case 4:
    case 5:
    case 6: }
    return columnSize;
  }

  public static int getNumOfDigits(Integer cmdbSize)
  {
    int numOfDigits = (int)(Math.log(cmdbSize.doubleValue()) / Math.log(10.0D));
    return (numOfDigits + 2);
  }

  public static void mirrorColumn(String sourceTable, String destinationTable, String columnName, TableModifications mods)
  {
    CmdbDalCommand columnAdder = new CmdbDalUpdateTableAddColumnsComplexCommand(new TableDescription(destinationTable), mods);

    columnAdder.execute();

    String sql = "update " + destinationTable + " set " + columnName + " = " + " (select source." + columnName + " from " + sourceTable + " source" + " where source." + "CMDB_ID" + " = " + destinationTable + "." + "CMDB_ID";

    if (DalClassModelUtil.isModelConsolidated()) {
      sql = sql + " and source.CUSTOMER_ID = " + destinationTable + "." + "CUSTOMER_ID" + ")" + " where " + "CUSTOMER_ID" + " = " + ServerApiFacade.getCustomerID().getID();
    }
    else
    {
      sql = sql + ")";
    }

    JDBCTemplate.getInstance(TransactionManager.getConnection()).executeUpdate(sql);
  }
}