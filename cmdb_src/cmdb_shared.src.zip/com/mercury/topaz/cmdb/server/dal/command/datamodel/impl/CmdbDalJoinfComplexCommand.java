package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.model.util.pair.CmdbObjectIDPair;
import com.mercury.topaz.cmdb.server.model.util.pair.impl.CmdbObjectIDPairFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ConditionOperator;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.JoinfPropertyCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternLinkJoinfParameter;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class CmdbDalJoinfComplexCommand extends CmdbDalObjectsConditionComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalJoinfComplexCommand.class);
  private ElementCondition _dstCondition = null;
  private ModelObjects _dstObjects = null;
  private String _dstClassNameSuffix = null;
  private PatternLinkJoinfParameter _joinfLinkParameter = null;
  private LinkCondition _linkCondition = null;
  private int _currResultCount = 0;
  private List<CmdbObjectIds> _srcConditionIDsInChunks = null;
  private List<CmdbObjectIds> _dstConditionIDsInChunks = null;
  private int _srcIndex;
  private int _dstIndex;

  public CmdbDalJoinfComplexCommand(ElementCondition srcCondition, ElementCondition dstCondition, ModelObjects srcObjects, ModelObjects dstObjects, PatternLinkJoinfParameter joinfParameter, LinkCondition linkCondition)
  {
    super(srcCondition, srcObjects);
    setDstObjects(dstObjects);
    setDstCondition(optimizeCondition(dstCondition));
    setJoinfLinkParameter(joinfParameter);
    setLinkCondition(linkCondition);
    setSrcClassNameSuffix("1");
    setDstClassNameSuffix("2");
  }

  protected void validateInput()
  {
    if ((getSrcCondition() == null) || (getSrcCondition().getClassCondition() == null) || (getDstCondition() == null) || (getDstCondition().getClassCondition() == null))
    {
      _logger.info("Error in joinf command - source or destination condition or class condition is null. Return empty links list !!!");
    }
  }

  protected Object perform() throws Exception {
    if ((getSrcCondition() == null) || (getSrcCondition().getClassCondition() == null) || (getDstCondition() == null) || (getDstCondition().getClassCondition() == null))
    {
      return new ArrayList();
    }

    int numOfInputObjects = getSrcObjects().size() + getDstObjects().size();
    if (numOfInputObjects > getMemoryInsteadTempTableHighThreshold()) {
      String errMsg = "Can't handle joinf query due to temp table limitation. Number of input objects [" + numOfInputObjects + "]. Maximum allowed [" + getMemoryInsteadTempTableHighThreshold() + "] !!!";

      throw new CmdbDalException(errMsg);
    }
    return performJoinfQuery();
  }

  private Object performJoinfQuery()
    throws Exception
  {
    if (_logger.isDebugEnabled()) {
      _logger.debug("Performing joinf query with src condition [" + getSrcCondition() + "], " + "dst condition [" + getDstCondition() + "], joinf parameter [" + getJoinfLinkParameter() + "], " + "src objects [" + getSrcObjects() + "], dst objects [" + getDstObjects() + "]");
    }

    this._currResultCount = 0;
    divideSrcConditionIDs();
    divideDstConditionIDs();
    CmdbDalConnection connection = getConnection();

    List totalResult = new ArrayList(1000);

    if ((this._srcConditionIDsInChunks.size() == 0) || (this._dstConditionIDsInChunks.size() == 0)) {
      totalResult.addAll((Collection)performJoinfQuery(extractConditionIDs(getSrcObjects(), getSrcCondition()), extractConditionIDs(getDstObjects(), getDstCondition()), connection));
    }
    else
      for (this._srcIndex = 0; this._srcIndex < this._srcConditionIDsInChunks.size(); this._srcIndex += 1)
        for (this._dstIndex = 0; this._dstIndex < this._dstConditionIDsInChunks.size(); this._dstIndex += 1)
        {
          CmdbObjectIds srcObjectIds = (CmdbObjectIds)this._srcConditionIDsInChunks.get(this._srcIndex);
          CmdbObjectIds dstObjectIds = (CmdbObjectIds)this._dstConditionIDsInChunks.get(this._dstIndex);

          totalResult.addAll((Collection)performJoinfQuery(srcObjectIds, dstObjectIds, connection));
        }


    return totalResult;
  }

  private Object performJoinfQuery(CmdbObjectIds srcObjectIds, CmdbObjectIds dstObjectIds, CmdbDalConnection connection)
    throws Exception
  {
    if (_logger.isDebugEnabled()) {
      _logger.debug("Performing joinf query for source chunk objects sized [" + srcObjectIds.size() + "], " + "destination chunk objects sized [" + dstObjectIds.size() + "]");
    }

    CmdbDalResultSet resultSet = null;
    CmdbDalPreparedStatement preparedStatement = null;
    try
    {
      List bindVariables = new ArrayList();
      List bindVariablesTypes = new ArrayList();

      String sqlString = createQuerySql(connection, bindVariables, bindVariablesTypes, srcObjectIds, dstObjectIds);
      preparedStatement = createAndFillPreparedStatement(connection, sqlString, bindVariables, bindVariablesTypes);
      resultSet = preparedStatement.executeQuery();

      Object localObject1 = getResult(resultSet);

      return localObject1;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private String createQuerySql(CmdbDalConnection connection, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, CmdbObjectIds srcObjectIds, CmdbObjectIds dstObjectIds)
    throws SQLException
  {
    Set participatedClasses = new HashSet();

    StringBuffer sqlString = new StringBuffer();

    addIDsCondition(connection, sqlString, bindVariables, bindVariablesTypes, srcObjectIds, dstObjectIds);
    addClassCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses);
    addPropertiesCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses);
    addJoinfParameterCondition(sqlString, participatedClasses);

    addSelectSql(sqlString, participatedClasses, bindVariables, bindVariablesTypes);

    return sqlString.toString();
  }

  protected void addSelectSql(StringBuffer conditionSql, Set<String> participatedClasses, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) {
    StringBuffer selectSql = new StringBuffer();

    selectSql.append("SELECT ");

    String srcConditionClassName = getSrcCondition().getClassCondition().getClassName();
    String dstConditionClassName = getDstCondition().getClassCondition().getClassName();
    selectSql.append(getDummyClassName(srcConditionClassName, getSrcClassNameSuffix())).append(".");
    selectSql.append("CMDB_ID");
    selectSql.append(", ");
    selectSql.append(getDummyClassName(dstConditionClassName, getDstClassNameSuffix())).append(".");
    selectSql.append("CMDB_ID");

    participatedClasses.add(getDummyClassName(srcConditionClassName, getSrcClassNameSuffix()));
    participatedClasses.add(getDummyClassName(dstConditionClassName, getDstClassNameSuffix()));

    addFromSql(selectSql, participatedClasses);

    selectSql.append(" WHERE ");

    addAllowedLinksTypeRestriction(selectSql, srcConditionClassName, dstConditionClassName);

    Collection srcClasses = new ArrayList();
    Collection dstClasses = new ArrayList();

    Iterator classesIter = participatedClasses.iterator();
    int srcClassNameLength = getSrcClassNameSuffix().length();
    while (classesIter.hasNext()) {
      String dummyClassName = (String)classesIter.next();
      if (extractClassNameSuffix(dummyClassName, srcClassNameLength).equals(getSrcClassNameSuffix()))
        srcClasses.add(dummyClassName);
      else
        dstClasses.add(dummyClassName);

    }

    addPairsJoinSql(selectSql, srcClasses, bindVariables, bindVariablesTypes);
    addPairsJoinSql(selectSql, dstClasses, bindVariables, bindVariablesTypes);

    conditionSql.insert(0, selectSql);
  }

  private void addAllowedLinksTypeRestriction(StringBuffer selectSql, String srcConditionClassName, String dstConditionClassName)
  {
    if (getLinkCondition().getAllowedLinksType() == 0) {
      selectSql.append(" 1=1 ");
    } else {
      selectSql.append(getDummyClassName(srcConditionClassName, getSrcClassNameSuffix())).append(".");
      selectSql.append("CMDB_ID");

      if (getLinkCondition().getAllowedLinksType() == 1)
        selectSql.append("!=");
      else
        selectSql.append("=");

      selectSql.append(getDummyClassName(dstConditionClassName, getDstClassNameSuffix())).append(".");
      selectSql.append("CMDB_ID");
    }
  }

  protected void addIDsCondition(CmdbDalConnection connection, StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, CmdbObjectIds srcConditionIDs, CmdbObjectIds dstConditionIDs)
    throws SQLException
  {
    int numOfIds = srcConditionIDs.size() + dstConditionIDs.size();
    if (numOfIds <= getMemoryInsteadTempTableLowThreshold())
      if (hasConditionIDs(srcConditionIDs, dstConditionIDs)) {
        truncateCmdbIDTempTable(connection);

        addIDsCondition(srcConditionIDs, connection, sqlString, bindVariables, bindVariablesTypes, getSrcCondition(), getSrcClassNameSuffix());
        addIDsCondition(dstConditionIDs, connection, sqlString, bindVariables, bindVariablesTypes, getDstCondition(), getDstClassNameSuffix());
      }
    else
      _logger.info("Decide not to use temp table in joinf query. Amount of ids [" + numOfIds + "] and" + " low threshold is [" + getMemoryInsteadTempTableLowThreshold() + "]");
  }

  private void addIDsCondition(CmdbObjectIds conditionIDs, CmdbDalConnection connection, StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, ElementCondition condition, String classNameSuffix)
    throws SQLException
  {
    if (hasConditionIDs(conditionIDs)) {
      ElementClassCondition classCondition = condition.getClassCondition();
      sqlString.append(" AND ");
      if ((condition.getIdsCondition() != null) && (condition.getIdsCondition().isNegate()))
        sqlString.append("NOT ");

      if (isCmdbIDTempTableMustNotUsingChunksMechanism(getContainerSize(conditionIDs))) {
        fillCmdbIDTempTable(connection, conditionIDs, Integer.valueOf(classNameSuffix).intValue());
        sqlString.append(createJoinWithCmdbIDTempTableIndexConditionSql(getDummyClassName(classCondition.getClassName(), classNameSuffix), conditionIDs.size()));

        bindVariables.add(Integer.valueOf(classNameSuffix));
        bindVariablesTypes.add(CmdbSimpleTypes.CmdbInteger);
      } else {
        sqlString.append(getDummyClassName(classCondition.getClassName(), classNameSuffix)).append(".").append("CMDB_ID");
        sqlString.append(getInSqlString(getContainerSize(conditionIDs)));

        addIDsToBindVariables(conditionIDs, bindVariables, bindVariablesTypes);
      }
    }
  }

  private void fillCmdbIDTempTable(CmdbDalConnection connection, CmdbObjectIds objectIds, int index) throws SQLException {
    List ids = new ArrayList();
    ReadOnlyIterator objectsIDsIter = objectIds.getIdsIterator();

    while (objectsIDsIter.hasNext()) {
      CmdbObjectID objectID = (CmdbObjectID)objectsIDsIter.next();
      ids.add(convertCmdbID2Bytes(objectID));
    }

    fillCmdbIDTempTable(connection, ids, index);
  }

  private CmdbObjectIds extractConditionIDs(ModelObjects objects, ElementCondition condition)
  {
    return ((CmdbObjectIds)super.extractConditionIDs(objects, condition));
  }

  protected void addClassCondition(StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses) throws SQLException {
    super.addClassCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses);
    addClassCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses, getDstClassNameSuffix(), getDstCondition(), getDstObjects());
  }

  protected void addPropertiesCondition(StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses) throws SQLException {
    super.addPropertiesCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses);
    addPropertiesCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses, getDstClassNameSuffix(), getDstCondition());
  }

  private void addJoinfParameterCondition(StringBuffer sqlString, Set<String> participatedClasses) {
    if (hasJoinfParameter()) {
      ReadOnlyIterator joinfPropertyConditionIter = getJoinfLinkParameter().getIterator();
      while (joinfPropertyConditionIter.hasNext()) {
        JoinfPropertyCondition joinfPropertyCondition = (JoinfPropertyCondition)joinfPropertyConditionIter.next();
        addJoinfPropertyCondition(joinfPropertyCondition, sqlString, participatedClasses);
      }
    }
  }

  private void addJoinfPropertyCondition(JoinfPropertyCondition joinfPropertyCondition, StringBuffer sqlString, Set<String> participatedClasses) {
    String end1PropertyName = joinfPropertyCondition.getEnd1PropertyName();
    String end2PropertyName = joinfPropertyCondition.getEnd2PropertyName();
    ConditionOperator conditionOperator = joinfPropertyCondition.getOperator();

    CmdbClass end1AttributeClass = ClassModelUtil.getAttributeClass(end1PropertyName, getSrcCondition().getClassCondition().getClassName());
    validateAttributePersistent(end1PropertyName, end1AttributeClass);
    CmdbClass end2AttributeClass = ClassModelUtil.getAttributeClass(end2PropertyName, getDstCondition().getClassCondition().getClassName());
    validateAttributePersistent(end2PropertyName, end2AttributeClass);

    addJoinfPropertyCondition(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, conditionOperator, end2AttributeClass, end2PropertyName);
  }

  private void validateAttributePersistent(String propertyName, CmdbClass attributeClass) {
    CmdbAttribute attribute = ClassModelUtil.getAttributeByName(propertyName, attributeClass);
    if (!(ClassModelUtil.isPersistentAttribute(attribute)))
      throw new CmdbDalException("Attribute [" + attribute.getName() + "] from class [" + attributeClass.getName() + "] is not persistent in db");
  }

  private void addJoinfPropertyCondition(StringBuffer sqlString, CmdbClass end1AttributeClass, String end1PropertyName, Set<String> participatedClasses, ConditionOperator conditionOperator, CmdbClass end2AttributeClass, String end2PropertyName)
  {
    sqlString.append(" AND ");
    if ((ConditionOperator.EQUEL.equals(conditionOperator)) || (ConditionOperator.NOT_EQUEL.equals(conditionOperator)))
    {
      addEqalityCondition(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, conditionOperator, end2AttributeClass, end2PropertyName);
    } else if (ConditionOperator.IN_STR.equals(conditionOperator))
      if (getConnectionPool().isUsingOracleDB())
        addOracleInstrCondition(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, end2AttributeClass, end2PropertyName);
      else
        addSqlServerCharIndexCondition(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, end2AttributeClass, end2PropertyName);

    else if (ConditionOperator.IN_STR_IGNORE_CASE.equals(conditionOperator))
      if (getConnectionPool().isUsingOracleDB())
        addOracleInstrIgnoreCaseCondition(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, end2AttributeClass, end2PropertyName);
      else
        addSqlServerCharIndexIgnoreCaseCondition(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, end2AttributeClass, end2PropertyName);

    else
      throw new CmdbDalException("Condition operator [" + conditionOperator + "], is not supported in joinf property condition !!!");
  }

  private void addSqlServerCharIndexIgnoreCaseCondition(StringBuffer sqlString, CmdbClass end1AttributeClass, String end1PropertyName, Set<String> participatedClasses, CmdbClass end2AttributeClass, String end2PropertyName)
  {
    sqlString.append("CHARINDEX(");
    sqlString.append("lower(");
    addColumnSql(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, getSrcClassNameSuffix());
    sqlString.append("),lower(");
    addColumnSql(sqlString, end2AttributeClass, end2PropertyName, participatedClasses, getDstClassNameSuffix());
    sqlString.append("))>0");
  }

  private void addOracleInstrIgnoreCaseCondition(StringBuffer sqlString, CmdbClass end1AttributeClass, String end1PropertyName, Set<String> participatedClasses, CmdbClass end2AttributeClass, String end2PropertyName)
  {
    sqlString.append("INSTR(");
    sqlString.append("lower(");
    addColumnSql(sqlString, end2AttributeClass, end2PropertyName, participatedClasses, getDstClassNameSuffix());
    sqlString.append("),lower(");
    addColumnSql(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, getSrcClassNameSuffix());
    sqlString.append("))>0");
  }

  private void addSqlServerCharIndexCondition(StringBuffer sqlString, CmdbClass end1AttributeClass, String end1PropertyName, Set<String> participatedClasses, CmdbClass end2AttributeClass, String end2PropertyName) {
    sqlString.append("CHARINDEX(");
    addColumnSql(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, getSrcClassNameSuffix());
    sqlString.append(",");
    addColumnSql(sqlString, end2AttributeClass, end2PropertyName, participatedClasses, getDstClassNameSuffix());
    sqlString.append(")>0");
  }

  private void addOracleInstrCondition(StringBuffer sqlString, CmdbClass end1AttributeClass, String end1PropertyName, Set<String> participatedClasses, CmdbClass end2AttributeClass, String end2PropertyName) {
    sqlString.append("INSTR(");
    addColumnSql(sqlString, end2AttributeClass, end2PropertyName, participatedClasses, getDstClassNameSuffix());
    sqlString.append(",");
    addColumnSql(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, getSrcClassNameSuffix());
    sqlString.append(")>0");
  }

  private void addEqalityCondition(StringBuffer sqlString, CmdbClass end1AttributeClass, String end1PropertyName, Set<String> participatedClasses, ConditionOperator conditionOperator, CmdbClass end2AttributeClass, String end2PropertyName)
  {
    addColumnSql(sqlString, end1AttributeClass, end1PropertyName, participatedClasses, getSrcClassNameSuffix());
    addJoinfOperator(conditionOperator, sqlString);
    addColumnSql(sqlString, end2AttributeClass, end2PropertyName, participatedClasses, getDstClassNameSuffix());
  }

  private void addJoinfOperator(ConditionOperator conditionOperator, StringBuffer sqlString) {
    if (ConditionOperator.EQUEL.equals(conditionOperator))
      addVariableOperator(sqlString, "=");
    else if (ConditionOperator.NOT_EQUEL.equals(conditionOperator))
      addVariableOperator(sqlString, "!=");
  }

  protected Object getResult(CmdbDalResultSet resultSet) throws SQLException
  {
    return buildCmdbIDsList(resultSet);
  }

  private List<CmdbObjectIDPair> buildCmdbIDsList(CmdbDalResultSet resultSet)
    throws SQLException
  {
    List cmdbObjectIdPairs = new ArrayList();
    boolean filterIds = false;

    int srcSize = (this._srcConditionIDsInChunks.size() == 0) ? 0 : ((CmdbObjectIds)this._srcConditionIDsInChunks.get(this._srcIndex)).size();
    int dstSize = (this._dstConditionIDsInChunks.size() == 0) ? 0 : ((CmdbObjectIds)this._dstConditionIDsInChunks.get(this._dstIndex)).size();
    int numOfIds = srcSize + dstSize;

    if (numOfIds > getMemoryInsteadTempTableLowThreshold()) {
      filterIds = true;
    }

    getConnectionPool().resetTimeout(getConnection());
    int maxJoinfResults = getLocalEnvironment().getSettingsReader().getInt("dal.joinf.max.result.size", 400000);
    int i = 0;
    while (resultSet.next()) {
      byte[] idAsBytes1 = resultSet.getBytes(1);
      byte[] idAsBytes2 = resultSet.getBytes(2);
      CmdbObjectID objectID1 = restoreObjectID(idAsBytes1);
      CmdbObjectID objectID2 = restoreObjectID(idAsBytes2);
      ++i;

      if (i % 10000 == 0) {
        getConnectionPool().resetTimeout(getConnection());
      }

      if (filterIds)
      {
        if ((((CmdbObjectIds)this._srcConditionIDsInChunks.get(this._srcIndex)).contains(objectID1)) && (((CmdbObjectIds)this._dstConditionIDsInChunks.get(this._dstIndex)).contains(objectID2)))
        {
          cmdbObjectIdPairs.add(CmdbObjectIDPairFactory.create(objectID1, objectID2));
          this._currResultCount += 1;
        }
      } else {
        cmdbObjectIdPairs.add(CmdbObjectIDPairFactory.create(objectID1, objectID2));
        this._currResultCount += 1;
      }

      if (this._currResultCount > maxJoinfResults) {
        String errMsg = "Joinf Results exceed maximum value [max results value is: " + maxJoinfResults + "]";
        throw new CmdbDalException(errMsg);
      }
    }

    return cmdbObjectIdPairs;
  }

  private List<CmdbObjectIds> divideIdsToChunks(CmdbObjectIds objectIds, int chunkSize)
  {
    if (chunkSize <= 0) {
      throw new IllegalArgumentException("Chunk size must be strictly positive");
    }

    List list = new ArrayList(objectIds.size() / chunkSize + 1);

    CmdbObjectIds chunkIds = CmdbObjectIdsFactory.createIdsList(chunkSize);

    for (ReadOnlyIterator iter = objectIds.getIdsIterator(); iter.hasNext(); ) {
      if (chunkIds.size() == chunkSize) {
        list.add(chunkIds);
        chunkIds = CmdbObjectIdsFactory.createIdsList(chunkSize);
      }
      chunkIds.add((CmdbObjectID)iter.next());
    }
    if (!(chunkIds.isEmpty())) {
      list.add(chunkIds);
    }

    return list;
  }

  protected boolean isNonIdTempTablesInUse()
  {
    return ((isNonIdTempTablesInUse(getSrcCondition(), getSrcObjects())) || (isNonIdTempTablesInUse(getDstCondition(), getDstObjects())));
  }

  private boolean hasConditionIDs(CmdbObjectIds srcConditionIDs, CmdbObjectIds dstConditionIDs) {
    return ((hasConditionIDs(srcConditionIDs)) || (hasConditionIDs(dstConditionIDs)));
  }

  protected boolean hasPropertiesCondition() {
    return ((hasPropertiesCondition(getSrcCondition())) || (hasPropertiesCondition(getDstCondition())));
  }

  private boolean hasJoinfParameter() {
    return ((getJoinfLinkParameter() != null) && (getJoinfLinkParameter().getIterator().hasNext()));
  }

  protected String getDummyClassName(String className, String classNameSuffix) {
    return getTableNameByClassName(className) + classNameSuffix;
  }

  protected String extractOriginalClassName(String dummyClassName, int classNameSuffixLength) {
    return dummyClassName.substring(0, dummyClassName.length() - classNameSuffixLength);
  }

  private String extractClassNameSuffix(String dummyClassName, int classNameSuffixLength) {
    return dummyClassName.substring(dummyClassName.length() - classNameSuffixLength, dummyClassName.length());
  }

  private ElementCondition getSrcCondition() {
    return getCondition();
  }

  private ElementCondition getDstCondition() {
    return this._dstCondition;
  }

  private void setDstCondition(ElementCondition dstCondition) {
    this._dstCondition = dstCondition;
  }

  private ModelObjects getSrcObjects() {
    return getModelObjects();
  }

  private ModelObjects getDstObjects() {
    return this._dstObjects;
  }

  private void setDstObjects(ModelObjects dstObjects) {
    this._dstObjects = dstObjects;
  }

  private PatternLinkJoinfParameter getJoinfLinkParameter() {
    return this._joinfLinkParameter;
  }

  private void setJoinfLinkParameter(PatternLinkJoinfParameter joinfLinkParameter) {
    this._joinfLinkParameter = joinfLinkParameter;
  }

  private String getDstClassNameSuffix() {
    return this._dstClassNameSuffix;
  }

  private void setDstClassNameSuffix(String dstClassNameSuffix) {
    this._dstClassNameSuffix = dstClassNameSuffix;
  }

  private String getSrcClassNameSuffix() {
    return getClassNameSuffix();
  }

  private void setSrcClassNameSuffix(String srcClassNameSuffix) {
    setClassNameSuffix(srcClassNameSuffix);
  }

  private LinkCondition getLinkCondition() {
    return this._linkCondition;
  }

  private void setLinkCondition(LinkCondition linkCondition) {
    this._linkCondition = linkCondition;
  }

  private void divideSrcConditionIDs() {
    CmdbObjectIds srcConditionIDs = extractConditionIDs(getSrcObjects(), getSrcCondition());

    int chunkSize = getLocalEnvironment().getSettingsReader().getInt("dal.joinf.calc.chunk.size", 30000);
    this._srcConditionIDsInChunks = divideIdsToChunks(srcConditionIDs, chunkSize);
  }

  private void divideDstConditionIDs() {
    CmdbObjectIds dstConditionIDs = extractConditionIDs(getDstObjects(), getDstCondition());

    int chunkSize = getLocalEnvironment().getSettingsReader().getInt("dal.joinf.calc.chunk.size", 30000);
    this._dstConditionIDsInChunks = divideIdsToChunks(dstConditionIDs, chunkSize);
  }
}