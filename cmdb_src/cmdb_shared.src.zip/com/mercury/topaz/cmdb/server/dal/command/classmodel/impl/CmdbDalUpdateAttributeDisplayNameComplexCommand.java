package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import java.sql.SQLException;

public class CmdbDalUpdateAttributeDisplayNameComplexCommand extends CmdbDalUpdateAttributePropertyComplexCommand
{
  public CmdbDalUpdateAttributeDisplayNameComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass)
  {
    super(attribute, cmdbClass);
  }

  protected String getCommandName() {
    return "Update display name of attribute [" + getAttribute().getName() + "] in class [" + getCmdbClass().getName() + "] to [" + ((CmdbAttribute)getAttribute()).getDisplayName() + "]";
  }

  protected String getColumnNameToUpdate() {
    return "DISPLAY_NAME";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long attributeId) throws SQLException {
    preparedStatement.setString(((CmdbAttribute)getAttribute()).getDisplayName());
    preparedStatement.setBoolean(getAttribute().isModifiedByUser());
    preparedStatement.setLong(attributeId);
  }
}