package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;

public class CmdbDalUpdateLinksComplexCommand extends CmdbDalUpdateElementsComplexCommand<CmdbLink>
{
  public CmdbDalUpdateLinksComplexCommand(CmdbLinks links)
  {
    super(links);
  }
}