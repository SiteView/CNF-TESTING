package com.mercury.topaz.cmdb.server.dal.dao.impl;

import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.CmdbDalDataModelCommandFactory;
import com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.cost_estimate.EstimateGettingCIs;
import com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.cost_estimate.IsCostEstimationSupported;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.dal.dao.CmdbDalDataModelDAO;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalDAO;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.manage.dal.TransactionManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.model.graph.ModelGraph;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrappers;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbUnresolvedDataIDs;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.graph.object.impl.ModelObjectsFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternLinkJoinfParameter;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import com.mercury.topaz.cmdb.shared.tql.result.CmdbAttributeGroupedByCount;
import com.mercury.topaz.cmdb.shared.tql.result.CmdbClassCount;
import java.util.List;
import java.util.Set;

class CmdbDalJdbcDataModelDAO
  implements CmdbDalDataModelDAO
{
  private final CmdbDalDAO dao;
  protected static Log _infoLogger = CmdbLogFactory.getCMDBInfoLog();
  private final LocalEnvironment localEnvironment;

  CmdbDalJdbcDataModelDAO(LocalEnvironment localEnvironment)
  {
    this.localEnvironment = localEnvironment;
    this.dao = localEnvironment.getDao();
  }

  public void startTransaction() {
    TransactionManager.start(this.dao.getConnectionsPoolManager());
  }

  public void commitTransaction() {
    TransactionManager.commit();
  }

  public void rollbackTransaction() {
    TransactionManager.rollback();
  }

  public <T> CmdbDalCommandResult<T> executeQuery(CmdbDalCommand<T> command) {
    return this.dao.executeQuery(command);
  }

  public void execute(CmdbDalCommand<Void> command) {
    this.dao.execute(command);
  }

  public CmdbObjects getObjectsLayout(ModelObjects objects, ElementSimpleLayout layout) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetObjectsLayoutComplexCommand(objects, layout));
    return ((CmdbObjects)result.getResult());
  }

  public CmdbLinks getLinksLayout(ModelLinks links, ElementSimpleLayout layout) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetLinksLayoutComplexCommand(links, layout));
    return ((CmdbLinks)result.getResult());
  }

  public CmdbObjects getFunctionsLayout(ModelObjects groupByObjects, ModelLinks modelLinks, ModelObjects aggregatedObjects, LayoutFunctionWrappers wrappers) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetFunctionsLayoutComplexCommand(groupByObjects, modelLinks, aggregatedObjects, wrappers));
    return ((CmdbObjects)result.getResult());
  }

  public CmdbObjectIds sortObjects(ModelObjects modelObjects, CmdbSortCommand sortCommand) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createSortObjectsComplexCommand(modelObjects, sortCommand));
    return ((CmdbObjectIds)result.getResult());
  }

  public CmdbObjectIds sortObjects(ElementCondition elementCondition, CmdbSortCommand sortCommand) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createSortObjectsComplexCommand(elementCondition, sortCommand));
    return ((CmdbObjectIds)result.getResult());
  }

  public CmdbLinks sortLinks(ModelLinks modelLinks, CmdbSortCommand sortCommand) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createSortLinksComplexCommand(modelLinks, sortCommand));
    return ((CmdbLinks)result.getResult());
  }

  public CmdbObjectIds getRecursiveDeleteSurvivors(CmdbLinks dependedEnd1Links, CmdbLinks dependedEnd2Links, CmdbLinkIds alreadyDeletedLinks) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetRecursiveDeleteSurvivorObjectsCommand(dependedEnd1Links, dependedEnd2Links, alreadyDeletedLinks));
    return ((CmdbObjectIds)result.getResult());
  }

  public CmdbObjectIds getObjectsIDs(ElementCondition condition) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetObjectsByConditionComplexCommand(ModelObjectsFactory.create(), condition));
    return ((CmdbObjectIds)result.getResult());
  }

  public CmdbObjectIds getObjectsIDs(ElementCondition condition, ModelObjects objects) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetObjectsByConditionComplexCommand(objects, condition));
    return ((CmdbObjectIds)result.getResult());
  }

  public CmdbObjects getCmdbObjects(ElementCondition condition) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetCmdbObjectsNoPropertiesComplexCommand(condition));
    return ((CmdbObjects)result.getResult());
  }

  public CmdbLinks getCmdbLinks(LinkCondition linkCondition) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetCmdbLinksNoPropertiesComplexCommand(linkCondition));
    return ((CmdbLinks)result.getResult());
  }

  public ModelLinks getLinks(LinkCondition linkCondition, ModelLinks links) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetLinksByConditionComplexCommand(links, linkCondition));
    return ((ModelLinks)result.getResult());
  }

  public ModelLinks getLinks(ElementCondition end1Condition, LinkCondition linkCondition, ElementCondition end2Condition) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetTriplesComplexCommand(end1Condition, linkCondition, end2Condition));
    return ((ModelLinks)result.getResult());
  }

  public ModelLinks getLinksOfObjects(ElementCondition elementCondition, LinkCondition linkCondition) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGetLinksOfObjectsComplexCommand(elementCondition, linkCondition));
    return ((ModelLinks)result.getResult());
  }

  public List getJoinObjectIDPairs(ElementCondition src, ElementCondition dst, PatternLinkJoinfParameter joinfLinkParameter, LinkCondition linkCondition) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createJoinfComplexCommand(src, dst, ModelObjectsFactory.create(), ModelObjectsFactory.create(), joinfLinkParameter, linkCondition));
    return ((List)result.getResult());
  }

  public List getJoinObjectIDPairs(ElementCondition src, ElementCondition dst, ModelObjects srcObjects, ModelObjects dstObjects, PatternLinkJoinfParameter joinfLinkParameter, LinkCondition linkCondition) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createJoinfComplexCommand(src, dst, srcObjects, dstObjects, joinfLinkParameter, linkCondition));
    return ((List)result.getResult());
  }

  public CmdbAttributeGroupedByCount getObjectsAttributesGroupedByCount(ElementCondition elementCondition, ModelObjects modelObjects, String attributeName) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createGroupClassByAttributeComplexCommand(elementCondition, modelObjects, attributeName));
    return ((CmdbAttributeGroupedByCount)result.getResult());
  }

  public ModelGraph loadModelTopology(Set<String> nonResidentClasses)
  {
    if (!(isRunStatisticsRequired())) {
      _infoLogger.info("Customer [" + getCustomerID() + "]: Check for statistics is not performed due to dal.handle.statistics.on.startup flag is false");
      return loadModel(nonResidentClasses);
    }

    if (checkIsRunStatisticsRequired()) {
      _infoLogger.info("Customer [" + getCustomerID() + "]: Statistics are not up to date. Decide to run statistics");
      runStatistics();
      return loadModel(nonResidentClasses);
    }
    try
    {
      _infoLogger.info("Customer [" + getCustomerID() + "]: Statistics are up to date (according to the defined threshold). Decide not to run statistics");
      return loadModel(nonResidentClasses);
    }
    catch (CmdbDalException ex) {
      _infoLogger.info("Customer [" + getCustomerID() + "]: Decide to run statistics due to exception during loading model. " + "If the problem persist after server restart please set dal.handle.statistics.on.startup flag to false", ex);

      runStatistics(); }
    return loadModel(nonResidentClasses);
  }

  protected void runStatistics()
  {
    try {
      execute(CmdbDalCommandFactory.createRunStatisticsComplexCommand());
    }
    catch (Exception ex) {
      _infoLogger.info("Customer [" + getCustomerID() + "]: Fail to run statistics", ex);
    }
  }

  protected ModelGraph loadModel(Set<String> nonResidentClasses) {
    return ((ModelGraph)executeQuery(CmdbDalDataModelCommandFactory.createLoadModelGraphComplexCommand(nonResidentClasses)).getResult());
  }

  protected boolean checkIsRunStatisticsRequired() {
    CmdbDalCommandResult result = executeQuery(CmdbDalCommandFactory.createIsRunStatisticsRequiredComplexCommand());
    return ((Boolean)result.getResult()).booleanValue();
  }

  private boolean isRunStatisticsRequired() {
    SettingsReader settingsReader = this.localEnvironment.getSettingsReader();
    return settingsReader.getBoolean("dal.handle.statistics.on.startup", true);
  }

  public void addObjects(CmdbObjects objects)
  {
    execute(CmdbDalDataModelCommandFactory.createAddObjectsComplexCommand(objects));
  }

  public void removeObjects(CmdbObjects objects) {
    execute(CmdbDalDataModelCommandFactory.createRemoveObjectsComplexCommand(objects));
  }

  public void updateObjects(CmdbObjects objects) {
    execute(CmdbDalDataModelCommandFactory.createUpdateObjectsComplexCommand(objects));
  }

  public void updateLinks(CmdbLinks links) {
    execute(CmdbDalDataModelCommandFactory.createUpdateLinksComplexCommand(links));
  }

  public void addLinks(CmdbLinks links) {
    execute(CmdbDalDataModelCommandFactory.createAddLinksComplexCommand(links));
  }

  public void removeLinks(CmdbLinks links) {
    execute(CmdbDalDataModelCommandFactory.createRemoveLinksComplexCommand(links));
  }

  public void updateElementsWithClassPropertiesAndNotUpdateUpdateTime(CmdbIDsCollection<? extends CmdbDataID> idsCollection, CmdbProperties properties, String className) {
    execute(CmdbDalDataModelCommandFactory.createUpdateElementsWithClassPropertiesAndNotUpdateTimeComplexCommand(idsCollection, properties, className));
  }

  public int countClassInstances(String fullQualifedClassName, boolean includeDerived) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createCountClassInstancesComplexCommand(fullQualifedClassName, includeDerived));
    return ((Integer)result.getResult()).intValue();
  }

  public CmdbClassCount countClassesInstances() {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createCountClassesInstancesComplexCommand());
    return ((CmdbClassCount)result.getResult());
  }

  public CmdbGraph getCmdbGraph() {
    return ((CmdbGraph)executeQuery(CmdbDalDataModelCommandFactory.createLoadCmdbGraphComplexCommand()).getResult());
  }

  public CmdbIDsCollection resolveCmdbIDs(CmdbUnresolvedDataIDs unresolvedDataIDs) {
    CmdbDalCommandResult result = executeQuery(CmdbDalDataModelCommandFactory.createResolveCmdbIDsCommand(unresolvedDataIDs));
    return ((CmdbIDsCollection)result.getResult());
  }

  public double estimateGettingCIs(ElementCondition condition) {
    CmdbDalCommand command = new EstimateGettingCIs(condition);
    CmdbDalCommandResult result = executeQuery(command);
    return ((Double)result.getResult()).doubleValue();
  }

  public boolean isCostEstimationSupported() {
    CmdbDalCommand command = new IsCostEstimationSupported();
    CmdbDalCommandResult result = executeQuery(command);
    return ((Boolean)result.getResult()).booleanValue();
  }

  public void optimizeStorage() {
    execute(CmdbDalCommandFactory.createRunStatisticsComplexCommand());
  }

  public DbContext getDbContext() {
    return this.dao.getConnectionsPoolManager().getDbContext();
  }

  private CmdbCustomerID getCustomerID() {
    return this.localEnvironment.getCustomerID();
  }
}