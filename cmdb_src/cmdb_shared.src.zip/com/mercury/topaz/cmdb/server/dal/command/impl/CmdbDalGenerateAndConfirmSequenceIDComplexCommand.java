package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class CmdbDalGenerateAndConfirmSequenceIDComplexCommand extends CmdbDalGenerateSequenceIDComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalGenerateAndConfirmSequenceIDComplexCommand.class);
  private static Map _tablesColumnsMap = null;

  public CmdbDalGenerateAndConfirmSequenceIDComplexCommand()
  {
    this(DEFAULT_GENERATOR_NAME);
  }

  public CmdbDalGenerateAndConfirmSequenceIDComplexCommand(String generatorName) {
    super(generatorName);
  }

  protected Long perform() throws Exception {
    Long sequenceId = getSequenceId();

    while (isSequenceIdExist(sequenceId)) {
      sequenceId = getSequenceId();
    }

    return sequenceId;
  }

  boolean isSequenceIdExist(Long sequenceId) throws SQLException {
    for (Iterator tablesIter = getTablesColumnsMap().keySet().iterator(); tablesIter.hasNext(); ) {
      String tableName = (String)tablesIter.next();
      String sequenceIdColumnName = (String)getTablesColumnsMap().get(tableName);

      if (isSequenceIdExist(sequenceId, tableName, sequenceIdColumnName))
        return true;

    }

    return false;
  }

  boolean isSequenceIdExist(Long sequenceId, String tableName, String sequenceIdColumnName) throws SQLException {
    StringBuffer sqlString = new StringBuffer();
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;

    sqlString.append("SELECT 1 FROM ").append(tableName).append(" WHERE ");
    sqlString.append(sequenceIdColumnName).append("=?");
    try
    {
      preparedStatement = getConnection().prepareStatement4Select(sqlString.toString());
      preparedStatement.setLong(sequenceId);
      resultSet = preparedStatement.executeQuery();

      boolean bool = resultSet.next();

      return bool;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private static Map getTablesColumnsMap()
  {
    return _tablesColumnsMap;
  }

  private static void setTablesColumnsMap(Map tablesColumnsMap) {
    _tablesColumnsMap = tablesColumnsMap;
  }

  static
  {
    Map tablesColumnsMap = new HashMap(5);
    tablesColumnsMap.put("CCM_CLASSES", "CLASS_ID");
    tablesColumnsMap.put("CCM_ATTRIBUTE", "ATTRIBUTE_ID");
    tablesColumnsMap.put("CCM_METHODS", "METHOD_ID");
    tablesColumnsMap.put("CCM_TYPE_DEFS", "TYPE_DEF_ID");
    tablesColumnsMap.put("CCM_TDEF_ENUM", "ID");
    tablesColumnsMap.put("CCM_MIGR_TBL", "CLASS_ID");
    tablesColumnsMap.put("CCM_VALIDLINK", "VALID_LINK_ID");

    setTablesColumnsMap(tablesColumnsMap);
  }
}