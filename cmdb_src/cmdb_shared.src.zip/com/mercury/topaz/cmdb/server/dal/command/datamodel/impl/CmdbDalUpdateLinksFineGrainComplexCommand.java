package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;

public class CmdbDalUpdateLinksFineGrainComplexCommand extends CmdbDalUpdateLinksComplexCommand
{
  public CmdbDalUpdateLinksFineGrainComplexCommand(CmdbLinks links)
  {
    super(links);
  }

  protected Object perform()
  {
    return fineGrainedPerform();
  }
}