package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.impl.CmdbAttributeFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;

public class CmdbDalRemoveAttributesComplexCommand extends CmdbDalRemoveAttributesOverridesComplexCommand
{
  public CmdbDalRemoveAttributesComplexCommand(BasicContainer attributes, CmdbClass cmdbClass, Long classId)
  {
    super(attributes, cmdbClass, classId);
  }

  public CmdbDalRemoveAttributesComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass, Long classId) {
    super((BasicContainer)null, cmdbClass, classId);

    CmdbModifiableAttributes attributes = CmdbAttributeFactory.createAttributes();
    attributes.add(attribute);
    setAttributes(attributes);
  }

  protected Void perform() throws Exception
  {
    removeAttributesFromAttributesMap();

    super.perform();

    return null;
  }

  private void removeAttributesFromAttributesMap() throws SQLException {
    CmdbDalConnection connection = getConnection();
    CmdbClass cmdbClass = getCmdbClass();

    BasicContainer attributes = getAttributes();
    if ((attributes != null) && (!(attributes.isEmpty()))) {
      StringBuffer condition = new StringBuffer();
      condition.append("ATTRIBUTE_ID").append("=?");

      String sqlString = createDeleteSql("CCM_MAP_ATTR", condition.toString());
      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      ReadOnlyIterator attributesIter = attributes.getIterator();
      while (attributesIter.hasNext()) {
        CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();

        Long attributeId = getAttributeID(attribute.getName(), cmdbClass.getName(), connection);

        preparedStatement.setLong(attributeId);
        preparedStatement.addBatch();
      }
      preparedStatement.executeBatch();
      preparedStatement.close();
    }
  }
}