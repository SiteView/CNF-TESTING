package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.dal.util.table.TableUtils;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import java.util.Iterator;
import java.util.List;

public class CmdbDalUpdateTableAddColumnsComplexCommand extends AbstractTableManagementCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalUpdateTableAddColumnsComplexCommand.class);
  private final TableModifications modifications;

  public CmdbDalUpdateTableAddColumnsComplexCommand(TableDescription currentTable, TableModifications modifications)
  {
    super(currentTable);
    this.modifications = modifications;
  }

  protected Void perform() {
    addColumns();
    return null;
  }

  protected String getCommandName() {
    return "Update table [" + getTableName() + "] with new columns [" + this.modifications.getColumnsToAdd() + "]";
  }

  private void addColumns() {
    for (Iterator i$ = this.modifications.getColumnsToAdd().iterator(); i$.hasNext(); ) { ColumnDescription columnDescription = (ColumnDescription)i$.next();
      addColumn(columnDescription);
    }

    for (i$ = this.modifications.getIndexesToAdd().iterator(); i$.hasNext(); ) { IndexDescription indexDescription = (IndexDescription)i$.next();
      addTableIndex(indexDescription);
    }
  }

  private void addColumn(ColumnDescription columnDescription) {
    String columnName = columnDescription.getName();

    synchronized (getLock()) {
      if (!(TableUtils.isColumnExist(getTableName(), columnName))) {
        if (_logger.isDebugEnabled()) {
          _logger.debug("Add new column [" + columnName + "], into table [" + getTableName() + "]");
        }

        StringBuffer sqlString = new StringBuffer();
        sqlString.append("ALTER TABLE ").append(getTableName());
        sqlString.append(" add ").append(createColumnCreationDataString(columnDescription));

        getConnection().executeAdhocSql(sqlString.toString());

        getConnection().commit();
      }
    }
  }

  private StringBuffer createColumnCreationDataString(ColumnDescription columnDescription)
  {
    StringBuffer columnCreationDataString = new StringBuffer();
    columnCreationDataString.append(columnDescription.getName()).append(" ");
    columnCreationDataString.append(TableUtils.getDBColumnType(columnDescription, getDbType()));
    columnCreationDataString.append(TableUtils.getDBColumnSize(columnDescription, getTableName()));
    if (!(columnDescription.isNullable()))
    {
      String defaultValue = columnDescription.getDefaultValue();
      if (defaultValue == null) {
        defaultValue = "'temp'";
      }

      columnCreationDataString.append(" DEFAULT ").append(defaultValue);
      columnCreationDataString.append(" NOT NULL");
    } else {
      columnCreationDataString.append(" NULL");
    }

    return columnCreationDataString;
  }
}