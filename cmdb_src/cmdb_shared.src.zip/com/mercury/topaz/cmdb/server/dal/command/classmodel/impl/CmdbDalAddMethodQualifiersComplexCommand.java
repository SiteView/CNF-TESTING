package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.CmdbMethodQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.CmdbModifiableMethodQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.impl.CmdbMethodQualifierFactory;
import java.sql.SQLException;

public class CmdbDalAddMethodQualifiersComplexCommand extends CmdbDalAddClassModelQualifiersComplexCommand
{
  private CmdbClass _cmdbClass = null;
  private CmdbMethod _cmdbMethod = null;

  public CmdbDalAddMethodQualifiersComplexCommand(CmdbMethod cmdbMethod, CmdbClass cmdbClass, BasicContainer qualifires, Long entityId)
  {
    super(qualifires, entityId);
    setCmdbClass(cmdbClass);
    setCmdbMethod(cmdbMethod);
  }

  public CmdbDalAddMethodQualifiersComplexCommand(CmdbMethod cmdbMethod, CmdbClass cmdbClass, CmdbMethodQualifier qualifier, Long entityId) {
    super(null, entityId);
    CmdbModifiableMethodQualifiers qualifiers = CmdbMethodQualifierFactory.createMethodQualifiers();
    qualifiers.add(qualifier);
    setQualifires(qualifiers);
    setCmdbClass(cmdbClass);
    setCmdbMethod(cmdbMethod);
  }

  protected String getCommandName() {
    return "Add method qualifiers [" + getQualifires() + "] to cmdb class [" + getCmdbClass().getName() + "], method [" + getCmdbMethod() + "]";
  }

  protected Long getEntityIdFromDB() throws SQLException {
    return getMethodID(getCmdbMethod().getName(), getCmdbClass().getName(), getConnection());
  }

  private CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass;
  }

  private CmdbMethod getCmdbMethod() {
    return this._cmdbMethod;
  }

  private void setCmdbMethod(CmdbMethod cmdbMethod) {
    this._cmdbMethod = cmdbMethod;
  }
}