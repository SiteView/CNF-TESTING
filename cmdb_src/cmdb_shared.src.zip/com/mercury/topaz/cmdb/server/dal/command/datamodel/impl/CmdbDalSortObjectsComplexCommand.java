package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommandAttributeOrder;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommandOrderDirection;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CmdbDalSortObjectsComplexCommand extends CmdbDalGetObjectsLayoutComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalSortObjectsComplexCommand.class);
  CmdbSortCommand _sortCommand;

  public CmdbDalSortObjectsComplexCommand(ModelObjects objects, CmdbSortCommand sortCommand)
  {
    super(objects, PatternLayoutFactory.createElementSimpleLayout());
    setSortCommand(sortCommand);
  }

  protected void validateInput() {
    if ((getModelObjects() == null) || (getModelObjects().size() == 0))
      _logger.info("Can't get objects layout - empty or null model objects. Returns empty list");
  }

  protected Object perform()
  {
    if ((getModelObjects() == null) || (getModelObjects().size() == 0))
    {
      return CmdbObjectIdsFactory.createIdsList(0);
    }
    if (_logger.isDebugEnabled()) {
      _logger.debug("Sort objects for [" + getModelObjects().size() + "] objects, sort by [" + getSortCommand().toString() + "]");
    }

    return getObjectsOrder(getModelObjects());
  }

  private Object getObjectsOrder(ModelObjects objects) {
    ElementSimpleLayout simpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    for (ReadOnlyIterator iter = getSortCommand().getAttributeOrderIterator(); iter.hasNext(); ) {
      CmdbSortCommandAttributeOrder attributeOrder = (CmdbSortCommandAttributeOrder)iter.next();
      String attributeName = attributeOrder.getAttributeName();
      simpleLayout.addKey(attributeName);
    }

    ModelObject object = (ModelObject)objects.getObjectsIterator().next();
    String baseClassName = getBaseCmdbClass(object.getType(), simpleLayout);

    ElementSimpleLayout layout = extractPersistentLayout(simpleLayout, baseClassName);

    Map attributes2ClassesMap = createAttributes2ClassesMap(layout.getKeysIterator(), ClassModelUtil.getCmdbClassByName(baseClassName));

    return getSortedObjects(objects, baseClassName, attributes2ClassesMap);
  }

  protected Object getSortedObjects(ModelObjects objects, String baseClassName, Map attributes2ClassesMap) {
    CmdbDalConnection connection = null;
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet result = null;
    try
    {
      connection = getConnection();

      if (isCmdbIDTempTableMustUsingChunksMechanism(objects.size())) {
        createCmdbIDTempTable(connection, objects);
      }

      List orderByAttributesList = getOrderByAttributesList();
      String sqlString = createLayoutSql(orderByAttributesList, attributes2ClassesMap, baseClassName, objects.size());
      sqlString = sqlString + getSortClause(attributes2ClassesMap);
      preparedStatement = connection.prepareStatement4Select(sqlString);
      addValuesToPrepareStatement(preparedStatement, objects, null);
      result = preparedStatement.executeQuery();

      Object resultObjects = buildCmdbObjectIDs(result);
      Object localObject1 = resultObjects;

      return localObject1;
    }
    catch (Exception e)
    {
    }
    finally
    {
      String errMsg;
      if (result != null)
        result.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private Object buildCmdbObjectIDs(CmdbDalResultSet resultSet)
    throws SQLException
  {
    CmdbObjectIds objectIDs = CmdbObjectIdsFactory.createIdsList(getModelObjects().size());

    while (resultSet.next()) {
      byte[] idAsBytes = resultSet.getBytes(1);
      CmdbObjectID objectID = CmdbObjectID.Factory.restoreObjectID(idAsBytes);
      objectIDs.add(objectID);
    }

    return objectIDs;
  }

  private String getSortClause(Map attributes2ClassesMap) {
    StringBuffer sb = new StringBuffer();
    sb.append(" order by ");
    int i = 0;
    for (ReadOnlyIterator iter = getSortCommand().getAttributeOrderIterator(); iter.hasNext(); ++i) {
      CmdbSortCommandAttributeOrder attributeOrder = (CmdbSortCommandAttributeOrder)iter.next();
      String attributeName = attributeOrder.getAttributeName();
      String className = ((CmdbClass)attributes2ClassesMap.get(attributeName)).getName();

      if (i != 0) {
        sb.append(",");
      }

      sb.append(getTableNameByClassName(className)).append(".").append(DalClassModelUtil.getColumnNameByAttributeName(attributeName));
      sb.append(" ");
      sb.append(attributeOrder.getOrderDirection().getSQLName());
    }
    return sb.toString();
  }

  private List getOrderByAttributesList() {
    List orderByList = new ArrayList();
    for (ReadOnlyIterator iter = getSortCommand().getAttributeOrderIterator(); iter.hasNext(); ) {
      CmdbSortCommandAttributeOrder attributeOrder = (CmdbSortCommandAttributeOrder)iter.next();
      orderByList.add(attributeOrder.getAttributeName());
    }
    return orderByList;
  }

  private CmdbSortCommand getSortCommand()
  {
    return this._sortCommand;
  }

  private void setSortCommand(CmdbSortCommand sortCommand) {
    if (sortCommand == null)
      throw new IllegalArgumentException("sortCommand was null");

    this._sortCommand = sortCommand;
  }
}