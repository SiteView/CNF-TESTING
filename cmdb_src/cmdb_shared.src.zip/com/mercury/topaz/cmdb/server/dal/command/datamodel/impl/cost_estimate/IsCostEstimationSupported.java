package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.cost_estimate;

import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;

public class IsCostEstimationSupported extends CmdbDalAbstractCommand
{
  protected void validateInput()
  {
  }

  protected Object perform()
    throws Exception
  {
    if (getConnectionPool().isUsingMSSqlDB()) {
      return Boolean.valueOf(false);
    }

    return new OracleEstimationSupport().execute();
  }
}