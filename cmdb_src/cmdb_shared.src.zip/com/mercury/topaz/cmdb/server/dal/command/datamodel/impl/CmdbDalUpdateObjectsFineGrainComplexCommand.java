package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;

public class CmdbDalUpdateObjectsFineGrainComplexCommand extends CmdbDalUpdateObjectsComplexCommand
{
  public CmdbDalUpdateObjectsFineGrainComplexCommand(CmdbObjects objects)
  {
    super(objects);
  }

  protected Object perform()
  {
    return fineGrainedPerform();
  }
}