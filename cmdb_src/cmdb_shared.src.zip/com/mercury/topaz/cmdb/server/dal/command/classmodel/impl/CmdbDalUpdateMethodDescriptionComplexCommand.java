package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import java.sql.SQLException;

public class CmdbDalUpdateMethodDescriptionComplexCommand extends CmdbDalUpdateMethodPropertyComplexCommand
{
  public CmdbDalUpdateMethodDescriptionComplexCommand(CmdbMethod method, CmdbClass cmdbClass)
  {
    super(method, cmdbClass);
  }

  protected String getCommandName() {
    return "Update description of method [" + getMethod().getName() + "] in class [" + getCmdbClass().getName() + "] to [" + getMethod().getDescription() + "]";
  }

  protected String getColumnNameToUpdate() {
    return "DESCRIPTION";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long methodId) throws SQLException {
    preparedStatement.setString(getMethod().getDescription());
    preparedStatement.setBoolean(getMethod().isModifiedByUser());
    preparedStatement.setLong(methodId);
  }
}