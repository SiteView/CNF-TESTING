package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import java.sql.SQLException;

public class CmdbDalUpdateAttributeDescriptionComplexCommand extends CmdbDalUpdateAttributePropertyComplexCommand
{
  public CmdbDalUpdateAttributeDescriptionComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass)
  {
    super(attribute, cmdbClass);
  }

  protected String getCommandName() {
    return "Update description of attribute [" + getAttribute().getName() + "] in class [" + getCmdbClass().getName() + "] to [" + ((CmdbAttribute)getAttribute()).getDescription() + "]";
  }

  protected String getColumnNameToUpdate() {
    return "DESCRIPTION";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long attributeId) throws SQLException {
    preparedStatement.setString(((CmdbAttribute)getAttribute()).getDescription());
    preparedStatement.setBoolean(getAttribute().isModifiedByUser());
    preparedStatement.setLong(attributeId);
  }
}