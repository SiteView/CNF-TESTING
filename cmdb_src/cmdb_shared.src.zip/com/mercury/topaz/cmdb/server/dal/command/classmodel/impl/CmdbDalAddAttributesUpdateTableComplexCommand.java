package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;

public class CmdbDalAddAttributesUpdateTableComplexCommand extends CmdbDalAddAttributesComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalAddAttributesUpdateTableComplexCommand.class);

  public CmdbDalAddAttributesUpdateTableComplexCommand(BasicContainer attributes, CmdbClass cmdbClass, Long classId)
  {
    super(attributes, cmdbClass, classId);
  }

  public CmdbDalAddAttributesUpdateTableComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass, Long classId) {
    super(attribute, cmdbClass, classId);
  }

  protected Object perform() throws Exception {
    super.perform();
    updateTableErrorHandling();
    return null;
  }

  private void updateTableErrorHandling()
  {
    getConnection().commit();
    try
    {
      updateTable();
    }
    catch (CmdbDalException e) {
      try {
        CmdbDalCommand removeCommand = CmdbDalClassModelCommandFactory.createRemoveAttributesUpdateTableComplexCommand((CmdbAttributes)getAttributes(), getCmdbClass(), getClassId());
        removeCommand.execute();
      }
      catch (Exception e1) {
        String errMsg1 = "Error Removing attributes [" + getAttributes() + "] of cmdb class [" + getCmdbClass().getName() + "], AFTER FAILED ADD, due to exception: " + e1;
        _logger.error(errMsg1);
      }
      throw e;
    }
  }

  private void updateTable() {
    String tableName = getTableNameByClassName(getCmdbClass().getName());
    TableDescription currentTableDescription = new TableDescription(tableName);
    TableModifications modifications = new TableModifications();

    updateCmdbClassDataLists(currentTableDescription);

    updateNewAttributesDataLists(modifications);

    CmdbDalCommand updateTableCommand = CmdbDalCommandFactory.createUpdateTableAddColumnsComplexCommand(currentTableDescription, modifications);
    updateTableCommand.execute();
  }

  private void updateNewAttributesDataLists(TableModifications modifications)
  {
    updateAttributesDataTableLists((CmdbAttributes)getAttributes(), modifications);

    updateTableIndicesLists((CmdbAttributes)getAttributes(), modifications);
  }

  private void updateCmdbClassDataLists(TableDescription tableDescription)
  {
    updateDefaultColumnsLists(tableDescription, getCmdbClass());

    updateAttributesDataTableLists(getCmdbClass(), tableDescription);

    updateTableIndicesLists(getCmdbClass(), tableDescription);
  }
}