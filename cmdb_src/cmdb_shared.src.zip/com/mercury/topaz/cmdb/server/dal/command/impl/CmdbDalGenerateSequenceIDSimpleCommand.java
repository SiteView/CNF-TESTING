package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.config.idgen.IDGen;
import com.mercury.infra.config.idgen.IDGenManager;
import com.mercury.infra.config.idgen.IDGenPersistencyException;
import com.mercury.infra.config.idgen.IDGenUnexpectedInitValueException;
import com.mercury.infra.config.idgen.IDGenUninitializedIDSequenceException;
import com.mercury.infra.config.idgen.IDGenUnsupportedIDDescriptorException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;

public class CmdbDalGenerateSequenceIDSimpleCommand extends CmdbDalAbstractCommand<Long>
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalGenerateSequenceIDSimpleCommand.class);
  private String _generatorName = null;
  public static String GENERATOR_NAME_SPACE = "CMDB";

  public CmdbDalGenerateSequenceIDSimpleCommand(String generatorName)
  {
    setGeneratorName(generatorName);
  }

  protected void validateInput() {
    if ((getGeneratorName() == null) || (getGeneratorName().length() == 0))
      throw new CmdbDalException("Can't generate sequence for null or empty generator name !!!");
  }

  protected Long perform()
  {
    try {
      return generateId();
    }
    catch (Exception e) {
      _logger.error("Error in generation of sequence id, due to exception: " + e);
      throw new CmdbDalException(e);
    }
  }

  private Long generateId()
    throws IDGenPersistencyException, IDGenUnexpectedInitValueException, IDGenUnsupportedIDDescriptorException, IDGenUninitializedIDSequenceException
  {
    IDGen idGen = IDGenManager.init(GENERATOR_NAME_SPACE, getGeneratorName(), 1000000, false);
    long generatedID = idGen.next();

    if (_logger.isDebugEnabled()) {
      _logger.debug("ID [" + generatedID + "] was generated");
    }

    return Long.valueOf(generatedID);
  }

  private String getGeneratorName() {
    return this._generatorName;
  }

  private void setGeneratorName(String generatorName) {
    this._generatorName = generatorName;
  }
}