package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import java.sql.SQLException;

public class CmdbDalUpdateMethodCommandComplexCommand extends CmdbDalUpdateMethodPropertyComplexCommand
{
  public CmdbDalUpdateMethodCommandComplexCommand(CmdbMethod method, CmdbClass cmdbClass)
  {
    super(method, cmdbClass);
  }

  protected String getCommandName() {
    return "Update command of method [" + getMethod().getName() + "] in class [" + getCmdbClass().getName() + "] to [" + getMethod().getCommand() + "]";
  }

  protected String getColumnNameToUpdate() {
    return "COMMAND";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long methodId) throws SQLException {
    preparedStatement.setString(getMethod().getCommand());
    preparedStatement.setBoolean(getMethod().isModifiedByUser());
    preparedStatement.setLong(methodId);
  }
}