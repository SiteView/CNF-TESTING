package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalDataModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverrides;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;

public class CmdbDalAddAttributeQualifiersUpdateTableComplexCommand extends CmdbDalAddAttributeQualifiersComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalAddAttributeQualifiersUpdateTableComplexCommand.class);

  public CmdbDalAddAttributeQualifiersUpdateTableComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, BasicContainer qualifires, Long entityId)
  {
    super(cmdbAttribute, cmdbClass, qualifires, entityId);
  }

  public CmdbDalAddAttributeQualifiersUpdateTableComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, CmdbAttributeQualifier qualifier, Long entityId) {
    super(cmdbAttribute, cmdbClass, qualifier, entityId);
  }

  protected void validateInput() {
    super.validateInput();
    updateTablePreprocessing();
  }

  protected Object perform() throws Exception {
    super.perform();

    getConnection().commit();

    DalDataModelUtil.handleQualifiersAddition(getCmdbClass(), getCmdbAttribute().getName(), getQualifires());

    updateTableErrorHandling();
    return null;
  }

  private void updateTableErrorHandling() {
    try {
      updateTable();
    } catch (CmdbDalException e) {
      try {
        CmdbDalCommand removeCommand = CmdbDalClassModelCommandFactory.createRemoveAttributeQualifiersUpdateTableComplexCommand(getCmdbAttribute(), getCmdbClass(), (CmdbAttributeQualifiers)getQualifires(), getEntityId());
        removeCommand.execute();
      } catch (Exception e1) {
        String errMsg1 = "Error Removing qualifiers [" + getQualifires() + "] of attribute [" + getCmdbAttribute().getName() + "] of cmdb class [" + getCmdbClass().getName() + "], AFTER FAILED ADD, due to exception: " + e1;
        _logger.error(errMsg1);
      }

      throw e;
    }
  }

  private void updateTablePreprocessing() {
    String tableName = getTableNameByClassName(getCmdbClass().getName());
    TableDescription table = new TableDescription(tableName);
    updateCmdbClassDataLists(table);
    CmdbDalCommand preprocessingCommand = CmdbDalCommandFactory.createCreateTablePreprocessingSimpleCommand(table);
    preprocessingCommand.execute();
  }

  private void updateCmdbClassDataLists(TableDescription tableDescription)
  {
    updateDefaultColumnsLists(tableDescription, getCmdbClass());

    updateAttributesDataTableLists(getCmdbClass(), tableDescription);

    updateTableIndicesLists(getCmdbClass(), tableDescription);
  }

  private void updateTable() {
    String tableName = getTableNameByClassName(getCmdbClass().getName());
    TableDescription currentTable = new TableDescription(tableName);
    TableModifications tableModifications = new TableModifications();

    updateAttributeDataTableLists(tableModifications);

    CmdbDalCommand updateTableCommand = CmdbDalCommandFactory.createUpdateTableUpdateColumnsComplexCommand(currentTable, tableModifications);
    updateTableCommand.execute();
  }

  private void updateAttributeDataTableLists(TableModifications tableModifications)
  {
    if ((!(getCmdbClass().getAllAttributeOverrides().hasAttributeOverride(getCmdbAttribute().getName()))) || (getCmdbAttribute().getQualifiers().containsQualifier(CmdbAttributeQualifierDefs.MIRRORED.getName())))
    {
      if (isIndexedAttribute(getCmdbAttribute())) {
        tableModifications.addIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(getCmdbAttribute().getName())));
      }

      if (isUniqueIndexedAttribute(getCmdbAttribute()))
        tableModifications.addIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(getCmdbAttribute().getName())).unique());
    }
  }
}