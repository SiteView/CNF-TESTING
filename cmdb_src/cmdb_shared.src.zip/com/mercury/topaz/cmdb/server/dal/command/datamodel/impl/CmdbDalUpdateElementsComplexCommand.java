package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.dal.exception.CmdbDalValidationException;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.impl.CmdbDatasFactory;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CmdbDalUpdateElementsComplexCommand<E extends CmdbData<? extends CmdbDataID>> extends CmdbDalDataModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalUpdateElementsComplexCommand.class);
  private CmdbDatas<?, E> _cmdbElements = null;

  public CmdbDalUpdateElementsComplexCommand(CmdbDatas<?, E> elements)
  {
    setCmdbElements(elements);
  }

  protected void validateInput() {
    if ((getCmdbElements() == null) || (getCmdbElements().isEmpty()))
      throw new CmdbDalValidationException("Can't update elements - null or empty elements");
  }

  protected Object perform()
  {
    updateElements(getCmdbElements());
    return null;
  }

  protected CmdbDatas<?, E> getCmdbElements() {
    return this._cmdbElements;
  }

  private void setCmdbElements(CmdbDatas<?, E> cmdbElements) {
    this._cmdbElements = cmdbElements;
  }

  protected void updateElements(List<E> elements, String type, CmdbDalConnection connection, Date currentTime)
    throws SQLException
  {
    if (_logger.isDebugEnabled()) {
      _logger.debug("Update elements from type: " + type);
    }

    CmdbClass cmdbClass = ClassModelUtil.getCmdbClassByName(type);

    String listOfAttributesInsertSql = createInsert2ListOfAttributesTableSql();
    CmdbDalPreparedStatement listOfAttributesPreparedStatement = connection.prepareStatement4Update(listOfAttributesInsertSql);
    String listOfAttributesDeleteSql = createDeleteListOfAttribsSql();
    CmdbDalPreparedStatement listOfAttributesDeletePreparedStatement = connection.prepareStatement4Update(listOfAttributesDeleteSql);

    CmdbAttributes attributes = ClassModelUtil.extractPersistentAttributes(cmdbClass);
    String previousElementSQL = null;
    CmdbDalPreparedStatement preparedStatement = null;

    Iterator i$ = elements.iterator();
    while (true) { CmdbData element;
      Map updatedAttributes;
      byte[] elementIdAsBytes;
      while (true) { while (true) { if (!(i$.hasNext())) break label815; element = (CmdbData)i$.next();
          if (element.hasProperties())
            break;
        }

        updatedAttributes = new HashMap();
        elementIdAsBytes = AbstractCMDBDigest.toBytes((AbstractCMDBDigest)element.getID());

        ReadOnlyIterator propertiesIter = element.getPropertiesIterator();
        while (true) { CmdbProperty property;
          CmdbPropertyValues propertyValues;
          CmdbSimpleType valuesType;
          while (true) { while (true) { while (true) { while (true) { if (!(propertiesIter.hasNext())) break label460;
                  property = (CmdbProperty)propertiesIter.next();

                  if (attributes.hasAttribute(property.getKey()))
                    break;
                }
                if (property.getType() instanceof CmdbSimpleList) break;
                updatedAttributes.put(property.getKey(), attributes.getAttributeByName(property.getKey()));
              }

              listOfAttributesDeletePreparedStatement.setBytes(elementIdAsBytes);
              listOfAttributesDeletePreparedStatement.setString(property.getKey());
              if (!(isUpdateClassModelEnabled()))
                listOfAttributesDeletePreparedStatement.setInt(getCustomerID().getID());

              listOfAttributesDeletePreparedStatement.executeUpdate();

              if (!(property.isValueEmpty()))
                break;
            }
            propertyValues = (CmdbPropertyValues)property.getValue();
            valuesType = ((CmdbSimpleList)property.getType()).getMembersType();

            if (!(propertyValues.isEmpty()))
              break;
          }
          ReadOnlyIterator valuesIter = propertyValues.valuesIterator();
          while (valuesIter.hasNext()) {
            Object value = valuesIter.next();

            listOfAttributesPreparedStatement.setBytes(elementIdAsBytes);
            listOfAttributesPreparedStatement.setString(property.getKey());
            listOfAttributesPreparedStatement.setString(valuesType.stringValue(value));
            if (!(isUpdateClassModelEnabled()))
              listOfAttributesPreparedStatement.setInt(getCustomerID().getID());

            listOfAttributesPreparedStatement.addBatch();
          }
        }

        if (cmdbClass.getName().equals("root")) {
          if (updatedAttributes.containsKey(getCreateTimeAttributeName()))
            label460: updatedAttributes.remove(getCreateTimeAttributeName());

          if (updatedAttributes.containsKey("root_class"))
            updatedAttributes.remove("root_class");

          if (!(updatedAttributes.containsKey(getUpdateTimeAttributeName())))
            updatedAttributes.put(getUpdateTimeAttributeName(), attributes.getAttributeByName(getUpdateTimeAttributeName()));
        }

        if (updatedAttributes.size() > 0)
          break;
      }
      String sqlString = createUpdateSql(cmdbClass.getName(), updatedAttributes.values());
      if ((preparedStatement == null) || (!(sqlString.equals(previousElementSQL)))) {
        if (preparedStatement != null) {
          preparedStatement.executeBatch();
          preparedStatement.close();
        }
        preparedStatement = connection.prepareStatement4Update(sqlString);
        previousElementSQL = sqlString;
      }

      for (Iterator i$ = updatedAttributes.values().iterator(); i$.hasNext(); ) { CmdbAttribute attribute = (CmdbAttribute)i$.next();
        CmdbProperty property = element.getProperty(attribute.getName());

        Object propertyValue = ((property == null) || (property.isValueEmpty())) ? null : property.getValue();

        if (attribute.getName().equals(getUpdateTimeAttributeName()))
          preparedStatement.setDate(currentTime);
        else
          DalTypeUtil.setObject(preparedStatement, propertyValue, attribute.getResolvedType(), attribute.getSizeLimit());
      }

      preparedStatement.setBytes(elementIdAsBytes);
      if (!(isUpdateClassModelEnabled()))
        preparedStatement.setInt(getCustomerID().getID());

      preparedStatement.addBatch();
    }
    if (preparedStatement != null) {
      label815: preparedStatement.executeBatch();
      preparedStatement.close();
    }

    listOfAttributesPreparedStatement.executeBatch();
    listOfAttributesPreparedStatement.close();
    listOfAttributesDeletePreparedStatement.close();
  }

  protected void updateElements(CmdbDatas<?, E> elements) {
    if (_logger.isDebugEnabled())
      _logger.debug("Update [" + elements.size() + "] elements");

    try
    {
      Map elementsFromSameTypeMap = sortElementsToTypes(elements);

      Date currentTime = getCurrentTime();

      for (Iterator i$ = elementsFromSameTypeMap.keySet().iterator(); i$.hasNext(); ) { String type = (String)i$.next();
        List elementsFromSameTypeList = (List)elementsFromSameTypeMap.get(type);
        try
        {
          updateElements(elementsFromSameTypeList, type, getConnection(), currentTime);
        } catch (Exception e) {
          String errMsg = "Error update cmdb elements from type [" + type + "], due to exception: " + e;
          throw new CmdbDalException(errMsg, e);
        }
      }
    }
    catch (Exception e) {
      String errMsg = "Error update cmdb elements [" + elements + "], due to exception: " + e;
      _logger.error(errMsg);
      throw new CmdbDalException("Error update cmdb elements. Check log for details !!!", e);
    }
  }

  protected Object fineGrainedPerform() {
    for (ReadOnlyIterator it = getCmdbElements().getDatasIterator(); it.hasNext(); ) {
      CmdbDatas oneElement = CmdbDatasFactory.create();
      oneElement.add((CmdbData)it.next());
      updateElements(oneElement);
    }
    return null;
  }
}