package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.graph.object.impl.ModelObjectsFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.EmptyCmdbObjects;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CmdbDalGetObjectsLayoutComplexCommand extends CmdbDalGetLayoutComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalGetObjectsLayoutComplexCommand.class);
  private ModelObjects _modelObjects = null;
  private ElementSimpleLayout _layout = null;

  public CmdbDalGetObjectsLayoutComplexCommand(ModelObjects objects, ElementSimpleLayout layout)
  {
    setModelObjects(objects);
    setLayout(layout);
  }

  protected void validateInput()
  {
    if ((getModelObjects() == null) || (getModelObjects().size() == 0))
      _logger.info("Can't get objects layout - empty or null model objects. Returns empty list");

    if ((getLayout() == null) || ((!(getLayout().isAllLayer())) && (!(getLayout().getKeysIterator().hasNext()))))
      _logger.info("Empty or null layout. Returns the same objects");
  }

  protected Object perform()
  {
    if ((getModelObjects() == null) || (getModelObjects().size() == 0))
      return EmptyCmdbObjects.getInstance();

    if ((getLayout() == null) || ((!(getLayout().isAllLayer())) && (!(getLayout().getKeysIterator().hasNext()))))
      return getModelObjects().toCmdbObjects();

    if (_logger.isDebugEnabled())
      _logger.debug("Get objects layout for [" + getModelObjects().size() + "] objects");

    return getObjectsLayout(getModelObjects());
  }

  private CmdbObjects getObjectsLayout(ModelObjects objects) {
    CmdbObjects layoutResult = CmdbObjectFactory.createObjects();

    Map elementsFromSameTypeMap = sortElementsToTypes(objects);

    for (Iterator i$ = elementsFromSameTypeMap.keySet().iterator(); i$.hasNext(); ) { String type = (String)i$.next();
      ModelObjects objectsWithSameTypeContainer = (ModelObjects)elementsFromSameTypeMap.get(type);

      ElementSimpleLayout layout = getLayout();
      if (layout.isAllLayer()) {
        layout = createFullLayout(type);
      }

      CmdbObjects cmdbObjectsWithSameType = getObjectsLayoutForSameType(objectsWithSameTypeContainer, layout);
      mergeCmdbElements(layoutResult, cmdbObjectsWithSameType);
    }
    return layoutResult;
  }

  private Map<String, ModelObjects> sortElementsToTypes(ModelObjects modelObjects) {
    Map elementsFromSameTypeMap = new HashMap();

    for (ReadOnlyIterator objectsIter = modelObjects.getObjectsIterator(); objectsIter.hasNext(); ) {
      ModelObject modelObject = (ModelObject)objectsIter.next();
      addElementToTypeSortedElementsMap(elementsFromSameTypeMap, modelObject);
    }
    return elementsFromSameTypeMap;
  }

  private void addElementToTypeSortedElementsMap(Map<String, ModelObjects> elementsFromSameTypeMap, ModelObject modelObject) {
    ModelObjects elementsWithSameTypeContainer = (ModelObjects)elementsFromSameTypeMap.get(modelObject.getType());
    if (elementsWithSameTypeContainer == null) {
      elementsWithSameTypeContainer = ModelObjectsFactory.create();
      elementsFromSameTypeMap.put(modelObject.getType(), elementsWithSameTypeContainer);
    }
    elementsWithSameTypeContainer.add(modelObject);
  }

  private CmdbObjects getObjectsLayoutForSameType(ModelObjects objects, ElementSimpleLayout requestedLayout)
  {
    ModelObject object = (ModelObject)objects.getObjectsIterator().next();
    String baseClassName = getBaseCmdbClass(object.getType(), requestedLayout);

    ElementSimpleLayout layout = extractPersistentLayout(requestedLayout, baseClassName);

    if (_logger.isDebugEnabled()) {
      StringBuffer logMsg = new StringBuffer();
      logMsg.append("Query for object layout [");
      logMsg.append(layout.toString());
      logMsg.append("] from base class [").append(baseClassName).append("]");
      _logger.debug(logMsg);
    }

    Map attributes2ClassesMap = createAttributes2ClassesMap(layout.getKeysIterator(), ClassModelUtil.getCmdbClassByName(baseClassName));

    List listOfAttribsPropertiesKeys = extractListOfAttribsProperties(layout, attributes2ClassesMap);
    List nonListOfAttribsPropertiesKeys = extractNonListOfAttribsProperties(layout, attributes2ClassesMap);

    if (isCmdbIDTempTableMustUsingChunksMechanism(objects.size())) {
      if (_logger.isDebugEnabled())
        _logger.debug("Decide to use temp table to get layout for [" + objects.size() + "] objects");

      return getChunkLayout(objects, baseClassName, attributes2ClassesMap, listOfAttribsPropertiesKeys, nonListOfAttribsPropertiesKeys);
    }

    int numOfChunks = calcNumOfInChunks(objects.size());
    if (_logger.isDebugEnabled()) {
      _logger.debug("Decide to use [" + numOfChunks + "] in chunks. Chunk size [" + getMaxPossibleSizeForInChunk() + "]");
    }

    if (numOfChunks == 1) {
      return getChunkLayout(objects, baseClassName, attributes2ClassesMap, listOfAttribsPropertiesKeys, nonListOfAttribsPropertiesKeys);
    }

    CmdbObjects resultObjects = CmdbObjectFactory.createObjects();
    for (int chunkNum = 0; chunkNum < numOfChunks; ++chunkNum) {
      ModelObjects chunkModelObjects = getInChunkObjects(objects, chunkNum);
      CmdbObjects chunkObjects = getChunkLayout(chunkModelObjects, baseClassName, attributes2ClassesMap, listOfAttribsPropertiesKeys, nonListOfAttribsPropertiesKeys);

      mergeCmdbElements(resultObjects, chunkObjects);
    }
    return resultObjects;
  }

  private ModelObjects getInChunkObjects(ModelObjects objects, int chunkNum) {
    ModelObjects chunkObjects = ModelObjectsFactory.create();
    int startPoint = getMaxPossibleSizeForInChunk() * chunkNum;
    int endPoint = getMaxPossibleSizeForInChunk() * (chunkNum + 1);
    int currentPoint = 0;

    ReadOnlyIterator objectsIter = objects.getObjectsIterator();
    while ((objectsIter.hasNext()) && (currentPoint < endPoint)) {
      ModelObject object = (ModelObject)objectsIter.next();
      if (currentPoint >= startPoint)
        chunkObjects.add(object);

      ++currentPoint;
    }
    return chunkObjects;
  }

  private CmdbObjects getChunkLayout(ModelObjects objects, String baseClassName, Map attributes2ClassesMap, List listOfAttribsPropertiesKeys, List nonListOfAttribsPropertiesKeys)
  {
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet result = null;
    CmdbDalPreparedStatement listOfAttribsPreparedStatement = null;
    CmdbDalResultSet listOfAttribsResult = null;
    try
    {
      CmdbDalConnection connection = getConnection();

      if (isCmdbIDTempTableMustUsingChunksMechanism(objects.size())) {
        createCmdbIDTempTable(connection, objects);
      }

      String sqlString = createLayoutSql(nonListOfAttribsPropertiesKeys, attributes2ClassesMap, baseClassName, objects.size());
      preparedStatement = connection.prepareStatement4Select(sqlString);
      addValuesToPrepareStatement(preparedStatement, objects, null);
      result = preparedStatement.executeQuery();

      if (listOfAttribsPropertiesKeys.size() > 0) {
        String listOfAttribsSqlString = createListOfAttribsLayoutSql(listOfAttribsPropertiesKeys.size(), objects.size());
        listOfAttribsPreparedStatement = connection.prepareStatement4Select(listOfAttribsSqlString);
        addValuesToPrepareStatement(listOfAttribsPreparedStatement, objects, listOfAttribsPropertiesKeys);
        listOfAttribsResult = listOfAttribsPreparedStatement.executeQuery();
      }

      CmdbObjects resultObjects = buildLayoutCmdbObjects(result, nonListOfAttribsPropertiesKeys, attributes2ClassesMap, listOfAttribsResult, listOfAttribsPropertiesKeys);
      if (resultObjects.size() != objects.size())
        _logger.info("Objects layout expect to return [" + objects.size() + "] objetcs. Instead return [" + resultObjects.size() + "] objects");

      CmdbObjects localCmdbObjects1 = resultObjects;

      return localCmdbObjects1;
    }
    catch (Exception e)
    {
    }
    finally
    {
      String errMsg;
      if (result != null)
        result.close();

      if (listOfAttribsResult != null)
        listOfAttribsResult.close();

      if (preparedStatement != null)
        preparedStatement.close();

      if (listOfAttribsPreparedStatement != null)
        listOfAttribsPreparedStatement.close();
    }
  }

  private CmdbObjects buildLayoutCmdbObjects(CmdbDalResultSet resultSet, List nonListOfAttribsPropertiesKeys, Map attributes2ClassesMap, CmdbDalResultSet listOfAttribsResultSet, List listOfAttribsPropertiesKeys)
    throws SQLException
  {
    Map ids2PropertiesMap = buildIDs2PropertiesMap(listOfAttribsResultSet, attributes2ClassesMap);
    CmdbObjects objects = CmdbObjectFactory.createObjects();

    int index = 0;
    while (resultSet.next()) {
      byte[] idAsBytes = resultSet.getBytes(1);
      CmdbObjectID objectID = CmdbObjectID.Factory.restoreObjectID(idAsBytes);

      ModelObject modelObject = getModelObjects().get(objectID);

      CmdbProperties properties = buildLayoutProperties(nonListOfAttribsPropertiesKeys, resultSet, attributes2ClassesMap);

      if (listOfAttribsPropertiesKeys.size() > 0) {
        CmdbProperties listProperties = (CmdbProperties)ids2PropertiesMap.get(getCmdbDigest(idAsBytes));
        properties = concatProperties(properties, listProperties);

        if ((listProperties == null) || (listOfAttribsPropertiesKeys.size() > listProperties.size()))
          addMissingListProperties(properties, listOfAttribsPropertiesKeys, attributes2ClassesMap);

      }

      CmdbObject object = buildCmdbObject(objectID, modelObject, properties);
      if (object != null) {
        objects.add(object);
      }

      ++index;
      if (index % 5000 == 0)
        getConnectionPool().resetTimeout(getConnection());
    }

    return objects;
  }

  private CmdbObject buildCmdbObject(CmdbObjectID objectID, ModelObject modelObject, CmdbProperties properties) {
    CmdbObject object = null;
    try {
      DataFactory dataFactory = DataFactoryCreator.create(getSynchronizedClassModel());
      object = dataFactory.restoreObject(objectID, modelObject.getType(), properties);
    }
    catch (Exception e) {
      _logger.error("!!! Fail to restore object with id [" + objectID + "], type [" + modelObject.getType() + "] and properties [" + properties + "], due to exception: " + e, e);
    }
    return object;
  }

  protected void addValuesToPrepareStatement(CmdbDalPreparedStatement preparedStatement, ModelObjects objects, List listOfAttribsPropertiesKeys) throws SQLException {
    if (listOfAttribsPropertiesKeys != null) {
      Iterator keysIter = listOfAttribsPropertiesKeys.iterator();
      while (keysIter.hasNext()) {
        String key = (String)keysIter.next();
        preparedStatement.setString(key);
      }
    }

    if (!(isCmdbIDTempTableMustUsingChunksMechanism(objects.size()))) {
      List ids = elementsToIDsAsBytes(objects);
      addIDsToPrepareStatement(preparedStatement, ids);
    }

    if (!(isUpdateClassModelEnabled()))
      preparedStatement.setInt(getCustomerID().getID());
  }

  protected ModelObjects getModelObjects()
  {
    return this._modelObjects;
  }

  private void setModelObjects(ModelObjects modelObjects) {
    this._modelObjects = modelObjects;
  }

  private ElementSimpleLayout getLayout() {
    return this._layout;
  }

  private void setLayout(ElementSimpleLayout layout) {
    this._layout = layout;
  }
}