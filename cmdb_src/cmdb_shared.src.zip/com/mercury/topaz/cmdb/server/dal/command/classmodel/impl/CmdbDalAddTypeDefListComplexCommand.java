package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class CmdbDalAddTypeDefListComplexCommand extends CmdbDalAddTypeDefComplexCommand
{
  public CmdbDalAddTypeDefListComplexCommand(CmdbList cmdbList)
  {
    super(cmdbList);
  }

  protected void updateTypeDefInTables(Long typeDefID) {
    add2TypeDefListTable(getList(), typeDefID);
  }

  private void add2TypeDefListTable(CmdbList typeDefList, Long typeDefID)
  {
    int enumIndex = 0;

    ReadOnlyIterator valuesIter = typeDefList.getValuesIterator();
    while (valuesIter.hasNext()) {
      CmdbListEntry listEntry = (CmdbListEntry)valuesIter.next();

      ++enumIndex;
      CmdbDalCommand addListEntryCommand = CmdbDalClassModelCommandFactory.createAddTypeDefListEntryComplexCommand(listEntry, typeDefList, new Integer(enumIndex), typeDefID);
      addListEntryCommand.execute();
    }
  }

  protected String getValueType() {
    return getList().getType().getName();
  }

  protected String getTypeDefType() {
    return "LIST";
  }

  private CmdbList getList() {
    return ((CmdbList)getTypeDef());
  }
}