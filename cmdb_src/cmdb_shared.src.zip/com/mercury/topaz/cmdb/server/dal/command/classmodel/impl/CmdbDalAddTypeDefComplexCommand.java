package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.sql.SQLException;
import java.util.List;

public abstract class CmdbDalAddTypeDefComplexCommand extends CmdbDalAbstractTypeDefComplexCommand
{
  private CmdbTypeDef _typeDef = null;

  public CmdbDalAddTypeDefComplexCommand(CmdbTypeDef typeDef)
  {
    setTypeDef(typeDef);
  }

  protected void validateInput() {
    if (getTypeDef() == null)
      throw new CmdbDalException("Can't add null type definition");
  }

  protected Object perform()
  {
    addTypeDef(getTypeDef());
    return null; }

  public void addTypeDef(CmdbTypeDef typeDef) {
    CmdbDalConnection connection;
    try {
      connection = getConnection();
      Long typeDefID = generateAndConfirmSequenceID();

      add2TypeDefsTable(connection, typeDef, typeDefID);

      updateTypeDefInTables(typeDefID);
    }
    catch (Exception e) {
      String errMsg = "Error adding type def [" + typeDef.getName() + "], due to exception: " + e;
      throw new CmdbDalException(errMsg, e);
    }
  }

  protected abstract void updateTypeDefInTables(Long paramLong)
    throws SQLException;

  private void add2TypeDefsTable(CmdbDalConnection connection, CmdbTypeDef typeDef, Long typeDefID)
    throws SQLException
  {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createInsertTypeDefsTableSql();
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

    preparedStatement.setLong(typeDefID);
    preparedStatement.setLong(customerID.getID());
    preparedStatement.setString(typeDef.getName());
    preparedStatement.setString(typeDef.getDisplayName());
    preparedStatement.setString(typeDef.getDescription());
    preparedStatement.setString(getTypeDefType());
    preparedStatement.setString(getValueType());
    preparedStatement.setBoolean(typeDef.isCreatedByFactory());
    preparedStatement.setBoolean(typeDef.isModifiedByUser());

    preparedStatement.executeUpdate();
    preparedStatement.close();
  }

  protected abstract String getTypeDefType();

  protected abstract String getValueType();

  private String createInsertTypeDefsTableSql()
  {
    List columnsNames = createTypeDefsTableColumnsNames();

    return createInsertSql("CCM_TYPE_DEFS", columnsNames);
  }

  protected CmdbTypeDef getTypeDef() {
    return this._typeDef;
  }

  private void setTypeDef(CmdbTypeDef typeDef) {
    this._typeDef = typeDef;
  }
}