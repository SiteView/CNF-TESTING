package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrapper;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrappers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreator;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.function.LayoutFunction;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.function.LayoutFunction.Utils;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.function.LayoutFunctionType;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class CmdbDalGetFunctionsLayoutComplexCommand extends CmdbDalGetLayoutComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalGetFunctionsLayoutComplexCommand.class);
  private ModelObjects _groupByObjects;
  private ModelObjects _aggregatedObjects;
  private ModelLinks _modelLinks;
  private LayoutFunctionWrappers _layoutFunctionWrappers;
  private String tempTableName;
  private static final String END1_ID = "end1_id";
  private static final String END2_ID = "end2_id";

  CmdbDalGetFunctionsLayoutComplexCommand(ModelObjects groupByObjects, ModelLinks modelLinks, ModelObjects aggregatedObjects, LayoutFunctionWrappers layoutFunctionWrappers)
  {
    setGroupByObjects(groupByObjects);
    setAggregatedObjects(aggregatedObjects);
    setModelLinks(modelLinks);
    setLayoutFunctionHandlers(layoutFunctionWrappers);
  }

  protected void validateInput()
  {
  }

  protected Object perform()
    throws Exception
  {
    if (getGroupByObjects().size() == 0) {
      return CmdbObjectFactory.createObjects();
    }

    if (getLayoutFunctionWrappers().size() == 0) {
      return getGroupByObjects().toCmdbObjects();
    }

    if (_logger.isDebugEnabled()) {
      String infoMsg = "Get function layout for " + getGroupByObjects().size() + " groupby objects, " + getAggregatedObjects().size() + " aggregated objects, " + getModelLinks().size() + " model links and the functions: [" + getLayoutFunctionWrappers() + "]";

      _logger.debug(infoMsg);
    }

    return getFunctionsLayout();
  }

  private CmdbObjects getFunctionsLayout()
    throws SQLException
  {
    Map resultPropertiesMap = null;

    if ((getModelLinks().size() == 0) || (getAggregatedObjects().size() == 0))
      resultPropertiesMap = new HashMap(0);
    else {
      try
      {
        prepareEnvironment();
        int i = 0;
        for (ReadOnlyIterator iter = getLayoutFunctionWrappers().getIterator(); iter.hasNext(); ++i) {
          LayoutFunctionWrapper layoutFunctionWrapper = (LayoutFunctionWrapper)iter.next();
          layoutFunctionWrapper.setSqlColumnName("column" + i);
          resultPropertiesMap = getFunctionLayout(layoutFunctionWrapper, resultPropertiesMap);
        }
      } finally {
        dropTempLinksTable();
      }

    }

    CmdbObjects cmdbObjects = buildResult(resultPropertiesMap);
    return cmdbObjects;
  }

  private void dropTempLinksTable() {
    getConnection().executeAdhocSql("drop table " + this.tempTableName);
  }

  protected void prepareEnvironment()
    throws SQLException
  {
    truncateCmdbIDTempTable(getConnection());
    this.tempTableName = "temp_link_ids" + hashCode();
    String createSql = "create table " + this.tempTableName + " (end1_id RAW(16) NOT NULL, end2_id RAW(16) NOT NULL)";
    if (DBType.isMsSql(getConnectionPool().getDBType()))
      createSql = "create table " + this.tempTableName + " (end1_id varbinary(16) NOT NULL, end2_id varbinary(16) NOT NULL)";

    getConnection().executeAdhocSql(createSql);
    getConnection().commit();
    String insertSql = "insert into " + this.tempTableName + " (end1_id, end2_id) values (?,?)";
    CmdbDalPreparedStatement statement = getConnection().prepareStatement4Update(insertSql);
    for (Iterator i$ = getModelLinks().getCollection().iterator(); i$.hasNext(); ) { ModelLink link = (ModelLink)i$.next();
      statement.setBytes(extractCmdbID2Bytes(link.getEnd1()));
      statement.setBytes(extractCmdbID2Bytes(link.getEnd2()));
      statement.addBatch();
    }
    statement.executeBatch();
    statement.close();
  }

  private String getAggregateClassName(LayoutFunctionWrapper layoutFunctionWrapper)
  {
    if (LayoutFunctionType.COUNT.equals(layoutFunctionWrapper.getLayoutFunction().getFunctionType())) {
      return "";
    }

    ModelObject object = (ModelObject)getAggregatedObjects().getObjectsIterator().next();
    String referenceClassName = object.getType();

    String attributeName = layoutFunctionWrapper.getLayoutFunction().getAttributeName();
    CmdbClass attributeClass = ClassModelUtil.getAttributeClass(attributeName, referenceClassName);
    return attributeClass.getName();
  }

  private Map<CmdbObjectID, CmdbProperties> getFunctionLayout(LayoutFunctionWrapper layoutFunctionWrapper, Map<CmdbObjectID, CmdbProperties> resultPropertiesMap)
  {
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet result = null;
    try
    {
      CmdbDalConnection connection = getConnection();
      String aggregateClassName = getAggregateClassName(layoutFunctionWrapper);

      String sqlString = createFunctionLayoutSql(aggregateClassName, layoutFunctionWrapper);
      preparedStatement = connection.prepareStatement4Select(sqlString);

      if ((!(isUpdateClassModelEnabled())) && (!(aggregateClassName.equals(""))))
        preparedStatement.setInt(getCustomerID().getID());

      result = preparedStatement.executeQuery();

      resultPropertiesMap = updateIds2PropertiesMap(result, layoutFunctionWrapper, resultPropertiesMap);

      Map localMap = resultPropertiesMap;

      return localMap;
    }
    catch (Exception e)
    {
    }
    finally
    {
      String errMsg;
      if (result != null)
        result.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private Map<CmdbObjectID, CmdbProperties> updateIds2PropertiesMap(CmdbDalResultSet resultSet, LayoutFunctionWrapper layoutFunctionWrapper, Map<CmdbObjectID, CmdbProperties> resultPropertiesMap)
    throws SQLException
  {
    Map ids2PropertiesMap = resultPropertiesMap;
    if (ids2PropertiesMap == null) {
      ids2PropertiesMap = new HashMap(getGroupByObjects().size());
    }

    while (resultSet.next()) {
      byte[] idAsBytes = resultSet.getBytes(1);
      CmdbObjectID objectID = CmdbObjectID.Factory.restoreObjectID(idAsBytes);

      Object propertyValue = DalTypeUtil.getObject(resultSet, layoutFunctionWrapper.getSqlColumnName(), LayoutFunction.Utils.getFunctionPropertyType(layoutFunctionWrapper.getLayoutFunction(), layoutFunctionWrapper.getPattern().getPatternGraph(), layoutFunctionWrapper.getClassModel()));
      CmdbProperty cmdbFunctionProperty = createFunctionProperty(layoutFunctionWrapper, propertyValue);

      CmdbProperties cmdbFunctionProperties = (CmdbProperties)ids2PropertiesMap.get(objectID);
      if (cmdbFunctionProperties == null) {
        cmdbFunctionProperties = CmdbPropertyFactory.createProperties();
        ids2PropertiesMap.put(objectID, cmdbFunctionProperties);
      }

      cmdbFunctionProperties.add(cmdbFunctionProperty);
    }

    return ids2PropertiesMap;
  }

  private CmdbProperty createFunctionProperty(LayoutFunctionWrapper layoutFunctionWrapper, Object propertyValue) {
    CmdbSimpleType functionType = LayoutFunction.Utils.getFunctionPropertyType(layoutFunctionWrapper.getLayoutFunction(), layoutFunctionWrapper.getPattern().getPatternGraph(), layoutFunctionWrapper.getClassModel());
    String functionName = layoutFunctionWrapper.getLayoutFunction().getFunctionName();
    CmdbProperty cmdbProperty = getPropertyCreator().createProperty(functionType, functionName, propertyValue);
    return cmdbProperty;
  }

  private String createFunctionLayoutSql(String aggregateClassName, LayoutFunctionWrapper layoutFunctionWrapper) {
    StringBuffer sql = new StringBuffer();
    String groupByColumnNameInLinkTable = (layoutFunctionWrapper.getLinkDirection() == 1) ? "end1_id" : "end2_id";
    String aggregatedColumnNameInLinkTable = (layoutFunctionWrapper.getLinkDirection() == 1) ? "end2_id" : "end1_id";

    sql.append("SELECT ").append(this.tempTableName).append(".").append(groupByColumnNameInLinkTable);
    sql.append(", ");
    sql.append(getFunctionSelectClause(layoutFunctionWrapper, aggregateClassName));
    sql.append(" as ").append(layoutFunctionWrapper.getSqlColumnName());

    sql.append(" FROM ");

    sql.append(this.tempTableName);

    if (!(aggregateClassName.equals(""))) {
      sql.append(", ");
      sql.append(getTableNameByClassName(aggregateClassName));
    }

    if (!(aggregateClassName.equals(""))) {
      sql.append(" WHERE ");
      sql.append(this.tempTableName).append(".").append(aggregatedColumnNameInLinkTable).append("=");
      sql.append(getTableNameByClassName(aggregateClassName)).append(".").append("CMDB_ID");

      if (!(isUpdateClassModelEnabled())) {
        sql.append(" AND ");
        sql.append(getTableNameByClassName(aggregateClassName)).append(".").append("CUSTOMER_ID").append("=?");
      }
    }
    sql.append(" GROUP BY ").append(this.tempTableName).append(".").append(groupByColumnNameInLinkTable);

    return sql.toString();
  }

  private String getFunctionSelectClause(LayoutFunctionWrapper layoutFunctionWrapper, String className)
  {
    if (LayoutFunctionType.COUNT.equals(layoutFunctionWrapper.getLayoutFunction().getFunctionType()))
      return "count(*)";

    StringBuffer sb = new StringBuffer();
    sb.append(getSQLFunction(layoutFunctionWrapper)).append("(").append(getTableNameByClassName(className)).append(".").append(DalClassModelUtil.getColumnNameByAttributeName(layoutFunctionWrapper.getLayoutFunction().getAttributeName())).append(")");

    return sb.toString();
  }

  private String getSQLFunction(LayoutFunctionWrapper layoutFunctionWrapper)
  {
    LayoutFunctionType functionType = layoutFunctionWrapper.getLayoutFunction().getFunctionType();
    if (LayoutFunctionType.Average.equals(functionType)) return "avg";
    if (LayoutFunctionType.MAX.equals(functionType)) return "max";
    if (LayoutFunctionType.MIN.equals(functionType)) return "min";
    if (LayoutFunctionType.SUM.equals(functionType)) return "sum";
    if (LayoutFunctionType.COUNT.equals(functionType)) return "count";
    throw new CmdbDalException("Not recognised function type: " + layoutFunctionWrapper.getLayoutFunction());
  }

  private CmdbObjects buildResult(Map<CmdbObjectID, CmdbProperties> resultPropertiesMap)
  {
    CmdbObjects cmdbObjects = CmdbObjectFactory.createObjects();
    for (ReadOnlyIterator iter = getGroupByObjects().getObjectsIterator(); iter.hasNext(); ) {
      CmdbObject cmdbObject;
      ModelObject modelObject = (ModelObject)iter.next();
      CmdbObjectID objectID = modelObject.getID();
      CmdbProperties properties = (CmdbProperties)resultPropertiesMap.get(objectID);
      if (properties == null)
      {
        cmdbObject = createEmptyFunctionProperties(modelObject);
        cmdbObjects.add(cmdbObject);
      } else {
        cmdbObject = CmdbObjectFactory.createObject(objectID, modelObject.getType(), properties);
        cmdbObjects.add(cmdbObject);
      }
    }
    return cmdbObjects;
  }

  private CmdbObject createEmptyFunctionProperties(ModelObject modelObject)
  {
    CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
    for (ReadOnlyIterator iter = getLayoutFunctionWrappers().getIterator(); iter.hasNext(); ) {
      LayoutFunctionWrapper wrapper = (LayoutFunctionWrapper)iter.next();
      cmdbProperties.add(CmdbPropertyFactory.createEmptyProperty(wrapper.getLayoutFunction().getFunctionName(), LayoutFunction.Utils.getFunctionPropertyType(wrapper.getLayoutFunction(), wrapper.getPattern().getPatternGraph(), wrapper.getClassModel())));
    }

    CmdbObject cmdbObject = CmdbObjectFactory.createObject(modelObject.getID(), modelObject.getType(), cmdbProperties);
    return cmdbObject;
  }

  private ModelObjects getGroupByObjects()
  {
    return this._groupByObjects;
  }

  private void setGroupByObjects(ModelObjects groupByObjects) {
    if (groupByObjects == null)
      throw new IllegalArgumentException("groupByObjects was null");

    if (groupByObjects.size() == 0)
      throw new IllegalArgumentException("groupByObjects was empty");

    this._groupByObjects = groupByObjects;
  }

  private ModelObjects getAggregatedObjects() {
    return this._aggregatedObjects;
  }

  private void setAggregatedObjects(ModelObjects aggregatedObjects) {
    if (aggregatedObjects == null)
      throw new IllegalArgumentException("aggregatedObjects was null");

    this._aggregatedObjects = aggregatedObjects;
  }

  private ModelLinks getModelLinks() {
    return this._modelLinks;
  }

  private void setModelLinks(ModelLinks modelLinks) {
    if (modelLinks == null)
      throw new IllegalArgumentException("modelLinks was null");

    this._modelLinks = modelLinks;
  }

  private LayoutFunctionWrappers getLayoutFunctionWrappers() {
    return this._layoutFunctionWrappers;
  }

  private void setLayoutFunctionHandlers(LayoutFunctionWrappers layoutFunctionWrappers) {
    if (layoutFunctionWrappers == null)
      throw new IllegalArgumentException("layoutFunctionWrappers was null");

    this._layoutFunctionWrappers = layoutFunctionWrappers;
  }
}