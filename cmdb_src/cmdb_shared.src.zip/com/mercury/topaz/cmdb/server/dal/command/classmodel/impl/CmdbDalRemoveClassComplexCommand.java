package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;

public class CmdbDalRemoveClassComplexCommand extends CmdbDalAbstractRemoveClassComplexCommand
{
  private Long _classID;

  public CmdbDalRemoveClassComplexCommand(CmdbClass cmdbClass)
  {
    super(cmdbClass);
  }

  protected Object perform() {
    removeClass(getCmdbClass());

    return null;
  }

  private void removeClass(CmdbClass cmdbClass) {
    CmdbDalConnection connection = getConnection();
    try
    {
      setClassID(getClassID(cmdbClass.getName(), connection));

      removeAttributes(cmdbClass, getClassID());
      removeMethods(cmdbClass, getClassID());
      removeClassQualifiers(cmdbClass, getClassID());

      removeClass(getClassID());

      connection.commit();
    }
    catch (Exception e) {
      String errMsg = "Error remove cmdb class [" + cmdbClass.getName() + "], due to exception: " + e;
      if (connection != null) {
        connection.rollback();
      }

      throw new CmdbDalException(errMsg, e);
    }
  }

  private void removeClassQualifiers(CmdbClass cmdbClass, Long classID) {
    CmdbDalCommand removeClassQualifiersCommand = CmdbDalClassModelCommandFactory.createRemoveClassQualifiersComplexCommand(cmdbClass, cmdbClass.getClassQualifiers(), classID);
    removeClassQualifiersCommand.execute();
  }

  private void removeMethods(CmdbClass cmdbClass, Long classID) {
    CmdbDalCommand removeMethodsCommand = CmdbDalClassModelCommandFactory.createRemoveMethodsComplexCommand(cmdbClass.getClassMethods(), cmdbClass, classID);
    removeMethodsCommand.execute();
  }

  private void removeAttributes(CmdbClass cmdbClass, Long classID) {
    CmdbDalCommand removeAttributesCommand = CmdbDalClassModelCommandFactory.createRemoveAttributesComplexCommand(cmdbClass.getClassAttributes(), cmdbClass, classID);
    removeAttributesCommand.execute();
    CmdbDalCommand removeAttributesOverrridesCommand = CmdbDalClassModelCommandFactory.createRemoveAttributesOverridesComplexCommand(cmdbClass.getAllAttributeOverrides(), cmdbClass, classID);
    removeAttributesOverrridesCommand.execute();
  }

  private void removeClass(Long classID) throws SQLException
  {
    deleteCmdbClassMetaData("CCM_CLASSES", classID);
  }

  protected void deleteCmdbClassMetaData(String tableName, Long classID) throws SQLException {
    StringBuffer condition = new StringBuffer();
    condition.append("CLASS_ID").append("=?");

    String sqlString = createDeleteSql(tableName, condition.toString());
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Update(sqlString);
    preparedStatement.setLong(classID);
    preparedStatement.executeUpdate();
    preparedStatement.close();
  }

  protected Long getClassID() {
    return this._classID;
  }

  private void setClassID(Long classID) {
    this._classID = classID;
  }
}