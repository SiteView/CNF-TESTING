package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.DBColumnType;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.table.TableUtils;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import java.util.List;
import java.util.Map;

public abstract class AbstractTableManagementCommand extends CmdbDalAbstractCommand<Void>
{
  private static Log _logger = LogFactory.getEasyLog(AbstractTableManagementCommand.class);
  public static final String DISABLE_PARTITION_CREATION = "DISABLE_PARTITION_CREATION";
  private final TableDescription tableDescription;

  public AbstractTableManagementCommand(TableDescription tableDescription)
  {
    this.tableDescription = tableDescription;
  }

  protected String getTableName() {
    return this.tableDescription.getTableName();
  }

  protected void validateInput() {
    CmdbDalCommand preprocessingCommand = CmdbDalCommandFactory.createCreateTablePreprocessingSimpleCommand(getTableDescription());
    preprocessingCommand.execute();
  }

  protected void commitChanges()
  {
    getConnection().commit();
  }

  protected void addTableIndex(IndexDescription indexDescription) {
    addTableIndex(indexDescription, buildIndexName(getTableName(), (String)indexDescription.getColumnNames().get(0)));
  }

  protected void addTableIndex(IndexDescription indexDescription, String indexName) {
    String columnName = (String)indexDescription.getColumnNames().get(0);
    if (!(columnCanBeIndexed(columnName))) {
      _logger.warn("Cannot create an index on column " + columnName + " of table " + getTableName() + " because its size exceeds the maximum of " + 900);

      return;
    }

    synchronized (CmdbDalCreateTableComplexCommand.getLock()) {
      if (!(isIndexExist(getTableName(), columnName))) {
        if (_logger.isDebugEnabled()) {
          _logger.debug("Add index on column [" + columnName + "] of table [" + getTableName() + "]");
        }

        StringBuffer sqlString = new StringBuffer();

        sqlString.append("create ");
        if ((indexDescription.isClustered()) && (isMsSql()))
          sqlString.append("clustered ");
        else if (indexDescription.isUnique())
          sqlString.append("unique ");

        sqlString.append("index ");
        sqlString.append(indexName);

        sqlString.append(" on ").append(getTableName());

        sqlString.append("(").append(columnName);
        if ((indexDescription.isUnique()) && (!(isUpdateClassModelEnabled())))
          sqlString.append(", ").append("CUSTOMER_ID");

        sqlString.append(")");
        sqlString.append(getIndexTableSpaceClause());
        sqlString.append(getFillFactorClause());

        if (!(isUpdateClassModelEnabled())) {
          sqlString.append(getLocalIndexClause());
        }

        getConnection().executeAdhocSql(sqlString.toString());

        commitChanges();
      }
    }
  }

  private boolean columnCanBeIndexed(String columnName) {
    ColumnDescription columnDescription = (ColumnDescription)this.tableDescription.getColumns().get(columnName);
    if (columnDescription != null) {
      DBColumnType columnType = columnDescription.getType();

      if (columnType != DBColumnType.VARCHAR) {
        return true;
      }

    }

    Integer columnSize = null;
    if (columnDescription != null) {
      columnSize = columnDescription.getSize();
    }

    if (columnSize == null) {
      CmdbDalCommand getColumnSize = CmdbDalCommandFactory.createGetColumnSizeSimpleCommand(getTableName(), columnName);
      CmdbDalCommandResult result = getColumnSize.execute();
      columnSize = (Integer)result.getResult();
    }
    return (columnSize.intValue() <= 900);
  }

  protected boolean isIndexExist(String tableName, String columnName) {
    CmdbDalCommand checkIndexExistenceCommand = CmdbDalCommandFactory.createCheckIndexExistenceByColumnSimpleCommand(tableName, columnName);
    CmdbDalCommandResult result = checkIndexExistenceCommand.execute();
    return ((Boolean)result.getResult()).booleanValue();
  }

  protected String buildConstraintName(String tableName, String columnName, String constraintType)
  {
    String name = constraintType + tableName + "_" + columnName;

    name = DalClassModelUtil.fixLongName(name);

    return name;
  }

  protected String buildIndexName(String tableName, String columnName) {
    return buildConstraintName(tableName, columnName, "IX1_");
  }

  protected String getIndexTableSpaceClause() {
    if (isOracle())
      return " tablespace " + getConnectionPool().getIndexTableSpaceName();
    if (isMsSql())
      return "";

    throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
  }

  protected String getFillFactorClause()
  {
    if (isOracle())
      return "";
    if (isMsSql())
      return " WITH FILLFACTOR=80";

    throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
  }

  protected String getLocalIndexClause()
  {
    if (isPartitioningDisabled())
      return "";

    if (isOracle())
      return " LOCAL";
    if (isMsSql())
      return "";

    throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
  }

  /**
   * @deprecated
   */
  protected boolean isPartitioningDisabled()
  {
    Boolean disableFlag = (Boolean)getConnection().getProperty("DISABLE_PARTITION_CREATION");

    return Boolean.TRUE.equals(disableFlag);
  }

  protected String getDBColumnSize(ColumnDescription columnDescription) {
    return TableUtils.getDBColumnSize(columnDescription, getTableName());
  }

  protected String getDBColumnType(ColumnDescription columnDescription) {
    return TableUtils.getDBColumnType(columnDescription, getDbType());
  }

  protected TableDescription getTableDescription() {
    return this.tableDescription;
  }
}