package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalDataModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverrides;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;

public class CmdbDalRemoveAttributeQualifiersUpdateTableComplexCommand extends CmdbDalRemoveAttributeQualifiersComplexCommand
{
  public CmdbDalRemoveAttributeQualifiersUpdateTableComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, BasicContainer qualifires, Long entityId)
  {
    super(cmdbAttribute, cmdbClass, qualifires, entityId);
  }

  public CmdbDalRemoveAttributeQualifiersUpdateTableComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, CmdbAttributeQualifier qualifier, Long entityId) {
    super(cmdbAttribute, cmdbClass, qualifier, entityId);
  }

  protected Void perform() throws Exception {
    super.perform();

    getConnection().commit();

    updateTable();

    DalDataModelUtil.handleQualifiersRemoval(getCmdbClass(), getCmdbAttribute().getName(), getQualifires());

    return null;
  }

  private void updateTable() {
    String tableName = getTableNameByClassName(getCmdbClass().getName());
    TableDescription currentTable = new TableDescription(tableName);
    TableModifications modifications = new TableModifications();

    updateAttributeDataTableLists(modifications);

    CmdbDalCommand updateTableCommand = CmdbDalCommandFactory.createUpdateTableUpdateColumnsComplexCommand(currentTable, modifications);
    updateTableCommand.execute();
  }

  private void updateAttributeDataTableLists(TableModifications modifications) {
    if ((!(getCmdbClass().getAllAttributeOverrides().hasAttributeOverride(getCmdbAttribute().getName()))) || (getCmdbAttribute().getQualifiers().containsQualifier(CmdbAttributeQualifierDefs.MIRRORED.getName())))
    {
      if (!(isIndexedAttribute(getCmdbAttribute()))) {
        modifications.removeIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(getCmdbAttribute().getName())));
      }

      if (!(isUniqueIndexedAttribute(getCmdbAttribute())))
        modifications.removeIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(getCmdbAttribute().getName())).unique());
    }
  }
}