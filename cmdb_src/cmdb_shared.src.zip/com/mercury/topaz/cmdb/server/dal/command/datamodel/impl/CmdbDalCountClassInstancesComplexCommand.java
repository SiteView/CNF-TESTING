package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class CmdbDalCountClassInstancesComplexCommand extends CmdbDalDataModelComplexCommand
{
  private String _fullQualifedClassName = null;
  private boolean _includeDerived;

  public CmdbDalCountClassInstancesComplexCommand(String fullQualifedClassName, boolean includeDerived)
  {
    setFullQualifedClassName(fullQualifedClassName);
    setIncludeDerived(includeDerived);
  }

  protected void prepare() throws Exception {
    setUseDirtyRead();
  }

  protected void validateInput() {
    if ((getFullQualifedClassName() == null) || (getFullQualifedClassName().length() == 0))
      throw new CmdbDalException("Can't count instances for null or empty length class name !!!");
  }

  protected Object perform() throws Exception
  {
    StringBuffer sqlString = new StringBuffer();
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;

    CmdbClass cmdbClass = getSynchronizedClassModel().getClass(getFullQualifedClassName());
    if (cmdbClass == null) {
      return Integer.valueOf(0);
    }

    if (getSynchronizedClassModel().isSimpleCalculatedLink(getFullQualifedClassName())) {
      return Integer.valueOf(0);
    }

    try
    {
      if (isIncludeDerived()) {
        sqlString.append("SELECT COUNT(*) FROM ").append(getTableNameByClassName(getFullQualifedClassName()));
        if (!(isUpdateClassModelEnabled()))
          sqlString.append(" WHERE ").append("CUSTOMER_ID").append("=?");
      }
      else
      {
        sqlString.append("SELECT COUNT(*) FROM ").append(getTableNameByClassName("root")).append(" WHERE ").append("CLASS").append("=?");

        if (!(isUpdateClassModelEnabled()))
          sqlString.append(" AND ").append("CUSTOMER_ID").append("=?");

      }

      preparedStatement = getConnection().prepareStatement4Select(sqlString.toString());
      if (!(isIncludeDerived()))
        preparedStatement.setString(getFullQualifedClassName());

      if (!(isUpdateClassModelEnabled()))
        preparedStatement.setInt(getCustomerID().getID());

      resultSet = preparedStatement.executeQuery();

      if (resultSet.next()) {
        localInteger = resultSet.getInt(1);

        return localInteger;
      }
      Integer localInteger = Integer.valueOf(0);

      return localInteger;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  protected String getCommandName()
  {
    return "Count instances for cmdb class " + getFullQualifedClassName();
  }

  private String getFullQualifedClassName() {
    return this._fullQualifedClassName;
  }

  private void setFullQualifedClassName(String fullQualifedClassName) {
    this._fullQualifedClassName = fullQualifedClassName;
  }

  private boolean isIncludeDerived() {
    return this._includeDerived;
  }

  private void setIncludeDerived(boolean includeDerived) {
    this._includeDerived = includeDerived;
  }
}