package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.model.graph.link.impl.ModelLinkFactory;
import com.mercury.topaz.cmdb.server.model.graph.object.impl.ModelObjectFactory;
import com.mercury.topaz.cmdb.shared.classmodel.impl.CmdbClassModelUtil;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.ModelLinksFactory;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.link.id.impl.CmdbLinkIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class CmdbDalGetTriplesComplexCommand extends CmdbDalConditionComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalGetTriplesComplexCommand.class);
  private ElementCondition _end2Condition = null;
  private String _end2ClassNameSuffix = null;
  private LinkCondition _linkCondition = null;
  private String _linkClassNameSuffix = null;

  public CmdbDalGetTriplesComplexCommand(ElementCondition end1Condition, LinkCondition linkCondition, ElementCondition end2Condition)
  {
    super(end1Condition);
    setEnd2Condition(optimizeCondition(end2Condition));
    setLinkCondition(linkCondition);
    setEnd1ClassNameSuffix("1");
    setEnd2ClassNameSuffix("2");
    setLinkClassNameSuffix("3");
  }

  protected void validateInput() {
    if ((getEnd1Condition() == null) || (getEnd1Condition().getClassCondition() == null) || (getEnd2Condition() == null) || (getEnd2Condition().getClassCondition() == null) || (getLinkCondition() == null) || (getLinkCondition().getClassCondition() == null))
    {
      _logger.error("Error in get-triples command - end1, end2 or link or class condition is null. Return empty links list !!!");
    }
  }

  protected Object perform() throws Exception {
    if ((getEnd1Condition() == null) || (getEnd1Condition().getClassCondition() == null) || (getEnd2Condition() == null) || (getEnd2Condition().getClassCondition() == null) || (getLinkCondition() == null) || (getLinkCondition().getClassCondition() == null))
    {
      return new ArrayList();
    }

    int sizeofEnd1 = 0;
    if ((getEnd1Condition().getIdsCondition() != null) && (!(isEmptyContainer(getEnd1Condition().getIdsCondition().getIds()))))
    {
      sizeofEnd1 = getEnd1Condition().getIdsCondition().getIds().size();
    }

    int sizeofEnd2 = 0;
    if ((getEnd2Condition().getIdsCondition() != null) && (!(isEmptyContainer(getEnd2Condition().getIdsCondition().getIds()))))
    {
      sizeofEnd2 = getEnd2Condition().getIdsCondition().getIds().size();
    }

    int sizeofLink = 0;
    if ((getLinkCondition().getIdsCondition() != null) && (!(isEmptyContainer(getLinkCondition().getIdsCondition().getLinkIds()))))
    {
      sizeofLink = getLinkCondition().getIdsCondition().getLinkIds().size();
    }

    int numOfInputObjects = sizeofEnd1 + sizeofEnd2 + sizeofLink;
    if (numOfInputObjects > getMemoryInsteadTempTableHighThreshold()) {
      String errMsg = "Can't handle get-triples query due to temp table limitation. Number of input objects [" + numOfInputObjects + "]. Maximum allowed [" + getMemoryInsteadTempTableHighThreshold() + "] !!!";

      throw new CmdbDalException(errMsg);
    }
    return performGetTriplesQuery();
  }

  private Object performGetTriplesQuery() throws Exception
  {
    if (_logger.isDebugEnabled()) {
      _logger.debug("Performing get-triples query with end1 condition [" + getEnd1Condition() + "], " + "link condition [" + getLinkCondition() + "], ned2 condition [" + getEnd2Condition() + "]");
    }

    CmdbDalConnection connection = getConnection();
    CmdbDalResultSet resultSet = null;
    CmdbDalPreparedStatement preparedStatement = null;
    try
    {
      List bindVariables = new ArrayList();
      List bindVariablesTypes = new ArrayList();

      if (hasConditionIDs())
        truncateCmdbIDTempTable(connection);

      String sqlString = createQuerySql(connection, bindVariables, bindVariablesTypes);

      preparedStatement = connection.statement4Select(sqlString);
      for (int i = 0; i < bindVariables.size(); ++i) {
        DalTypeUtil.setObject(preparedStatement, bindVariables.get(i), (CmdbType)bindVariablesTypes.get(i));
      }

      resultSet = preparedStatement.executeQuery();

      i = getResult(resultSet);

      return i;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  protected String createQuerySql(CmdbDalConnection connection, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) throws SQLException
  {
    Set participatedClasses = new HashSet();
    StringBuffer queryStr = new StringBuffer();
    StringBuffer selectSql = new StringBuffer();

    addIDsCondition(connection, queryStr, bindVariables, bindVariablesTypes, participatedClasses);
    addClassCondition(queryStr, bindVariables, bindVariablesTypes, participatedClasses);
    addPropertiesCondition(queryStr, bindVariables, bindVariablesTypes, participatedClasses);

    addSelectSql(selectSql, participatedClasses);
    addFromSql(selectSql, participatedClasses);

    selectSql.append(" WHERE ");
    addJoinConditions(selectSql, participatedClasses, bindVariables, bindVariablesTypes);

    queryStr.insert(0, selectSql);

    return queryStr.toString();
  }

  protected void addJoinConditions(StringBuffer selectSql, Set<String> participatedClasses, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) {
    Collection end1Classes = new ArrayList();
    Collection linkClasses = new ArrayList();
    Collection end2Classes = new ArrayList();

    Iterator classesIter = participatedClasses.iterator();
    int end1ClassNameLength = getEnd1ClassNameSuffix().length();
    int linkClassNameLength = getLinkClassNameSuffix().length();

    while (classesIter.hasNext()) {
      String dummyClassName = (String)classesIter.next();
      if (extractClassNameSuffix(dummyClassName, end1ClassNameLength).equals(getEnd1ClassNameSuffix()))
        end1Classes.add(dummyClassName);
      else if (extractClassNameSuffix(dummyClassName, linkClassNameLength).equals(getLinkClassNameSuffix()))
        linkClasses.add(dummyClassName);
      else
        end2Classes.add(dummyClassName);

    }

    String end1ConditionClassName = getEnd1Condition().getClassCondition().getClassName();
    String end2ConditionClassName = getEnd2Condition().getClassCondition().getClassName();
    String dummyClassNameEnd1 = getDummyClassName(end1ConditionClassName, getEnd1ClassNameSuffix());
    String dummyClassNameEnd2 = getDummyClassName(end2ConditionClassName, getEnd2ClassNameSuffix());

    addLinkJoinSql(selectSql, dummyClassNameEnd1, dummyClassNameEnd2);
    addPairsJoinSql(selectSql, end1Classes, bindVariables, bindVariablesTypes);
    addPairsJoinSql(selectSql, linkClasses, bindVariables, bindVariablesTypes);
    addPairsJoinSql(selectSql, end2Classes, bindVariables, bindVariablesTypes);
  }

  protected void addSelectSql(StringBuffer selectSql, Set<String> participatedClasses)
  {
    String end1ConditionClassName = getEnd1Condition().getClassCondition().getClassName();
    String end2ConditionClassName = getEnd2Condition().getClassCondition().getClassName();

    String dummyClassNameLink = getDummyClassName("link", getLinkClassNameSuffix());
    String dummyRootEnd1ClassName = getDummyClassName("root", getEnd1ClassNameSuffix());
    String dummyRootLinkClassName = getDummyClassName("link", getLinkClassNameSuffix());
    String dummyRootEnd2ClassName = getDummyClassName("root", getEnd2ClassNameSuffix());

    selectSql.append("SELECT ");
    selectSql.append(dummyClassNameLink).append(".");
    selectSql.append("END1_ID");
    selectSql.append(", ");
    selectSql.append(dummyRootEnd1ClassName).append(".");
    selectSql.append("CLASS");
    selectSql.append(", ");
    selectSql.append(dummyClassNameLink).append(".");
    selectSql.append("CMDB_ID");
    selectSql.append(", ");
    selectSql.append(dummyRootLinkClassName).append(".");
    selectSql.append("CLASS");
    selectSql.append(", ");
    selectSql.append(dummyClassNameLink).append(".");
    selectSql.append("END2_ID");
    selectSql.append(", ");
    selectSql.append(dummyRootEnd2ClassName).append(".");
    selectSql.append("CLASS");

    participatedClasses.add(getDummyClassName(end1ConditionClassName, getEnd1ClassNameSuffix()));
    participatedClasses.add(getDummyClassName("link", getLinkClassNameSuffix()));
    participatedClasses.add(getDummyClassName(end2ConditionClassName, getEnd2ClassNameSuffix()));
    participatedClasses.add(dummyRootEnd1ClassName);
    participatedClasses.add(dummyRootLinkClassName);
    participatedClasses.add(dummyRootEnd2ClassName);
  }

  protected void addLinkJoinSql(StringBuffer selectSql, String dummyClassNameEnd1, String dummyClassNameEnd2) {
    String linkDummyClassName = getDummyClassName("link", getLinkClassNameSuffix());

    selectSql.append(dummyClassNameEnd1).append(".").append("CMDB_ID");
    selectSql.append("=");
    selectSql.append(linkDummyClassName).append(".").append("END1_ID");
    selectSql.append(" AND ");
    selectSql.append(dummyClassNameEnd2).append(".").append("CMDB_ID");
    selectSql.append("=");
    selectSql.append(linkDummyClassName).append(".").append("END2_ID");
  }

  protected void addPropertiesCondition(StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses) throws SQLException
  {
    super.addPropertiesCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses);
    addPropertiesCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses, getLinkClassNameSuffix(), getLinkCondition());
    addPropertiesCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses, getEnd2ClassNameSuffix(), getEnd2Condition());
  }

  protected void addClassCondition(StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses) throws SQLException {
    super.addClassCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses);

    addLinkClassCondition(sqlString, bindVariables, bindVariablesTypes);

    addClassCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses, getEnd2ClassNameSuffix(), getEnd2Condition(), null);
  }

  protected void addLinkClassCondition(StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) throws SQLException
  {
    ElementClassCondition classCondition = getLinkCondition().getClassCondition();
    String className = classCondition.getClassName();
    String alias = getDummyClassName("link", getLinkClassNameSuffix());

    if (!(classCondition.hasQualifiersLimitations())) {
      if (classCondition.isDerived()) {
        sqlString.append(" AND ");
        Collection descendents = CmdbClassModelUtil.getAllDescendentClassesNames(getSynchronizedClassModel(), className);
        Collection itselfAndAllDescendents = new ArrayList(descendents.size() + 1);
        itselfAndAllDescendents.add(className);
        itselfAndAllDescendents.addAll(descendents);
        addInClause(sqlString, "CLASS", itselfAndAllDescendents.iterator(), itselfAndAllDescendents.size(), CmdbSimpleTypes.CmdbString, alias, bindVariables, bindVariablesTypes, null);
      }
      else {
        sqlString.append(" AND ").append(alias).append(".").append("CLASS").append("=? ");
        bindVariables.add(className);
        bindVariablesTypes.add(CmdbSimpleTypes.CmdbString);
      }
    } else {
      sqlString.append(" AND ");
      ReadOnlyIterator classesIter = classCondition.getClassNames(getSynchronizedClassModel());
      List classesList = getClassesList(classesIter);
      addInClause(sqlString, "CLASS", classesList.iterator(), classesList.size(), CmdbSimpleTypes.CmdbString, alias, bindVariables, bindVariablesTypes, null);
    }
  }

  protected void addIDsCondition(CmdbDalConnection connection, StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses)
    throws SQLException
  {
    if (!(hasConditionIDs())) {
      return;
    }

    CmdbIDsCollection cmdbIDsCollection = extractConditionIDs(getEnd1Condition());
    addIDsCondition(cmdbIDsCollection, connection, sqlString, bindVariables, bindVariablesTypes, getEnd1Condition(), getEnd1ClassNameSuffix(), participatedClasses);

    cmdbIDsCollection = extractConditionIDs(getLinkCondition());
    addIDsCondition(cmdbIDsCollection, connection, sqlString, bindVariables, bindVariablesTypes, getLinkCondition(), getLinkClassNameSuffix(), participatedClasses);

    cmdbIDsCollection = extractConditionIDs(getEnd2Condition());
    addIDsCondition(cmdbIDsCollection, connection, sqlString, bindVariables, bindVariablesTypes, getEnd2Condition(), getEnd2ClassNameSuffix(), participatedClasses);
  }

  protected void addIDsCondition(CmdbIDsCollection<? extends CmdbDataID> conditionIDs, CmdbDalConnection connection, StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, ElementCondition condition, String classNameSuffix, Set<String> participatedClasses) throws SQLException
  {
    if (hasConditionIDs(conditionIDs)) {
      String className = condition.getClassCondition().getClassName();
      sqlString.append(" AND ");
      if ((condition.getIdsCondition() != null) && (condition.getIdsCondition().isNegate()))
        sqlString.append("NOT ");

      fillCmdbIDTempTable(connection, conditionIDs, Integer.valueOf(classNameSuffix).intValue());
      String alias = getDummyClassName(className, classNameSuffix);
      sqlString.append(createJoinWithCmdbIDTempTableIndexConditionSql(alias, conditionIDs.size()));
      bindVariables.add(Integer.valueOf(classNameSuffix));
      bindVariablesTypes.add(CmdbSimpleTypes.CmdbInteger);
      participatedClasses.add(alias);
    }
  }

  private void fillCmdbIDTempTable(CmdbDalConnection connection, CmdbIDsCollection<? extends CmdbDataID> objectIds, int index) throws SQLException {
    List ids = new ArrayList();
    ReadOnlyIterator objectsIDsIter = objectIds.getIdsIterator();
    while (objectsIDsIter.hasNext()) {
      CmdbDataID objectID = (CmdbDataID)objectsIDsIter.next();
      ids.add(convertCmdbID2Bytes(objectID));
    }
    fillCmdbIDTempTable(connection, ids, index);
  }

  protected boolean hasConditionIDs() {
    return ((hasConditionIDs(getEnd1Condition())) || (hasConditionIDs(getEnd2Condition())) || (hasConditionIDs(getLinkCondition())));
  }

  protected boolean hasConditionIDs(ElementCondition elementCondition) {
    if (elementCondition.getIdsCondition() == null)
      return false;

    return hasConditionIDs(elementCondition.getIdsCondition().getIds());
  }

  public boolean hasConditionIDs(LinkCondition linkCondition) {
    if (linkCondition.getIdsCondition() == null)
      return false;

    return hasConditionIDs(linkCondition.getIdsCondition().getLinkIds());
  }

  protected boolean hasConditionIDs(Object conditionIDs) {
    if (conditionIDs == null)
      return false;

    if (conditionIDs instanceof CmdbObjectIds)
      return (!(isEmptyContainer((CmdbObjectIds)conditionIDs)));

    return (!(isEmptyContainer((CmdbLinkIds)conditionIDs)));
  }

  protected Object getResult(CmdbDalResultSet resultSet) throws SQLException
  {
    int maxTripleResults = getLocalEnvironment().getSettingsReader().getInt("dal.triple.max.result.size", 400000);
    ModelLinks resultModelLinks = ModelLinksFactory.createLinks();

    int numberOfResults = 0;
    while (resultSet.next()) {
      byte[] idAsBytes = resultSet.getBytes(1);
      CmdbObjectID end1Id = restoreObjectID(idAsBytes);
      String end1Type = resultSet.getString(2);
      idAsBytes = resultSet.getBytes(3);
      CmdbLinkID linkId = restoreLinkID(idAsBytes);
      String linkType = resultSet.getString(4);
      idAsBytes = resultSet.getBytes(5);
      CmdbObjectID end2Id = restoreObjectID(idAsBytes);
      String end2Type = resultSet.getString(6);
      ModelObject end1Obj = ModelObjectFactory.create(end1Id, end1Type);
      ModelObject end2Obj = ModelObjectFactory.create(end2Id, end2Type);
      ModelLink link = ModelLinkFactory.create(linkType, end1Obj, end2Obj, linkId);
      resultModelLinks.add(link);
      ++numberOfResults;
      if (numberOfResults > maxTripleResults) {
        String errMsg = "Number of Triples exceeded the maximum allowed (max allowed value is: " + maxTripleResults + ")";
        throw new CmdbDalException(errMsg);
      }
    }
    return resultModelLinks;
  }

  protected void createCmdbIDTempTable(Object conditionIDs, CmdbDalConnection connection) throws SQLException {
    if (conditionIDs instanceof CmdbObjectIds)
      createCmdbIDTempTable(connection, (CmdbObjectIds)conditionIDs);
    else
      createCmdbIDTempTable(connection, (CmdbLinkIds)conditionIDs);
  }

  protected void addIDsToBindVariables(CmdbIDsCollection<? extends CmdbDataID> conditionIDs, List<Object> bindVariables, List<CmdbType> bindVariablesTypes)
  {
    ReadOnlyIterator iter = conditionIDs.getIdsIterator();
    while (iter.hasNext()) {
      CmdbDataID id = (CmdbDataID)iter.next();
      byte[] idAsBytes = convertCmdbID2Bytes(id);
      bindVariables.add(idAsBytes);
      bindVariablesTypes.add(CmdbSimpleTypes.CmdbBytes);
    }
  }

  protected int getContainerSize(Object container) {
    if (container instanceof CmdbObjectIds) {
      return ((CmdbObjectIds)container).size();
    }

    if (container instanceof CmdbLinkIds) {
      return ((CmdbLinkIds)container).size();
    }

    throw new CmdbDalException("Container from type [" + container.getClass() + "] is not supported !!!");
  }

  protected CmdbIDsCollection<? extends CmdbDataID> extractConditionIDs(ElementCondition condition) {
    return extractConditionIDs(null, condition);
  }

  protected CmdbIDsCollection<? extends CmdbDataID> extractConditionIDs(Object modelElements, ElementCondition condition) {
    if (condition instanceof LinkCondition)
      return extractLinkConditionIDs(modelElements, condition);

    return extractObjectConditionIDs(modelElements, condition);
  }

  protected boolean hasModelElements(Object modelElements)
  {
    return false;
  }

  protected CmdbLinkIds extractLinkConditionIDs(Object modelElements, ElementCondition condition) {
    if ((condition.getIdsCondition() != null) && (!(isEmptyContainer(condition.getIdsCondition().getLinkIds()))))
      return condition.getIdsCondition().getLinkIds();

    return CmdbLinkIdsFactory.create();
  }

  protected CmdbObjectIds extractObjectConditionIDs(Object modelElements, ElementCondition condition) {
    if ((condition.getIdsCondition() != null) && (!(isEmptyContainer(condition.getIdsCondition().getIds()))))
      return condition.getIdsCondition().getIds();

    return CmdbObjectIdsFactory.create();
  }

  protected String getDummyClassName(String className, String classNameSuffix) {
    return getTableNameByClassName(className) + classNameSuffix;
  }

  protected String extractOriginalClassName(String dummyClassName, int classNameSuffixLength) {
    return dummyClassName.substring(0, dummyClassName.length() - classNameSuffixLength);
  }

  private String extractClassNameSuffix(String dummyClassName, int classNameSuffixLength) {
    return dummyClassName.substring(dummyClassName.length() - classNameSuffixLength, dummyClassName.length());
  }

  protected ElementCondition getEnd1Condition()
  {
    return getCondition();
  }

  protected LinkCondition getLinkCondition() {
    return this._linkCondition;
  }

  private void setLinkCondition(LinkCondition linkCondition) {
    this._linkCondition = linkCondition;
  }

  protected ElementCondition getEnd2Condition() {
    return this._end2Condition;
  }

  private void setEnd2Condition(ElementCondition end2Condition) {
    this._end2Condition = end2Condition;
  }

  private String getEnd2ClassNameSuffix() {
    return this._end2ClassNameSuffix;
  }

  private void setEnd2ClassNameSuffix(String end2ClassNameSuffix) {
    this._end2ClassNameSuffix = end2ClassNameSuffix;
  }

  private String getEnd1ClassNameSuffix() {
    return getClassNameSuffix();
  }

  private void setEnd1ClassNameSuffix(String end1ClassNameSuffix) {
    setClassNameSuffix(end1ClassNameSuffix);
  }

  public String getLinkClassNameSuffix() {
    return this._linkClassNameSuffix;
  }

  public void setLinkClassNameSuffix(String linkClassNameSuffix) {
    this._linkClassNameSuffix = linkClassNameSuffix;
  }

  protected Object getModelElements() {
    return null;
  }
}