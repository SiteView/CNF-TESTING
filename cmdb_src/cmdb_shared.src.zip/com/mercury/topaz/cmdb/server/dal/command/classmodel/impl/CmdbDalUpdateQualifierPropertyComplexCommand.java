package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;

public abstract class CmdbDalUpdateQualifierPropertyComplexCommand extends CmdbDalUpdatePropertyComplexCommand
{
  private ClassModelQualifier _qualifier = null;

  public CmdbDalUpdateQualifierPropertyComplexCommand(ClassModelQualifier qualifier, CmdbClass cmdbClass)
  {
    super(cmdbClass);
    setQulifier(qualifier);
  }

  protected void validateInput()
  {
    if (getQualifier() == null)
      throw new CmdbDalException("Can't update null qualifier");
  }

  protected Void perform() throws Exception
  {
    CmdbDalPreparedStatement preparedStatement = null;
    try
    {
      Long entityId = getRowId();
      String entityName = getRowQuailifierName();

      String sql = createUpdateSql(getTableNameToUpdate(), getRowIdConditionColumnName(), getRowQuailifierNameColumnName(), getColumnNameToUpdate());
      preparedStatement = getConnection().prepareStatement4Update(sql);
      setValuesToPreparedStatement(preparedStatement, entityId, entityName);

      preparedStatement.executeUpdate();
    }
    finally {
      if (preparedStatement != null)
        preparedStatement.close();

    }

    return null;
  }

  protected Long getRowId() throws SQLException {
    Long classId = getClassID(getCmdbClass().getName(), getConnection());
    return classId;
  }

  protected String getRowIdConditionColumnName() {
    return "ENTITY_ID";
  }

  protected String getTableNameToUpdate() {
    return "CCM_QUALIFIER";
  }

  protected String getRowQuailifierName() throws SQLException {
    return getQualifier().getName();
  }

  protected String getRowQuailifierNameColumnName() throws SQLException {
    return "QUALIFIER_NAME";
  }

  protected String createUpdateSql(String tableName, String rowIdConditionColumnName, String rowIdQualifierNameColumnName, String propertyToUpdate) {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("UPDATE ").append(tableName).append(" SET ");
    sqlString.append(propertyToUpdate).append("=?, ").append("IS_UPDATED").append("=?");
    sqlString.append(" WHERE ").append(rowIdConditionColumnName).append("=?");
    sqlString.append(" AND ").append(rowIdQualifierNameColumnName).append("=?");

    return sqlString.toString();
  }

  protected abstract void setValuesToPreparedStatement(CmdbDalPreparedStatement paramCmdbDalPreparedStatement, Long paramLong, String paramString) throws SQLException;

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long rowId) throws SQLException {
    throw new UnsupportedOperationException("This operation is unsupported from Qualifier command, use the same method with the rowQualifierName parameter");
  }

  protected ClassModelQualifier getQualifier()
  {
    return this._qualifier;
  }

  private void setQulifier(ClassModelQualifier qualifier) {
    this._qualifier = qualifier;
  }
}