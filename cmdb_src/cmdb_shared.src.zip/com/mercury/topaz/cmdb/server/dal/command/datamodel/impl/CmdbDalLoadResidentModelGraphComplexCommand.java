package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.model.graph.ModelGraph;
import com.mercury.topaz.cmdb.shared.util.Stopper;
import java.util.Set;

public class CmdbDalLoadResidentModelGraphComplexCommand extends CmdbDalAbstractLoadModelGraphComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalLoadResidentModelGraphComplexCommand.class);
  private Set<String> _nonResidentClasses = null;

  public CmdbDalLoadResidentModelGraphComplexCommand(Set<String> nonResidentClasses)
  {
    setNonResidentClasses(nonResidentClasses);
  }

  private Set<String> getNonResidentClasses() {
    return this._nonResidentClasses;
  }

  private void setNonResidentClasses(Set<String> nonResidentClasses) {
    this._nonResidentClasses = nonResidentClasses;
  }

  protected ModelGraph perform() {
    if (!(isOracle()))
      throw new CmdbDalException("New topology mode is not allowed with MsSql DB Only with Oracle DB");

    return super.perform();
  }

  private String createInsertResidentObjectsIntoTempTableSql()
  {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("insert into ").append("CDM_TMP_OBJID_STR").append(" (").append("CMDB_ID").append(",").append("T_VALUE").append(",").append("T_VALUES_INDEX").append(") ").append("(select ").append("r.").append("CMDB_ID").append(", r.").append("CLASS").append(", 1").append(" from ").append(getTableNameByClassName("root")).append(" r").append(" where not exists ( select 1 from ").append(getTableNameByClassName("link")).append(" l where l.").append("CMDB_ID").append("=r.").append("CMDB_ID").append(")");

    if (!(getNonResidentClasses().isEmpty())) {
      sqlString.append(" AND ");
      addInClause(sqlString, "r.CLASS", getNonResidentClasses(), true);
    }

    if (!(isUpdateClassModelEnabled())) {
      sqlString.append(" AND r.").append("CUSTOMER_ID").append("=?");
    }

    sqlString.append(")");
    return sqlString.toString();
  }

  private void insertResidentObjectsIntoTempTable() {
    CmdbDalPreparedStatement preparedStatement = null;
    try {
      CmdbDalConnection connection = getConnection();
      String insertSql = createInsertResidentObjectsIntoTempTableSql();
      preparedStatement = connection.prepareStatement4Update(insertSql);
      Stopper stopper = new Stopper();
      stopper.start();
      int numOfResObjects = preparedStatement.executeUpdate();
      preparedStatement.close();
      _logger.info("Insert Resident Objects Into Temp Table - execution time (sec): " + (stopper.elapsedTime() / 1000L) + ", Number of resident objects: " + numOfResObjects);
    } finally {
      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  protected String createObjectsSql()
  {
    insertResidentObjectsIntoTempTable();
    StringBuffer getObjectsSql = new StringBuffer();
    getObjectsSql.append("select ").append("CMDB_ID").append(", ").append("T_VALUE").append(" from ").append("CDM_TMP_OBJID_STR");

    return getObjectsSql.toString();
  }

  private String createLinkSubSelect(String linkEnd) {
    StringBuffer sqlString = new StringBuffer();
    sqlString.append("select 1 from ").append("CDM_TMP_OBJID_STR").append(" t where t.").append("CMDB_ID").append("=l.").append(linkEnd).append(" and t.").append("T_VALUES_INDEX").append("=1");

    return sqlString.toString();
  }

  protected String createLinksSql()
  {
    String sql = "select CMDB_ID, CLASS, END1_ID, END2_ID from " + getTableNameByClassName("link") + " l where exists (" + createLinkSubSelect("END1_ID") + ") and exists (" + createLinkSubSelect("END2_ID") + ")";

    if (!(isUpdateClassModelEnabled()))
      sql = sql + " and CUSTOMER_ID = ?";

    sql = sql + " order by CLASS";
    return sql;
  }
}