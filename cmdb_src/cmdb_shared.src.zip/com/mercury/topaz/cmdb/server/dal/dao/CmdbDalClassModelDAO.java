package com.mercury.topaz.cmdb.server.dal.dao;

import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModelDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.definition.CmdbMethodQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.diff.ClassModelDiffs;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.definition.CmdbValidLinkQualifierDef;

public abstract interface CmdbDalClassModelDAO
{
  public abstract CmdbClassModelDefinition getClassModelDefinition();

  public abstract void addClassQualifierDef(CmdbClassQualifierDef paramCmdbClassQualifierDef);

  public abstract void addMethodQualifierDef(CmdbMethodQualifierDef paramCmdbMethodQualifierDef);

  public abstract void addAttributeQualifierDef(CmdbAttributeQualifierDef paramCmdbAttributeQualifierDef);

  public abstract void addValidLinkQualifierDef(CmdbValidLinkQualifierDef paramCmdbValidLinkQualifierDef);

  public abstract void addClass(CmdbClass paramCmdbClass);

  public abstract void removeClass(CmdbClass paramCmdbClass);

  public abstract void updateClass(CmdbClass paramCmdbClass);

  public abstract void addValidLink(CmdbValidLink paramCmdbValidLink);

  public abstract void updateValidLink(CmdbValidLink paramCmdbValidLink);

  public abstract void removeValidLink(CmdbValidLink paramCmdbValidLink);

  public abstract void addTypeDef(CmdbTypeDef paramCmdbTypeDef);

  public abstract void updateTypeDef(CmdbTypeDef paramCmdbTypeDef);

  public abstract void removeTypeDef(CmdbTypeDef paramCmdbTypeDef);

  public abstract void addCalculatedLink(CmdbCalculatedLink paramCmdbCalculatedLink, CmdbClass paramCmdbClass);

  public abstract void removeCalculatedLink(CmdbCalculatedLink paramCmdbCalculatedLink, CmdbClass paramCmdbClass);

  public abstract void updateCalculatedLink(CmdbCalculatedLink paramCmdbCalculatedLink);

  public abstract void update(ClassModelDiffs paramClassModelDiffs);
}