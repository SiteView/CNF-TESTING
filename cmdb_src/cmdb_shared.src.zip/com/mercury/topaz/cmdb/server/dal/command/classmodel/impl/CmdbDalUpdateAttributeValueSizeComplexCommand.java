package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.impl.CmdbAttributeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;

public class CmdbDalUpdateAttributeValueSizeComplexCommand extends CmdbDalAbstractUpdateAttributeValueSizeComplexCommand
{
  public CmdbDalUpdateAttributeValueSizeComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass)
  {
    super(attribute, cmdbClass);
  }

  protected Void perform() throws Exception {
    super.perform();
    updateColumnSize();
    return null;
  }

  protected String getColumnNameToUpdate() {
    return "VALUE_SIZE";
  }

  private void updateColumnSize()
  {
    if (!(isUpdateColumnNeeded())) {
      return;
    }

    String tableName = getTableNameByClassName(getCmdbClass().getName());
    TableDescription tableDescription = new TableDescription(tableName);
    TableModifications modifications = new TableModifications();

    updateLists(modifications);

    CmdbDalCommand updateTableCommand = CmdbDalCommandFactory.createUpdateTableUpdateColumnsComplexCommand(tableDescription, modifications);
    updateTableCommand.execute();
  }

  private boolean isUpdateColumnNeeded() {
    CmdbAttribute attribute = (CmdbAttribute)getAttribute();
    if (attribute.getSizeLimit() == null)
      return false;

    if (attribute.getResolvedType().equals(CmdbSimpleTypes.CmdbString)) {
      return true;
    }

    return ((attribute.getResolvedType().equals(CmdbSimpleTypes.CmdbBytes)) && (attribute.getSizeLimit().intValue() < 2000));
  }

  private void updateLists(TableModifications modifications)
  {
    CmdbModifiableAttributes attributes = CmdbAttributeFactory.createAttributes();
    attributes.add((CmdbAttribute)getAttribute());
    addColumnModification(attributes, modifications);
    updateTableIndicesListsDueToSizeChange(attributes, modifications);
  }

  private void addColumnModification(CmdbAttributes attributes, TableModifications modifications) {
    CmdbAttributes persistentAttributes = ClassModelUtil.extractPersistentAttributes(attributes);
    ReadOnlyIterator attributesIter = persistentAttributes.getIterator();
    while (attributesIter.hasNext()) {
      CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();

      if (isSimpleTypeAttribute(attribute)) {
        String columnName = DalClassModelUtil.getColumnNameByAttributeName(attribute.getName());
        ColumnDescription columnDescription = new ColumnDescription(columnName).ofCmdbType(attribute.getResolvedType());

        if (attribute.getSizeLimit() != null) {
          columnDescription.ofSize(attribute.getSizeLimit().intValue());
        }

        if (DalClassModelUtil.isNotNullAttribute(attribute)) {
          columnDescription.notNullable();
        }

        modifications.changeColumnSize(columnDescription);
      }
    }
  }

  private void updateTableIndicesListsDueToSizeChange(CmdbAttributes attributes, TableModifications modifications)
  {
    CmdbAttributes persistentAttributes = ClassModelUtil.extractPersistentAttributes(attributes);
    ReadOnlyIterator attributesIter = persistentAttributes.getIterator();
    while (attributesIter.hasNext()) {
      CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();

      if ((isSimpleTypeAttribute(attribute)) && (isIndexedAttribute(attribute)))
        if (attribute.getSizeLimit().intValue() <= 900)
          modifications.addIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName())));
        else
          modifications.removeIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName())));
    }
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long attributeId)
    throws SQLException
  {
    preparedStatement.setInt(((CmdbAttribute)getAttribute()).getSizeLimit());
    preparedStatement.setBoolean(getAttribute().isModifiedByUser());
    preparedStatement.setLong(attributeId);
  }
}