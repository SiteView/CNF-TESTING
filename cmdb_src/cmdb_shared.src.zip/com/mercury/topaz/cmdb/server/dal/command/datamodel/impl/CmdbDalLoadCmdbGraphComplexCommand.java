package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.model.graph.ModelGraph;
import com.mercury.topaz.cmdb.server.model.graph.impl.ModelGraphFactory;
import com.mercury.topaz.cmdb.server.model.graph.object.MutableModelObject;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.graph.ModifiableCMDBGraph;
import com.mercury.topaz.cmdb.shared.model.graph.impl.CmdbGraphFactory;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.ModelLinksFactory;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.graph.object.impl.ModelObjectsFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.set.CmdbHashSet;
import java.util.Iterator;

public class CmdbDalLoadCmdbGraphComplexCommand extends CmdbDalDataModelComplexCommand<CmdbGraph>
{
  ModifiedLoadGraphCommand innerCommand;

  protected void validateInput()
  {
  }

  protected CmdbGraph perform()
  {
    this.innerCommand.perform();

    ModifiableCMDBGraph cmdbGraph = CmdbGraphFactory.createModifiableCMDBGraph();
    cmdbGraph.addObjects(this.innerCommand._objects.getObjectsIterator());
    cmdbGraph.addLinks(this.innerCommand._links.getLinksIterator());

    return cmdbGraph; }

  private static class ModifiedLoadGraphCommand extends CmdbDalLoadModelGraphComplexCommand { final CmdbObjects _objects;
    final CmdbLinks _links;

    private ModifiedLoadGraphCommand() { this._objects = CmdbObjectFactory.createObjects();
      this._links = CmdbLinkFactory.createLinks(); }

    protected ModelGraph buildModelGraphFromObjectToLinksMap(CmdbHashSet<MutableModelObject> objects) throws Exception {
      ModelGraph modelGraph = ModelGraphFactory.createModelGraph(objects, 0L, 0L, getSynchronizedClassModel(), getLocalEnvironment());
      ModelLinks finalLinks = ModelLinksFactory.createLinks();

      for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { MutableModelObject modelObject = (MutableModelObject)i$.next();
        ModelLink[] links = modelObject.getLinks();
        ModelLink[] arr$ = links; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { ModelLink link = arr$[i$];
          if (!(finalLinks.contains(link))) {
            finalLinks.add(link);
          }

        }

        ModelObjects modelObjects = ModelObjectsFactory.create();
        modelObjects.add(modelObject);
        ElementSimpleLayout simpleLayout = PatternLayoutFactory.createElementSimpleLayout();
        simpleLayout.setAllLayer(true);
        CmdbDalCommand getObjectsLayoutCommand = CmdbDalDataModelCommandFactory.createGetObjectsLayoutComplexCommand(modelObjects, simpleLayout);
        CmdbDalCommandResult result = getObjectsLayoutCommand.execute();
        CmdbObjects cmdbObjects = (CmdbObjects)result.getResult();
        CmdbObject object = (CmdbObject)cmdbObjects.getObjectsIterator().next();
        this._objects.add(object);
        modelGraph.addObject(object);
      }

      ElementSimpleLayout simpleLayout = PatternLayoutFactory.createElementSimpleLayout();
      simpleLayout.setAllLayer(true);
      CmdbDalCommand getLinksLayoutCommand = CmdbDalDataModelCommandFactory.createGetLinksLayoutComplexCommand(finalLinks, simpleLayout);
      CmdbDalCommandResult result = getLinksLayoutCommand.execute();
      CmdbLinks cmdbLinks = (CmdbLinks)result.getResult();
      this._links.add(cmdbLinks);
      modelGraph.addLinks(cmdbLinks);
      return modelGraph;
    }
  }
}