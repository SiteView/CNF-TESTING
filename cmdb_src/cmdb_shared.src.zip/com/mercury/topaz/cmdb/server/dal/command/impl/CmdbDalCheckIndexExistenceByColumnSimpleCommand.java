package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;

public class CmdbDalCheckIndexExistenceByColumnSimpleCommand extends CmdbDalAbstractCommand<Boolean>
{
  private String _tableName = null;
  private String _columnName = null;

  public CmdbDalCheckIndexExistenceByColumnSimpleCommand(String tableName, String columnName)
  {
    setTableName(tableName);
    setColumnName(columnName);
  }

  protected void validateInput() {
    if ((getTableName() == null) || (getTableName().length() == 0) || (getColumnName() == null) || (getColumnName().length() == 0))
    {
      throw new CmdbDalException("Can't check existence of index for column [" + getColumnName() + "], in table [" + getTableName() + "]");
    }
  }

  protected Boolean perform() throws Exception {
    return Boolean.valueOf(checkIndexExistence());
  }

  private boolean checkIndexExistence()
    throws SQLException
  {
    String sqlString;
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;

    if (isOracle())
    {
      sqlString = "SELECT 1 FROM USER_IND_COLUMNS WHERE TABLE_NAME=? AND COLUMN_NAME=?";
    }
    else if (isMsSql()) {
      sqlString = "SELECT 1 FROM sysindexkeys ik join sysindexes i on ik.indid = i.indid and ik.id = i.id where object_name(ik.id) = ? and indexproperty(ik.id,i.name,'IsStatistics') = 0 and col_name(ik.id,ik.colid)=?";
    }
    else
    {
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
    }
    try
    {
      preparedStatement = getConnection().prepareStatement4Select(sqlString);
      preparedStatement.setString(getTableName());
      preparedStatement.setString(getColumnName());

      resultSet = preparedStatement.executeQuery();

      boolean res = resultSet.next();

      resultSet.close();
      preparedStatement.close();

      boolean bool1 = res;

      return bool1;
    }
    finally
    {
      if (resultSet != null) resultSet.close();
      if (preparedStatement != null) preparedStatement.close();
    }
  }

  private String getTableName() {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    this._tableName = tableName;
  }

  private String getColumnName() {
    return this._columnName;
  }

  private void setColumnName(String columnName) {
    this._columnName = columnName;
  }
}