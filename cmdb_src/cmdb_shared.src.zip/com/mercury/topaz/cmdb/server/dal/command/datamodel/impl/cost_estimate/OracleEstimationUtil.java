package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.cost_estimate;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.base.CmdbException;

class OracleEstimationUtil
{
  private static final String PLAN_TABLE_NAME = "PLAN_TABLE";
  private static final String PLAN_TABLE_VERIFICATION_SQL = "select count(*) from PLAN_TABLE where 1 = 2";
  private static final String PLAN_TABLE_DOES_NOT_EXIST_MSG = "PLAN_TABLE does not exist";
  private static boolean planTableExists = false;
  private static boolean planTableExistenceVerified = false;

  static void verifyPlanTableExists(CmdbDalPreparedStatement statement)
  {
    if (planTableExistenceVerified) {
      if (planTableExists) {
        return;
      }

      throw new CmdbException("PLAN_TABLE does not exist");
    }
    try
    {
      statement.executeQuery();
      planTableExists = true;
    } catch (Exception e) {
    }
    finally {
      planTableExistenceVerified = true;
    }
  }

  static boolean planTableExists(CmdbDalPreparedStatement statement) {
    if (planTableExistenceVerified)
      return planTableExists;

    try
    {
      statement.executeQuery();
      planTableExists = true;
    } catch (Exception e) {
      LogFactory.getEasyLog(OracleEstimationUtil.class).info("PLAN_TABLE does not exist");
    } finally {
      planTableExistenceVerified = true;
    }

    return planTableExists;
  }

  static String getPlanTableVerificationSql() {
    return "select count(*) from PLAN_TABLE where 1 = 2";
  }
}