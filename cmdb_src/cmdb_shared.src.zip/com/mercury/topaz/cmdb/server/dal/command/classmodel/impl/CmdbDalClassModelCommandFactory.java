package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalHandleNewCustomerComplexCommand;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalHandleNewCustomerOracleComplexCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModelDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CalculatedLinkTripletDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverrides;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethods;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.CmdbMethodQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.CmdbMethodQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.definition.CmdbMethodQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbClassQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbClassQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnumEntry;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.CmdbValidLinkQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.CmdbValidLinkQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.definition.CmdbValidLinkQualifierDef;

public class CmdbDalClassModelCommandFactory extends CmdbDalCommandFactory
{
  public static CmdbDalCommand<Void> createAddClassComplexCommand(CmdbClass cmdbClass)
  {
    return new CmdbDalAddClassComplexCommand(cmdbClass);
  }

  public static CmdbDalCommand<Void> createAddClassUpdateTableComplexCommand(CmdbClass cmdbClass) {
    return new CmdbDalAddClassUpdateTableComplexCommand(cmdbClass);
  }

  public static CmdbDalCommand<Void> createRemoveClassComplexCommand(CmdbClass cmdbClass) {
    return new CmdbDalRemoveClassComplexCommand(cmdbClass);
  }

  public static CmdbDalCommand<Void> createRemoveClassUpdateTableComplexCommand(CmdbClass cmdbClass) {
    return new CmdbDalRemoveClassUpdateTableComplexCommand(cmdbClass);
  }

  public static CmdbDalCommand<Void> createAddValidLinkComplexCommand(CmdbValidLink validLink) {
    return new CmdbDalAddValidLinkComplexCommand(validLink);
  }

  public static CmdbDalCommand<Void> createRemoveValidLinkComplexCommand(CmdbValidLink validLink) {
    return new CmdbDalRemoveValidLinkComplexCommand(validLink);
  }

  public static CmdbDalCommand<Void> createAddTypeDefComplexCommand(CmdbTypeDef typeDef) {
    if (typeDef instanceof CmdbEnum)
      return new CmdbDalAddTypeDefEnumComplexCommand((CmdbEnum)typeDef);
    if (typeDef instanceof CmdbList)
      return new CmdbDalAddTypeDefListComplexCommand((CmdbList)typeDef);

    throw new UnsupportedOperationException("Unknown type def: [" + typeDef + "]");
  }

  public static CmdbDalCommand<Void> createAddTypeDefListComplexCommand(CmdbList cmdbList) {
    return new CmdbDalAddTypeDefListComplexCommand(cmdbList);
  }

  public static CmdbDalCommand<Void> createAddTypeDefEnumComplexCommand(CmdbEnum cmdbEnum) {
    return new CmdbDalAddTypeDefEnumComplexCommand(cmdbEnum);
  }

  public static CmdbDalCommand<Void> createRemoveTypeDefComplexCommand(CmdbTypeDef typeDef) {
    return new CmdbDalRemoveTypeDefComplexCommand(typeDef);
  }

  public static CmdbDalCommand<Void> createUpdateTypeDefDisplayNameComplexCommand(CmdbTypeDef typeDef) {
    return new CmdbDalUpdateTypeDefDisplayNameComplexCommand(typeDef);
  }

  public static CmdbDalCommand<Void> createUpdateTypeDefDescriptionComplexCommand(CmdbTypeDef typeDef) {
    return new CmdbDalUpdateTypeDefDescriptionComplexCommand(typeDef);
  }

  public static CmdbDalCommand<Void> createRemoveTypeDefEnumEntryComplexCommand(CmdbEnumEntry enumEntry, CmdbEnum cmdbEnum, Long typeDefId) {
    return new CmdbDalRemoveTypeDefEnumEntryComplexCommand(enumEntry, cmdbEnum, typeDefId);
  }

  public static CmdbDalCommand<Void> createAddClassQualifierDefComplexCommand(CmdbClassQualifierDef qualifierDef) {
    return new CmdbDalAddClassQualifierDefComplexCommand(qualifierDef);
  }

  public static CmdbDalCommand<Void> createAddMethodQualifierDefComplexCommand(CmdbMethodQualifierDef qualifierDef) {
    return new CmdbDalAddMethodQualifierDefComplexCommand(qualifierDef);
  }

  public static CmdbDalCommand<Void> createAddAttributeQualifierDefComplexCommand(CmdbAttributeQualifierDef qualifierDef) {
    return new CmdbDalAddAttributeQualifierDefComplexCommand(qualifierDef);
  }

  public static CmdbDalCommand<Void> createAddValidLinkQualifierDefComplexCommand(CmdbValidLinkQualifierDef qualifierDef) {
    return new CmdbDalAddValidLinkQualifierDefComplexCommand(qualifierDef);
  }

  public static CmdbDalCommand<CmdbClassModelDefinition> createLoadClassModelComplexCommand() {
    return new CmdbDalLoadClassModelCoarseGrainComplexCommand();
  }

  public static CmdbDalCommand<Void> createUpdateClassDisplayNameComplexCommand(CmdbClass cmdbClass) {
    return new CmdbDalUpdateClassDisplayNameComplexCommand(cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateClassDescriptionComplexCommand(CmdbClass cmdbClass) {
    return new CmdbDalUpdateClassDescriptionComplexCommand(cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateAttributeDisplayNameComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass) {
    return new CmdbDalUpdateAttributeDisplayNameComplexCommand(attribute, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateAttributeDescriptionComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass) {
    return new CmdbDalUpdateAttributeDescriptionComplexCommand(attribute, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateAttributeDefaultValueComplexCommand(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass) {
    return new CmdbDalUpdateAttributeDefaultValueComplexCommand(attributeOverride, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateAttributeIsPartialOverrideComplexCommand(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass) {
    return new CmdbDalUpdateAttributeIsPartialOverrideComplexCommand(attributeOverride, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateAttributeValueSizeComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass) {
    return new CmdbDalUpdateAttributeValueSizeComplexCommand(attribute, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateAttributeValueSizeUpdateTableComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass) {
    return new CmdbDalUpdateAttributeValueSizeUpdateTableComplexCommand(attribute, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateAttributeTypeComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass) {
    return new CmdbDalUpdateAttributeTypeComplexCommand(attribute, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateMethodDisplayNameComplexCommand(CmdbMethod method, CmdbClass cmdbClass) {
    return new CmdbDalUpdateMethodDisplayNameComplexCommand(method, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateMethodDescriptionComplexCommand(CmdbMethod method, CmdbClass cmdbClass) {
    return new CmdbDalUpdateMethodDescriptionComplexCommand(method, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateMethodTypeComplexCommand(CmdbMethod method, CmdbClass cmdbClass) {
    return new CmdbDalUpdateMethodTypeComplexCommand(method, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateMethodCommandComplexCommand(CmdbMethod method, CmdbClass cmdbClass) {
    return new CmdbDalUpdateMethodCommandComplexCommand(method, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateMethodParamsComplexCommand(CmdbMethod method, CmdbClass cmdbClass) {
    return new CmdbDalUpdateMethodParamsComplexCommand(method, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateAttributeIsFactoryComplexCommand(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass) {
    return new CmdbDalUpdateAttributeIsFactoryComplexCommand(attributeOverride, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateClassIsFactoryComplexCommand(CmdbClass cmdbClass) {
    return new CmdbDalUpdateClassIsFactoryComplexCommand(cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateMethodIsFactoryComplexCommand(CmdbMethod method, CmdbClass cmdbClass) {
    return new CmdbDalUpdateMethodIsFactoryComplexCommand(method, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateValidLinkIsFactoryComplexCommand(CmdbValidLink validLink) {
    return new CmdbDalUpdateValidLinkIsFactoryComplexCommand(validLink);
  }

  public static CmdbDalCommand<Void> createUpdateTypeDefIsFactoryComplexCommand(CmdbTypeDef typeDef) {
    return new CmdbDalUpdateTypeDefIsFactoryComplexCommand(typeDef);
  }

  public static CmdbDalCommand<Void> createUpdateTypeDefEnumEntryIsFactoryComplexCommand(CmdbEnum cmdbEnum, CmdbEnumEntry enumEntry) {
    return new CmdbDalUpdateTypeDefEnumEntryIsFactoryComplexCommand(enumEntry, cmdbEnum, null);
  }

  public static CmdbDalCommand<Void> createUpdateTypeDefListEntryIsFactoryComplexCommand(CmdbList cmdbList, CmdbListEntry listEntry) {
    return new CmdbDalUpdateTypeDefListEntryIsFactoryComplexCommand(listEntry, cmdbList, null);
  }

  public static CmdbDalCommand<Void> createUpdateAttributeQualifierIsFactoryComplexCommand(ClassModelQualifier classModelQualifier, CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass) {
    return new CmdbDalUpdateAttributeQualifierIsFactoryComplexCommand(classModelQualifier, cmdbClass, attributeOverride);
  }

  public static CmdbDalCommand<Void> createUpdateClassQualifierIsFactoryComplexCommand(ClassModelQualifier classModelQualifier, CmdbClass cmdbClass) {
    return new CmdbDalUpdateClassQualifierIsFactoryComplexCommand(classModelQualifier, cmdbClass);
  }

  public static CmdbDalCommand<Void> createUpdateMethodQualifierIsFactoryComplexCommand(ClassModelQualifier classModelQualifier, CmdbMethod method, CmdbClass cmdbClass) {
    return new CmdbDalUpdateMethodQualifierIsFactoryComplexCommand(classModelQualifier, cmdbClass, method);
  }

  public static CmdbDalCommand<Void> createAddClassQualifiersComplexCommand(CmdbClass cmdbClass, CmdbClassQualifiers qualifiers, Long entityId) {
    return new CmdbDalAddClassQualifiersComplexCommand(cmdbClass, qualifiers, entityId);
  }

  public static CmdbDalCommand<Void> createAddClassQualifiersComplexCommand(CmdbClass cmdbClass, CmdbClassQualifier qualifier, Long entityId) {
    return new CmdbDalAddClassQualifiersComplexCommand(cmdbClass, qualifier, entityId);
  }

  public static CmdbDalCommand<Void> createAddAttributeQualifiersComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, CmdbAttributeQualifiers qualifiers, Long entityId) {
    return new CmdbDalAddAttributeQualifiersComplexCommand(cmdbAttribute, cmdbClass, qualifiers, entityId);
  }

  public static CmdbDalCommand<Void> createAddAttributeQualifiersUpdateTableComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, CmdbAttributeQualifiers qualifiers, Long entityId) {
    return new CmdbDalAddAttributeQualifiersUpdateTableComplexCommand(cmdbAttribute, cmdbClass, qualifiers, entityId);
  }

  public static CmdbDalCommand<Void> createAddMethodQualifiersComplexCommand(CmdbMethod cmdbMethod, CmdbClass cmdbClass, CmdbMethodQualifiers qualifiers, Long entityId) {
    return new CmdbDalAddMethodQualifiersComplexCommand(cmdbMethod, cmdbClass, qualifiers, entityId);
  }

  public static CmdbDalCommand<Void> createAddMethodQualifiersComplexCommand(CmdbMethod cmdbMethod, CmdbClass cmdbClass, CmdbMethodQualifier qualifier, Long entityId) {
    return new CmdbDalAddMethodQualifiersComplexCommand(cmdbMethod, cmdbClass, qualifier, entityId);
  }

  public static CmdbDalCommand<Void> createAddValidLinkQualifiersComplexCommand(CmdbValidLink cmdbValidLink, CmdbValidLinkQualifiers qualifiers, Long entityId) {
    return new CmdbDalAddValidLinkQualifiersComplexCommand(cmdbValidLink, qualifiers, entityId);
  }

  public static CmdbDalCommand<Void> createAddValidLinkQualifiersComplexCommand(CmdbValidLink cmdbValidLink, CmdbValidLinkQualifier qualifier, Long entityId) {
    return new CmdbDalAddValidLinkQualifiersComplexCommand(cmdbValidLink, qualifier, entityId);
  }

  public static CmdbDalCommand<Void> createAddMethodsComplexCommand(CmdbMethods cmdbMethods, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalAddMethodsComplexCommand(cmdbMethods, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createAddMethodsComplexCommand(CmdbMethod cmdbMethod, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalAddMethodsComplexCommand(cmdbMethod, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createAddAttributesComplexCommand(CmdbAttributes cmdbAttributes, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalAddAttributesComplexCommand(cmdbAttributes, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createAddAttributesComplexCommand(CmdbAttribute cmdbAttribute, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalAddAttributesComplexCommand(cmdbAttribute, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createAddAttributesUpdateTableComplexCommand(CmdbAttributes cmdbAttributes, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalAddAttributesUpdateTableComplexCommand(cmdbAttributes, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createAddAttributesUpdateTableComplexCommand(CmdbAttribute cmdbAttribute, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalAddAttributesUpdateTableComplexCommand(cmdbAttribute, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createAddAttributesOverridesComplexCommand(CmdbAttributeOverrides cmdbAttributeOverrides, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalAddAttributesOverridesComplexCommand(cmdbAttributeOverrides, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createRemoveClassQualifiersComplexCommand(CmdbClass cmdbClass, CmdbClassQualifiers qualifiers, Long entityId) {
    return new CmdbDalRemoveClassQualifiersComplexCommand(cmdbClass, qualifiers, entityId);
  }

  public static CmdbDalCommand<Void> createRemoveClassQualifiersComplexCommand(CmdbClass cmdbClass, CmdbClassQualifier qualifier, Long entityId) {
    return new CmdbDalRemoveClassQualifiersComplexCommand(cmdbClass, qualifier, entityId);
  }

  public static CmdbDalCommand<Void> createRemoveAttributeQualifiersComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, CmdbAttributeQualifiers qualifiers, Long entityId) {
    return new CmdbDalRemoveAttributeQualifiersComplexCommand(cmdbAttribute, cmdbClass, qualifiers, entityId);
  }

  public static CmdbDalCommand<Void> createRemoveAttributeQualifiersComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, CmdbAttributeQualifier qualifier, Long entityId) {
    return new CmdbDalRemoveAttributeQualifiersComplexCommand(cmdbAttribute, cmdbClass, qualifier, entityId);
  }

  public static CmdbDalCommand<Void> createRemoveAttributeQualifiersUpdateTableComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, CmdbAttributeQualifiers qualifiers, Long entityId) {
    return new CmdbDalRemoveAttributeQualifiersUpdateTableComplexCommand(cmdbAttribute, cmdbClass, qualifiers, entityId);
  }

  public static CmdbDalCommand<Void> createRemoveMethodQualifiersComplexCommand(CmdbMethod cmdbMethod, CmdbClass cmdbClass, CmdbMethodQualifiers qualifiers, Long entityId) {
    return new CmdbDalRemoveMethodQualifiersComplexCommand(cmdbMethod, cmdbClass, qualifiers, entityId);
  }

  public static CmdbDalCommand<Void> createRemoveMethodQualifiersComplexCommand(CmdbMethod cmdbMethod, CmdbClass cmdbClass, CmdbMethodQualifier qualifier, Long entityId) {
    return new CmdbDalRemoveMethodQualifiersComplexCommand(cmdbMethod, cmdbClass, qualifier, entityId);
  }

  public static CmdbDalCommand<Void> createRemoveValidLinkQualifiersComplexCommand(CmdbValidLink cmdbValidLink, CmdbValidLinkQualifiers qualifiers, Long entityId) {
    return new CmdbDalRemoveValidLinkQualifiersComplexCommand(cmdbValidLink, qualifiers, entityId);
  }

  public static CmdbDalCommand<Void> createRemoveValidLinkQualifiersComplexCommand(CmdbValidLink cmdbValidLink, CmdbValidLinkQualifier qualifier, Long entityId) {
    return new CmdbDalRemoveValidLinkQualifiersComplexCommand(cmdbValidLink, qualifier, entityId);
  }

  public static CmdbDalCommand<Void> createRemoveMethodsComplexCommand(CmdbMethods cmdbMethods, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalRemoveMethodsComplexCommand(cmdbMethods, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createRemoveMethodsComplexCommand(CmdbMethod cmdbMethod, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalRemoveMethodsComplexCommand(cmdbMethod, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createRemoveAttributesComplexCommand(CmdbAttributes cmdbAttributes, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalRemoveAttributesComplexCommand(cmdbAttributes, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createRemoveAttributesComplexCommand(CmdbAttribute cmdbAttribute, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalRemoveAttributesComplexCommand(cmdbAttribute, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createRemoveAttributesUpdateTableComplexCommand(CmdbAttributes cmdbAttributes, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalRemoveAttributesUpdateTableComplexCommand(cmdbAttributes, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createRemoveAttributesUpdateTableComplexCommand(CmdbAttribute cmdbAttribute, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalRemoveAttributesUpdateTableComplexCommand(cmdbAttribute, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createRemoveAttributesOverridesComplexCommand(CmdbAttributeOverrides cmdbAttributeOverrides, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalRemoveAttributesOverridesComplexCommand(cmdbAttributeOverrides, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createRemoveAttributesOverridesComplexCommand(CmdbAttributeOverride cmdbAttributeOverride, CmdbClass cmdbClass, Long classId) {
    return new CmdbDalRemoveAttributesOverridesComplexCommand(cmdbAttributeOverride, cmdbClass, classId);
  }

  public static CmdbDalCommand<Void> createAddTypeDefEnumEntryComplexCommand(CmdbEnumEntry enumEntry, CmdbEnum cmdbEnum, Integer orderingIndex, Long typeDefId) {
    return new CmdbDalAddTypeDefEnumEntryComplexCommand(enumEntry, cmdbEnum, orderingIndex, typeDefId);
  }

  public static CmdbDalCommand<Void> createAddTypeDefListEntryComplexCommand(CmdbListEntry listEntry, CmdbList cmdbList, Integer orderingIndex, Long typeDefId) {
    return new CmdbDalAddTypeDefListEntryComplexCommand(listEntry, cmdbList, orderingIndex, typeDefId);
  }

  public static CmdbDalCommand<Void> createRemoveTypeDefListEntryComplexCommand(CmdbListEntry listEntry, CmdbList cmdbList, Long typeDefId) {
    return new CmdbDalRemoveTypeDefListEntryComplexCommand(listEntry, cmdbList, typeDefId);
  }

  public static CmdbDalCommand<Void> createUpdateAddMigrationTableComplexCommand(String className, Long classId) {
    return new CmdbDalUpdateAddMigrationTableComplexCommand(className, classId);
  }

  public static CmdbDalCommand<Void> createAddCalculatedLinkTripletComplexCommand(CmdbClass cmdbClass, CmdbCalculatedLink calculatedLink, CalculatedLinkTripletDefinition calculatedLinkTriplet, Long classID) {
    return new CmdbDalAddCalculatedLinkTripletCommand(cmdbClass, calculatedLink, calculatedLinkTriplet, classID);
  }

  public static CmdbDalCommand<Void> createAddCalculatedLinkComplexCommand(CmdbCalculatedLink cmdbCalculatedLink, CmdbClass cmdbClass) {
    return new CmdbDalAddCalculatedLinkComplexCommand(cmdbCalculatedLink, cmdbClass);
  }

  public static CmdbDalCommand<Void> createRemoveCalculatedLinkTripletComplexCommand(CalculatedLinkTripletDefinition triplet, CmdbClass cmdbClass, Long classID) {
    return new CmdbDalRemoveCalculatedLinkTripletCommand(triplet, cmdbClass, classID);
  }

  public static CmdbDalCommand<Void> createRemoveCalculatedLinkComplexCommand(CmdbCalculatedLink cmdbCalculatedLink, CmdbClass cmdbClass) {
    return new CmdbDalRemoveCalculatedLinkComplexCommand(cmdbCalculatedLink, cmdbClass);
  }

  public static CmdbDalCommand<Void> createHandleNewCustomerComplexCommand(DBType dbType)
  {
    if (DBType.isOracle(dbType))
      return new CmdbDalHandleNewCustomerOracleComplexCommand();
    if (DBType.isMsSql(dbType))
      return new CmdbDalHandleNewCustomerComplexCommand();

    throw new CmdbDalException("Unknown db type [" + dbType + "] !!!");
  }

  public static CmdbDalCommand<Void> createUpdateClassHierarchyComplexCommand(CmdbClass cmdbClass)
  {
    return new CmdbDalUpdateClassHierarchyComplexCommand(cmdbClass);
  }
}