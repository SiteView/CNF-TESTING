package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.dal.command.classmodel.impl.CmdbDalClassModelCommandFactory;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.manage.dal.DalCallStack;
import com.mercury.topaz.cmdb.server.manage.dal.LogUtil;
import com.mercury.topaz.cmdb.server.manage.dal.TransactionManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.common.qualifiedname.CmdbQualifiedNameFactory;
import com.mercury.topaz.cmdb.shared.dal.exception.CmdbDalValidationException;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Iterator;

public abstract class CmdbDalAbstractCommand<RESULT>
  implements CmdbDalCommand<RESULT>
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalAbstractCommand.class);
  private static Object _lock = new Object();
  private String _createTimeAttributeName;
  private String _updateTimeAttributeName;
  private Integer _inClauseThreshold;
  private Integer _maxNumOfInChunks;
  private Long _memoryInsteadTempTableLowThreshold;
  private Long _memoryInsteadTempTableHighThreshold;
  private Boolean _updateClassModelEnabled;
  public static final String DATA_MODEL_TABLE_NAME_PREFIX = "CDM_";
  public static final String DATA_MODEL_TABLE_NAME_DELIMITER = "_";
  protected static final String LIST_OF_ATTRIBUTES_DUMMY_CLASS_NAME = "LIST_ATTR_PRIMITIVE";
  protected static final String LIST_OF_ATTRIBUTES_ATTRIBUTE_NAME_COLUMN_NAME = "ATTR_NAME";
  protected static final String LIST_OF_ATTRIBUTES_ATTRIBUTE_VALUE_COLUMN_NAME = "ATTR_VALUE";
  protected static final String CLASS_MODEL_MIGRATION_TABLE_NAME = "CCM_MIGR_TBL";
  protected static final String UNIFIED_NAME_COLUMN_NAME = "UNIFIED_NAME";
  protected static final String SEPERATE_NAME_COLUMN_NAME = "SEPARATE_NAME";
  protected static final String CMDB_ID_TEMP_TABLE_NAME = "CDM_TMP_OBJID";
  protected static final String STRING_TEMP_TABLE_NAME = "CDM_TMP_STR";
  protected static final String NUMBER_TEMP_TABLE_NAME = "CDM_TMP_INT";
  protected static final String CMDB_ID_STR_TEMP_TABLE_NAME = "CDM_TMP_OBJID_STR";
  protected static final String CLASS_MODEL_TEMP_TABLE_NAME = "CCM_TMP_EID";
  protected static final String TEMP_TABLE_VALUE_COLUMN_NAME = "T_VALUE";
  protected static final String TEMP_TABLE_VALUES_INDEX_COLUMN_NAME = "T_VALUES_INDEX";
  protected static final String DATA_TABLE_SPACE_NAME = "CMDBDATA";
  protected static final String INDEX_TABLE_SPACE_NAME = "CMDBINDEX";
  protected static final String PRIMARY_KEY_PREFIX = "PK_";
  protected static final String FOREIGN_KEY_PREFIX = "FK1_";
  protected static final String INDEX_PREFIX = "IX1_";
  protected static final String UNIQUE_INDEX_PREFIX = "UIX1_";
  public static final int MAX_SIZE_BYTES_COLUMN = 2000;
  public static final String OBJECT_CLASS_NAME = "object";
  public static final String NONE_CLASS_NAME = "none";
  public static final String ROOT_CLASS_NAME = "root";
  public static final String LINK_CLASS_NAME = "link";
  protected static final String CMDB_ID_COLUMN_NAME = "CMDB_ID";
  protected static final String CLASS_COLUMN_NAME = "CLASS";
  protected static final String ROOT_CLASS_ATTRIBUTE_NAME = "root_class";
  protected static final String LINK_END1_ID_COLUMN_NAME = "END1_ID";
  protected static final String LINK_END2_ID_COLUMN_NAME = "END2_ID";
  protected static final String ADD_LINK_ID_COLUMN_NAME = "ADD_LINK_ID";
  protected static final String ENTITY_ID_COLUMN_NAME = "ENTITY_ID";
  protected static final String CUSTOMER_ID_COLUMN_NAME = "CUSTOMER_ID";
  protected static final String CLASS_ID_COLUMN_NAME = "CLASS_ID";
  protected static final String LINK_VALID_LINK_ID_COLUMN_NAME = "VALID_LINK_ID";
  protected static final String CALCULATED_LINK_TRIPLET_ID_COLUMN_NAME = "TRIPLET_ID";
  protected static final String CREATE_TIME_ATTRIBUTE_NAME = "dal.datamodel.createtime.attribute.name";
  protected static final String UPDATE_TIME_ATTRIBUTE_NAME = "dal.datamodel.updatetime.attribute.name";
  protected static final String IN_CLAUSE_THRESHOLD_ORACLE_KEY = "dal.in.clause.threshold.oracle";
  protected static final String IN_CLAUSE_THRESHOLD_MSSQL_KEY = "dal.in.clause.threshold.mssql";
  protected static final int IN_CLAUSE_THRESHOLD_ORACLE = 15;
  protected static final int IN_CLAUSE_THRESHOLD_MSSQL = 100;
  protected static final String MAX_NUM_OF_IN_CHUNKS_ORACLE_KEY = "dal.num.of.in.chunks.oracle";
  protected static final String MAX_NUM_OF_IN_CHUNKS_MSSQL_KEY = "dal.num.of.in.chunks.mssql";
  protected static final int MAX_NUM_OF_IN_CHUNKS_ORACLE = 1;
  protected static final int MAX_NUM_OF_IN_CHUNKS_MSSQL = 1;
  protected static final String USE_MEMORY_INSTEAD_TEMP_TABLE_LOW_THRESHOLD_ORACLE_KEY = "dal.use.memory.instead.temp.table.low.threshold.oracle";
  protected static final String USE_MEMORY_INSTEAD_TEMP_TABLE_LOW_THRESHOLD_MSSQL_KEY = "dal.use.memory.instead.temp.table.low.threshold.mssql";
  protected static final long MEMORY_INSTEAD_TEMP_TABLE_LOW_THRESHOLD_ORACLE = 100000L;
  protected static final long MEMORY_INSTEAD_TEMP_TABLE_LOW_THRESHOLD_MSSQL = 1410065408L;
  protected static final String USE_MEMORY_INSTEAD_TEMP_TABLE_HIGH_THRESHOLD_ORACLE_KEY = "dal.use.memory.instead.temp.table.high.threshold.oracle";
  protected static final String USE_MEMORY_INSTEAD_TEMP_TABLE_HIGH_THRESHOLD_MSSQL_KEY = "dal.use.memory.instead.temp.table.high.threshold.mssql";
  protected static final long MEMORY_INSTEAD_TEMP_TABLE_HIGH_THRESHOLD_ORACLE = 600000L;
  protected static final long MEMORY_INSTEAD_TEMP_TABLE_HIGH_THRESHOLD_MSSQL = 1410065408L;
  public static final String UPDTAE_CLASS_MODEL_ENABLED_KEY = "dal.update.class.model.enabled";

  public CmdbDalAbstractCommand()
  {
    this._createTimeAttributeName = null;
    this._updateTimeAttributeName = null;

    this._inClauseThreshold = null;

    this._maxNumOfInChunks = null;

    this._memoryInsteadTempTableLowThreshold = null;

    this._memoryInsteadTempTableHighThreshold = null;

    this._updateClassModelEnabled = null;
  }

  public CmdbDalCommandResult<RESULT> execute()
  {
    addCommandToStackTrace();

    Throwable err = null;
    try
    {
      validateInput();

      prepare();

      if ((_logger.isDebugEnabled()) && 
        (getCommandName() != null)) {
        _logger.debug(getTabShift() + getCommandName());
      }

      Object result = perform();

      postProcess();

      CmdbDalCommandResult localCmdbDalCommandResult1 = createCommandResult(result);

      return localCmdbDalCommandResult1;
    }
    catch (CmdbDalValidationException e)
    {
      err = e;
      CmdbDalCommandResult localCmdbDalCommandResult2 = createCommandResult(null);

      return localCmdbDalCommandResult2;
    }
    catch (Throwable e)
    {
      throw new CmdbDalException("Failed to execute " + DalCallStack.get(), e);
    } finally {
      removeCommandFromStackTrace(err);
    }
  }

  private String getTabShift() {
    return LogUtil.indent();
  }

  private void removeCommandFromStackTrace(Throwable t) {
    DalCallStack.pop(t);
  }

  private void addCommandToStackTrace() {
    DalCallStack.push(this);
  }

  public String toString() {
    String className = super.getClass().getName();
    return className.substring(className.lastIndexOf(46) + 1);
  }

  protected String getCommandName()
  {
    return null;
  }

  protected void prepare()
    throws Exception
  {
  }

  protected void postProcess()
    throws Exception
  {
  }

  protected abstract RESULT perform()
    throws Exception;

  protected abstract void validateInput();

  private CmdbDalCommandResult<RESULT> createCommandResult(RESULT result)
  {
    if (result instanceof CmdbDalCommandResult)
    {
      return ((CmdbDalCommandResult)result);
    }
    return new CmdbDalCommandResult(result);
  }

  protected CmdbDalConnection getConnection() {
    return TransactionManager.getConnection();
  }

  protected DBType getDbType() {
    return getConnection().getDBType();
  }

  protected boolean isOracle() {
    return DBType.isOracle(getDbType());
  }

  protected boolean isMsSql() {
    return DBType.isMsSql(getDbType());
  }

  protected LocalEnvironment getLocalEnvironment() {
    return ServerApiFacade.getLocalEnvironment();
  }

  protected CmdbCustomerID getCustomerID() {
    return getLocalEnvironment().getCustomerID();
  }

  protected String getTableNameByClassName(String classFullQualifiedName)
  {
    if (isUpdateClassModelEnabled()) {
      return getCustomerTableNameByClassName(classFullQualifiedName);
    }

    return getConsolidatedTableNameByClassName(classFullQualifiedName);
  }

  protected String getConsolidatedTableNameByClassName(String classFullQualifiedName)
  {
    return mapClassName2TableName(classFullQualifiedName, 0);
  }

  protected String getCustomerTableNameByClassName(String classFullQualifiedName) {
    int customerID = getCustomerID().getID();
    return mapClassName2TableName(classFullQualifiedName, customerID);
  }

  private String mapClassName2TableName(String classFullQualifiedName, int customerID) {
    String[] parsedClassName = CmdbQualifiedNameFactory.parseQualifiedName(classFullQualifiedName);
    String nameSpace = parsedClassName[0] + "_";
    String className = parsedClassName[1];

    String tableName = "CDM_" + nameSpace + className + "_" + customerID;

    tableName = DalClassModelUtil.fixLongName(tableName);

    return tableName;
  }

  protected boolean checkTableExistence(String tableName)
  {
    CmdbDalCommand checkTableExistenceCommand = CmdbDalCommandFactory.createCheckTableExistenceSimpleCommand(tableName);
    CmdbDalCommandResult result = checkTableExistenceCommand.execute();
    return ((Boolean)result.getResult()).booleanValue();
  }

  protected String getCreateTimeAttributeName() {
    if (this._createTimeAttributeName == null) {
      SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();
      this._createTimeAttributeName = settingsReader.getString("dal.datamodel.createtime.attribute.name", "root_createtime");
    }
    return this._createTimeAttributeName;
  }

  protected String getUpdateTimeAttributeName() {
    if (this._updateTimeAttributeName == null) {
      SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();
      this._updateTimeAttributeName = settingsReader.getString("dal.datamodel.updatetime.attribute.name", "root_updatetime");
    }
    return this._updateTimeAttributeName;
  }

  protected boolean isUpdateClassModelEnabled() {
    if (this._updateClassModelEnabled == null) {
      SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();
      this._updateClassModelEnabled = Boolean.valueOf(settingsReader.getBoolean("dal.update.class.model.enabled", true));
    }
    return this._updateClassModelEnabled.booleanValue();
  }

  protected int getMaxPossibleSizeForInChunk() {
    return getInClauseThreshold();
  }

  private int getInClauseThreshold() {
    if (this._inClauseThreshold == null) {
      int defaultVal;
      int inClauseThreshold;
      SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();

      if (isOracle()) {
        defaultVal = 15;
        inClauseThreshold = settingsReader.getInt("dal.in.clause.threshold.oracle", defaultVal);
      } else if (isMsSql()) {
        defaultVal = 100;
        inClauseThreshold = settingsReader.getInt("dal.in.clause.threshold.mssql", defaultVal);
      } else {
        throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
      }

      setInClauseThreshold(inClauseThreshold);
    }
    return this._inClauseThreshold.intValue();
  }

  private void setInClauseThreshold(int inClauseThreshold) {
    this._inClauseThreshold = Integer.valueOf(inClauseThreshold);
  }

  protected int getMaxNumOfInChunks() {
    if (this._maxNumOfInChunks == null) {
      int defaultVal;
      int numOfInChunks;
      SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();

      if (isOracle()) {
        defaultVal = 1;
        numOfInChunks = settingsReader.getInt("dal.num.of.in.chunks.oracle", defaultVal);
      } else if (isMsSql()) {
        defaultVal = 1;
        numOfInChunks = settingsReader.getInt("dal.num.of.in.chunks.mssql", defaultVal);
      } else {
        throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
      }

      setMaxNumOfInChunks(numOfInChunks);
    }
    return this._maxNumOfInChunks.intValue();
  }

  private void setMaxNumOfInChunks(int maxNumOfInChunks) {
    this._maxNumOfInChunks = Integer.valueOf(maxNumOfInChunks);
  }

  protected long getMemoryInsteadTempTableLowThreshold() {
    if (this._memoryInsteadTempTableLowThreshold == null) {
      long defaultVal;
      long memoryInsteadTempTableLowThreshold;
      SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();

      if (isOracle()) {
        defaultVal = 100000L;
        memoryInsteadTempTableLowThreshold = settingsReader.getLong("dal.use.memory.instead.temp.table.low.threshold.oracle", defaultVal);
      } else if (isMsSql()) {
        defaultVal = 1410065408L;
        memoryInsteadTempTableLowThreshold = settingsReader.getLong("dal.use.memory.instead.temp.table.low.threshold.mssql", defaultVal);
      } else {
        throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
      }

      setMemoryInsteadTempTableLowThreshold(memoryInsteadTempTableLowThreshold);
    }
    return this._memoryInsteadTempTableLowThreshold.longValue();
  }

  private void setMemoryInsteadTempTableLowThreshold(long memoryInsteadTempTableLowThreshold) {
    this._memoryInsteadTempTableLowThreshold = Long.valueOf(memoryInsteadTempTableLowThreshold);
  }

  protected long getMemoryInsteadTempTableHighThreshold() {
    if (this._memoryInsteadTempTableHighThreshold == null) {
      long defaultVal;
      long memoryInsteadTempTableHighThreshold;
      SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();

      if (isOracle()) {
        defaultVal = 600000L;
        memoryInsteadTempTableHighThreshold = settingsReader.getLong("dal.use.memory.instead.temp.table.high.threshold.oracle", defaultVal);
      } else if (isMsSql()) {
        defaultVal = 1410065408L;
        memoryInsteadTempTableHighThreshold = settingsReader.getLong("dal.use.memory.instead.temp.table.high.threshold.mssql", defaultVal);
      } else {
        throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
      }

      setMemoryInsteadTempTableHighThreshold(memoryInsteadTempTableHighThreshold);
    }
    return this._memoryInsteadTempTableHighThreshold.longValue();
  }

  private void setMemoryInsteadTempTableHighThreshold(long memoryInsteadTempTableHighThreshold) {
    this._memoryInsteadTempTableHighThreshold = Long.valueOf(memoryInsteadTempTableHighThreshold);
  }

  protected boolean hasNextElement(Object iterator) {
    if (iterator instanceof Iterator)
      return ((Iterator)iterator).hasNext();

    if (iterator instanceof ReadOnlyIterator)
      return ((ReadOnlyIterator)iterator).hasNext();

    throw new CmdbDalException("Unknown iterator class [" + iterator.getClass() + "]");
  }

  protected Object getNextElement(Object iterator) {
    if (iterator instanceof Iterator)
      return ((Iterator)iterator).next();

    if (iterator instanceof ReadOnlyIterator)
      return ((ReadOnlyIterator)iterator).next();

    throw new CmdbDalException("Unknown iterator class [" + iterator.getClass() + "]");
  }

  protected Long generateAndConfirmSequenceID()
  {
    CmdbDalCommand generateSequenceIDCommand = CmdbDalClassModelCommandFactory.createGenerateAndConfirmSequenceIDComplexCommand();

    CmdbDalCommandResult result = generateSequenceIDCommand.execute();

    return ((Long)result.getResult());
  }

  protected Long generateSequenceID(String generatorName)
  {
    CmdbDalCommand generateSequenceIDCommand = CmdbDalClassModelCommandFactory.createGenerateSequenceIDComplexCommand(generatorName);

    CmdbDalCommandResult result = generateSequenceIDCommand.execute();

    return ((Long)result.getResult());
  }

  protected void setUseDirtyRead()
  {
    if (isMsSql())
      getConnection().setTransactionIsolation(1);
  }

  protected ConnectionPoolManager getConnectionPool()
  {
    return getConnection().getConnectionPool();
  }

  protected static Object getLock() {
    return _lock;
  }
}