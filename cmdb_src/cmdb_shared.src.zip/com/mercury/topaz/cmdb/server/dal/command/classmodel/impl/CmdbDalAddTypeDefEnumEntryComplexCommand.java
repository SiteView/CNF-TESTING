package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItem;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItems;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnumEntry;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalAddTypeDefEnumEntryComplexCommand extends CmdbDalAbstractTypeDefComplexCommand
{
  private CmdbEnum _cmdbEnum = null;
  private CmdbEnumEntry _enumEntry = null;
  private Long _cmdbEnumId = null;
  private Integer _enumIndex = null;

  public CmdbDalAddTypeDefEnumEntryComplexCommand(CmdbEnumEntry enumEntry, CmdbEnum cmdbEnum, Integer orderingIndex, Long typeDefId)
  {
    setCmdbEnum(cmdbEnum);
    setEnumEntry(enumEntry);
    setCmdbEnumId(typeDefId);
    setEnumIndex(orderingIndex);
  }

  protected void validateInput() {
    if ((getCmdbEnum() == null) || (getEnumEntry() == null))
      throw new CmdbDalException("Can't add cmdbenum entry. Null cmdbenum or null cmdbenum entry !!!");
  }

  protected Object perform() throws Exception
  {
    addEnumEntry(getConnection(), getCmdbEnum(), getCmdbEnumId());
    return null;
  }

  private void addEnumEntry(CmdbDalConnection connection, CmdbEnum typeDefEnum, Long typeDefID)
    throws SQLException
  {
    Long uniqueID = null;
    int enumIndex = getEnumIndex().intValue();

    String sqlString = createInsertTypeDefEnumTableSql();
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);
    CmdbType valueType = typeDefEnum.getType();

    CmdbEnumEntry enumEntry = getEnumEntry();

    preparedStatement.setLong(typeDefID);
    String enumValueString = (enumEntry.getEnumValue() == null) ? null : valueType.stringValue(enumEntry.getEnumValue());
    preparedStatement.setString(enumValueString);
    preparedStatement.setInt(enumEntry.getEnumKey());
    uniqueID = generateAndConfirmSequenceID();
    preparedStatement.setLong(uniqueID);
    preparedStatement.setBoolean(enumEntry.isCreatedByFactory());
    preparedStatement.setBoolean(enumEntry.isModifiedByUser());
    preparedStatement.setInt(enumIndex);

    preparedStatement.executeUpdate();

    DataItems dataItems = enumEntry.getDataItems();
    addTypeDefDataItems(dataItems, connection, typeDefID, enumEntry.getEnumKey());
    preparedStatement.close();
  }

  private void addTypeDefDataItems(DataItems dataItems, CmdbDalConnection connection, Long typeDefID, int enumKey)
    throws SQLException
  {
    String sqlString = createInsertTypeDefDataItemsTableSql();
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

    if ((dataItems != null) && (!(dataItems.isEmpty()))) {
      ReadOnlyIterator dataItemsIter = dataItems.getIterator();
      int dataItemsIndex = 0;

      while (dataItemsIter.hasNext()) {
        DataItem dataItem = (DataItem)dataItemsIter.next();
        preparedStatement.setLong(typeDefID);
        preparedStatement.setInt(enumKey);
        preparedStatement.setString(dataItem.getName());
        preparedStatement.setString(dataItem.getType().getName());
        preparedStatement.setString(dataItem.getValue().toString());
        preparedStatement.setBoolean(dataItem.isCreatedByFactory());
        preparedStatement.setBoolean(dataItem.isModifiedByUser());
        ++dataItemsIndex;
        preparedStatement.setInt(dataItemsIndex);

        preparedStatement.addBatch();
      }
    }

    preparedStatement.executeBatch();
    preparedStatement.close();
  }

  private String createInsertTypeDefDataItemsTableSql() {
    List columnsNames = createTypeDefDataItemsTableColumnsNames();

    return createInsertSql("CCM_TDEFDITEM", columnsNames);
  }

  private CmdbEnumEntry getEnumEntry() {
    return this._enumEntry;
  }

  private void setEnumEntry(CmdbEnumEntry enumEntry) {
    this._enumEntry = enumEntry;
  }

  private CmdbEnum getCmdbEnum() {
    return this._cmdbEnum;
  }

  private void setCmdbEnum(CmdbEnum cmdbEnum) {
    this._cmdbEnum = cmdbEnum;
  }

  private Long getCmdbEnumId() throws SQLException {
    Long typeDefId = this._cmdbEnumId;
    if (typeDefId == null) {
      typeDefId = getTypeDefID(getConnection(), getCmdbEnum());
      setCmdbEnumId(typeDefId);
    }
    return this._cmdbEnumId;
  }

  private void setCmdbEnumId(Long cmdbEnumId) {
    this._cmdbEnumId = cmdbEnumId;
  }

  private Integer getEnumIndex() throws SQLException {
    Integer enumIndex = this._enumIndex;

    if (enumIndex == null) {
      int lastOrderingIndex = getLastOrderingIndex("ENUM_INDEX", "CCM_TDEF_ENUM", "TYPE_DEF_ID", getCmdbEnumId());
      enumIndex = new Integer(lastOrderingIndex + 1);
      setEnumIndex(enumIndex);
    }
    return enumIndex;
  }

  private void setEnumIndex(Integer enumIndex) {
    this._enumIndex = enumIndex;
  }
}