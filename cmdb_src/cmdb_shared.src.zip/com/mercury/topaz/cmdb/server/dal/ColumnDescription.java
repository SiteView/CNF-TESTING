package com.mercury.topaz.cmdb.server.dal;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;

public class ColumnDescription
{
  private String name;
  private CmdbType cmdbType;
  private DBColumnType dbType;
  private Integer size;
  private boolean isNullable = true;
  private String defaultValue = null;

  public ColumnDescription(String name)
  {
    this.name = name;
  }

  public String getName() {
    return this.name;
  }

  public ColumnDescription ofCmdbType(CmdbType type) {
    this.cmdbType = type;
    return this;
  }

  public DBColumnType getType() {
    if (this.dbType == null)
      this.dbType = getDBTypeFromCmdbType(this.cmdbType, this.size);

    return this.dbType;
  }

  public ColumnDescription ofType(DBColumnType type) {
    this.dbType = type;
    return this;
  }

  public Integer getSize() {
    return this.size;
  }

  public ColumnDescription ofSize(int size) {
    this.size = Integer.valueOf(size);
    return this;
  }

  public boolean isNullable() {
    return this.isNullable;
  }

  public ColumnDescription setNullable(boolean nullable) {
    this.isNullable = nullable;
    return this;
  }

  public ColumnDescription nullable() {
    this.isNullable = true;
    return this;
  }

  public ColumnDescription notNullable() {
    this.isNullable = false;
    return this;
  }

  public String getDefaultValue() {
    return this.defaultValue;
  }

  public void setDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
  }

  public ColumnDescription ofDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
    return this;
  }

  private static DBColumnType getDBTypeFromCmdbType(CmdbType type, Integer sizeLimit)
  {
    DBColumnType dbType;
    if (type instanceof CmdbEnum)
      return getDBTypeFromCmdbType(CmdbSimpleTypes.CmdbInteger, sizeLimit);
    if (type instanceof CmdbList) {
      CmdbList typeDefList = (CmdbList)type;
      return getDBTypeFromCmdbType(typeDefList.getType(), sizeLimit); }
    if (type instanceof CmdbExternalResource)
      return getDBTypeFromCmdbType(CmdbSimpleTypes.CmdbString, sizeLimit);
    if (CmdbSimpleTypes.CmdbBoolean.equals(type))
      dbType = DBColumnType.BOOLEAN;
    else if (CmdbSimpleTypes.CmdbBytes.equals(type))
      if ((sizeLimit != null) && (sizeLimit.intValue() > 2000))
        dbType = DBColumnType.BLOB;
      else
        dbType = DBColumnType.VARBINARY;

    else if (CmdbSimpleTypes.CmdbDate.equals(type))
      dbType = DBColumnType.LONG;
    else if (CmdbSimpleTypes.CmdbDouble.equals(type))
      dbType = DBColumnType.DOUBLE;
    else if (CmdbSimpleTypes.CmdbFloat.equals(type))
      dbType = DBColumnType.FLOAT;
    else if (CmdbSimpleTypes.CmdbInteger.equals(type))
      dbType = DBColumnType.INTEGER;
    else if (CmdbSimpleTypes.CmdbLong.equals(type))
      dbType = DBColumnType.LONG;
    else if (CmdbSimpleTypes.CmdbString.equals(type))
      dbType = DBColumnType.VARCHAR;
    else if (CmdbSimpleTypes.CmdbXml.equals(type))
      dbType = DBColumnType.CLOB;
    else
      throw new CmdbDalException("Can't get db type to cmdb type [" + type + "]");

    return dbType;
  }
}