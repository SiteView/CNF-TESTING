package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalAddValidLinkComplexCommand extends CmdbDalClassModelComplexCommand
{
  private CmdbValidLink _validLink = null;

  public CmdbDalAddValidLinkComplexCommand(CmdbValidLink validLink)
  {
    setValidLink(validLink);
  }

  protected void validateInput() {
    if (getValidLink() == null)
      throw new CmdbDalException("Can't add null valid link");
  }

  protected Object perform()
  {
    addValidLink(getValidLink());

    return null;
  }

  private CmdbValidLink getValidLink() {
    return this._validLink;
  }

  private void setValidLink(CmdbValidLink validLink) {
    this._validLink = validLink; }

  public void addValidLink(CmdbValidLink validLink) {
    CmdbDalConnection connection;
    try {
      connection = getConnection();
      Long validLinkID = generateAndConfirmSequenceID();

      addValidLink(connection, validLink, validLinkID);
      addValidLinkQualifiers(validLink, validLinkID);
    }
    catch (Exception e) {
      String errMsg = "Error adding valid link [" + validLink.getLinkClassName() + "], end1 [" + validLink.getEnd1ClassName() + "], end2 [" + validLink.getEnd2ClassName() + "], due to exception: " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }

  private void addValidLink(CmdbDalConnection connection, CmdbValidLink validLink, Long validLinkID) throws SQLException {
    String sqlString = createInsertValidLinksTableSql();
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    preparedStatement.setLong(validLinkID);
    preparedStatement.setString(validLink.getLinkClassName());
    preparedStatement.setString(validLink.getEnd1ClassName());
    preparedStatement.setString(validLink.getEnd2ClassName());
    preparedStatement.setLong(customerID.getID());

    preparedStatement.setInt(null);
    preparedStatement.setInt(null);
    preparedStatement.setInt(null);
    preparedStatement.setInt(null);

    preparedStatement.setBoolean(validLink.isCreatedByFactory());
    preparedStatement.setBoolean(validLink.isModifiedByUser());

    preparedStatement.executeUpdate();

    preparedStatement.close();
  }

  private void addValidLinkQualifiers(CmdbValidLink validLink, Long validLinkID) {
    CmdbDalCommand addValidLinkQualifiersCommand = CmdbDalClassModelCommandFactory.createAddValidLinkQualifiersComplexCommand(validLink, validLink.getValidLinkQualifiers(), validLinkID);
    addValidLinkQualifiersCommand.execute();
  }

  private String createInsertValidLinksTableSql() {
    List columnsNames = createValidLinksTableColumnsNames();

    return createInsertSql("CCM_VALIDLINK", columnsNames);
  }
}