package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbModifiableAttributeQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.impl.CmdbAttributeQualifierFactory;
import java.sql.SQLException;

public class CmdbDalRemoveAttributeQualifiersComplexCommand extends CmdbDalRemoveQualifiersComplexCommand
{
  private CmdbClass _cmdbClass = null;
  private CmdbAttributeOverride _cmdbAttribute = null;

  public CmdbDalRemoveAttributeQualifiersComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, BasicContainer qualifires, Long entityId)
  {
    super(qualifires, entityId);
    setCmdbClass(cmdbClass);
    setCmdbAttribute(cmdbAttribute);
  }

  public CmdbDalRemoveAttributeQualifiersComplexCommand(CmdbAttributeOverride cmdbAttribute, CmdbClass cmdbClass, CmdbAttributeQualifier qualifier, Long entityId) {
    super(null, entityId);
    CmdbModifiableAttributeQualifiers qualifiers = CmdbAttributeQualifierFactory.createAttributeQualifiers();
    qualifiers.add(qualifier);
    setQualifires(qualifiers);
    setCmdbClass(cmdbClass);
    setCmdbAttribute(cmdbAttribute);
  }

  protected String getCommandName() {
    return "Remove attribute qualifiers [" + getQualifires() + "] of cmdb class [" + getCmdbClass().getName() + "], attribute [" + getCmdbAttribute() + "]";
  }

  protected Long getEntityIdFromDB() throws SQLException {
    return getAttributeID(getCmdbAttribute().getName(), getCmdbClass().getName(), getConnection());
  }

  protected CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass;
  }

  protected CmdbAttributeOverride getCmdbAttribute() {
    return this._cmdbAttribute;
  }

  private void setCmdbAttribute(CmdbAttributeOverride cmdbAttribute) {
    this._cmdbAttribute = cmdbAttribute;
  }
}