package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CmdbDalGetIndicesByColumnSimpleCommand extends CmdbDalAbstractCommand<List<String>>
{
  private String _tableName = null;
  private String _columnName = null;

  public CmdbDalGetIndicesByColumnSimpleCommand(String tableName, String columnName)
  {
    setTableName(tableName);
    setColumnName(columnName);
  }

  protected void validateInput() {
    if ((getTableName() == null) || (getTableName().length() == 0) || (getColumnName() == null) || (getColumnName().length() == 0))
    {
      throw new CmdbDalException("Can't get indices for column [" + getColumnName() + "], in table [" + getTableName() + "]");
    }
  }

  protected List<String> perform() throws Exception {
    return getIndicesNames();
  }

  private List<String> getIndicesNames() throws SQLException
  {
    String sqlString;
    List indexesNames = new ArrayList();

    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;

    if (isOracle())
      sqlString = "SELECT INDEX_NAME FROM USER_IND_COLUMNS WHERE TABLE_NAME=? AND COLUMN_NAME=?";
    else if (isMsSql()) {
      sqlString = "SELECT name FROM sysindexkeys ik join sysindexes i on ik.indid = i.indid and ik.id = i.id where object_name(ik.id) = ? and indexproperty(ik.id,i.name,'IsStatistics') = 0 and col_name(ik.id,ik.colid)=?";
    }
    else
    {
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
    }
    try
    {
      preparedStatement = getConnection().prepareStatement4Select(sqlString);
      preparedStatement.setString(getTableName());
      preparedStatement.setString(getColumnName());

      resultSet = preparedStatement.executeQuery();

      while (resultSet.next()) {
        indexesNames.add(resultSet.getString(1));
      }

      resultSet.close();
      preparedStatement.close();

      List localList1 = indexesNames;

      return localList1;
    }
    finally
    {
      if (resultSet != null) resultSet.close();
      if (preparedStatement != null) preparedStatement.close();
    }
  }

  private String getTableName() {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    this._tableName = tableName;
  }

  private String getColumnName() {
    return this._columnName;
  }

  private void setColumnName(String columnName) {
    this._columnName = columnName;
  }
}