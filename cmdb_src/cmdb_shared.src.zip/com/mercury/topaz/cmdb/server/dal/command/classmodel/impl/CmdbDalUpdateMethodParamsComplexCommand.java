package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import java.sql.SQLException;

public class CmdbDalUpdateMethodParamsComplexCommand extends CmdbDalUpdateMethodPropertyComplexCommand
{
  public CmdbDalUpdateMethodParamsComplexCommand(CmdbMethod method, CmdbClass cmdbClass)
  {
    super(method, cmdbClass);
  }

  protected String getCommandName() {
    return "Update params of method [" + getMethod().getName() + "] in class [" + getCmdbClass().getName() + "] to [" + getMethod().getParams() + "]";
  }

  protected String getColumnNameToUpdate() {
    return "PARAMS";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long methodId) throws SQLException {
    String paramsAsString = createMethodParamsString(getMethod().getParams());
    preparedStatement.setString(paramsAsString);
    preparedStatement.setBoolean(getMethod().isModifiedByUser());
    preparedStatement.setLong(methodId);
  }
}