package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnumEntry;
import java.sql.SQLException;

public abstract class CmdbDalUpdateTypeDefEnumEntryPropertyComplexCommand extends CmdbDalUpdatePropertyComplexCommand
{
  private CmdbEnum _cmdbEnum = null;
  private CmdbEnumEntry _cmdbEnumEntry = null;
  private Long _cmdbEnumId = null;

  public CmdbDalUpdateTypeDefEnumEntryPropertyComplexCommand(CmdbEnumEntry cmdbEnumEntry, CmdbEnum cmdbEnum, Long cmdbEnumId)
  {
    super(null);
    setCmdbEnumEntry(cmdbEnumEntry);
    setCmdbEnum(cmdbEnum);
    setCmdbEnumId(cmdbEnumId);
  }

  protected void validateInput() {
    if (getCmdbEnumEntry() == null)
      throw new CmdbDalException("Can't update null enum entry");

    if (getCmdbEnum() == null)
      throw new CmdbDalException("Can't update null enum");
    try
    {
      if (getCmdbEnumId() == null)
        throw new CmdbDalException("Can't update enum with null id");
    }
    catch (SQLException se) {
      throw new CmdbDalException("Can't get enum id.", se);
    }
  }

  protected String getTableNameToUpdate() {
    return "CCM_TDEF_ENUM";
  }

  protected String getRowIdConditionColumnName() {
    return "ID";
  }

  protected Long getRowId() throws SQLException {
    Long enumEntryID = getEnumEntryID(getCmdbEnumId(), getCmdbEnumEntry(), getConnection());
    return enumEntryID;
  }

  protected CmdbEnumEntry getCmdbEnumEntry() {
    return this._cmdbEnumEntry;
  }

  private void setCmdbEnumEntry(CmdbEnumEntry cmdbEnumEntry) {
    this._cmdbEnumEntry = cmdbEnumEntry;
  }

  protected CmdbEnum getCmdbEnum() {
    return this._cmdbEnum;
  }

  private void setCmdbEnum(CmdbEnum cmdbEnum) {
    this._cmdbEnum = cmdbEnum;
  }

  protected Long getCmdbEnumId() throws SQLException {
    Long typeDefId = this._cmdbEnumId;
    if (typeDefId == null) {
      typeDefId = getTypeDefID(getConnection(), getCmdbEnum());
      setCmdbEnumId(typeDefId);
    }
    return this._cmdbEnumId;
  }

  private void setCmdbEnumId(Long cmdbEnumId) {
    this._cmdbEnumId = cmdbEnumId;
  }
}