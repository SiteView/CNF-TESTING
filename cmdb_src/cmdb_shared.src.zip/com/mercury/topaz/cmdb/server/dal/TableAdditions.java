package com.mercury.topaz.cmdb.server.dal;

import java.util.Collection;

public abstract interface TableAdditions
{
  public abstract void addColumn(ColumnDescription paramColumnDescription);

  public abstract void addIndex(IndexDescription paramIndexDescription);

  public abstract Collection<IndexDescription> getIndexesToAdd();

  public abstract Collection<ColumnDescription> getColumnsToAdd();
}