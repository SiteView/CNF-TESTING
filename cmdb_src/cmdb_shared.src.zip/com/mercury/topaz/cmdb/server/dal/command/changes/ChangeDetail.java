package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;

public class ChangeDetail
{
  private CmdbDataID elementId;
  private String elementType;
  private CmdbObjectID end1Id;
  private CmdbObjectID end2Id;
  private boolean isAdd;
  private boolean isObject;

  public ChangeDetail()
  {
    this.end1Id = null;
    this.end2Id = null;
  }

  public void addingObject(CmdbObject object)
  {
    this.elementId = ((CmdbDataID)object.getID());
    this.elementType = object.getType();
    this.isAdd = true;
    this.isObject = true;
  }

  public void removingObject(CmdbObject object) {
    this.elementId = ((CmdbDataID)object.getID());
    this.elementType = object.getType();
    this.isAdd = false;
    this.isObject = true;
  }

  public void addingLink(CmdbLink link) {
    this.elementId = ((CmdbDataID)link.getID());
    this.elementType = link.getType();
    this.end1Id = link.getEnd1();
    this.end2Id = link.getEnd2();
    this.isAdd = true;
    this.isObject = false;
  }

  public void removingLink(CmdbLink link) {
    this.elementId = ((CmdbDataID)link.getID());
    this.elementType = link.getType();
    this.end1Id = link.getEnd1();
    this.end2Id = link.getEnd2();
    this.isAdd = false;
    this.isObject = false;
  }

  public CmdbDataID getElementID() {
    return this.elementId;
  }

  public String getElementType() {
    return this.elementType;
  }

  public CmdbDataID getEnd1Id() {
    return this.end1Id;
  }

  public CmdbDataID getEnd2Id() {
    return this.end2Id;
  }

  public boolean isAdd() {
    return this.isAdd;
  }

  public boolean isObject() {
    return this.isObject;
  }
}