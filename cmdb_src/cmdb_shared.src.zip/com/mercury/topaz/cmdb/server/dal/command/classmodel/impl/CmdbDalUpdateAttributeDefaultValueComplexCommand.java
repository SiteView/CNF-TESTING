package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import java.sql.SQLException;

public class CmdbDalUpdateAttributeDefaultValueComplexCommand extends CmdbDalUpdateAttributePropertyComplexCommand
{
  public CmdbDalUpdateAttributeDefaultValueComplexCommand(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass)
  {
    super(attributeOverride, cmdbClass);
  }

  protected String getCommandName() {
    return "Update default value of attribute [" + getAttribute().getName() + "] in class [" + getCmdbClass().getName() + "] to [" + getAttribute().getDefaultValue() + "]";
  }

  protected String getColumnNameToUpdate() {
    return "DEFAULT_VALUE";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long attributeId) throws SQLException {
    preparedStatement.setClob(getAttribute().getDefaultValue());
    preparedStatement.setBoolean(getAttribute().isModifiedByUser());
    preparedStatement.setLong(attributeId);
  }
}