package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.EmptyModelLinks;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.link.id.impl.CmdbLinkIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

public class CmdbDalGetCmdbLinksByCondition extends CmdbDalLinksConditionComplexCommand
{
  private int chunkSize;

  public CmdbDalGetCmdbLinksByCondition(LinkCondition linkCondition)
  {
    super(linkCondition, EmptyModelLinks.getInstance());
    this.chunkSize = -1;
  }

  public CmdbDalGetCmdbLinksByCondition(LinkCondition condition, int maxCount)
  {
    super(condition, EmptyModelLinks.getInstance());
    this.chunkSize = maxCount;
  }

  protected Object perform() throws Exception {
    if ((getCondition() == null) || (getCondition().getClassCondition() == null))
      return CmdbLinkFactory.createLinks();

    return performQueryCondition();
  }

  protected Object getResult(CmdbDalResultSet resultSet) throws SQLException {
    if (this.chunkSize > 0) {
      return buildCmdbLinks(resultSet);
    }

    resultSet.next();
    int count = resultSet.getInt("ci_count").intValue();
    resultSet.close();
    return new Integer(count);
  }

  private CmdbLinkIds buildCmdbLinks(CmdbDalResultSet resultSet)
    throws SQLException
  {
    CmdbLinkIds data = CmdbLinkIdsFactory.create();
    while (resultSet.next())
    {
      byte[] linkIdAsBytes = resultSet.getBytes(1);
      CmdbLinkID linkID = restoreLinkID(linkIdAsBytes);
      data.add(linkID);
    }
    return data;
  }

  protected CmdbIDsCollection<? extends CmdbDataID> extractConditionIDs(Object modelElements, ElementCondition condition) {
    if ((condition.getIdsCondition() != null) && (!(isEmptyContainer(condition.getIdsCondition().getLinkIds()))))
      return condition.getIdsCondition().getLinkIds();

    return CmdbLinkIdsFactory.create();
  }

  protected void addSelectSql(StringBuffer conditionSql, Set<String> participatedClasses, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) {
    StringBuffer selectSql = new StringBuffer();
    String conditionClassName = getCondition().getClassCondition().getClassName();
    String rootTable = getDummyClassName("root", getClassNameSuffix());
    String condClassTable = getDummyClassName(conditionClassName, getClassNameSuffix());
    String linksTable = getDummyClassName("link", getClassNameSuffix());
    String itworldTable = getDummyClassName("it_world", getClassNameSuffix());

    if (this.chunkSize < 0) {
      selectSql.append("SELECT COUNT(").append(linksTable).append(".").append("CMDB_ID").append(") AS ci_count ");
    }
    else
    {
      if (isMsSql()) {
        selectSql.append("SELECT TOP ").append(Integer.toString(this.chunkSize)).append(" ");
      }
      else
        selectSql.append("SELECT ");

      selectSql.append(linksTable).append(".");
      selectSql.append("CMDB_ID");
    }

    participatedClasses.add(linksTable);
    participatedClasses.add(rootTable);
    addFromSql(selectSql, participatedClasses);

    selectSql.append(" WHERE ");
    if (this.chunkSize > 0) {
      if (isOracle()) {
        selectSql.append(" ROWNUM <= ").append(Integer.toString(this.chunkSize)).append(" ");
      }
      else
        selectSql.append("1=1");

    }
    else
      selectSql.append("1=1");

    addPairsJoinSql(selectSql, participatedClasses, bindVariables, bindVariablesTypes);
    selectSql.append(" AND ");
    selectSql.append(getExistClause(linksTable, itworldTable, "END1_ID"));
    selectSql.append(" AND ");
    selectSql.append(getExistClause(linksTable, itworldTable, "END2_ID"));
    selectSql.append(" AND ");
    selectSql.append(getExistClause(linksTable, condClassTable, "CMDB_ID"));

    conditionSql.insert(0, selectSql);
  }

  String getExistClause(String linkTabl, String tabl, String fld) {
    StringBuffer result = new StringBuffer();
    result.append(" EXISTS (SELECT 1 FROM ").append(tabl).append(" ").append(tabl);
    result.append(" WHERE ").append(linkTabl).append(".").append(fld).append(" = ").append(tabl).append(".").append("CMDB_ID").append(")");

    return result.toString();
  }
}