package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;

public class CmdbDalAddObjectsFineGrainComplexCommand extends CmdbDalAddObjectsComplexCommand
{
  public CmdbDalAddObjectsFineGrainComplexCommand(CmdbObjects objects)
  {
    super(objects);
  }

  protected Object perform() {
    return fineGrainedPerform();
  }
}