package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import java.sql.SQLException;

public class CmdbDalUpdateTypeDefDescriptionComplexCommand extends CmdbDalUpdateTypeDefPropertyComplexCommand
{
  public CmdbDalUpdateTypeDefDescriptionComplexCommand(CmdbTypeDef typeDef)
  {
    super(typeDef);
  }

  protected String getColumnNameToUpdate() {
    return "DESCRIPTION";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long typeDefId) throws SQLException {
    preparedStatement.setString(getTypeDef().getDescription());
    preparedStatement.setBoolean(getTypeDef().isModifiedByUser());
    preparedStatement.setLong(typeDefId);
  }

  protected String getCommandName() {
    return "Update description of type def [" + getTypeDef().getName() + "] to [" + getTypeDef().getDescription() + "]";
  }
}