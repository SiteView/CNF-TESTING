package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.model.aging.AgingPropertiesUpdater;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.dal.exception.CmdbDalValidationException;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.impl.CmdbDatasFactory;
import com.mercury.topaz.cmdb.shared.model.data.impl.CmdbDatasImpl;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

abstract class CmdbDalAddElementsComplexCommand<E extends CmdbData<? extends CmdbDataID>> extends CmdbDalDataModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalAddElementsComplexCommand.class);
  private CmdbDatas<?, E> _cmdbDatas = null;

  protected CmdbDalAddElementsComplexCommand(CmdbDatas<?, E> datas)
  {
    setCmdbElements(datas);
  }

  protected void validateInput() {
    if ((getCmdbElements() == null) || (getCmdbElements().isEmpty()))
      throw new CmdbDalValidationException("Can't add null or empty cmdb element");
  }

  protected Object perform()
  {
    addElements(getCmdbElements());
    return null;
  }

  protected CmdbDatas<?, E> getCmdbElements() {
    return this._cmdbDatas;
  }

  private void setCmdbElements(CmdbDatas<?, E> cmdbElements) {
    this._cmdbDatas = cmdbElements;
  }

  protected void addElements(List<E> elements, String type, CmdbDalConnection connection, Date currentTime) throws SQLException {
    if (_logger.isDebugEnabled()) {
      _logger.debug("Add [" + elements.size() + "] elements from type: " + type);
    }

    CmdbClass cmdbClass = ClassModelUtil.getCmdbClassByName(type);

    String listOfAttributesInsertSql = createInsert2ListOfAttributesTableSql();
    CmdbDalPreparedStatement listOfAttributesPreparedStatement = connection.prepareStatement4Update(listOfAttributesInsertSql);

    CmdbAttributes attributes = ClassModelUtil.extractPersistentAttributes(cmdbClass);

    String sqlString = createInsertSql(cmdbClass.getName(), attributes);
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

    for (Iterator it = elements.iterator(); it.hasNext(); preparedStatement.addBatch()) {
      CmdbData element = (CmdbData)it.next();
      byte[] elementIdAsBytes = AbstractCMDBDigest.toBytes((AbstractCMDBDigest)element.getID());
      preparedStatement.setBytes(elementIdAsBytes);

      if (!(isUpdateClassModelEnabled()))
        preparedStatement.setInt(getCustomerID().getID());

      handleRoot(cmdbClass, element, preparedStatement);
      handleLink(cmdbClass, element, preparedStatement);

      if (attributes != null) { if (attributes.isEmpty())
          break label579:

        ReadOnlyIterator attributesIter = attributes.getIterator();
        while (true) { CmdbProperty property;
          CmdbPropertyValues propertyValues;
          CmdbSimpleType valuesType;
          while (true) { if (!(attributesIter.hasNext())) break label579;
            CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();
            property = element.getProperty(attribute.getName());
            if (!(attribute.getResolvedType() instanceof CmdbSimpleList)) {
              Object propertyValue = ((property == null) || (property.isValueEmpty())) ? null : property.getValue();

              if (attribute.getName().equals(getCreateTimeAttributeName()))
                preparedStatement.setDate(currentTime);
              else if (attribute.getName().equals(getUpdateTimeAttributeName()))
                preparedStatement.setDate(currentTime);
              else if (attribute.getName().equals("root_class"))
                preparedStatement.setString(element.getType());
              else
                DalTypeUtil.setObject(preparedStatement, propertyValue, attribute.getResolvedType(), attribute.getSizeLimit());

              break label576: } if ((property == null) || (property.isValueEmpty())) break label576;
            propertyValues = (CmdbPropertyValues)property.getValue();
            valuesType = ((CmdbSimpleList)attribute.getResolvedType()).getMembersType();

            if (!(propertyValues.isEmpty()))
              break;
          }
          ReadOnlyIterator valuesIter = propertyValues.valuesIterator();
          while (valuesIter.hasNext()) {
            Object value = valuesIter.next();

            listOfAttributesPreparedStatement.setBytes(elementIdAsBytes);
            listOfAttributesPreparedStatement.setString(property.getKey());
            listOfAttributesPreparedStatement.setString(valuesType.stringValue(value));
            if (!(isUpdateClassModelEnabled())) {
              listOfAttributesPreparedStatement.setInt(getCustomerID().getID());
            }

            label576: label579: listOfAttributesPreparedStatement.addBatch();
          }
        }
      }
    }
    preparedStatement.executeBatch();
    preparedStatement.close();
    listOfAttributesPreparedStatement.executeBatch();
    listOfAttributesPreparedStatement.close();
  }

  protected void handleLink(CmdbClass cmdbClass, E element, CmdbDalPreparedStatement preparedStatement) throws SQLException {
  }

  protected void handleRoot(CmdbClass cmdbClass, E element, CmdbDalPreparedStatement preparedStatement) throws SQLException {
    if (cmdbClass.getName().equalsIgnoreCase("root"))
      preparedStatement.setString(element.getType());
  }

  protected void addElements(CmdbDatas<?, E> elements)
  {
    if (_logger.isDebugEnabled())
      _logger.debug("Add [" + elements.size() + "] elements");
    try
    {
      elements = addTimes(elements);

      Map elementsFromSameTypeMap = sortElementsToTypes(elements);

      Date currentTime = getCurrentTime();

      for (Iterator i$ = elementsFromSameTypeMap.keySet().iterator(); i$.hasNext(); ) { String type = (String)i$.next();
        List elementsFromSameTypeList = (List)elementsFromSameTypeMap.get(type);
        try
        {
          addElements(elementsFromSameTypeList, type, getConnection(), currentTime);
        } catch (Exception e) {
          String errMsg = "Error adding cmdb elements from type [" + type + "], due to exception: " + e;
          throw new CmdbDalException(errMsg, e);
        }
      }
    }
    catch (Exception e) {
      String errMsg = "Error adding cmdb elements [" + elements + "], due to exception: " + e;
      _logger.error(errMsg);
      throw new CmdbDalException("Error adding cmdb elements. Check log for details !!!", e);
    }
  }

  private CmdbDatas<?, E> addTimes(CmdbDatas<?, E> elements) {
    AgingPropertiesUpdater agingPropertiesUpdater = new AgingPropertiesUpdater(getSynchronizedClassModel(), getLocalEnvironment().getSettingsReader(), null);

    Map timeProps = agingPropertiesUpdater.getTimeProperties(elements, new HashMap());
    CmdbDatas ret = new CmdbDatasImpl();
    for (Iterator i$ = elements.iterator(); i$.hasNext(); ) { CmdbData data = (CmdbData)i$.next();
      String type = data.getType();
      CmdbProperties props = (CmdbProperties)timeProps.get(type);
      ret.add(addPropertiesToData(data, props));
    }
    return ret;
  }

  protected abstract E addPropertiesToData(E paramE, CmdbProperties paramCmdbProperties);

  protected Object fineGrainedPerform() {
    for (ReadOnlyIterator it = getCmdbElements().getDatasIterator(); it.hasNext(); ) {
      CmdbDatas oneElement = CmdbDatasFactory.create();
      oneElement.add((CmdbData)it.next());
      addElements(oneElement);
    }
    return null;
  }
}