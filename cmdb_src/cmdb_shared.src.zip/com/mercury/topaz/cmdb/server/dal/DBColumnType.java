package com.mercury.topaz.cmdb.server.dal;

public enum DBColumnType
{
  BOOLEAN, INTEGER, LONG, FLOAT, DOUBLE, DATE, VARCHAR, VARBINARY, CLOB, BLOB;

  public static final DBColumnType[] values()
  {
    return ((DBColumnType[])$VALUES.clone());
  }
}