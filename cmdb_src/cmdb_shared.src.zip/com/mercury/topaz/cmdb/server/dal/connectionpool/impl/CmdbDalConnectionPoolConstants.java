package com.mercury.topaz.cmdb.server.dal.connectionpool.impl;

public class CmdbDalConnectionPoolConstants
{
  public static final int MAX_SIZE_BYTES_COLUMN = 2000;
}