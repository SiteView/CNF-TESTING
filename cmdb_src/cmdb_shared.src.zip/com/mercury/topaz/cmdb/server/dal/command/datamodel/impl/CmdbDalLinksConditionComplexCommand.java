package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.ModelLinksFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.link.id.impl.CmdbLinkIdsFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalLinksConditionComplexCommand extends CmdbDalConditionComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalLinksConditionComplexCommand.class);
  private ModelLinks _modelLinks = null;

  public CmdbDalLinksConditionComplexCommand(LinkCondition linkCondition, ModelLinks links)
  {
    super(linkCondition);
    setModelLinks(links);
  }

  protected void validateInput() {
    super.validateInput();

    if (getModelLinks() == null)
      _logger.info("Can't perform condition for links - null model links !!!");
  }

  protected Object perform() throws Exception
  {
    if ((getModelLinks() == null) || (getModelLinks().size() == 0) || (getCondition() == null) || (getCondition().getClassCondition() == null))
      return ModelLinksFactory.createLinks();

    if (_logger.isDebugEnabled())
      _logger.debug("Perform links query for [" + getModelLinks().size() + "] links");

    return performQueryCondition();
  }

  protected Object getResult(CmdbDalResultSet resultSet) throws SQLException
  {
    CmdbLinkIds resultIDs = buildCmdbIDs(resultSet);
    ModelLinks resultLinks = ModelLinksFactory.createLinks();
    ReadOnlyIterator linksIter = getModelLinks().getLinksIterator();

    while (linksIter.hasNext()) {
      ModelLink link = (ModelLink)linksIter.next();
      if (resultIDs.contains(link.getID()))
        resultLinks.add(link);
    }

    return resultLinks;
  }

  protected boolean hasConditionIDs(Object conditionIDs) {
    return (!(isEmptyContainer((CmdbLinkIds)conditionIDs)));
  }

  protected void createCmdbIDTempTable(Object conditionIDs, CmdbDalConnection connection) throws SQLException {
    createCmdbIDTempTable(connection, (CmdbLinkIds)conditionIDs);
  }

  protected void addIDsToBindVariables(CmdbIDsCollection<? extends CmdbDataID> conditionIDs, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) {
    ReadOnlyIterator linkIDsIter = conditionIDs.getIdsIterator();
    while (linkIDsIter.hasNext()) {
      CmdbDataID linkID = (CmdbDataID)linkIDsIter.next();

      byte[] linkIDAsBytes = convertCmdbID2Bytes(linkID);
      bindVariables.add(linkIDAsBytes);
      bindVariablesTypes.add(CmdbSimpleTypes.CmdbBytes);
    }
  }

  protected int getContainerSize(Object container) {
    if (container instanceof CmdbLinkIds) {
      CmdbLinkIds cmdbLinkIds = (CmdbLinkIds)container;
      return cmdbLinkIds.size();
    }
    throw new CmdbDalException("Container from type [" + container.getClass() + "] is not supported !!!");
  }

  protected CmdbIDsCollection<? extends CmdbDataID> extractConditionIDs(Object modelElements, ElementCondition condition) {
    if (hasModelElements(modelElements)) {
      return extractCmdbLinkIds((ModelLinks)modelElements);
    }

    throw new CmdbDalException("Can't handle links condition with no links !!!");
  }

  private CmdbLinkIds buildCmdbIDs(CmdbDalResultSet resultSet) throws SQLException
  {
    int maxResults = getLocalEnvironment().getSettingsReader().getInt("dal.link.condition.max.result.size", 500000);
    int currentResultCount = 0;

    CmdbLinkIds ids = CmdbLinkIdsFactory.create();
    while (resultSet.next())
    {
      ++currentResultCount;
      if (currentResultCount > maxResults) {
        String errMsg = "Number of Link condition results exceeded the maximum allowed (max allowed value is: " + maxResults + ")";
        throw new CmdbDalException(errMsg);
      }

      byte[] idAsBytes = resultSet.getBytes(1);
      CmdbLinkID linkID = restoreLinkID(idAsBytes);

      ids.add(linkID);
    }
    return ids;
  }

  protected boolean hasModelElements(Object modelElements) {
    return (!(isEmptyContainer((ModelLinks)modelElements)));
  }

  protected Object getModelElements() {
    return getModelLinks();
  }

  private ModelLinks getModelLinks() {
    return this._modelLinks;
  }

  private void setModelLinks(ModelLinks modelLinks) {
    this._modelLinks = modelLinks;
  }
}