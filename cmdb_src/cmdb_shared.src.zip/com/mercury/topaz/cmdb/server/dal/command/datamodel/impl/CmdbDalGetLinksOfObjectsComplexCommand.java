package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalGetLinksOfObjectsComplexCommand extends CmdbDalGetTriplesComplexCommand
{
  public CmdbDalGetLinksOfObjectsComplexCommand(ElementCondition elementCondition, LinkCondition linkCondition)
  {
    super(elementCondition, linkCondition, createAnyObjectCondition());
  }

  private static ElementCondition createAnyObjectCondition() {
    ElementClassCondition objectClassCondition = PatternConditionFactory.createElementClassCondition("object", true);

    return PatternConditionFactory.createElementCondition(objectClassCondition);
  }

  protected String createQuerySql(CmdbDalConnection connection, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) throws SQLException {
    String querySql = super.createQuerySql(connection, bindVariables, bindVariablesTypes);
    querySql = querySql + " UNION ALL ";
    CmdbDalGetTriplesComplexCommand reverseDirectionCommand = new CmdbDalGetTriplesComplexCommand(createAnyObjectCondition(), getLinkCondition(), getEnd1Condition());
    querySql = querySql + reverseDirectionCommand.createQuerySql(connection, bindVariables, bindVariablesTypes);
    return querySql;
  }
}