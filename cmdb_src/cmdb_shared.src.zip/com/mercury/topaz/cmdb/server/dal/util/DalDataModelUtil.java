package com.mercury.topaz.cmdb.server.dal.util;

import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalUpdateTableRemoveColumnsComplexCommand;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalUpdateTableUpdateColumnsComplexCommand;
import com.mercury.topaz.cmdb.server.dal.dao.CmdbDalDataModelDAO;
import com.mercury.topaz.cmdb.server.dal.dao.impl.CmdbDalDAOFactory;
import com.mercury.topaz.cmdb.server.dal.util.table.TableUtils;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class DalDataModelUtil
{
  public static void handleQualifiersAddition(CmdbClass cmdbClass, String attrName, BasicContainer<CmdbAttributeQualifier> qualifiers)
  {
    ReadOnlyIterator iter = qualifiers.getIterator();
    while (iter.hasNext()) {
      CmdbAttributeQualifier qualifier = (CmdbAttributeQualifier)iter.next();
      if (qualifier.getName().equals(CmdbAttributeQualifierDefs.MIRRORED.getName())) {
        CmdbClass attributeBaseClass = ClassModelUtil.getAttributeBaseClass(attrName, cmdbClass);

        String sourceTable = DalClassModelUtil.getTableNameByClassName(attributeBaseClass.getName());

        String destinationTable = DalClassModelUtil.getTableNameByClassName(cmdbClass.getName());

        String columnName = DalClassModelUtil.getColumnNameByAttributeName(attrName);

        CmdbAttribute attr = cmdbClass.getAttributeByName(attrName);
        ColumnDescription columnDescription = DalClassModelUtil.createColumnDescFromAttribute(attr);

        TableModifications mods = new TableModifications();
        mods.addColumn(columnDescription);

        if (ClassModelUtil.isIndexedAttribute(attr)) {
          mods.addIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(attrName)));
        }

        TableUtils.mirrorColumn(sourceTable, destinationTable, columnName, mods);

        return; }
    }
  }

  public static void handleQualifiersRemoval(CmdbClass cmdbClass, String attrName, BasicContainer<CmdbAttributeQualifier> qualifiers) {
    ReadOnlyIterator iter = qualifiers.getIterator();
    while (iter.hasNext()) {
      CmdbAttributeQualifier qualifier = (CmdbAttributeQualifier)iter.next();
      if (qualifier.getName().equals(CmdbAttributeQualifierDefs.MIRRORED.getName())) {
        CmdbAttribute attr = cmdbClass.getAttributeByName(attrName);

        String tableName = DalClassModelUtil.getTableNameByClassName(cmdbClass.getName());

        TableDescription tableDescription = new TableDescription(tableName);

        TableModifications mods = new TableModifications();

        CmdbDalDataModelDAO dao = CmdbDalDAOFactory.createDataModelDAO();

        if (ClassModelUtil.isIndexedAttribute(attr)) {
          mods.removeIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(attrName)));
          dao.execute(new CmdbDalUpdateTableUpdateColumnsComplexCommand(tableDescription, mods));
        }

        ColumnDescription columnDescription = DalClassModelUtil.createColumnDescFromAttribute(attr);
        mods.removeColumn(columnDescription);
        dao.execute(new CmdbDalUpdateTableRemoveColumnsComplexCommand(tableDescription, mods));

        return;
      }
    }
  }
}