package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommandAttributeOrder;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommandOrderDirection;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CmdbDalSortLinksComplexCommand extends CmdbDalDataModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalSortObjectsComplexCommand.class);
  CmdbSortCommand _sortCommand;
  private ModelLinks _modelLinks;
  private Map<CmdbLinkID, String> _linkTypes;

  public CmdbDalSortLinksComplexCommand(ModelLinks modelLinks, CmdbSortCommand sortCommand)
  {
    setModelLinks(modelLinks);
    setSortCommand(sortCommand);
    init();
  }

  private void init() {
    Map linkTypes = new HashMap(getModelLinks().size());
    for (Iterator i$ = getModelLinks().iterator(); i$.hasNext(); ) { ModelLink modelLink = (ModelLink)i$.next();
      linkTypes.put(modelLink.getID(), modelLink.getType());
    }
    setLinkTypes(linkTypes);
  }

  protected void validateInput() {
    if ((getModelLinks() == null) || (getModelLinks().size() == 0))
      _logger.info("Can't sort links - empty or null model links. Returns empty list");
  }

  protected Object perform()
  {
    if ((getModelLinks() == null) || (getModelLinks().size() == 0))
      return CmdbLinkFactory.createEmptyLinks();

    if (_logger.isDebugEnabled()) {
      _logger.debug("Sort links for [" + getModelLinks().size() + "] links, sort by [" + getSortCommand().toString() + "]");
    }

    return getLinksOrder(getModelLinks());
  }

  private Object getLinksOrder(ModelLinks modelLinks)
  {
    List attributeList = getSortAttrList();

    ModelLink modelLink = (ModelLink)modelLinks.getLinksIterator().next();
    String baseClassName = getBaseCmdbClass(modelLink.getType(), attributeList);

    List persistentAttrNames = extractPersistentAttrNames(attributeList.iterator(), baseClassName);
    Map attributes2ClassesMap = createAttributes2ClassesMap(new ReadOnlyIteratorImpl(persistentAttrNames.iterator()), ClassModelUtil.getCmdbClassByName(baseClassName));

    return getSortedLinks(modelLinks, baseClassName, attributes2ClassesMap);
  }

  private List getSortAttrList()
  {
    List attrList = new ArrayList(getSortCommand().size());

    for (ReadOnlyIterator iter = getSortCommand().getAttributeOrderIterator(); iter.hasNext(); ) {
      CmdbSortCommandAttributeOrder attributeOrder = (CmdbSortCommandAttributeOrder)iter.next();
      String attributeName = attributeOrder.getAttributeName();
      attrList.add(attributeName);
    }
    return attrList;
  }

  protected Object getSortedLinks(ModelLinks modelLinks, String baseClassName, Map attributes2ClassesMap)
  {
    CmdbDalConnection connection = null;
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet result = null;
    try
    {
      connection = getConnection();

      if (isCmdbIDTempTableMustUsingChunksMechanism(modelLinks.size())) {
        createCmdbIDTempTable(connection, modelLinks);
      }

      List orderByAttributesList = getOrderByAttributesList();

      Set classes = extractRequiredClassNames(orderByAttributesList, attributes2ClassesMap);
      classes.add("link");
      classes.add(baseClassName);

      String sqlString = createSelectStatement();
      sqlString = sqlString + createFromStatement(classes);
      sqlString = sqlString + createWhereStatement(baseClassName, classes, modelLinks.size());
      sqlString = sqlString + getSortClause(attributes2ClassesMap);
      preparedStatement = connection.prepareStatement4Select(sqlString);
      addValuesToPrepareStatement(preparedStatement, modelLinks, null);
      result = preparedStatement.executeQuery();

      Object resultLinks = buildCmdbLinks(result);
      Object localObject1 = resultLinks;

      return localObject1;
    }
    catch (Exception e)
    {
    }
    finally
    {
      String errMsg;
      if (result != null)
        result.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private Set extractRequiredClassNames(List orderByAttributesList, Map attributes2ClassesMap)
  {
    Set classes = new HashSet();

    for (Iterator attrIter = orderByAttributesList.iterator(); attrIter.hasNext(); ) {
      String attributeName = (String)attrIter.next();
      String className = ((CmdbClass)attributes2ClassesMap.get(attributeName)).getName();
      classes.add(className);
    }
    return classes;
  }

  private String createSelectStatement()
  {
    StringBuffer sql = new StringBuffer();

    sql.append("SELECT ").append(getTableNameByClassName("link")).append(".");
    sql.append("CMDB_ID");
    sql.append(", ");
    sql.append(getTableNameByClassName("link")).append(".").append("END1_ID");
    sql.append(", ");
    sql.append(getTableNameByClassName("link")).append(".").append("END2_ID");
    return sql.toString();
  }

  private String createFromStatement(Set classes)
  {
    StringBuffer sql = new StringBuffer();
    sql.append(" FROM ");
    boolean comma = false;

    for (Iterator iter = classes.iterator(); iter.hasNext(); ) {
      String className = (String)iter.next();
      if (comma) sql.append(", ");
      sql.append(getTableNameByClassName(className));
      comma = true;
    }
    return sql.toString();
  }

  private String createWhereStatement(String baseCmdbClassName, Set classes, int numOfCmdbIDs)
  {
    StringBuffer sql = new StringBuffer();
    Object[] classesArray = classes.toArray();

    sql.append(" WHERE ");

    for (int i = 0; i < classesArray.length - 1; ++i) {
      String className1 = (String)classesArray[i];
      String className2 = (String)classesArray[(i + 1)];

      sql.append(getTableNameByClassName(className1)).append(".").append("CMDB_ID").append("=");
      sql.append(getTableNameByClassName(className2)).append(".").append("CMDB_ID").append(" AND ");

      if (!(isUpdateClassModelEnabled())) {
        sql.append(getTableNameByClassName(className1)).append(".").append("CUSTOMER_ID").append("=");
        sql.append(getTableNameByClassName(className2)).append(".").append("CUSTOMER_ID").append(" AND ");
      }

    }

    if (isCmdbIDTempTableMustUsingChunksMechanism(numOfCmdbIDs)) {
      sql.append(createJoinWithCmdbIDTempTableConditionSql(getTableNameByClassName(baseCmdbClassName), numOfCmdbIDs));
    }
    else
    {
      sql.append(getTableNameByClassName(baseCmdbClassName)).append(".").append("CMDB_ID");
      sql.append(getInSqlString(numOfCmdbIDs));
    }

    if (!(isUpdateClassModelEnabled())) {
      sql.append(" AND ").append(getTableNameByClassName(baseCmdbClassName)).append(".").append("CUSTOMER_ID");
      sql.append("=?");
    }

    return sql.toString();
  }

  private CmdbLinks buildCmdbLinks(CmdbDalResultSet resultSet) throws SQLException {
    CmdbLinks cmdbLinks = CmdbLinkFactory.createLinksListImpl(getModelLinks().size());
    while (resultSet.next())
    {
      byte[] linkIdAsBytes = resultSet.getBytes(1);
      CmdbLinkID linkID = restoreLinkID(linkIdAsBytes);

      byte[] end1IdAsBytes = resultSet.getBytes(2);
      CmdbObjectID end1Id = restoreObjectID(end1IdAsBytes);

      byte[] end2IdAsBytes = resultSet.getBytes(3);
      CmdbObjectID end2Id = restoreObjectID(end2IdAsBytes);

      String linkType = (String)getLinkTypes().get(linkID);
      if (linkType == null)
        throw new IllegalStateException("Link ID was not found in the map");

      cmdbLinks.add(CmdbLinkFactory.createLink(linkID, end1Id, end2Id, linkType));
    }
    return cmdbLinks;
  }

  private String getSortClause(Map attributes2ClassesMap)
  {
    StringBuffer sb = new StringBuffer();
    sb.append(" order by ");
    int i = 0;
    for (ReadOnlyIterator iter = getSortCommand().getAttributeOrderIterator(); iter.hasNext(); ++i) {
      CmdbSortCommandAttributeOrder attributeOrder = (CmdbSortCommandAttributeOrder)iter.next();
      String attributeName = attributeOrder.getAttributeName();
      String className = ((CmdbClass)attributes2ClassesMap.get(attributeName)).getName();

      if (i != 0) {
        sb.append(",");
      }

      sb.append(getTableNameByClassName(className)).append(".").append(DalClassModelUtil.getColumnNameByAttributeName(attributeName));
      sb.append(" ");
      sb.append(attributeOrder.getOrderDirection().getSQLName());
    }
    return sb.toString();
  }

  private List getOrderByAttributesList() {
    List orderByList = new ArrayList();
    for (ReadOnlyIterator iter = getSortCommand().getAttributeOrderIterator(); iter.hasNext(); ) {
      CmdbSortCommandAttributeOrder attributeOrder = (CmdbSortCommandAttributeOrder)iter.next();
      orderByList.add(attributeOrder.getAttributeName());
    }
    return orderByList;
  }

  private CmdbSortCommand getSortCommand()
  {
    return this._sortCommand;
  }

  private void setSortCommand(CmdbSortCommand sortCommand) {
    if (sortCommand == null)
      throw new IllegalArgumentException("sortCommand was null");

    this._sortCommand = sortCommand;
  }

  private ModelLinks getModelLinks() {
    return this._modelLinks;
  }

  private void setModelLinks(ModelLinks modelLinks) {
    if (modelLinks == null)
      throw new IllegalArgumentException("Received null");

    this._modelLinks = modelLinks;
  }

  private Map<CmdbLinkID, String> getLinkTypes() {
    return this._linkTypes;
  }

  private void setLinkTypes(Map<CmdbLinkID, String> linkTypes) {
    this._linkTypes = linkTypes;
  }
}