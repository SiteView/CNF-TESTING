package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethods;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbModifiableMethods;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.impl.CmdbMethodFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalAddMethodsComplexCommand extends CmdbDalClassModelComplexCommand
{
  private CmdbMethods _cmdbMethods = null;
  private CmdbClass _cmdbClass = null;
  private Long _classId = null;

  public CmdbDalAddMethodsComplexCommand(CmdbMethods cmdbMethods, CmdbClass cmdbClass, Long classId)
  {
    setCmdbMethods(cmdbMethods);
    setCmdbClass(cmdbClass);
    setClassId(classId);
  }

  public CmdbDalAddMethodsComplexCommand(CmdbMethod cmdbMethod, CmdbClass cmdbClass, Long classId)
  {
    CmdbModifiableMethods methods = CmdbMethodFactory.createMethods();
    methods.add(cmdbMethod);
    setCmdbMethods(methods);
    setCmdbClass(cmdbClass);
    setClassId(classId);
  }

  protected void validateInput() {
    if (getCmdbClass() == null)
      throw new CmdbDalException("Can't add methods of null cmdb class !!!");
  }

  protected Object perform() throws Exception
  {
    addMethods();
    return null;
  }

  protected String getCommandName() {
    return "Add methods [" + getCmdbMethods() + "] to cmdb class [" + getCmdbClass().getName() + "]";
  }

  private void addMethods()
    throws SQLException
  {
    CmdbDalConnection connection = getConnection();
    Long classID = getClassId();
    CmdbClass cmdbClass = getCmdbClass();

    CmdbMethods methods = getCmdbMethods();
    if ((methods != null) && (!(methods.isEmpty()))) {
      String sqlString = createInsertMethodsTableSql();
      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      ReadOnlyIterator methodsIter = methods.getIterator();
      while (methodsIter.hasNext()) {
        CmdbMethod method = (CmdbMethod)methodsIter.next();

        Long methodID = generateAndConfirmSequenceID();
        preparedStatement.setLong(methodID);
        preparedStatement.setLong(classID);
        preparedStatement.setString(method.getName());
        preparedStatement.setString(method.getType());
        preparedStatement.setString(method.getCommand());
        preparedStatement.setString(createMethodParamsString(method.getParams()));
        preparedStatement.setString(method.getDisplayName());
        preparedStatement.setString(method.getDescription());
        preparedStatement.setBoolean(method.isCreatedByFactory());
        preparedStatement.setBoolean(method.isModifiedByUser());

        preparedStatement.executeUpdate();

        CmdbDalCommand addMethodQualifiersCommand = CmdbDalClassModelCommandFactory.createAddMethodQualifiersComplexCommand(method, cmdbClass, method.getMethodQualifiers(), methodID);
        addMethodQualifiersCommand.execute();
      }

      preparedStatement.close();
    }
  }

  private String createInsertMethodsTableSql() {
    List columnsNames = createMethodsTableColumnsNames();

    return createInsertSql("CCM_METHODS", columnsNames);
  }

  private CmdbMethods getCmdbMethods() {
    return this._cmdbMethods;
  }

  private void setCmdbMethods(CmdbMethods cmdbMethods) {
    this._cmdbMethods = cmdbMethods;
  }

  private CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass;
  }

  private Long getClassId() throws SQLException {
    Long classId = this._classId;

    if (classId == null) {
      classId = getClassID(getCmdbClass().getName(), getConnection());
      setClassId(classId);
    }

    return classId;
  }

  private void setClassId(Long classId) {
    this._classId = classId;
  }
}