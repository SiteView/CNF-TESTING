package com.mercury.topaz.cmdb.server.dal;

public class ForeignKeyDescription
{
  private final String columnName;
  private final String referencedTableName;
  private String referencedColumnName;

  public ForeignKeyDescription(String columnName, String referencedTableName)
  {
    this.columnName = columnName;
    this.referencedTableName = referencedTableName;
    this.referencedColumnName = columnName;
  }

  public void setReferencedColumnName(String referencedColumnName) {
    this.referencedColumnName = referencedColumnName;
  }

  public String getColumnName() {
    return this.columnName;
  }

  public String getReferencedTableName() {
    return this.referencedTableName;
  }

  public String getReferencedColumnName() {
    return this.referencedColumnName;
  }
}