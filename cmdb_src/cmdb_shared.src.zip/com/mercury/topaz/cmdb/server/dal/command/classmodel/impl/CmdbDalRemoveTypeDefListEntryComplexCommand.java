package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import java.sql.SQLException;

public class CmdbDalRemoveTypeDefListEntryComplexCommand extends CmdbDalAbstractTypeDefComplexCommand
{
  private CmdbList _cmdbList = null;
  private CmdbListEntry _listEntry = null;
  private Long _cmdbListId = null;

  public CmdbDalRemoveTypeDefListEntryComplexCommand(CmdbListEntry listEntry, CmdbList cmdbList, Long cmdbListId)
  {
    setCmdbList(cmdbList);
    setListEntry(listEntry);
    setCmdbListId(cmdbListId);
  }

  protected void validateInput() {
    if ((getCmdbList() == null) || (getListEntry() == null))
      throw new CmdbDalException("Can't remove list entry. Null list or null list entry !!!");
  }

  protected Object perform() throws Exception
  {
    removeEnumEntry();
    return null;
  }

  private void removeEnumEntry() throws SQLException {
    CmdbDalConnection connection = getConnection();

    StringBuffer condition = new StringBuffer();
    condition.append("TYPE_DEF_ID").append("=? AND ").append("ENUM_VALUE").append("=?");

    CmdbType valueType = getCmdbList().getType();
    String enumValueString = (getListEntry().getListValue() == null) ? null : valueType.stringValue(getListEntry().getListValue());

    String sqlString = createDeleteSql("CCM_TDEF_ENUM", condition.toString());
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);
    preparedStatement.setLong(getCmdbListId());
    preparedStatement.setString(enumValueString);
    preparedStatement.executeUpdate();
    preparedStatement.close();
  }

  private CmdbListEntry getListEntry() {
    return this._listEntry;
  }

  private void setListEntry(CmdbListEntry listEntry) {
    this._listEntry = listEntry;
  }

  private CmdbList getCmdbList() {
    return this._cmdbList;
  }

  private void setCmdbList(CmdbList cmdbList) {
    this._cmdbList = cmdbList;
  }

  private Long getCmdbListId() throws SQLException {
    Long typeDefId = this._cmdbListId;
    if (typeDefId == null) {
      typeDefId = getTypeDefID(getConnection(), getCmdbList());
      setCmdbListId(typeDefId);
    }
    return this._cmdbListId;
  }

  private void setCmdbListId(Long cmdbListId) {
    this._cmdbListId = cmdbListId;
  }
}