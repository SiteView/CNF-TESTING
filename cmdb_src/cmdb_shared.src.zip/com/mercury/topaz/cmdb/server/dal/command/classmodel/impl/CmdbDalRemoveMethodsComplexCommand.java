package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethods;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbModifiableMethods;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.impl.CmdbMethodFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;

public class CmdbDalRemoveMethodsComplexCommand extends CmdbDalClassModelComplexCommand<Void>
{
  private CmdbMethods _cmdbMethods = null;
  private CmdbClass _cmdbClass = null;
  private Long _classId = null;

  public CmdbDalRemoveMethodsComplexCommand(CmdbMethods cmdbMethods, CmdbClass cmdbClass, Long classId)
  {
    setCmdbMethods(cmdbMethods);
    setCmdbClass(cmdbClass);
    setClassId(classId);
  }

  public CmdbDalRemoveMethodsComplexCommand(CmdbMethod cmdbMethod, CmdbClass cmdbClass, Long classId)
  {
    CmdbModifiableMethods methods = CmdbMethodFactory.createMethods();
    methods.add(cmdbMethod);
    setCmdbMethods(methods);
    setCmdbClass(cmdbClass);
    setClassId(classId);
  }

  protected void validateInput() {
    if (getCmdbClass() == null)
      throw new CmdbDalException("Can't remove methods of null cmdb class !!!");
  }

  protected Void perform() throws Exception
  {
    removeMethods();
    return null;
  }

  protected String getCommandName() {
    return "Remove methods [" + getCmdbMethods() + "] of cmdb class [" + getCmdbClass().getName() + "]";
  }

  private void removeMethods() throws SQLException {
    CmdbDalConnection connection = getConnection();
    Long classID = getClassId();
    CmdbClass cmdbClass = getCmdbClass();

    CmdbMethods methods = getCmdbMethods();
    if ((methods != null) && (!(methods.isEmpty()))) {
      StringBuffer condition = new StringBuffer();
      condition.append("CLASS_ID").append("=? AND ");
      condition.append("METHOD_ID").append("=?");

      String sqlString = createDeleteSql("CCM_METHODS", condition.toString());
      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      ReadOnlyIterator methodsIter = methods.getIterator();
      while (methodsIter.hasNext()) {
        CmdbMethod method = (CmdbMethod)methodsIter.next();

        Long methodId = getMethodID(method.getName(), cmdbClass.getName(), connection);
        removeQualifiers(method, cmdbClass, methodId);

        preparedStatement.setLong(classID);
        preparedStatement.setLong(methodId);
        preparedStatement.addBatch();
      }
      preparedStatement.executeBatch();
      preparedStatement.close();
    }
  }

  private void removeQualifiers(CmdbMethod method, CmdbClass cmdbClass, Long methodId) {
    CmdbDalCommand removeMethodQualifiersCommand = CmdbDalClassModelCommandFactory.createRemoveMethodQualifiersComplexCommand(method, cmdbClass, method.getMethodQualifiers(), methodId);
    removeMethodQualifiersCommand.execute();
  }

  private CmdbMethods getCmdbMethods()
  {
    return this._cmdbMethods;
  }

  private void setCmdbMethods(CmdbMethods cmdbMethods) {
    this._cmdbMethods = cmdbMethods;
  }

  private CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass;
  }

  private Long getClassId() throws SQLException {
    Long classId = this._classId;

    if (classId == null) {
      classId = getClassID(getCmdbClass().getName(), getConnection());
      setClassId(classId);
    }

    return classId;
  }

  private void setClassId(Long classId) {
    this._classId = classId;
  }
}