package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnumEntry;
import java.sql.SQLException;

public class CmdbDalUpdateTypeDefEnumEntryIsFactoryComplexCommand extends CmdbDalUpdateTypeDefEnumEntryPropertyComplexCommand
{
  public CmdbDalUpdateTypeDefEnumEntryIsFactoryComplexCommand(CmdbEnumEntry cmdbEnumEntry, CmdbEnum cmdbEnum, Long cmdbEnumId)
  {
    super(cmdbEnumEntry, cmdbEnum, cmdbEnumId);
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long enumEntryId) throws SQLException {
    preparedStatement.setBoolean(getCmdbEnumEntry().isCreatedByFactory());
    preparedStatement.setBoolean(getCmdbEnumEntry().isModifiedByUser());
    preparedStatement.setLong(enumEntryId);
  }

  protected String getColumnNameToUpdate() {
    return "IS_FACTORY";
  }

  protected String getCommandName() {
    return "Update is factory of enum entry [" + getCmdbEnumEntry().getEnumKey() + "-" + getCmdbEnumEntry().getEnumValue() + "] of type def [" + getCmdbEnum().getName() + "] to [" + getCmdbEnumEntry().isCreatedByFactory() + "]";
  }
}