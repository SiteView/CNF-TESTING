package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.dal.exception.CmdbDalValidationException;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CmdbDalRemoveElementsComplexCommand<E extends CmdbData<? extends CmdbDataID>> extends CmdbDalDataModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalRemoveElementsComplexCommand.class);
  private CmdbDatas<?, E> _cmdbElements = null;

  public CmdbDalRemoveElementsComplexCommand(CmdbDatas<?, E> elements)
  {
    setCmdbElements(elements);
  }

  protected void validateInput() {
    if ((getCmdbElements() == null) || (getCmdbElements().isEmpty()))
      throw new CmdbDalValidationException("Can't remove objects - null or empty objects");
  }

  protected void postProcess() throws Exception
  {
    truncateCmdbIDTempTable(getConnection());
  }

  protected Object perform() {
    removeElements(getCmdbElements());
    return null;
  }

  private CmdbDatas<?, E> getCmdbElements() {
    return this._cmdbElements;
  }

  protected void setCmdbElements(CmdbDatas<?, E> cmdbElements) {
    this._cmdbElements = cmdbElements;
  }

  private void removeElements(CmdbDatas<?, E> elements) {
    if (_logger.isDebugEnabled())
      _logger.debug("Removing [" + elements.size() + "] elements");
    try
    {
      List ids = elementsToIDsAsBytes(elements);

      if (isCmdbIDTempTableMustNotUsingChunksMechanism(ids.size())) {
        if (_logger.isDebugEnabled())
          _logger.debug("Filling temp table with " + ids.size() + " ids");

        createCmdbIDTempTable(getConnection(), ids);
        if (_logger.isDebugEnabled()) {
          _logger.debug("Finished");
        }

      }

      Map elementsFromSameTypeMap = sortElementsToTypes(elements);
      elementsFromSameTypeMap.put("LIST_ATTR_PRIMITIVE", Collections.emptyList());
      for (Iterator i$ = elementsFromSameTypeMap.keySet().iterator(); i$.hasNext(); ) { String type = (String)i$.next();

        removeObjects(ids, type, getConnection());
      }
    }
    catch (Exception e) {
      String errMsg = "Error removing cmdb objects [" + elements + "], due to exception: " + e;
      _logger.error(errMsg);
      throw new CmdbDalException("Error removing cmdb objects. Check log for details !!!", e);
    }
  }

  private void removeObjects(List<byte[]> ids, String type, CmdbDalConnection connection) {
    try {
      if (_logger.isDebugEnabled()) {
        _logger.debug("Removing elements from type: " + type);
      }

      String sqlString = createDeleteSql(type, ids.size());
      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      if (!(isCmdbIDTempTableMustNotUsingChunksMechanism(ids.size())))
        addIDsToPrepareStatement(preparedStatement, ids);

      if (!(isUpdateClassModelEnabled())) {
        preparedStatement.setInt(getCustomerID().getID());
      }

      preparedStatement.executeUpdate();
      preparedStatement.close();
      if (_logger.isDebugEnabled())
        _logger.debug("Finished removing elements from type: " + type);
    }
    catch (Exception e)
    {
      String errMsg = "Error removing cmdb elements from type [" + type + "], due to exception: " + e;
      throw new CmdbDalException(errMsg, e);
    }
  }
}