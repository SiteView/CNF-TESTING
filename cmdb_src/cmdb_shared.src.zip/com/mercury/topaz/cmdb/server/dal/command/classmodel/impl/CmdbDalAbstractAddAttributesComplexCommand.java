package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributeOverrides;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.impl.CmdbAttributeFactory;
import java.sql.SQLException;
import java.util.List;

public abstract class CmdbDalAbstractAddAttributesComplexCommand extends CmdbDalClassModelComplexCommand
{
  private BasicContainer _attributes = null;
  private CmdbClass _cmdbClass = null;
  private Long _classId = null;

  protected CmdbDalAbstractAddAttributesComplexCommand(BasicContainer attributes, CmdbClass cmdbClass, Long classId)
  {
    setAttributes(attributes);
    setCmdbClass(cmdbClass);
    setClassId(classId);
  }

  protected CmdbDalAbstractAddAttributesComplexCommand(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass, Long classId)
  {
    CmdbModifiableAttributeOverrides attributesOverrides = CmdbAttributeFactory.createAttributeOverrides();
    attributesOverrides.add(attributeOverride);
    setAttributes(attributesOverrides);
    setCmdbClass(cmdbClass);
    setClassId(classId);
  }

  protected void validateInput() {
    if (getCmdbClass() == null)
      throw new CmdbDalException("Can't add attributes of null cmdb class !!!");
  }

  protected Object perform() throws Exception
  {
    addAttributes();
    return null;
  }

  protected String getCommandName() {
    return "Add attributes [" + getAttributes() + "] to cmdb class [" + getCmdbClass().getName() + "]";
  }

  private void addAttributes() throws SQLException {
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalConnection connection = getConnection();
    try
    {
      String sqlString = createInsertAttributesTableSql();
      preparedStatement = connection.prepareStatement4Update(sqlString);

      fillPrepareStatementAndExecute(preparedStatement, getCmdbClass(), getClassId(), getAttributes());
    }
    finally {
      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  protected int getLastOrderingIndex() throws SQLException
  {
    return super.getLastOrderingIndex("ATTRIBUTE_INDEX", "CCM_ATTRIBUTE", "CLASS_ID", getClassId());
  }

  protected abstract void fillPrepareStatementAndExecute(CmdbDalPreparedStatement paramCmdbDalPreparedStatement, CmdbClass paramCmdbClass, Long paramLong, BasicContainer paramBasicContainer) throws SQLException;

  private String createInsertAttributesTableSql() {
    List columnsNames = createAttributesTableColumnsNames();

    return createInsertSql("CCM_ATTRIBUTE", columnsNames);
  }

  protected BasicContainer getAttributes()
  {
    return this._attributes;
  }

  protected void setAttributes(BasicContainer attributes) {
    this._attributes = attributes;
  }

  protected CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass;
  }

  protected Long getClassId() throws SQLException {
    Long classId = this._classId;

    if (classId == null) {
      classId = getClassID(getCmdbClass().getName(), getConnection());
      setClassId(classId);
    }

    return classId;
  }

  private void setClassId(Long classId) {
    this._classId = classId;
  }
}