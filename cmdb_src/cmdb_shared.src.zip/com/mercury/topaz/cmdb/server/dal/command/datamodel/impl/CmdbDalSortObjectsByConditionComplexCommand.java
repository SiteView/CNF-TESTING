package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.model.graph.object.impl.ModelObjectsFactory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommandAttributeOrder;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommandOrderDirection;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

class CmdbDalSortObjectsByConditionComplexCommand extends CmdbDalObjectsConditionComplexCommand
{
  private CmdbSortCommand _sortCommand;

  CmdbDalSortObjectsByConditionComplexCommand(ElementCondition condition, CmdbSortCommand sortCommand)
  {
    super(condition, ModelObjectsFactory.create());
    setSortCommand(sortCommand);
  }

  public String createConditionSql(CmdbDalConnection connection, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) throws SQLException {
    String sqlStatement = super.createConditionSql(connection, bindVariables, bindVariablesTypes);
    StringBuffer sb = new StringBuffer(sqlStatement);
    addOrderbySql(sb);
    return sb.toString();
  }

  private String addOrderbySql(StringBuffer sb) {
    sb.append(" order by ");
    int i = 0;
    for (ReadOnlyIterator iter = getSortCommand().getAttributeOrderIterator(); iter.hasNext(); ++i) {
      CmdbSortCommandAttributeOrder attributeOrder = (CmdbSortCommandAttributeOrder)iter.next();
      String attributeName = attributeOrder.getAttributeName();
      String className = getAttributeClassName(attributeName);

      if (i != 0) {
        sb.append(",");
      }

      sb.append(getDummyClassName(className, getClassNameSuffix())).append(".").append(DalClassModelUtil.getColumnNameByAttributeName(attributeName));
      sb.append(" ");
      sb.append(attributeOrder.getOrderDirection().getSQLName());
    }

    return sb.toString();
  }

  protected void addSelectSql(StringBuffer conditionSql, Set<String> participatedClasses, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) {
    StringBuffer selectSql = new StringBuffer();
    String conditionClassName = getCondition().getClassCondition().getClassName();
    selectSql.append("SELECT ").append(getDummyClassName(conditionClassName, getClassNameSuffix())).append(".");
    selectSql.append("CMDB_ID");

    for (ReadOnlyIterator iter = getSortCommand().getAttributeOrderIterator(); iter.hasNext(); ) {
      CmdbSortCommandAttributeOrder attributeOrder = (CmdbSortCommandAttributeOrder)iter.next();
      String attributeName = attributeOrder.getAttributeName();
      String className = getAttributeClassName(attributeName);

      selectSql.append(",");
      selectSql.append(getDummyClassName(className, getClassNameSuffix()));
      selectSql.append(".");
      selectSql.append(DalClassModelUtil.getColumnNameByAttributeName(attributeName));

      participatedClasses.add(getDummyClassName(className, getClassNameSuffix()));
    }

    participatedClasses.add(getDummyClassName(conditionClassName, getClassNameSuffix()));

    addFromSql(selectSql, participatedClasses);

    selectSql.append(" WHERE ");
    selectSql.append("1=1");

    addPairsJoinSql(selectSql, participatedClasses, bindVariables, bindVariablesTypes);

    conditionSql.insert(0, selectSql);
  }

  protected CmdbObjectIds buildCmdbIDs(CmdbDalResultSet resultSet)
    throws SQLException
  {
    int maxResults = getLocalEnvironment().getSettingsReader().getInt("dal.object.condition.max.result.size", 500000);
    int currentResultCount = 0;

    CmdbObjectIds ids = CmdbObjectIdsFactory.createIdsList();
    while (resultSet.next())
    {
      ++currentResultCount;
      if (currentResultCount > maxResults) {
        String errMsg = "Number of Object condition results exceeded the maximum allowed (max allowed value is: " + maxResults + ")";
        throw new CmdbDalException(errMsg);
      }

      byte[] idAsBytes = resultSet.getBytes(1);
      CmdbObjectID objectID = restoreObjectID(idAsBytes);

      ids.add(objectID);
    }
    return ids;
  }

  private String getAttributeClassName(String attributeName)
  {
    CmdbClass attributeClass = ClassModelUtil.getAttributeClass(attributeName, getCondition().getClassCondition().getClassName());
    return attributeClass.getName();
  }

  private CmdbSortCommand getSortCommand()
  {
    return this._sortCommand;
  }

  private void setSortCommand(CmdbSortCommand sortCommand) {
    if (sortCommand == null)
      throw new IllegalArgumentException("sortCommand was null");

    this._sortCommand = sortCommand;
  }
}