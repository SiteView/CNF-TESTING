package com.mercury.topaz.cmdb.server.dal.dao.impl;

import com.mercury.topaz.cmdb.server.dal.dao.CmdbDalClassModelDAO;
import com.mercury.topaz.cmdb.server.dal.dao.CmdbDalDataModelDAO;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;

public class CmdbDalDAOFactory
{
  public static CmdbDalDataModelDAO createDataModelDAO(LocalEnvironment localEnvironment)
  {
    return new CmdbDalJdbcDataModelDAO(localEnvironment);
  }

  public static CmdbDalDataModelDAO createDataModelDAO() {
    return createDataModelDAO(ServerApiFacade.getLocalEnvironment());
  }

  public static CmdbDalClassModelDAO createClassModelDAO(LocalEnvironment localEnvironment) {
    return new CmdbDalJdbcClassModelDAO(localEnvironment);
  }

  public static CmdbDalClassModelDAO createClassModelDAO() {
    return createClassModelDAO(ServerApiFacade.getLocalEnvironment());
  }
}