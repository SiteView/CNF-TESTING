package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import java.sql.SQLException;

public class CmdbDalUpdateMethodDisplayNameComplexCommand extends CmdbDalUpdateMethodPropertyComplexCommand
{
  public CmdbDalUpdateMethodDisplayNameComplexCommand(CmdbMethod method, CmdbClass cmdbClass)
  {
    super(method, cmdbClass);
  }

  protected String getCommandName() {
    return "Update display name of method [" + getMethod().getName() + "] in class [" + getCmdbClass().getName() + "] to [" + getMethod().getDisplayName() + "]";
  }

  protected String getColumnNameToUpdate() {
    return "DISPLAY_NAME";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long methodId) throws SQLException {
    preparedStatement.setString(getMethod().getDisplayName());
    preparedStatement.setBoolean(getMethod().isModifiedByUser());
    preparedStatement.setLong(methodId);
  }
}