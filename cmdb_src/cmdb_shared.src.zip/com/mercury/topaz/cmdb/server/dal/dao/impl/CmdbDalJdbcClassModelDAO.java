package com.mercury.topaz.cmdb.server.dal.dao.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.dal.command.classmodel.impl.AddAttributeOverride;
import com.mercury.topaz.cmdb.server.dal.command.classmodel.impl.CmdbDalClassModelCommandFactory;
import com.mercury.topaz.cmdb.server.dal.command.classmodel.impl.RemoveAttributeOverride;
import com.mercury.topaz.cmdb.server.dal.dao.CmdbDalClassModelDAO;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalDAO;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModelDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CalculatedLinkTripletDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.CmdbMethodQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.CmdbMethodQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.definition.CmdbMethodQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbClassQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbClassQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.diff.ClassModelDiffs;
import com.mercury.topaz.cmdb.shared.classmodel.diff.impl.AbstractClassModelDiffSubscriber;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnumEntry;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.CmdbValidLinkQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.definition.CmdbValidLinkQualifierDef;
import com.mercury.topaz.cmdb.shared.notification.service.util.ChangesPublisher;

class CmdbDalJdbcClassModelDAO
  implements CmdbDalClassModelDAO
{
  private final CmdbDalDAO dao;
  private CmdbDalClassModelDiffSubscriber _classModelDiffSubscriber = null;
  private final LocalEnvironment localEnvironment;

  CmdbDalJdbcClassModelDAO(LocalEnvironment localEnvironment)
  {
    this.localEnvironment = localEnvironment;
    this.dao = localEnvironment.getDao();
    initNewCustomer();
    setClassModelDiffSubscriber(new CmdbDalClassModelDiffSubscriber(this, null));

    SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();
    boolean updateClassModelEnabled = settingsReader.getBoolean("dal.update.class.model.enabled", true);
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getLocalEnvironment().getCustomerID() + "]: Class model update enabled (customer is isolated) flag value is set to [" + updateClassModelEnabled + "]");
  }

  private LocalEnvironment getLocalEnvironment() {
    return this.localEnvironment;
  }

  public CmdbClassModelDefinition getClassModelDefinition()
  {
    return ((CmdbClassModelDefinition)this.dao.executeQuery(CmdbDalClassModelCommandFactory.createLoadClassModelComplexCommand()).getResult());
  }

  public void addClass(CmdbClass cmdbClass) {
    getClassModelDiffSubscriber().addClass(cmdbClass);
  }

  public void addValidLink(CmdbValidLink validLink) {
    getClassModelDiffSubscriber().addValidLink(validLink);
  }

  public void addTypeDef(CmdbTypeDef typeDef) {
    getClassModelDiffSubscriber().addTypeDef(typeDef);
  }

  public void addClassQualifierDef(CmdbClassQualifierDef classQualifier) {
    getClassModelDiffSubscriber().addClassQualifierDef(classQualifier);
  }

  public void addMethodQualifierDef(CmdbMethodQualifierDef methodQualifier) {
    getClassModelDiffSubscriber().addMethodQualifierDef(methodQualifier);
  }

  public void addAttributeQualifierDef(CmdbAttributeQualifierDef attributeQualifier) {
    getClassModelDiffSubscriber().addAttributeQualifierDef(attributeQualifier);
  }

  public void addValidLinkQualifierDef(CmdbValidLinkQualifierDef validLinkQualifier) {
    getClassModelDiffSubscriber().addValidLinkQualifierDef(validLinkQualifier);
  }

  public void removeValidLink(CmdbValidLink validLink) {
    getClassModelDiffSubscriber().removeValidLink(validLink);
  }

  public void removeTypeDef(CmdbTypeDef typeDef) {
    getClassModelDiffSubscriber().removeTypeDef(typeDef);
  }

  public void addCalculatedLink(CmdbCalculatedLink calculatedLink, CmdbClass cmdbClass) {
    getClassModelDiffSubscriber().addCalculatedLink(calculatedLink, cmdbClass);
  }

  public void removeCalculatedLink(CmdbCalculatedLink calculatedLink, CmdbClass cmdbClass) {
    getClassModelDiffSubscriber().removeCalculatedLink(calculatedLink, cmdbClass);
  }

  public void updateCalculatedLink(CmdbCalculatedLink calculatedLink) {
    throw new UnsupportedOperationException();
  }

  public void removeClass(CmdbClass cmdbClass) {
    getClassModelDiffSubscriber().removeClass(cmdbClass);
  }

  public void updateClass(CmdbClass cmdbClass) {
    throw new UnsupportedOperationException();
  }

  public void updateTypeDef(CmdbTypeDef typeDef) {
    throw new UnsupportedOperationException();
  }

  public void updateValidLink(CmdbValidLink validLink) {
    throw new UnsupportedOperationException();
  }

  public void update(ClassModelDiffs classModelDiffs) {
    ChangesPublisher.publish(getClassModelDiffSubscriber(), classModelDiffs);
  }

  public void initNewCustomer() {
    this.dao.execute(CmdbDalClassModelCommandFactory.createHandleNewCustomerComplexCommand(this.dao.getDBType()));
  }

  private CmdbDalClassModelDiffSubscriber getClassModelDiffSubscriber()
  {
    return this._classModelDiffSubscriber;
  }

  private void setClassModelDiffSubscriber(CmdbDalClassModelDiffSubscriber classModelDiffSubscriber) {
    this._classModelDiffSubscriber = classModelDiffSubscriber;
  }

  private class CmdbDalClassModelDiffSubscriber extends AbstractClassModelDiffSubscriber
  {
    public void addClass()
    {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddClassUpdateTableComplexCommand(cmdbClass));
    }

    public void updateMethodAddQualifiers(, CmdbMethod cmdbMethod, CmdbMethodQualifiers cmdbMethodQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddMethodQualifiersComplexCommand(cmdbMethod, cmdbClass, cmdbMethodQualifiers, null));
    }

    public void updateMethodRemoveQualifiers(, CmdbMethod cmdbMethod, CmdbMethodQualifiers cmdbMethodQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveMethodQualifiersComplexCommand(cmdbMethod, cmdbClass, cmdbMethodQualifiers, null));
    }

    public void updateValidLinkAddQualifiers(, CmdbValidLinkQualifiers cmdbValidLinkQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddValidLinkQualifiersComplexCommand(cmdbValidLink, cmdbValidLinkQualifiers, null));
    }

    public void updateValidLinkRemoveQualifiers(, CmdbValidLinkQualifiers cmdbValidLinkQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveValidLinkQualifiersComplexCommand(cmdbValidLink, cmdbValidLinkQualifiers, null));
    }

    public void updateQualifierDataItems(, CmdbMethod cmdbMethod, CmdbMethodQualifier cmdbMethodQualifier) {
      throw new UnsupportedOperationException();
    }

    public void addAttribute(, CmdbAttribute cmdbAttribute) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddAttributesUpdateTableComplexCommand(cmdbAttribute, cmdbClass, null));
    }

    public void addMethod(, CmdbMethod cmdbMethod) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddMethodsComplexCommand(cmdbMethod, cmdbClass, null));
    }

    public void addValidLink() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddValidLinkComplexCommand(validLink));
    }

    public void addTypeDef() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddTypeDefComplexCommand(typeDef));
    }

    public void addCalculatedLink(, CmdbClass cmdbClass) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddCalculatedLinkComplexCommand(calculatedLink, cmdbClass));
    }

    public void addClassQualifierDef() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddClassQualifierDefComplexCommand(classQualifier));
    }

    public void addMethodQualifierDef() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddMethodQualifierDefComplexCommand(methodQualifier));
    }

    public void addAttributeQualifierDef() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddAttributeQualifierDefComplexCommand(attributeQualifier));
    }

    public void addValidLinkQualifierDef() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddValidLinkQualifierDefComplexCommand(validLinkQualifier));
    }

    public void removeClass() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveClassUpdateTableComplexCommand(cmdbClass));
    }

    public void removeAttribute(, CmdbAttribute cmdbAttribute) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveAttributesUpdateTableComplexCommand(cmdbAttribute, cmdbClass, null));
    }

    public void removeMethod(, CmdbMethod cmdbMethod) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveMethodsComplexCommand(cmdbMethod, cmdbClass, null));
    }

    public void removeTypeDef() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveTypeDefComplexCommand(typeDef));
    }

    public void removeCalculatedLink(, CmdbClass cmdbClass) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveCalculatedLinkComplexCommand(calculatedLink, cmdbClass));
    }

    public void updateTypeDefDisplayName() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateTypeDefDisplayNameComplexCommand(typeDef));
    }

    public void updateTypeDefDescription() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateTypeDefDescriptionComplexCommand(typeDef));
    }

    public void updateCalculatedLinkAddTriplet(, CmdbCalculatedLink calculatedLink, CalculatedLinkTripletDefinition triplet) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddCalculatedLinkTripletComplexCommand(cmdbClass, calculatedLink, triplet, null));
    }

    public void updateCalculatedLinkRemoveTriplet(, CmdbCalculatedLink calculatedLink, CalculatedLinkTripletDefinition triplet) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveCalculatedLinkTripletComplexCommand(triplet, cmdbClass, null));
    }

    public void removeValidLink() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveValidLinkComplexCommand(validLink));
    }

    public void updateClassDisplayName() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateClassDisplayNameComplexCommand(cmdbClass));
    }

    public void updateClassDescription() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateClassDescriptionComplexCommand(cmdbClass));
    }

    public void updateAttributeDisplayName(, CmdbAttribute cmdbAttribute) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateAttributeDisplayNameComplexCommand(cmdbAttribute, cmdbClass));
    }

    public void updateAttributeDescription(, CmdbAttribute cmdbAttribute) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateAttributeDescriptionComplexCommand(cmdbAttribute, cmdbClass));
    }

    public void updateAttributeDefaultValue(, CmdbAttribute cmdbAttribute) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateAttributeDefaultValueComplexCommand(cmdbAttribute, cmdbClass));
    }

    public void updateAttributeOverridePartialState(, CmdbAttributeOverride cmdbAttributeOverride) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateAttributeIsPartialOverrideComplexCommand(cmdbAttributeOverride, cmdbClass));
    }

    public void updateAttributeValueSize(, CmdbAttribute cmdbAttribute) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateAttributeValueSizeUpdateTableComplexCommand(cmdbAttribute, cmdbClass));
    }

    public void updateMethodDisplayName(, CmdbMethod cmdbMethod) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateMethodDisplayNameComplexCommand(cmdbMethod, cmdbClass));
    }

    public void updateMethodDescription(, CmdbMethod cmdbMethod) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateMethodDescriptionComplexCommand(cmdbMethod, cmdbClass));
    }

    public void updateClassAddQualifiers(, CmdbClassQualifiers cmdbClassQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddClassQualifiersComplexCommand(cmdbClass, cmdbClassQualifiers, null));
    }

    public void updateClassRemoveQualifiers(, CmdbClassQualifiers cmdbClassQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveClassQualifiersComplexCommand(cmdbClass, cmdbClassQualifiers, null));
    }

    public void updateAttributeAddQualifiers(, CmdbAttribute cmdbAttribute, CmdbAttributeQualifiers cmdbAttributeQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddAttributeQualifiersUpdateTableComplexCommand(cmdbAttribute, cmdbClass, cmdbAttributeQualifiers, null));
    }

    public void updateAttributeRemoveQualifiers(, CmdbAttribute cmdbAttribute, CmdbAttributeQualifiers cmdbAttributeQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveAttributeQualifiersUpdateTableComplexCommand(cmdbAttribute, cmdbClass, cmdbAttributeQualifiers, null));
    }

    public void updateQualifierDataItems(, CmdbClassQualifier cmdbClassQualifier) {
      throw new UnsupportedOperationException();
    }

    public void updateQualifierDataItems(, CmdbAttribute cmdbAttribute, CmdbAttributeQualifier cmdbAttributeQualifiery) {
      throw new UnsupportedOperationException();
    }

    public void updateAddToEnum(, CmdbEnumEntry enumEntry) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddTypeDefEnumEntryComplexCommand(enumEntry, cmdbEnum, null, null));
    }

    public void updateRemoveFromEnum(, CmdbEnumEntry enumEntry) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveTypeDefEnumEntryComplexCommand(enumEntry, cmdbEnum, null));
    }

    public void updateMethodName(, CmdbMethod cmdbMethod) {
      throw new UnsupportedOperationException("method name is read only and therefore the method is not supported.");
    }

    public void updateMethodType(, CmdbMethod cmdbMethod) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateMethodTypeComplexCommand(cmdbMethod, cmdbClass));
    }

    public void updateMethodParams(, CmdbMethod cmdbMethod) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateMethodParamsComplexCommand(cmdbMethod, cmdbClass));
    }

    public void updateMethodCommand(, CmdbMethod cmdbMethod) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateMethodCommandComplexCommand(cmdbMethod, cmdbClass));
    }

    public void updateClassName() {
      throw new UnsupportedOperationException("class name is read only and therefore the method is not supported.");
    }

    public void updateClassType() {
      throw new UnsupportedOperationException("class type is read only and therefore the method is not supported.");
    }

    public void updateClassHierarchy() {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateClassHierarchyComplexCommand(cmdbClass));
    }

    public void updateAttributeName(, CmdbAttribute cmdbAttribute) {
      throw new UnsupportedOperationException("Attribute name is read only and therefore the method is not supported.");
    }

    public void updateAttributeType(, CmdbAttribute cmdbAttribute) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateAttributeTypeComplexCommand(cmdbAttribute, cmdbClass));
    }

    public void addAttributeOverride(, CmdbAttributeOverride cmdbAttributeOverride) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(new AddAttributeOverride(cmdbAttributeOverride, cmdbClass, null));
    }

    public void addAttributePartiallyOverride(, CmdbAttributeOverride cmdbAttributeOverride) {
      addAttributeOverride(cmdbClass, cmdbAttributeOverride);
    }

    public void removeAttributeOverride(, CmdbAttributeOverride cmdbAttributeOverride) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(new RemoveAttributeOverride(cmdbAttributeOverride, cmdbClass, null));
    }

    public void removeAttributePartiallyOverride(, CmdbAttributeOverride cmdbAttributeOverride) {
      removeAttributeOverride(cmdbClass, cmdbAttributeOverride);
    }

    public void updateAttributeOverrideDefaultValue(, CmdbAttributeOverride cmdbAttributeOverride) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createUpdateAttributeDefaultValueComplexCommand(cmdbAttributeOverride, cmdbClass));
    }

    public void updateAttributeOverrideAddQualifiers(, CmdbAttributeOverride cmdbAttributeOverride, CmdbAttributeQualifiers cmdbAttributeQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddAttributeQualifiersUpdateTableComplexCommand(cmdbAttributeOverride, cmdbClass, cmdbAttributeQualifiers, null));
    }

    public void updateAttributePartiallyOverrideAddQualifiers(, CmdbAttributeOverride cmdbAttributeOverride, CmdbAttributeQualifiers cmdbAttributeQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddAttributeQualifiersUpdateTableComplexCommand(cmdbAttributeOverride, cmdbClass, cmdbAttributeQualifiers, null));
    }

    public void updateAttributeOverrideRemoveQualifiers(, CmdbAttributeOverride cmdbAttributeOverride, CmdbAttributeQualifiers cmdbAttributeQualifiers) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveAttributeQualifiersUpdateTableComplexCommand(cmdbAttributeOverride, cmdbClass, cmdbAttributeQualifiers, null));
    }

    public void updateAttributePartiallyOverrideRemoveQualifiers(, CmdbAttributeOverride cmdbAttributeOverride, CmdbAttributeQualifiers cmdbAttributeQualifiers) {
      updateAttributeOverrideRemoveQualifiers(cmdbClass, cmdbAttributeOverride, cmdbAttributeQualifiers);
    }

    public void notDefinedDiff() {
      throw new UnsupportedOperationException(message);
    }

    public void updateAddToList(, CmdbListEntry listEntry) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createAddTypeDefListEntryComplexCommand(listEntry, cmdbList, null, null));
    }

    public void updateRemoveFromList(, CmdbListEntry listEntry) {
      CmdbDalJdbcClassModelDAO.access$100(this.this$0).execute(CmdbDalClassModelCommandFactory.createRemoveTypeDefListEntryComplexCommand(listEntry, cmdbList, null));
    }
  }
}