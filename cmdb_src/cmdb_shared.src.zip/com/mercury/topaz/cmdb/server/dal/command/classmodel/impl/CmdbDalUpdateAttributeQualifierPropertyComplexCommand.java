package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import java.sql.SQLException;

public abstract class CmdbDalUpdateAttributeQualifierPropertyComplexCommand extends CmdbDalUpdateQualifierPropertyComplexCommand
{
  CmdbAttributeOverride _attribute;

  public CmdbDalUpdateAttributeQualifierPropertyComplexCommand(ClassModelQualifier qualifier, CmdbClass cmdbClass, CmdbAttributeOverride cmdbAttribute)
  {
    super(qualifier, cmdbClass);
    setAttribute(cmdbAttribute);
  }

  protected Long getRowId() throws SQLException {
    Long attributeId = getAttributeID(getAttribute().getName(), getCmdbClass().getName(), getConnection());
    return attributeId;
  }

  protected CmdbAttributeOverride getAttribute() {
    return this._attribute;
  }

  private void setAttribute(CmdbAttributeOverride attribute) {
    this._attribute = attribute;
  }
}