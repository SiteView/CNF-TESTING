package com.mercury.topaz.cmdb.server.dal.command;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;

public abstract interface CmdbDalDataModelUpdateDAO
{
  public abstract void addObjects(CmdbObjects paramCmdbObjects);

  public abstract void removeObjects(CmdbObjects paramCmdbObjects);

  public abstract void addLinks(CmdbLinks paramCmdbLinks);

  public abstract void removeLinks(CmdbLinks paramCmdbLinks);

  public abstract void updateObjects(CmdbObjects paramCmdbObjects);

  public abstract void updateLinks(CmdbLinks paramCmdbLinks);

  public abstract void updateElementsWithClassPropertiesAndNotUpdateUpdateTime(CmdbIDsCollection<? extends CmdbDataID> paramCmdbIDsCollection, CmdbProperties paramCmdbProperties, String paramString);

  public abstract void execute(CmdbDalCommand<Void> paramCmdbDalCommand);
}