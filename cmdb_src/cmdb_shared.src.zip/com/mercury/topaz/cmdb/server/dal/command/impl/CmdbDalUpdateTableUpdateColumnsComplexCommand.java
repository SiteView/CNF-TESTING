package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import java.util.Iterator;
import java.util.List;

public class CmdbDalUpdateTableUpdateColumnsComplexCommand extends AbstractTableManagementCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalUpdateTableUpdateColumnsComplexCommand.class);
  private final TableModifications modifications;

  public CmdbDalUpdateTableUpdateColumnsComplexCommand(TableDescription currentTable, TableModifications modifications)
  {
    super(currentTable);
    this.modifications = modifications;
  }

  protected Void perform() {
    updateExistingColumns();
    return null;
  }

  protected String getCommandName() {
    return "Update table [" + getTableName() + "]";
  }

  private void updateExistingColumns()
  {
    IndexDescription indexDescription;
    String columnName;
    for (Iterator i$ = this.modifications.getIndexesToRemove().iterator(); i$.hasNext(); ) { indexDescription = (IndexDescription)i$.next();
      removeTableIndex(indexDescription);
    }

    for (i$ = this.modifications.getColumnsToMakeNullable().iterator(); i$.hasNext(); ) { columnName = (String)i$.next();
      makeColumnNullable(columnName);
    }
    for (i$ = this.modifications.getColumnsToMakeNonNullable().iterator(); i$.hasNext(); ) { columnName = (String)i$.next();
      makeColumnNotNullable(columnName);
    }

    for (i$ = this.modifications.getColumnsToChangeSize().iterator(); i$.hasNext(); ) { ColumnDescription columnDescription = (ColumnDescription)i$.next();
      updateColumnSize(columnDescription);
    }

    for (i$ = this.modifications.getIndexesToAdd().iterator(); i$.hasNext(); ) { indexDescription = (IndexDescription)i$.next();
      addTableIndex(indexDescription);
    }
  }

  private void makeColumnNullable(String columnName) {
    if (_logger.isDebugEnabled()) {
      _logger.debug("Change column [" + columnName + "] in table [" + getTableName() + "] to be nullable");
    }

    throw new UnsupportedOperationException();
  }

  private void makeColumnNotNullable(String columnName) {
    if (_logger.isDebugEnabled()) {
      _logger.debug("Change column [" + columnName + "] in table [" + getTableName() + "] to be not nullable");
    }

    throw new UnsupportedOperationException();
  }

  private void updateColumnSize(ColumnDescription columnDescription) {
    String columnSizeString = getDBColumnSize(columnDescription);
    String columnName = columnDescription.getName();
    String columnType = getDBColumnType(columnDescription);

    if (_logger.isDebugEnabled()) {
      _logger.debug("Update size of column [" + columnName + "], from table [" + getTableName() + "] into size [" + columnSizeString + "]");
    }

    StringBuffer sqlString = new StringBuffer();
    sqlString.append("ALTER TABLE ").append(getTableName());

    if (isOracle())
      sqlString.append(" MODIFY ");
    else if (isMsSql())
      sqlString.append(" ALTER COLUMN ");
    else {
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
    }

    sqlString.append(columnName).append(" ");
    sqlString.append(columnType).append(columnSizeString);

    getConnection().executeAdhocSql(sqlString.toString());

    commitChanges();
  }

  private void removeTableIndex(IndexDescription indexDescription) {
    String columnName = (String)indexDescription.getColumnNames().get(0);
    if (_logger.isDebugEnabled())
      _logger.debug("Remove index from column [" + columnName + "] in table [" + getTableName() + "]");

    dropTableIndex(columnName);
  }

  private void dropTableIndex(String columnName) {
    String indexName = buildIndexName(getTableName(), columnName);

    synchronized (getLock()) {
      if (!(isIndexExist(getTableName(), columnName))) break label200;
      CmdbDalCommand getIndexes = CmdbDalCommandFactory.createGetIndexesByColumnSimpleCommand(getTableName(), columnName);
      CmdbDalCommandResult commandResult = getIndexes.execute();
      List indexesNames = (List)commandResult.getResult();
      if (indexesNames.size() <= 1) break label115;
      _logger.error("There is more than one index on column [" + columnName + "] in table [" + getTableName() + "]. Cannot decide which index to remove");
      return;
      label115: if (indexesNames.size() != 1) break label138;
      indexName = (String)indexesNames.get(0);

      label138: StringBuffer sqlString = new StringBuffer();

      sqlString.append("drop index ");
      if (!(isMsSql())) break label177;
      sqlString.append(getTableName()).append(".");

      label177: sqlString.append(indexName);

      getConnection().executeAdhocSql(sqlString.toString());

      label200: commitChanges();
    }
  }
}