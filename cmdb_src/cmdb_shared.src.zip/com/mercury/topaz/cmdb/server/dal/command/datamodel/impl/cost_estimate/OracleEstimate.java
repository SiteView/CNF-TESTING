package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.cost_estimate;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.CmdbDalConditionComplexCommand;
import com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.CmdbDalDataModelComplexCommand;
import com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.CmdbDalLinksConditionGetCmdbLinksNoModelLinksComplexCommand;
import com.mercury.topaz.cmdb.server.dal.command.datamodel.impl.CmdbDalObjectsConditionGetCmdbObjectsNoModelObjectsComplexCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class OracleEstimate extends CmdbDalDataModelComplexCommand
{
  private static final String COST_COLUMN_NAME = "position";
  private static final String PLAN_TABLE_NAME = "PLAN_TABLE";
  private static final int STATEMENT_ID_CEIL = 67108864;
  private static final Random random = new Random();
  private ElementCondition condition;

  public OracleEstimate(ElementCondition condition)
  {
    this.condition = condition;
  }

  protected void validateInput() {
  }

  protected CmdbDalConditionComplexCommand constructCommand(ElementCondition condition) {
    if (condition instanceof LinkCondition) {
      return new CmdbDalLinksConditionGetCmdbLinksNoModelLinksComplexCommand((LinkCondition)condition);
    }

    return new CmdbDalObjectsConditionGetCmdbObjectsNoModelObjectsComplexCommand(condition);
  }

  protected Log getLogger() {
    return LogFactory.getEasyLog(getClass());
  }

  protected Double perform() throws Exception {
    if ((this.condition == null) || (this.condition.getClassCondition() == null)) {
      throw new CmdbException("Can't estimate command cost: got null condition or null class condition: [condition = " + this.condition + "]");
    }

    verifyPlanTableExists();

    String statementID = createExecutionPlan();
    double cost = getCost(statementID);
    getLogger().info("Estimated cost is " + cost);
    return Double.valueOf(cost);
  }

  private void verifyPlanTableExists() throws SQLException {
    CmdbDalPreparedStatement preparedStatement = null;
    try
    {
      preparedStatement = createPreparedStatement(getConnection(), OracleEstimationUtil.getPlanTableVerificationSql());

      OracleEstimationUtil.verifyPlanTableExists(preparedStatement);
    } finally {
      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private double getCost(String statementID) throws Exception
  {
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;
    try
    {
      List bindVariables = new ArrayList();
      bindVariables.add(statementID);
      List bindVariablesTypes = new ArrayList();
      bindVariablesTypes.add(CmdbSimpleTypes.CmdbString);

      preparedStatement = createAndFillPreparedStatement(getConnection(), createSQLForSelectFromPlanTable(), bindVariables, bindVariablesTypes);

      resultSet = preparedStatement.executeQuery();
      if (!(resultSet.next())) {
        throw new CmdbException("Received empty result set from PLAN_TABLE");
      }

      double d = resultSet.getInt("position").intValue();

      return d;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null) {
        preparedStatement.close();
      }

      clearPlanTable(statementID);
    }
  }

  private String createSQLForSelectFromPlanTable() {
    return "select position from PLAN_TABLE where id = 0 and statement_id = ?";
  }

  private String createExecutionPlan() throws Exception {
    CmdbDalPreparedStatement statement = null;
    try
    {
      String statementID = generateStatementID();
      List bindVariables = new ArrayList();
      List bindVariablesTypes = new ArrayList();

      CmdbDalConditionComplexCommand command = constructCommand(this.condition);
      String sqlString = command.createConditionSql(getConnection(), bindVariables, bindVariablesTypes);
      String executionPlanStatement = createExecutionPlanSQL(sqlString);

      bindVariables.add(0, statementID);
      bindVariablesTypes.add(0, CmdbSimpleTypes.CmdbString);

      statement = createAndFillPreparedStatement(getConnection(), executionPlanStatement, bindVariables, bindVariablesTypes);

      statement.executeQuery();

      getLogger().info("Estimating cost for statement: " + statement);
      String str1 = statementID;

      return str1;
    }
    finally
    {
      if (statement != null)
        statement.close();
    }
  }

  private String generateStatementID()
  {
    return String.valueOf(random.nextInt(67108863));
  }

  private String createExecutionPlanSQL(String sqlString) {
    return "explain plan set statement_id = ? for " + sqlString;
  }

  private void clearPlanTable(String statementID) throws SQLException {
    CmdbDalPreparedStatement preparedStatement = null;
    try
    {
      List bindVariables = new ArrayList();
      bindVariables.add(statementID);
      List bindVariablesTypes = new ArrayList();
      bindVariablesTypes.add(CmdbSimpleTypes.CmdbString);

      String sql = "delete from PLAN_TABLE where statement_id = ?";

      preparedStatement = createAndFillPreparedStatement(getConnection(), sql, bindVariables, bindVariablesTypes);
      preparedStatement.executeUpdate();
    } finally {
      if (preparedStatement != null)
        preparedStatement.close();
    }
  }
}