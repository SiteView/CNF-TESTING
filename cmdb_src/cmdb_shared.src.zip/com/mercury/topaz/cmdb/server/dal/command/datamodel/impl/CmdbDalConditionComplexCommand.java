package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.util.time.CmdbTime;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.common.expression.ExpressionElement;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalExpression;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalOperator;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ConditionOperator;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.PropertyCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public abstract class CmdbDalConditionComplexCommand extends CmdbDalDataModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalConditionComplexCommand.class);
  private ElementCondition _condition = null;
  private int _numberTempTableIndex = 0;
  private int _stringTempTableIndex = 0;
  private String _classNameSuffix = null;
  private static final String EMPTY_STRING = "";
  private static final String ESCAPING_CHARACTER = "?";
  private static final String UNDERSCORE_WILDCARD = "_";
  private static final String AND_OPERATOR = "AND";
  private static final String OR_OPERATOR = "OR";
  private static final String NOT_OPERATOR = "NOT";
  protected static final String EQUAL_OPERATOR = "=";
  protected static final String NOT_EQUAL_OPERATOR = "!=";
  private static final String GREATER_OPERATOR = ">";
  private static final String GREATER_EQUAL_OPERATOR = ">=";
  private static final String LESS_OPERATOR = "<";
  private static final String LESS_EQUAL_OPERATOR = "<=";
  private static final String LIKE_OPERATOR = "LIKE";
  private static final String LIKE_IGNORE_CASE_OPERATOR = "LIKE";
  private static final String IS_NULL_OPERATOR = "IS NULL";
  private static final String EQUAL_IGNORE_CASE_OPERATOR = "=";

  public CmdbDalConditionComplexCommand(ElementCondition condition)
  {
    setCondition(optimizeCondition(condition));
    setNumberTempTableIndex(0);
    setStringTempTableIndex(0);
    setClassNameSuffix("");
  }

  protected void validateInput() {
    if ((getCondition() == null) || (getCondition().getClassCondition() == null))
    {
      _logger.info("Error in condiiton command - null condition or null class condition !!!");
    }
  }

  protected ElementCondition optimizeCondition(ElementCondition condition) {
    return condition;
  }

  protected void prepare() throws Exception {
    setUseDirtyRead();

    if (isNonIdTempTablesInUse())
      truncateNonIdTempTables();
  }

  protected void postProcess() throws Exception
  {
    if (isNonIdTempTablesInUse())
      truncateNonIdTempTables();

    truncateCmdbIDTempTable(getConnection());
  }

  protected Object performQueryCondition() throws Exception {
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;
    try
    {
      if (_logger.isDebugEnabled()) {
        _logger.debug("Performing query with condition [" + getCondition() + "]");
      }

      List bindVariables = new ArrayList();
      List bindVariablesTypes = new ArrayList();
      CmdbDalConnection connection = getConnection();

      String sqlString = createConditionSql(connection, bindVariables, bindVariablesTypes);
      preparedStatement = createAndFillPreparedStatement(connection, sqlString, bindVariables, bindVariablesTypes);

      resultSet = preparedStatement.executeQuery();

      Object localObject1 = getResult(resultSet);

      return localObject1;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  protected boolean isNonIdTempTablesInUse()
  {
    return isNonIdTempTablesInUse(getCondition(), getModelElements());
  }

  protected boolean isNonIdTempTablesInUse(ElementCondition condition, Object modelElements)
  {
    return ((condition != null) && ((
      (hasPropertiesCondition(condition)) || (!(hasModelElements(modelElements))))));
  }

  public String createConditionSql(CmdbDalConnection connection, List<Object> bindVariables, List<CmdbType> bindVariablesTypes)
    throws SQLException
  {
    Set participatedClasses = new HashSet();

    StringBuffer sqlString = new StringBuffer();

    addIDsCondition(connection, sqlString, bindVariables, bindVariablesTypes);
    addClassCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses);
    addPropertiesCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses);

    addSelectSql(sqlString, participatedClasses, bindVariables, bindVariablesTypes);

    return sqlString.toString();
  }

  protected void addIDsCondition(CmdbDalConnection connection, StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) throws SQLException
  {
    CmdbIDsCollection conditionIDs = extractConditionIDs(getModelElements(), getCondition());

    addIDsCondition(conditionIDs, connection, sqlString, bindVariables, bindVariablesTypes, getCondition(), getClassNameSuffix());
  }

  protected void addIDsCondition(CmdbIDsCollection<? extends CmdbDataID> conditionIDs, CmdbDalConnection connection, StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, ElementCondition condition, String classNameSuffix) throws SQLException {
    if (hasConditionIDs(conditionIDs)) {
      ElementClassCondition classCondition = condition.getClassCondition();
      sqlString.append(" AND ");

      if ((!(hasModelElements(getModelElements()))) && (condition.getIdsCondition() != null) && (condition.getIdsCondition().isNegate()))
        sqlString.append("NOT ");

      if (isCmdbIDTempTableMustNotUsingChunksMechanism(getContainerSize(conditionIDs))) {
        createCmdbIDTempTable(conditionIDs, connection);
        sqlString.append(createJoinWithCmdbIDTempTableConditionSql(getDummyClassName(classCondition.getClassName(), classNameSuffix), getContainerSize(conditionIDs)));
      } else {
        sqlString.append(getDummyClassName(classCondition.getClassName(), classNameSuffix)).append(".").append("CMDB_ID");
        sqlString.append(getInSqlString(getContainerSize(conditionIDs)));

        addIDsToBindVariables(conditionIDs, bindVariables, bindVariablesTypes);
      }
    }
  }

  protected abstract void addIDsToBindVariables(CmdbIDsCollection<? extends CmdbDataID> paramCmdbIDsCollection, List<Object> paramList, List<CmdbType> paramList1);

  protected abstract int getContainerSize(Object paramObject);

  protected abstract CmdbIDsCollection<? extends CmdbDataID> extractConditionIDs(Object paramObject, ElementCondition paramElementCondition);

  protected abstract void createCmdbIDTempTable(Object paramObject, CmdbDalConnection paramCmdbDalConnection)
    throws SQLException;

  protected boolean hasPropertiesCondition()
  {
    return hasPropertiesCondition(getCondition());
  }

  protected boolean hasPropertiesCondition(ElementCondition condition) {
    ElementPropertiesCondition propertiesCondition = condition.getPropertiesCondition();
    return ((propertiesCondition != null) && (propertiesCondition.getNumberOfElements() > 0));
  }

  protected void addPropertiesCondition(StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses) throws SQLException {
    addPropertiesCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses, getClassNameSuffix(), getCondition());
  }

  private void truncateNonIdTempTables() throws SQLException
  {
    truncateStringTempTable(getConnection());
    truncateNumberTempTable(getConnection());
  }

  protected void addPropertiesCondition(StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) throws SQLException {
    if (hasPropertiesCondition(condition)) {
      ElementPropertiesCondition propertiesCondition = condition.getPropertiesCondition();
      sqlString.append(" ").append("AND").append(" ");
      addSubExpression(propertiesCondition.getIterator(), sqlString, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
    }
  }

  protected void addClassCondition(StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses) throws SQLException {
    addClassCondition(sqlString, bindVariables, bindVariablesTypes, participatedClasses, getClassNameSuffix(), getCondition(), getModelElements());
  }

  protected void addClassCondition(StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition, Object modelElements) throws SQLException {
    ElementClassCondition classCondition = condition.getClassCondition();
    String className = classCondition.getClassName();
    String alias = getDummyClassName(getClassColumnHolder(className), classNameSuffix);

    if (!(hasModelElements(modelElements))) {
      if ((!(classCondition.hasQualifiersLimitations())) && (!(classCondition.isDerived()))) {
        sqlString.append(" AND ").append(alias).append(".").append("CLASS").append("=? ");
        bindVariables.add(className);
        bindVariablesTypes.add(CmdbSimpleTypes.CmdbString);
        participatedClasses.add(alias);
      }
      if (classCondition.hasQualifiersLimitations()) {
        sqlString.append(" AND ");
        ReadOnlyIterator classesIter = classCondition.getClassNames(getSynchronizedClassModel());
        List classesList = getClassesList(classesIter);
        addInClause(sqlString, "CLASS", classesList.iterator(), classesList.size(), CmdbSimpleTypes.CmdbString, alias, bindVariables, bindVariablesTypes, participatedClasses);
      }
    }
  }

  protected List<String> getClassesList(ReadOnlyIterator<String> classesIter)
  {
    List classesNames = new ArrayList();
    while (classesIter.hasNext())
      classesNames.add(classesIter.next());

    return classesNames;
  }

  protected abstract Object getResult(CmdbDalResultSet paramCmdbDalResultSet) throws SQLException;

  protected abstract boolean hasConditionIDs(Object paramObject);

  protected abstract Object getModelElements();

  protected abstract boolean hasModelElements(Object paramObject);

  private void addLogicalOperator(LogicalOperator operator, StringBuffer sqlString) {
    if (LogicalOperator.AND.equals(operator))
      sqlString.append(" ").append("AND").append(" ");
    else if (LogicalOperator.OR.equals(operator))
      sqlString.append(" ").append("OR").append(" ");
    else if (LogicalOperator.NOT.equals(operator))
      sqlString.append(" ").append("NOT").append(" ");
    else
      throw new CmdbDalException("Unknown condition logical operator [" + operator + "]");
  }

  private void addVariable(PropertyCondition propertyCondition, StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) throws SQLException
  {
    ConditionOperator conditionOperator = propertyCondition.getOperator();
    String propertyName = propertyCondition.getPropertyName();
    Object propertyValue = propertyCondition.getPropertyValue();

    String attributeClassName = condition.getClassCondition().getClassName();
    CmdbAttribute attribute = ClassModelUtil.getAttributeByName(propertyName, attributeClassName);
    if (!(ClassModelUtil.isPersistentAttribute(attribute))) {
      throw new CmdbDalException("Attribute [" + attribute.getName() + "] from class [" + attributeClassName + "] is not persistent in db");
    }

    CmdbClass attributeClass = ClassModelUtil.getAttributeClass(propertyName, attributeClassName);

    if (ConditionOperator.EQUEL.equals(conditionOperator)) {
      addEqualVariable(sqlString, propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
    } else if (ConditionOperator.NOT_EQUEL.equals(conditionOperator)) {
      addNotEqualVariable(sqlString, propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
    } else if (ConditionOperator.GREATER.equals(conditionOperator)) {
      addGreaterVariable(sqlString, propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
    } else if (ConditionOperator.GREATER_EQUEL.equals(conditionOperator)) {
      addGreaterEqualVariable(sqlString, propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
    } else if (ConditionOperator.LESS.equals(conditionOperator)) {
      addLessVariable(sqlString, propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
    } else if (ConditionOperator.LESS_EQUEL.equals(conditionOperator)) {
      addLessEqualVariable(sqlString, propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
    } else if (ConditionOperator.LIKE.equals(conditionOperator)) {
      addLikeVariable(sqlString, propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
    } else if (ConditionOperator.IN.equals(conditionOperator)) {
      addInVariable(sqlString, propertyName, propertyValue, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix);
    } else if (ConditionOperator.IS_NULL.equals(conditionOperator)) {
      addIsNullVariable(sqlString, propertyName, attribute, attributeClass, participatedClasses, bindVariables, bindVariablesTypes, classNameSuffix, condition);
    } else if (ConditionOperator.EQUAL_IGNORE_CASE.equals(conditionOperator)) {
      addEqualIgnoreCaseVariable(sqlString, propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
    } else if (ConditionOperator.IN_LIST.equals(conditionOperator)) {
      addInListVariable(sqlString, propertyName, propertyValue, attribute, bindVariables, bindVariablesTypes, condition, classNameSuffix);
    } else if (ConditionOperator.LIKE_IGNORE_CASE.equals(conditionOperator)) {
      addLikeIgnoreCaseVariable(sqlString, propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition); } else {
      Date propertyValueAsDate;
      PropertyCondition modifiedPropertyCondition;
      if (ConditionOperator.CHANGED_DURING.equals(conditionOperator)) {
        propertyValueAsDate = convertHoursFromNowToDate((Integer)propertyValue);
        modifiedPropertyCondition = PatternConditionFactory.createPropertyCondition(propertyName, ConditionOperator.GREATER_EQUEL, propertyValueAsDate, false);
        addGreaterEqualVariable(sqlString, propertyName, propertyValueAsDate, modifiedPropertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
      } else if (ConditionOperator.UNCHANGED_DURING.equals(conditionOperator)) {
        propertyValueAsDate = convertHoursFromNowToDate((Integer)propertyValue);
        modifiedPropertyCondition = PatternConditionFactory.createPropertyCondition(propertyName, ConditionOperator.LESS, propertyValueAsDate, false);
        addLessVariable(sqlString, propertyName, propertyValueAsDate, modifiedPropertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
      } else {
        throw new CmdbDalException("Unknown condition operator [" + conditionOperator + "]"); }
    }
  }

  private Date convertHoursFromNowToDate(Integer hoursFromNow) {
    long timeInMs = CmdbTime.currentTimeMillis() - hoursFromNow.longValue() * 60L * 60L * 1000L;
    return new Date(timeInMs);
  }

  private void addInVariable(StringBuffer sqlString, String propertyName, Object propertyValue, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix) throws SQLException {
    CmdbType propertyType = extractSimpleType(attribute.getResolvedType());
    String dummyClassName = getDummyClassName(attributeClass.getName(), classNameSuffix);
    ReadOnlyIterator valuesIter = ((CmdbPropertyValues)propertyValue).valuesIterator();

    if (propertyType.equals(CmdbSimpleTypes.CmdbBoolean))
    {
      Set valuesSet = new HashSet();
      while (valuesIter.hasNext())
        valuesSet.add(valuesIter.next());

      addInClause(sqlString, DalClassModelUtil.getColumnNameByAttributeName(propertyName), valuesSet.iterator(), valuesSet.size(), propertyType, dummyClassName, bindVariables, bindVariablesTypes, participatedClasses);
    } else {
      addInClause(sqlString, DalClassModelUtil.getColumnNameByAttributeName(propertyName), valuesIter, ((CmdbPropertyValues)propertyValue).size(), propertyType, dummyClassName, bindVariables, bindVariablesTypes, participatedClasses);
    }
  }

  protected void addInClause(StringBuffer sqlString, String columnName, Object valuesIter, int valuesCount, CmdbType propertyType, String dummyClassName, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses) throws SQLException {
    if (valuesCount > getMaxPossibleSizeForInChunk()) {
      insertValuesToTempTable(propertyType, valuesIter, getTempTableIndex(propertyType), getConnection());

      addInSql(sqlString, dummyClassName, columnName, propertyType);

      bindVariables.add(Integer.valueOf(String.valueOf(getTempTableIndex(propertyType))));
      bindVariablesTypes.add(CmdbSimpleTypes.CmdbInteger);

      setTempTableIndex(propertyType, getTempTableIndex(propertyType) + 1);
    } else {
      sqlString.append(dummyClassName).append(".").append(columnName);
      sqlString.append(getInSqlString(valuesCount));

      addValuesToBindVariables(valuesIter, propertyType, bindVariables, bindVariablesTypes);
    }

    if (participatedClasses != null)
      participatedClasses.add(dummyClassName);
  }

  protected void addValuesToBindVariables(Object valuesIter, CmdbType propertyType, List<Object> bindVariables, List<CmdbType> bindVariablesTypes)
  {
    while (hasNextElement(valuesIter)) {
      Object value = getNextElement(valuesIter);
      bindVariables.add(value);
      bindVariablesTypes.add(propertyType);
    }
  }

  private void addInSql(StringBuffer sqlString, String dummyClassName, String columnName, CmdbType propertyType) {
    sqlString.append("EXISTS (SELECT 1 FROM ");
    sqlString.append(getTempTableNameByType(propertyType)).append(" T ");

    sqlString.append("WHERE ").append(dummyClassName).append(".");
    sqlString.append(columnName).append("=T.").append("T_VALUE");
    sqlString.append(" AND T.").append("T_VALUES_INDEX").append("=?)");
  }

  private void addInListVariable(StringBuffer sqlString, String propertyName, Object propertyValue, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, ElementCondition condition, String classNameSuffix) {
    sqlString.append("EXISTS (SELECT 1 FROM ");
    sqlString.append(getTableNameByClassName("LIST_ATTR_PRIMITIVE")).append(" T ");

    sqlString.append("WHERE T.").append("CMDB_ID").append("=");
    sqlString.append(getDummyClassName(condition.getClassCondition().getClassName(), classNameSuffix)).append(".").append("CMDB_ID");
    sqlString.append(" AND T.").append("ATTR_NAME").append("=? AND ");
    sqlString.append("ATTR_VALUE").append("=?");

    if (!(isUpdateClassModelEnabled())) {
      sqlString.append(" AND ");
      sqlString.append("T.").append("CUSTOMER_ID").append("=");
      sqlString.append(getDummyClassName(condition.getClassCondition().getClassName(), classNameSuffix)).append(".").append("CUSTOMER_ID");
      sqlString.append(" AND T.").append("CUSTOMER_ID").append("=?");
    }

    sqlString.append(")");

    bindVariables.add(propertyName);
    CmdbType listElementType = extractSimpleListElementType(attribute.getResolvedType());
    bindVariables.add(listElementType.stringValue(propertyValue));
    bindVariablesTypes.add(CmdbSimpleTypes.CmdbString);
    bindVariablesTypes.add(CmdbSimpleTypes.CmdbString);

    if (!(isUpdateClassModelEnabled())) {
      bindVariables.add(Integer.valueOf(getCustomerID().getID()));
      bindVariablesTypes.add(CmdbSimpleTypes.CmdbInteger);
    }
  }

  private void addEqualVariable(StringBuffer sqlString, String propertyName, Object propertyValue, PropertyCondition propertyCondition, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) {
    addBinaryVariable(sqlString, "=", propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
  }

  private void addEqualIgnoreCaseVariable(StringBuffer sqlString, String propertyName, Object propertyValue, PropertyCondition propertyCondition, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) {
    sqlString.append("lower(");
    addBinaryVariableLeftSide(sqlString, attributeClass, propertyName, participatedClasses, classNameSuffix);
    sqlString.append(")");
    addVariableOperator(sqlString, "=");
    sqlString.append("lower(");
    addBinaryVariableRightSide(propertyCondition, propertyValue, propertyName, participatedClasses, sqlString, bindVariables, bindVariablesTypes, attribute, classNameSuffix, condition);
    sqlString.append(")");
  }

  private void addLikeIgnoreCaseVariable(StringBuffer sqlString, String propertyName, Object propertyValue, PropertyCondition propertyCondition, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) {
    sqlString.append("lower(");
    addBinaryVariableLeftSide(sqlString, attributeClass, propertyName, participatedClasses, classNameSuffix);
    sqlString.append(")");
    addVariableOperator(sqlString, "LIKE");
    sqlString.append("lower(");
    String escapedValue = createEscapedValue(propertyValue);
    addBinaryVariableRightSide(propertyCondition, escapedValue, propertyName, participatedClasses, sqlString, bindVariables, bindVariablesTypes, attribute, classNameSuffix, condition);
    sqlString.append(")");
    addEscapeClause(sqlString);
  }

  private void addEscapeClause(StringBuffer sqlString) {
    sqlString.append(" escape '").append("?").append("' ");
  }

  private String createEscapedValue(Object propertyValue) {
    if (propertyValue instanceof String) {
      String value = (String)propertyValue;
      return value.replaceAll("_", "?_");
    }
    String errMsg = "Can't escape value of like condition operator. The value [" + propertyValue + "] is from type [" + propertyValue.getClass() + "] instead from type String";

    throw new CmdbDalException(errMsg);
  }

  private void addNotEqualVariable(StringBuffer sqlString, String propertyName, Object propertyValue, PropertyCondition propertyCondition, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition)
  {
    addBinaryVariable(sqlString, "!=", propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
  }

  private void addGreaterVariable(StringBuffer sqlString, String propertyName, Object propertyValue, PropertyCondition propertyCondition, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) {
    addBinaryVariable(sqlString, ">", propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
  }

  private void addGreaterEqualVariable(StringBuffer sqlString, String propertyName, Object propertyValue, PropertyCondition propertyCondition, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) {
    addBinaryVariable(sqlString, ">=", propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
  }

  private void addLessVariable(StringBuffer sqlString, String propertyName, Object propertyValue, PropertyCondition propertyCondition, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) {
    addBinaryVariable(sqlString, "<", propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
  }

  private void addLessEqualVariable(StringBuffer sqlString, String propertyName, Object propertyValue, PropertyCondition propertyCondition, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) {
    addBinaryVariable(sqlString, "<=", propertyName, propertyValue, propertyCondition, attributeClass, attribute, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
  }

  private void addLikeVariable(StringBuffer sqlString, String propertyName, Object propertyValue, PropertyCondition propertyCondition, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) {
    addBinaryVariableLeftSide(sqlString, attributeClass, propertyName, participatedClasses, classNameSuffix);
    addVariableOperator(sqlString, "LIKE");
    String escapedValue = createEscapedValue(propertyValue);
    addBinaryVariableRightSide(propertyCondition, escapedValue, propertyName, participatedClasses, sqlString, bindVariables, bindVariablesTypes, attribute, classNameSuffix, condition);
    addEscapeClause(sqlString);
  }

  private void addIsNullVariable(StringBuffer sqlString, String propertyName, CmdbAttribute attribute, CmdbClass attributeClass, Set<String> participatedClasses, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, String classNameSuffix, ElementCondition condition) {
    CmdbType attributeType = attribute.getResolvedType();
    if (attributeType instanceof CmdbSimpleList) {
      sqlString.append("(NOT EXISTS (SELECT 1 FROM ");
      sqlString.append(getTableNameByClassName("LIST_ATTR_PRIMITIVE")).append(" T ");

      sqlString.append("WHERE T.").append("CMDB_ID").append("=");
      sqlString.append(getDummyClassName(condition.getClassCondition().getClassName(), classNameSuffix)).append(".").append("CMDB_ID");
      sqlString.append(" AND T.").append("ATTR_NAME").append("=?");

      if (!(isUpdateClassModelEnabled())) {
        sqlString.append(" AND ");
        sqlString.append("T.").append("CUSTOMER_ID").append("=");
        sqlString.append(getDummyClassName(condition.getClassCondition().getClassName(), classNameSuffix)).append(".").append("CUSTOMER_ID");
        sqlString.append(" AND T.").append("CUSTOMER_ID").append("=?");
      }

      sqlString.append("))");

      bindVariables.add(propertyName);
      bindVariablesTypes.add(CmdbSimpleTypes.CmdbString);

      if (!(isUpdateClassModelEnabled())) {
        bindVariables.add(Integer.valueOf(getCustomerID().getID()));
        bindVariablesTypes.add(CmdbSimpleTypes.CmdbInteger); }
    } else {
      if ((attributeType.equals(CmdbSimpleTypes.CmdbXml)) || ((attributeType.equals(CmdbSimpleTypes.CmdbBytes)) && (attribute.getSizeLimit() != null) && (attribute.getSizeLimit().intValue() > 2000)))
      {
        if (isOracle()) {
          sqlString.append("dbms_lob.getlength(");
          addBinaryVariableLeftSide(sqlString, attributeClass, propertyName, participatedClasses, classNameSuffix);
          sqlString.append(")");
          addVariableOperator(sqlString, "=");
          sqlString.append("0");
          return; } if (isMsSql()) {
          sqlString.append("DATALENGTH(");
          addBinaryVariableLeftSide(sqlString, attributeClass, propertyName, participatedClasses, classNameSuffix);
          sqlString.append(")");
          addVariableOperator(sqlString, "=");
          sqlString.append("0");
          return; }
        throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");
      }

      addUnaryVariable(sqlString, "IS NULL", propertyName, attributeClass, participatedClasses, classNameSuffix);
    }
  }

  private void addUnaryVariable(StringBuffer sqlString, String operatorName, String propertyName, CmdbClass attributeClass, Set<String> participatedClasses, String classNameSuffix) {
    addBinaryVariableLeftSide(sqlString, attributeClass, propertyName, participatedClasses, classNameSuffix);
    addVariableOperator(sqlString, operatorName);
  }

  private void addBinaryVariable(StringBuffer sqlString, String operatorName, String propertyName, Object propertyValue, PropertyCondition propertyCondition, CmdbClass attributeClass, CmdbAttribute attribute, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) {
    addBinaryVariableLeftSide(sqlString, attributeClass, propertyName, participatedClasses, classNameSuffix);
    addVariableOperator(sqlString, operatorName);
    addBinaryVariableRightSide(propertyCondition, propertyValue, propertyName, participatedClasses, sqlString, bindVariables, bindVariablesTypes, attribute, classNameSuffix, condition);
  }

  protected void addVariableOperator(StringBuffer sqlString, String operatorName) {
    sqlString.append(" ").append(operatorName).append(" ");
  }

  private void addBinaryVariableRightSide(PropertyCondition propertyCondition, Object propertyValue, String propertyName, Set<String> participatedClasses, StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, CmdbAttribute attribute, String classNameSuffix, ElementCondition condition) {
    if (propertyCondition.isTwoPropertiesCondition()) {
      String secondPropertyName = (String)propertyValue;
      CmdbClass secondAttributeClass = ClassModelUtil.getAttributeClass(propertyName, condition.getClassCondition().getClassName());

      addColumnSql(sqlString, secondAttributeClass, secondPropertyName, participatedClasses, classNameSuffix);
    } else {
      sqlString.append("? ");
      bindVariables.add(propertyValue);
      bindVariablesTypes.add(extractSimpleType(attribute.getResolvedType()));
    }
  }

  protected void addColumnSql(StringBuffer sqlString, CmdbClass attributeClass, String attributeName, Set<String> participatedClasses, String classNameSuffix) {
    sqlString.append(getDummyClassName(attributeClass.getName(), classNameSuffix));
    sqlString.append(".").append(DalClassModelUtil.getColumnNameByAttributeName(attributeName));

    participatedClasses.add(getDummyClassName(attributeClass.getName(), classNameSuffix));
  }

  private void addBinaryVariableLeftSide(StringBuffer sqlString, CmdbClass attributeClass, String propertyName, Set<String> participatedClasses, String classNameSuffix) {
    addColumnSql(sqlString, attributeClass, propertyName, participatedClasses, classNameSuffix);
  }

  private void addSubExpression(ReadOnlyIterator<ExpressionElement> propertiesIter, StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, Set<String> participatedClasses, String classNameSuffix, ElementCondition condition) throws SQLException {
    sqlString.append(" (");

    while (propertiesIter.hasNext()) {
      ExpressionElement element = (ExpressionElement)propertiesIter.next();

      if (element.isOperator()) {
        addLogicalOperator((LogicalOperator)element, sqlString);
      } else if (element.isVar()) {
        addVariable((PropertyCondition)element, sqlString, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
      } else if (element.isSubExpression()) {
        LogicalExpression subExpression = (LogicalExpression)element;
        addSubExpression(subExpression.getIterator(), sqlString, bindVariables, bindVariablesTypes, participatedClasses, classNameSuffix, condition);
      } else {
        throw new CmdbDalException("Unknown condition element type for element [" + element + "] - not from type [operator, var, sub expression] !!!");
      }
    }
    sqlString.append(") ");
  }

  protected void addSelectSql(StringBuffer conditionSql, Set<String> participatedClasses, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) {
    StringBuffer selectSql = new StringBuffer();
    String conditionClassName = getCondition().getClassCondition().getClassName();
    selectSql.append("SELECT ").append(getDummyClassName(conditionClassName, getClassNameSuffix())).append(".");
    selectSql.append("CMDB_ID");

    participatedClasses.add(getDummyClassName(conditionClassName, getClassNameSuffix()));

    addFromSql(selectSql, participatedClasses);

    selectSql.append(" WHERE ");
    selectSql.append("1=1");

    addPairsJoinSql(selectSql, participatedClasses, bindVariables, bindVariablesTypes);

    conditionSql.insert(0, selectSql);
  }

  protected void addPairsJoinSql(StringBuffer selectSql, Collection<String> participatedClassesSet, List<Object> bindVariables, List<CmdbType> bindVariablesTypes)
  {
    Iterator classesIter = participatedClassesSet.iterator();
    String firstClassName = (String)classesIter.next();

    while (classesIter.hasNext()) {
      String participatedClassDummyName = (String)classesIter.next();
      selectSql.append(" AND ");
      selectSql.append(firstClassName).append(".").append("CMDB_ID");
      selectSql.append("=");
      selectSql.append(participatedClassDummyName).append(".").append("CMDB_ID");
      if (!(isUpdateClassModelEnabled())) {
        selectSql.append(" AND ");
        selectSql.append(firstClassName).append(".").append("CUSTOMER_ID");
        selectSql.append("=");
        selectSql.append(participatedClassDummyName).append(".").append("CUSTOMER_ID");
      }
    }

    if (!(isUpdateClassModelEnabled())) {
      selectSql.append(" AND ");
      selectSql.append(firstClassName).append(".").append("CUSTOMER_ID");
      selectSql.append("=?");

      bindVariables.add(0, Integer.valueOf(getCustomerID().getID()));
      bindVariablesTypes.add(0, CmdbSimpleTypes.CmdbInteger);
    }
  }

  protected void addFromSql(StringBuffer selectSql, Set<String> participatedClasses) {
    selectSql.append(" FROM ");
    Iterator classesIter = participatedClasses.iterator();
    while (classesIter.hasNext()) {
      String participatedClassDummyName = (String)classesIter.next();

      selectSql.append(extractOriginalClassName(participatedClassDummyName, getClassNameSuffix().length()));
      selectSql.append(" ").append(participatedClassDummyName);
      if (classesIter.hasNext())
        selectSql.append(", ");
    }
  }

  protected String getDummyClassName(String className, String classNameSuffix)
  {
    return getTableNameByClassName(className);
  }

  protected String extractOriginalClassName(String dummyClassName, int classNameSuffixLength)
  {
    return dummyClassName;
  }

  protected String getClassNameSuffix() {
    return this._classNameSuffix;
  }

  protected void setClassNameSuffix(String classNameSuffix) {
    this._classNameSuffix = classNameSuffix;
  }

  protected ElementCondition getCondition() {
    return this._condition;
  }

  private void setCondition(ElementCondition condition) {
    this._condition = condition;
  }

  private int getNumberTempTableIndex() {
    return this._numberTempTableIndex;
  }

  private void setNumberTempTableIndex(int numberTempTableIndex) {
    this._numberTempTableIndex = numberTempTableIndex;
  }

  private int getStringTempTableIndex() {
    return this._stringTempTableIndex;
  }

  private void setStringTempTableIndex(int stringTempTableIndex) {
    this._stringTempTableIndex = stringTempTableIndex;
  }

  private int getTempTableIndex(CmdbType type) {
    if (CmdbSimpleTypes.CmdbInteger.equals(type))
      return getNumberTempTableIndex();

    if (CmdbSimpleTypes.CmdbString.equals(type))
      return getStringTempTableIndex();

    throw new CmdbDalException("There is no temp table for cmdb type [" + type + "] !!!");
  }

  private void setTempTableIndex(CmdbType type, int tempTableIndex) {
    if (CmdbSimpleTypes.CmdbInteger.equals(type))
      setNumberTempTableIndex(tempTableIndex);
    else if (CmdbSimpleTypes.CmdbString.equals(type))
      setStringTempTableIndex(tempTableIndex);
    else
      throw new CmdbDalException("There is no temp table for cmdb type [" + type + "] !!!");
  }
}