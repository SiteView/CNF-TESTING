package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;

public abstract class CmdbDalAbstractUpdateAttributeValueSizeComplexCommand extends CmdbDalUpdateAttributePropertyComplexCommand
{
  public CmdbDalAbstractUpdateAttributeValueSizeComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass)
  {
    super(attribute, cmdbClass);
  }

  protected String getCommandName() {
    return "Update value size of attribute [" + getAttribute().getName() + "] in class [" + getCmdbClass().getName() + "] to [" + ((CmdbAttribute)getAttribute()).getSizeLimit() + "]";
  }
}