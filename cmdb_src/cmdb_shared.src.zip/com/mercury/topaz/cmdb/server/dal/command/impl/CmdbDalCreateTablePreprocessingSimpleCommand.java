package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.DBColumnType;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public class CmdbDalCreateTablePreprocessingSimpleCommand extends CmdbDalAbstractCommand
{
  private static final int MAX_ROW_SIZE = 8060;
  private static final int DEFAULT_RAW_COLUMN_SIZE = 16;
  private static final int DEFAULT_STRING_COLUMN_SIZE = 50;
  private static final int MAX_STRING_COLUMN_SIZE = 4000;
  private final TableDescription tableDescription;

  public CmdbDalCreateTablePreprocessingSimpleCommand(TableDescription tableDescription)
  {
    this.tableDescription = tableDescription;
  }

  protected void validateInput() {
    if ((getTableName() == null) || (getTableName().length() == 0))
      throw new CmdbDalException("null or empty table name");
  }

  protected Object perform() throws Exception
  {
    performPreprocessing();

    return null;
  }

  private void performPreprocessing() {
    verifyRowLength();
    verifyTableName();
    verifyColumnsNames();
  }

  private void verifyColumnsNames() {
    if (!(areValidColumnsNames())) {
      String errMsg = "Can't create\\update table [" + getTableName() + "], with columns [" + this.tableDescription.getColumns().keySet() + "]. Columns names not valid !!!";

      throw new CmdbDalException(errMsg);
    }
  }

  private void verifyTableName() {
    if (!(isValidTableName())) {
      String errMsg = "Can't create table [" + getTableName() + "]. Not a valid table name !!!";
      throw new CmdbDalException(errMsg);
    }
  }

  private void verifyRowLength() {
    if (DBType.isOracle(getConnection().getDBType())) {
      return;
    }

    String version = JDBCTemplate.getInstance(getConnection()).queryForString("select serverproperty('ProductVersion')");
    if (version.startsWith("9")) {
      return;
    }

    if (calcRowLength() > 8060) {
      String errMsg = "Can't create\\update table [" + getTableName() + "], with columns [" + this.tableDescription.getColumns().keySet() + "]. Row size exceeds " + 8060 + " bytes !!!";

      throw new CmdbDalException(errMsg);
    }
  }

  private boolean isValidTableName() {
    return isValidDBName(getTableName());
  }

  private boolean areValidColumnsNames() {
    return areValidColumnsNames(this.tableDescription.getColumns().keySet());
  }

  protected boolean areValidColumnsNames(Collection<String> columnNames) {
    for (Iterator i$ = columnNames.iterator(); i$.hasNext(); ) { String columnName = (String)i$.next();
      if (!(isValidDBName(columnName)))
        return false;

    }

    return true;
  }

  private boolean isValidDBName(String name) {
    for (int i = 0; i < name.length(); ++i) {
      char ch = name.charAt(i);
      if ((!(Character.isLetterOrDigit(ch))) && (ch != "_".charAt(0)))
        return false;
    }

    return true;
  }

  private int calcRowLength() {
    int rowLength = 0;
    for (Iterator i$ = this.tableDescription.getColumns().values().iterator(); i$.hasNext(); ) { ColumnDescription columnDescription = (ColumnDescription)i$.next();
      rowLength += getMSSqlColumnBytesSizeFromCmdbSize(columnDescription.getType(), columnDescription.getSize());
    }

    return rowLength;
  }

  private int getMSSqlColumnBytesSizeFromCmdbSize(DBColumnType type, Integer cmdbSize)
  {
    int columnSize = 0;

    switch (1.$SwitchMap$com$mercury$topaz$cmdb$server$dal$DBColumnType[type.ordinal()])
    {
    case 1:
      columnSize = 9;
      break;
    case 2:
      columnSize = (cmdbSize == null) ? 16 : cmdbSize.intValue();
      break;
    case 3:
      columnSize = 16;
      break;
    case 4:
    case 5:
      columnSize = 8;
      break;
    case 6:
    case 7:
      columnSize = 9;
      break;
    case 8:
      columnSize = 50;
      if ((cmdbSize != null) && (cmdbSize.intValue() > 4000)) {
        columnSize = 4000;
        break label157: } if ((cmdbSize != null) && (cmdbSize.intValue() == 0)) {
        columnSize = 50;
        break label157: } if (cmdbSize == null) break label157;
      columnSize = cmdbSize.intValue();
      break;
    case 9:
      columnSize = 8;
    }
    label157: return columnSize;
  }

  private String getTableName() {
    return this.tableDescription.getTableName();
  }
}