package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;

public class CmdbDalUpdateObjectsComplexCommand extends CmdbDalUpdateElementsComplexCommand<CmdbObject>
{
  public CmdbDalUpdateObjectsComplexCommand(CmdbObjects objects)
  {
    super(objects);
  }
}