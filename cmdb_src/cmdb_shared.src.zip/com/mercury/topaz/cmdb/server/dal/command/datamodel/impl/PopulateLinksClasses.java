package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.DBColumnType;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.dal.util.table.TableUtils;

public class PopulateLinksClasses extends CmdbDalAbstractCommand
{
  protected Object perform()
    throws Exception
  {
    String rootTable = getTableNameByClassName("root");
    String linkTable = getTableNameByClassName("link");

    ColumnDescription columnDesc = new ColumnDescription("CLASS").ofType(DBColumnType.VARCHAR).ofSize(100).notNullable();

    TableModifications mods = new TableModifications();
    mods.addColumn(columnDesc);
    mods.addIndex(new IndexDescription("CLASS"));

    TableUtils.mirrorColumn(rootTable, linkTable, "CLASS", mods);

    return null;
  }

  protected void validateInput()
  {
  }
}