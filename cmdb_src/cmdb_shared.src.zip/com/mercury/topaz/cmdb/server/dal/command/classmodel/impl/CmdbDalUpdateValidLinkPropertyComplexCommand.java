package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import java.sql.SQLException;

public abstract class CmdbDalUpdateValidLinkPropertyComplexCommand extends CmdbDalUpdatePropertyComplexCommand
{
  private CmdbValidLink _validLink = null;

  public CmdbDalUpdateValidLinkPropertyComplexCommand(CmdbValidLink validLink)
  {
    super(null);
    setValidLink(validLink);
  }

  protected void validateInput() {
    if (getValidLink() == null)
      throw new CmdbDalException("Can't update null valid link");
  }

  protected String getTableNameToUpdate()
  {
    return "CCM_VALIDLINK";
  }

  protected String getRowIdConditionColumnName() {
    return "VALID_LINK_ID";
  }

  protected Long getRowId() throws SQLException {
    Long validLinkId = getValidLinkID(getValidLink(), getConnection());
    return validLinkId;
  }

  protected CmdbValidLink getValidLink() {
    return this._validLink;
  }

  private void setValidLink(CmdbValidLink validLink) {
    this._validLink = validLink;
  }
}