package com.mercury.topaz.cmdb.server.dal;

import java.util.ArrayList;
import java.util.List;

public class TableModifications
  implements TableAdditions
{
  private final List<IndexDescription> indexesToAdd;
  private final List<IndexDescription> indexesToRemove;
  private final List<ColumnDescription> columnsToRemove;
  private final List<ColumnDescription> columnsToAdd;
  private final List<String> columnsToMakeNullable;
  private final List<String> columnsToMakeNonNullable;
  private final List<ColumnDescription> columnsToChangeSize;

  public TableModifications()
  {
    this.indexesToAdd = new ArrayList();
    this.indexesToRemove = new ArrayList();
    this.columnsToRemove = new ArrayList();
    this.columnsToAdd = new ArrayList();
    this.columnsToMakeNullable = new ArrayList();
    this.columnsToMakeNonNullable = new ArrayList();
    this.columnsToChangeSize = new ArrayList(); }

  public void addIndex(IndexDescription indexDescription) {
    this.indexesToAdd.add(indexDescription);
  }

  public void removeIndex(IndexDescription indexDescription) {
    this.indexesToRemove.add(indexDescription);
  }

  public void addColumn(ColumnDescription columnDescription) {
    this.columnsToAdd.add(columnDescription);
  }

  public void removeColumn(ColumnDescription columnDescription) {
    this.columnsToRemove.add(columnDescription);
  }

  public void makeColumnNullable(String columnName) {
    this.columnsToMakeNullable.add(columnName);
  }

  public void makeColumnNonNullable(String columnName) {
    this.columnsToMakeNonNullable.add(columnName);
  }

  public void changeColumnSize(ColumnDescription columnDescription) {
    this.columnsToChangeSize.add(columnDescription);
  }

  public List<IndexDescription> getIndexesToAdd() {
    return this.indexesToAdd;
  }

  public List<IndexDescription> getIndexesToRemove() {
    return this.indexesToRemove;
  }

  public List<ColumnDescription> getColumnsToAdd() {
    return this.columnsToAdd;
  }

  public List<ColumnDescription> getColumnsToRemove() {
    return this.columnsToRemove;
  }

  public List<String> getColumnsToMakeNullable() {
    return this.columnsToMakeNullable;
  }

  public List<String> getColumnsToMakeNonNullable() {
    return this.columnsToMakeNonNullable;
  }

  public List<ColumnDescription> getColumnsToChangeSize() {
    return this.columnsToChangeSize;
  }
}