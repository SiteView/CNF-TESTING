package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class CmdbDalRemoveTableComplexCommand extends CmdbDalAbstractCommand
{
  private String _tableName = null;

  public CmdbDalRemoveTableComplexCommand(String tableName)
  {
    setTableName(tableName);
  }

  protected void validateInput() {
    if (getTableName() == null)
      throw new CmdbDalException("Can't remove table. null table name !!!");
  }

  protected Object perform() throws Exception
  {
    removeLogicalTable();
    return null;
  }

  private void removeLogicalTable()
  {
    if (checkTableExistence(getTableName()))
      if (isUpdateClassModelEnabled()) {
        removeTable();
      }
      else
        removePartition();
  }

  private void removePartition()
  {
    if (isOracle()) {
      StringBuffer sqlString = new StringBuffer();
      sqlString.append("alter table ").append(getTableName()).append(" drop partition cust_");
      sqlString.append(getCustomerID().getID()).append(" UPDATE GLOBAL INDEXES");

      getConnection().executeAdhocSql(sqlString.toString());
    }
  }

  private void removeTable() {
    StringBuffer sqlString = new StringBuffer();
    sqlString.append("drop table ").append(getTableName());

    getConnection().executeAdhocSql(sqlString.toString());
  }

  private String getTableName() {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    this._tableName = tableName;
  }
}