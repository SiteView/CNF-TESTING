package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.dal.util.table.TableUtils;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import java.util.Iterator;
import java.util.List;

public class CmdbDalUpdateTableRemoveColumnsComplexCommand extends AbstractTableManagementCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalUpdateTableRemoveColumnsComplexCommand.class);
  private final TableModifications modifications;

  public CmdbDalUpdateTableRemoveColumnsComplexCommand(TableDescription currentTable, TableModifications modifications)
  {
    super(currentTable);
    this.modifications = modifications;
  }

  protected Void perform() {
    removeColumns();
    return null;
  }

  protected String getCommandName() {
    return "Update table [" + getTableName() + "] by remove columns columns [" + this.modifications.getColumnsToRemove() + "]";
  }

  private void removeColumns() {
    for (Iterator i$ = this.modifications.getColumnsToRemove().iterator(); i$.hasNext(); ) { ColumnDescription columnDescription = (ColumnDescription)i$.next();
      removeColumn(columnDescription.getName());
    }
  }

  private void removeColumn(String columnName) {
    synchronized (getLock()) {
      if (TableUtils.isColumnExist(getTableName(), columnName)) {
        if (_logger.isDebugEnabled()) {
          _logger.debug("Remove column [" + columnName + "], from table [" + getTableName() + "]");
        }

        StringBuffer sqlString = new StringBuffer();
        sqlString.append("ALTER TABLE ").append(getTableName());
        sqlString.append(" drop column ").append(columnName);

        getConnection().executeAdhocSql(sqlString.toString());

        getConnection().commit();
      }
    }
  }
}