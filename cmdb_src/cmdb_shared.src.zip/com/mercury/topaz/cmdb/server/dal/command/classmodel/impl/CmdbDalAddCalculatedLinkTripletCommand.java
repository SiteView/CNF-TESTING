package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CalculatedLinkTripletDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalAddCalculatedLinkTripletCommand extends CmdbDalAddCalculatedLinkComplexCommand
{
  private CalculatedLinkTripletDefinition _triplet;
  private Long _linkClassID;

  public CmdbDalAddCalculatedLinkTripletCommand(CmdbClass cmdbClass, CmdbCalculatedLink calculatedLink, CalculatedLinkTripletDefinition triplet, Long classID)
  {
    super(calculatedLink, cmdbClass);
    setTriplet(triplet);
    setLinkClassID(classID);
  }

  protected void validateInput() {
    if (getTriplet() == null)
      throw new CmdbDalException("Can't add null triplet !!!");
  }

  protected Object perform() throws Exception
  {
    addTriplets();
    return null;
  }

  protected String getCommandName() {
    return "Add triplet [" + getTriplet() + "] for link [" + getCalculatedLink().getName() + "]";
  }

  private void addTriplets() throws SQLException {
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalConnection connection = getConnection();
    try
    {
      String sqlString = createInsertTripletTableSql();
      preparedStatement = connection.prepareStatement4Update(sqlString);

      fillPrepareStatementAndExecute(preparedStatement, getLinkClassID(), getTriplet());
    }
    finally {
      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  protected void fillPrepareStatementAndExecute(CmdbDalPreparedStatement preparedStatement, Long classID, CalculatedLinkTripletDefinition triplet) throws SQLException
  {
    addTriplet(preparedStatement, classID, triplet);
  }

  private Long addTriplet(CmdbDalPreparedStatement preparedStatement, Long classID, CalculatedLinkTripletDefinition triplet) throws SQLException {
    Long tripletId = generateAndConfirmSequenceID();
    preparedStatement.setLong(tripletId);
    preparedStatement.setString(triplet.getEnd1Type());
    preparedStatement.setString(triplet.getEnd2Type());
    preparedStatement.setString(triplet.getLinkType());
    preparedStatement.setBoolean(triplet.isForward());
    preparedStatement.setLong(classID);
    preparedStatement.setLong(getCustomerID().getID());

    preparedStatement.executeUpdate();

    return tripletId;
  }

  private String createInsertTripletTableSql()
  {
    List columnsNames = createCalculatedLinkTableColumnsNames();

    return createInsertSql("CCM_SIMPLE_CALC_LINK_TRIPLET", columnsNames);
  }

  protected CalculatedLinkTripletDefinition getTriplet() {
    return this._triplet;
  }

  private void setTriplet(CalculatedLinkTripletDefinition triplet) {
    this._triplet = triplet;
  }

  private void setLinkClassID(Long classID) {
    this._linkClassID = classID;
  }
}