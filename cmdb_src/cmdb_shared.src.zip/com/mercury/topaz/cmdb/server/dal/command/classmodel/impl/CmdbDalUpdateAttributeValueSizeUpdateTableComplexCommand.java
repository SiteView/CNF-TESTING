package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;

public class CmdbDalUpdateAttributeValueSizeUpdateTableComplexCommand extends CmdbDalUpdateAttributeValueSizeComplexCommand
{
  public CmdbDalUpdateAttributeValueSizeUpdateTableComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass)
  {
    super(attribute, cmdbClass);
  }

  protected void validateInput() {
    super.validateInput();
    updateTablePreprocessing();
  }

  protected Void perform() throws Exception {
    super.perform();
    return null;
  }

  private void updateTablePreprocessing() {
    String tableName = getTableNameByClassName(getCmdbClass().getName());
    TableDescription tableDescription = new TableDescription(tableName);
    updateCmdbClassDataLists(tableDescription);

    CmdbDalCommand preprocessingCommand = CmdbDalCommandFactory.createCreateTablePreprocessingSimpleCommand(tableDescription);
    preprocessingCommand.execute();
  }

  private void updateCmdbClassDataLists(TableDescription tableDescription)
  {
    updateDefaultColumnsLists(tableDescription, getCmdbClass());

    updateAttributesDataTableLists(getCmdbClass(), tableDescription);

    updateTableIndicesLists(getCmdbClass(), tableDescription);
  }
}