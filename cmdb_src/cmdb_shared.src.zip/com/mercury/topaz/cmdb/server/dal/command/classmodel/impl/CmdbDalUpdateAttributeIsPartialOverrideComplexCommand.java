package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import java.sql.SQLException;

public class CmdbDalUpdateAttributeIsPartialOverrideComplexCommand extends CmdbDalUpdateAttributePropertyComplexCommand
{
  public CmdbDalUpdateAttributeIsPartialOverrideComplexCommand(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass)
  {
    super(attributeOverride, cmdbClass);
  }

  protected String getCommandName() {
    return "Update is partial of attribute [" + getAttribute().getName() + "] in class [" + getCmdbClass().getName() + "] to [" + getAttribute().isPartiallyOverride() + "]";
  }

  protected String getColumnNameToUpdate() {
    return "PARTIAL_OVERRIDE";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long attributeId) throws SQLException {
    preparedStatement.setBoolean(getAttribute().isPartiallyOverride());
    preparedStatement.setBoolean(getAttribute().isModifiedByUser());
    preparedStatement.setLong(attributeId);
  }
}