package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CmdbDalGetRecursiveDeleteSurvivorObjects extends CmdbDalDataModelComplexCommand<CmdbObjectIds>
{
  public static final int DEPENDED_END1_TMP_TABLE_INDX = 1;
  public static final int DEPENDED_END2_TMP_TABLE_INDX = 2;
  public static final int ALREADY_DELETED_TMP_TABLE_INDEX = 3;
  private CmdbLinks _dependedEnd1Links = null;
  private CmdbLinks _dependedEnd2Links = null;
  private CmdbLinkIds _alreadyDeletedLinks = null;

  CmdbDalGetRecursiveDeleteSurvivorObjects(CmdbLinks dependedEnd1Links, CmdbLinks dependedEnd2Links, CmdbLinkIds alreadyDeletedLinks)
  {
    setDependedEnd1Links(dependedEnd1Links);
    setDependedEnd2Links(dependedEnd2Links);
    setAlreadyDeletedLinks(alreadyDeletedLinks);
  }

  protected CmdbObjectIds perform() throws Exception
  {
    CmdbDalConnection connection = getConnection();
    CmdbDalResultSet resultSet = null;
    CmdbDalPreparedStatement preparedStatement = null;
    try
    {
      List bindVariables = new ArrayList();
      List bindVariablesTypes = new ArrayList();

      String sqlString = createSqlQuery(bindVariables, bindVariablesTypes, connection);
      preparedStatement = createAndFillPreparedStatement(connection, sqlString, bindVariables, bindVariablesTypes);
      resultSet = preparedStatement.executeQuery();

      CmdbObjectIds localCmdbObjectIds = getResult(resultSet);

      return localCmdbObjectIds;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private String createSqlQuery(List<Object> bindVariables, List<CmdbType> bindVariablesTypes, CmdbDalConnection connection)
    throws SQLException
  {
    StringBuffer sqlEnd1 = new StringBuffer();
    StringBuffer sqlEnd2 = new StringBuffer();

    truncateCmdbIDTempTable(connection);

    fillTmpTableWithAlreadyDeletedIds(connection);

    if (hasEnd1DependedLinks()) {
      createDependedEndSurvivorsSql(sqlEnd1, "END1_ID", "END2_ID", getDependedEnd1Links(), bindVariables, bindVariablesTypes, 1, connection);
    }

    if ((hasEnd1DependedLinks()) && (!(hasEnd2DependedLinks()))) {
      return sqlEnd1.toString();
    }

    if (hasEnd2DependedLinks()) {
      createDependedEndSurvivorsSql(sqlEnd2, "END2_ID", "END1_ID", getDependedEnd2Links(), bindVariables, bindVariablesTypes, 2, connection);
    }

    if ((hasEnd2DependedLinks()) && (!(hasEnd1DependedLinks()))) {
      return sqlEnd2.toString();
    }

    return sqlEnd1.toString() + " UNION ALL " + sqlEnd2.toString();
  }

  protected CmdbDalPreparedStatement createAndFillPreparedStatement(CmdbDalConnection connection, String sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes)
    throws SQLException
  {
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Select(sqlString);

    for (int i = 0; i < bindVariables.size(); ++i)
      DalTypeUtil.setObject(preparedStatement, bindVariables.get(i), (CmdbType)bindVariablesTypes.get(i));

    return preparedStatement;
  }

  protected CmdbObjectIds getResult(CmdbDalResultSet resultSet) throws SQLException {
    CmdbObjectIds ids = CmdbObjectIdsFactory.create();
    while (resultSet.next()) {
      byte[] idAsBytes = resultSet.getBytes(1);
      ids.add(restoreObjectID(idAsBytes));
    }
    return ids;
  }

  protected void validateInput() {
    if ((((getDependedEnd1Links() == null) || (getDependedEnd1Links().isEmpty()))) && (((getDependedEnd2Links() == null) || (getDependedEnd2Links().isEmpty()))))
    {
      throw new CmdbDalException("No Input Link Ids to analyze !!!");
    }
  }

  private void createDependedEndSurvivorsSql(StringBuffer sqlString, String dependedEnd, String notDependedEnd, CmdbLinks dependedEndLinks, List<Object> bindVariables, List<CmdbType> bindVariablesTypes, int dependedEndTmpTableIndx, CmdbDalConnection connection)
    throws SQLException
  {
    String sql = "select l1." + dependedEnd + " from " + getTableNameByClassName("link") + " l1, " + getTableNameByClassName("link") + " l2 " + " where " + "l1." + dependedEnd + " = l2." + dependedEnd + " AND " + "l1." + notDependedEnd + " <> l2." + notDependedEnd + " AND " + "l1." + "CLASS" + " = l2." + "CLASS";

    sqlString.append(sql);

    sqlString.append(" AND ");

    addDependedEndIDsCondition(convert2List(dependedEndLinks), sqlString, dependedEndTmpTableIndx, connection, bindVariables, bindVariablesTypes);

    sqlString.append(" AND NOT ");
    createAlreadyDeletedTmpTableJoin(sqlString, bindVariables, bindVariablesTypes);
  }

  private void addDependedEndIDsCondition(List<byte[]> linkIds, StringBuffer sqlString, int tempTableIndex, CmdbDalConnection connection, List<Object> bindVariables, List<CmdbType> bindVariablesTypes)
    throws SQLException
  {
    fillCmdbIDTempTable(connection, linkIds, tempTableIndex);
    sqlString.append(createJoinWithCmdbIDTempTableIndexConditionSql("l1", -1));
    bindVariables.add(Integer.valueOf(tempTableIndex));
    bindVariablesTypes.add(CmdbSimpleTypes.CmdbInteger);
  }

  private void createAlreadyDeletedTmpTableJoin(StringBuffer sqlString, List<Object> bindVariables, List<CmdbType> bindVariablesTypes)
  {
    sqlString.append(createJoinWithCmdbIDTempTableIndexConditionSql("l2", -1));
    bindVariables.add(Integer.valueOf(3));
    bindVariablesTypes.add(CmdbSimpleTypes.CmdbInteger);
  }

  private void fillTmpTableWithAlreadyDeletedIds(CmdbDalConnection connection)
    throws SQLException
  {
    List alreadyDeleted = new ArrayList();

    if (hasAlreadyDeletedLinks())
      alreadyDeleted.addAll(convertLinkIds2List(getAlreadyDeletedLinks()));

    if (hasEnd1DependedLinks())
      alreadyDeleted.addAll(convert2List(getDependedEnd1Links()));

    if (hasEnd2DependedLinks())
      alreadyDeleted.addAll(convert2List(getDependedEnd2Links()));

    fillCmdbIDTempTable(connection, alreadyDeleted, 3);
  }

  public List<byte[]> convert2List(CmdbLinks links) {
    List list = new ArrayList();
    ReadOnlyIterator it = links.getLinksIterator();
    while (it.hasNext()) {
      CmdbDataID objectID = (CmdbDataID)((CmdbLink)it.next()).getID();
      list.add(convertCmdbID2Bytes(objectID));
    }
    return list;
  }

  public List<byte[]> convertLinkIds2List(CmdbLinkIds links) {
    List list = new ArrayList();
    ReadOnlyIterator it = links.getLinkIdsIterator();
    while (it.hasNext()) {
      CmdbDataID objectID = (CmdbDataID)it.next();
      list.add(convertCmdbID2Bytes(objectID));
    }
    return list;
  }

  private CmdbLinks getDependedEnd1Links() {
    return this._dependedEnd1Links;
  }

  private void setDependedEnd1Links(CmdbLinks dependedEnd1Links) {
    this._dependedEnd1Links = dependedEnd1Links;
  }

  private CmdbLinks getDependedEnd2Links() {
    return this._dependedEnd2Links;
  }

  private void setDependedEnd2Links(CmdbLinks dependedEnd2Links) {
    this._dependedEnd2Links = dependedEnd2Links;
  }

  private CmdbLinkIds getAlreadyDeletedLinks() {
    return this._alreadyDeletedLinks;
  }

  private void setAlreadyDeletedLinks(CmdbLinkIds alreadyDeletedLinks) {
    this._alreadyDeletedLinks = alreadyDeletedLinks;
  }

  private boolean hasAlreadyDeletedLinks() {
    return ((getAlreadyDeletedLinks() != null) && (!(getAlreadyDeletedLinks().isEmpty())));
  }

  private boolean hasEnd1DependedLinks() {
    return ((getDependedEnd1Links() != null) && (!(getDependedEnd1Links().isEmpty())));
  }

  private boolean hasEnd2DependedLinks() {
    return ((getDependedEnd2Links() != null) && (!(getDependedEnd2Links().isEmpty())));
  }
}