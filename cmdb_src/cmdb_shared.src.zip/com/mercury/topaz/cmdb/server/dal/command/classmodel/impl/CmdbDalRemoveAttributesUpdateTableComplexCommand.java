package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class CmdbDalRemoveAttributesUpdateTableComplexCommand extends CmdbDalRemoveAttributesComplexCommand
{
  public CmdbDalRemoveAttributesUpdateTableComplexCommand(BasicContainer attributes, CmdbClass cmdbClass, Long classId)
  {
    super(attributes, cmdbClass, classId);
  }

  public CmdbDalRemoveAttributesUpdateTableComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass, Long classId) {
    super(attribute, cmdbClass, classId);
  }

  protected Void perform() throws Exception {
    super.perform();

    getConnection().commit();

    if (isUpdateClassModelEnabled())
      updateTable();

    return null;
  }

  private void updateTable() {
    String tableName = getTableNameByClassName(getCmdbClass().getName());
    TableDescription currentTableDescription = new TableDescription(tableName);
    TableModifications tableModifications = new TableModifications();

    removeConstraints(currentTableDescription, tableModifications);

    removeColumns(currentTableDescription, tableModifications);
  }

  private void removeConstraints(TableDescription tableDescription, TableModifications tableModifications)
  {
    updateListsOfColumnsToRemoveConstraints(tableModifications);

    CmdbDalCommand updateTableCommand = CmdbDalCommandFactory.createUpdateTableUpdateColumnsComplexCommand(tableDescription, tableModifications);
    updateTableCommand.execute();
  }

  private void removeColumns(TableDescription tableDescription, TableModifications tableModifications)
  {
    updateListOfColumnsToRemove((CmdbAttributes)getAttributes(), tableModifications);

    CmdbDalCommand updateTableCommand = CmdbDalCommandFactory.createUpdateTableRemoveColumnsComplexCommand(tableDescription, tableModifications);
    updateTableCommand.execute();
  }

  private void updateListOfColumnsToRemove(CmdbAttributes attributes, TableModifications tableModifications) {
    CmdbAttributes persistentAttributes = ClassModelUtil.extractPersistentAttributes(attributes);
    ReadOnlyIterator attributesIter = persistentAttributes.getIterator();
    while (attributesIter.hasNext()) {
      CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();

      if (isSimpleTypeAttribute(attribute))
        tableModifications.removeColumn(new ColumnDescription(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName())));
    }
  }

  private void updateListsOfColumnsToRemoveConstraints(TableModifications tableModifications)
  {
    CmdbAttributes attributes = (CmdbAttributes)getAttributes();
    ReadOnlyIterator attributesIter = attributes.getIterator();
    while (attributesIter.hasNext()) {
      CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();

      if (isIndexedAttribute(attribute))
        tableModifications.removeIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName())));
      else if (isUniqueIndexedAttribute(attribute))
        tableModifications.removeIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName())).unique());
    }
  }
}