package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.TransactionManager;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import java.util.Date;

public class CmdbDalChangesManagement
{
  public static final String CHANGE_SESSION_PROPERTY = "CHANGE";
  public static final long ONE_GENERATION_SIZE = 300000L;
  public static final long INITIAL_CHANGE = 0L;

  public static int getCurrentChangeTableGeneration(CmdbDalConnection connection)
  {
    long currentDBTime = getCurrentDBTime(connection);
    return (int)(currentDBTime / 300000L % 3L);
  }

  public static int getOldestChangeTableGeneration(CmdbDalConnection connection) {
    long currentDBTime = getCurrentDBTime(connection);

    return (int)(((currentDBTime + 150000L) / 300000L + 1L) % 3L);
  }

  private static long getCurrentDBTime(CmdbDalConnection connection) {
    String getDateSql = "SELECT ";
    if (DBType.isOracle(connection.getDBType()))
      getDateSql = getDateSql + "SYSDATE FROM DUAL";
    else
      getDateSql = getDateSql + "GETDATE()";

    JDBCTemplate jdbcTemplate = JDBCTemplate.getInstance(connection);
    Date currentDBDate = (Date)jdbcTemplate.queryForObject(getDateSql, new Object[0]);
    return currentDBDate.getTime();
  }

  public static long getCurrentChange() {
    CmdbDalConnection connection = TransactionManager.getConnection();
    return ((Change)connection.getProperty("CHANGE")).getChangeNumber();
  }

  public static Change getOrCreateNewChange() {
    CmdbDalConnection connection = TransactionManager.getConnection();
    Change change = (Change)connection.getProperty("CHANGE");
    if (change == null) {
      change = (Change)new CmdbDalCreateNewChange().execute().getResult();
      connection.setProperty("CHANGE", change);
    }
    return change;
  }

  public static void addAddedObjectsToCurrentChange(CmdbObjects addedObjects) {
    new CmdbDalAddObjectsChange(addedObjects).execute();
  }

  public static void addRemovedObjectsToCurrentChange(CmdbObjects removedObjects) {
    new CmdbDalRemoveObjectsChange(removedObjects).execute();
  }

  public static void addAddedLinksToCurrentChange(CmdbLinks addedLinks) {
    new CmdbDalAddLinksChange(addedLinks).execute();
  }

  public static void addRemovedLinksToCurrentChange(CmdbLinks removedLinks) {
    new CmdbDalRemoveLinksChange(removedLinks).execute();
  }

  public static abstract interface Columns
  {
    public static final String ID = "ID";
    public static final String MASTER = "MASTER";
    public static final String CHANGE_ID = "CHANGE_ID";
    public static final String CUSTOMER_ID = "CUSTOMER_ID";
    public static final String CHANGE_TIME = "CHANGE_TIME";
    public static final String CMDB_ID = "CMDB_ID";
    public static final String CLASS_NAME = "CLASS";
    public static final String END1_ID = "END1_ID";
    public static final String END2_ID = "END2_ID";
    public static final String IS_ADD = "IS_ADD";
    public static final String IS_OBJECT = "IS_OBJECT";
  }

  public static abstract interface Tables
  {
    public static final String CHANGES_MANAGEMENT = "TOPOLOGY_CHANGES_MGMT";
    public static final String CHANGES_DETAILS = "TOPOLOGY_CHANGES";
  }
}