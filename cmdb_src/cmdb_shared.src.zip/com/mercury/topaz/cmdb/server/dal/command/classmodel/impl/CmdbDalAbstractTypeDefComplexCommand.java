package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import java.util.List;

public abstract class CmdbDalAbstractTypeDefComplexCommand extends CmdbDalClassModelComplexCommand
{
  protected String createInsertTypeDefEnumTableSql()
  {
    List columnsNames = createTypeDefEnumTableColumnsNames();

    return createInsertSql("CCM_TDEF_ENUM", columnsNames);
  }
}