package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.ModelLinksFactory;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CmdbDalGetLinksLayoutComplexCommand extends CmdbDalGetLayoutComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalGetLinksLayoutComplexCommand.class);
  private ModelLinks _modelLinks = null;
  private ElementSimpleLayout _layout = null;

  public CmdbDalGetLinksLayoutComplexCommand(ModelLinks links, ElementSimpleLayout layout)
  {
    setModelLinks(links);
    setLayout(layout);
  }

  protected void validateInput()
  {
    if ((getModelLinks() == null) || (getModelLinks().size() == 0))
      _logger.info("Can't get links layout - empty or null model links. Returns empty list");

    if ((getLayout() == null) || ((!(getLayout().isAllLayer())) && (!(getLayout().getKeysIterator().hasNext()))))
      _logger.info("Empty or null layout. Returns the same links");
  }

  protected Object perform()
  {
    if ((getModelLinks() == null) || (getModelLinks().size() == 0))
      return CmdbLinkFactory.createEmptyLinks();

    if ((getLayout() == null) || ((!(getLayout().isAllLayer())) && (!(getLayout().getKeysIterator().hasNext()))))
      return getModelLinks().toCmdbLinks();

    if (_logger.isDebugEnabled())
      _logger.debug("Get links layout for [" + getModelLinks().size() + "] links");

    if (getLayout().isAllLayer())
      return getLinksLayout(getModelLinks());

    return getLinksLayout(getModelLinks(), getLayout());
  }

  private CmdbLinks getLinksLayout(ModelLinks links) {
    CmdbLinks layoutResult = CmdbLinkFactory.createLinks();

    Map elementsFromSameTypeMap = sortElementsToTypes(links);

    for (Iterator typesIter = elementsFromSameTypeMap.keySet().iterator(); typesIter.hasNext(); ) {
      String type = (String)typesIter.next();
      ModelLinks linksWithSameTypeContainer = (ModelLinks)elementsFromSameTypeMap.get(type);

      ElementSimpleLayout simpleLayout = createFullLayout(type);

      CmdbLinks cmdbLinksWithSameType = getLinksLayout(linksWithSameTypeContainer, simpleLayout);
      mergeCmdbElements(layoutResult, cmdbLinksWithSameType);
    }
    return layoutResult;
  }

  protected Map sortElementsToTypes(ModelLinks modelLinks) {
    Map elementsFromSameTypeMap = new HashMap();

    for (ReadOnlyIterator linksIter = modelLinks.getLinksIterator(); linksIter.hasNext(); ) {
      ModelLink modelLink = (ModelLink)linksIter.next();
      addElementToTypeSortedElementsMap(elementsFromSameTypeMap, modelLink);
    }
    return elementsFromSameTypeMap;
  }

  private void addElementToTypeSortedElementsMap(Map elementsFromSameTypeMap, ModelLink modelLink) {
    ModelLinks elementsWithSameTypeContainer = (ModelLinks)elementsFromSameTypeMap.get(modelLink.getType());
    if (elementsWithSameTypeContainer == null) {
      elementsWithSameTypeContainer = ModelLinksFactory.createLinksList();
      elementsFromSameTypeMap.put(modelLink.getType(), elementsWithSameTypeContainer);
    }
    elementsWithSameTypeContainer.add(modelLink);
  }

  private CmdbLinks getLinksLayout(ModelLinks links, ElementSimpleLayout requestedLayout)
  {
    ModelLink link = (ModelLink)links.getLinksIterator().next();
    String baseClassName = getBaseCmdbClass(link.getType(), requestedLayout);

    ElementSimpleLayout layout = extractPersistentLayout(requestedLayout, baseClassName);

    if (_logger.isDebugEnabled()) {
      StringBuffer logMsg = new StringBuffer();
      logMsg.append("Query for links layout [");
      logMsg.append(layout.toString());
      logMsg.append("] from base class [").append(baseClassName).append("]");
      _logger.debug(logMsg);
    }

    CmdbClass baseClass = ClassModelUtil.getCmdbClassByName(baseClassName);
    Map attributes2ClassesMap = createAttributes2ClassesMap(layout.getKeysIterator(), baseClass);

    List nonListOfAttribsPropertiesKeys = extractNonListOfAttribsProperties(layout, attributes2ClassesMap);
    List listOfAttribsPropertiesKeys = extractListOfAttribsProperties(layout, attributes2ClassesMap);

    if (isCmdbIDTempTableMustUsingChunksMechanism(links.size())) {
      if (_logger.isDebugEnabled())
        _logger.debug("Decide to use temp table to get layout for [" + links.size() + "] links");

      return getChunkLayout(links, baseClassName, attributes2ClassesMap, listOfAttribsPropertiesKeys, nonListOfAttribsPropertiesKeys);
    }

    int numOfChunks = calcNumOfInChunks(links.size());
    if (_logger.isDebugEnabled()) {
      _logger.debug("Decide to use [" + numOfChunks + "] in chunks. Chunk size [" + getMaxPossibleSizeForInChunk() + "]");
    }

    if (numOfChunks == 1) {
      return getChunkLayout(links, baseClassName, attributes2ClassesMap, listOfAttribsPropertiesKeys, nonListOfAttribsPropertiesKeys);
    }

    CmdbLinks resultLinks = CmdbLinkFactory.createLinks();
    for (int chunkNum = 0; chunkNum < numOfChunks; ++chunkNum) {
      ModelLinks chunkModelLinks = getInChunkLinks(links, chunkNum);
      CmdbLinks chunkLinks = getChunkLayout(chunkModelLinks, baseClassName, attributes2ClassesMap, listOfAttribsPropertiesKeys, nonListOfAttribsPropertiesKeys);

      mergeCmdbElements(resultLinks, chunkLinks);
    }
    return resultLinks;
  }

  private ModelLinks getInChunkLinks(ModelLinks links, int chunkNum) {
    ModelLinks chunkLinks = ModelLinksFactory.createLinks();
    int startPoint = getMaxPossibleSizeForInChunk() * chunkNum;
    int endPoint = getMaxPossibleSizeForInChunk() * (chunkNum + 1);
    int currentPoint = 0;

    ReadOnlyIterator linksIter = links.getLinksIterator();
    while ((linksIter.hasNext()) && (currentPoint < endPoint)) {
      ModelLink link = (ModelLink)linksIter.next();
      if (currentPoint >= startPoint)
        chunkLinks.add(link);

      ++currentPoint;
    }
    return chunkLinks;
  }

  private CmdbLinks getChunkLayout(ModelLinks links, String baseClassName, Map attributes2ClassesMap, List listOfAttribsPropertiesKeys, List nonListOfAttribsPropertiesKeys)
  {
    CmdbDalResultSet result = null;
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalPreparedStatement listOfAttribsPreparedStatement = null;
    CmdbDalResultSet listOfAttribsResult = null;
    try
    {
      CmdbDalConnection connection = getConnection();

      if (isCmdbIDTempTableMustUsingChunksMechanism(links.size())) {
        createCmdbIDTempTable(connection, links);
      }

      String sqlString = createLayoutSql(nonListOfAttribsPropertiesKeys, attributes2ClassesMap, baseClassName, links.size());
      preparedStatement = connection.prepareStatement4Select(sqlString);
      addValuesToPrepareStatement(preparedStatement, links, null);
      result = preparedStatement.executeQuery();

      if (listOfAttribsPropertiesKeys.size() > 0) {
        String listOfAttribsSqlString = createListOfAttribsLayoutSql(listOfAttribsPropertiesKeys.size(), links.size());
        listOfAttribsPreparedStatement = connection.prepareStatement4Select(listOfAttribsSqlString);
        addValuesToPrepareStatement(listOfAttribsPreparedStatement, links, listOfAttribsPropertiesKeys);
        listOfAttribsResult = listOfAttribsPreparedStatement.executeQuery();
      }

      CmdbLinks resultLinks = buildLayoutCmdbLinks(result, listOfAttribsResult, nonListOfAttribsPropertiesKeys, attributes2ClassesMap, listOfAttribsPropertiesKeys);
      if (resultLinks.size() != links.size())
        _logger.info("Links layout expect to return [" + links.size() + "] links. Instead return [" + resultLinks.size() + "] links");

      CmdbLinks localCmdbLinks1 = resultLinks;

      return localCmdbLinks1;
    }
    catch (Exception e)
    {
    }
    finally
    {
      String errMsg;
      if (result != null)
        result.close();

      if (listOfAttribsResult != null)
        listOfAttribsResult.close();

      if (preparedStatement != null)
        preparedStatement.close();

      if (listOfAttribsPreparedStatement != null)
        listOfAttribsPreparedStatement.close();
    }
  }

  private Map buildLinkIDsToModelLinksMap()
  {
    Map linkIDsToModelLinksMap = new HashMap();

    ReadOnlyIterator linksIter = getModelLinks().getLinksIterator();
    while (linksIter.hasNext()) {
      ModelLink link = (ModelLink)linksIter.next();
      linkIDsToModelLinksMap.put(link.getID(), link);
    }
    return linkIDsToModelLinksMap;
  }

  private CmdbLinks buildLayoutCmdbLinks(CmdbDalResultSet resultSet, CmdbDalResultSet listOfAttribsResultSet, List nonListOfAttribsPropertiesKeys, Map attributes2ClassesMap, List listOfAttribsPropertiesKeys)
    throws SQLException
  {
    Map linkIDsToModelLinksMap = buildLinkIDsToModelLinksMap();
    Map ids2PropertiesMap = buildIDs2PropertiesMap(listOfAttribsResultSet, attributes2ClassesMap);
    CmdbLinks links = CmdbLinkFactory.createLinks();

    int index = 0;
    while (resultSet.next()) {
      byte[] idAsBytes = resultSet.getBytes(1);
      CmdbLinkID linkID = CmdbLinkID.Factory.restoreLinkID(idAsBytes);

      ModelLink modelLink = (ModelLink)linkIDsToModelLinksMap.get(linkID);

      CmdbProperties properties = buildLayoutProperties(nonListOfAttribsPropertiesKeys, resultSet, attributes2ClassesMap);

      if (listOfAttribsPropertiesKeys.size() > 0) {
        CmdbProperties listProperties = (CmdbProperties)ids2PropertiesMap.get(getCmdbDigest(idAsBytes));
        properties = concatProperties(properties, listProperties);

        if ((listProperties == null) || (listOfAttribsPropertiesKeys.size() > listProperties.size()))
          addMissingListProperties(properties, listOfAttribsPropertiesKeys, attributes2ClassesMap);

      }

      CmdbLink link = buildCmdbLink(modelLink, linkID, properties);
      if (link != null) {
        links.add(link);
      }

      ++index;
      if (index % 5000 == 0)
        getConnectionPool().resetTimeout(getConnection());
    }

    return links;
  }

  private CmdbLink buildCmdbLink(ModelLink modelLink, CmdbLinkID linkID, CmdbProperties properties) {
    CmdbLink link = null;
    try {
      link = getDataFactory().restoreLink(linkID, modelLink.getType(), modelLink.getEnd1().toCmdbObjectID(), modelLink.getEnd2().toCmdbObjectID(), properties);
    }
    catch (Exception e) {
      _logger.error("!!! Fail to restore link with id [" + linkID + "], type [" + modelLink.getType() + "] and properties [" + properties + "], due to exception: " + e, e);
    }
    return link;
  }

  protected ModelLinks getModelLinks() {
    return this._modelLinks;
  }

  private void setModelLinks(ModelLinks modelLinks) {
    this._modelLinks = modelLinks;
  }

  private ElementSimpleLayout getLayout() {
    return this._layout;
  }

  private void setLayout(ElementSimpleLayout layout) {
    this._layout = layout;
  }
}