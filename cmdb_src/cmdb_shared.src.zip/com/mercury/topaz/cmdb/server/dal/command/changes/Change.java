package com.mercury.topaz.cmdb.server.dal.command.changes;

public class Change
{
  private long changeNumber;
  private int tableGeneration;

  public Change(long changeNumber, int tableGeneration)
  {
    this.changeNumber = changeNumber;
    this.tableGeneration = tableGeneration;
  }

  public long getChangeNumber() {
    return this.changeNumber;
  }

  public int getTableGeneration() {
    return this.tableGeneration;
  }
}