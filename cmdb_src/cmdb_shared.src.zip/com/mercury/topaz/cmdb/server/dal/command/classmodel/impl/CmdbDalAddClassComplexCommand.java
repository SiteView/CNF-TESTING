package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.common.qualifiedname.CmdbQualifiedNameFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalAddClassComplexCommand extends CmdbDalAbstractAddClassComplexCommand
{
  private Long _classID;

  public CmdbDalAddClassComplexCommand(CmdbClass cmdbClass)
  {
    super(cmdbClass);
  }

  protected Object perform() {
    addClass(getCmdbClass());
    return null;
  }

  private void addClass(CmdbClass cmdbClass) {
    CmdbDalConnection connection = getConnection();
    try {
      Long parentID = getClassParentID(cmdbClass, connection);
      setClassID(generateAndConfirmSequenceID());

      addClass(connection, getClassID(), cmdbClass, parentID);
      addClassQualifiers(cmdbClass, getClassID());
      addAttributes(cmdbClass, getClassID());
      addMethods(cmdbClass, getClassID());

      connection.commit();
    }
    catch (Exception e) {
      String errMsg = "Error adding cmdb class [" + cmdbClass.getName() + "], due to exception: " + e;

      if (connection != null)
        connection.rollback();

      throw new CmdbDalException(errMsg, e);
    }
  }

  private void addClass(CmdbDalConnection connection, Long classID, CmdbClass cmdbClass, Long parentID) throws SQLException {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createInsertClassesTableSql();
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);
    preparedStatement.setLong(classID);
    preparedStatement.setInt(customerID.getID());
    String classFullQualifiedName = cmdbClass.getName();
    String[] parsedClassName = CmdbQualifiedNameFactory.parseQualifiedName(classFullQualifiedName);
    preparedStatement.setString(parsedClassName[0]);
    preparedStatement.setString(parsedClassName[1]);
    preparedStatement.setString(cmdbClass.getDisplayName());
    preparedStatement.setLong(parentID);
    preparedStatement.setString(cmdbClass.getClassType());
    preparedStatement.setString(cmdbClass.getDescription());

    preparedStatement.setBoolean(true);

    preparedStatement.setBoolean(cmdbClass.isCreatedByFactory());
    preparedStatement.setBoolean(cmdbClass.isModifiedByUser());

    preparedStatement.executeUpdate();
    preparedStatement.close();
  }

  private void addMethods(CmdbClass cmdbClass, Long classID) {
    CmdbDalCommand addMethodsCommand = CmdbDalClassModelCommandFactory.createAddMethodsComplexCommand(cmdbClass.getClassMethods(), cmdbClass, classID);
    addMethodsCommand.execute();
  }

  private void addClassQualifiers(CmdbClass cmdbClass, Long classID) {
    CmdbDalCommand addClassQualifiersCommand = CmdbDalClassModelCommandFactory.createAddClassQualifiersComplexCommand(cmdbClass, cmdbClass.getClassQualifiers(), classID);
    addClassQualifiersCommand.execute();
  }

  private void addAttributes(CmdbClass cmdbClass, Long classID) {
    CmdbDalCommand addAttributesCommand = CmdbDalClassModelCommandFactory.createAddAttributesComplexCommand(cmdbClass.getClassAttributes(), cmdbClass, classID);
    addAttributesCommand.execute();
    CmdbDalCommand addAttributesOverrridesCommand = CmdbDalClassModelCommandFactory.createAddAttributesOverridesComplexCommand(cmdbClass.getAllAttributeOverrides(), cmdbClass, classID);
    addAttributesOverrridesCommand.execute();
  }

  private String createInsertClassesTableSql() {
    List columnsNames = createClassesTableColumnsNames();

    return createInsertSql("CCM_CLASSES", columnsNames);
  }

  private Long getClassParentID(CmdbClass cmdbClass, CmdbDalConnection connection) throws SQLException
  {
    CmdbDalPreparedStatement preparedStatement;
    if (cmdbClass.getSuperClass().equalsIgnoreCase("none")) {
      return null;
    }

    String[] parsedSuperClassName = CmdbQualifiedNameFactory.parseQualifiedName(cmdbClass.getSuperClass());
    String superClassName = parsedSuperClassName[1];
    String superClassNameSpace = parsedSuperClassName[0];
    superClassNameSpace = (superClassNameSpace == null) ? "" : superClassNameSpace;
    int customerID = getLocalEnvironment().getCustomerID().getID();
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("select ").append("CLASS_ID").append(" from ").append("CCM_CLASSES");
    sqlString.append(" where ").append("CLASS_NAME").append("=? and ").append("CUSTOMER_ID").append("=?");

    if ((superClassNameSpace != null) && (superClassNameSpace.length() > 0)) {
      sqlString.append(" and ").append("NAME_SPACE").append("=?");

      preparedStatement = connection.prepareStatement4Select(sqlString.toString());
      preparedStatement.setString(superClassName);
      preparedStatement.setInt(customerID);
      preparedStatement.setString(superClassNameSpace);
    }
    else {
      sqlString.append(" and ").append("NAME_SPACE").append(" is null");

      preparedStatement = connection.prepareStatement4Select(sqlString.toString());
      preparedStatement.setString(superClassName);
      preparedStatement.setInt(customerID);
    }

    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    if (!(resultSet.next())) {
      String errMsg = "There is no parent id for super class [" + superClassName + "], name space [" + superClassNameSpace + "], customer id [" + customerID + "]";

      throw new CmdbDalException(errMsg);
    }

    Long parentID = resultSet.getLong(1);
    resultSet.close();
    preparedStatement.close();

    return parentID;
  }

  protected Long getClassID() {
    return this._classID;
  }

  private void setClassID(Long classID) {
    this._classID = classID;
  }
}