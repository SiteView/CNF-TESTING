package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.result.CmdbModifiableAttributeGroupedByCount;
import com.mercury.topaz.cmdb.shared.tql.result.impl.CmdbAttributeGroupedByCountFactory;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

class CmdbDalGroupClassByAttributeComplexCommand extends CmdbDalObjectsConditionComplexCommand
{
  private String _attributeName;

  CmdbDalGroupClassByAttributeComplexCommand(ElementCondition elementCondition, ModelObjects objects, String attributeName)
  {
    super(elementCondition, objects);
    setAttributeName(attributeName);
  }

  protected void addSelectSql(StringBuffer conditionSql, Set<String> participatedClasses, List<Object> bindVariables, List<CmdbType> bindVariablesTypes) {
    StringBuffer selectSql = new StringBuffer();

    participatedClasses.add(getTableNameByClassName(getCondition().getClassCondition().getClassName()));
    selectSql.append("SELECT ");
    selectSql.append(DalClassModelUtil.getColumnNameByAttributeName(getAttributeName()));
    selectSql.append(", COUNT(*) ");
    CmdbClass attributeClass = ClassModelUtil.getAttributeClass(getAttributeName(), getCondition().getClassCondition().getClassName());

    participatedClasses.add(getDummyClassName(attributeClass.getName(), getClassNameSuffix()));

    addFromSql(selectSql, participatedClasses);

    selectSql.append(" WHERE ");
    selectSql.append("1=1");

    addPairsJoinSql(selectSql, participatedClasses, bindVariables, bindVariablesTypes);

    conditionSql.insert(0, selectSql);
    conditionSql.append(" GROUP BY ").append(DalClassModelUtil.getColumnNameByAttributeName(getAttributeName()));
  }

  protected Object getResult(CmdbDalResultSet resultSet) throws SQLException {
    int maxResults = getLocalEnvironment().getSettingsReader().getInt("dal.group.class.by.attribute.condition.max.result.size", 100000);
    CmdbModifiableAttributeGroupedByCount attributeCount = CmdbAttributeGroupedByCountFactory.createModifiableAttributeGroupedByCount();
    int currentResultCount = 0;
    while (resultSet.next()) {
      ++currentResultCount;
      if (currentResultCount > maxResults) {
        String errMsg = "Number of group class by attribut results exceeded the maximum allowed (max allowed value is: " + maxResults + ")";
        throw new CmdbDalException(errMsg);
      }
      String attributeValue = resultSet.getString(1);
      Integer count = resultSet.getInt(2);
      attributeCount.put(attributeValue, count);
    }
    return attributeCount;
  }

  private String getAttributeName()
  {
    return this._attributeName;
  }

  private void setAttributeName(String attributeName) {
    if (attributeName == null)
      throw new IllegalArgumentException("Received null");

    this._attributeName = attributeName;
  }
}