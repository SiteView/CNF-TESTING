package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;

public class CmdbDalGetColumnSizeSimpleCommand extends CmdbDalAbstractCommand<Integer>
{
  private String _tableName = null;
  private String _columnName = null;

  public CmdbDalGetColumnSizeSimpleCommand(String tableName, String columnName)
  {
    setTableName(tableName);
    setColumnName(columnName);
  }

  protected void validateInput() {
    if ((getTableName() == null) || (getTableName().length() == 0))
      throw new CmdbDalException("Can't get table meta data for table [" + getTableName() + "]");
  }

  protected Integer perform() throws Exception
  {
    return Integer.valueOf(getColumnSize());
  }

  private int getColumnSize() throws SQLException
  {
    String sqlString;
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;

    if (isOracle()) {
      sqlString = "SELECT DATA_LENGTH FROM USER_TAB_COLUMNS WHERE TABLE_NAME = ? AND COLUMN_NAME = ?";
    }
    else if (isMsSql()) {
      sqlString = "SELECT CHARACTER_MAXIMUM_LENGTH FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ? AND COLUMN_NAME = ?";
    }
    else
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");

    try
    {
      preparedStatement = getConnection().prepareStatement4Select(sqlString);
      preparedStatement.setString(getTableName());
      preparedStatement.setString(getColumnName());
      resultSet = preparedStatement.executeQuery();

      if (resultSet.next()) {
        columnSize = resultSet.getInt(1);
        if (columnSize != null) {
          int i = columnSize.intValue();

          return i;
        }
      }
      Integer columnSize = 0;

      return columnSize;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private String getTableName()
  {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    this._tableName = tableName;
  }

  private String getColumnName() {
    return this._columnName;
  }

  private void setColumnName(String columnName) {
    this._columnName = columnName;
  }
}