package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import java.sql.SQLException;

public class CmdbDalCheckIsRunStatisticsRequiredComplexCommand extends CmdbDalAbstractCommand<Boolean>
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalCheckIsRunStatisticsRequiredComplexCommand.class);

  protected void validateInput()
  {
  }

  private int getStatisticsStartupPercentageThreshold()
  {
    SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();
    return settingsReader.getInt("dal.statistics.startup.percentage.threshold", 5);
  }

  private int getStatisticsStartupAgingThreshold()
  {
    SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();
    return settingsReader.getInt("dal.statistics.startup.aging.threshold.hours", 36);
  }

  protected Boolean perform() throws Exception
  {
    return Boolean.valueOf(checkIsRunStatisticsRequired());
  }

  private boolean checkIsRunStatisticsRequired() throws SQLException {
    CmdbDalPreparedStatement preparedStatement = buildSqlQuery();
    CmdbDalResultSet resultSet = null;
    try
    {
      resultSet = preparedStatement.executeQuery();

      resultSet.next();

      Integer changes = resultSet.getInt(1);
      boolean res = changes.intValue() >= getStatisticsStartupPercentageThreshold();

      _logger.info("Checking statistics for the last " + getStatisticsStartupAgingThreshold() + " hours. " + changes + "% of the tables are not up to date. (Threshold is " + getStatisticsStartupPercentageThreshold() + "%)");

      if (res) {
        _logger.info("Runnimg statistics is required");
      }
      else
        _logger.info("Runnimg statistics is not required");

      boolean bool1 = res;

      return bool1;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private CmdbDalPreparedStatement buildSqlQuery()
    throws SQLException
  {
    CmdbDalPreparedStatement preparedStatement;
    String sqlString;
    if (getConnectionPool().isUsingOracle10gDB()) {
      if (!(getConnectionPool().isUsingOracle10gDBRelease1())) {
        sqlString = buildSqlQuery10g();
      }
      else
        sqlString = buildSqlQuery9i();

      preparedStatement = getConnection().prepareStatement4Select(sqlString);
      preparedStatement.setInt(getStatisticsStartupAgingThreshold());
    }
    else if (getConnectionPool().isUsingOracleDB()) {
      sqlString = buildSqlQuery9i();
      preparedStatement = getConnection().prepareStatement4Select(sqlString);
      preparedStatement.setInt(getStatisticsStartupAgingThreshold());
    }
    else if (getConnectionPool().isUsingMSSqlDB()) {
      sqlString = buildSqlQueryMSSqlDB();
      preparedStatement = getConnection().prepareStatement4Select(sqlString);
      preparedStatement.setInt(getStatisticsStartupAgingThreshold());
      preparedStatement.setInt(getStatisticsStartupAgingThreshold());
    }
    else {
      throw new CmdbDalException("Unknown db type [" + getConnectionPool().getDBType() + "] !!!");
    }
    return preparedStatement;
  }

  private String buildSqlQuery10g() {
    return "SELECT CEIL(COUNT(TAB1.TABLE_NAME) / DECODE(COUNT(TAB2.TABLE_NAME),0,1,COUNT(TAB2.TABLE_NAME))*100)\n" + "FROM (SELECT DISTINCT TABLE_NAME FROM USER_TAB_STATISTICS WHERE (TABLE_NAME LIKE 'CCM%' OR TABLE_NAME LIKE 'CDM%')) TAB2\n" + "LEFT OUTER JOIN\n" + "(SELECT MAX(NVL(TAB1.LAST_ANALYZED,SYSDATE-30)),TAB1.TABLE_NAME FROM USER_TAB_STATISTICS TAB1\n" + "WHERE NVL(TAB1.LAST_ANALYZED,SYSDATE-30)<SYSDATE-?/24\n" + "AND NVL(STALE_STATS,'YES')='YES' GROUP BY TAB1.TABLE_NAME) TAB1\n" + "ON TAB1.TABLE_NAME=TAB2.TABLE_NAME\n" + "INNER JOIN USER_TABLES TABS1\n" + "ON TABS1.TABLE_NAME=TAB2.TABLE_NAME WHERE TABS1.TEMPORARY='N'";
  }

  private String buildSqlQuery9i()
  {
    return "SELECT CEIL(COUNT(TAB1.TABLE_NAME)/DECODE(COUNT(TAB2.TABLE_NAME),0,1,COUNT(TAB2.TABLE_NAME))*100)\n" + "FROM (SELECT TABLE_NAME FROM USER_TABLES WHERE (TABLE_NAME LIKE 'CCM%' OR TABLE_NAME LIKE 'CDM%') AND TEMPORARY='N') TAB2\n" + "LEFT OUTER JOIN\n" + "(SELECT TABLE_NAME FROM USER_TABLES WHERE NVL(LAST_ANALYZED,SYSDATE-30)<SYSDATE-?/24\n" + "AND (TABLE_NAME LIKE 'CCM%' OR TABLE_NAME LIKE 'CDM%') AND TEMPORARY='N') TAB1\n" + "ON TAB1.TABLE_NAME=TAB2.TABLE_NAME";
  }

  private String buildSqlQueryMSSqlDB()
  {
    return "select cast(SUM(StatFlag)*100./ISNULL(COUNT(StatFlag),1) as numeric)\nfrom(\n SELECT object_name(id) as TableName,\n case when ((MIN(STATS_DATE (id,indid)) IS NULL\n    OR MIN(STATS_DATE (id,indid)) <= DATEADD(d,-?,getdate())) AND\n    (select crdate from sysobjects\n    where sysobjects.id = sysindexes.id) <= DATEADD(d,-?,getdate())\n    AND MAX(rowmodctr) > 0 AND MAX(rowcnt) > 1000\n    AND (MAX(cast(rowmodctr as numeric))*100)/ISNULL(MAX(rowcnt),1.) > 10) then 1\n    else 0\n end as StatFlag\n FROM sysindexes\n WHERE (object_name(id) like 'CCM%' or object_name(id) like 'CDM%')\n GROUP BY id) as allTables";
  }
}