package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;

public abstract class CmdbDalRemoveQualifiersComplexCommand extends CmdbDalClassModelComplexCommand<Void>
{
  private BasicContainer _qualifires = null;
  private Long _entityId = null;

  public CmdbDalRemoveQualifiersComplexCommand(BasicContainer qualifires, Long entityId)
  {
    setQualifires(qualifires);
    setEntityId(entityId);
  }

  protected void validateInput() {
  }

  protected Void perform() throws Exception {
    deleteQualifiers();
    return null;
  }

  private void deleteQualifiers() throws SQLException {
    CmdbDalPreparedStatement preparedStatement = null;
    BasicContainer qualifires = getQualifires();

    if ((qualifires != null) && (!(qualifires.isEmpty()))) {
      ReadOnlyIterator qualifiersIter = qualifires.getIterator();

      StringBuffer condition = new StringBuffer();
      condition.append("ENTITY_ID").append("=? AND ");
      condition.append("QUALIFIER_NAME").append("=?");
      String sqlString = createDeleteSql("CCM_QUALIFIER", condition.toString());
      preparedStatement = getConnection().prepareStatement4Update(sqlString);

      while (qualifiersIter.hasNext()) {
        ClassModelQualifier qualifier = (ClassModelQualifier)qualifiersIter.next();
        deleteQualifierDataItems(qualifier);

        preparedStatement.setLong(getEntityId());
        preparedStatement.setString(qualifier.getName());
        preparedStatement.addBatch();
      }
      preparedStatement.executeBatch();
      preparedStatement.close();
    }
  }

  private void deleteQualifierDataItems(ClassModelQualifier qualifier) throws SQLException {
    StringBuffer condition = new StringBuffer();

    condition.append("QUALIFIER_ENTITYID").append("=? AND ");
    condition.append("QUALIFIER_NAME").append("=?");
    String sqlString = createDeleteSql("CCM_QUALDITEM", condition.toString());

    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Update(sqlString);
    preparedStatement.setLong(getEntityId());
    preparedStatement.setString(qualifier.getName());

    preparedStatement.executeUpdate();
    preparedStatement.close();
  }

  protected abstract Long getEntityIdFromDB() throws SQLException;

  protected BasicContainer getQualifires() {
    return this._qualifires;
  }

  protected void setQualifires(BasicContainer qualifires) {
    this._qualifires = qualifires;
  }

  private Long getEntityId() throws SQLException {
    Long entityId = this._entityId;

    if (entityId == null) {
      entityId = getEntityIdFromDB();
      setEntityId(entityId);
    }

    return entityId;
  }

  private void setEntityId(Long entityId) {
    this._entityId = entityId;
  }
}