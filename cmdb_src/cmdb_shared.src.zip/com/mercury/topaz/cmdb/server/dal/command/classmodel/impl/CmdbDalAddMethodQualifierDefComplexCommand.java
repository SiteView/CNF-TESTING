package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifierDef;

public class CmdbDalAddMethodQualifierDefComplexCommand extends CmdbDalAddQualifierDefComplexCommand
{
  public CmdbDalAddMethodQualifierDefComplexCommand(ClassModelQualifierDef qualifierDef)
  {
    super(qualifierDef);
  }

  protected String getQualifierType() {
    return "METHOD";
  }
}