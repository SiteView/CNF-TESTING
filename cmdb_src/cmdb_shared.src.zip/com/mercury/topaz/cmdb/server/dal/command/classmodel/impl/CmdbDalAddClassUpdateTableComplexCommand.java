package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalAddClassUpdateTableComplexCommand extends CmdbDalAddClassComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalAddClassUpdateTableComplexCommand.class);

  public CmdbDalAddClassUpdateTableComplexCommand(CmdbClass cmdbClass)
  {
    super(cmdbClass);
  }

  protected Object perform() {
    super.perform();
    addClass(getCmdbClass());
    return null;
  }

  private void addClass(CmdbClass cmdbClass) {
    try {
      addClassTable(cmdbClass);
    }
    catch (Exception e) {
      String errMsg = "Error adding table for class [" + cmdbClass.getName() + "], due to exception: " + e;
      try
      {
        CmdbDalCommand removeCommand = CmdbDalClassModelCommandFactory.createRemoveClassUpdateTableComplexCommand(cmdbClass);
        removeCommand.execute();
      }
      catch (Exception e1) {
        String errMsg1 = "Error Remove class [" + cmdbClass.getName() + "] AFTER FAILED ADD";
        _logger.error(new Exception(errMsg1, e1));
      }
      throw new CmdbDalException(errMsg, e);
    }
  }

  private void updateClassMetaData(CmdbDalConnection connection, Long classID, String classFullQualifiedName) throws SQLException
  {
    updateMapClassesTable(connection, classID, classFullQualifiedName);

    CmdbDalCommand updateMigrationTableCommand = CmdbDalClassModelCommandFactory.createUpdateAddMigrationTableComplexCommand(classFullQualifiedName, classID);
    updateMigrationTableCommand.execute();
  }

  private void updateMapClassesTable(CmdbDalConnection connection, Long classID, String classFullQualifiedName) throws SQLException {
    String mapSqlString = createInsertMapClassesTableSql();
    CmdbDalPreparedStatement mapPreparedStatement = connection.prepareStatement4Update(mapSqlString);
    mapPreparedStatement.setLong(classID);
    mapPreparedStatement.setString(getTableNameByClassName(classFullQualifiedName));

    mapPreparedStatement.executeUpdate();
    mapPreparedStatement.close();
  }

  private String createInsertMapClassesTableSql() {
    List columnsNames = createMapClassesTableColumnsNames();

    return createInsertSql("CCM_MAP_CLASS", columnsNames);
  }

  private void addClassTable(CmdbClass cmdbClass) {
    String tableName = getTableNameByClassName(cmdbClass.getName());
    TableDescription tableDescription = new TableDescription(tableName);

    createNewClassTable(cmdbClass, tableDescription);
    addTablePrimaryKey(tableDescription);
    addTableIndices(cmdbClass, tableDescription);

    CmdbDalCommand createTableCommand = CmdbDalCommandFactory.createCreateTableComplexCommand(tableDescription);
    createTableCommand.execute();

    updateClassMetaData(cmdbClass);
  }

  private void updateClassMetaData(CmdbClass cmdbClass) {
    CmdbDalConnection connection = getConnection();
    try
    {
      updateClassMetaData(connection, getClassID(), cmdbClass.getName());
    }
    catch (SQLException ex) {
      String errMsg = "Error adding cmdb class [" + cmdbClass.getName() + ']';

      if (connection != null)
        connection.rollback();

      throw new CmdbDalException(errMsg, ex);
    }
  }

  private void createNewClassTable(CmdbClass cmdbClass, TableDescription tableDescription)
  {
    updateDefaultColumnsLists(tableDescription, cmdbClass);

    updateAttributesDataTableLists(cmdbClass, tableDescription);
  }

  private void addTablePrimaryKey(TableDescription tableDescription) {
    IndexDescription primaryKey = new IndexDescription("CMDB_ID");
    if (!(isUpdateClassModelEnabled()))
      primaryKey.addColumn("CUSTOMER_ID");

    tableDescription.setPrimaryKey(primaryKey);
  }

  private void addTableIndices(CmdbClass cmdbClass, TableDescription tableDescription) {
    if (cmdbClass.getName().equalsIgnoreCase("root"))
      tableDescription.addIndex(new IndexDescription("CLASS"));

    if (cmdbClass.getName().equalsIgnoreCase("link")) {
      tableDescription.addIndex(new IndexDescription("END1_ID"));
      tableDescription.addIndex(new IndexDescription("END2_ID"));
      tableDescription.addIndex(new IndexDescription("CLASS"));
    }
    updateTableIndicesLists(cmdbClass, tableDescription);
  }
}