package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.CmdbModifiableValidLinkQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.CmdbValidLinkQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.impl.CmdbValidLinkQualifierFactory;
import java.sql.SQLException;

public class CmdbDalAddValidLinkQualifiersComplexCommand extends CmdbDalAddClassModelQualifiersComplexCommand
{
  private CmdbValidLink _cmdbValidLink;

  public CmdbDalAddValidLinkQualifiersComplexCommand(CmdbValidLink cmdbValidLink, BasicContainer qualifires, Long entityId)
  {
    super(qualifires, entityId);
    setCmdbValidLink(cmdbValidLink);
  }

  public CmdbDalAddValidLinkQualifiersComplexCommand(CmdbValidLink cmdbValidLink, CmdbValidLinkQualifier qualifier, Long entityId) {
    super(null, entityId);
    CmdbModifiableValidLinkQualifiers qualifiers = CmdbValidLinkQualifierFactory.createValidLinkQualifiers();
    qualifiers.add(qualifier);
    setQualifires(qualifiers);
    setCmdbValidLink(cmdbValidLink);
  }

  protected String getCommandName() {
    return "Add valid link qualifiers [" + getQualifires() + "] to valid link [" + getCmdbValidLink() + "]";
  }

  protected Long getEntityIdFromDB() throws SQLException {
    return getValidLinkID(getCmdbValidLink(), getConnection());
  }

  protected CmdbValidLink getCmdbValidLink() {
    return this._cmdbValidLink;
  }

  private void setCmdbValidLink(CmdbValidLink cmdbValidLink) {
    this._cmdbValidLink = cmdbValidLink;
  }
}