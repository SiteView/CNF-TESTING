package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.classmodel.CmdbModifiableClassModelDefinition;
import com.mercury.topaz.cmdb.server.classmodel.impl.CmdbModifiableClassModelFactory;
import com.mercury.topaz.cmdb.server.dal.util.table.impl.CmdbDalGenericClassModelTable;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModelDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItem;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.impl.DataItemFactory;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelModifiableQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CalculatedLinkTripletDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.impl.CmdbCalculatedLinkFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbModifiableClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributeOverrideDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.impl.CmdbAttributeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbModifiableAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.impl.CmdbAttributeQualifierFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.impl.CmdbClassFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbModifiableMethod;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.impl.CmdbMethodFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.param.CmdbAttributeParam;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.param.CmdbModifiableParams;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.param.CmdbParam;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.param.CmdbParams;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.param.impl.CmdbParamFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.CmdbModifiableMethodQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.impl.CmdbMethodQualifierFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbModifiableClassQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.impl.CmdbClassQualifierFactory;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbModifiableTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbModifiableEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbModifiableEnumEntry;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.impl.CmdbEnumFactory;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbModifiableList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbModifiableListEntry;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.impl.CmdbListFactory;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbModifiableExternalResource;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbModifiableValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.impl.CmdbValidLinkFactory;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.CmdbModifiableValidLinkQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.impl.CmdbValidLinkQualifierFactory;
import com.mercury.topaz.cmdb.shared.common.qualifiedname.CmdbQualifiedNameFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class CmdbDalLoadClassModelCoarseGrainComplexCommand extends CmdbDalClassModelComplexCommand<CmdbClassModelDefinition>
{
  protected static final String PARENT_NAME_ALIAS = "PARENT_NAME";
  protected static final String PARENT_NAME_SPACE_ALIAS = "PARENT_NAME_SPACE";

  protected void validateInput()
  {
  }

  protected void prepare()
    throws Exception
  {
    setUseDirtyRead();
  }

  protected CmdbClassModelDefinition perform() {
    return getClassModelDefinition();
  }

  public CmdbClassModelDefinition getClassModelDefinition() {
    CmdbModifiableClassModelDefinition classModelDefinition = CmdbModifiableClassModelFactory.createClassModelDefinition();
    try
    {
      loadValidLinks(classModelDefinition);
      loadClasses(classModelDefinition);
      loadTypeDefs(classModelDefinition);

      return classModelDefinition;
    }
    catch (Exception e) {
      String errMsg = "Error loading class model definition, due to exception: " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }

  private void loadClasses(CmdbModifiableClassModelDefinition classModel) throws SQLException {
    CmdbDalGenericClassModelTable classesTable = loadClassesTable();
    CmdbDalGenericClassModelTable attributesTable = loadAttributesTable();
    CmdbDalGenericClassModelTable methodsTable = loadMethodsTable();
    CmdbDalGenericClassModelTable qualifiersTable = loadQualifiersTable();
    CmdbDalGenericClassModelTable qualifiersDataItemsTable = loadQualifiersDataItemsTable();
    CmdbDalGenericClassModelTable calculatedLinksTable = loadCalculatedLinksTable();

    classesTable.getRowsIterator();
    for (Iterator rowsIter = classesTable.getRowsIterator(); rowsIter.hasNext(); ) {
      Map row = (Map)rowsIter.next();

      Long classID = (Long)row.get("CLASS_ID");
      String className = (String)row.get("CLASS_NAME");
      String nameSpace = (String)row.get("NAME_SPACE");
      String displayName = (String)row.get("DISPLAY_NAME");
      String description = (String)row.get("DESCRIPTION");
      String classType = (String)row.get("CLASS_TYPE");
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      String parentName = null;
      String parentNameSpace = null;
      Long parentClassID = (Long)row.get("PARENT_ID");

      if (parentClassID != null) {
        Map parentRow = classesTable.getRow(parentClassID);
        parentName = (String)parentRow.get("CLASS_NAME");
        parentNameSpace = (String)parentRow.get("NAME_SPACE");
      }

      parentName = (parentName != null) ? parentName : "none";
      if ((parentNameSpace != null) && (parentNameSpace.length() > 0)) {
        parentName = CmdbQualifiedNameFactory.createCmdbQualifiedName(parentNameSpace, parentName);
      }

      CmdbModifiableClassDefinition cmdbClass = CmdbClassFactory.createClassDefinition(nameSpace, className, parentName);
      cmdbClass.setDisplayName(displayName);
      cmdbClass.setDescription(description);
      cmdbClass.setClassType(classType);
      cmdbClass.setCreatedByFactory(createdByFactory);
      cmdbClass.setModifiedByUser(updatedByUser);

      loadMethods(cmdbClass, classID, methodsTable, qualifiersTable, qualifiersDataItemsTable);
      loadAttributes(cmdbClass, classID, attributesTable, qualifiersTable, qualifiersDataItemsTable);
      loadQualifires(cmdbClass, classID, qualifiersTable, qualifiersDataItemsTable);

      classModel.addClass(cmdbClass);

      if (cmdbClass.hasQualifier(CmdbClassQualifierDefs.CALCULATED_LINK.getName())) {
        CmdbClassDefinition readOnlyClassDefinition = CmdbClassFactory.createClassDefinition(cmdbClass);
        loadCalculatedLinks(classModel, readOnlyClassDefinition, classID, calculatedLinksTable);
      }
    }
  }

  private void loadMethods(CmdbModifiableClassDefinition cmdbClassDefinition, Long classID, CmdbDalGenericClassModelTable methodsTable, CmdbDalGenericClassModelTable qualifiersTable, CmdbDalGenericClassModelTable qualifiersDataItemsTable)
  {
    for (Iterator rowsIter = methodsTable.getRowIdsIterator(classID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = methodsTable.getRow(rowId);

      Long methodID = (Long)row.get("METHOD_ID");
      String methodName = (String)row.get("METHOD_NAME");
      String methodType = (String)row.get("METHOD_TYPE");
      String command = (String)row.get("COMMAND");
      String description = (String)row.get("DESCRIPTION");
      String displayName = (String)row.get("DISPLAY_NAME");
      String paramsString = (String)row.get("PARAMS");
      CmdbParams params = createMethodParamsFromString(paramsString);
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      CmdbModifiableMethod method = CmdbMethodFactory.create(methodName, methodType, command);
      method.setDescription(description);
      method.setDisplayName(displayName);
      method.setCreatedByFactory(createdByFactory);
      method.setModifiedByUser(updatedByUser);

      ReadOnlyIterator paramsIter = params.getIterator();
      while (paramsIter.hasNext()) {
        CmdbParam param = (CmdbParam)paramsIter.next();
        method.addParam(param);
      }

      loadQualifires(method, methodID, qualifiersTable, qualifiersDataItemsTable);

      cmdbClassDefinition.addMethod(method);
    }
  }

  private CmdbParams createMethodParamsFromString(String paramsString) {
    CmdbModifiableParams params = CmdbParamFactory.createParams();

    if (paramsString != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(paramsString, "##");

      while (stringTokenizer.hasMoreTokens()) {
        String attributeName = stringTokenizer.nextToken();
        CmdbAttributeParam param = CmdbParamFactory.createAttributeParam(attributeName);

        params.add(param);
      }
    }
    return params;
  }

  private void loadAttributes(CmdbModifiableClassDefinition cmdbClassDefinition, Long classID, CmdbDalGenericClassModelTable attributesTable, CmdbDalGenericClassModelTable qualifiersTable, CmdbDalGenericClassModelTable qualifiersDataItemsTable) throws SQLException {
    Map attributesMap = new HashMap();
    Map attributesOverridesMap = new HashMap();

    for (Iterator rowsIter = attributesTable.getRowIdsIterator(classID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = attributesTable.getRow(rowId);

      Long attributeID = (Long)row.get("ATTRIBUTE_ID");
      String attributeName = (String)row.get("ATTRIBUTE_NAME");
      String defaultValue = (String)row.get("DEFAULT_VALUE");
      String attributeType = (String)row.get("ATTRIBUTE_TYPE");
      Integer valueSize = (Integer)row.get("VALUE_SIZE");
      String description = (String)row.get("DESCRIPTION");
      String displayName = (String)row.get("DISPLAY_NAME");
      Integer fullOverride = (Integer)row.get("FULL_OVERRIDE");
      Boolean isEmptyValue = (Boolean)row.get("IS_EMPTY");
      Boolean partialOverride = (Boolean)row.get("PARTIAL_OVERRIDE");
      Integer attributeIndex = (Integer)row.get("ATTRIBUTE_INDEX");
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      if (fullOverride.intValue() == 0) {
        CmdbModifiableAttributeDefinition attribute = CmdbAttributeFactory.createAttributeDefinition(attributeName, attributeType);
        attribute.setDescription(description);
        attribute.setDisplayName(displayName);
        attribute.setSizeLimit(valueSize);
        attribute.setCreatedByFactory(createdByFactory);
        attribute.setModifiedByUser(updatedByUser);

        if (isEmptyValue.booleanValue()) {
          attribute.setDefaultValueAsEmpty();
        }
        else if ((defaultValue != null) && (defaultValue.length() > 0)) {
          attribute.setDefaultValue(defaultValue);
        }

        loadQualifires(attribute, attributeID, qualifiersTable, qualifiersDataItemsTable);
        attributesMap.put(attributeIndex, attribute);
      }
      else
      {
        CmdbModifiableAttributeOverrideDefinition attributeOverride = CmdbAttributeFactory.createAttributeOverrideDefinition(attributeName);
        attributeOverride.setCreatedByFactory(createdByFactory);
        attributeOverride.setModifiedByUser(updatedByUser);
        attributeOverride.setPartiallyOverride(partialOverride.booleanValue());

        if (isEmptyValue.booleanValue()) {
          attributeOverride.setDefaultValueAsEmpty();
        }
        else if ((defaultValue != null) && (defaultValue.length() > 0)) {
          if (CmdbSimpleTypes.CmdbXml.getName().equals(attributeType)) {
            attributeOverride.setXmlDefaultValue(defaultValue);
          }
          else {
            attributeOverride.setDefaultValue(defaultValue);
          }

        }

        loadQualifires(attributeOverride, attributeID, qualifiersTable, qualifiersDataItemsTable);
        attributesOverridesMap.put(attributeIndex, attributeOverride);
      }

    }

    updateClassDefinitionWithAttributesMap(attributesMap, cmdbClassDefinition);
    updateClassDefinitionWithAttributesOverridesMap(attributesOverridesMap, cmdbClassDefinition);
  }

  private void updateClassDefinitionWithAttributesOverridesMap(Map attributesOverridesMap, CmdbModifiableClassDefinition cmdbClassDefinition) {
    int attributeOverrideIndex = 0;
    int numOfAddedAttributes = 0;

    while (numOfAddedAttributes < attributesOverridesMap.size()) {
      ++attributeOverrideIndex;
      CmdbModifiableAttributeOverrideDefinition attributeOverrideDefinition = (CmdbModifiableAttributeOverrideDefinition)attributesOverridesMap.get(new Integer(attributeOverrideIndex));
      if (attributeOverrideDefinition != null) {
        ++numOfAddedAttributes;
        cmdbClassDefinition.addAttributeOverride(attributeOverrideDefinition);
      }
    }
  }

  private void updateClassDefinitionWithAttributesMap(Map attributesMap, CmdbModifiableClassDefinition cmdbClassDefinition) {
    int attributeIndex = 0;
    int numOfAddedAttributes = 0;

    while (numOfAddedAttributes < attributesMap.size()) {
      ++attributeIndex;
      CmdbModifiableAttributeDefinition attributeDefinition = (CmdbModifiableAttributeDefinition)attributesMap.get(new Integer(attributeIndex));
      if (attributeDefinition != null) {
        ++numOfAddedAttributes;
        cmdbClassDefinition.addAttribute(attributeDefinition);
      }
    }
  }

  private void loadQualifires(CmdbModifiableMethod method, Long entityID, CmdbDalGenericClassModelTable qualifiersTable, CmdbDalGenericClassModelTable qualifiersDataItemsTable) {
    for (Iterator rowsIter = qualifiersTable.getRowIdsIterator(entityID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = qualifiersTable.getRow(rowId);

      String qualifierName = (String)row.get("QUALIFIER_NAME");
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      CmdbModifiableMethodQualifier qualifier = CmdbMethodQualifierFactory.create(qualifierName);
      qualifier.setCreatedByFactory(createdByFactory);
      qualifier.setModifiedByUser(updatedByUser);
      loadQualifierDataItems(qualifier, entityID, qualifiersDataItemsTable);

      method.addQualifier(qualifier);
    }
  }

  private void loadQualifires(CmdbModifiableAttributeOverrideDefinition attributeOverride, Long entityID, CmdbDalGenericClassModelTable qualifiersTable, CmdbDalGenericClassModelTable qualifiersDataItemsTable) {
    for (Iterator rowsIter = qualifiersTable.getRowIdsIterator(entityID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = qualifiersTable.getRow(rowId);

      String qualifierName = (String)row.get("QUALIFIER_NAME");
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      CmdbModifiableAttributeQualifier qualifier = CmdbAttributeQualifierFactory.create(qualifierName);
      qualifier.setCreatedByFactory(createdByFactory);
      qualifier.setModifiedByUser(updatedByUser);
      loadQualifierDataItems(qualifier, entityID, qualifiersDataItemsTable);

      attributeOverride.addQualifier(qualifier);
    }
  }

  private void loadQualifires(CmdbModifiableAttributeDefinition attribute, Long entityID, CmdbDalGenericClassModelTable qualifiersTable, CmdbDalGenericClassModelTable qualifiersDataItemsTable) {
    for (Iterator rowsIter = qualifiersTable.getRowIdsIterator(entityID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = qualifiersTable.getRow(rowId);

      String qualifierName = (String)row.get("QUALIFIER_NAME");
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      CmdbModifiableAttributeQualifier qualifier = CmdbAttributeQualifierFactory.create(qualifierName);
      qualifier.setCreatedByFactory(createdByFactory);
      qualifier.setModifiedByUser(updatedByUser);
      loadQualifierDataItems(qualifier, entityID, qualifiersDataItemsTable);

      attribute.addQualifier(qualifier);
    }
  }

  private void loadQualifires(CmdbModifiableClassDefinition cmdbClass, Long entityID, CmdbDalGenericClassModelTable qualifiersTable, CmdbDalGenericClassModelTable qualifiersDataItemsTable) {
    for (Iterator rowsIter = qualifiersTable.getRowIdsIterator(entityID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = qualifiersTable.getRow(rowId);

      String qualifierName = (String)row.get("QUALIFIER_NAME");
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      CmdbModifiableClassQualifier qualifier = CmdbClassQualifierFactory.createQualifier(qualifierName);
      qualifier.setCreatedByFactory(createdByFactory);
      qualifier.setModifiedByUser(updatedByUser);
      loadQualifierDataItems(qualifier, entityID, qualifiersDataItemsTable);

      cmdbClass.addQualifier(qualifier);
    }
  }

  private void loadQualifires(CmdbModifiableValidLink validLink, Long entityID, CmdbDalGenericClassModelTable qualifiersTable, CmdbDalGenericClassModelTable qualifiersDataItemsTable) {
    for (Iterator rowsIter = qualifiersTable.getRowIdsIterator(entityID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = qualifiersTable.getRow(rowId);

      String qualifierName = (String)row.get("QUALIFIER_NAME");
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      CmdbModifiableValidLinkQualifier qualifier = CmdbValidLinkQualifierFactory.create(qualifierName);
      qualifier.setCreatedByFactory(createdByFactory);
      qualifier.setModifiedByUser(updatedByUser);
      loadQualifierDataItems(qualifier, entityID, qualifiersDataItemsTable);

      validLink.addQualifier(qualifier);
    }
  }

  private void loadQualifierDataItems(ClassModelModifiableQualifier qualifier, Long entityID, CmdbDalGenericClassModelTable qualifiersDataItemsTable) {
    for (Iterator rowsIter = qualifiersDataItemsTable.getRowIdsIterator(entityID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = qualifiersDataItemsTable.getRow(rowId);

      if (qualifier.getName().equals(row.get("QUALIFIER_NAME"))) {
        String dataItemName = (String)row.get("DATA_ITEM_NAME");
        String dataItemTypeAsString = (String)row.get("DATA_ITEM_TYPE");
        String dataItemValueAsString = (String)row.get("DATA_ITEM_VALUE");
        Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
        Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

        CmdbSimpleType dataItemType = CmdbSimpleTypes.getSimpleType(dataItemTypeAsString);
        Object dataItemValue = dataItemType.valueOf(dataItemValueAsString);

        DataItem dataItem = DataItemFactory.createDataItem(dataItemName, dataItemType, dataItemValue);

        qualifier.addDataItem(dataItem);
      }
    }
  }

  private void loadValidLinks(CmdbModifiableClassModelDefinition classModel) throws SQLException {
    CmdbDalGenericClassModelTable validLinksTable = loadValidLinksTable();

    CmdbDalGenericClassModelTable qualifiersTable = loadQualifiersTable();
    CmdbDalGenericClassModelTable qualifiersDataItemsTable = loadQualifiersDataItemsTable();

    for (Iterator rowsIter = validLinksTable.getRowsIterator(); rowsIter.hasNext(); ) {
      Map row = (Map)rowsIter.next();

      String linkClassName = (String)row.get("LINK_CLASS_NAME");
      String end1Name = (String)row.get("LINK_END1_NAME");
      String end2Name = (String)row.get("LINK_END2_NAME");
      Integer end1LowMultiplicity = (Integer)row.get("END1_LOW_MULT");
      Integer end1HighMultiplicity = (Integer)row.get("END1_HIGH_MULT");
      Integer end2LowMultiplicity = (Integer)row.get("END2_LOW_MULT");
      Integer end2HighMultiplicity = (Integer)row.get("END2_HIGH_MULT");
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      CmdbModifiableValidLink validLink = CmdbValidLinkFactory.createValidLink(linkClassName, end1Name, end2Name);
      validLink.setCreatedByFactory(createdByFactory);
      validLink.setModifiedByUser(updatedByUser);

      Long validLinkID = (Long)row.get("VALID_LINK_ID");
      loadQualifires(validLink, validLinkID, qualifiersTable, qualifiersDataItemsTable);

      classModel.addValidLink(validLink);
    }
  }

  private void loadTypeDefs(CmdbModifiableClassModelDefinition classModel) throws SQLException {
    CmdbDalGenericClassModelTable typeDefsTable = loadTypeDefsTable();
    CmdbDalGenericClassModelTable typeDefsEnumTable = loadTypeDefsEnumTable();
    CmdbDalGenericClassModelTable typeDefsDataItemsTable = loadTypeDefsDataItemsTable();

    for (Iterator rowsIter = typeDefsTable.getRowsIterator(); rowsIter.hasNext(); ) {
      CmdbModifiableTypeDef typeDef;
      Map row = (Map)rowsIter.next();

      Long typeDefID = (Long)row.get("TYPE_DEF_ID");
      String typeDefName = (String)row.get("TYPE_DEF_NAME");
      String displayName = (String)row.get("DISPLAY_NAME");
      String typeDefType = (String)row.get("TYPE_DEF_TYPE");
      String description = (String)row.get("DESCRIPTION");
      String valueTypeAsString = (String)row.get("VALUE_TYPE");
      CmdbSimpleType valueType = CmdbSimpleTypes.getSimpleType(valueTypeAsString);
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      if (typeDefType.equals("ENUM")) {
        typeDef = CmdbEnumFactory.createEnum(typeDefName, valueType);
        loadTypeDefEnum(typeDefID, (CmdbModifiableEnum)typeDef, typeDefsEnumTable, typeDefsDataItemsTable);
      }
      else if (typeDefType.equals("LIST")) {
        typeDef = CmdbListFactory.create(typeDefName, valueType);
        loadTypeDefList((CmdbModifiableList)typeDef, typeDefID, typeDefsEnumTable);
      }
      else if (typeDefType.equals("STRING"))
      {
        typeDef = null;
        loadTypeDefExternalResource(typeDefID, (CmdbModifiableExternalResource)typeDef);
      }
      else {
        throw new CmdbDalException("Try to load unknown type def type [" + typeDefType + "]");
      }

      if (typeDef != null) {
        typeDef.setDescription(description);
        typeDef.setDisplayName(displayName);
        typeDef.setCreatedByFactory(createdByFactory);
        typeDef.setModifiedByUser(updatedByUser);

        classModel.addTypeDef(typeDef);
      }
    }
  }

  private void loadCalculatedLinks(CmdbModifiableClassModelDefinition classModel, CmdbClassDefinition cmdbClass, Long classID, CmdbDalGenericClassModelTable calculatedLinkTable) throws SQLException {
    CmdbCalculatedLink calculatedLink = CmdbCalculatedLinkFactory.createCalculatedLinkDefinition(cmdbClass, new ArrayList());

    for (Iterator rowsIter = calculatedLinkTable.getRowIdsIterator(classID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = calculatedLinkTable.getRow(rowId);

      String end1Type = (String)row.get("TRIPLET_END1_NAME");
      String end2Type = (String)row.get("TRIPLET_END2_NAME");
      String linkType = (String)row.get("TRIPLET_LINK_NAME");
      Boolean isForward = (Boolean)row.get("IS_FORWARD");

      CalculatedLinkTripletDefinition calculatedLinkTriplet = CmdbCalculatedLinkFactory.createTriplet(end1Type, end2Type, linkType, isForward.booleanValue());
      calculatedLink.addTriplet(calculatedLinkTriplet);
    }

    classModel.addCalculatedLink(calculatedLink);
  }

  private CmdbModifiableTypeDef loadTypeDefExternalResource(Long typeDefID, CmdbModifiableExternalResource typeDefExternalResource)
  {
    throw new UnsupportedOperationException("loadTypeDefExternalResource is not supported !!!");
  }

  private void loadTypeDefEnum(Long typeDefID, CmdbModifiableEnum typeDefEnum, CmdbDalGenericClassModelTable typeDefsEnumTable, CmdbDalGenericClassModelTable typeDefsDataItemsTable) {
    Map enumeratorsMap = new HashMap();

    for (Iterator rowsIter = typeDefsEnumTable.getRowIdsIterator(typeDefID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = typeDefsEnumTable.getRow(rowId);

      String enumValueAsString = (String)row.get("ENUM_VALUE");
      Integer enumKey = (Integer)row.get("ENUM_KEY");
      Object enumValue = typeDefEnum.getType().valueOf(enumValueAsString);
      Integer enumIndex = (Integer)row.get("ENUM_INDEX");
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      CmdbModifiableEnumEntry enumEntry = CmdbEnumFactory.createEnumEntry(enumKey.intValue(), enumValue);
      enumEntry.setCreatedByFactory(createdByFactory);
      enumEntry.setModifiedByUser(updatedByUser);

      loadTypeDefDataItems(enumEntry, typeDefID, enumKey.intValue(), typeDefsDataItemsTable);

      enumeratorsMap.put(enumIndex, enumEntry);
    }

    updateTypeDefDefinitionWithEnumeratorsMap(typeDefEnum, enumeratorsMap);
  }

  private void updateTypeDefDefinitionWithEnumeratorsMap(CmdbModifiableEnum typeDefEnum, Map enumeratorsMap) {
    int enumIndex = 0;
    int numOfAddedEnumerators = 0;

    while (numOfAddedEnumerators < enumeratorsMap.size()) {
      ++enumIndex;
      CmdbModifiableEnumEntry enumEntry = (CmdbModifiableEnumEntry)enumeratorsMap.get(new Integer(enumIndex));
      if (enumEntry != null) {
        ++numOfAddedEnumerators;
        typeDefEnum.addEnumerator(enumEntry);
      }
    }
  }

  private void loadTypeDefList(CmdbModifiableList typeDefList, Long typeDefID, CmdbDalGenericClassModelTable typeDefsEnumTable) {
    Map listEntriesMap = new HashMap();

    for (Iterator rowsIter = typeDefsEnumTable.getRowIdsIterator(typeDefID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = typeDefsEnumTable.getRow(rowId);

      String listValueAsString = (String)row.get("ENUM_VALUE");
      Object listValue = typeDefList.getType().valueOf(listValueAsString);
      Integer enumIndex = (Integer)row.get("ENUM_INDEX");
      Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
      Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

      CmdbModifiableListEntry listEntry = CmdbListFactory.createModifiableListEntry(listValue);
      listEntry.setCreatedByFactory(createdByFactory);
      listEntry.setModifiedByUser(updatedByUser);

      listEntriesMap.put(enumIndex, listEntry);
    }

    updateTypeDefDefinitionWithListEntriesMap(typeDefList, listEntriesMap);
  }

  private void updateTypeDefDefinitionWithListEntriesMap(CmdbModifiableList typeDefList, Map listEntriesMap) {
    int enumIndex = 0;
    int numOfAddedEntries = 0;

    while (numOfAddedEntries < listEntriesMap.size()) {
      ++enumIndex;
      CmdbListEntry listEntry = (CmdbListEntry)listEntriesMap.get(new Integer(enumIndex));
      if (listEntry != null) {
        ++numOfAddedEntries;
        typeDefList.addListEntry(listEntry);
      }
    }
  }

  private void loadTypeDefDataItems(CmdbModifiableEnumEntry enumEntry, Long typeDefID, int enumKey, CmdbDalGenericClassModelTable typeDefsDataItemsTable) {
    Map dataItemsMap = new HashMap();

    for (Iterator rowsIter = typeDefsDataItemsTable.getRowIdsIterator(typeDefID); rowsIter.hasNext(); ) {
      Long rowId = (Long)rowsIter.next();
      Map row = typeDefsDataItemsTable.getRow(rowId);

      if (((Integer)row.get("ENUM_KEY")).intValue() == enumKey) {
        String dataItemName = (String)row.get("DATA_ITEM_NAME");
        String dataItemTypeAsString = (String)row.get("DATA_ITEM_TYPE");
        String dataItemValueAsString = (String)row.get("DATA_ITEM_VALUE");
        Integer dataItemsIndex = (Integer)row.get("DITEM_INDEX");
        Boolean createdByFactory = (Boolean)row.get("IS_FACTORY");
        Boolean updatedByUser = (Boolean)row.get("IS_UPDATED");

        CmdbSimpleType dataItemType = CmdbSimpleTypes.getSimpleType(dataItemTypeAsString);
        Object dataItemValue = dataItemType.valueOf(dataItemValueAsString);

        DataItem dataItem = DataItemFactory.createDataItem(dataItemName, dataItemType, dataItemValue);

        dataItemsMap.put(dataItemsIndex, dataItem);
      }

    }

    updateEnumEntryWithDataItemsMap(enumEntry, dataItemsMap);
  }

  private void updateEnumEntryWithDataItemsMap(CmdbModifiableEnumEntry enumEntry, Map dataItemsMap) {
    int dataItemsIndex = 0;
    int numOfAddedDataItems = 0;

    while (numOfAddedDataItems < dataItemsMap.size()) {
      ++dataItemsIndex;
      DataItem dataItem = (DataItem)dataItemsMap.get(new Integer(dataItemsIndex));
      if (dataItem != null) {
        ++numOfAddedDataItems;
        enumEntry.addDataItem(dataItem);
      }
    }
  }

  private void loadQualifiresDefs(CmdbModifiableClassModelDefinition classModel, CmdbDalConnection connection) throws SQLException {
    Boolean updatedByUser;
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectQualifiresDefTableSql();
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Select(sqlString);

    preparedStatement.setLong(customerID.getID());

    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    while (resultSet.next()) {
      String qualifierType = resultSet.getString("QUALIFIER_TYPE");
      String qualifierName = resultSet.getString("QUALIFIER_NAME");
      String displayName = resultSet.getString("DISPLAY_NAME");
      String description = resultSet.getString("DESCRIPTION");
      Boolean createdByFactory = resultSet.getBoolean("IS_FACTORY");
      updatedByUser = resultSet.getBoolean("IS_UPDATED");
    }

    resultSet.close();
    preparedStatement.close();
  }

  private CmdbDalGenericClassModelTable loadClassesTable() throws SQLException {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectClassesTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString);
    preparedStatement.setLong(customerID.getID());
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbDalGenericClassModelTable classesTable = new CmdbDalGenericClassModelTable(resultSet, createClassesTableColumnsNames(), createClassesTableColumnsTypes(), "CLASS_ID", null);

    resultSet.close();
    preparedStatement.close();

    return classesTable;
  }

  private CmdbDalGenericClassModelTable loadAttributesTable() throws SQLException {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectAttributesTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString);
    preparedStatement.setLong(customerID.getID());
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbDalGenericClassModelTable attributesTable = new CmdbDalGenericClassModelTable(resultSet, createAttributesTableColumnsNames(), createAttributesTableColumnsTypes(), "ATTRIBUTE_ID", "CLASS_ID");

    resultSet.close();
    preparedStatement.close();

    return attributesTable;
  }

  private CmdbDalGenericClassModelTable loadMethodsTable() throws SQLException {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectMethodsTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString);
    preparedStatement.setLong(customerID.getID());
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbDalGenericClassModelTable methodsTable = new CmdbDalGenericClassModelTable(resultSet, createMethodsTableColumnsNames(), createMethodsTableColumnsTypes(), "METHOD_ID", "CLASS_ID");

    resultSet.close();
    preparedStatement.close();

    return methodsTable;
  }

  private CmdbDalGenericClassModelTable loadQualifiersTable() throws SQLException {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectQualifiresTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString);
    preparedStatement.setLong(customerID.getID());
    preparedStatement.setLong(customerID.getID());
    preparedStatement.setLong(customerID.getID());
    preparedStatement.setLong(customerID.getID());
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbDalGenericClassModelTable qualifiersTable = new CmdbDalGenericClassModelTable(resultSet, createQualifiresTableColumnsNames(), createQualifiresTableColumnsTypes(), null, "ENTITY_ID");

    resultSet.close();
    preparedStatement.close();

    return qualifiersTable;
  }

  private CmdbDalGenericClassModelTable loadQualifiersDataItemsTable() throws SQLException {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectQualifirDataItemsTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString);
    preparedStatement.setLong(customerID.getID());
    preparedStatement.setLong(customerID.getID());
    preparedStatement.setLong(customerID.getID());
    preparedStatement.setLong(customerID.getID());
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbDalGenericClassModelTable qualifiersDataItemsTable = new CmdbDalGenericClassModelTable(resultSet, createQualifiresDataItemsTableColumnsNames(), createQualifiresDataItemsTableColumnsTypes(), null, "QUALIFIER_ENTITYID");

    resultSet.close();
    preparedStatement.close();

    return qualifiersDataItemsTable;
  }

  private CmdbDalGenericClassModelTable loadValidLinksTable() throws SQLException {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectValidLinksTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString);
    preparedStatement.setLong(customerID.getID());
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbDalGenericClassModelTable validLinksTable = new CmdbDalGenericClassModelTable(resultSet, createValidLinksTableColumnsNames(), createValidLinksTableColumnsTypes(), null, null);

    resultSet.close();
    preparedStatement.close();

    return validLinksTable;
  }

  private CmdbDalGenericClassModelTable loadTypeDefsTable() throws SQLException {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectTypeDefsTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString);
    preparedStatement.setLong(customerID.getID());
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbDalGenericClassModelTable typeDefsTable = new CmdbDalGenericClassModelTable(resultSet, createTypeDefsTableColumnsNames(), createTypeDefsTableColumnsTypes(), "TYPE_DEF_ID", null);

    resultSet.close();
    preparedStatement.close();

    return typeDefsTable;
  }

  private CmdbDalGenericClassModelTable loadCalculatedLinksTable() throws SQLException {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectCalculatedLinkTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString);
    preparedStatement.setLong(customerID.getID());
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbDalGenericClassModelTable calculatedLinkTable = new CmdbDalGenericClassModelTable(resultSet, createCalculatedLinkTableColumnsNames(), createCalculatedLinkTableColumnsTypes(), "TRIPLET_ID", "SIMPLE_CALC_LINK_CLASS_ID");

    resultSet.close();
    preparedStatement.close();

    return calculatedLinkTable;
  }

  private CmdbDalGenericClassModelTable loadTypeDefsEnumTable() throws SQLException
  {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectTypeDefEnumTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString);
    preparedStatement.setLong(customerID.getID());
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbDalGenericClassModelTable typeDefsEnumTable = new CmdbDalGenericClassModelTable(resultSet, createTypeDefEnumTableColumnsNames(), createTypeDefEnumTableColumnsTypes(), null, "TYPE_DEF_ID");

    resultSet.close();
    preparedStatement.close();

    return typeDefsEnumTable;
  }

  private CmdbDalGenericClassModelTable loadTypeDefsDataItemsTable() throws SQLException {
    CmdbCustomerID customerID = getLocalEnvironment().getCustomerID();

    String sqlString = createSelectTypeDefDataItemsTableSql();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlString);
    preparedStatement.setLong(customerID.getID());
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbDalGenericClassModelTable typeDefsDataItemsTable = new CmdbDalGenericClassModelTable(resultSet, createTypeDefDataItemsTableColumnsNames(), createTypeDefDataItemsTableColumnsTypes(), null, "TYPE_DEF_ID");

    resultSet.close();
    preparedStatement.close();

    return typeDefsDataItemsTable;
  }

  private String createSelectTypeDefsTableSql() {
    List columnsNames = createTypeDefsTableColumnsNames();

    return createSelectSql("CCM_TYPE_DEFS", columnsNames, "CUSTOMER_ID=?");
  }

  private String createSelectTypeDefStringTableSql() {
    List columnsNames = createTypeDefStringTableColumnsNames();

    StringBuffer condition = new StringBuffer();
    condition.append("EXISTS (SELECT 1 FROM ").append("CCM_TYPE_DEFS");
    condition.append(" TD WHERE TD.").append("TYPE_DEF_ID").append("=").append("CCM_TDEF_STR");
    condition.append(".").append("TYPE_DEF_ID").append(" AND TD.").append("CUSTOMER_ID");
    condition.append("=?)");

    return createSelectSql("CCM_TDEF_STR", columnsNames, condition.toString());
  }

  private String createSelectTypeDefEnumTableSql() {
    List columnsNames = createTypeDefEnumTableColumnsNames();

    StringBuffer condition = new StringBuffer();
    condition.append("EXISTS (SELECT 1 FROM ").append("CCM_TYPE_DEFS");
    condition.append(" TD WHERE TD.").append("TYPE_DEF_ID").append("=").append("CCM_TDEF_ENUM");
    condition.append(".").append("TYPE_DEF_ID").append(" AND TD.").append("CUSTOMER_ID");
    condition.append("=?)");

    return createSelectSql("CCM_TDEF_ENUM", columnsNames, condition.toString());
  }

  private String createSelectTypeDefDataItemsTableSql() {
    List columnsNames = createTypeDefDataItemsTableColumnsNames();

    StringBuffer condition = new StringBuffer();
    condition.append("EXISTS (SELECT 1 FROM ").append("CCM_TYPE_DEFS");
    condition.append(" TD WHERE TD.").append("TYPE_DEF_ID").append("=").append("CCM_TDEFDITEM");
    condition.append(".").append("TYPE_DEF_ID").append(" AND TD.").append("CUSTOMER_ID");
    condition.append("=?)");

    return createSelectSql("CCM_TDEFDITEM", columnsNames, condition.toString());
  }

  private String createSelectValidLinksTableSql() {
    List columnsNames = createValidLinksTableColumnsNames();

    return createSelectSql("CCM_VALIDLINK", columnsNames, "CUSTOMER_ID=?");
  }

  private String createSelectClassesTableSql() {
    List columnsNames = createClassesTableColumnsNames();

    return createSelectSql("CCM_CLASSES", columnsNames, "CUSTOMER_ID=?");
  }

  private String createSelectAttributesTableSql() {
    List columnsNames = createAttributesTableColumnsNames();

    StringBuffer condition = new StringBuffer();
    condition.append("EXISTS (SELECT 1 FROM ").append("CCM_CLASSES");
    condition.append(" C WHERE C.").append("CLASS_ID").append("=").append("CCM_ATTRIBUTE");
    condition.append(".").append("CLASS_ID").append(" AND C.").append("CUSTOMER_ID");
    condition.append("=?)");
    return createSelectSql("CCM_ATTRIBUTE", columnsNames, condition.toString());
  }

  private String createSelectMethodsTableSql() {
    List columnsNames = createMethodsTableColumnsNames();

    StringBuffer condition = new StringBuffer();
    condition.append("EXISTS (SELECT 1 FROM ").append("CCM_CLASSES");
    condition.append(" C WHERE C.").append("CLASS_ID").append("=").append("CCM_METHODS");
    condition.append(".").append("CLASS_ID").append(" AND C.").append("CUSTOMER_ID");
    condition.append("=?)");
    return createSelectSql("CCM_METHODS", columnsNames, condition.toString());
  }

  private String createSelectQualifiresTableSql() {
    List columnsNames = createQualifiresTableColumnsNames();

    StringBuffer condition = new StringBuffer();
    condition.append("EXISTS (SELECT 1 FROM ").append("CCM_CLASSES");
    condition.append(" C WHERE C.").append("CLASS_ID").append("=").append("CCM_QUALIFIER");
    condition.append(".").append("ENTITY_ID").append(" AND C.").append("CUSTOMER_ID");
    condition.append("=?)");
    condition.append(" OR EXISTS (SELECT 1 FROM ").append("CCM_ATTRIBUTE").append(" A WHERE ");
    condition.append("A.").append("ATTRIBUTE_ID").append("=").append("CCM_QUALIFIER");
    condition.append(".").append("ENTITY_ID").append(" AND EXISTS (SELECT 1 FROM ");
    condition.append("CCM_CLASSES").append(" C WHERE C.").append("CLASS_ID");
    condition.append("=A.").append("CLASS_ID").append(" AND C.").append("CUSTOMER_ID");
    condition.append("=?))");
    condition.append(" OR EXISTS (SELECT 1 FROM ").append("CCM_METHODS").append(" M WHERE ");
    condition.append("M.").append("METHOD_ID").append("=").append("CCM_QUALIFIER");
    condition.append(".").append("ENTITY_ID").append(" AND EXISTS (SELECT 1 FROM ");
    condition.append("CCM_CLASSES").append(" C WHERE C.").append("CLASS_ID");
    condition.append("=M.").append("CLASS_ID").append(" AND C.").append("CUSTOMER_ID");
    condition.append("=?))");
    condition.append(" OR EXISTS (SELECT 1 FROM ").append("CCM_VALIDLINK");
    condition.append(" V WHERE V.").append("VALID_LINK_ID").append("=").append("CCM_QUALIFIER");
    condition.append(".").append("ENTITY_ID").append(" AND V.").append("CUSTOMER_ID");
    condition.append("=?)");

    return createSelectSql("CCM_QUALIFIER", columnsNames, condition.toString());
  }

  private String createSelectQualifiresDefTableSql() {
    List columnsNames = createQualifiresDefTableColumnsNames();

    return createSelectSql("CCM_QUAL_DEF", columnsNames, "CUSTOMER_ID=?");
  }

  private String createSelectQualifirDataItemsTableSql() {
    List columnsNames = createQualifiresDataItemsTableColumnsNames();

    StringBuffer condition = new StringBuffer();
    condition.append("EXISTS (SELECT 1 FROM ").append("CCM_QUALIFIER").append(" Q ");
    condition.append("WHERE Q.").append("ENTITY_ID").append("=").append("CCM_QUALDITEM");
    condition.append(".").append("QUALIFIER_ENTITYID").append(" AND (EXISTS ");
    condition.append("(SELECT 1 FROM ").append("CCM_CLASSES").append(" C WHERE C.");
    condition.append("CLASS_ID").append("=Q.").append("ENTITY_ID").append(" AND ");
    condition.append("C.").append("CUSTOMER_ID").append("=?)");
    condition.append(" OR EXISTS (SELECT 1 FROM ").append("CCM_ATTRIBUTE");
    condition.append(" A WHERE A.").append("ATTRIBUTE_ID").append("=Q.").append("ENTITY_ID");
    condition.append(" AND EXISTS (SELECT 1 FROM ").append("CCM_CLASSES").append(" C ");
    condition.append("WHERE C.").append("CLASS_ID").append("=A.").append("CLASS_ID");
    condition.append(" AND C.").append("CUSTOMER_ID").append("=?))");
    condition.append(" OR EXISTS (SELECT 1 FROM ").append("CCM_METHODS").append(" M ");
    condition.append("WHERE M.").append("METHOD_ID").append("=Q.").append("ENTITY_ID");
    condition.append(" AND EXISTS (SELECT 1 FROM ").append("CCM_CLASSES").append(" C ");
    condition.append("WHERE C.").append("CLASS_ID").append("=M.").append("CLASS_ID");
    condition.append(" AND C.").append("CUSTOMER_ID").append("=?))");
    condition.append(" OR EXISTS (SELECT 1 FROM ").append("CCM_VALIDLINK").append(" V WHERE V.");
    condition.append("VALID_LINK_ID").append("=Q.").append("ENTITY_ID").append(" AND ");
    condition.append("V.").append("CUSTOMER_ID").append("=?)))");

    return createSelectSql("CCM_QUALDITEM", columnsNames, condition.toString());
  }

  private String createSelectCalculatedLinkTableSql() {
    List columnsNames = createCalculatedLinkTableColumnsNames();

    return createSelectSql("CCM_SIMPLE_CALC_LINK_TRIPLET", columnsNames, "CUSTOMER_ID=?");
  }

  private String createSelectSql(String tableName, List columnsNames, String condition) {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("SELECT ");

    Iterator columnsNamesIter = columnsNames.iterator();
    while (columnsNamesIter.hasNext()) {
      String columnName = (String)columnsNamesIter.next();

      sqlString.append(columnName);

      if (columnsNamesIter.hasNext())
        sqlString.append(", ");

    }

    sqlString.append(" FROM ").append(tableName).append(" WHERE ").append(condition);

    return sqlString.toString();
  }

  private List createClassesTableColumnsTypes() {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    return columnsTypes;
  }

  private List createMethodsTableColumnsTypes() {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    return columnsTypes;
  }

  private List createAttributesTableColumnsTypes() {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbXml);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    return columnsTypes;
  }

  private List createQualifiresTableColumnsTypes() {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    return columnsTypes;
  }

  private List createQualifiresDataItemsTableColumnsTypes() {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    return columnsTypes;
  }

  private List createCalculatedLinkTableColumnsTypes() {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbLong);

    return columnsTypes;
  }

  private List createTypeDefsTableColumnsTypes()
  {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);

    return columnsTypes;
  }

  private List createTypeDefStringTableColumnsTypes() {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    return columnsTypes;
  }

  private List createTypeDefEnumTableColumnsTypes() {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);
    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);

    return columnsTypes;
  }

  private List createTypeDefDataItemsTableColumnsTypes() {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);

    return columnsTypes;
  }

  private List createValidLinksTableColumnsTypes() {
    List columnsTypes = new ArrayList();

    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbString);
    columnsTypes.add(CmdbSimpleTypes.CmdbLong);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);
    columnsTypes.add(CmdbSimpleTypes.CmdbInteger);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);
    columnsTypes.add(CmdbSimpleTypes.CmdbBoolean);

    return columnsTypes;
  }

  private String createSelectCalculatedLinkTableSql(String tableName, List columnsNames) {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("SELECT ");

    Iterator columnsNamesIter = columnsNames.iterator();
    while (columnsNamesIter.hasNext()) {
      String columnName = (String)columnsNamesIter.next();

      sqlString.append(columnName);

      if (columnsNamesIter.hasNext())
        sqlString.append(", ");

    }

    sqlString.append(" FROM ").append(tableName).append(" WHERE CUSTOMER_ID = ?");

    return sqlString.toString();
  }
}