package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;

public class CmdbDalRemoveClassUpdateTableComplexCommand extends CmdbDalRemoveClassComplexCommand
{
  public CmdbDalRemoveClassUpdateTableComplexCommand(CmdbClass cmdbClass)
  {
    super(cmdbClass);
  }

  protected Object perform() {
    super.perform();
    removeClass(getCmdbClass());

    return null;
  }

  private void removeClass(CmdbClass cmdbClass) {
    try {
      removeClassTable(cmdbClass.getName());
    }
    catch (Exception e) {
      String errMsg = "Error remove cmdb class [" + cmdbClass.getName() + "], due to exception: " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }

  private void removeClassTable(String classFullQualifiedName) {
    removeClass(getClassID());

    CmdbDalCommand removeTableCommand = CmdbDalCommandFactory.createRemoveTableComplexCommand(getTableNameByClassName(classFullQualifiedName));
    removeTableCommand.execute();
  }

  private void removeClass(Long classID)
  {
    try {
      deleteCmdbClassMetaData("CCM_MAP_CLASS", classID);

      deleteCmdbClassMetaData("CCM_MIGR_TBL", classID);
    }
    catch (Exception ex) {
      String errMsg = "Error removing cmdb class [" + getCmdbClass().getName() + "] (map classes and/or migration)";

      throw new CmdbDalException(errMsg, ex);
    }
  }
}