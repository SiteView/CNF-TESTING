package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.impl.CmdbAttributeFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.List;

public class CmdbDalAddAttributesComplexCommand extends CmdbDalAbstractAddAttributesComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalAddAttributesComplexCommand.class);

  public CmdbDalAddAttributesComplexCommand(BasicContainer attributes, CmdbClass cmdbClass, Long classId)
  {
    super(attributes, cmdbClass, classId);
  }

  public CmdbDalAddAttributesComplexCommand(CmdbAttribute attribute, CmdbClass cmdbClass, Long classId) {
    super((CmdbAttributes)null, cmdbClass, classId);
    CmdbModifiableAttributes attributes = CmdbAttributeFactory.createAttributes();
    attributes.add(attribute);
    setAttributes(attributes);
  }

  protected void fillPrepareStatementAndExecute(CmdbDalPreparedStatement preparedStatement, CmdbClass cmdbClass, Long classId, BasicContainer attributes) throws SQLException {
    if ((attributes != null) && (!(attributes.isEmpty()))) {
      ReadOnlyIterator attributesIter = attributes.getIterator();
      int attributeIndex = getLastOrderingIndex();
      while (attributesIter.hasNext()) {
        CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();
        ++attributeIndex;

        Long attributeId = addAttribute(preparedStatement, classId, attribute, attributeIndex, cmdbClass);
        try
        {
          updateAttributesMapTable(attribute, attributeId, getCmdbClass());
        }
        catch (SQLException ex) {
          String errMsg = "Error adding cmdb attributes [" + attribute + "] to class [" + getCmdbClass() + ']';
          _logger.error(errMsg, ex);
        }
      }
    }
  }

  private void updateAttributesMapTable(CmdbAttribute attribute, Long attributeID, CmdbClass cmdbClass) throws SQLException {
    if (ClassModelUtil.isPersistentAttribute(attribute)) {
      String mapSqlString = createInsertMapAttributesTableSql();
      CmdbDalPreparedStatement mapPreparedStatement = getConnection().prepareStatement4Update(mapSqlString);
      mapPreparedStatement.setLong(attributeID);
      mapPreparedStatement.setString(getTableNameByClassName(cmdbClass.getName()));
      mapPreparedStatement.setString(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName()));

      mapPreparedStatement.executeUpdate();
      mapPreparedStatement.close();
    }
  }

  private String createInsertMapAttributesTableSql() {
    List columnsNames = createMapAttributesTableColumnsNames();

    return createInsertSql("CCM_MAP_ATTR", columnsNames);
  }

  private Long addAttribute(CmdbDalPreparedStatement preparedStatement, Long classId, CmdbAttribute attribute, int attributeIndex, CmdbClass cmdbClass) throws SQLException {
    Long attributeId = generateAndConfirmSequenceID();
    preparedStatement.setLong(attributeId);
    preparedStatement.setLong(classId);
    preparedStatement.setString(attribute.getName());
    preparedStatement.setString(attribute.getDisplayName());
    preparedStatement.setString(attribute.getDescription());
    preparedStatement.setClob(attribute.getDefaultValue());
    preparedStatement.setString(attribute.getType());
    preparedStatement.setInt(attribute.getSizeLimit());
    preparedStatement.setInt(0);
    preparedStatement.setInt(0);
    preparedStatement.setBoolean(attribute.hasEmptyDefaultValue());
    preparedStatement.setInt(attributeIndex);
    preparedStatement.setBoolean(attribute.isCreatedByFactory());
    preparedStatement.setBoolean(attribute.isModifiedByUser());

    preparedStatement.executeUpdate();

    addQualifiers(attribute, cmdbClass, attributeId);

    return attributeId;
  }

  private void addQualifiers(CmdbAttribute attribute, CmdbClass cmdbClass, Long attributeID) {
    CmdbDalCommand addAttributeQualifiersCommand = CmdbDalClassModelCommandFactory.createAddAttributeQualifiersComplexCommand(attribute, cmdbClass, attribute.getQualifiers(), attributeID);
    addAttributeQualifiersCommand.execute();
  }
}