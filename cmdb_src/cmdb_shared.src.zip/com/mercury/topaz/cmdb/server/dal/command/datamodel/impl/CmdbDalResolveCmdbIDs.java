package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbUnresolvedDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import java.sql.SQLException;

public class CmdbDalResolveCmdbIDs extends CmdbDalDataModelComplexCommand
{
  private CmdbUnresolvedDataIDs _unresolvedDataIDs;

  public CmdbDalResolveCmdbIDs(CmdbUnresolvedDataIDs unresolvedDataIDs)
  {
    setUnresolvedDataIDs(unresolvedDataIDs);
  }

  protected Object perform() throws Exception
  {
    CmdbDalConnection connection = null;
    CmdbDalResultSet result = null;
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDataIDs ids = CmdbDataIdsFactory.create();
    try {
      connection = getConnection();

      createCmdbIDTempTable(getConnection(), getUnresolvedDataIDs());

      String query = getQuery();
      preparedStatement = connection.prepareStatement4Select(query);
      result = preparedStatement.executeQuery();

      analyzeResults(result, ids);
    }
    finally {
      if (result != null)
        result.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }

    return ids;
  }

  private String getQuery() {
    StringBuffer query = new StringBuffer();

    query.append("select T.").append("CMDB_ID").append(" EXTERNAL_ID,R.").append("CLASS").append(", case when R.").append("CMDB_ID").append(" is null then 'NO' else 'YES' END IS_IN_MODEL, case when R.").append("CMDB_ID").append(" is null then 'NA' else case when L.").append("CMDB_ID").append(" is null then 'OBJECT' else 'LINK' end end IS_LINK");

    query.append(" from ").append(getTempTableName()).append(" T LEFT JOIN ").append(getTableNameByClassName("root")).append(" R ON T.").append("CMDB_ID").append("=R.").append("CMDB_ID").append(" LEFT JOIN ").append(getTableNameByClassName("link")).append(" L ON R.").append("CMDB_ID").append("=L.").append("CMDB_ID");

    query.append(" ORDER BY IS_IN_MODEL,IS_LINK");

    return query.toString();
  }

  private String getTempTableName() {
    if (getConnectionPool().isUsingOracleDB()) {
      return "CDM_TMP_OBJID";
    }

    return "#CDM_TMP_OBJID";
  }

  private void analyzeResults(CmdbDalResultSet result, CmdbDataIDs ids) throws SQLException
  {
    while (result.next()) {
      CmdbDataID id = null;
      byte[] cmdbID = result.getBytes("EXTERNAL_ID");
      String isInModel = result.getString("IS_IN_MODEL");
      if (isInModel.equals("YES")) {
        String isLink = result.getString("IS_LINK");
        if (isLink.equals("LINK")) {
          id = CmdbLinkID.Factory.restoreLinkID(cmdbID);
        }
        else
          id = CmdbObjectID.Factory.restoreObjectID(cmdbID);

        ids.add(id);
      }
    }
  }

  protected void validateInput()
  {
  }

  private CmdbUnresolvedDataIDs getUnresolvedDataIDs() {
    return this._unresolvedDataIDs;
  }

  private void setUnresolvedDataIDs(CmdbUnresolvedDataIDs unresolvedDataIDs) {
    this._unresolvedDataIDs = unresolvedDataIDs;
  }
}