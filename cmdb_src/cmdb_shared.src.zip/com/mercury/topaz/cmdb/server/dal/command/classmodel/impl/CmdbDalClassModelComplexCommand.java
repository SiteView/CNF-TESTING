package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.ColumnDescription;
import com.mercury.topaz.cmdb.server.dal.DBColumnType;
import com.mercury.topaz.cmdb.server.dal.IndexDescription;
import com.mercury.topaz.cmdb.server.dal.TableAdditions;
import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.param.CmdbAttributeParam;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.param.CmdbParams;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnumEntry;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.common.qualifiedname.CmdbQualifiedNameFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public abstract class CmdbDalClassModelComplexCommand<RESULT> extends CmdbDalAbstractCommand<RESULT>
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalClassModelComplexCommand.class);
  protected static final String CLASS_MODEL_CLASSES_TABLE_NAME = "CCM_CLASSES";
  protected static final String CLASS_MODEL_QUALIFIERS_TABLE_NAME = "CCM_QUALIFIER";
  protected static final String CLASS_MODEL_QUALIFIERS_DEF_TABLE_NAME = "CCM_QUAL_DEF";
  protected static final String CLASS_MODEL_QUALIFIER_DATA_ITEMS_TABLE_NAME = "CCM_QUALDITEM";
  protected static final String CLASS_MODEL_METHODS_TABLE_NAME = "CCM_METHODS";
  protected static final String CLASS_MODEL_ATTRIBUTES_TABLE_NAME = "CCM_ATTRIBUTE";
  protected static final String CLASS_MODEL_VALID_LINKS_TABLE_NAME = "CCM_VALIDLINK";
  protected static final String CLASS_MODEL_SIMPLE_CALCULATED_LINK_TRIPLET_TABLE_NAME = "CCM_SIMPLE_CALC_LINK_TRIPLET";
  protected static final String CLASS_MODEL_TYPE_DEFS_TABLE_NAME = "CCM_TYPE_DEFS";
  protected static final String CLASS_MODEL_TYPE_DEF_STRING_TABLE_NAME = "CCM_TDEF_STR";
  protected static final String CLASS_MODEL_TYPE_DEF_ENUM_TABLE_NAME = "CCM_TDEF_ENUM";
  protected static final String CLASS_MODEL_TYPE_DEF_DATA_ITEMS_TABLE_NAME = "CCM_TDEFDITEM";
  protected static final String CLASS_MODEL_MAP_ATTRIBUTES_TABLE_NAME = "CCM_MAP_ATTR";
  protected static final String CLASS_MODEL_MAP_CLASSES_TABLE_NAME = "CCM_MAP_CLASS";
  protected static final String ATTRIBUTE_ID_COLUMN_NAME = "ATTRIBUTE_ID";
  protected static final String CLASS_NAME_COLUMN_NAME = "CLASS_NAME";
  protected static final String NAME_SPACE_COLUMN_NAME = "NAME_SPACE";
  protected static final String DISPLAY_NAME_COLUMN_NAME = "DISPLAY_NAME";
  protected static final String PARENT_ID_COLUMN_NAME = "PARENT_ID";
  protected static final String CLASS_TYPE_COLUMN_NAME = "CLASS_TYPE";
  protected static final String DESCRIPTION_COLUMN_NAME = "DESCRIPTION";
  protected static final String IS_ACTIVE_COLUMN_NAME = "IS_ACTIVE";
  protected static final String METHOD_ID_COLUMN_NAME = "METHOD_ID";
  protected static final String METHOD_NAME_COLUMN_NAME = "METHOD_NAME";
  protected static final String METHOD_TYPE_COLUMN_NAME = "METHOD_TYPE";
  protected static final String COMMAND_COLUMN_NAME = "COMMAND";
  protected static final String PARAMS_COLUMN_NAME = "PARAMS";
  protected static final String ATTRIBUTE_NAME_COLUMN_NAME = "ATTRIBUTE_NAME";
  protected static final String DEFAULT_VALUE_COLUMN_NAME = "DEFAULT_VALUE";
  protected static final String ATTRIBUTE_TYPE_COLUMN_NAME = "ATTRIBUTE_TYPE";
  protected static final String VALUE_SIZE_COLUMN_NAME = "VALUE_SIZE";
  protected static final String FULL_OVERRIDE_COLUMN_NAME = "FULL_OVERRIDE";
  protected static final String PARTIAL_OVERRIDE_COLUMN_NAME = "PARTIAL_OVERRIDE";
  protected static final String IS_EMPTY_COLUMN_NAME = "IS_EMPTY";
  protected static final String ATTRIBUTE_INDEX = "ATTRIBUTE_INDEX";
  protected static final String QUALIFIER_NAME_COLUMN_NAME = "QUALIFIER_NAME";
  protected static final String QUALIFIER_ENTITY_ID_COLUMN_NAME = "QUALIFIER_ENTITYID";
  protected static final String DATA_ITEM_NAME_COLUMN_NAME = "DATA_ITEM_NAME";
  protected static final String DATA_ITEM_TYPE_COLUMN_NAME = "DATA_ITEM_TYPE";
  protected static final String DATA_ITEM_VALUE_COLUMN_NAME = "DATA_ITEM_VALUE";
  protected static final String QUALIFIER_TYPE_COLUMN_NAME = "QUALIFIER_TYPE";
  protected static final String TYPE_DEF_ID_COLUMN_NAME = "TYPE_DEF_ID";
  protected static final String TYPE_DEF_UNIQUE_ID_COLUMN_NAME = "ID";
  protected static final String TYPE_DEF_NAME_COLUMN_NAME = "TYPE_DEF_NAME";
  protected static final String TYPE_DEF_TYPE_COLUMN_NAME = "TYPE_DEF_TYPE";
  protected static final String VALUE_TYPE_COLUMN_NAME = "VALUE_TYPE";
  protected static final String STRING_VALUE_COLUMN_NAME = "STRING_VALUE";
  protected static final String ENUM_VALUE_COLUMN_NAME = "ENUM_VALUE";
  protected static final String ENUM_KEY_COLUMN_NAME = "ENUM_KEY";
  protected static final String LINK_VALID_LINK_ID_COLUMN_NAME = "VALID_LINK_ID";
  protected static final String LINK_CLASS_NAME_COLUMN_NAME = "LINK_CLASS_NAME";
  protected static final String LINK_END1_NAME_COLUMN_NAME = "LINK_END1_NAME";
  protected static final String LINK_END2_NAME_COLUMN_NAME = "LINK_END2_NAME";
  protected static final String END1_LOW_MULTIPLICITY_COLUMN_NAME = "END1_LOW_MULT";
  protected static final String END1_HIGH_MULTIPLICITY_COLUMN_NAME = "END1_HIGH_MULT";
  protected static final String END2_LOW_MULTIPLICITY_COLUMN_NAME = "END2_LOW_MULT";
  protected static final String END2_HIGH_MULTIPLICITY_COLUMN_NAME = "END2_HIGH_MULT";
  protected static final String TABLE_NAME_COLUMN_NAME = "TABLE_NAME";
  protected static final String COLUMN_NAME_COLUMN_NAME = "COLUMN_NAME";
  protected static final String IS_FACTORY_COLUMN_NAME = "IS_FACTORY";
  protected static final String IS_UPDATED_COLUMN_NAME = "IS_UPDATED";
  protected static final String ENUM_INDEX_COLUMN_NAME = "ENUM_INDEX";
  protected static final String DITEM_INDEX_COLUMN_NAME = "DITEM_INDEX";
  protected static final String TRIPLET_END1_COLUMN_NANE = "TRIPLET_END1_NAME";
  protected static final String TRIPLET_END2_COLUMN_NANE = "TRIPLET_END2_NAME";
  protected static final String TRIPLET_LINK_COLUMN_NAME = "TRIPLET_LINK_NAME";
  protected static final String TRIPLET_IS_FORWARD_COLUMN_NAME = "IS_FORWARD";
  protected static final String CALC_LINK_CLASS_ID_COLUMN_NAME = "SIMPLE_CALC_LINK_CLASS_ID";
  protected static final String TYPE_DEF_ENUM = "ENUM";
  protected static final String TYPE_DEF_LIST = "LIST";
  protected static final String TYPE_DEF_EXTERNAL_RESOURCE = "STRING";
  protected static final String DELIMITER = "##";

  private String createGetIDByNamesSql(String tableName, String[] namesColumnName, String idColumnName)
  {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("SELECT ").append(idColumnName).append(" FROM ").append(tableName);
    sqlString.append(" WHERE ");

    for (int i = 0; i < namesColumnName.length; ++i) {
      sqlString.append(namesColumnName[i]).append("=? ");

      if (i < namesColumnName.length - 1)
        sqlString.append("AND ");
    }

    return sqlString.toString();
  }

  protected Long getIDByNames(String tableName, String[] namesColumnName, String idColumnName, Object[] values, CmdbType[] types)
    throws SQLException
  {
    String sqlString = createGetIDByNamesSql(tableName, namesColumnName, idColumnName);
    return JDBCTemplate.getInstance(getConnection()).queryForLong(sqlString, values);
  }

  protected Long getClassID(String classFullQualifiedName, CmdbDalConnection connection)
    throws SQLException
  {
    String[] namesColumnName;
    Object[] values;
    CmdbType[] types;
    String[] parsedClassName = CmdbQualifiedNameFactory.parseQualifiedName(classFullQualifiedName);

    if ((parsedClassName[0] == null) || (parsedClassName[0].length() == 0)) {
      namesColumnName = new String[2];
      values = new Object[2];
      types = new CmdbType[2];

      namesColumnName[0] = "CLASS_NAME";
      namesColumnName[1] = "CUSTOMER_ID";

      values[0] = parsedClassName[1];
      types[0] = CmdbSimpleTypes.CmdbString;
      values[1] = Integer.valueOf(getCustomerID().getID());
      types[1] = CmdbSimpleTypes.CmdbInteger;
    }
    else
    {
      namesColumnName = new String[3];
      values = new Object[3];
      types = new CmdbType[3];

      namesColumnName[0] = "NAME_SPACE";
      namesColumnName[1] = "CLASS_NAME";
      namesColumnName[2] = "CUSTOMER_ID";

      values[0] = parsedClassName[0];
      types[0] = CmdbSimpleTypes.CmdbString;
      values[1] = parsedClassName[1];
      types[1] = CmdbSimpleTypes.CmdbString;
      values[2] = Integer.valueOf(getCustomerID().getID());
      types[2] = CmdbSimpleTypes.CmdbInteger;
    }

    return getIDByNames("CCM_CLASSES", namesColumnName, "CLASS_ID", values, types);
  }

  protected Long getAttributeID(String attributeName, String classFullQualifiedName, CmdbDalConnection connection)
    throws SQLException
  {
    Long classId = getClassID(classFullQualifiedName, connection);

    String[] namesColumnName = new String[2];
    Object[] values = new Object[2];
    CmdbType[] types = new CmdbType[2];

    namesColumnName[0] = "ATTRIBUTE_NAME";
    values[0] = attributeName;
    types[0] = CmdbSimpleTypes.CmdbString;

    namesColumnName[1] = "CLASS_ID";
    values[1] = classId;
    types[1] = CmdbSimpleTypes.CmdbLong;

    return getIDByNames("CCM_ATTRIBUTE", namesColumnName, "ATTRIBUTE_ID", values, types);
  }

  protected int getLastOrderingIndex(String indexColumnName, String tableName, String conditionColumn, Long condition)
    throws SQLException
  {
    int lastOrderingIndex = 0;

    StringBuffer sqlString = new StringBuffer();
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;

    sqlString.append("select ").append(indexColumnName).append(" from ");
    sqlString.append(tableName).append(" where ").append(conditionColumn);
    sqlString.append("=?");
    try
    {
      preparedStatement = getConnection().prepareStatement4Select(sqlString.toString());

      preparedStatement.setLong(condition);
      resultSet = preparedStatement.executeQuery();

      while (resultSet.next()) {
        index = resultSet.getInt(1);
        if (index.intValue() > lastOrderingIndex)
          lastOrderingIndex = index.intValue();
      }

      Integer index = lastOrderingIndex;

      return index;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  protected Long getMethodID(String methodName, String classFullQualifiedName, CmdbDalConnection connection)
    throws SQLException
  {
    Long classId = getClassID(classFullQualifiedName, connection);

    String[] namesColumnName = new String[2];
    Object[] values = new Object[2];
    CmdbType[] types = new CmdbType[2];

    namesColumnName[0] = "METHOD_NAME";
    values[0] = methodName;
    types[0] = CmdbSimpleTypes.CmdbString;

    namesColumnName[1] = "CLASS_ID";
    values[1] = classId;
    types[1] = CmdbSimpleTypes.CmdbLong;

    return getIDByNames("CCM_METHODS", namesColumnName, "METHOD_ID", values, types);
  }

  protected Long getValidLinkID(CmdbValidLink validLink, CmdbDalConnection connection)
    throws SQLException
  {
    String[] namesColumnName = new String[4];
    Object[] values = new Object[4];
    CmdbType[] types = new CmdbType[4];

    namesColumnName[0] = "LINK_CLASS_NAME";
    namesColumnName[1] = "LINK_END1_NAME";
    namesColumnName[2] = "LINK_END2_NAME";
    namesColumnName[3] = "CUSTOMER_ID";

    values[0] = validLink.getLinkClassName();
    types[0] = CmdbSimpleTypes.CmdbString;
    values[1] = validLink.getEnd1ClassName();
    types[1] = CmdbSimpleTypes.CmdbString;
    values[2] = validLink.getEnd2ClassName();
    types[2] = CmdbSimpleTypes.CmdbString;
    values[3] = Integer.valueOf(getCustomerID().getID());
    types[3] = CmdbSimpleTypes.CmdbInteger;

    return getIDByNames("CCM_VALIDLINK", namesColumnName, "VALID_LINK_ID", values, types);
  }

  protected Long getTypeDefID(CmdbDalConnection connection, CmdbTypeDef typeDef) throws SQLException {
    String[] namesColumnName = new String[2];
    namesColumnName[0] = "TYPE_DEF_NAME";
    namesColumnName[1] = "CUSTOMER_ID";
    Object[] values = new Object[2];
    CmdbType[] types = new CmdbType[2];

    values[0] = typeDef.getName();
    types[0] = CmdbSimpleTypes.CmdbString;
    values[1] = Integer.valueOf(getCustomerID().getID());
    types[1] = CmdbSimpleTypes.CmdbInteger;

    return getIDByNames("CCM_TYPE_DEFS", namesColumnName, "TYPE_DEF_ID", values, types);
  }

  protected Long getEnumEntryID(Long typeDefID, CmdbEnumEntry enumEntry, CmdbDalConnection connection) throws SQLException {
    String[] namesColumnName = new String[2];
    namesColumnName[0] = "TYPE_DEF_ID";
    namesColumnName[1] = "ENUM_KEY";
    Object[] values = new Object[2];
    CmdbType[] types = new CmdbType[2];

    values[0] = typeDefID;
    types[0] = CmdbSimpleTypes.CmdbLong;
    values[1] = Integer.valueOf(enumEntry.getEnumKey());
    types[1] = CmdbSimpleTypes.CmdbInteger;

    return getIDByNames("CCM_TDEF_ENUM", namesColumnName, "ID", values, types);
  }

  protected Long getListEntryID(Long typeDefID, CmdbListEntry listEntry, CmdbType cmdbListType, CmdbDalConnection connection) throws SQLException {
    String[] namesColumnName = new String[2];
    namesColumnName[0] = "TYPE_DEF_ID";
    namesColumnName[1] = "ENUM_VALUE";
    Object[] values = new Object[2];
    CmdbType[] types = new CmdbType[2];

    values[0] = typeDefID;
    types[0] = CmdbSimpleTypes.CmdbLong;
    values[1] = cmdbListType.stringValue(listEntry.getListValue());
    types[1] = CmdbSimpleTypes.CmdbString;

    return getIDByNames("CCM_TDEF_ENUM", namesColumnName, "ID", values, types);
  }

  protected boolean isSimpleTypeAttribute(CmdbAttribute attribute) {
    return (!(attribute.getResolvedType() instanceof CmdbSimpleList));
  }

  protected boolean isUniqueIndexedAttribute(CmdbAttributeOverride attribute) {
    return hasUniqueIndexQualifier(attribute.getQualifiers());
  }

  protected boolean hasUniqueIndexQualifier(CmdbAttributeQualifiers attributeQualifiers) {
    if (attributeQualifiers == null)
      return false;

    return attributeQualifiers.containsQualifier(CmdbAttributeQualifierDefs.UNIQUE_INDEXED_ATTRIBUTE.getName());
  }

  protected boolean isIndexedAttribute(CmdbAttributeOverride attribute) {
    return hasIndexQualifier(attribute.getQualifiers());
  }

  protected boolean hasIndexQualifier(CmdbAttributeQualifiers attributeQualifiers) {
    if (attributeQualifiers == null)
      return false;

    if (attributeQualifiers.containsQualifier(CmdbAttributeQualifierDefs.INDEXED_ATTRIBUTE.getName()))
      return true;

    return attributeQualifiers.containsQualifier(CmdbAttributeQualifierDefs.ID_ATTRIBUTE.getName());
  }

  protected void updateTableIndicesLists(CmdbAttributes attributes, TableAdditions tableAdditions) {
    CmdbAttributes persistentAttributes = ClassModelUtil.extractPersistentAttributes(attributes);
    addIndices(persistentAttributes, tableAdditions);
  }

  protected void updateTableIndicesLists(CmdbClass cmdbClass, TableAdditions tableAdditions) {
    CmdbAttributes persistentAttributes = ClassModelUtil.extractPersistentAttributes(cmdbClass);
    addIndices(persistentAttributes, tableAdditions);
  }

  private void addIndices(CmdbAttributes persistentAttributes, TableAdditions tableAdditions) {
    ReadOnlyIterator attributesIter = persistentAttributes.getIterator();
    while (attributesIter.hasNext()) {
      CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();

      if ((isSimpleTypeAttribute(attribute)) && (((isIndexedAttribute(attribute)) || (isUniqueIndexedAttribute(attribute)))))
      {
        if (isIndexedAttribute(attribute))
          tableAdditions.addIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName())));
        else if (isUniqueIndexedAttribute(attribute))
          tableAdditions.addIndex(new IndexDescription(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName())).unique());
      }
    }
  }

  protected void updateAttributesDataTableLists(CmdbAttributes attributes, TableAdditions tableAdditions)
  {
    CmdbAttributes persistentAttributes = ClassModelUtil.extractPersistentAttributes(attributes);
    addColumns(persistentAttributes, tableAdditions);
  }

  protected void updateAttributesDataTableLists(CmdbClass cmdbClass, TableAdditions tableAdditions) {
    CmdbAttributes persistentAttributes = ClassModelUtil.extractPersistentAttributes(cmdbClass);
    addColumns(persistentAttributes, tableAdditions);
  }

  private void addColumns(CmdbAttributes persistentAttributes, TableAdditions tableAdditions) {
    ReadOnlyIterator attributesIter = persistentAttributes.getIterator();
    while (attributesIter.hasNext()) {
      CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();

      if (isSimpleTypeAttribute(attribute)) {
        ColumnDescription columnDescription = new ColumnDescription(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName())).ofCmdbType(attribute.getResolvedType());

        if (attribute.getSizeLimit() != null)
          columnDescription.ofSize(attribute.getSizeLimit().intValue());

        if (DalClassModelUtil.isNotNullAttribute(attribute))
          columnDescription.notNullable();

        tableAdditions.addColumn(columnDescription);
      }
    }
  }

  protected String createMethodParamsString(CmdbParams params)
  {
    StringBuffer paramsString = new StringBuffer();

    ReadOnlyIterator paramsIter = params.getIterator();
    while (paramsIter.hasNext()) {
      CmdbAttributeParam param = (CmdbAttributeParam)paramsIter.next();

      paramsString.append(param.getAttributeName());
      paramsString.append("##");
    }
    return paramsString.toString();
  }

  protected void updateDefaultColumnsLists(TableDescription tableDescription, CmdbClass cmdbClass) {
    tableDescription.addColumn("CMDB_ID").ofCmdbType(CmdbSimpleTypes.CmdbBytes).ofSize(16).notNullable();

    if (!(isUpdateClassModelEnabled())) {
      tableDescription.addColumn("CUSTOMER_ID").ofCmdbType(CmdbSimpleTypes.CmdbInteger).notNullable();
    }

    if (cmdbClass.getName().equalsIgnoreCase("root")) {
      tableDescription.addColumn("CLASS").ofCmdbType(CmdbSimpleTypes.CmdbString).ofSize(100).notNullable();
    }

    if (cmdbClass.getName().equalsIgnoreCase("link")) {
      tableDescription.addColumn("END1_ID").ofType(DBColumnType.VARBINARY).ofSize(16).notNullable();
      tableDescription.addColumn("END2_ID").ofType(DBColumnType.VARBINARY).ofSize(16).notNullable();
      tableDescription.addColumn("CLASS").ofType(DBColumnType.VARCHAR).ofSize(100).notNullable();
    }
  }

  protected final String cutLongName(String longName) {
    String newName = DalClassModelUtil.cutLongName(longName);
    if (_logger.isDebugEnabled())
      _logger.debug("Fix long name [" + longName + "], to new name [" + newName + "]");

    return newName;
  }

  protected String createInsertSql(String tableName, List<String> columnsNames) {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("INSERT INTO ").append(tableName).append(" (");

    for (int i = 0; i < columnsNames.size(); ++i) {
      String columnName = (String)columnsNames.get(i);
      sqlString.append(columnName);
      if (i < columnsNames.size() - 1)
        sqlString.append(", ");

    }

    sqlString.append(") values (?");

    for (i = 0; i < columnsNames.size() - 1; ++i)
      sqlString.append(",?");

    sqlString.append(")");

    return sqlString.toString();
  }

  protected String createDeleteSql(String tableName, String condition) {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("DELETE FROM ").append(tableName).append(" WHERE ").append(condition);

    return sqlString.toString();
  }

  protected List<String> createClassesTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("CLASS_ID");
    columnsNames.add("CUSTOMER_ID");
    columnsNames.add("NAME_SPACE");
    columnsNames.add("CLASS_NAME");
    columnsNames.add("DISPLAY_NAME");
    columnsNames.add("PARENT_ID");
    columnsNames.add("CLASS_TYPE");
    columnsNames.add("DESCRIPTION");
    columnsNames.add("IS_ACTIVE");
    columnsNames.add("IS_FACTORY");
    columnsNames.add("IS_UPDATED");
    return columnsNames;
  }

  protected List<String> createMethodsTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("METHOD_ID");
    columnsNames.add("CLASS_ID");
    columnsNames.add("METHOD_NAME");
    columnsNames.add("METHOD_TYPE");
    columnsNames.add("COMMAND");
    columnsNames.add("PARAMS");
    columnsNames.add("DISPLAY_NAME");
    columnsNames.add("DESCRIPTION");
    columnsNames.add("IS_FACTORY");
    columnsNames.add("IS_UPDATED");
    return columnsNames;
  }

  protected List<String> createAttributesTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("ATTRIBUTE_ID");
    columnsNames.add("CLASS_ID");
    columnsNames.add("ATTRIBUTE_NAME");
    columnsNames.add("DISPLAY_NAME");
    columnsNames.add("DESCRIPTION");
    columnsNames.add("DEFAULT_VALUE");
    columnsNames.add("ATTRIBUTE_TYPE");
    columnsNames.add("VALUE_SIZE");
    columnsNames.add("FULL_OVERRIDE");
    columnsNames.add("PARTIAL_OVERRIDE");
    columnsNames.add("IS_EMPTY");
    columnsNames.add("ATTRIBUTE_INDEX");
    columnsNames.add("IS_FACTORY");
    columnsNames.add("IS_UPDATED");
    return columnsNames;
  }

  protected List<String> createQualifiresTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("ENTITY_ID");
    columnsNames.add("QUALIFIER_NAME");
    columnsNames.add("IS_FACTORY");
    columnsNames.add("IS_UPDATED");
    return columnsNames;
  }

  protected List<String> createQualifiresDataItemsTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("QUALIFIER_ENTITYID");
    columnsNames.add("QUALIFIER_NAME");
    columnsNames.add("DATA_ITEM_NAME");
    columnsNames.add("DATA_ITEM_TYPE");
    columnsNames.add("DATA_ITEM_VALUE");
    columnsNames.add("IS_FACTORY");
    columnsNames.add("IS_UPDATED");
    return columnsNames;
  }

  protected List<String> createQualifiresDefTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("QUALIFIER_NAME");
    columnsNames.add("DESCRIPTION");
    columnsNames.add("DISPLAY_NAME");
    columnsNames.add("QUALIFIER_TYPE");
    columnsNames.add("CUSTOMER_ID");
    columnsNames.add("IS_FACTORY");
    columnsNames.add("IS_UPDATED");
    return columnsNames;
  }

  protected List<String> createTypeDefsTableColumnsNames()
  {
    List columnsNames = new ArrayList();

    columnsNames.add("TYPE_DEF_ID");
    columnsNames.add("CUSTOMER_ID");
    columnsNames.add("TYPE_DEF_NAME");
    columnsNames.add("DISPLAY_NAME");
    columnsNames.add("DESCRIPTION");
    columnsNames.add("TYPE_DEF_TYPE");
    columnsNames.add("VALUE_TYPE");
    columnsNames.add("IS_FACTORY");
    columnsNames.add("IS_UPDATED");

    return columnsNames;
  }

  protected List<String> createTypeDefStringTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("TYPE_DEF_ID");
    columnsNames.add("STRING_VALUE");
    columnsNames.add("IS_UPDATED");
    return columnsNames;
  }

  protected List<String> createTypeDefEnumTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("TYPE_DEF_ID");
    columnsNames.add("ENUM_VALUE");
    columnsNames.add("ENUM_KEY");
    columnsNames.add("ID");
    columnsNames.add("IS_FACTORY");
    columnsNames.add("IS_UPDATED");
    columnsNames.add("ENUM_INDEX");

    return columnsNames;
  }

  protected List<String> createTypeDefDataItemsTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("TYPE_DEF_ID");
    columnsNames.add("ENUM_KEY");
    columnsNames.add("DATA_ITEM_NAME");
    columnsNames.add("DATA_ITEM_TYPE");
    columnsNames.add("DATA_ITEM_VALUE");
    columnsNames.add("IS_FACTORY");
    columnsNames.add("IS_UPDATED");
    columnsNames.add("DITEM_INDEX");

    return columnsNames;
  }

  protected List<String> createValidLinksTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("VALID_LINK_ID");
    columnsNames.add("LINK_CLASS_NAME");
    columnsNames.add("LINK_END1_NAME");
    columnsNames.add("LINK_END2_NAME");
    columnsNames.add("CUSTOMER_ID");
    columnsNames.add("END1_LOW_MULT");
    columnsNames.add("END1_HIGH_MULT");
    columnsNames.add("END2_LOW_MULT");
    columnsNames.add("END2_HIGH_MULT");
    columnsNames.add("IS_FACTORY");
    columnsNames.add("IS_UPDATED");

    return columnsNames;
  }

  protected List<String> createCalculatedLinkTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("TRIPLET_ID");
    columnsNames.add("TRIPLET_END1_NAME");
    columnsNames.add("TRIPLET_END2_NAME");
    columnsNames.add("TRIPLET_LINK_NAME");
    columnsNames.add("IS_FORWARD");
    columnsNames.add("SIMPLE_CALC_LINK_CLASS_ID");
    columnsNames.add("CUSTOMER_ID");
    return columnsNames;
  }

  protected List<String> createMapClassesTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("CLASS_ID");
    columnsNames.add("TABLE_NAME");
    return columnsNames;
  }

  protected List<String> createMapAttributesTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("ATTRIBUTE_ID");
    columnsNames.add("TABLE_NAME");
    columnsNames.add("COLUMN_NAME");
    return columnsNames;
  }

  protected List<String> createMigrationTableColumnsNames() {
    List columnsNames = new ArrayList();

    columnsNames.add("CLASS_ID");
    columnsNames.add("UNIFIED_NAME");
    columnsNames.add("SEPARATE_NAME");
    columnsNames.add("CUSTOMER_ID");

    return columnsNames;
  }
}