package com.mercury.topaz.cmdb.server.dal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public class TableDescription
  implements TableAdditions
{
  private String tableName;
  private Map<String, ColumnDescription> columns = new LinkedHashMap();
  private IndexDescription primaryKey = null;
  private Collection<IndexDescription> indexes = new ArrayList();
  private Collection<ForeignKeyDescription> foreignKeys = new ArrayList();

  public TableDescription(String tableName)
  {
    this.tableName = tableName;
  }

  public String getTableName() {
    return this.tableName;
  }

  public ColumnDescription addColumn(String columnName) {
    ColumnDescription columnDescription = new ColumnDescription(columnName);
    addColumn(columnDescription);
    return columnDescription;
  }

  public void addColumn(ColumnDescription columnDescription) {
    this.columns.put(columnDescription.getName(), columnDescription);
  }

  public Map<String, ColumnDescription> getColumns() {
    return this.columns;
  }

  public Collection<ColumnDescription> getColumnsToAdd() {
    return getColumns().values();
  }

  public void setPrimaryKey(IndexDescription primaryKey) {
    primaryKey.unique();
    this.primaryKey = primaryKey;
  }

  public IndexDescription getPrimaryKey() {
    return this.primaryKey;
  }

  public void addIndex(IndexDescription indexDescription) {
    this.indexes.add(indexDescription);
  }

  public IndexDescription addIndex(String columnName) {
    IndexDescription indexDescription = new IndexDescription(columnName);
    addIndex(indexDescription);
    return indexDescription;
  }

  public Collection<IndexDescription> getIndexes() {
    return this.indexes;
  }

  public Collection<IndexDescription> getIndexesToAdd() {
    return getIndexes();
  }

  public void addForeignKey(ForeignKeyDescription foreignKeyDescription) {
    this.foreignKeys.add(foreignKeyDescription);
  }

  public Collection<ForeignKeyDescription> getForeignKeys() {
    return this.foreignKeys;
  }
}