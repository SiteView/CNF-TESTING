package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CalculatedLinkTripletDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;

public class CmdbDalRemoveCalculatedLinkTripletCommand extends CmdbDalClassModelComplexCommand
{
  private CmdbClass _cmdbClass;
  private CalculatedLinkTripletDefinition _triplet;
  private Long _linkClassID;

  public CmdbDalRemoveCalculatedLinkTripletCommand(CalculatedLinkTripletDefinition triplet, CmdbClass cmdbClass, Long classID)
  {
    setCmdbClass(cmdbClass);
    setTriplet(triplet);
    setLinkClassID(classID);
  }

  protected void validateInput() {
    if (getTriplet() == null)
      throw new CmdbDalException("Can't remove null triplet !!!");
  }

  protected Object perform() throws Exception
  {
    removeTriplet(getLinkClassID(), getTriplet());
    return null;
  }

  protected String getCommandName()
  {
    return "Remove calculated link triplets for link [] to cmdb class []";
  }

  protected void removeTriplet(Long classID, CalculatedLinkTripletDefinition triplet) throws SQLException {
    StringBuffer condition = new StringBuffer();
    condition.append("SIMPLE_CALC_LINK_CLASS_ID").append("=? AND ").append("TRIPLET_END1_NAME").append(" =? AND ").append("TRIPLET_END2_NAME").append(" =? AND ").append("TRIPLET_LINK_NAME").append(" =? AND ").append("IS_FORWARD").append(" =?");

    String sqlString = createDeleteSql("CCM_SIMPLE_CALC_LINK_TRIPLET", condition.toString());
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Update(sqlString);
    preparedStatement.setLong(classID);
    preparedStatement.setString(triplet.getEnd1Type());
    preparedStatement.setString(triplet.getEnd2Type());
    preparedStatement.setString(triplet.getLinkType());
    preparedStatement.setBoolean(triplet.isForward());
    preparedStatement.executeUpdate();
    preparedStatement.close();
  }

  protected CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass; }

  protected CalculatedLinkTripletDefinition getTriplet() {
    return this._triplet;
  }

  private void setTriplet(CalculatedLinkTripletDefinition triplet) {
    this._triplet = triplet;
  }

  private void setLinkClassID(Long classID) {
    this._linkClassID = classID;
  }

  protected Long getLinkClassID() throws SQLException {
    Long classId = this._linkClassID;

    if (classId == null) {
      classId = getClassID(getCmdbClass().getName(), getConnection());
      setLinkClassID(classId);
    }

    return classId;
  }
}