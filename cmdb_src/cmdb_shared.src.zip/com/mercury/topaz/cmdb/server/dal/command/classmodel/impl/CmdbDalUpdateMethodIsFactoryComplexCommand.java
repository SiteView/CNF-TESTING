package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import java.sql.SQLException;

public class CmdbDalUpdateMethodIsFactoryComplexCommand extends CmdbDalUpdateMethodPropertyComplexCommand
{
  public CmdbDalUpdateMethodIsFactoryComplexCommand(CmdbMethod method, CmdbClass cmdbClass)
  {
    super(method, cmdbClass);
  }

  protected String getCommandName() {
    return "Update is factory of method [" + getMethod().getName() + "] in class [" + getCmdbClass().getName() + "] to [" + getMethod().isCreatedByFactory() + "]";
  }

  protected String getColumnNameToUpdate() {
    return "IS_FACTORY";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long methodId) throws SQLException {
    preparedStatement.setBoolean(getMethod().isCreatedByFactory());
    preparedStatement.setBoolean(getMethod().isModifiedByUser());
    preparedStatement.setLong(methodId);
  }
}