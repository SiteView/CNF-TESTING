package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;

public class CmdbDalUpdateClassDescriptionComplexCommand extends CmdbDalUpdateClassPropertyComplexCommand
{
  public CmdbDalUpdateClassDescriptionComplexCommand(CmdbClass cmdbClass)
  {
    super(cmdbClass);
  }

  protected String getColumnNameToUpdate() {
    return "DESCRIPTION";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long classId) throws SQLException {
    preparedStatement.setString(getCmdbClass().getDescription());
    preparedStatement.setBoolean(getCmdbClass().isModifiedByUser());
    preparedStatement.setLong(classId);
  }

  protected String getCommandName() {
    return "Update description of class [" + getCmdbClass().getName() + "] to [" + getCmdbClass().getDescription() + "]";
  }
}