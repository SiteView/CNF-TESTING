package com.mercury.topaz.cmdb.server.dal.command.impl;

public class CmdbDalConstants
{
  public static final class DataModel
  {
    public static final String DATA_MODEL_TABLE_NAME_PREFIX = "CDM_";
    public static final String DATA_MODEL_TABLE_NAME_DELIMITER = "_";
    public static final String COLUMN_PREFIX = "A_";
    public static final String DATA_MODEL_MANAGEMENT_TABLE_NAME_PREFIX = "CDMM_";
    public static final String DATA_TABLE_SPACE_NAME = "CMDBDATA";
    public static final String INDEX_TABLE_SPACE_NAME = "CMDBINDEX";
    public static final String PRIMARY_KEY_PREFIX = "PK_";
    public static final String FOREIGN_KEY_PREFIX = "FK1_";
    public static final String INDEX_PREFIX = "IX1_";
    public static final String UNIQUE_INDEX_PREFIX = "UIX1_";
    public static final String CMDB_ID_COLUMN_NAME = "CMDB_ID";
    public static final String CLASS_COLUMN_NAME = "CLASS";
    public static final String LINK_END1_ID_COLUMN_NAME = "END1_ID";
    public static final String LINK_END2_ID_COLUMN_NAME = "END2_ID";
    public static final String ADD_LINK_ID_COLUMN_NAME = "ADD_LINK_ID";
    public static final String LIST_OF_ATTRIBUTES_DUMMY_CLASS_NAME = "LIST_ATTR_PRIMITIVE";
    public static final String LIST_OF_ATTRIBUTES_ATTRIBUTE_NAME_COLUMN_NAME = "ATTR_NAME";
    public static final String LIST_OF_ATTRIBUTES_ATTRIBUTE_VALUE_COLUMN_NAME = "ATTR_VALUE";
    public static final String CMDB_ID_TEMP_TABLE_NAME = "CDM_TMP_OBJID";
    public static final String STRING_TEMP_TABLE_NAME = "CDM_TMP_STR";
    public static final String NUMBER_TEMP_TABLE_NAME = "CDM_TMP_INT";
    public static final String CMDB_ID_STR_TEMP_TABLE_NAME = "CDM_TMP_OBJID_STR";
    public static final String TEMP_TABLE_VALUE_COLUMN_NAME = "T_VALUE";
    public static final String TEMP_TABLE_VALUES_INDEX_COLUMN_NAME = "T_VALUES_INDEX";
  }

  public static final class ClassModel
  {
    public static final String CLASS_MODEL_TABLE_NAME_PREFIX = "CCM_";
    public static final String CLASS_MODEL_TEMP_TABLE_NAME = "CCM_TMP_EID";
    public static final String CLASS_MODEL_CLASSES_TABLE_NAME = "CCM_CLASSES";
    public static final String CLASS_MODEL_QUALIFIERS_TABLE_NAME = "CCM_QUALIFIER";
    public static final String CLASS_MODEL_QUALIFIERS_DEF_TABLE_NAME = "CCM_QUAL_DEF";
    public static final String CLASS_MODEL_QUALIFIER_DATA_ITEMS_TABLE_NAME = "CCM_QUALDITEM";
    public static final String CLASS_MODEL_METHODS_TABLE_NAME = "CCM_METHODS";
    public static final String CLASS_MODEL_ATTRIBUTES_TABLE_NAME = "CCM_ATTRIBUTE";
    public static final String CLASS_MODEL_VALID_LINKS_TABLE_NAME = "CCM_VALIDLINK";
    public static final String CLASS_MODEL_TYPE_DEFS_TABLE_NAME = "CCM_TYPE_DEFS";
    public static final String CLASS_MODEL_SIMPLE_CALCULATED_LINK_TRIPLET_TABLE_NAME = "CCM_SIMPLE_CALC_LINK_TRIPLET";
    public static final String CLASS_MODEL_TYPE_DEF_STRING_TABLE_NAME = "CCM_TDEF_STR";
    public static final String CLASS_MODEL_TYPE_DEF_ENUM_TABLE_NAME = "CCM_TDEF_ENUM";
    public static final String CLASS_MODEL_TYPE_DEF_DATA_ITEMS_TABLE_NAME = "CCM_TDEFDITEM";
    public static final String CLASS_MODEL_MAP_ATTRIBUTES_TABLE_NAME = "CCM_MAP_ATTR";
    public static final String CLASS_MODEL_MAP_CLASSES_TABLE_NAME = "CCM_MAP_CLASS";
    public static final String ATTRIBUTE_ID_COLUMN_NAME = "ATTRIBUTE_ID";
    public static final String CLASS_NAME_COLUMN_NAME = "CLASS_NAME";
    public static final String NAME_SPACE_COLUMN_NAME = "NAME_SPACE";
    public static final String DISPLAY_NAME_COLUMN_NAME = "DISPLAY_NAME";
    public static final String PARENT_ID_COLUMN_NAME = "PARENT_ID";
    public static final String CLASS_TYPE_COLUMN_NAME = "CLASS_TYPE";
    public static final String DESCRIPTION_COLUMN_NAME = "DESCRIPTION";
    public static final String IS_ACTIVE_COLUMN_NAME = "IS_ACTIVE";
    public static final String METHOD_ID_COLUMN_NAME = "METHOD_ID";
    public static final String METHOD_NAME_COLUMN_NAME = "METHOD_NAME";
    public static final String METHOD_TYPE_COLUMN_NAME = "METHOD_TYPE";
    public static final String COMMAND_COLUMN_NAME = "COMMAND";
    public static final String PARAMS_COLUMN_NAME = "PARAMS";
    public static final String ATTRIBUTE_NAME_COLUMN_NAME = "ATTRIBUTE_NAME";
    public static final String DEFAULT_VALUE_COLUMN_NAME = "DEFAULT_VALUE";
    public static final String ATTRIBUTE_TYPE_COLUMN_NAME = "ATTRIBUTE_TYPE";
    public static final String VALUE_SIZE_COLUMN_NAME = "VALUE_SIZE";
    public static final String FULL_OVERRIDE_COLUMN_NAME = "FULL_OVERRIDE";
    public static final String PARTIAL_OVERRIDE_COLUMN_NAME = "PARTIAL_OVERRIDE";
    public static final String IS_EMPTY_COLUMN_NAME = "IS_EMPTY";
    public static final String ATTRIBUTE_INDEX = "ATTRIBUTE_INDEX";
    public static final String QUALIFIER_NAME_COLUMN_NAME = "QUALIFIER_NAME";
    public static final String QUALIFIER_ENTITY_ID_COLUMN_NAME = "QUALIFIER_ENTITYID";
    public static final String DATA_ITEM_NAME_COLUMN_NAME = "DATA_ITEM_NAME";
    public static final String DATA_ITEM_TYPE_COLUMN_NAME = "DATA_ITEM_TYPE";
    public static final String DATA_ITEM_VALUE_COLUMN_NAME = "DATA_ITEM_VALUE";
    public static final String QUALIFIER_TYPE_COLUMN_NAME = "QUALIFIER_TYPE";
    public static final String TYPE_DEF_ID_COLUMN_NAME = "TYPE_DEF_ID";
    public static final String TYPE_DEF_UNIQUE_ID_COLUMN_NAME = "ID";
    public static final String TYPE_DEF_NAME_COLUMN_NAME = "TYPE_DEF_NAME";
    public static final String TYPE_DEF_TYPE_COLUMN_NAME = "TYPE_DEF_TYPE";
    public static final String VALUE_TYPE_COLUMN_NAME = "VALUE_TYPE";
    public static final String STRING_VALUE_COLUMN_NAME = "STRING_VALUE";
    public static final String ENUM_VALUE_COLUMN_NAME = "ENUM_VALUE";
    public static final String ENUM_KEY_COLUMN_NAME = "ENUM_KEY";
    public static final String LINK_VALID_LINK_ID_COLUMN_NAME = "VALID_LINK_ID";
    public static final String LINK_CLASS_NAME_COLUMN_NAME = "LINK_CLASS_NAME";
    public static final String LINK_END1_NAME_COLUMN_NAME = "LINK_END1_NAME";
    public static final String LINK_END2_NAME_COLUMN_NAME = "LINK_END2_NAME";
    public static final String END1_LOW_MULTIPLICITY_COLUMN_NAME = "END1_LOW_MULT";
    public static final String END1_HIGH_MULTIPLICITY_COLUMN_NAME = "END1_HIGH_MULT";
    public static final String END2_LOW_MULTIPLICITY_COLUMN_NAME = "END2_LOW_MULT";
    public static final String END2_HIGH_MULTIPLICITY_COLUMN_NAME = "END2_HIGH_MULT";
    public static final String TABLE_NAME_COLUMN_NAME = "TABLE_NAME";
    public static final String COLUMN_NAME_COLUMN_NAME = "COLUMN_NAME";
    public static final String IS_FACTORY_COLUMN_NAME = "IS_FACTORY";
    public static final String IS_UPDATED_COLUMN_NAME = "IS_UPDATED";
    public static final String ENUM_INDEX_COLUMN_NAME = "ENUM_INDEX";
    public static final String DITEM_INDEX_COLUMN_NAME = "DITEM_INDEX";
    public static final String ENTITY_ID_COLUMN_NAME = "ENTITY_ID";
    public static final String CLASS_ID_COLUMN_NAME = "CLASS_ID";
    public static final String CALCULATED_LINK_TRIPLET_ID_COLUMN_NAME = "TRIPLET_ID";
    public static final String TRIPLET_END1_COLUMN_NANE = "TRIPLET_END1_NAME";
    public static final String TRIPLET_END2_COLUMN_NANE = "TRIPLET_END2_NAME";
    public static final String TRIPLET_LINK_COLUMN_NANE = "TRIPLET_LINK_NAME";
    public static final String TRIPLET_IS_FORWARD_COLUMN_NAME = "IS_FORWARD";
    public static final String CALC_LINK_CLASS_ID_COLUMN_NAME = "SIMPLE_CALC_LINK_CLASS_ID";
    public static final int MAX_STRING_COLUMN_SIZE = 4000;
    public static final int MAX_INDEXED_STRING_COLUMN_SIZE = 900;
    public static final int DEFAULT_STRING_COLUMN_SIZE = 50;
    public static final int DEFAULT_RAW_COLUMN_SIZE = 16;
    public static final int DEFAULT_NUMBER_COLUMN_SIZE = 11;
    public static final int DEFAULT_LONG_COLUMN_SIZE = 22;
    public static final String CLASS_MODEL_MIGRATION_TABLE_NAME = "CCM_MIGR_TBL";
    public static final String UNIFIED_NAME_COLUMN_NAME = "UNIFIED_NAME";
    public static final String SEPERATE_NAME_COLUMN_NAME = "SEPARATE_NAME";
  }

  public static final class Common
  {
    public static final String CUSTOMER_ID_COLUMN_NAME = "CUSTOMER_ID";
    public static final String CSV_CUSTOMER_ID_COLUMN_NAME = "CSV_CUSTOMER_ID";
    public static final String CSV_SUBSYSTEM_COLUMN_NAME = "CSV_SUBSYSTEM";
    public static final String CSV_VERSION_COLUMN_NAME = "CSV_VERSION";
    public static final boolean HANDLE_STATISTICS_ON_STARTUP = 1;
    public static final int STATISTICS_STARTUP_PERCENTAGE_THRESHOLD = 5;
    public static final int STATISTICS_STARTUP_AGING_THRESHOLD_HOURS = 36;
  }
}