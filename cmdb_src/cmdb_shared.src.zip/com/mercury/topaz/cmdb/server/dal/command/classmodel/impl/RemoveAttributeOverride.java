package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.dal.dao.CmdbDalDataModelDAO;
import com.mercury.topaz.cmdb.server.dal.dao.impl.CmdbDalDAOFactory;
import com.mercury.topaz.cmdb.server.dal.util.DalDataModelUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;

public class RemoveAttributeOverride extends CmdbDalClassModelComplexCommand<Void>
{
  private final CmdbAttributeOverride attributeOverride;
  private final CmdbClass cmdbClass;
  private final Long classId;

  public RemoveAttributeOverride(CmdbAttributeOverride attributeOverride, CmdbClass cmdbClass, Long classId)
  {
    this.attributeOverride = attributeOverride;
    this.cmdbClass = cmdbClass;
    this.classId = classId;
  }

  protected void validateInput() {
    if (this.cmdbClass == null)
      throw new CmdbDalException("Can't remove attribute override of null cmdb class !!!");
  }

  protected Void perform() throws Exception
  {
    CmdbDalDataModelDAO dao = CmdbDalDAOFactory.createDataModelDAO();
    dao.execute(new CmdbDalRemoveAttributesOverridesComplexCommand(this.attributeOverride, this.cmdbClass, this.classId));

    getConnection().commit();

    DalDataModelUtil.handleQualifiersRemoval(this.cmdbClass, this.attributeOverride.getName(), this.attributeOverride.getQualifiers());

    return null;
  }

  protected String getCommandName() {
    return "Remove attribute override [" + this.attributeOverride + "] of cmdb class [" + this.cmdbClass.getName() + "]";
  }
}