package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreator;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreatorFactory;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyValuesFactory;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbIntegerPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbStringPropertyValues;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class CmdbDalGetLayoutComplexCommand extends CmdbDalDataModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalGetLayoutComplexCommand.class);
  private static final int MAX_VARCHAR2_LENGTH_BYTES = 4000;
  private static final int MAX_VARCHAR2_SAFE_LENGTH_CHARS = 1333;
  private static final String VARCHAR_COLUMN_PREFIX = "VC_";
  protected static final int RESET_ITERATION_NUMBER = 5000;
  private PropertyCreator _propertyCreator;

  public CmdbDalGetLayoutComplexCommand()
  {
    this._propertyCreator = null; }

  protected void prepare() throws Exception {
    setUseDirtyRead();
  }

  protected void postProcess() throws Exception {
    truncateCmdbIDTempTable(getConnection());
  }

  protected String getBaseCmdbClass(String referenceClassName, ElementSimpleLayout layout)
  {
    CmdbClass referenceCmdbClass = ClassModelUtil.getCmdbClassByName(referenceClassName);

    while (!(referenceCmdbClass.getName().equals("none"))) {
      CmdbAttributes attributes = ClassModelUtil.extractPersistentAttributes(referenceCmdbClass);
      ReadOnlyIterator attributesIter = attributes.getIterator();
      while (attributesIter.hasNext()) {
        CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();
        if (layout.contains(attribute.getName()))
          return referenceCmdbClass.getName();

      }

      referenceCmdbClass = referenceCmdbClass.getResolvedSuperClass();
    }

    String errMsg = "Can't find base cmdb class for layout: [" + layout + "], with " + "reference class: [" + referenceClassName + "]. Returns lower (root/link) base class !!!";

    _logger.info(errMsg);

    if (isTypeOfLink(referenceClassName))
      return "link";

    return "root";
  }

  protected String createListOfAttribsLayoutSql(int listOfAttribsPropertiesSize, int numOfCmdbIDs) {
    StringBuffer sql = new StringBuffer();

    sql.append("SELECT ").append("CMDB_ID");
    sql.append(", ").append("ATTR_NAME");
    sql.append(", ").append("ATTR_VALUE");
    sql.append(" FROM ").append(getTableNameByClassName("LIST_ATTR_PRIMITIVE"));
    sql.append(" WHERE ").append("ATTR_NAME");
    sql.append(getInSqlString(listOfAttribsPropertiesSize));
    sql.append(" AND ");

    if (isCmdbIDTempTableMustUsingChunksMechanism(numOfCmdbIDs)) {
      StringBuffer joinWithTempTableConditionSql = createJoinWithCmdbIDTempTableConditionSql(getTableNameByClassName("LIST_ATTR_PRIMITIVE"), numOfCmdbIDs);
      sql.append(joinWithTempTableConditionSql);
    }
    else
    {
      sql.append("CMDB_ID");
      sql.append(getInSqlString(numOfCmdbIDs));
    }

    if (!(isUpdateClassModelEnabled())) {
      sql.append(" AND ").append("CUSTOMER_ID").append("=?");
    }

    sql.append(" ORDER BY ").append("CMDB_ID").append(", ").append("ATTR_NAME");

    return sql.toString();
  }

  protected String createLayoutSql(List<String> nonListAttributes, Map<String, CmdbClass> attributes2ClassesMap, String baseCmdbClassName, int numOfCmdbIDs)
  {
    StringBuffer sql = new StringBuffer();
    Set classes = new HashSet();

    sql.append("SELECT ").append(getTableNameByClassName(baseCmdbClassName)).append(".").append("CMDB_ID");
    classes.add(baseCmdbClassName);

    for (Iterator i$ = nonListAttributes.iterator(); i$.hasNext(); ) { String attributeName = (String)i$.next();
      String className = ((CmdbClass)attributes2ClassesMap.get(attributeName)).getName();
      classes.add(className);

      sql.append(", ");
      sql.append(getTableNameByClassName(className)).append(".").append(DalClassModelUtil.getColumnNameByAttributeName(attributeName));
      CmdbAttribute attribute = getAttributeByName(attributeName, attributes2ClassesMap);
      if ((attribute.getResolvedType() instanceof CmdbXmlType) && (isOracle()))
      {
        sql.append(", ");
        appendCastAsVarchar(sql, className, attributeName);
        sql.append(" AS ").append(getVarcharColumnNameByAttributeName(attributeName));
      }
    }

    List allBaseClassAncestors = getCmdbClassAncestors(baseCmdbClassName);
    sql.append(" FROM ");
    boolean comma = false;

    for (Iterator i$ = allBaseClassAncestors.iterator(); i$.hasNext(); ) { CmdbClass cmdbClass = (CmdbClass)i$.next();
      String className = cmdbClass.getName();

      if (classes.contains(className)) {
        if (comma)
          sql.append(", ");

        sql.append(getTableNameByClassName(className));
        comma = true;
      }
    }

    String[] classesArray = (String[])classes.toArray(new String[classes.size()]);
    sql.append(" WHERE ");
    for (int i = 0; i < classesArray.length - 1; ++i) {
      String className1 = classesArray[i];
      String className2 = classesArray[(i + 1)];

      sql.append(getTableNameByClassName(className1)).append(".").append("CMDB_ID").append("=");
      sql.append(getTableNameByClassName(className2)).append(".").append("CMDB_ID").append(" AND ");

      if (!(isUpdateClassModelEnabled())) {
        sql.append(getTableNameByClassName(className1)).append(".").append("CUSTOMER_ID").append("=");
        sql.append(getTableNameByClassName(className2)).append(".").append("CUSTOMER_ID").append(" AND ");
      }

    }

    if (isCmdbIDTempTableMustUsingChunksMechanism(numOfCmdbIDs)) {
      sql.append(createJoinWithCmdbIDTempTableConditionSql(getTableNameByClassName(baseCmdbClassName), numOfCmdbIDs));
    }
    else
    {
      sql.append(getTableNameByClassName(baseCmdbClassName)).append(".").append("CMDB_ID");
      sql.append(getInSqlString(numOfCmdbIDs));
    }

    if (!(isUpdateClassModelEnabled())) {
      sql.append(" AND ").append(getTableNameByClassName(baseCmdbClassName)).append(".").append("CUSTOMER_ID");
      sql.append("=?");
    }
    return sql.toString();
  }

  private void appendCastAsVarchar(StringBuffer sql, String className, String attributeName) {
    sql.append("DBMS_LOB.SUBSTR(").append(getTableNameByClassName(className)).append(".").append(DalClassModelUtil.getColumnNameByAttributeName(attributeName)).append(",").append(1333).append(",1)");
  }

  protected List extractListOfAttribsProperties(ElementSimpleLayout layout, Map attributes2ClassesMap)
  {
    List listOfAttribsProperties = new ArrayList();

    ReadOnlyIterator keysIter = layout.getKeysIterator();
    while (keysIter.hasNext()) {
      String attributeName = (String)keysIter.next();
      CmdbAttribute attribute = getAttributeByName(attributeName, attributes2ClassesMap);
      CmdbType attributeType = attribute.getResolvedType();

      if (attributeType instanceof CmdbSimpleList)
        listOfAttribsProperties.add(attributeName);
    }

    return listOfAttribsProperties;
  }

  protected List extractNonListOfAttribsProperties(ElementSimpleLayout layout, Map attributes2ClassesMap) {
    List nonListOfAttribsProperties = new ArrayList();

    ReadOnlyIterator keysIter = layout.getKeysIterator();
    while (keysIter.hasNext()) {
      String attributeName = (String)keysIter.next();
      CmdbAttribute attribute = getAttributeByName(attributeName, attributes2ClassesMap);
      CmdbType attributeType = attribute.getResolvedType();

      if (!(attributeType instanceof CmdbSimpleList))
        nonListOfAttribsProperties.add(attributeName);
    }

    return nonListOfAttribsProperties;
  }

  protected CmdbAttribute getAttributeByName(String attributeName, Map attributes2ClassesMap) {
    CmdbClass attributeClass = (CmdbClass)attributes2ClassesMap.get(attributeName);

    return ClassModelUtil.getAttributeByName(attributeName, attributeClass);
  }

  protected ElementSimpleLayout createFullLayout(String type) {
    ElementSimpleLayout simpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    CmdbAttributes attributes = ClassModelUtil.getCmdbClassByName(type).getAllAttributes();
    ReadOnlyIterator attributesIter = attributes.getIterator();
    while (attributesIter.hasNext()) {
      CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();
      simpleLayout.addKey(attribute.getName());
    }
    return simpleLayout;
  }

  protected CmdbProperties buildLayoutProperties(List nonListOfAttribsPropertiesKeys, CmdbDalResultSet resultSet, Map attributes2ClassesMap)
    throws SQLException
  {
    CmdbProperties properties = CmdbPropertyFactory.createProperties();

    Iterator keysIter = nonListOfAttribsPropertiesKeys.iterator();
    while (keysIter.hasNext()) {
      String attributeName = (String)keysIter.next();
      CmdbAttribute attribute = getAttributeByName(attributeName, attributes2ClassesMap);
      CmdbType attributeType = attribute.getResolvedType();
      Object propertyValue = getPropertyValue(attributeType, attribute, resultSet, attributeName);

      if ((isEmptyXmlValue(attributeType, propertyValue)) || (isEmptyBytesValue(attributeType, propertyValue))) {
        propertyValue = null;
      }

      CmdbProperty property = getPropertyCreator().createProperty(attributeType, attributeName, propertyValue);
      properties.add(property);
    }
    return properties;
  }

  private Object getPropertyValue(CmdbType attributeType, CmdbAttribute attribute, CmdbDalResultSet resultSet, String attributeName) throws SQLException
  {
    Object propertyValue;
    if ((attributeType instanceof CmdbXmlType) && (isOracle())) {
      propertyValue = resultSet.getString(getVarcharColumnNameByAttributeName(attributeName));
      if ((propertyValue != null) && (((String)propertyValue).length() >= 1333))
        propertyValue = DalTypeUtil.getObject(resultSet, DalClassModelUtil.getColumnNameByAttributeName(attributeName), attributeType, attribute.getSizeLimit());
    }
    else {
      propertyValue = DalTypeUtil.getObject(resultSet, DalClassModelUtil.getColumnNameByAttributeName(attributeName), attributeType, attribute.getSizeLimit());
    }
    return propertyValue;
  }

  private String getVarcharColumnNameByAttributeName(String attributeName) {
    return DalClassModelUtil.fixLongName("VC_" + attributeName);
  }

  private boolean isEmptyXmlValue(CmdbType attributeType, Object value)
  {
    return ((CmdbSimpleTypes.CmdbXml.equals(attributeType)) && (((value == null) || (((String)value).length() == 0))));
  }

  private boolean isEmptyBytesValue(CmdbType attributeType, Object value)
  {
    return ((CmdbSimpleTypes.CmdbBytes.equals(attributeType)) && (((value == null) || (((byte[])(byte[])value).length == 0))));
  }

  protected ElementSimpleLayout extractPersistentLayout(ElementSimpleLayout layout, String baseClassName)
  {
    ElementSimpleLayout persistentLayout = PatternLayoutFactory.createElementSimpleLayout();
    CmdbAttributes attributes = ClassModelUtil.extractAllPersistentAttributes(ClassModelUtil.getCmdbClassByName(baseClassName));
    ReadOnlyIterator keysIter = layout.getKeysIterator();
    while (keysIter.hasNext()) {
      String key = (String)keysIter.next();
      if (attributes.hasAttribute(key))
        persistentLayout.addKey(key);

    }

    if ((persistentLayout.getKeysIterator() == null) || (!(persistentLayout.getKeysIterator().hasNext()))) {
      _logger.error("Illegal layout [" + layout + "] from base class [" + baseClassName + "]. After verifing with class model the new layout is empty !!!");
    }

    if (_logger.isDebugEnabled())
      _logger.debug("Requested layout [" + layout + "]. Persistent layout [" + persistentLayout + "]");

    return persistentLayout;
  }

  protected CmdbProperties concatProperties(CmdbProperties properties1, CmdbProperties properties2) {
    if ((properties2 != null) && (!(properties2.isEmpty()))) {
      ReadOnlyIterator properties2Iter = properties2.getPropertiesIterator();
      while (properties2Iter.hasNext()) {
        CmdbProperty property = (CmdbProperty)properties2Iter.next();
        properties1.add(property);
      }
    }
    return properties1;
  }

  protected void addMissingListProperties(CmdbProperties properties, List listOfAttribsPropertiesKeys, Map attributes2ClassesMap) {
    Iterator keysIter = listOfAttribsPropertiesKeys.iterator();
    while (keysIter.hasNext()) {
      String key = (String)keysIter.next();

      if (!(properties.contains(key))) {
        CmdbType attributeType = getAttributeByName(key, attributes2ClassesMap).getResolvedType();
        CmdbProperty property = CmdbPropertyFactory.createEmptyProperty(key, attributeType);
        properties.add(property);
      }
    }
  }

  protected Map buildIDs2PropertiesMap(CmdbDalResultSet listOfAttribsResultSet, Map attributes2ClassesMap) throws SQLException {
    Map ids2PropertiesMap = new HashMap();

    if ((listOfAttribsResultSet != null) && (listOfAttribsResultSet.next()))
    {
      CmdbProperties properties = CmdbPropertyFactory.createProperties();

      byte[] idAsBytes1 = listOfAttribsResultSet.getBytes(1);
      String key1 = listOfAttribsResultSet.getString(2);
      String value = listOfAttribsResultSet.getString(3);
      CmdbType attributeType1 = getAttributeByName(key1, attributes2ClassesMap).getResolvedType();

      CmdbPropertyValues values = createPropertyValues(attributeType1);
      addValueToPropertyValues(attributeType1, values, value);
      while (true) { CmdbType attributeType2;
        byte[] idAsBytes2;
        String key2;
        while (true) { while (true) { if (!(listOfAttribsResultSet.next())) break label290;
            idAsBytes2 = listOfAttribsResultSet.getBytes(1);
            key2 = listOfAttribsResultSet.getString(2);
            attributeType2 = getAttributeByName(key2, attributes2ClassesMap).getResolvedType();
            value = listOfAttribsResultSet.getString(3);

            if ((!(Arrays.equals(idAsBytes1, idAsBytes2))) || (!(key2.equals(key1)))) break;
            addValueToPropertyValues(attributeType1, values, value); }
          if ((!(Arrays.equals(idAsBytes1, idAsBytes2))) || (key2.equals(key1))) break;
          property = CmdbPropertyFactory.createProperty(key1, values);
          properties.add(property);
          key1 = key2;
          attributeType1 = attributeType2;

          values = createPropertyValues(attributeType1);
          addValueToPropertyValues(attributeType1, values, value);
        }

        property = CmdbPropertyFactory.createProperty(key1, values);
        properties.add(property);

        ids2PropertiesMap.put(getCmdbDigest(idAsBytes1), properties);

        idAsBytes1 = idAsBytes2;
        key1 = key2;
        attributeType1 = attributeType2;

        properties = CmdbPropertyFactory.createProperties();
        values = createPropertyValues(attributeType1);
        addValueToPropertyValues(attributeType1, values, value);
      }

      label290: CmdbProperty property = CmdbPropertyFactory.createProperty(key1, values);
      properties.add(property);

      ids2PropertiesMap.put(getCmdbDigest(idAsBytes1), properties);
    }
    return ids2PropertiesMap;
  }

  protected AbstractCMDBDigest getCmdbDigest(byte[] idAsBytes) {
    return ((AbstractCMDBDigest)CmdbObjectID.Factory.restoreObjectID(idAsBytes));
  }

  protected void addValueToPropertyValues(CmdbType type, CmdbPropertyValues values, String value) {
    if (type instanceof CmdbStringListType) {
      CmdbStringPropertyValues stringValues = (CmdbStringPropertyValues)values;
      stringValues.add((String)CmdbSimpleTypes.CmdbString.valueOf(value));
    } else if (type instanceof CmdbIntegerListType) {
      CmdbIntegerPropertyValues integerValues = (CmdbIntegerPropertyValues)values;
      integerValues.add((Integer)CmdbSimpleTypes.CmdbInteger.valueOf(value));
    } else {
      throw new CmdbDalException("Unknown list type [" + type + "]");
    }
  }

  protected CmdbPropertyValues createPropertyValues(CmdbType type)
  {
    CmdbPropertyValues values;
    if (type instanceof CmdbStringListType)
      values = CmdbPropertyValuesFactory.createCmdbStringPropertyValues();
    else if (type instanceof CmdbIntegerListType)
      values = CmdbPropertyValuesFactory.createCmdbIntegerPropertyValues();
    else
      throw new CmdbDalException("Unknown type [" + type + "]");

    return values;
  }

  protected PropertyCreator getPropertyCreator() {
    if (this._propertyCreator == null)
      setPropertyCreator(PropertyCreatorFactory.create());

    return this._propertyCreator;
  }

  private void setPropertyCreator(PropertyCreator propertyCreator) {
    this._propertyCreator = propertyCreator;
  }
}