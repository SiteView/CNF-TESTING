package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.ClassModelManager;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalClassModelUtil;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.manage.dal.TransactionManager;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.server.manage.instance.CmdbInstanceManager;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryGetInstancesCount;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.impl.CmdbClassModelUtil;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbContextRepository;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class CmdbDalUpdateClassHierarchyComplexCommand extends CmdbDalClassModelComplexCommand<Void>
{
  private final CmdbClass cmdbClass;
  private static final Log log = LogFactory.getEasyLog(CmdbDalUpdateClassHierarchyComplexCommand.class);

  public CmdbDalUpdateClassHierarchyComplexCommand(CmdbClass cmdbClass)
  {
    this.cmdbClass = cmdbClass;
  }

  protected Void perform() throws Exception
  {
    if (log.isInfoEnabled())
      log.info("Performing move of class in hierarchy for class: " + this.cmdbClass);

    CmdbDalUpdateClassParentComplexCommand updateParent = new CmdbDalUpdateClassParentComplexCommand(this.cmdbClass);
    updateParent.execute();
    dataUpgrade();
    return null;
  }

  private void dataUpgrade()
  {
    String tableName;
    if (noInstances()) return;

    log.info("Data found, performing data upgrade");
    CustomerInstance instance = Framework.getInstance().getInstanceManager().getInstance(getCustomerID());
    ClassModelManager classModelManager = (ClassModelManager)instance.getManager("Class Model Task");
    CmdbClassModel cmdbClassModel = classModelManager.getClassModelClone();

    CmdbClass oldClass = cmdbClassModel.getClass(this.cmdbClass.getName());
    if (oldClass.getSuperClass().equals(this.cmdbClass.getSuperClass()))
      throw new RuntimeException("Hierarchy change failed, old == new class, this should never happen (the trigger is diff)");

    CmdbLogFactory.getClassModelShortAuditLog().info("Changing class [" + this.cmdbClass.getName() + "] hierarchy from [" + this.cmdbClass.getSuperClass() + "] to [" + oldClass.getSuperClass() + "]");
    String commonBase = CmdbClassModelUtil.findCommomBaseClass(cmdbClassModel, this.cmdbClass.getSuperClass(), oldClass.getSuperClass());
    if (log.isDebugEnabled()) {
      log.debug("Common base class is: " + commonBase);
    }

    int customerId = CmdbContextRepository.peek().getCustomerID().getID();

    CmdbClass processClass = oldClass.getResolvedSuperClass();
    String classTable = getTableNameByClassName(this.cmdbClass.getName());

    if (!(isUpdateClassModelEnabled())) {
      log.debug("We are in the mms mode, adding customer_id to the queries");
      classTable = classTable + " where " + "CUSTOMER_ID" + "=" + customerId;
    }

    while (!(processClass.getName().equals(commonBase))) {
      tableName = getTableNameByClassName(processClass.getName());
      if (log.isDebugEnabled())
        log.debug("Deleting rows from table: " + tableName);

      String sql = "delete from " + tableName + " where " + "CMDB_ID" + " in (select " + "CMDB_ID" + " from " + classTable + ")";
      JDBCTemplate.getInstance(TransactionManager.getConnection()).execute(sql);
      processClass = processClass.getResolvedSuperClass();
    }

    processClass = this.cmdbClass.getResolvedSuperClass();
    while (!(processClass.getName().equals(commonBase))) {
      tableName = getTableNameByClassName(processClass.getName());
      if (log.isDebugEnabled())
        log.debug("Adding rows to table: " + tableName);

      String sqlFormat = "insert into " + tableName + " (%s) select %s from " + classTable;

      StringBuilder columns = new StringBuilder("CMDB_ID");
      StringBuilder values = new StringBuilder("CMDB_ID");
      CmdbAttributes classAttributes = processClass.getClassAttributes();
      ReadOnlyIterator iterator = classAttributes.getIterator();
      while (iterator.hasNext()) {
        CmdbAttribute attribute = (CmdbAttribute)iterator.next();
        if ((!(ClassModelUtil.isStaticAttribute(attribute))) && (attribute.getResolvedDefaultValue() != null) && (!(attribute.hasEmptyDefaultValue())) && (!(attribute.getResolvedType() instanceof CmdbSimpleList)))
        {
          Object defaultValue = attribute.getResolvedDefaultValue();

          if (attribute.getResolvedType() instanceof CmdbBooleanType) {
            defaultValue = (((java.lang.Boolean)defaultValue).booleanValue()) ? "1" : "0";
          }

          columns.append(", ").append(DalClassModelUtil.getColumnNameByAttributeName(attribute.getName()));
          values.append(", '").append(defaultValue).append("'");
        }
      }

      if (!(isUpdateClassModelEnabled())) {
        columns.append(", ").append("CUSTOMER_ID");
        values.append(", '").append(customerId).append("'");
      }

      String sql = String.format(sqlFormat, new Object[] { columns, values });
      JDBCTemplate.getInstance(TransactionManager.getConnection()).execute(sql);
      processClass = processClass.getResolvedSuperClass();
    }
  }

  private boolean noInstances() {
    ModelQueryGetInstancesCount query = new ModelQueryGetInstancesCount(this.cmdbClass.getName(), true);
    ServerApiFacade.executeOperation(query);
    return (query.getInstancesCount() == 0);
  }

  protected void validateInput()
  {
  }
}