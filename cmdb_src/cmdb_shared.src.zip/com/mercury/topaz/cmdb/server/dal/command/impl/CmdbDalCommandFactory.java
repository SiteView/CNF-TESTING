package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.dal.TableDescription;
import com.mercury.topaz.cmdb.server.dal.TableModifications;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import java.util.List;

public class CmdbDalCommandFactory
{
  public static CmdbDalCommand<Long> createGenerateSequenceIDComplexCommand(String generatorName)
  {
    return new CmdbDalGenerateSequenceIDComplexCommand(generatorName);
  }

  public static CmdbDalCommand<Long> createGenerateAndConfirmSequenceIDComplexCommand() {
    return new CmdbDalGenerateAndConfirmSequenceIDComplexCommand();
  }

  public static CmdbDalCommand<Long> createGenerateSequenceIDSimpleCommand(String generatorName) {
    return new CmdbDalGenerateSequenceIDSimpleCommand(generatorName);
  }

  public static CmdbDalCommand<Void> createTruncateTempTableComplexCommand(String tableName) {
    return new CmdbDalTruncateTempTableComplexCommand(tableName);
  }

  public static CmdbDalCommand<Void> createTruncateTableSimpleCommand(String tableName) {
    return new CmdbDalTruncateTableSimpleCommand(tableName);
  }

  public static CmdbDalCommand<Void> createCreateTableComplexCommand(TableDescription tableDescription) {
    return new CmdbDalCreateTableComplexCommand(tableDescription);
  }

  public static CmdbDalCommand<Void> createCreateTablePreprocessingSimpleCommand(TableDescription tableDescription) {
    return new CmdbDalCreateTablePreprocessingSimpleCommand(tableDescription);
  }

  public static CmdbDalCommand<Void> createRemoveTableComplexCommand(String tableName) {
    return new CmdbDalRemoveTableComplexCommand(tableName);
  }

  public static CmdbDalCommand<Boolean> createCheckTableExistenceSimpleCommand(String tableName) {
    return new CmdbDalCheckTableExistenceSimpleCommand(tableName);
  }

  public static CmdbDalCommand<Boolean> createCheckColumnExistenceSimpleCommand(String tableName, String columnName) {
    return new CmdbDalCheckColumnExistenceSimpleCommand(tableName, columnName);
  }

  public static CmdbDalCommand<List<String>> createGetTableMetaDataSimpleCommand(String tableName) {
    return new CmdbDalGetTableMetaDataSimpleCommand(tableName);
  }

  public static CmdbDalCommand<Integer> createGetColumnSizeSimpleCommand(String tableName, String columnName) {
    return new CmdbDalGetColumnSizeSimpleCommand(tableName, columnName);
  }

  public static CmdbDalCommand<Boolean> createCheckPartitionExistenceSimpleCommand(String partitionName, String tableName) {
    return new CmdbDalCheckPartitionExistenceSimpleCommand(partitionName, tableName);
  }

  public static CmdbDalCommand<Boolean> createCheckIndexExistenceSimpleCommand(String tableName, String indexName) {
    return new CmdbDalCheckIndexExistenceSimpleCommand(tableName, indexName);
  }

  public static CmdbDalCommand<Boolean> createCheckIndexExistenceByColumnSimpleCommand(String tableName, String columnName) {
    return new CmdbDalCheckIndexExistenceByColumnSimpleCommand(tableName, columnName);
  }

  public static CmdbDalCommand<Void> createRunStatisticsComplexCommand() {
    return new CmdbDalRunStatisticsComplexCommand();
  }

  public static CmdbDalCommand<List<String>> createGetIndexesByColumnSimpleCommand(String tableName, String columnName) {
    return new CmdbDalGetIndicesByColumnSimpleCommand(tableName, columnName);
  }

  public static CmdbDalCommand<Boolean> createIsRunStatisticsRequiredComplexCommand() {
    return new CmdbDalCheckIsRunStatisticsRequiredComplexCommand();
  }

  public static CmdbDalCommand<Void> createUpdateTableAddColumnsComplexCommand(TableDescription currentTable, TableModifications modifications)
  {
    return new CmdbDalUpdateTableAddColumnsComplexCommand(currentTable, modifications);
  }

  public static CmdbDalCommand<Void> createUpdateTableRemoveColumnsComplexCommand(TableDescription currentTable, TableModifications modifications) {
    return new CmdbDalUpdateTableRemoveColumnsComplexCommand(currentTable, modifications);
  }

  public static CmdbDalCommand<Void> createUpdateTableUpdateColumnsComplexCommand(TableDescription currentTable, TableModifications modifications) {
    return new CmdbDalUpdateTableUpdateColumnsComplexCommand(currentTable, modifications);
  }
}