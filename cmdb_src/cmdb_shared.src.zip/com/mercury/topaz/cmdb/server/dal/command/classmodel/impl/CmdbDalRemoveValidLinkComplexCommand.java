package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class CmdbDalRemoveValidLinkComplexCommand extends CmdbDalClassModelComplexCommand
{
  private CmdbValidLink _validLink = null;

  public CmdbDalRemoveValidLinkComplexCommand(CmdbValidLink validLink)
  {
    setValidLink(validLink);
  }

  protected void validateInput() {
    if (getValidLink() == null)
      throw new CmdbDalException("Can't remove null valid link");
  }

  protected Object perform()
  {
    removeValidLink(getValidLink());

    return null;
  }

  private CmdbValidLink getValidLink() {
    return this._validLink;
  }

  private void setValidLink(CmdbValidLink validLink) {
    this._validLink = validLink; }

  public void removeValidLink(CmdbValidLink validLink) {
    CmdbDalConnection connection;
    try {
      connection = getConnection();
      String sqlString = createDeleteValidLinkSql();
      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      Long validLinkId = getValidLinkID(validLink, connection);
      removeQualifiers(validLink, validLinkId);

      preparedStatement.setString(validLink.getLinkClassName());
      preparedStatement.setString(validLink.getEnd1ClassName());
      preparedStatement.setString(validLink.getEnd2ClassName());
      preparedStatement.setInt(getCustomerID().getID());

      preparedStatement.executeUpdate();
      preparedStatement.close();
    }
    catch (Exception e) {
      String errMsg = "Error remove valid link [" + validLink.getLinkClassName() + "], end1 [" + validLink.getEnd1ClassName() + "], end2 [" + validLink.getEnd2ClassName() + "], due to exception: " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }

  private void removeQualifiers(CmdbValidLink validLink, Long validLinkId) {
    CmdbDalCommand removeValidLinkQualifiersCommand = CmdbDalClassModelCommandFactory.createRemoveValidLinkQualifiersComplexCommand(validLink, validLink.getValidLinkQualifiers(), validLinkId);
    removeValidLinkQualifiersCommand.execute();
  }

  private String createDeleteValidLinkSql() {
    return createDeleteSql("CCM_VALIDLINK", "LINK_CLASS_NAME=? and LINK_END1_NAME=? and LINK_END2_NAME=? and CUSTOMER_ID=?");
  }
}