package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;

public class CmdbDalLoadModelGraphComplexCommand extends CmdbDalAbstractLoadModelGraphComplexCommand
{
  protected String createObjectsSql()
  {
    StringBuffer sqlString = new StringBuffer();
    sqlString.append("select r.").append("CMDB_ID").append(", r.").append("CLASS").append(" from ").append(getTableNameByClassName("root")).append(" r").append(" where not exists (select 1 from ").append(getTableNameByClassName("link")).append(" l where l.").append("CMDB_ID").append("=r.").append("CMDB_ID").append(")");

    if (!(isUpdateClassModelEnabled()))
      sqlString.append(" AND r.").append("CUSTOMER_ID").append("=?");

    return sqlString.toString();
  }

  protected String createLinksSql() {
    String sql = "select CMDB_ID, CLASS, END1_ID, END2_ID from " + getTableNameByClassName("link");

    if (!(isUpdateClassModelEnabled())) {
      sql = sql + " where CUSTOMER_ID = ?";
    }

    if (DBType.isMsSql(getConnectionPool().getDBType()))
      sql = sql + " order by cast(CLASS as varbinary(200))";
    else {
      sql = sql + " order by CLASS";
    }

    return sql;
  }
}