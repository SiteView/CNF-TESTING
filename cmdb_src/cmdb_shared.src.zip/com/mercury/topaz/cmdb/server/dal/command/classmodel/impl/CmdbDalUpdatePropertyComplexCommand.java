package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.sql.SQLException;

public abstract class CmdbDalUpdatePropertyComplexCommand extends CmdbDalClassModelComplexCommand<Void>
{
  private CmdbClass _cmdbClass = null;

  public CmdbDalUpdatePropertyComplexCommand(CmdbClass cmdbClass)
  {
    setCmdbClass(cmdbClass);
  }

  protected void validateInput() {
    if (getCmdbClass() == null)
      throw new CmdbDalException("Can't update null cmdb class");
  }

  protected Void perform() throws Exception
  {
    CmdbDalPreparedStatement preparedStatement = null;
    try
    {
      Long entityId = getRowId();

      String sql = createUpdateSql(getTableNameToUpdate(), getRowIdConditionColumnName(), getColumnNameToUpdate());
      preparedStatement = getConnection().prepareStatement4Update(sql);
      setValuesToPreparedStatement(preparedStatement, entityId);

      preparedStatement.executeUpdate();
    }
    finally {
      if (preparedStatement != null)
        preparedStatement.close();

    }

    return null;
  }

  protected abstract void setValuesToPreparedStatement(CmdbDalPreparedStatement paramCmdbDalPreparedStatement, Long paramLong)
    throws SQLException;

  protected abstract String getColumnNameToUpdate();

  protected abstract String getTableNameToUpdate();

  protected abstract String getRowIdConditionColumnName();

  protected abstract Long getRowId()
    throws SQLException;

  protected String createUpdateSql(String tableName, String rowIdConditionColumnName, String propertyToUpdate)
  {
    StringBuffer sqlString = new StringBuffer();

    sqlString.append("UPDATE ").append(tableName).append(" SET ");
    sqlString.append(propertyToUpdate).append("=?, ").append("IS_UPDATED").append("=?");
    sqlString.append(" WHERE ").append(rowIdConditionColumnName).append("=?");

    return sqlString.toString();
  }

  protected CmdbClass getCmdbClass() {
    return this._cmdbClass;
  }

  private void setCmdbClass(CmdbClass cmdbClass) {
    this._cmdbClass = cmdbClass;
  }
}