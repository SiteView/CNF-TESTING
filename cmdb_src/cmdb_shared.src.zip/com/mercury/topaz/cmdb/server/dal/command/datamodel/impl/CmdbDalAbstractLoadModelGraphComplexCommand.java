package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.dal.command.changes.CmdbDalGetModelRevision;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.model.graph.ModelGraph;
import com.mercury.topaz.cmdb.server.model.graph.impl.ModelGraphFactory;
import com.mercury.topaz.cmdb.server.model.graph.link.impl.ModelLinkFactory;
import com.mercury.topaz.cmdb.server.model.graph.object.MutableModelObject;
import com.mercury.topaz.cmdb.server.model.graph.object.impl.ModelObjectFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.util.Stopper;
import com.mercury.topaz.cmdb.shared.util.collections.impl.ChunkedStorageCollection;
import com.mercury.topaz.cmdb.shared.util.set.CmdbHashSet;
import com.mercury.topaz.cmdb.shared.util.set.CmdbHashSet.CmdbHashSetType;
import com.mercury.topaz.cmdb.shared.util.set.impl.CmdbHashSetFactory;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public abstract class CmdbDalAbstractLoadModelGraphComplexCommand extends CmdbDalDataModelComplexCommand<ModelGraph>
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalAbstractLoadModelGraphComplexCommand.class);
  private static final int CHUNK_SIZE = 50000;

  protected abstract String createObjectsSql();

  protected abstract String createLinksSql();

  protected void validateInput()
  {
  }

  protected ModelGraph perform()
  {
    return getModelGraph();
  }

  private ModelGraph getModelGraph() {
    CmdbHashSet objectsToLinks = CmdbHashSetFactory.create(CmdbHashSet.CmdbHashSetType.FLYWEIGHT_SET, 1000, 0.5F);
    try
    {
      long revision = queryRevision();

      _logger.info("Load model objects...");
      queryObjects(objectsToLinks);

      _logger.info("Load model links...");
      queryLinks(objectsToLinks);

      long stableRevision = queryRevision();

      _logger.info("Build model graph...");
      ModelGraph modelGraph = buildModelGraphFromObjectToLinksMap(objectsToLinks, revision, stableRevision);

      _logger.info("Loaded model graph: " + modelGraph.getObjectsAmount() + " objects and " + modelGraph.getLinksAmount() + " links were loaded");

      return modelGraph;
    }
    catch (Exception e) {
      String errMsg = "Error loading model graph due to exception: " + e;
      throw new CmdbDalException(errMsg, e);
    }
  }

  private long queryRevision() {
    CmdbDalGetModelRevision getModelRevision = new CmdbDalGetModelRevision();
    CmdbDalCommandResult commandResult = getModelRevision.execute();
    return ((Long)commandResult.getResult()).longValue();
  }

  private void queryObjects(Set<MutableModelObject> objectsToLinks) throws SQLException
  {
    CmdbDalResultSet result = null;
    CmdbDalPreparedStatement preparedStatement = null;
    try {
      CmdbDalConnection connection = getConnection();

      String objectsSql = createObjectsSql();

      if (isUseStatement())
        preparedStatement = connection.statement4Select(objectsSql);
      else {
        preparedStatement = connection.prepareStatement4Select(objectsSql);
      }

      if (!(isUpdateClassModelEnabled())) {
        preparedStatement.setInt(getCustomerID().getID());
      }

      Stopper stopper = new Stopper();
      stopper.start();
      result = preparedStatement.executeQuery();
      _logger.info("Read Objects - query execution time (sec): " + (stopper.elapsedTime() / 1000L));
      getConnectionPool().resetTimeout(connection);
      addObjectsFromResultSet(result, objectsToLinks);
    } finally {
      if (result != null)
        result.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private void queryLinks(CmdbHashSet<MutableModelObject> objectsToLinks)
    throws SQLException
  {
    CmdbDalResultSet result = null;
    CmdbDalPreparedStatement preparedStatement = null;
    try {
      CmdbDalConnection connection = getConnection();

      String linksSql = createLinksSql();

      if (isUseStatement())
        preparedStatement = connection.statement4Select(linksSql);
      else {
        preparedStatement = connection.prepareStatement4Select(linksSql);
      }

      if (!(isUpdateClassModelEnabled())) {
        preparedStatement.setInt(getCustomerID().getID());
      }

      Stopper stopper = new Stopper();
      stopper.start();
      result = preparedStatement.executeQuery();
      _logger.info("Read Links - query execution time (sec): " + (stopper.elapsedTime() / 1000L));
      getConnectionPool().resetTimeout(connection);

      addLinksFromResultSet(result, objectsToLinks);
      getConnectionPool().resetTimeout(connection);
    } finally {
      if (result != null)
        result.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  protected void addInClause(StringBuffer sqlString, String columnName, Set<String> inMembers, boolean notInClause)
  {
    if (notInClause)
      sqlString.append(columnName).append(" not in (");
    else
      sqlString.append(columnName).append(" in (");

    Iterator itMembers = inMembers.iterator();
    while (itMembers.hasNext()) {
      String cmdbClassName = (String)itMembers.next();
      if (itMembers.hasNext())
        sqlString.append("'").append(cmdbClassName).append("', ");
      else
        sqlString.append("'").append(cmdbClassName).append("')");
    }
  }

  protected void addLinksFromResultSet(CmdbDalResultSet resultSet, CmdbHashSet<MutableModelObject> objectsToLinks)
    throws SQLException
  {
    Collection links = new ChunkedStorageCollection(50000);

    CmdbClassModel classModel = getSynchronizedClassModel();
    Stopper stopper = new Stopper();
    stopper.start();
    while (true) { String type;
      CmdbLinkID linkID;
      MutableModelObject end1;
      MutableModelObject end2;
      while (true) { CmdbObjectID end2ID;
        byte[] idAsBytes;
        while (true) { if (!(resultSet.next())) break label378;
          type = resultSet.getString(2);
          CmdbClass cmdbClass = classModel.getClass(type);
          CmdbAttributes idAttributes = cmdbClass.getIDAttributesSortedByName();
          linkID = null;
          if (!(idAttributes.isEmpty())) {
            byte[] idAsBytes = resultSet.getBytes(1);
            linkID = CmdbLinkID.Factory.restoreLinkID(idAsBytes);
          }
          byte[] end1IDAsBytes = resultSet.getBytes(3);
          byte[] end2IDAsBytes = resultSet.getBytes(4);
          CmdbObjectID end1ID = CmdbObjectID.Factory.restoreObjectID(end1IDAsBytes, false);
          end2ID = CmdbObjectID.Factory.restoreObjectID(end2IDAsBytes, false);
          end1 = (MutableModelObject)objectsToLinks.get(end1ID);
          end2 = (MutableModelObject)objectsToLinks.get(end2ID);

          if (end1 != null) break;
          if (linkID == null) {
            idAsBytes = resultSet.getBytes(1);
            linkID = CmdbLinkID.Factory.restoreLinkID(idAsBytes);
          }
          _logger.warn("Attempt to add [link=" + linkID + " " + type + "] that end1 [id=" + end1ID + "] doesn't exist in model topology." + " Perhaps the link has been added by another node in the cluster.");
        }

        if (end2 != null) break;
        if (linkID == null) {
          idAsBytes = resultSet.getBytes(1);
          linkID = CmdbLinkID.Factory.restoreLinkID(idAsBytes);
        }
        _logger.warn("Attempt to add [link=" + linkID + " " + type + "] that end2 [id=" + end2ID + "] doesn't exist in model topology" + " Perhaps the link has been added by another node in the cluster.");
      }

      ModelLink link = buildModelLink(linkID, type, end1, end2);
      if (link != null) {
        end1.increaseLinkCount();
        end2.increaseLinkCount();
        links.add(link);
      }
    }

    for (Iterator i$ = links.iterator(); i$.hasNext(); ) { label378: ModelLink link = (ModelLink)i$.next();
      ((MutableModelObject)link.getEnd1()).optimizedAddLink(link);
      ((MutableModelObject)link.getEnd2()).optimizedAddLink(link);
    }

    _logger.info("Links (get-next) load time (sec): " + (stopper.elapsedTime() / 1000L));
  }

  protected void addObjectsFromResultSet(CmdbDalResultSet resultSet, Set<MutableModelObject> objectsToLinks)
    throws SQLException
  {
    Stopper stopper = new Stopper();
    stopper.start();
    while (resultSet.next()) {
      byte[] idAsBytes = resultSet.getBytes(1);
      String type = resultSet.getString(2);
      CmdbObjectID objectID = CmdbObjectID.Factory.restoreObjectID(idAsBytes, false);
      MutableModelObject object = buildModelObject(objectID, type);
      if (object != null)
        objectsToLinks.add(object);
    }

    _logger.info("Objects (get-next) Load time (sec): " + (stopper.elapsedTime() / 1000L));
  }

  protected ModelGraph buildModelGraphFromObjectToLinksMap(CmdbHashSet<MutableModelObject> objectsToLinks, long revision, long stableRevision) throws Exception {
    return ModelGraphFactory.createModelGraph(objectsToLinks, revision, stableRevision, getSynchronizedClassModel(), getLocalEnvironment());
  }

  private MutableModelObject buildModelObject(CmdbObjectID objectID, String type) {
    MutableModelObject object = null;
    try {
      object = (MutableModelObject)ModelObjectFactory.create(objectID, type);
    }
    catch (Exception e) {
      _logger.error("Couldn't create object with id [" + objectID + "], type [" + type + "] due to " + e);
    }
    return object;
  }

  private ModelLink buildModelLink(CmdbLinkID linkID, String type, ModelObject end1, ModelObject end2) {
    ModelLink link = null;
    try {
      if (linkID != null)
        link = ModelLinkFactory.create(type, end1, end2, linkID);
      else
        link = ModelLinkFactory.create(type, end1, end2);
    }
    catch (Exception e) {
      _logger.error("Couldn't create link with id [" + ((linkID != null) ? linkID : "unknown") + "], type [" + type + "], end1 [" + end1 + "], end2 [" + end2 + "] due to " + e);
    }

    return link;
  }
}