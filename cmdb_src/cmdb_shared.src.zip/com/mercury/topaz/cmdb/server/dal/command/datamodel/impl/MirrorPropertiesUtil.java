package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItem;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItems;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.model.object.CmdbModifiableObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MirrorPropertiesUtil
{
  public static final String MIRRORED_DATA_ITEM_NAME = "ORIGINAL";

  public static List<CmdbObject> mirrorProperties(List<CmdbObject> objects, CmdbClass cmdbClass)
  {
    CmdbAttributes duplicatedAttributes = cmdbClass.getAttributesByQualifier(CmdbAttributeQualifierDefs.MIRRORED);
    if (duplicatedAttributes.isEmpty())
      return objects;

    List modifiedObjects = null;
    for (ReadOnlyIterator it = duplicatedAttributes.getIterator(); it.hasNext(); ) {
      modifiedObjects = new ArrayList(objects.size());
      CmdbAttributeDefinition attributeDefinition = (CmdbAttributeDefinition)it.next();
      CmdbAttributeQualifier qualifier = attributeDefinition.getQualifierByName(CmdbAttributeQualifierDefs.MIRRORED.getName());
      String originalAttributeName = (String)qualifier.getDataItems().getDataItemByName("ORIGINAL").getValue();
      for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
        CmdbProperty originalProperty = object.getProperty(originalAttributeName);
        if (originalProperty != null) {
          CmdbModifiableObject modifiableObject = CmdbObjectFactory.createModifiableObject(object);

          modifiableObject.addOrUpdateProperty(CmdbPropertyFactory.createProperty(attributeDefinition.getName(), (String)originalProperty.getValue()));

          modifiedObjects.add(modifiableObject);
        } else {
          modifiedObjects.add(object);
        }
      }
      objects = modifiedObjects;
    }
    return modifiedObjects;
  }
}