package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifierDef;

public class CmdbDalAddValidLinkQualifierDefComplexCommand extends CmdbDalAddQualifierDefComplexCommand
{
  public CmdbDalAddValidLinkQualifierDefComplexCommand(ClassModelQualifierDef qualifierDef)
  {
    super(qualifierDef);
  }

  protected String getQualifierType() {
    return "VALID_LINK";
  }
}