package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.dal.command.classmodel.impl.CmdbDalClassModelCommandFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.manage.Environment;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;

public class CmdbDalGenerateSequenceIDComplexCommand extends CmdbDalAbstractCommand<Long>
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalGenerateSequenceIDComplexCommand.class);
  private String _generatorName;
  public static final String DISABLE_PARTITION_CREATION = "DISABLE_PARTITION_CREATION";
  public static String DEFAULT_GENERATOR_NAME = "CMDB_GENERAL";

  public CmdbDalGenerateSequenceIDComplexCommand()
  {
    this(DEFAULT_GENERATOR_NAME);
  }

  public CmdbDalGenerateSequenceIDComplexCommand(String generatorName)
  {
    this._generatorName = null;

    setGeneratorName(generatorName);
  }

  protected void validateInput() {
    if ((getGeneratorName() == null) || (getGeneratorName().length() == 0))
      throw new CmdbDalException("Can't generate sequence for null or empty generator name !!!");
  }

  protected Long perform() throws Exception
  {
    return getSequenceId();
  }

  protected Long getSequenceId() {
    try {
      if (!(isUseTopazIDGen())) {
        if (_logger.isDebugEnabled())
          _logger.debug("The use idgen flag is set to false. Using ramdom idgen)");

        return generateOldID();
      }
      return generateId();
    }
    catch (Exception e) {
      _logger.error("Error in generation of sequence id, due to exception: " + e);
      throw new CmdbDalException(e);
    }
  }

  private Long generateId()
  {
    CmdbDalCommand generateSequenceIDCommand = CmdbDalClassModelCommandFactory.createGenerateSequenceIDSimpleCommand(getGeneratorName());

    CmdbDalCommandResult result = generateSequenceIDCommand.execute();

    return ((Long)result.getResult());
  }

  private boolean isUseTopazIDGen() {
    if (Environment.TEST_MODE)
      return false;

    SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();
    return settingsReader.getBoolean("dal.classmodel.use.idgen", true);
  }

  private Long generateOldID()
  {
    long generatedID = ((AbstractCMDBDigest)CmdbObjectID.Factory.createObjectID()).getMostSign();

    return Long.valueOf(generatedID);
  }

  private String getGeneratorName() {
    return this._generatorName;
  }

  private void setGeneratorName(String generatorName) {
    this._generatorName = generatorName;
  }
}