package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.CmdbMethod;
import java.sql.SQLException;

public class CmdbDalUpdateMethodQualifierIsFactoryComplexCommand extends CmdbDalUpdateMethodQualifierPropertyComplexCommand
{
  public CmdbDalUpdateMethodQualifierIsFactoryComplexCommand(ClassModelQualifier qualifier, CmdbClass cmdbClass, CmdbMethod cmdbMethod)
  {
    super(qualifier, cmdbClass, cmdbMethod);
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long methodId, String rowQualifierName) throws SQLException {
    preparedStatement.setBoolean(getQualifier().isCreatedByFactory());
    preparedStatement.setBoolean(getQualifier().isModifiedByUser());
    preparedStatement.setLong(methodId);
    preparedStatement.setString(rowQualifierName);
  }

  protected String getColumnNameToUpdate() {
    return "IS_FACTORY";
  }
}