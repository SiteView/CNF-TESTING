package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;

public class CmdbDalCheckTableExistenceSimpleCommand extends CmdbDalAbstractCommand<Boolean>
{
  private String _tableName = null;

  public CmdbDalCheckTableExistenceSimpleCommand(String tableName)
  {
    setTableName(tableName);
  }

  protected void validateInput() {
    if ((getTableName() == null) || (getTableName().length() == 0))
      throw new CmdbDalException("Can't check existence for table [" + getTableName() + "]");
  }

  protected Boolean perform() throws Exception
  {
    return Boolean.valueOf(checkTableExistence());
  }

  private boolean checkTableExistence()
    throws SQLException
  {
    String sqlString;
    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;

    if (isOracle()) {
      sqlString = "select table_name from user_tables where table_name=?";
    }
    else if (isMsSql()) {
      sqlString = "select OBJECT_ID(?)";
    }
    else
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");

    try
    {
      preparedStatement = getConnection().prepareStatement4Select(sqlString);
      preparedStatement.setString(getTableName());
      resultSet = preparedStatement.executeQuery();

      boolean res = resultSet.next();

      if (res) {
        res = resultSet.getString(1) != null;
      }

      resultSet.close();
      preparedStatement.close();

      boolean bool1 = res;

      return bool1;
    }
    finally
    {
      if (resultSet != null) resultSet.close();
      if (preparedStatement != null) preparedStatement.close();
    }
  }

  private String getTableName() {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    this._tableName = tableName;
  }
}