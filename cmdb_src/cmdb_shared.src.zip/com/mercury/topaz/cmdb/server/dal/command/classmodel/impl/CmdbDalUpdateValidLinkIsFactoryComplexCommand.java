package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLinkIdentifier;
import java.sql.SQLException;

public class CmdbDalUpdateValidLinkIsFactoryComplexCommand extends CmdbDalUpdateValidLinkPropertyComplexCommand
{
  public CmdbDalUpdateValidLinkIsFactoryComplexCommand(CmdbValidLink validLink)
  {
    super(validLink);
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long validLinkId) throws SQLException {
    preparedStatement.setBoolean(getValidLink().isCreatedByFactory());
    preparedStatement.setBoolean(getValidLink().isModifiedByUser());
    preparedStatement.setLong(validLinkId);
  }

  protected String getCommandName() {
    return "Update is factory of valid link with end1 [" + getValidLink().getValidLinkIdentifier().getEnd1ClassName() + "], end2 [" + getValidLink().getValidLinkIdentifier().getEnd2ClassName() + "] and link class name [" + getValidLink().getValidLinkIdentifier().getLinkClassName() + "]  to [" + getValidLink().isCreatedByFactory() + "]";
  }

  protected String getColumnNameToUpdate() {
    return "IS_FACTORY";
  }
}