package com.mercury.topaz.cmdb.server.dal.command.changes;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import java.util.Iterator;

public class CmdbDalAddObjectsChange extends AbstractChangeDetailCommand
{
  private final CmdbObjects addedObjects;

  public CmdbDalAddObjectsChange(CmdbObjects addedObjects)
  {
    this.addedObjects = addedObjects;
  }

  protected Void perform() throws Exception {
    CmdbDalPreparedStatement statement = createChangeDetailStatement();
    for (Iterator i$ = this.addedObjects.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
      ChangeDetail changeDetail = new ChangeDetail();
      changeDetail.addingObject(object);
      setBindVariables(statement, changeDetail);
      statement.addBatch();
    }
    statement.executeBatch();
    return null;
  }
}