package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import java.sql.SQLException;

public class CmdbDalUpdateAttributeQualifierIsFactoryComplexCommand extends CmdbDalUpdateAttributeQualifierPropertyComplexCommand
{
  public CmdbDalUpdateAttributeQualifierIsFactoryComplexCommand(ClassModelQualifier qualifier, CmdbClass cmdbClass, CmdbAttributeOverride cmdbAttribute)
  {
    super(qualifier, cmdbClass, cmdbAttribute);
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long attributeId, String rowQualifierName) throws SQLException {
    preparedStatement.setBoolean(getQualifier().isCreatedByFactory());
    preparedStatement.setBoolean(getQualifier().isModifiedByUser());
    preparedStatement.setLong(attributeId);
    preparedStatement.setString(rowQualifierName);
  }

  protected String getColumnNameToUpdate() {
    return "IS_FACTORY";
  }
}