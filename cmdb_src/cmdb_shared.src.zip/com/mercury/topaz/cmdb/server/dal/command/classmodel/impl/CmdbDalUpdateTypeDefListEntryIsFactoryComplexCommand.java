package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import java.sql.SQLException;

public class CmdbDalUpdateTypeDefListEntryIsFactoryComplexCommand extends CmdbDalUpdateTypeDefListEntryPropertyComplexCommand
{
  public CmdbDalUpdateTypeDefListEntryIsFactoryComplexCommand(CmdbListEntry cmdbListEntry, CmdbList cmdbList, Long cmdbListId)
  {
    super(cmdbListEntry, cmdbList, cmdbListId);
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long listEntryId) throws SQLException {
    preparedStatement.setBoolean(getCmdbListEntry().isCreatedByFactory());
    preparedStatement.setBoolean(getCmdbListEntry().isModifiedByUser());
    preparedStatement.setLong(listEntryId);
  }

  protected String getColumnNameToUpdate() {
    return "IS_FACTORY";
  }

  protected String getCommandName() {
    return "Update is factory of list entry [" + getCmdbListEntry().getListValue() + "] of type def [" + getCmdbList().getName() + "] to [" + getCmdbListEntry().isCreatedByFactory() + "]";
  }
}