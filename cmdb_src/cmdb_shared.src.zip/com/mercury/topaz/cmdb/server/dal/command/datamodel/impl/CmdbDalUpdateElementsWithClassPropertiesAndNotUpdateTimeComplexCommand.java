package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.impl.ClassModelUtil;
import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.dal.exception.CmdbDalValidationException;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CmdbDalUpdateElementsWithClassPropertiesAndNotUpdateTimeComplexCommand extends CmdbDalDataModelComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalUpdateElementsWithClassPropertiesAndNotUpdateTimeComplexCommand.class);
  CmdbIDsCollection<? extends CmdbDataID> _idsCollection = null;
  CmdbProperties _properties = null;
  String _className = null;

  public CmdbDalUpdateElementsWithClassPropertiesAndNotUpdateTimeComplexCommand(CmdbIDsCollection<? extends CmdbDataID> idsCollection, CmdbProperties properties, String className)
  {
    setIdsCollection(idsCollection);
    setProperties(properties);
    setClassName(className);
  }

  protected void validateInput() {
    if ((getIdsCollection() == null) || (getIdsCollection().size() == 0)) {
      throw new CmdbDalValidationException("Can't update elements - null or empty ids collection");
    }

    if ((getProperties() == null) || (getProperties().size() == 0)) {
      throw new CmdbDalValidationException("Can't update elements - null or empty properties");
    }

    if ((getClassName() == null) || (getClassName().length() == 0))
      throw new CmdbDalValidationException("Can't update elements - null or empty class name");
  }

  protected Object perform()
  {
    updateElements();
    return null;
  }

  protected void updateElements() {
    String dataString = "Update [" + getIdsCollection().size() + "] [" + getClassName() + "] elements, with properties [" + getProperties() + "]";
    if (_logger.isDebugEnabled()) {
      _logger.debug(dataString);
    }

    CmdbDalPreparedStatement preparedStatement = null;
    try
    {
      Map updatedAttributes = extractUpdatedAttributes();

      if (updatedAttributes.size() > 0) {
        List idsAsBytes = elementsToIDsAsBytes(getIdsCollection());
        if (isCmdbIDTempTableMustNotUsingChunksMechanism(getIdsCollection().size())) {
          createCmdbIDTempTable(getConnection(), idsAsBytes);
        }

        String sqlString = createUpdateSql(getClassName(), updatedAttributes.values(), getIdsCollection().size());
        preparedStatement = getConnection().prepareStatement4Update(sqlString);

        for (Iterator i$ = updatedAttributes.values().iterator(); i$.hasNext(); ) { CmdbAttribute attribute = (CmdbAttribute)i$.next();
          CmdbProperty property = getProperties().get(attribute.getName());

          Object propertyValue = ((property == null) || (property.isValueEmpty())) ? null : property.getValue();

          DalTypeUtil.setObject(preparedStatement, propertyValue, attribute.getResolvedType(), attribute.getSizeLimit());
        }

        if (!(isCmdbIDTempTableMustNotUsingChunksMechanism(getIdsCollection().size()))) {
          addIDsToPrepareStatement(preparedStatement, idsAsBytes);
        }

        if (!(isUpdateClassModelEnabled())) {
          preparedStatement.setInt(getCustomerID().getID());
        }

        preparedStatement.executeUpdate();
        preparedStatement.close();
      }
    }
    catch (Exception e)
    {
    }
    finally
    {
      String errMsg;
      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private Map<String, CmdbAttribute> extractUpdatedAttributes()
  {
    CmdbClass cmdbClass = ClassModelUtil.getCmdbClassByName(getClassName());
    CmdbAttributes persistentAttributes = ClassModelUtil.extractPersistentAttributes(cmdbClass.getClassAttributes());
    Map updateAttributes = new HashMap();

    ReadOnlyIterator propertiesIter = getProperties().getPropertiesIterator();
    while (propertiesIter.hasNext()) {
      CmdbProperty property = (CmdbProperty)propertiesIter.next();

      if ((persistentAttributes.hasAttribute(property.getKey())) && 
        (!(property.getType() instanceof CmdbSimpleList))) {
        updateAttributes.put(property.getKey(), persistentAttributes.getAttributeByName(property.getKey()));
      }

    }

    if ((cmdbClass.getName().equals("root")) && 
      (updateAttributes.containsKey(getCreateTimeAttributeName()))) {
      updateAttributes.remove(getCreateTimeAttributeName());
    }

    return updateAttributes;
  }

  private CmdbIDsCollection<? extends CmdbDataID> getIdsCollection() {
    return this._idsCollection;
  }

  private void setIdsCollection(CmdbIDsCollection<? extends CmdbDataID> idsCollection) {
    this._idsCollection = idsCollection;
  }

  private CmdbProperties getProperties() {
    return this._properties;
  }

  private void setProperties(CmdbProperties properties) {
    this._properties = properties;
  }

  private String getClassName() {
    return this._className;
  }

  public void setClassName(String className) {
    this._className = className;
  }
}