package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifierDef;

public class CmdbDalAddClassQualifierDefComplexCommand extends CmdbDalAddQualifierDefComplexCommand
{
  public CmdbDalAddClassQualifierDefComplexCommand(ClassModelQualifierDef qualifierDef)
  {
    super(qualifierDef);
  }

  protected String getQualifierType() {
    return "CLASS";
  }
}