package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;

public class CmdbDalRemoveTypeDefComplexCommand extends CmdbDalAbstractTypeDefComplexCommand
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalRemoveTypeDefComplexCommand.class);
  private CmdbTypeDef _typeDef = null;

  public CmdbDalRemoveTypeDefComplexCommand(CmdbTypeDef typeDef)
  {
    setTypeDef(typeDef);
  }

  protected void validateInput() {
    if (getTypeDef() == null)
      throw new CmdbDalException("Can't remove null type definition");
  }

  protected Object perform()
  {
    removeTypeDef(getTypeDef());

    return null;
  }

  private CmdbTypeDef getTypeDef() {
    return this._typeDef;
  }

  private void setTypeDef(CmdbTypeDef typeDef) {
    this._typeDef = typeDef;
  }

  public void removeTypeDef(CmdbTypeDef typeDef) {
    CmdbDalConnection connection;
    try {
      connection = getConnection();

      Long typeDefID = getTypeDefID(connection, typeDef);

      StringBuffer condition = new StringBuffer();
      condition.append("TYPE_DEF_ID").append("=?");

      String sqlString = createDeleteSql("CCM_TDEFDITEM", condition.toString());
      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);
      preparedStatement.setLong(typeDefID);
      preparedStatement.executeUpdate();
      preparedStatement.close();

      sqlString = createDeleteSql("CCM_TDEF_ENUM", condition.toString());
      preparedStatement = connection.prepareStatement4Update(sqlString);
      preparedStatement.setLong(typeDefID);
      preparedStatement.executeUpdate();
      preparedStatement.close();

      sqlString = createDeleteSql("CCM_TDEF_STR", condition.toString());
      preparedStatement = connection.prepareStatement4Update(sqlString);
      preparedStatement.setLong(typeDefID);
      preparedStatement.executeUpdate();
      preparedStatement.close();

      sqlString = createDeleteSql("CCM_TYPE_DEFS", condition.toString());
      preparedStatement = connection.prepareStatement4Update(sqlString);
      preparedStatement.setLong(typeDefID);
      preparedStatement.executeUpdate();
      preparedStatement.close();
    }
    catch (Exception e) {
      String errMsg = "Error remove type def [" + typeDef.getName() + "], due to exception: " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }
}