package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.base.container.BasicContainer;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItem;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItems;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.List;

public abstract class CmdbDalAddClassModelQualifiersComplexCommand extends CmdbDalClassModelComplexCommand
{
  private BasicContainer _qualifires = null;
  private Long _entityId = null;

  public CmdbDalAddClassModelQualifiersComplexCommand(BasicContainer qualifires, Long entityId)
  {
    setQualifires(qualifires);
    setEntityId(entityId);
  }

  protected void validateInput() {
  }

  protected Object perform() throws Exception {
    addQualifires();
    return null;
  }

  private void addQualifires()
    throws SQLException
  {
    CmdbDalConnection connection = getConnection();
    BasicContainer qualifires = getQualifires();
    Long entityID = getEntityId();

    if ((qualifires != null) && (!(qualifires.isEmpty()))) {
      ReadOnlyIterator qualifiersIter = qualifires.getIterator();

      String sqlString = createInsertQualifiersTableSql();
      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      while (qualifiersIter.hasNext()) {
        ClassModelQualifier qualifier = (ClassModelQualifier)qualifiersIter.next();

        preparedStatement.setLong(entityID);
        preparedStatement.setString(qualifier.getName());
        preparedStatement.setBoolean(qualifier.isCreatedByFactory());
        preparedStatement.setBoolean(qualifier.isModifiedByUser());

        preparedStatement.addBatch();
      }
      preparedStatement.executeBatch();
      preparedStatement.close();

      addQualifiresDataItems(qualifires, connection, entityID);
    }
  }

  private void addQualifiresDataItems(BasicContainer qualifires, CmdbDalConnection connection, Long entityID)
    throws SQLException
  {
    ReadOnlyIterator qualifiersIter = qualifires.getIterator();

    String sqlString = createInsertQualifierDataItemsTableSql();
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

    while (qualifiersIter.hasNext()) {
      ClassModelQualifier qualifier = (ClassModelQualifier)qualifiersIter.next();
      String qualifierName = qualifier.getName();

      DataItems dataItems = qualifier.getDataItems();
      if ((dataItems != null) && (!(dataItems.isEmpty()))) {
        ReadOnlyIterator dataItemsIter = dataItems.getIterator();

        while (dataItemsIter.hasNext()) {
          DataItem dataItem = (DataItem)dataItemsIter.next();
          preparedStatement.setLong(entityID);
          preparedStatement.setString(qualifierName);
          preparedStatement.setString(dataItem.getName());
          CmdbSimpleType type = dataItem.getType();
          preparedStatement.setString(type.getName());
          preparedStatement.setString(type.stringValue(dataItem.getValue()));
          preparedStatement.setBoolean(dataItem.isCreatedByFactory());
          preparedStatement.setBoolean(dataItem.isModifiedByUser());

          preparedStatement.addBatch();
        }
      }
    }
    preparedStatement.executeBatch();
    preparedStatement.close();
  }

  private String createInsertQualifiersTableSql() {
    List columnsNames = createQualifiresTableColumnsNames();

    return createInsertSql("CCM_QUALIFIER", columnsNames);
  }

  private String createInsertQualifierDataItemsTableSql() {
    List columnsNames = createQualifiresDataItemsTableColumnsNames();

    return createInsertSql("CCM_QUALDITEM", columnsNames);
  }

  protected abstract Long getEntityIdFromDB() throws SQLException;

  protected Long getEntityId() throws SQLException {
    Long entityId = this._entityId;

    if (entityId == null) {
      entityId = getEntityIdFromDB();
      setEntityId(entityId);
    }

    return entityId;
  }

  private void setEntityId(Long entityId) {
    this._entityId = entityId;
  }

  protected BasicContainer getQualifires() {
    return this._qualifires;
  }

  protected void setQualifires(BasicContainer qualifires) {
    this._qualifires = qualifires;
  }
}