package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.EmptyModelLinks;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.impl.CmdbLinkIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

public class CmdbDalLinksConditionGetCmdbLinksNoModelLinksComplexCommand extends CmdbDalLinksConditionComplexCommand
{
  public CmdbDalLinksConditionGetCmdbLinksNoModelLinksComplexCommand(LinkCondition linkCondition)
  {
    super(linkCondition, EmptyModelLinks.getInstance());
  }

  protected Object perform() throws Exception {
    if ((getCondition() == null) || (getCondition().getClassCondition() == null))
      return CmdbLinkFactory.createLinks();

    return performQueryCondition();
  }

  protected Object getResult(CmdbDalResultSet resultSet) throws SQLException {
    return buildCmdbLinks(resultSet);
  }

  private CmdbLinks buildCmdbLinks(CmdbDalResultSet resultSet) throws SQLException
  {
    int maxResults = getLocalEnvironment().getSettingsReader().getInt("dal.link.condition.max.result.size", 500000);
    int currentResultCount = 0;

    CmdbLinks cmdbLinks = CmdbLinkFactory.createLinks();
    while (resultSet.next())
    {
      ++currentResultCount;
      if (currentResultCount > maxResults) {
        String errMsg = "Number of Link condition results exceeded the maximum allowed (max allowed value is: " + maxResults + ")";
        throw new CmdbDalException(errMsg);
      }

      byte[] linkIdAsBytes = resultSet.getBytes(1);
      CmdbLinkID linkID = restoreLinkID(linkIdAsBytes);

      byte[] end1IdAsBytes = resultSet.getBytes(2);
      CmdbObjectID end1Id = restoreObjectID(end1IdAsBytes);

      byte[] end2IdAsBytes = resultSet.getBytes(3);
      CmdbObjectID end2Id = restoreObjectID(end2IdAsBytes);

      String type = resultSet.getString(4);

      cmdbLinks.add(CmdbLinkFactory.createLink(linkID, end1Id, end2Id, type));
    }
    return cmdbLinks;
  }

  protected CmdbIDsCollection<? extends CmdbDataID> extractConditionIDs(Object modelElements, ElementCondition condition) {
    if ((condition.getIdsCondition() != null) && (!(isEmptyContainer(condition.getIdsCondition().getLinkIds()))))
      return condition.getIdsCondition().getLinkIds();

    return CmdbLinkIdsFactory.create();
  }

  protected void addSelectSql(StringBuffer conditionSql, Set<String> participatedClasses, List<Object> bindVariables, List<CmdbType> bindVariablesTypes)
  {
    StringBuffer selectSql = new StringBuffer();
    String conditionClassName = getCondition().getClassCondition().getClassName();
    selectSql.append("SELECT ").append(getDummyClassName(conditionClassName, getClassNameSuffix())).append(".");
    selectSql.append("CMDB_ID");
    selectSql.append(", ");
    selectSql.append(getDummyClassName("link", getClassNameSuffix())).append(".").append("END1_ID");
    selectSql.append(", ");
    selectSql.append(getDummyClassName("link", getClassNameSuffix())).append(".").append("END2_ID");
    selectSql.append(", ");
    selectSql.append(getDummyClassName("link", getClassNameSuffix())).append(".").append("CLASS");

    participatedClasses.add(getDummyClassName("link", getClassNameSuffix()));
    participatedClasses.add(getDummyClassName(conditionClassName, getClassNameSuffix()));

    addFromSql(selectSql, participatedClasses);

    selectSql.append(" WHERE ");
    selectSql.append("1=1");

    addAllowedLinksTypeRestriction(selectSql);

    addPairsJoinSql(selectSql, participatedClasses, bindVariables, bindVariablesTypes);

    conditionSql.insert(0, selectSql);
  }

  private void addAllowedLinksTypeRestriction(StringBuffer selectSql)
  {
    if (((LinkCondition)getCondition()).getAllowedLinksType() == 0)
      return;

    selectSql.append(" AND ");
    selectSql.append(getDummyClassName("link", getClassNameSuffix())).append(".").append("END1_ID");
    if (((LinkCondition)getCondition()).getAllowedLinksType() == 1)
      selectSql.append("!=");
    else
      selectSql.append("=");

    selectSql.append(getDummyClassName("link", getClassNameSuffix())).append(".").append("END2_ID");
  }
}