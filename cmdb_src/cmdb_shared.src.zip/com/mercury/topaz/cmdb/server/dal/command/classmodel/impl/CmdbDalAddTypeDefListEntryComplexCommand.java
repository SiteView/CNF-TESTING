package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import java.sql.SQLException;

public class CmdbDalAddTypeDefListEntryComplexCommand extends CmdbDalAbstractTypeDefComplexCommand
{
  private CmdbList _cmdbList = null;
  private CmdbListEntry _listEntry = null;
  private Long _cmdbListId = null;
  private Integer _enumIndex = null;

  public CmdbDalAddTypeDefListEntryComplexCommand(CmdbListEntry listEntry, CmdbList cmdbList, Integer enumIndex, Long cmdbListId)
  {
    setCmdbList(cmdbList);
    setListEntry(listEntry);
    setCmdbListId(cmdbListId);
    setEnumIndex(enumIndex);
  }

  protected void validateInput() {
    if ((getCmdbList() == null) || (getListEntry() == null))
      throw new CmdbDalException("Can't add list entry. Null list or null list entry !!!");
  }

  protected Object perform() throws Exception
  {
    addListEntry(getConnection(), getCmdbList(), getCmdbListId());
    return null;
  }

  private void addListEntry(CmdbDalConnection connection, CmdbList typeDefList, Long typeDefID)
    throws SQLException
  {
    Long uniqueID = null;
    int enumIndex = getEnumIndex().intValue();

    String sqlString = createInsertTypeDefEnumTableSql();
    CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);
    CmdbType valueType = typeDefList.getType();

    CmdbListEntry listEntry = getListEntry();

    preparedStatement.setLong(typeDefID);
    String enumValueString = (listEntry.getListValue() == null) ? null : valueType.stringValue(listEntry.getListValue());
    preparedStatement.setString(enumValueString);
    preparedStatement.setInt(null);
    uniqueID = generateAndConfirmSequenceID();
    preparedStatement.setLong(uniqueID);
    preparedStatement.setBoolean(listEntry.isCreatedByFactory());
    preparedStatement.setBoolean(listEntry.isModifiedByUser());
    preparedStatement.setInt(enumIndex);

    preparedStatement.executeUpdate();
    preparedStatement.close();
  }

  private CmdbList getCmdbList() {
    return this._cmdbList;
  }

  private void setCmdbList(CmdbList cmdbList) {
    this._cmdbList = cmdbList;
  }

  private CmdbListEntry getListEntry() {
    return this._listEntry;
  }

  private void setListEntry(CmdbListEntry listEntry) {
    this._listEntry = listEntry;
  }

  private Long getCmdbListId() throws SQLException {
    Long typeDefId = this._cmdbListId;
    if (typeDefId == null) {
      typeDefId = getTypeDefID(getConnection(), getCmdbList());
      setCmdbListId(typeDefId);
    }
    return this._cmdbListId;
  }

  private void setCmdbListId(Long cmdbListId) {
    this._cmdbListId = cmdbListId;
  }

  private Integer getEnumIndex() throws SQLException {
    Integer enumIndex = this._enumIndex;

    if (enumIndex == null) {
      int lastOrderingIndex = getLastOrderingIndex("ENUM_INDEX", "CCM_TDEF_ENUM", "TYPE_DEF_ID", getCmdbListId());
      enumIndex = new Integer(lastOrderingIndex + 1);
      setEnumIndex(enumIndex);
    }
    return enumIndex;
  }

  private void setEnumIndex(Integer enumIndex) {
    this._enumIndex = enumIndex;
  }
}