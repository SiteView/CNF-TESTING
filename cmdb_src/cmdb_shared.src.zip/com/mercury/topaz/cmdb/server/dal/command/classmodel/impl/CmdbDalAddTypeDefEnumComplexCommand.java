package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnumEntry;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class CmdbDalAddTypeDefEnumComplexCommand extends CmdbDalAddTypeDefComplexCommand
{
  public CmdbDalAddTypeDefEnumComplexCommand(CmdbEnum cmdbEnum)
  {
    super(cmdbEnum);
  }

  protected void updateTypeDefInTables(Long typeDefID) {
    add2TypeDefEnumTable(getEnum(), typeDefID);
  }

  private void add2TypeDefEnumTable(CmdbEnum typeDefEnum, Long typeDefID)
  {
    int enumIndex = 0;

    ReadOnlyIterator enumerationsIter = typeDefEnum.getEnumerators();
    while (enumerationsIter.hasNext()) {
      CmdbEnumEntry enumEntry = (CmdbEnumEntry)enumerationsIter.next();

      ++enumIndex;
      CmdbDalCommand addEnumEntryCommand = CmdbDalClassModelCommandFactory.createAddTypeDefEnumEntryComplexCommand(enumEntry, typeDefEnum, new Integer(enumIndex), typeDefID);
      addEnumEntryCommand.execute();
    }
  }

  protected String getValueType() {
    return getEnum().getType().getName();
  }

  protected String getTypeDefType() {
    return "ENUM";
  }

  private CmdbEnum getEnum() {
    return ((CmdbEnum)getTypeDef());
  }
}