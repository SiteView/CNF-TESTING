package com.mercury.topaz.cmdb.server.dal.command.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CmdbDalGetTableMetaDataSimpleCommand extends CmdbDalAbstractCommand<List<String>>
{
  private String _tableName = null;

  public CmdbDalGetTableMetaDataSimpleCommand(String tableName)
  {
    setTableName(tableName);
  }

  protected void validateInput() {
    if ((getTableName() == null) || (getTableName().length() == 0))
      throw new CmdbDalException("Can't get table meta data for table [" + getTableName() + "]");
  }

  protected List<String> perform() throws Exception
  {
    return getTableColumns();
  }

  private List<String> getTableColumns() throws SQLException {
    String sqlString;
    List columnsNames = new ArrayList();

    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;

    if (isOracle())
      sqlString = "SELECT COLUMN_NAME FROM USER_TAB_COLUMNS WHERE TABLE_NAME=?";
    else if (isMsSql())
      sqlString = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME=?";
    else
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");

    try
    {
      preparedStatement = getConnection().prepareStatement4Select(sqlString);
      preparedStatement.setString(getTableName());
      resultSet = preparedStatement.executeQuery();

      while (resultSet.next()) {
        columnsNames.add(resultSet.getString(1));
      }

      List localList1 = columnsNames;

      return localList1;
    }
    finally
    {
      if (resultSet != null)
        resultSet.close();

      if (preparedStatement != null)
        preparedStatement.close();
    }
  }

  private String getTableName()
  {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    this._tableName = tableName;
  }
}