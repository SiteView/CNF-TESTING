package com.mercury.topaz.cmdb.server.dal.command.datamodel.impl;

import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.environment.subsystem.impl.DalCmdbSubsystemEnvironment;
import com.mercury.topaz.cmdb.server.model.graph.ModelGraph;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrappers;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbUnresolvedDataIDs;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternLinkJoinfParameter;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import java.util.Set;

public class CmdbDalDataModelCommandFactory extends CmdbDalCommandFactory
{
  public static CmdbDalCommand createAddLinksComplexCommand(CmdbLinks links)
  {
    DalCmdbSubsystemEnvironment dalSubsystemEnvironment = (DalCmdbSubsystemEnvironment)ServerApiFacade.getLocalEnvironment().getSubsystemEnvironment(FrameworkConstants.Subsystem.DAL);

    if (dalSubsystemEnvironment.isDisableCoarseGrainElementsInsert())
      return new CmdbDalAddLinksFineGrainComplexCommand(links);

    return new CmdbDalAddLinksComplexCommand(links);
  }

  public static CmdbDalCommand createAddObjectsComplexCommand(CmdbObjects objects)
  {
    DalCmdbSubsystemEnvironment dalSubsystemEnvironment = (DalCmdbSubsystemEnvironment)ServerApiFacade.getLocalEnvironment().getSubsystemEnvironment(FrameworkConstants.Subsystem.DAL);

    if (dalSubsystemEnvironment.isDisableCoarseGrainElementsInsert())
      return new CmdbDalAddObjectsFineGrainComplexCommand(objects);

    return new CmdbDalAddObjectsComplexCommand(objects);
  }

  public static CmdbDalCommand createRemoveLinksComplexCommand(CmdbLinks links)
  {
    return new CmdbDalRemoveLinksComplexCommand(links);
  }

  public static CmdbDalCommand createRemoveObjectsComplexCommand(CmdbObjects objects) {
    return new CmdbDalRemoveObjectsComplexCommand(objects);
  }

  public static CmdbDalCommand createUpdateElementsWithClassPropertiesAndNotUpdateTimeComplexCommand(CmdbIDsCollection<? extends CmdbDataID> idsCollection, CmdbProperties properties, String className) {
    return new CmdbDalUpdateElementsWithClassPropertiesAndNotUpdateTimeComplexCommand(idsCollection, properties, className);
  }

  public static CmdbDalCommand createUpdateLinksComplexCommand(CmdbLinks links) {
    DalCmdbSubsystemEnvironment dalSubsystemEnvironment = (DalCmdbSubsystemEnvironment)ServerApiFacade.getLocalEnvironment().getSubsystemEnvironment(FrameworkConstants.Subsystem.DAL);

    if (dalSubsystemEnvironment.isDisableCoarseGrainElementsInsert())
      return new CmdbDalUpdateLinksFineGrainComplexCommand(links);

    return new CmdbDalUpdateLinksComplexCommand(links);
  }

  public static CmdbDalCommand createUpdateObjectsComplexCommand(CmdbObjects objects)
  {
    DalCmdbSubsystemEnvironment dalSubsystemEnvironment = (DalCmdbSubsystemEnvironment)ServerApiFacade.getLocalEnvironment().getSubsystemEnvironment(FrameworkConstants.Subsystem.DAL);

    if (dalSubsystemEnvironment.isDisableCoarseGrainElementsInsert())
      return new CmdbDalUpdateObjectsFineGrainComplexCommand(objects);

    return new CmdbDalUpdateObjectsComplexCommand(objects);
  }

  public static CmdbDalCommand createGetLinksLayoutComplexCommand(ModelLinks links, ElementSimpleLayout layout)
  {
    return new CmdbDalGetLinksLayoutComplexCommand(links, layout);
  }

  public static CmdbDalCommand createGetObjectsLayoutComplexCommand(ModelObjects objects, ElementSimpleLayout layout) {
    return new CmdbDalGetObjectsLayoutComplexCommand(objects, layout);
  }

  public static CmdbDalCommand<ModelGraph> createLoadModelGraphComplexCommand(Set<String> nonResidentClasses) {
    if (nonResidentClasses.isEmpty())
      return new CmdbDalLoadModelGraphComplexCommand();

    return new CmdbDalLoadResidentModelGraphComplexCommand(nonResidentClasses);
  }

  public static CmdbDalCommand<CmdbGraph> createLoadCmdbGraphComplexCommand()
  {
    return new CmdbDalLoadCmdbGraphComplexCommand();
  }

  public static CmdbDalCommand createGetObjectsByConditionComplexCommand(ModelObjects objects, ElementCondition condition) {
    return new CmdbDalObjectsConditionComplexCommand(condition, objects);
  }

  public static CmdbDalCommand createGetLinksByConditionComplexCommand(ModelLinks links, LinkCondition linkCondition) {
    return new CmdbDalLinksConditionComplexCommand(linkCondition, links);
  }

  public static CmdbDalCommand createGetTriplesComplexCommand(ElementCondition end1Condition, LinkCondition linkCondition, ElementCondition end2Condition) {
    return new CmdbDalGetTriplesComplexCommand(end1Condition, linkCondition, end2Condition);
  }

  public static CmdbDalCommand createGetLinksOfObjectsComplexCommand(ElementCondition elementCondition, LinkCondition linkCondition) {
    return new CmdbDalGetLinksOfObjectsComplexCommand(elementCondition, linkCondition);
  }

  public static CmdbDalCommand createJoinfComplexCommand(ElementCondition srcCondition, ElementCondition dstCondition, ModelObjects srcObjects, ModelObjects dstObjects, PatternLinkJoinfParameter joinfLinkParameter, LinkCondition linkCondition) {
    return new CmdbDalJoinfComplexCommand(srcCondition, dstCondition, srcObjects, dstObjects, joinfLinkParameter, linkCondition);
  }

  public static CmdbDalCommand createCountClassInstancesComplexCommand(String fullQualifedClassName, boolean includeDerived) {
    return new CmdbDalCountClassInstancesComplexCommand(fullQualifedClassName, includeDerived);
  }

  public static CmdbDalCommand createCountClassesInstancesComplexCommand() {
    return new CmdbDalCountClassesInstancesComplexCommand();
  }

  public static CmdbDalCommand createGetCmdbObjectsNoPropertiesComplexCommand(ElementCondition condition) {
    return new CmdbDalObjectsConditionGetCmdbObjectsNoModelObjectsComplexCommand(condition);
  }

  public static CmdbDalCommand createGetCmdbLinksNoPropertiesComplexCommand(LinkCondition linkCondition) {
    return new CmdbDalLinksConditionGetCmdbLinksNoModelLinksComplexCommand(linkCondition);
  }

  public static CmdbDalCommand createGetFunctionsLayoutComplexCommand(ModelObjects groupByObjects, ModelLinks modelLinks, ModelObjects aggregatedObjects, LayoutFunctionWrappers layoutFunctionWrappers) {
    return new CmdbDalGetFunctionsLayoutComplexCommand(groupByObjects, modelLinks, aggregatedObjects, layoutFunctionWrappers);
  }

  public static CmdbDalCommand createSortObjectsComplexCommand(ModelObjects modelObjects, CmdbSortCommand sortCommand) {
    return new CmdbDalSortObjectsComplexCommand(modelObjects, sortCommand);
  }

  public static CmdbDalCommand createSortObjectsComplexCommand(ElementCondition elementCondition, CmdbSortCommand sortCommand) {
    return new CmdbDalSortObjectsByConditionComplexCommand(elementCondition, sortCommand);
  }

  public static CmdbDalCommand createSortLinksComplexCommand(ModelLinks modelLinks, CmdbSortCommand sortCommand) {
    return new CmdbDalSortLinksComplexCommand(modelLinks, sortCommand);
  }

  public static CmdbDalCommand createGroupClassByAttributeComplexCommand(ElementCondition elementCondition, ModelObjects modelObjects, String attributeName) {
    return new CmdbDalGroupClassByAttributeComplexCommand(elementCondition, modelObjects, attributeName);
  }

  public static CmdbDalCommand createResolveCmdbIDsCommand(CmdbUnresolvedDataIDs unresolvedDataIDs) {
    return new CmdbDalResolveCmdbIDs(unresolvedDataIDs);
  }

  public static CmdbDalCommand createGetRecursiveDeleteSurvivorObjectsCommand(CmdbLinks dependedEnd1Links, CmdbLinks dependedEnd2Links, CmdbLinkIds alreadyDeletedLinks) {
    return new CmdbDalGetRecursiveDeleteSurvivorObjects(dependedEnd1Links, dependedEnd2Links, alreadyDeletedLinks);
  }
}