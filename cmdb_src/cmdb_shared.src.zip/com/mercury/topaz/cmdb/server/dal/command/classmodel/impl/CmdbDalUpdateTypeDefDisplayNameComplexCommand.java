package com.mercury.topaz.cmdb.server.dal.command.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import java.sql.SQLException;

public class CmdbDalUpdateTypeDefDisplayNameComplexCommand extends CmdbDalUpdateTypeDefPropertyComplexCommand
{
  public CmdbDalUpdateTypeDefDisplayNameComplexCommand(CmdbTypeDef typeDef)
  {
    super(typeDef);
  }

  protected String getColumnNameToUpdate() {
    return "DISPLAY_NAME";
  }

  protected void setValuesToPreparedStatement(CmdbDalPreparedStatement preparedStatement, Long typeDefId) throws SQLException {
    preparedStatement.setString(getTypeDef().getDisplayName());
    preparedStatement.setBoolean(getTypeDef().isModifiedByUser());
    preparedStatement.setLong(typeDefId);
  }

  protected String getCommandName() {
    return "Update display name of type def [" + getTypeDef().getName() + "] to [" + getTypeDef().getDisplayName() + "]";
  }
}