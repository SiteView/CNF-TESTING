package com.mercury.topaz.cmdb.server.base.jmx.systemhealth;

import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.SHMonitorCustomer;
import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.SHMonitorCustomerFactory;
import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.SHMonitorMeasurement;
import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.SHMonitorMeasurementFactory;
import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.SHMonitorObj;
import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.SHMonitorObjFactory;
import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.SHMonitorValues;
import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.SHMonitorValuesFactory;
import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.enums.Availability;
import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.enums.Status;
import com.mercury.am.systemhealth.monitor.client.monitordataloader.dataobjects.enums.Units;
import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.server.monitor.CmdbMonitorStatistics;
import com.mercury.topaz.cmdb.server.monitors.CmdbMonitor;
import com.mercury.topaz.cmdb.server.monitors.info.impl.CustomerPatternsMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.info.impl.FailedTqlsMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.info.impl.PatternResultInfo;
import com.mercury.topaz.cmdb.server.monitors.info.impl.PatternResultMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.info.impl.QuotaMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.info.impl.StatisticsMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.metadata.CmdbMultiThresholdMonitorMetaData;
import com.mercury.topaz.cmdb.server.monitors.metadata.CmdbThresholdMonitorMetaData;
import com.mercury.topaz.cmdb.server.monitors.operation.query.impl.MonitorsQueryReadMonitorOperation;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.API;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl.CmdbCustomerQueryGetLoadedCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import com.mercury.topaz.cmdb.shared.monitor.action.MeasuredActionResult;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=System Health Services", description="CMDB System Health Services")
public class SystemHealthJmxServices extends AbstractCmdbJmx
  implements SystemHealthJmxServicesInterface
{
  public static final String FAILED_TQLS = "tql.failed";
  public static final String TQL_COUNT_MONITOR = "tql.count.monitor";
  public static final String OBJECTS_COUNT_MONITOR = "objects.count.monitor";
  public static final String TQL_RESULT_COUNT_MONITOR = "tql.result.count.monitor";
  public static final String PERFORMANCE_MONITOR = "performance.monitor";

  private String getTQLCountMonitorData()
  {
    MonitorsQueryReadMonitorOperation monitorsQueryReadMonitorOperation = new MonitorsQueryReadMonitorOperation("TQL Quota and Count");

    invokeOperation(monitorsQueryReadMonitorOperation, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    CmdbMonitor monitor = monitorsQueryReadMonitorOperation.getMonitor();

    SHMonitorObj shMonitorObj = SHMonitorObjFactory.create();
    shMonitorObj.setMonitorName("TQL Quota and Count");
    shMonitorObj.setDescription("Compares the tqls current count with the tqls quota.");
    shMonitorObj.setMonitorAvailability(Availability.FALSE);

    setQuotaInfo(monitor, "quota.name.server.tql.active", "quota.name.customer.tql.active", shMonitorObj, Units.TQL);

    return shMonitorObj.toXML();
  }

  private void setQuotaInfo(CmdbMonitor monitor, String quotaServerName, String quotaCustomerName, SHMonitorObj shMonitorObj, Units units)
  {
    Status status = Status.GOOD;
    CmdbThresholdMonitorMetaData monitorMetaData = (CmdbThresholdMonitorMetaData)monitor.getMonitorMetaData();
    QuotaMonitorInfo quotaMonitorInfo = (QuotaMonitorInfo)monitor.getMonitorInfo();

    Map customersQuotasAndCounts = quotaMonitorInfo.getCustomersQuotasAndCountsClone();

    Map serverQuotasAndCounts = quotaMonitorInfo.getServerQuotasAndCountsClone();
    QuotaCount serverQuotaCount = (QuotaCount)serverQuotasAndCounts.get(quotaServerName);
    if ((customersQuotasAndCounts.isEmpty()) || (serverQuotasAndCounts.isEmpty())) {
      shMonitorObj.setMonitorStatus(Status.GOOD);
      shMonitorObj.setMonitorDetails("The requested information is missing. Monitor is not available.");
      return;
    }
    SHMonitorValues shMonitorValues = SHMonitorValuesFactory.create();
    shMonitorValues.setLimitVal(serverQuotaCount.getQuota());
    shMonitorValues.setCurrentVal(serverQuotaCount.getCount());
    shMonitorValues.setUnits(units);
    if (shMonitorValues.getLimitVal() != 0D)
      shMonitorValues.setPercentVal(shMonitorValues.getCurrentVal() / shMonitorValues.getLimitVal() * 100.0D);
    else {
      shMonitorValues.setPercentVal(100.0D);
    }

    if (shMonitorValues.getPercentVal() >= monitorMetaData.getErrorLevel()) {
      status = Status.ERROR;
    }
    else if ((((shMonitorValues.getPercentVal() >= monitorMetaData.getWarningLevel()) ? 1 : 0) & ((status.compareTo(Status.WARN) <= 0) ? 1 : 0)) != 0) {
      status = Status.WARN;
    }

    Set customersID = customersQuotasAndCounts.keySet();

    List customersValues = new ArrayList();

    for (Iterator i$ = customersID.iterator(); i$.hasNext(); ) { CmdbCustomerID customerID = (CmdbCustomerID)i$.next();
      SHMonitorCustomer shMonitorCustomer = SHMonitorCustomerFactory.create();
      shMonitorCustomer.setCustID(customerID.getID());
      CustomerQuotasAndCounts customerQuotasAndCounts = (CustomerQuotasAndCounts)customersQuotasAndCounts.get(customerID);
      shMonitorCustomer.setCustLimitVal(customerQuotasAndCounts.getQuotaCount(quotaCustomerName).getQuota());
      shMonitorCustomer.setCustCurrentVal(customerQuotasAndCounts.getQuotaCount(quotaCustomerName).getCount());
      shMonitorCustomer.setUnits(units);
      if (shMonitorCustomer.getCustLimitVal() != 0D) {
        shMonitorCustomer.setCustPercentVal(shMonitorCustomer.getCustCurrentVal() / shMonitorCustomer.getCustLimitVal() * 100.0D);
      }
      else
        shMonitorCustomer.setCustPercentVal(100.0D);

      shMonitorCustomer.setCustStatus(Status.GOOD);
      if (shMonitorCustomer.getCustPercentVal() >= monitorMetaData.getErrorLevel()) {
        shMonitorCustomer.setCustStatus(Status.ERROR);
        status = Status.ERROR;
      } else if (shMonitorCustomer.getCustPercentVal() >= monitorMetaData.getWarningLevel()) {
        shMonitorCustomer.setCustStatus(Status.WARN);
        if (status.compareTo(Status.WARN) <= 0)
          status = Status.WARN;
      }

      customersValues.add(shMonitorCustomer);
    }

    shMonitorValues.setCustomers(customersValues);
    shMonitorObj.setMonitorValues(shMonitorValues);
    shMonitorObj.setMonitorStatus(status);
  }

  private String getCICountMonitorData() {
    MonitorsQueryReadMonitorOperation monitorsQueryReadMonitorOperation = new MonitorsQueryReadMonitorOperation("Model Objects Quota and Count");

    invokeOperation(monitorsQueryReadMonitorOperation, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    CmdbMonitor monitor = monitorsQueryReadMonitorOperation.getMonitor();

    SHMonitorObj shMonitorObj = SHMonitorObjFactory.create();
    shMonitorObj.setMonitorName("Model Objects Quota and Count");
    shMonitorObj.setDescription("Compares the model objects current count with the model objects quota.");
    shMonitorObj.setMonitorAvailability(Availability.FALSE);

    setQuotaInfo(monitor, "quota.name.server.model.objects", "quota.name.customer.model.objects", shMonitorObj, Units.OBJECT);

    return shMonitorObj.toXML();
  }

  private void setCustTQLResultCount(SHMonitorObj shMonitorObj, Integer customerID, PatternResultMonitorInfo monitorInfo, CmdbThresholdMonitorMetaData monitorMetaData)
  {
    SHMonitorCustomer shMonitorCustomer = SHMonitorCustomerFactory.create();
    shMonitorCustomer.setCustID(customerID.intValue());
    shMonitorCustomer.setCustStatus(Status.GOOD);
    StringBuffer problematicTQLs = new StringBuffer(" The following TQLs results exceeded the max result: ");
    StringBuffer warnTQLs = new StringBuffer(" The following TQLs results capacity is higher than " + monitorMetaData.getWarningLevel() + "% : ");

    boolean isError = false;
    boolean isWarn = false;

    long totalOversizeTql = 0L;

    CustomerPatternsMonitorInfo customersInfo = monitorInfo.getCustomerPatternsInfo(createCustomerID(customerID));
    if (customersInfo != null) {
      for (Iterator i$ = customersInfo.getPatternsInfo().values().iterator(); i$.hasNext(); ) { PatternResultInfo pattern = (PatternResultInfo)i$.next();

        long resultSize = pattern.getResultSize();

        int maxResultSize = customersInfo.getGroupSize(pattern.getGroupID());

        if (((maxResultSize == 0) && (resultSize != 0L)) || ((resultSize != 0L) && (resultSize / maxResultSize >= monitorMetaData.getErrorLevel()))) {
          problematicTQLs.append(pattern.getName());
          problematicTQLs.append(", ");
          isError = true;
          totalOversizeTql += 1L;
        } else if ((maxResultSize != 0) && (resultSize / maxResultSize > monitorMetaData.getWarningLevel())) {
          warnTQLs.append(pattern.getName());
          warnTQLs.append(", ");
          isWarn = true;
          totalOversizeTql += 1L;
        }
      }

      if (isError) {
        shMonitorCustomer.setCustStatus(Status.ERROR);
        shMonitorObj.setMonitorStatus(Status.ERROR);
      } else if (isWarn) {
        shMonitorCustomer.setCustStatus(Status.WARN);
        if (shMonitorObj.getMonitorStatus().compareTo(Status.WARN) <= 0)
          shMonitorObj.setMonitorStatus(Status.WARN);
      }

    }

    String result = (isError) ? problematicTQLs.substring(0, problematicTQLs.length() - 2) + " " : "";
    result = result + ((isWarn) ? warnTQLs.substring(0, warnTQLs.length() - 2) : "");
    if (result.length() == 0) {
      result = "There are no problematic TQLs";
    }

    shMonitorCustomer.setCustDetails(result);
    shMonitorObj.getMonitorValues().getCustomers().add(shMonitorCustomer);
    shMonitorObj.getMonitorValues().setCurrentVal(shMonitorObj.getMonitorValues().getCurrentVal() + totalOversizeTql);
  }

  private String getTQLResultCountMonitorData(boolean isMMS)
  {
    SHMonitorObj shMonitorObj = SHMonitorObjFactory.create();
    shMonitorObj.setMonitorName("Oversized TQLs");
    shMonitorObj.setDescription("Finds tqls that are oversized. If find at least one oversized tql the monitor fails.");
    shMonitorObj.setMonitorStatus(Status.GOOD);
    shMonitorObj.setMonitorValues(SHMonitorValuesFactory.create());
    shMonitorObj.getMonitorValues().setCurrentVal(0D);
    shMonitorObj.getMonitorValues().setUnits(Units.TQL);
    shMonitorObj.getMonitorValues().setCustomers(new ArrayList());

    List customersIds = getCustomers();
    MonitorsQueryReadMonitorOperation monitorsQueryReadMonitorOperation = new MonitorsQueryReadMonitorOperation("Oversized TQLs");

    invokeOperation(monitorsQueryReadMonitorOperation, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    CmdbMonitor monitor = monitorsQueryReadMonitorOperation.getMonitor();
    PatternResultMonitorInfo monitorInfo = (PatternResultMonitorInfo)monitor.getMonitorInfo();
    CmdbThresholdMonitorMetaData monitorMetaData = (CmdbThresholdMonitorMetaData)monitor.getMonitorMetaData();
    for (Iterator i$ = customersIds.iterator(); i$.hasNext(); ) { Integer customerId = (Integer)i$.next();
      setCustTQLResultCount(shMonitorObj, customerId, monitorInfo, monitorMetaData);
    }

    if ((!(isMMS)) && 
      (customersIds.size() > 0)) {
      SHMonitorCustomer shMonitorCustomer = (SHMonitorCustomer)shMonitorObj.getMonitorValues().getCustomers().get(0);
      shMonitorObj.setMonitorDetails(shMonitorCustomer.getCustDetails());
    }

    return shMonitorObj.toXML();
  }

  private String getFailedTQLsMonitorData(boolean isMMS) {
    SHMonitorObj shMonitorObj = SHMonitorObjFactory.create();
    shMonitorObj.setMonitorName("Failed TQLs");
    shMonitorObj.setDescription("Finds tqls that are failed. If finds one or more failed tqls, the monitor warns.");

    shMonitorObj.setMonitorStatus(Status.GOOD);
    shMonitorObj.setMonitorValues(SHMonitorValuesFactory.create());
    shMonitorObj.getMonitorValues().setCurrentVal(0D);
    shMonitorObj.getMonitorValues().setUnits(Units.TQL);
    shMonitorObj.getMonitorValues().setCustomers(new ArrayList());

    MonitorsQueryReadMonitorOperation monitorsQueryReadMonitorOperation = new MonitorsQueryReadMonitorOperation("Failed TQLs");

    invokeOperation(monitorsQueryReadMonitorOperation, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    CmdbMonitor monitor = monitorsQueryReadMonitorOperation.getMonitor();
    FailedTqlsMonitorInfo monitorInfo = (FailedTqlsMonitorInfo)monitor.getMonitorInfo();

    CmdbCustomerIDs customersIds = getCustomersCmdbIds();
    ReadOnlyIterator customersIdsIterator = customersIds.getCustomerIdsIterator();
    while (customersIdsIterator.hasNext()) {
      setCustFailedTqls(shMonitorObj, (CmdbCustomerID)customersIdsIterator.next(), monitorInfo);
    }

    if ((!(isMMS)) && 
      (customersIds.size() > 0)) {
      SHMonitorCustomer shMonitorCustomer = (SHMonitorCustomer)shMonitorObj.getMonitorValues().getCustomers().get(0);
      shMonitorObj.setMonitorDetails(shMonitorCustomer.getCustDetails());
    }

    return shMonitorObj.toXML();
  }

  private void setCustFailedTqls(SHMonitorObj shMonitorObj, CmdbCustomerID customerID, FailedTqlsMonitorInfo monitorInfo)
  {
    String problematicTQLs;
    SHMonitorCustomer shMonitorCustomer = SHMonitorCustomerFactory.create();
    shMonitorCustomer.setCustID(customerID.getID());
    Collection failedTqlsForCustomer = monitorInfo.getCustomerFailedTqlsInfo(customerID);

    if (failedTqlsForCustomer != null) {
      if (failedTqlsForCustomer.size() == 0) {
        shMonitorCustomer.setCustStatus(Status.GOOD);
        problematicTQLs = "No failed tqls for customer";
      } else {
        shMonitorObj.setMonitorStatus(Status.WARN);
        shMonitorCustomer.setCustStatus(Status.WARN);
        problematicTQLs = "The following TQLs are failed: ";
        for (Iterator i$ = failedTqlsForCustomer.iterator(); i$.hasNext(); ) { String failedTqlForCustomer = (String)i$.next();
          problematicTQLs = problematicTQLs + failedTqlForCustomer;
          problematicTQLs = problematicTQLs + ", ";
        }
        problematicTQLs = problematicTQLs.substring(0, problematicTQLs.length() - 2);
      }
      shMonitorObj.getMonitorValues().setCurrentVal(shMonitorObj.getMonitorValues().getCurrentVal() + failedTqlsForCustomer.size());
    }
    else {
      shMonitorCustomer.setCustStatus(Status.NA);
      problematicTQLs = "No Information for customer";
    }

    shMonitorCustomer.setCustDetails(problematicTQLs);
    shMonitorObj.getMonitorValues().getCustomers().add(shMonitorCustomer);
  }

  private void setCustPerformanceStatus(Integer customerID, StatisticsMonitorInfo monitorInfo, CmdbMultiThresholdMonitorMetaData monitorMetaData, Map<String, SHMonitorMeasurement> mesurements)
  {
    CmdbMonitorStatistics statistics = monitorInfo.getCustomerStatisticsInfo(createCustomerID(customerID));
    if ((statistics != null) && 
      (statistics.getExecutionResults().size() > 0))
    {
      Map times = statistics.getExecutionResults();
      Iterator it = times.keySet().iterator();
      while (it.hasNext()) {
        String key = (String)it.next();
        MeasuredActionResult actionResult = (MeasuredActionResult)times.get(key);
        if (!(mesurements.containsKey(key))) {
          SHMonitorMeasurement newMeasurement = SHMonitorMeasurementFactory.create();
          newMeasurement.setMeasName(actionResult.getDescription());
          newMeasurement.setMeasDescription("Check response time of " + actionResult.getDescription() + " action.");

          newMeasurement.setUnits(Units.MILLISECOND);
          newMeasurement.setCustomers(new ArrayList());
          newMeasurement.setMeasStatus(Status.GOOD);
          mesurements.put(key, newMeasurement);
        }
        SHMonitorCustomer customerMeasurement = SHMonitorCustomerFactory.create();
        customerMeasurement.setCustID(customerID.intValue());

        long executionTime = actionResult.getExecutionTime();
        if (!(actionResult.isTimedout())) {
          customerMeasurement.setCustDetails(actionResult.getDescription() + " action took " + actionResult.getExecutionTime() + " milliseconds to run.");

          customerMeasurement.setCustCurrentVal(executionTime);
          customerMeasurement.setUnits(Units.MILLISECOND);
          customerMeasurement.setCustStatus(Status.INFO);
          double warningTime = monitorMetaData.getWarningLevel(key);
          double errorTime = monitorMetaData.getErrorLevel(key);
          customerMeasurement.setCustLimitVal(errorTime);
          if (executionTime < warningTime) {
            customerMeasurement.setCustStatus(Status.GOOD);
          } else if (executionTime < errorTime) {
            customerMeasurement.setCustStatus(Status.WARN);
            if (!(((SHMonitorMeasurement)mesurements.get(key)).getMeasStatus().equals(Status.ERROR)))
              ((SHMonitorMeasurement)mesurements.get(key)).setMeasStatus(Status.WARN);
          }
          else {
            customerMeasurement.setCustStatus(Status.ERROR);
            ((SHMonitorMeasurement)mesurements.get(key)).setMeasStatus(Status.ERROR);
          }
        } else {
          customerMeasurement.setCustDetails("Timeout occured");
          customerMeasurement.setCustStatus(Status.ERROR);
          customerMeasurement.setCustDetails("Timeout occured when executing " + actionResult.getDescription() + " action.");
        }

        ((SHMonitorMeasurement)mesurements.get(key)).getCustomers().add(customerMeasurement);
      }
    }
  }

  private String getPerformanceMonitorData(boolean isMMS)
  {
    SHMonitorObj shMonitorObj = SHMonitorObjFactory.create();
    shMonitorObj.setMonitorName("Availability and Performance");
    shMonitorObj.setDescription("Checks system availability, throughput and response time");
    shMonitorObj.setMonitorStatus(Status.GOOD);
    shMonitorObj.setMonitorValues(SHMonitorValuesFactory.create());
    shMonitorObj.getMonitorValues().setCustomers(new ArrayList());
    List customersIds = getCustomers();

    MonitorsQueryReadMonitorOperation monitorsQueryReadMonitorOperation = new MonitorsQueryReadMonitorOperation("Availability and Performance");

    invokeOperation(monitorsQueryReadMonitorOperation, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    CmdbMonitor monitor = monitorsQueryReadMonitorOperation.getMonitor();
    StatisticsMonitorInfo monitorInfo = (StatisticsMonitorInfo)monitor.getMonitorInfo();
    CmdbMultiThresholdMonitorMetaData monitorMetaData = (CmdbMultiThresholdMonitorMetaData)monitor.getMonitorMetaData();

    Iterator customersIdsItr = customersIds.iterator();
    Map measurments = new HashMap();
    while (customersIdsItr.hasNext()) {
      setCustPerformanceStatus((Integer)customersIdsItr.next(), monitorInfo, monitorMetaData, measurments);
    }

    if (measurments.size() > 0)
    {
      shMonitorObj.setMonitorMeasurements(new ArrayList(measurments.size()));
      for (Iterator i$ = measurments.values().iterator(); i$.hasNext(); ) { SHMonitorMeasurement currMeasurement = (SHMonitorMeasurement)i$.next();
        double maxMeasurementTime = 0D;
        for (Iterator i$ = currMeasurement.getCustomers().iterator(); i$.hasNext(); ) { SHMonitorCustomer currCustomer = (SHMonitorCustomer)i$.next();
          if (currCustomer.getCustCurrentVal() > maxMeasurementTime)
            maxMeasurementTime = currCustomer.getCustCurrentVal();
        }

        if (currMeasurement.getCustomers().size() > 1)
          currMeasurement.setMeasDetails("Max response time was " + maxMeasurementTime + " milliseconds.");
        else
          currMeasurement.setMeasDetails("Response time was " + maxMeasurementTime + " milliseconds.");

        if (!(isMMS)) {
          SHMonitorCustomer currCustomer = (SHMonitorCustomer)currMeasurement.getCustomers().get(0);
          currMeasurement.setMeasLimitVal(currCustomer.getCustLimitVal());
          currMeasurement.setMeasVal(currCustomer.getCustCurrentVal());
          currMeasurement.setMeasDetails(currCustomer.getCustDetails());
        }
        shMonitorObj.getMonitorMeasurements().add(currMeasurement);
        if ((currMeasurement.getMeasStatus().equals(Status.WARN)) && (!(shMonitorObj.getMonitorStatus().equals(Status.ERROR))))
        {
          shMonitorObj.setMonitorStatus(Status.WARN);
        } else if (currMeasurement.getMeasStatus().equals(Status.ERROR))
          shMonitorObj.setMonitorStatus(Status.ERROR);
      }
    }

    return shMonitorObj.toXML();
  }

  private List<Integer> getCustomers() {
    CmdbCustomerIDs cmdbCustomerIDs = getCustomersCmdbIds();
    List customerIds = new ArrayList();
    ReadOnlyIterator customerIDsItr = cmdbCustomerIDs.getCustomerIdsIterator();
    while (customerIDsItr.hasNext()) {
      CmdbCustomerID customerID = (CmdbCustomerID)customerIDsItr.next();
      customerIds.add(Integer.valueOf(customerID.getID()));
    }
    return customerIds;
  }

  private CmdbCustomerIDs getCustomersCmdbIds()
  {
    CmdbCustomerQueryGetLoadedCustomerIDs cmdbCustomerQueryGetLoadedCustomerIDs = new CmdbCustomerQueryGetLoadedCustomerIDs("CMDB");

    invokeOperation(cmdbCustomerQueryGetLoadedCustomerIDs, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    return cmdbCustomerQueryGetLoadedCustomerIDs.getCustomerIDs();
  }

  @ManagedOperation(description="Get Monitor Data (friendly)")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="monitorName", description="<script type=\"text/javascript\"> function findFormByElementNameAndValue(name, value) { var forms = document.forms; for (i = 0; i < forms.length; i++) { var form = forms[i]; var elements = form.elements; for (j = 0; j < elements.length; j++) {  if (elements[j].name == name && elements[j].value == value) { return form; } } } return null; } function setMonitorName(monitorName) { var form = findFormByElementNameAndValue('methodIndex', '0'); for (i = 0; i < form.elements.length; i++) { if (form.elements[i].name == 'arg0') { form.elements[i].value = monitorName; break; } } } </script>  <table> <tr><td align=\"center\"> <input type=\"submit\" value=\"objects.count.monitor\" onclick=\"setMonitorName('objects.count.monitor')\"> </td></tr> <tr><td align=\"center\"> <input type=\"submit\" value=\"tql.count.monitor\"onclick=\"setMonitorName('tql.count.monitor')\"> </td></tr> <tr><td align=\"center\"> <input type=\"submit\" value=\"tql.result.count.monitor\"onclick=\"setMonitorName('tql.result.count.monitor')\"> </td></tr> <tr><td align=\"center\"> <input type=\"submit\" value=\"tql.failed\"onclick=\"setMonitorName('tql.failed')\"> </td></tr> <tr><td align=\"center\"> <input type=\"submit\" value=\"performance.monitor\"onclick=\"setMonitorName('performance.monitor')\"> </td></tr> </table>"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="isMMS", description="Is MMS")})
  public String friendlyGetMonitorData(String monitorName, boolean isMMS)
  {
    return XmlUtils.convertStringWithXmlTags(getMonitorData(monitorName, isMMS));
  }

  @ManagedOperation(description="Get Monitor Data - that doesn't show results unless you view the page source ...")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="monitorName", description="monitor name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="isMMS", description="Is MMS")})
  public String getMonitorData(String monitorName, boolean isMMS)
  {
    if (monitorName.equals("tql.failed"))
      return getFailedTQLsMonitorData(isMMS);
    if (monitorName.equals("tql.count.monitor"))
      return getTQLCountMonitorData();
    if (monitorName.equals("tql.result.count.monitor"))
      return getTQLResultCountMonitorData(isMMS);
    if (monitorName.equals("objects.count.monitor"))
      return getCICountMonitorData();
    if (monitorName.equals("performance.monitor"))
      return getPerformanceMonitorData(isMMS);

    return "";
  }
}