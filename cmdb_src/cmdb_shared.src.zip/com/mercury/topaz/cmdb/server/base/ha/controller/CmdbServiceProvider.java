package com.mercury.topaz.cmdb.server.base.ha.controller;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.ControllerServiceProvider;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.impl.ControllerServiceInstance;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChange;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.admin.notificaion.change.CmdbAdminChangeFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;
import com.mercury.topaz.cmdb.shared.notification.operation.command.impl.DeploymentCommandPublishChanges;

public class CmdbServiceProvider extends ControllerServiceProvider
{
  public CmdbServiceProvider()
  {
    super("CMDB");
  }

  public ControllerServiceInstance createServiceInstance(CustomerInstance customerInstance) {
    return new CmdbServiceInstance(customerInstance);
  }

  protected void specificPostStartup(CmdbCustomerID customerID) {
    publishCustomerLoadedMessage(customerID);
  }

  private void publishCustomerLoadedMessage(CmdbCustomerID customerID) {
    CmdbChange customerLoadedChange = CmdbAdminChangeFactory.createCustomerStartedChange();
    DeploymentCommandPublishChanges publishChanges = new DeploymentCommandPublishChanges(FrameworkConstants.Subsystem.CMDB_ADMIN, customerLoadedChange);

    CmdbContext cmdbContext = CmdbContextFactory.createCmdbContext(customerID, "CmdbServiceProvider");
    CmdbApiFactory.createCMDBAPI(CmdbApi.LOCAL_TYPE).executeCMDBOperation(publishChanges, cmdbContext);
  }
}