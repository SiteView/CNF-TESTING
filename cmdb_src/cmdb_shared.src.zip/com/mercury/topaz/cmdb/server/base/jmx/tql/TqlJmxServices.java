package com.mercury.topaz.cmdb.server.base.jmx.tql;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.server.systemtql.datatypes.SystemTqlGeneralData;
import com.mercury.topaz.cmdb.server.systemtql.operation.SystemTqlCacheQueryGetGraphSysTQLs;
import com.mercury.topaz.cmdb.server.systemtql.operation.SystemTqlCacheQueryGetOverallData;
import com.mercury.topaz.cmdb.server.systemtql.operation.SystemTqlCacheQueryGetResultObjectsByStr;
import com.mercury.topaz.cmdb.server.tql.calculator.optimize.persistency.OptimizationPersistencyUtils;
import com.mercury.topaz.cmdb.server.tql.operation.command.impl.TqlCommandConditionCountWakeUp;
import com.mercury.topaz.cmdb.server.tql.operation.command.impl.TqlCommandUpdateTqlsNotToOptimize;
import com.mercury.topaz.cmdb.server.tql.operation.query.impl.TqlQueryGetTqlsNotToOptimize;
import com.mercury.topaz.cmdb.server.tql.scheduler.state.PatternStatisticsInfo;
import com.mercury.topaz.cmdb.server.util.jmx.JMXUtils;
import com.mercury.topaz.cmdb.server.util.time.CmdbTime;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph.Utils;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.PatternState;
import com.mercury.topaz.cmdb.shared.tql.definition.PatternXmlBuilder;
import com.mercury.topaz.cmdb.shared.tql.definition.Patterns;
import com.mercury.topaz.cmdb.shared.tql.definition.Priority.PatternPriorityType;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumbers;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.CmdbPatternIDFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.EmptyPatternElementNumbers;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementTypeLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetNeighborsGraph;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetObjectsAttributesGroupByCount;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetPattern;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetPatterns;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultCount;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultGraph;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultMap;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetSchedulerStatistics;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdatePatternRemove;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdatePatternUpdate;
import com.mercury.topaz.cmdb.shared.tql.result.CmdbAttributeGroupedByCount;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultCount;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.ResultEntry;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultMapUtils;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=CMDB Tql Services", description="CMDB Tql Services")
public class TqlJmxServices extends AbstractCmdbJmx
{
  private static Log _infoLogger = CmdbLogFactory.getCMDBInfoLog();

  @ManagedOperation(description="Activate Tql")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="patternName", description="Pattern name")})
  public String activateTql(Integer customerID, String patternName)
    throws Exception
  {
    setCustomerID(customerID);
    Pattern p = retrievePatternDefinition(customerID, patternName);
    if (p == null)
      return getNotExistMessage(patternName);

    if (p.getState().isActive()) {
      return "The pattern " + patternName + " is already active";
    }

    ModifiablePattern mp = p.toModifiablePattern();
    mp.setState(PatternDefinitionFactory.createPatternState(p.getState().isPresist(), true, p.getState().getPriority(), p.getState().isNotificationOnly()));
    TqlUpdatePatternUpdate update = new TqlUpdatePatternUpdate(mp);
    invokeOperation(update, customerID);
    return "Pattern " + patternName + " activated successfully";
  }

  @ManagedOperation(description="Deactivate Tql")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="patternName", description="Pattern name")})
  public String deactivateTql(Integer customerID, String patternName)
    throws Exception
  {
    setCustomerID(customerID);
    Pattern p = retrievePatternDefinition(customerID, patternName);
    if (p == null)
      return getNotExistMessage(patternName);

    if (!(p.getState().isActive())) {
      return "The pattern " + patternName + " is already not active";
    }

    ModifiablePattern mp = p.toModifiablePattern();
    mp.setState(PatternDefinitionFactory.createPatternState(p.getState().isPresist(), false, p.getState().getPriority(), p.getState().isNotificationOnly()));
    TqlUpdatePatternUpdate update = new TqlUpdatePatternUpdate(mp);
    invokeOperation(update, customerID);
    return "Pattern " + patternName + " deactivated";
  }

  @ManagedOperation(description="Show Tql definition in xml")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="patternName", description="Pattern name")})
  public String exportTql(Integer customerID, String patternName)
    throws Exception
  {
    setCustomerID(customerID);
    Pattern p = retrievePatternDefinition(customerID, patternName);
    if (p == null)
      return getNotExistMessage(patternName);

    return XmlUtils.convertStringWithXmlTags(PatternXmlBuilder.toXml(p));
  }

  @ManagedOperation(description="Retrieve list of Tql Names")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String retrieveTqlNames(Integer customerID)
  {
    setCustomerID(customerID);
    TqlQueryGetPatterns query = new TqlQueryGetPatterns(null);
    invokeOperation(query, customerID);
    Patterns patterns = query.getPatterns();
    if (patterns == null)
      return "There are no patterns defined in CMDB!";

    ReadOnlyIterator itr = patterns.getIterator();
    StringBuilder result = new StringBuilder("</pre>");
    result.append("<h4>List of patterns defined in CMDB</h4>");

    Map sortedPatterns = new TreeMap();
    while (itr.hasNext()) {
      Pattern pattern = (Pattern)itr.next();
      sortedPatterns.put(pattern.getName(), pattern);
    }

    PatternGroupsStatistic groupsStatistic = new PatternGroupsStatistic();

    result.append("<table>");
    for (Iterator i$ = sortedPatterns.values().iterator(); i$.hasNext(); ) { Pattern pattern = (Pattern)i$.next();
      String patternName = pattern.getName();
      boolean isActive = pattern.getState().isActive();
      boolean isPersistent = pattern.getState().isPresist();
      String patternGroup = pattern.getGroupId().toString();
      groupsStatistic.add(patternGroup, isActive, isPersistent);

      String patternPriority = pattern.getState().getPriority().getName();

      result.append("<tr><td><a href=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "exportTql", new Object[] { patternName })).append("\">").append(patternName).append("</a> - ");

      result.append((isActive) ? "Active" : "NOT Active");
      result.append(", ").append((isPersistent) ? "Persistent" : "NOT Persistent");
      result.append(", ").append(patternPriority);
      result.append(", ").append("Group=").append(patternGroup).append("</td>");
      result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "retrieveTqlResultCount", new Object[] { patternName })).append("\">").append("<input value=\"Count\" type=\"submit\"></form></td>");

      result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "retrieveTqlResultCountByElementNumbers", new Object[] { patternName })).append("\">").append("<input value=\"Count By Elements\" type=\"submit\"></form></td>");

      result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "retrieveTqlResult", new Object[] { patternName, Integer.valueOf(10000), "map" })).append("\">").append("<input value=\"Get Result\" type=\"submit\"></form></td>");

      if (isActive) {
        result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "deactivateTql", new Object[] { patternName })).append("\">").append("<input value=\"Deactivate\" type=\"submit\"></form></td>");
      }
      else
      {
        result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "activateTql", new Object[] { patternName })).append("\">").append("<input value=\"Activate\" type=\"submit\"></form></td>");
      }

      result.append("</tr>\n");
    }
    result.append("</table>\n");

    for (i$ = groupsStatistic.getGroups().iterator(); i$.hasNext(); ) { String patternGroup = (String)i$.next();
      result.append("<h4>Group:").append(patternGroup).append("</h4>");
      result.append("<p>patterns:").append(groupsStatistic.getAll(patternGroup)).append(", active:").append(groupsStatistic.getActive(patternGroup)).append(", persistent:").append(groupsStatistic.getPersistent(patternGroup));
    }

    result.append("<h4>All groups:</h4>");
    result.append("<p>patterns:").append(groupsStatistic.getAll()).append(", active:").append(groupsStatistic.getActive()).append(", persistent:").append(groupsStatistic.getPersistent());

    result.append("<pre>");
    return result.toString();
  }

  @ManagedOperation(description="Show object neigbors graph")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="objectId", description="Object id"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="depth", description="search depth")})
  public String retrieveObjectNeighbors(Integer customerID, String objectId, int depth)
    throws Exception
  {
    CmdbObjectID srcId;
    setCustomerID(customerID);
    try
    {
      srcId = CmdbObjectID.Factory.restoreObjectID(objectId.toLowerCase());
    }
    catch (Exception ex) {
      return "The object id " + objectId + " is not a valid object id";
    }
    ElementTypeLayout typeLayout = PatternLayoutFactory.createTypeLayout();
    TqlQueryGetNeighborsGraph query = new TqlQueryGetNeighborsGraph(srcId, depth, typeLayout);
    invokeOperation(query, customerID);
    return CmdbGraph.Utils.toString(query.getResultGraph());
  }

  @ManagedOperation(description="Given a pattern name, it retieves the TqlResult as either graph or map")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="patternName", description="Pattern name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="maxGraphSize", description="Maximal graph size to retrieve"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="format", description="Result format, can be either \"map\" or \"graph\"")})
  public String retrieveTqlResult(Integer customerID, String patternName, int maxGraphSize, String format)
  {
    String stringToReturn;
    setCustomerID(customerID);

    Pattern pattern = retrievePatternDefinition(customerID, patternName);
    if (pattern == null)
      return getNotExistMessage(patternName);

    if (format.equalsIgnoreCase("graph")) {
      TqlQueryGetResultGraph getPatternResultAsGraph = new TqlQueryGetResultGraph(CmdbPatternIDFactory.createObjectID(patternName));
      invokeOperation(getPatternResultAsGraph, customerID);

      CmdbGraph graph = getPatternResultAsGraph.getResultGraph();

      if (graph.getObjectsAmount() > maxGraphSize) {
        return "The result Graph size exceeds limit";
      }

      stringToReturn = CmdbGraph.Utils.toXML(graph);
    }
    else if (format.equalsIgnoreCase("map")) {
      TqlQueryGetResultMap getPatternResultAsMap = new TqlQueryGetResultMap(CmdbPatternIDFactory.createObjectID(patternName));
      invokeOperation(getPatternResultAsMap, customerID);

      if (getPatternResultAsMap.getResultSize() > maxGraphSize) {
        return "The result map size [" + getPatternResultAsMap.getResultSize() + "] exceeds limit [" + maxGraphSize + "]";
      }

      TqlResultMap map = (getPatternResultAsMap.isDividedToChunks()) ? TqlResultMapUtils.getResultInChunks(getPatternResultAsMap.getChunkRequest(), PatternGraphFactory.createGraphDictionary(pattern.getPatternGraph()), getAPI(getPatternResultAsMap), getContext(), true) : getPatternResultAsMap.getResultMap();

      stringToReturn = map.toString();
    }
    else
    {
      stringToReturn = "Format parameter must be either \"graph\" or \"map\" !!!";
    }
    return XmlUtils.convertStringWithXmlTags(stringToReturn);
  }

  @ManagedOperation(description="Remove Tql")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="patternName", description="Pattern name")})
  public String removeTql(Integer customerID, String patternName)
    throws Exception
  {
    setCustomerID(customerID);
    Pattern pattern = retrievePatternDefinition(customerID, patternName);
    if (pattern == null)
      return getNotExistMessage(patternName);

    TqlUpdatePatternRemove remove = new TqlUpdatePatternRemove(pattern.getID());
    invokeOperation(remove, customerID);
    return "operation succeeded";
  }

  @ManagedOperation(description="Retrieve Tql Result counts")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="patternName", description="Pattern name")})
  public String retrieveTqlResultCount(Integer customerID, String patternName)
    throws Exception
  {
    setCustomerID(customerID);
    TqlResultCount count = findTqlResultCount(customerID, patternName);
    if (count == null)
      return getNotExistMessage(patternName);

    return "Count for pattern " + patternName + ": " + count.size();
  }

  protected TqlResultCount findTqlResultCount(Integer customerID, String patternName) throws Exception {
    Pattern p = retrievePatternDefinition(customerID, patternName);
    if (p == null)
      return null;

    TqlQueryGetResultCount query = new TqlQueryGetResultCount(p.getID());
    invokeOperation(query, customerID);
    return query.getResultCount();
  }

  @ManagedOperation(description="Retrive Tql Result counts per element number")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="patternName", description="Pattern name")})
  public String retrieveTqlResultCountByElementNumbers(Integer customerID, String patternName)
    throws Exception
  {
    setCustomerID(customerID);
    TqlResultCount rcount = findTqlResultCount(customerID, patternName);
    if (rcount == null)
      return getNotExistMessage(patternName);

    StringBuilder result = new StringBuilder();
    result.append("Objects Entries:\n");
    ReadOnlyIterator oItr = rcount.getObjectResultEntriesIterator();
    while (oItr.hasNext()) {
      ResultEntry oEntry = (ResultEntry)oItr.next();
      result.append("Element Number:").append(oEntry.getElementNumber()).append("\tcount:").append(oEntry.size()).append("\n");
    }

    result.append("Links Entries:\n");
    ReadOnlyIterator lItr = rcount.getLinkResultEntriesIterator();
    while (lItr.hasNext()) {
      ResultEntry lEntry = (ResultEntry)lItr.next();
      result.append("Element Number:").append(lEntry.getElementNumber()).append("\tcount:").append(lEntry.size()).append("\n");
    }

    if (rcount.getCmdbVersion() != null)
      result.append("Version: ").append(rcount.getCmdbVersion()).append("\n");

    return result.toString();
  }

  @ManagedOperation(description="Given a customer id, it retieves the scheduler current statistics data")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String getSchedulerStatistics(Integer customerID)
  {
    setCustomerID(customerID);
    TqlQueryGetSchedulerStatistics schedulerSchedulerStatistics = new TqlQueryGetSchedulerStatistics();
    invokeOperation(schedulerSchedulerStatistics, customerID);

    StringBuilder statisticsStr = new StringBuilder();
    statisticsStr.append("\t\tAvr Over All");
    statisticsStr.append("\tAvr Calculation");
    statisticsStr.append("\tAvr Queue Waiting");
    statisticsStr.append("\tMin Over All");
    statisticsStr.append("\tMin Queue Waiting");
    statisticsStr.append("\tMax Over All");
    statisticsStr.append("\tMax Queue Waiting");
    statisticsStr.append("\tNum of measurments");
    statisticsStr.append("\tLast measurment time");
    statisticsStr.append("\n***************************************************************************************************************************************");
    statisticsStr.append("***************************************************************************************************************************************\n\n");
    for (Iterator iter = schedulerSchedulerStatistics.getStatistics().keySet().iterator(); iter.hasNext(); )
    {
      Pattern pattern = (Pattern)iter.next();
      CmdbPatternID patternID = pattern.getID();
      PatternStatisticsInfo statisticsInfo = (PatternStatisticsInfo)schedulerSchedulerStatistics.getStatistics().get(pattern);
      statisticsStr.append("\n" + patternID.toString());

      statisticsStr.append("\tImme_clac");
      if (statisticsInfo.getNumOfImmediateMeasurments() > 0) {
        statisticsStr.append("\t" + statisticsInfo.getOverAllImmediateAvrMeasurment());
        statisticsStr.append("\t" + statisticsInfo.getAvrImmediateMeasurment());
        statisticsStr.append("\t" + statisticsInfo.getQueueTimeImmediateAvrMeasurment());

        statisticsStr.append("\t" + statisticsInfo.getMinOverAllImmediateMeasurment());
        statisticsStr.append("\t" + statisticsInfo.getMinQueueTimeImmediateMeasurment());

        statisticsStr.append("\t" + statisticsInfo.getMaxOverAllImmediateMeasurment());
        statisticsStr.append("\t" + statisticsInfo.getMaxQueueTimeImmediateMeasurment());

        statisticsStr.append("\t" + statisticsInfo.getNumOfImmediateMeasurments());
      }
      statisticsStr.append("\t" + statisticsInfo.getLastImmediateInvokationTime());

      statisticsStr.append("\n" + patternID.toString());

      statisticsStr.append("\tFull_clac");
      if (statisticsInfo.getNumOfFullCalcMeasurments() > 0) {
        statisticsStr.append("\t" + statisticsInfo.getOverAllFullCalcAvrMeasurment());
        statisticsStr.append("\t" + statisticsInfo.getAvrFullCalcMeasurment());
        statisticsStr.append("\t" + statisticsInfo.getQueueTimeFullCalcAvrMeasurment());

        statisticsStr.append("\t" + statisticsInfo.getMinOverAllFullCalcMeasurment());
        statisticsStr.append("\t" + statisticsInfo.getMinQueueTimeFullCalcMeasurment());

        statisticsStr.append("\t" + statisticsInfo.getMaxOverAllFullCalcMeasurment());
        statisticsStr.append("\t" + statisticsInfo.getMaxQueueTimeFullCalcMeasurment());

        statisticsStr.append("\t" + statisticsInfo.getNumOfFullCalcMeasurments());
      }
      statisticsStr.append("\t" + statisticsInfo.getLastFullCalcInvokationTime());

      statisticsStr.append("\n");
    }
    return statisticsStr.toString();
  }

  @ManagedOperation(description="Update Tql statistics counts")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public void updateCountStatistics(Integer customerID)
  {
    setCustomerID(customerID);
    TqlCommandConditionCountWakeUp update = new TqlCommandConditionCountWakeUp();
    invokeOperation(update, customerID);
  }

  @ManagedOperation(description="Get Class Count Grouped By Attribute")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="Class Name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="isDerived", description="Is Derived"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="attributeName", description="Attribute Name")})
  public String getGroupByAttributeCount(Integer customerID, String className, boolean isDerived, String attributeName)
  {
    setCustomerID(customerID);
    CmdbClassModel cmdbClassModel = getCmdbClassModel();
    CmdbClass cmdbClass = cmdbClassModel.getClass(className);
    if (cmdbClass == null)
      return "The class " + className + " doesn't exist in class model";

    CmdbAttribute cmdbAttribute = cmdbClass.getAttributeByName(attributeName);
    if (cmdbAttribute == null)
      return "The attribute " + attributeName + " doesn't exist in class " + className + " in class model";

    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(className, isDerived);
    TqlQueryGetObjectsAttributesGroupByCount getGroupByCount = new TqlQueryGetObjectsAttributesGroupByCount(elementCondition, attributeName);
    invokeOperation(getGroupByCount, customerID);

    StringBuilder sb = new StringBuilder("Class Type: " + className + ", Derived: " + isDerived + ", Count Group By: " + attributeName);
    sb.append("\n*******************************************************************************\n");
    for (ReadOnlyIterator iter = getGroupByCount.getAttributeGroupedByCount().getAttributeValues(); iter.hasNext(); ) {
      String attributeValue = (String)iter.next();
      int count = getGroupByCount.getAttributeGroupedByCount().getAttributeCount(attributeValue);
      sb.append("\n\t").append(attributeValue).append("=>").append(count);
    }
    return sb.toString();
  }

  @ManagedOperation(description="Get System TQLs General Data")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String getSystemTqlsGeneralData(Integer customerID)
  {
    setCustomerID(customerID);
    SystemTqlCacheQueryGetOverallData getOverallData = new SystemTqlCacheQueryGetOverallData();
    invokeOperation(getOverallData, customerID);

    Map data = getOverallData.getData();

    StringBuilder sb = new StringBuilder("Number of System TQLs [" + data.size() + "]\nElement Condition toString to Total Result Count\n**************************************************************************\n");
    for (Iterator i$ = data.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      sb.append(((ElementCondition)entry.getKey()).toString()).append(" --> ").append(((SystemTqlGeneralData)entry.getValue()).getTotalResultSize()).append("\n");
    }
    return sb.toString();
  }

  @ManagedOperation(description="Get System TQL Total Result Objects")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="condition", description="Element Condition toString")})
  public String getSystemTqlResultObjects(Integer customerID, String condition)
  {
    setCustomerID(customerID);
    SystemTqlCacheQueryGetResultObjectsByStr getResultObjectsByStr = new SystemTqlCacheQueryGetResultObjectsByStr(condition);

    invokeOperation(getResultObjectsByStr, customerID);

    if (getResultObjectsByStr.getResultObjects() == null) return "No system TQL was found with the given toString !!!";

    StringBuilder sb = new StringBuilder("Number of Result Objects [" + getResultObjectsByStr.getResultObjects().size() + "]\n**************************************************************************\n");
    for (Iterator i$ = getResultObjectsByStr.getResultObjects().iterator(); i$.hasNext(); ) { ModelObject modelObject = (ModelObject)i$.next();
      sb.append(modelObject.toString()).append("\n");
    }
    return sb.toString();
  }

  @ManagedOperation(description="Get Names of Pattern Using System TQLs and their Relevant Node Numbers")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String getPatternNamesUsingSystemTQLs(Integer customerID)
  {
    setCustomerID(customerID);
    TqlQueryGetPatterns getPatterns = new TqlQueryGetPatterns(null);
    invokeOperation(getPatterns, customerID);

    StringBuilder sb = new StringBuilder("Pattern Name to Element Numbers\n**************************************************************************\n");

    for (ReadOnlyIterator iter = getPatterns.getPatterns().getIterator(); iter.hasNext(); ) {
      Pattern pattern = (Pattern)iter.next();
      SystemTqlCacheQueryGetGraphSysTQLs getGraphSysTQLs = new SystemTqlCacheQueryGetGraphSysTQLs(pattern.getPatternGraph(), EmptyPatternElementNumbers.getInstance());
      invokeOperation(getGraphSysTQLs, customerID);
      if (!(getGraphSysTQLs.getRelevantNumbers().isEmpty()))
        sb.append(pattern.getName()).append("\t").append(getGraphSysTQLs.getRelevantNumbers()).append("\n");
    }

    return sb.toString();
  }

  @ManagedOperation(description="Reload TQLs that should not be optimized list")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public void reloadTqlsNotToOptimize(Integer customerID)
  {
    setCustomerID(customerID);
    Collection newTqlsNotToOptimize = OptimizationPersistencyUtils.buildTqlsNotToOptimizeForCustomer(customerID.intValue());
    TqlCommandUpdateTqlsNotToOptimize reloadTqlsNotToOptimize = new TqlCommandUpdateTqlsNotToOptimize(newTqlsNotToOptimize);
    invokeOperation(reloadTqlsNotToOptimize, customerID);
  }

  @ManagedOperation(description="Displays TQLs that should not be optimized list")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public Collection getTqlsNotToOptimize(Integer customerID)
  {
    setCustomerID(customerID);
    TqlQueryGetTqlsNotToOptimize getTqlsNotToOptimize = new TqlQueryGetTqlsNotToOptimize();
    invokeOperation(getTqlsNotToOptimize, customerID);
    return getTqlsNotToOptimize.getTqlsNotToOptimize();
  }

  @ManagedOperation(description="Calculates TQL Ad Hoc. Returns the calculation time, size and result")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="patternName", description="Pattern name")})
  public String calculateTqlAdHoc(Integer customerID, String patternName)
  {
    setCustomerID(customerID);
    Pattern getPattern = retrievePatternDefinition(customerID, patternName);
    if (getPattern == null)
      return getNotExistMessage(patternName);

    TqlQueryGetAdHocMap getAdHocMap = new TqlQueryGetAdHocMap(getPattern, null);
    long startTime = CmdbTime.currentTimeMillis();
    invokeOperation(getAdHocMap, customerID);
    long calculationTime = CmdbTime.currentTimeMillis() - startTime;
    return "Calculation finished. Calculation time: " + calculationTime + " ms. Calculation result size: " + getAdHocMap.getResultMap().size() + "\n\n" + "Result:\n" + XmlUtils.convertStringWithXmlTags(getAdHocMap.getResultMap().toString());
  }

  private Pattern retrievePatternDefinition(Integer customerID, String patternName) {
    TqlQueryGetPattern query = new TqlQueryGetPattern(CmdbPatternIDFactory.createObjectID(patternName), true);
    invokeOperation(query, customerID);
    Pattern p = query.getPattern();
    if (p == null) {
      String msg = "Pattern: " + patternName + " doesn't exist in CMDB!";
      _infoLogger.info(msg);
    }
    return p;
  }

  private String getNotExistMessage(String patternName) {
    return "The pattern " + patternName + " does not exist in CMDB";
  }
}