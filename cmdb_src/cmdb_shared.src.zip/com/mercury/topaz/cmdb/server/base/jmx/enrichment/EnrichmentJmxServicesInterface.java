package com.mercury.topaz.cmdb.server.base.jmx.enrichment;

public abstract interface EnrichmentJmxServicesInterface
{
  public abstract String activateEnrichment(Integer paramInteger, String paramString);

  public abstract String deactivateEnrichment(Integer paramInteger, String paramString);

  public abstract String calculateAdHocEnrichment(Integer paramInteger, String paramString);

  public abstract String exportEnrichment(Integer paramInteger, String paramString);

  public abstract String retrieveAllEnrichmentNames(Integer paramInteger);

  public abstract String removeEnrichment(Integer paramInteger, String paramString);

  public abstract String removeEnrichmentResults(Integer paramInteger, String paramString);

  public abstract String retrieveEnrichmentResultCount(Integer paramInteger, String paramString);

  public abstract String retrieveEnrichmentResultCountByElementNumbers(Integer paramInteger, String paramString);
}