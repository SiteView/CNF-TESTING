package com.mercury.topaz.cmdb.server.base.jmx.tql;

class PatternGroupStatistic
{
  private int _countAll;
  private int _countActive;
  private int _countPersistent;

  void add(boolean isActive, boolean isPersistent)
  {
    this._countAll += 1;
    if (isActive)
      this._countActive += 1;

    if (isPersistent)
      this._countPersistent += 1;
  }

  int getAll()
  {
    return this._countAll;
  }

  int getActive() {
    return this._countActive;
  }

  int getPersistent() {
    return this._countPersistent;
  }
}