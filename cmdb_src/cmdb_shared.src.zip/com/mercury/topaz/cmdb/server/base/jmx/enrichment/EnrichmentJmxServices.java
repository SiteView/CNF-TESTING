package com.mercury.topaz.cmdb.server.base.jmx.enrichment;

import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.shared.enrichment.admin.operation.update.impl.EnrichmentUpdateActivateEnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.admin.operation.update.impl.EnrichmentUpdateDeactivateEnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.admin.operation.update.impl.EnrichmentUpdateRemoveEnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.command.impl.EnrichmentCommandAdHocCalculator;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.query.impl.EnrichmentQueryGetResultCount;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.update.impl.EnrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.impl.EnrichmentQueryGetEnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.impl.EnrichmentQueryGetEnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.result.EnrichmentResultCount;
import com.mercury.topaz.cmdb.shared.enrichment.definition.util.EnrichmentDefinitionXmlBuilder;
import com.mercury.topaz.cmdb.shared.enrichment.definition.util.impl.EnrichmentDefinitionXmlBuilderFactory;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.ResultEntry;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=CMDB Enrichment Services", description="CMDB Enrichment Services")
public class EnrichmentJmxServices extends AbstractCmdbJmx
  implements EnrichmentJmxServicesInterface
{
  @ManagedOperation(description="Activate Enrichment")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String activateEnrichment(Integer customerID, String enrichmentName)
  {
    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinition(customerID, enrichmentName);
    if (enrichmentDefinition == null)
      return getNotExistMessage(enrichmentName);

    if (enrichmentDefinition.getIsActive()) {
      return "The enrichment " + enrichmentName + " is already active";
    }

    EnrichmentUpdateActivateEnrichmentDefinition update = new EnrichmentUpdateActivateEnrichmentDefinition(enrichmentName);
    invokeOperation(update, customerID);
    return "operation succeeded";
  }

  @ManagedOperation(description="Deactivate Enrichment")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String deactivateEnrichment(Integer customerID, String enrichmentName)
  {
    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinition(customerID, enrichmentName);
    if (enrichmentDefinition == null)
      return getNotExistMessage(enrichmentName);

    if (!(enrichmentDefinition.getIsActive())) {
      return "The enrichment " + enrichmentName + " is already not active";
    }

    EnrichmentUpdateDeactivateEnrichmentDefinition update = new EnrichmentUpdateDeactivateEnrichmentDefinition(enrichmentName);
    invokeOperation(update, customerID);
    return "operation succeeded";
  }

  @ManagedOperation(description="Calculate Enrichment")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String calculateAdHocEnrichment(Integer customerID, String enrichmentName)
  {
    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinition(customerID, enrichmentName);
    if (enrichmentDefinition == null) {
      return getNotExistMessage(enrichmentName);
    }

    EnrichmentCommandAdHocCalculator command = new EnrichmentCommandAdHocCalculator(enrichmentName);
    invokeOperation(command, customerID);
    return "operation succeeded";
  }

  @ManagedOperation(description="Show Enrichment definition as xml")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String exportEnrichment(Integer customerID, String enrichmentName)
  {
    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinition(customerID, enrichmentName);
    if (enrichmentDefinition == null) {
      return getNotExistMessage(enrichmentName);
    }

    EnrichmentDefinitionXmlBuilder enrichmentDefinitionXmlBuilder = EnrichmentDefinitionXmlBuilderFactory.create();
    return enrichmentDefinitionXmlBuilder.toXml(enrichmentDefinition);
  }

  @ManagedOperation(description="Show list of Enrichments defined in CMDB")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String retrieveAllEnrichmentNames(Integer customerID)
  {
    EnrichmentQueryGetEnrichmentDefinitions query = new EnrichmentQueryGetEnrichmentDefinitions();
    invokeOperation(query, customerID);
    EnrichmentDefinitions definitions = query.getEnrichmentDefinitions();
    if (definitions == null)
      return "There are no enrichments defined in CMDB!";

    StringBuffer result = new StringBuffer();
    result.append("Enrichment defined in CMDB:\n");
    int count = 0;
    int activeCount = 0;
    ReadOnlyIterator itr = definitions.getElementsIterator();
    while (itr.hasNext()) {
      EnrichmentDefinition definition = (EnrichmentDefinition)itr.next();
      String isActiveStr = "NOT ACTIVE";
      boolean isActive = definition.getIsActive();
      if (isActive) {
        ++activeCount;
        isActiveStr = "ACTIVE";
      }
      result.append(definition.getEnrichmentName() + '\t' + isActiveStr + '\n');
      ++count;
    }
    result.append("\nTotal number of enrichments:" + count);
    result.append("\nTotal number of active enrichments:" + activeCount);
    return result.toString();
  }

  @ManagedOperation(description="Remove Enrichment")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String removeEnrichment(Integer customerID, String enrichmentName)
  {
    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinition(customerID, enrichmentName);
    if (enrichmentDefinition == null) {
      return getNotExistMessage(enrichmentName);
    }

    EnrichmentUpdateRemoveEnrichmentDefinition remove = new EnrichmentUpdateRemoveEnrichmentDefinition(enrichmentName);
    invokeOperation(remove, customerID);
    return "operation succeeded";
  }

  @ManagedOperation(description="Remove Enrichment Results")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String removeEnrichmentResults(Integer customerID, String enrichmentName)
  {
    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinition(customerID, enrichmentName);
    if (enrichmentDefinition == null) {
      return getNotExistMessage(enrichmentName);
    }

    EnrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment remove = new EnrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment(enrichmentName);
    invokeOperation(remove, customerID);
    return "operation succeeded";
  }

  @ManagedOperation(description="Retrieve Enrichment Result counts")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String retrieveEnrichmentResultCount(Integer customerID, String enrichmentName)
  {
    EnrichmentResultCount count = findEnrichmentResultCount(customerID, enrichmentName);
    if (count == null)
      return getNotExistMessage(enrichmentName);

    return String.valueOf(count.size());
  }

  protected EnrichmentResultCount findEnrichmentResultCount(Integer customerID, String enrichmentName) {
    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinition(customerID, enrichmentName);
    if (enrichmentDefinition == null) {
      return null;
    }

    EnrichmentQueryGetResultCount query = new EnrichmentQueryGetResultCount(enrichmentName);
    invokeOperation(query, customerID);
    return query.getResultCount();
  }

  private EnrichmentDefinition retrieveEnrichmentDefinition(Integer customerID, String enrichmentName) {
    EnrichmentQueryGetEnrichmentDefinition enrichmentQueryGetEnrichmentDefinition = new EnrichmentQueryGetEnrichmentDefinition(enrichmentName);
    invokeOperation(enrichmentQueryGetEnrichmentDefinition, customerID);
    EnrichmentDefinition enrichmentDefinition = enrichmentQueryGetEnrichmentDefinition.getEnrichmentDefinition();
    return enrichmentDefinition;
  }

  @ManagedOperation(description="Retrieve Enrichment Result counts per element number")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String retrieveEnrichmentResultCountByElementNumbers(Integer customerID, String enrichmentName)
  {
    EnrichmentResultCount rcount = findEnrichmentResultCount(customerID, enrichmentName);
    if (rcount == null)
      return getNotExistMessage(enrichmentName);

    StringBuffer result = new StringBuffer();
    result.append("Objects Entries:\n");
    ReadOnlyIterator oItr = rcount.getObjectResultEntriesIterator();
    while (oItr.hasNext()) {
      ResultEntry oEntry = (ResultEntry)oItr.next();
      result.append("Element Number:" + oEntry.getElementNumber() + "\tcount:" + oEntry.size() + '\n');
    }

    result.append("Links Entries:\n");
    ReadOnlyIterator lItr = rcount.getLinkResultEntriesIterator();
    while (lItr.hasNext()) {
      ResultEntry lEntry = (ResultEntry)lItr.next();
      result.append("Element Number:" + lEntry.getElementNumber() + "\tcount:" + lEntry.size() + '\n');
    }
    return result.toString();
  }

  private String getNotExistMessage(String enrichmentName) {
    return "The enrichment " + enrichmentName + " does not exist in CMDB";
  }
}