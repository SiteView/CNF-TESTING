package com.mercury.topaz.cmdb.server.base.ha.controller;

import com.mercury.topaz.cmdb.client.manage.api.CmdbNotification;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.impl.ControllerServiceInstance;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.JMSListenerAdapterFactory;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher.JMSPublisher;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;

public class CmdbServiceInstance extends ControllerServiceInstance
{
  private CmdbChangeListenerCorseGrained adminAdapter;

  public CmdbServiceInstance(CustomerInstance customerInstance)
  {
    super("CMDB", customerInstance);
  }

  public void startUp() {
    super.startUp();

    JMSPublisher jmsPublisher = getLocalEnvironment().getGlobalEnvironment().getJmsPublisher();
    this.adminAdapter = JMSListenerAdapterFactory.createCmdbAdminListenerAdapter(getCustomerID(), jmsPublisher);
    CmdbApiFactory.createNotificationService().register(this.adminAdapter, CmdbContextFactory.createCmdbContext(getCustomerID(), -1, "CMDB"));
  }

  public void shutdown()
  {
    if (this.adminAdapter != null) {
      CmdbApiFactory.createNotificationService().unregister(this.adminAdapter, CmdbContextFactory.createCmdbContext(getCustomerID(), -1, "CMDB"));
    }

    super.shutdown();
  }
}