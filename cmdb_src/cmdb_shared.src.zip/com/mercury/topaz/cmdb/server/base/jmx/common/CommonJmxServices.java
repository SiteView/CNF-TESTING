package com.mercury.topaz.cmdb.server.base.jmx.common;

import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryGetInstancesCount;
import com.mercury.topaz.cmdb.server.model.operation.query.topology.memory.ModelMemoryTopologyQueryGetLinksCount;
import com.mercury.topaz.cmdb.server.model.operation.query.topology.memory.ModelMemoryTopologyQueryGetObjectsCount;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Default;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.impl.EnrichmentQueryGetEnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.customer.id.impl.CmdbCustomerIDsFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl.CmdbCustomerQueryGetLoadedCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.PatternSelector;
import com.mercury.topaz.cmdb.shared.tql.definition.Patterns;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.CmdbPatternIDFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetPatterns;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultCount;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetTotalResultCountFromRepository;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultCount;
import com.mercury.topaz.cmdb.shared.tql.util.PatternSelectorFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=CMDB Common Services", description="CMDB Common Services")
public class CommonJmxServices extends AbstractCmdbJmx
  implements CommonJmxServicesInterface
{
  @ManagedOperation(description="Display the capacity of one customer")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String retrieveCustomerCapacity(Integer customerID)
  {
    StringBuffer sb = new StringBuffer();

    CmdbCustomerIDs customerIDs = CmdbCustomerIDsFactory.createCustomerIDs();
    customerIDs.addCustomerID(createCustomerID(customerID));

    printBPM(sb, customerIDs);

    printSiS(sb, customerIDs);

    printAlerts(sb, customerIDs);

    printCMDB(sb, customerIDs);

    printViews(sb, customerIDs);

    printSLM(sb, customerIDs);

    printTrinity(sb, customerIDs);

    return sb.toString();
  }

  @ManagedOperation(description="Display the capacity of all the customers aggregated")
  public String retrieveCMDBCapacity()
  {
    StringBuffer sb = new StringBuffer();

    CmdbCustomerQueryGetLoadedCustomerIDs getLoadedCustomers = new CmdbCustomerQueryGetLoadedCustomerIDs("CMDB");

    CmdbContext cmdbContext = createContext(Integer.valueOf(FrameworkConstants.Customer.Default.ID.getID()));
    invokeOperation(getLoadedCustomers, cmdbContext);

    CmdbCustomerIDs customerIDs = getLoadedCustomers.getCustomerIDs();

    printGeneralData(sb, customerIDs);

    printBPM(sb, customerIDs);

    printSiS(sb, customerIDs);

    printAlerts(sb, customerIDs);

    printCMDB(sb, customerIDs);

    printViews(sb, customerIDs);

    printSLM(sb, customerIDs);

    printTrinity(sb, customerIDs);

    return sb.toString();
  }

  private CmdbCustomerIDs printGeneralData(StringBuffer sb, CmdbCustomerIDs customerIDs)
  {
    printComponentHeader(sb, "General Data");

    printRecord(sb, "Loaded Customers", String.valueOf(customerIDs.size()));

    printComponentFooter(sb);
    return customerIDs;
  }

  private String getClassCount(String className, CmdbContext cmdbContext) {
    ModelQueryGetInstancesCount getInstancesCount = new ModelQueryGetInstancesCount(className);
    try {
      invokeOperation(getInstancesCount, cmdbContext);
      return String.valueOf(getInstancesCount.getInstancesCount());
    } catch (Throwable t) {
    }
    return "Error getting count for class: " + className;
  }

  private String getObjectsInMemory(CmdbContext cmdbContext)
  {
    ModelMemoryTopologyQueryGetObjectsCount getObjectsCount = new ModelMemoryTopologyQueryGetObjectsCount();
    try {
      invokeOperation(getObjectsCount, cmdbContext);
      return String.valueOf(getObjectsCount.getInstancesCount());
    } catch (Throwable t) {
    }
    return "Error getting number of objects in memory";
  }

  private String getLinksInMemory(CmdbContext cmdbContext)
  {
    ModelMemoryTopologyQueryGetLinksCount getLinksCount = new ModelMemoryTopologyQueryGetLinksCount();
    try {
      invokeOperation(getLinksCount, cmdbContext);
      return String.valueOf(getLinksCount.getCount());
    } catch (Throwable t) {
    }
    return "Error getting number of links in memory";
  }

  private void printTrinity(StringBuffer sb, CmdbCustomerIDs customerIDs)
  {
    printComponentHeader(sb, "Trinity");

    String customersCIs = "0";
    String customersKPIs = "0";

    for (ReadOnlyIterator iter = customerIDs.getCustomerIdsIterator(); iter.hasNext(); ) {
      CmdbCustomerID customerID = (CmdbCustomerID)iter.next();
      CmdbContext cmdbContext = createContext(Integer.valueOf(FrameworkConstants.Customer.Default.ID.getID()));

      String trinityTqlName = "trinity_dashboard_tql";
      if (isTqlExist(customerID, trinityTqlName)) {
        CmdbPatternID patternID = CmdbPatternIDFactory.createObjectID(trinityTqlName);
        TqlQueryGetResultCount getResultCount = new TqlQueryGetResultCount(patternID, true);

        invokeOperation(getResultCount, cmdbContext);
        TqlResultCount trinityResult = getResultCount.getResultCount();

        PatternElementNumber CIElementNumber = PatternElementNumberFactory.createElementNumber(1);
        PatternElementNumber KPIElementNumber = PatternElementNumberFactory.createElementNumber(3);
        try {
          int ciCount = (trinityResult.containsElementNumber(CIElementNumber)) ? trinityResult.getSize(CIElementNumber) : 0;
          customersCIs = addStrings(customersCIs, String.valueOf(ciCount));
        }
        catch (Throwable t) {
          customersCIs = addStrings(customersCIs, "ERROR in customer: " + customerID);
        }
        try
        {
          int kpiCount = (trinityResult.containsElementNumber(KPIElementNumber)) ? trinityResult.getSize(KPIElementNumber) : 0;
          customersKPIs = addStrings(customersKPIs, String.valueOf(kpiCount));
        }
        catch (Throwable kpiCount) {
          customersKPIs = addStrings(customersKPIs, "ERROR in customer: " + customerID);
        }
      }
    }

    printRecord(sb, "CIs", customersCIs);
    printRecord(sb, "KPIs", customersKPIs);

    printComponentFooter(sb);
  }

  private void printSLM(StringBuffer sb, CmdbCustomerIDs customerIDs)
  {
    printComponentHeader(sb, "SLM");

    String customersSLAs = "0";
    String customersCIs = "0";

    for (ReadOnlyIterator iter = customerIDs.getCustomerIdsIterator(); iter.hasNext(); ) {
      CmdbCustomerID customerID = (CmdbCustomerID)iter.next();
      CmdbContext cmdbContext = CmdbContextFactory.createCmdbContext(createCustomerID(Integer.valueOf(customerID.getID())), 1, "JMX");

      String instancesCount = getClassCount("sla", cmdbContext);
      customersSLAs = addStrings(customersSLAs, instancesCount);

      String associationsCount = getClassCount("association", cmdbContext);
      String dimensionOfCount = getClassCount("dimension_of", cmdbContext);
      String objectiveOfCount = getClassCount("objective_of", cmdbContext);
      String eventOfCount = getClassCount("event_of", cmdbContext);

      String derivedClassesCount = dimensionOfCount;
      derivedClassesCount = addStrings(derivedClassesCount, objectiveOfCount);
      derivedClassesCount = addStrings(derivedClassesCount, eventOfCount);
      try
      {
        int slaAssociationsCount = Integer.parseInt(associationsCount) - Integer.parseInt(derivedClassesCount);
        customersCIs = addStrings(customersCIs, String.valueOf(slaAssociationsCount));
      }
      catch (Throwable t) {
        customersCIs = addStrings(customersCIs, "ERROR in customer: " + customerID);
      }
    }

    printRecord(sb, "SLAs", customersSLAs);
    printRecord(sb, "CIs in SLAs", customersCIs);

    printComponentFooter(sb);
  }

  private void printViews(StringBuffer sb, CmdbCustomerIDs customerIDs)
  {
    printComponentHeader(sb, "Views");

    String customersMAMViews = "0";
    String customersBACViews = "0";

    for (ReadOnlyIterator iter = customerIDs.getCustomerIdsIterator(); iter.hasNext(); ) {
      CmdbCustomerID customerID = (CmdbCustomerID)iter.next();
      CmdbContext cmdbContext = CmdbContextFactory.createCmdbContext(createCustomerID(Integer.valueOf(customerID.getID())), 1, "JMX");

      String instancesCount = getClassCount("mapview", cmdbContext);
      customersMAMViews = addStrings(customersMAMViews, instancesCount);
      instancesCount = getClassCount("bac_view", cmdbContext);
      customersBACViews = addStrings(customersBACViews, instancesCount);
    }

    printRecord(sb, "MAM Views", customersMAMViews);
    printRecord(sb, "BAC Views", customersBACViews);

    printComponentFooter(sb);
  }

  private void printCMDB(StringBuffer sb, CmdbCustomerIDs customerIDs)
  {
    printComponentHeader(sb, "CMDB");

    String customersTotalCIs = "0";
    String customersITUObjects = "0";
    String customersITULinks = "0";
    String customersConfigurationObjects = "0";
    String customersConfigurationLinks = "0";
    String customersObjects = "0";
    String customersObjectsInMemory = "0";
    String customersHosts = "0";
    String customersLinks = "0";
    String customersLinksInMemory = "0";
    String customersEnrichments = "0";
    String customersTqlsAllGroup = "0";
    String customersTqlsCollectorsGroup = "0";
    String customersTqlsCorrelationGroup = "0";
    String customersTqlsInternalEnrichmentsGroup = "0";
    String customersTqlsPathManagerGroup = "0";
    String customersTqlsReportGroup = "0";
    String customersTqlsServerDataGroup = "0";
    String customersTqlsTopologyGroup = "0";
    String customersTqlsViewGroup = "0";
    String customersTqlsTotal = "0";
    String customersTotalResultCount = "0";

    for (ReadOnlyIterator iter = customerIDs.getCustomerIdsIterator(); iter.hasNext(); ) {
      CmdbCustomerID customerID = (CmdbCustomerID)iter.next();
      CmdbContext cmdbContext = createContext(Integer.valueOf(customerID.getID()));

      String cisCount = getClassCount("root", cmdbContext);
      customersTotalCIs = addStrings(customersTotalCIs, cisCount);

      String instancesCount = getClassCount("object", cmdbContext);
      customersObjects = addStrings(customersObjects, instancesCount);

      instancesCount = getObjectsInMemory(cmdbContext);
      customersObjectsInMemory = addStrings(customersObjectsInMemory, instancesCount);

      instancesCount = getClassCount("link", cmdbContext);
      customersLinks = addStrings(customersLinks, instancesCount);

      instancesCount = getClassCount("configuration", cmdbContext);
      customersConfigurationObjects = addStrings(customersConfigurationObjects, instancesCount);

      instancesCount = getClassCount("configuration_links", cmdbContext);
      customersConfigurationLinks = addStrings(customersConfigurationLinks, instancesCount);

      instancesCount = getLinksInMemory(cmdbContext);
      customersLinksInMemory = addStrings(customersLinksInMemory, instancesCount);

      instancesCount = getClassCount("it_world", cmdbContext);
      customersITUObjects = addStrings(customersITUObjects, instancesCount);

      instancesCount = getClassCount("it_world_links", cmdbContext);
      customersITULinks = addStrings(customersITULinks, instancesCount);

      instancesCount = getClassCount("host", cmdbContext);
      customersHosts = addStrings(customersHosts, instancesCount);

      EnrichmentQueryGetEnrichmentDefinitions getEnrichments = new EnrichmentQueryGetEnrichmentDefinitions();
      invokeOperation(getEnrichments, cmdbContext);
      customersEnrichments = addStrings(customersEnrichments, String.valueOf(getEnrichments.getEnrichmentDefinitions().size()));

      PatternSelector patternSelector = PatternSelectorFactory.createGroupSelctor(PatternGroupId.PATTERN_GROUP_ALL);
      TqlQueryGetPatterns getPatterns = new TqlQueryGetPatterns(patternSelector);
      invokeOperation(getPatterns, cmdbContext);
      int numberOfTqls = getPatterns.getPatterns().size();
      customersTqlsAllGroup = addStrings(customersTqlsAllGroup, String.valueOf(getPatterns.getPatterns().size()));

      patternSelector = PatternSelectorFactory.createGroupSelctor(PatternGroupId.PATTERN_GROUP_COLLECTORS);
      getPatterns = new TqlQueryGetPatterns(patternSelector);
      invokeOperation(getPatterns, cmdbContext);
      numberOfTqls += getPatterns.getPatterns().size();
      customersTqlsCollectorsGroup = addStrings(customersTqlsCollectorsGroup, String.valueOf(getPatterns.getPatterns().size()));

      patternSelector = PatternSelectorFactory.createGroupSelctor(PatternGroupId.PATTERN_GROUP_PATHMANAGER);
      getPatterns = new TqlQueryGetPatterns(patternSelector);
      invokeOperation(getPatterns, cmdbContext);
      numberOfTqls += getPatterns.getPatterns().size();
      customersTqlsPathManagerGroup = addStrings(customersTqlsPathManagerGroup, String.valueOf(getPatterns.getPatterns().size()));

      patternSelector = PatternSelectorFactory.createGroupSelctor(PatternGroupId.PATTERN_GROUP_REPORT);
      getPatterns = new TqlQueryGetPatterns(patternSelector);
      invokeOperation(getPatterns, cmdbContext);
      numberOfTqls += getPatterns.getPatterns().size();
      customersTqlsReportGroup = addStrings(customersTqlsReportGroup, String.valueOf(getPatterns.getPatterns().size()));

      patternSelector = PatternSelectorFactory.createGroupSelctor(PatternGroupId.PATTERN_GROUP_SERVERDATA);
      getPatterns = new TqlQueryGetPatterns(patternSelector);
      invokeOperation(getPatterns, cmdbContext);
      numberOfTqls += getPatterns.getPatterns().size();
      customersTqlsServerDataGroup = addStrings(customersTqlsServerDataGroup, String.valueOf(getPatterns.getPatterns().size()));

      patternSelector = PatternSelectorFactory.createGroupSelctor(PatternGroupId.PATTERN_GROUP_TOPOLOGY);
      getPatterns = new TqlQueryGetPatterns(patternSelector);
      invokeOperation(getPatterns, cmdbContext);
      numberOfTqls += getPatterns.getPatterns().size();
      customersTqlsTopologyGroup = addStrings(customersTqlsTopologyGroup, String.valueOf(getPatterns.getPatterns().size()));

      patternSelector = PatternSelectorFactory.createGroupSelctor(PatternGroupId.PATTERN_GROUP_VIEW);
      getPatterns = new TqlQueryGetPatterns(patternSelector);
      invokeOperation(getPatterns, cmdbContext);
      numberOfTqls += getPatterns.getPatterns().size();
      customersTqlsViewGroup = addStrings(customersTqlsViewGroup, String.valueOf(getPatterns.getPatterns().size()));

      customersTqlsTotal = addStrings(customersTqlsTotal, String.valueOf(numberOfTqls));

      TqlQueryGetTotalResultCountFromRepository getTotalResultCountFromRepository = new TqlQueryGetTotalResultCountFromRepository();
      invokeOperation(getTotalResultCountFromRepository, cmdbContext);
      long totalResultCount = getTotalResultCountFromRepository.getResultCount();

      customersTotalResultCount = addStrings(customersTotalResultCount, String.valueOf(totalResultCount));
    }

    printRecord(sb, "CIs (root)", customersTotalCIs);
    printRecord(sb, "Objects", customersObjects + " (" + customersObjectsInMemory + " in memory)");
    printRecord(sb, "Links", customersLinks + " (" + customersLinksInMemory + " in memory)");
    printRecord(sb, "IT Universe Objects", customersITUObjects);
    printRecord(sb, "IT World Links", customersITULinks);
    printRecord(sb, "Configuration Objects", customersConfigurationObjects);
    printRecord(sb, "Configuration Links", customersConfigurationLinks);

    printRecord(sb, "Hosts", customersHosts);
    printRecord(sb, "Enrichments", customersEnrichments);

    printRecord(sb, "Tqls All Group", customersTqlsAllGroup);
    printRecord(sb, "Tqls Collectors Group", customersTqlsCollectorsGroup);
    printRecord(sb, "Tqls Correlation Group", customersTqlsCorrelationGroup);
    printRecord(sb, "Tqls Internal Enrichments Group", customersTqlsInternalEnrichmentsGroup);
    printRecord(sb, "Tqls Path Manager Group", customersTqlsPathManagerGroup);
    printRecord(sb, "Tqls Report Group", customersTqlsReportGroup);
    printRecord(sb, "Tqls Server Data Group", customersTqlsServerDataGroup);
    printRecord(sb, "Tqls Topology Group", customersTqlsTopologyGroup);
    printRecord(sb, "Tqls View Group", customersTqlsViewGroup);
    printRecord(sb, "Tqls Total", customersTqlsTotal);
    printRecord(sb, "Total Result Count", customersTotalResultCount);

    printComponentFooter(sb);
  }

  private void printAlerts(StringBuffer sb, CmdbCustomerIDs customerIDs)
  {
    printComponentHeader(sb, "Alerts");

    String customersAlerts = "0";

    for (ReadOnlyIterator iter = customerIDs.getCustomerIdsIterator(); iter.hasNext(); ) {
      CmdbCustomerID customerID = (CmdbCustomerID)iter.next();
      CmdbContext cmdbContext = CmdbContextFactory.createCmdbContext(createCustomerID(Integer.valueOf(customerID.getID())), 1, "JMX");

      String instancesCount = getClassCount("alert", cmdbContext);

      customersAlerts = addStrings(customersAlerts, instancesCount);
    }

    printRecord(sb, "New Alerts", customersAlerts);

    printComponentFooter(sb);
  }

  private void printSiS(StringBuffer sb, CmdbCustomerIDs customerIDs)
  {
    printComponentHeader(sb, "SiteScope");

    String customersTotalMonitors = "0";
    String customersMonitors = "0";
    String customersMeasurements = "0";

    for (ReadOnlyIterator iter = customerIDs.getCustomerIdsIterator(); iter.hasNext(); ) {
      String totalMonitors;
      CmdbCustomerID customerID = (CmdbCustomerID)iter.next();
      CmdbContext cmdbContext = CmdbContextFactory.createCmdbContext(createCustomerID(Integer.valueOf(customerID.getID())), 1, "JMX");

      String instancesCount = getClassCount("sitescope_monitor", cmdbContext);
      String siteScopeMonitors = instancesCount;
      instancesCount = getClassCount("sitescope_measurement", cmdbContext);
      String siteScopeMeasurements = instancesCount;
      try
      {
        totalMonitors = String.valueOf(Integer.parseInt(siteScopeMonitors) + Integer.parseInt(siteScopeMeasurements));
      }
      catch (Throwable t) {
        totalMonitors = "ERROR";
      }
      customersTotalMonitors = addStrings(customersTotalMonitors, totalMonitors);
      customersMonitors = addStrings(customersMonitors, siteScopeMonitors);
      customersMeasurements = addStrings(customersMeasurements, siteScopeMeasurements);
    }

    printRecord(sb, "Total Monitors", String.valueOf(customersTotalMonitors));
    printRecord(sb, "Monitors", String.valueOf(customersMonitors));
    printRecord(sb, "Measurements", String.valueOf(customersMeasurements));

    printComponentFooter(sb);
  }

  private void printBPM(StringBuffer sb, CmdbCustomerIDs customerIDs)
  {
    printComponentHeader(sb, "BPM");

    String locationCount = "0";
    String profileCount = "0";
    String txFromLocationCount = "0";
    String txCount = "0";

    for (ReadOnlyIterator iter = customerIDs.getCustomerIdsIterator(); iter.hasNext(); ) {
      CmdbCustomerID customerID = (CmdbCustomerID)iter.next();
      CmdbContext cmdbContext = CmdbContextFactory.createCmdbContext(createCustomerID(Integer.valueOf(customerID.getID())), 1, "JMX");

      String instancesCount = getClassCount("location", cmdbContext);
      locationCount = addStrings(locationCount, instancesCount);
      instancesCount = getClassCount("bp_group", cmdbContext);
      profileCount = addStrings(profileCount, instancesCount);
      instancesCount = getClassCount("bpm_tx_from_location", cmdbContext);
      txFromLocationCount = addStrings(txFromLocationCount, instancesCount);
      instancesCount = getClassCount("bp_step", cmdbContext);
      txCount = addStrings(txCount, instancesCount);
    }

    printRecord(sb, "Locations", locationCount);
    printRecord(sb, "Profiles", profileCount);
    printRecord(sb, "Transactions", txCount);
    printRecord(sb, "Tx from location", txFromLocationCount);

    printComponentFooter(sb);
  }

  private boolean isTqlExist(CmdbCustomerID customerID, String tqlName)
  {
    TqlQueryGetPatterns query = new TqlQueryGetPatterns(null);
    invokeOperation(query, Integer.valueOf(customerID.getID()));
    Patterns patterns = query.getPatterns();
    if (patterns == null)
      return false;

    ReadOnlyIterator itr = patterns.getIterator();
    while (itr.hasNext()) {
      Pattern p = (Pattern)itr.next();
      if (tqlName.equals(p.getName()))
        return true;
    }

    return false;
  }

  private String addStrings(String str1, String str2)
  {
    int str1Value;
    int str2Value;
    try
    {
      str1Value = Integer.parseInt(str1);
    }
    catch (Throwable t) {
      return str1;
    }
    try {
      str2Value = Integer.parseInt(str2);
    }
    catch (Throwable t) {
      return str2;
    }
    return String.valueOf(str1Value + str2Value);
  }

  private void printRecord(StringBuffer sb, String recordName, String value) {
    sb.append(recordName).append(" = ").append(value).append('\n');
  }

  private void printComponentFooter(StringBuffer sb) {
    sb.append('\n');
  }

  private void printComponentHeader(StringBuffer sb, String componentName) {
    sb.append(componentName).append('\n').append("*****************************\n");
  }
}