package com.mercury.topaz.cmdb.server.base.jmx.dal;

public abstract interface CmdbDalJmxServicesInterface
{
  public abstract String getCmdbVersion(Integer paramInteger, boolean paramBoolean);

  public abstract String setCmdbVersion(Integer paramInteger, String paramString1, String paramString2);

  public abstract String getDbContext(Integer paramInteger);

  public abstract void setDisableCoarseGrainElementsInsert(Integer paramInteger, boolean paramBoolean);

  public abstract boolean isDisableCoarseGrainElementsInsert(Integer paramInteger);

  public abstract void runStatistics(Integer paramInteger);

  public abstract String isolateCustomer(Integer paramInteger, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);
}