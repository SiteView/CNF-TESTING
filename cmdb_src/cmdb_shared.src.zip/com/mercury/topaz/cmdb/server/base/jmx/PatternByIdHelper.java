package com.mercury.topaz.cmdb.server.base.jmx;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class PatternByIdHelper extends AbstractCmdbJmx
{
  private ModifiablePattern _pattern;
  private PatternLayout _patternLayout;

  public void createPattern()
  {
    PatternElementNumber number = createPatternOnly();
    ElementSimpleLayout elayout = PatternLayoutFactory.createElementSimpleLayout();
    elayout.setAllLayer(true);
    this._patternLayout.setElementLayout(number, elayout);
  }

  public void createPatternIDLayout() {
    PatternElementNumber number = createPatternOnly();
    ElementSimpleLayout elayout = PatternLayoutFactory.createElementSimpleLayout();
    elayout.addPropertiesQulifiers(CmdbAttributeQualifierDefs.ID_ATTRIBUTE.getName());
    this._patternLayout.setElementLayout(number, elayout);
  }

  private PatternElementNumber createPatternOnly() {
    PatternElementNumber number = PatternElementNumberFactory.createElementNumber(1);
    ElementCondition condition = PatternConditionFactory.createElementCondition("object", true);

    PatternNode node = PatternGraphFactory.createModifiablePatternNode(number, condition, true, null, "");
    ModifiablePatternGraph pgraph = PatternGraphFactory.createModifiableGraph();
    pgraph.addNode(node);
    this._pattern = PatternDefinitionFactory.createPattern("", "ObjectProperties", PatternGroupId.PATTERN_GROUP_ALL, pgraph);

    this._patternLayout = PatternLayoutFactory.createLayout();
    return number;
  }

  public String setPatternId(String objectID) {
    ModifiablePatternNode node = this._pattern.getModifiableGraph().getModifiableNode(PatternElementNumberFactory.createElementNumber(1));

    CmdbObjectIds ids = CmdbObjectIdsFactory.create();
    try {
      CmdbObjectID id = CmdbObjectID.Factory.restoreObjectID(objectID.toLowerCase());
      ids.add(id);
    }
    catch (Exception ex) {
      return "The object id " + objectID + " is not a valid object id";
    }

    ElementClassCondition classCondition = PatternConditionFactory.createElementClassCondition("root", true);

    ElementCondition newCondition = PatternConditionFactory.createElementCondition(classCondition, null, ids);
    node.setCondition(newCondition);
    return null;
  }

  public CmdbObject getObject(Integer customerID) {
    TqlQueryGetAdHocMap query = new TqlQueryGetAdHocMap(this._pattern, this._patternLayout);
    invokeOperation(query, customerID);
    TqlResultMap map = query.getResultMap();

    CmdbObjects objects = map.getObjects(PatternElementNumberFactory.createElementNumber(1));
    if ((objects == null) || (objects.isEmpty()))
      return null;

    return ((CmdbObject)objects.getObjectsIterator().next());
  }
}