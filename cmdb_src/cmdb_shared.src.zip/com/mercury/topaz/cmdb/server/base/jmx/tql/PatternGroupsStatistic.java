package com.mercury.topaz.cmdb.server.base.jmx.tql;

import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

class PatternGroupsStatistic extends PatternGroupStatistic
{
  private Map<String, PatternGroupStatistic> _patternGroups;

  PatternGroupsStatistic()
  {
    this._patternGroups = new TreeMap(); }

  void add(String patternGroup, boolean isActive, boolean isPersistent) {
    PatternGroupStatistic groupStatistic = (PatternGroupStatistic)this._patternGroups.get(patternGroup);
    if (groupStatistic == null) {
      groupStatistic = new PatternGroupStatistic();
      this._patternGroups.put(patternGroup, groupStatistic);
    }
    groupStatistic.add(isActive, isPersistent);

    add(isActive, isPersistent);
  }

  Collection<String> getGroups() {
    return this._patternGroups.keySet();
  }

  int getAll(String patternGroup) {
    return ((PatternGroupStatistic)this._patternGroups.get(patternGroup)).getAll();
  }

  int getActive(String patternGroup) {
    return ((PatternGroupStatistic)this._patternGroups.get(patternGroup)).getActive();
  }

  int getPersistent(String patternGroup) {
    return ((PatternGroupStatistic)this._patternGroups.get(patternGroup)).getPersistent();
  }
}