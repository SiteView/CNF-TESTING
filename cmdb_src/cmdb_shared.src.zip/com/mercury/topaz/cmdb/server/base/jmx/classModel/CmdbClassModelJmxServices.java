package com.mercury.topaz.cmdb.server.base.jmx.classModel;

import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.util.jmx.JMXUtils;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModelDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLinks;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.impl.CmdbClassFactory;
import com.mercury.topaz.cmdb.shared.classmodel.impl.CmdbClassModelFactory;
import com.mercury.topaz.cmdb.shared.classmodel.impl.CmdbClassModelUtil;
import com.mercury.topaz.cmdb.shared.classmodel.operation.update.impl.ClassModelCommandLoadFromPersistency;
import com.mercury.topaz.cmdb.shared.classmodel.operation.update.impl.cmdbclass.ClassModelUpdateCreateOrUpdateCmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDefs;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnumEntry;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import com.mercury.topaz.cmdb.shared.classmodel.util.xml.XMLBuilder;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLinks;
import com.mercury.topaz.cmdb.shared.util.Exceptions;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Text;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=CMDB Class Model Services", description="CMDB Class Model Services")
public class CmdbClassModelJmxServices extends AbstractCmdbJmx
{
  @ManagedOperation(description="Show list of classes defined in CMDB")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String retrieveAllClasses(Integer customerID)
  {
    setCustomerID(customerID);
    CmdbClassModel classModel = getCmdbClassModel();
    StringBuilder results = new StringBuilder();
    Collection classesNames = sortClassesNames(classModel.getAllClasses());
    results.append("Total of ").append(classesNames.size()).append(" classes in CMDB");
    results.append("<table border=\"1\" cellpadding=\"4%\">");
    results.append("<tr>");
    results.append("<th>Class Name</th>");
    results.append("<th>Class Type</th>");
    results.append("<th>Class Display Name</th>");
    results.append("<th>Class Description</th>");
    results.append("</tr>");
    for (Iterator i$ = classesNames.iterator(); i$.hasNext(); ) { String type;
      String className = (String)i$.next();
      CmdbClass cmdbClass = classModel.getClass(className);

      if (cmdbClass.isTypeOfObject())
        type = "OBJECT";
      else
        type = "LINK";

      results.append("<tr>");
      results.append("<td>").append(generateClassDefHyperlink(cmdbClass.getName())).append("</td>");
      results.append("<td>").append(type).append("</td>");
      results.append("<td>").append(cmdbClass.getDisplayName()).append("</td>");
      results.append("<td>").append(cmdbClass.getDescription()).append("</td>");
      results.append("</tr>\n");
    }
    results.append("</table>\n");
    return results.toString();
  }

  private List<String> sortClassesNames(CmdbClasses<CmdbClass> classes) {
    List classNames = new ArrayList(classes.getSize());
    Set classNamesSet = new TreeSet();
    for (ReadOnlyIterator it = classes.getIterator(); it.hasNext(); )
      classNamesSet.add(((CmdbClass)it.next()).getName());

    classNames.addAll(classNamesSet);
    return classNames;
  }

  @ManagedOperation(description="Retrieves the class xml")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="Object Type (host ip etc..)")})
  public String retrieveCmdbClassXml(Integer customerID, String className)
  {
    setCustomerID(customerID);
    CmdbClassModel classModel = getCmdbClassModel();

    CmdbCalculatedLinks calculatedLinks = classModel.getAllCalculatedLinks();
    if ((calculatedLinks != null) && (!(calculatedLinks.isEmpty()))) {
      CmdbCalculatedLink calculatedLink = calculatedLinks.getCalculatedLink(className);
      if (calculatedLink != null) {
        String calcLinkXml = XMLBuilder.toXml(calculatedLink);
        calcLinkXml = XmlUtils.convertStringWithXmlTags(calcLinkXml);
        calcLinkXml = replaceClassNameByHyperLink(calcLinkXml, "class-name=&quot;", "&quot;");
        return calcLinkXml;
      }
    }

    CmdbClass cmdbClass = classModel.getClass(className);
    if (cmdbClass == null) {
      return "The class " + className + " doesn't exist in class model";
    }

    String classXml = XMLBuilder.toXml(CmdbClassFactory.createClassDefinition(cmdbClass));
    classXml = XmlUtils.convertStringWithXmlTags(classXml);
    classXml = replaceClassNameByHyperLink(classXml, "&lt;Derived-From class-name=&quot;", "&quot;");
    StringBuilder result = new StringBuilder();
    addValidLinksForm(result, className, classModel);
    result.append(classXml);
    return result.toString();
  }

  private void addValidLinksForm(StringBuilder result, String className, CmdbClassModel classModel) {
    result.append("</pre><table cellpadding=\"5\"><tr>\n");
    if (classModel.isTypeOf("object", className)) {
      result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "getValidLinksForClass", new Object[] { className, Boolean.valueOf(true) })).append("\">");
      result.append("<input value=\"Outgoing Valid Links\" type=\"submit\">\n");
      result.append("</form></td>");
      result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "getValidLinksForClass", new Object[] { className, Boolean.valueOf(false) })).append("\">");
      result.append("<input value=\"Incoming Valid Links\" type=\"submit\">\n");
      result.append("</form></td>");
    } else {
      result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "getValidLinksForLinkClass", new Object[] { className })).append("\">");
      result.append("<input value=\"Valid Links with Link's class\" type=\"submit\">\n");
      result.append("</form></td>");
    }
    result.append("</tr></table><pre>");
  }

  @ManagedOperation(description="Retrieves the class hierarchy (super- and sub-classes)")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="Object Type (host ip etc..)")})
  public String retrieveClassHierarchy(Integer customerID, String className)
  {
    setCustomerID(customerID);
    CmdbClassModel classModel = getCmdbClassModel();
    CmdbClass cmdbClass = classModel.getClass(className);
    if (cmdbClass == null)
      return "Class " + className + " is not defined in the class model";

    StringBuilder result = new StringBuilder("</pre>");
    List ancestors = classModel.getCmdbClassAncestors(cmdbClass);
    int startingNestingLevel = 0;
    for (int i = ancestors.size() - 1; i >= 0; --i) {
      CmdbClass superClass = (CmdbClass)ancestors.get(i);
      result.append("<ul><li>").append(JMXUtils.generateCmdbClassHyperlink(superClass.getName())).append("</li>\n");
      ++startingNestingLevel;
    }
    String linkText = "<font size=\"+2\">" + className + "</font>";
    result.append("<ul><li>").append(generateClassDefHyperlink(className, linkText)).append("</li>\n");
    ++startingNestingLevel;
    CmdbClasses allSubClasses = classModel.getAllDescendentClasses(className);
    int currentNestingLevel = startingNestingLevel;
    for (ReadOnlyIterator it = allSubClasses.getIterator(); it.hasNext(); ) {
      CmdbClass subclass = (CmdbClass)it.next();
      int hierarchyDistance = classModel.getHierarchyDistance(className, subclass.getName());
      if (hierarchyDistance < 0)
        throw new RuntimeException("No distance between " + className + " and " + subclass.getName());

      hierarchyDistance += startingNestingLevel;
      if (currentNestingLevel > hierarchyDistance) while (true) {
          if (currentNestingLevel <= hierarchyDistance) break label360;
          result.append("</ul>\n");

          --currentNestingLevel;
        }

      for (; (currentNestingLevel < hierarchyDistance) && 
        (currentNestingLevel < hierarchyDistance); 
        ++currentNestingLevel) {
        result.append("<ul>\n");
      }

      label360: result.append("<li>").append(JMXUtils.generateCmdbClassHyperlink(subclass.getName())).append("</li>\n");
      currentNestingLevel = hierarchyDistance;
    }
    for (; currentNestingLevel > 0; --currentNestingLevel)
      result.append("</ul>\n");

    result.append("<pre>");
    return result.toString();
  }

  @ManagedOperation(description="Retrieves the typedef xml")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="typeDefName", description="Typedef Name")})
  public String retrieveCmdbTypeDefXml(Integer customerID, String typeDefName)
  {
    setCustomerID(customerID);
    CmdbClassModel classModel = getCmdbClassModel();
    CmdbTypeDef typeDef = classModel.getAllTypeDefs().getCmdbTypeDefByName(typeDefName);
    if (typeDef == null)
      return "The typeDef " + typeDefName + " doesn't exist in class model";

    String result = XMLBuilder.toXml(typeDef);
    return XmlUtils.convertStringWithXmlTags(result);
  }

  @ManagedOperation(description="Retrieves the valid links in the class model")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String retrieveAllValidLinks(Integer customerID) {
    setCustomerID(customerID);
    CmdbClassModel classModel = getCmdbClassModel();
    CmdbValidLinks validLinks = classModel.getAllValidLinks();
    String result = XMLBuilder.toXml(validLinks);
    result = XmlUtils.convertStringWithXmlTags(result);
    result = replaceClassNameByHyperLink(result, "class-name=&quot;", "&quot;");
    return result;
  }

  @ManagedOperation(description="Retrieves links that can be created from/to instances of the given class")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="Class Name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="outgoing", description="Outgoing or incoming")})
  public String getValidLinksForClass(Integer customerID, String className, boolean outgoing)
  {
    setCustomerID(customerID);
    StringBuilder result = new StringBuilder();
    CmdbClassModel classModel = getCmdbClassModel();
    CmdbValidLinks validLinks = (outgoing) ? classModel.getAllValidLinksForEnd1(className) : classModel.getAllValidLinksForEnd2(className);
    for (ReadOnlyIterator it = validLinks.getIterator(); it.hasNext(); ) {
      CmdbValidLink validLink = (CmdbValidLink)it.next();
      result.append(JMXUtils.generateCmdbClassHyperlink(validLink.getLinkClassName())).append(" from ").append(JMXUtils.generateCmdbClassHyperlink(validLink.getEnd1ClassName())).append(" to ").append(JMXUtils.generateCmdbClassHyperlink(validLink.getEnd2ClassName())).append("\n");
    }

    return result.toString();
  }

  @ManagedOperation(description="Retrieves all valid links with link's class")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="linkClassName", description="Link Class Name")})
  public String getValidLinksForLinkClass(Integer customerID, String linkClassName)
  {
    setCustomerID(customerID);
    StringBuilder result = new StringBuilder();
    CmdbClassModel classModel = getCmdbClassModel();
    CmdbValidLinks validLinks = classModel.getAllValidLinks();
    ReadOnlyIterator it = validLinks.getIterator();
    while (it.hasNext()) {
      CmdbValidLink validLink = (CmdbValidLink)it.next();
      if (classModel.isTypeOf(validLink.getLinkClassName(), linkClassName))
        result.append(JMXUtils.generateCmdbClassHyperlink(validLink.getLinkClassName())).append(" from ").append(JMXUtils.generateCmdbClassHyperlink(validLink.getEnd1ClassName())).append(" to ").append(JMXUtils.generateCmdbClassHyperlink(validLink.getEnd2ClassName())).append("\n");
    }
    return result.toString();
  }

  @ManagedOperation(description="Retrieves all classes' destinations")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String getAllClassesDestinations(Integer customerID)
  {
    setCustomerID(customerID);
    StringBuilder buf = new StringBuilder();
    CmdbClassModel classModel = getCmdbClassModel();
    ClassModelDestinationsConfig classModelDestsConfig = classModel.getClassesDestinationsConfig();
    Iterator iter = classModelDestsConfig.getAllClassDestinationsConfig();
    while (iter.hasNext()) {
      ClassDestinationsConfig classDestsConfig = (ClassDestinationsConfig)iter.next();

      String className = classDestsConfig.getClassName();
      buf.append("\nClass name: ").append(className).append("\n");

      buf.append("Destinations:").append("\n");
      Collection dests = classDestsConfig.getDestinations();
      for (Iterator i$ = dests.iterator(); i$.hasNext(); ) { String dest = (String)i$.next();
        buf.append("\t").append(dest).append("\n");
      }
    }

    return buf.toString();
  }

  @ManagedOperation(description="Updates the class model with the classes, typedefs and valid links in the xml files")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String updateClassModel(Integer customerID)
  {
    StringWriter stringWriter;
    setCustomerID(customerID);
    try {
      CmdbClassModelUtil.updateClassModelFromResources(createOperationExecutor());
      return "Class model update succeeded";
    }
    catch (Exception e) {
      stringWriter = new StringWriter();
      e.printStackTrace(new PrintWriter(stringWriter)); }
    return XmlUtils.convertStringWithXmlTags(stringWriter.toString());
  }

  @ManagedOperation(description="Deprecated. Use updateClassModel. Updates the class model with the classes, typedefs and valid links in the xml files")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="folderPath", description="Folder or File path (the operation will update only files that ends with _deployment.xml)")})
  public String updateClassModelFromFolder(Integer customerID, String folderPath)
  {
    StringWriter stringWriter;
    setCustomerID(customerID);
    try {
      CmdbClassModelUtil.updateClassModelFromFolder(createOperationExecutor(), folderPath);
      return "Class model update from folder [" + folderPath + "] succeeded";
    }
    catch (Exception e) {
      stringWriter = new StringWriter();
      e.printStackTrace(new PrintWriter(stringWriter)); }
    return XmlUtils.convertStringWithXmlTags(stringWriter.toString());
  }

  @ManagedOperation(description="Reloads the class model from persistency")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String reloadClassModelFromPersistency(Integer customerID)
  {
    StringWriter stringWriter;
    setCustomerID(customerID);
    try {
      ClassModelCommandLoadFromPersistency loadFromPersistency = new ClassModelCommandLoadFromPersistency();
      invokeOperation(loadFromPersistency);
      return "Class model reload from persistency succeeded";
    }
    catch (Exception e) {
      stringWriter = new StringWriter();
      e.printStackTrace(new PrintWriter(stringWriter)); }
    return XmlUtils.convertStringWithXmlTags(stringWriter.toString());
  }

  private String replaceClassNameByHyperLink(String htmlString, String prefix, String postfix)
  {
    StringBuilder result = new StringBuilder();
    int currentPos = 0;
    while (true) {
      int stringStart = htmlString.indexOf(prefix, currentPos);
      if (stringStart < 0)
        break;

      int openingQuote = stringStart + prefix.length();
      int closingQuote = htmlString.indexOf(postfix, openingQuote);
      String superClassName = htmlString.substring(openingQuote, closingQuote);
      if (!(superClassName.equals("none"))) {
        result.append(htmlString.substring(currentPos, openingQuote)).append(generateClassDefHyperlink(superClassName));
      }
      else
        result.append(htmlString.substring(currentPos, closingQuote));

      currentPos = closingQuote;
    }
    result.append(htmlString.substring(currentPos, htmlString.length()));
    return result.toString();
  }

  private String generateClassDefHyperlink(String className) {
    return "<a href='" + JMXUtils.generateMethodHyperlink(getClass(), "retrieveCmdbClassXml", new Object[] { className }) + "'>" + className + "</a>";
  }

  private String generateClassDefHyperlink(String className, String linkText)
  {
    return "<a href='" + JMXUtils.generateMethodHyperlink(getClass(), "retrieveCmdbClassXml", new Object[] { className }) + "'>" + linkText + "</a>";
  }

  @ManagedOperation(description="Export Class Model")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="path", description="Path")})
  public String exportClassModelToXml(Integer customerID, String path)
  {
    setCustomerID(customerID);
    return exportClassModel(path);
  }

  private String exportClassModel(String path) {
    String str1;
    String result = "";
    CmdbClassModel classModel = getCmdbClassModel();

    CmdbClassModelDefinition classModelDefinition = CmdbClassModelFactory.createCmdbClassModelDefinition(classModel);
    String xml = XMLBuilder.toXml(classModelDefinition);
    try {
      xml = sortXML(xml);
    } catch (Exception e) {
      result = "Failed to parse the XML in order to sort it. ";
    }

    FileWriter fw = null;
    try {
      fw = new FileWriter(path);
      fw.write(xml);
      fw.flush();
    }
    catch (FileNotFoundException e) {
      result = result + "Can't create file [" + path + "]";
      str1 = result;

      return str1;
    }
    catch (IOException e)
    {
      result = result + "Failed to export Class Model to file [" + path + "] due to the following error: " + e.getMessage();
      str1 = result;

      return str1;
    }
    finally
    {
      if (fw != null)
        try {
          fw.close();
        }
        catch (IOException e)
        {
        }
    }

    return result + "Class Model was exported to xml and saved at " + path;
  }

  @ManagedOperation(description="Export Class Model to CSV Files")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="path", description="Path for CSV files")})
  public String exportClassModelToCSV(Integer customerID, String path)
  {
    setCustomerID(customerID);
    return exportClassModel2CSV(path);
  }

  private String exportClassModel2CSV(String path) {
    String classFile = "CITypes.csv";
    String validLinksFile = "CITValidRelationships.csv";
    String attrFile = "CITAttributes.csv";
    String enumsFile = "CITEnums.csv";
    String classQualif = "DOCUMENTED";
    String attrQualif = "DOCUMENTED";
    String delimiter = ",";
    String classHeader = "CIType Name,Super CIType,Type,Description";
    String vlinksHeader = "Source,Target,Relationship,Description";
    String attrHeader = "CIType Name,Attribute Name,Is Key,Type,Default Value,Description";
    String enumsHeader = "Name,Values,Description";
    String objTitle = "CI";
    String linkTitle = "Relationship";

    if (StringUtils.isEmpty(path)) return "Path cannot be empty.";

    String result = "";
    if (!(path.endsWith(File.separator))) {
      path = path + File.separator;
    }

    CmdbClassModel classModel = getCmdbClassModel();
    List availClasses = new ArrayList();
    List availLinks = new ArrayList();

    result = exportClasses2CSV(classModel, "DOCUMENTED", ",", "CIType Name,Super CIType,Type,Description", path + "CITypes.csv", "CI", "Relationship", availClasses, availLinks);

    if (!(StringUtils.isEmpty(result))) {
      return result;
    }

    result = exportValidLinks2CSV(classModel, ",", "Source,Target,Relationship,Description", path + "CITValidRelationships.csv", availClasses, availLinks);

    if (!(StringUtils.isEmpty(result))) {
      return result;
    }

    result = exportAttr2CSV(classModel, "DOCUMENTED", ",", "CIType Name,Attribute Name,Is Key,Type,Default Value,Description", path + "CITAttributes.csv", availClasses, availLinks);

    if (!(StringUtils.isEmpty(result))) {
      return result;
    }

    result = exportEnums2CSV(classModel, ",", "Name,Values,Description", path + "CITEnums.csv");
    if (!(StringUtils.isEmpty(result))) {
      return result;
    }

    return "Class Model was exported to CSV files at " + path;
  }

  private String exportClasses2CSV(CmdbClassModel classModel, String qualif, String delimiter, String header, String fileName, String objTitle, String linkTitle, List<String> availClasses, List<String> availLinks)
  {
    CmdbClass c;
    String result = "";

    CmdbClasses cls = classModel.getClassesByQualifier(qualif);
    List classes = new ArrayList(cls.getSize());
    ReadOnlyIterator it = cls.getIterator();
    while (it.hasNext()) {
      classes.add(it.next());
    }

    if (classes.isEmpty()) return "No classes to export.";

    Collections.sort(classes, new Comparator(this) {
      public int compare(, CmdbClass o2) {
        if ((o1 == null) || (o2 == null)) { return 0;
        }

        if ((o1.isTypeOfObject()) && (!(o2.isTypeOfObject())))
          return -1;

        if ((!(o1.isTypeOfObject())) && (o2.isTypeOfObject())) {
          return 1;
        }

        return o1.getDisplayName().compareTo(o2.getDisplayName());
      }

    });
    for (Iterator i$ = classes.iterator(); i$.hasNext(); ) { CmdbClass c = (CmdbClass)i$.next();

      if (c.isTypeOfObject()) {
        availClasses.add(c.getName());
      }
      else {
        availLinks.add(c.getName());
      }

    }

    PrintWriter fw = null;
    try {
      fw = new PrintWriter(new FileWriter(new File(fileName)));
      fw.println(header);
      for (Iterator i$ = classes.iterator(); i$.hasNext(); ) { String superCls;
        c = (CmdbClass)i$.next();
        String type = (c.isTypeOfObject()) ? objTitle : linkTitle;
        if (c.getResolvedSuperClass() != null) {
          superCls = c.getResolvedSuperClass().getDisplayName();
        }
        else
          superCls = "";

        String descr = "\"" + c.getDescription() + "\"";
        fw.println(c.getDisplayName() + delimiter + superCls + delimiter + type + delimiter + descr);
      }
      fw.flush();
    }
    catch (FileNotFoundException e) {
      result = result + "Cannot create file [" + fileName + "]:" + e.getMessage();
      c = result;

      return c;
    }
    catch (IOException e)
    {
      result = result + "Failed to export Class Model to file [" + fileName + "] due to the following error: " + e.getMessage();
      c = result;

      return c;
    }
    finally
    {
      if (fw != null)
        fw.close();
    }

    return result;
  }

  private String exportValidLinks2CSV(CmdbClassModel classModel, String delimiter, String header, String fileName, List<String> availClasses, List<String> availLinks)
  {
    String result = "";

    CmdbValidLinks vlinks = classModel.getAllValidLinks();
    List links = new ArrayList(vlinks.getSize());
    ReadOnlyIterator it = vlinks.getIterator();
    while (it.hasNext()) {
      CmdbValidLink lnk = (CmdbValidLink)it.next();
      if (isLinkToExport(lnk, availClasses, availLinks))
        links.add(lnk);

    }

    if (!(links.isEmpty())) {
      CmdbValidLink vl;
      Collections.sort(links, new Comparator(this, classModel) {
        public int compare(, CmdbValidLink o2) {
          if ((o1 == null) || (o2 == null)) return 0;

          if (!(o1.getEnd1ClassName().equals(o2.getEnd1ClassName())))
            return CmdbClassModelUtil.getCmdbClassDisplayName(this.val$classModel, o1.getEnd1ClassName()).compareTo(CmdbClassModelUtil.getCmdbClassDisplayName(this.val$classModel, o2.getEnd1ClassName()));

          if (!(o1.getEnd2ClassName().equals(o2.getEnd2ClassName()))) {
            return CmdbClassModelUtil.getCmdbClassDisplayName(this.val$classModel, o1.getEnd2ClassName()).compareTo(CmdbClassModelUtil.getCmdbClassDisplayName(this.val$classModel, o2.getEnd2ClassName()));
          }

          return CmdbClassModelUtil.getCmdbClassDisplayName(this.val$classModel, o1.getLinkClassName()).compareTo(CmdbClassModelUtil.getCmdbClassDisplayName(this.val$classModel, o2.getLinkClassName()));
        }

      });
      PrintWriter fw = null;
      try {
        fw = new PrintWriter(new FileWriter(new File(fileName)));
        fw.println(header);
        for (Iterator i$ = links.iterator(); i$.hasNext(); ) { vl = (CmdbValidLink)i$.next();
          String descr = "\"" + vl.getDescription() + "\"";
          fw.println(CmdbClassModelUtil.getCmdbClassDisplayName(classModel, vl.getEnd1ClassName()) + delimiter + CmdbClassModelUtil.getCmdbClassDisplayName(classModel, vl.getEnd2ClassName()) + delimiter + CmdbClassModelUtil.getCmdbClassDisplayName(classModel, vl.getLinkClassName()) + delimiter + descr);
        }

        fw.flush();
      }
      catch (FileNotFoundException e) {
        result = result + "Cannot create file [" + fileName + "]:" + e.getMessage();
        vl = result;

        return vl;
      }
      catch (IOException e)
      {
        result = result + "Failed to export Class Model to file [" + fileName + "] due to the following error: " + e.getMessage();
        vl = result;

        return vl;
      }
      finally
      {
        if (fw != null)
          fw.close();
      }
    }

    return result;
  }

  private boolean isLinkToExport(CmdbValidLink lnk, List<String> availClasses, List<String> availLinks) {
    if ((lnk == null) || (availClasses == null) || (availLinks == null)) return false;

    CmdbClassModel classModel = getCmdbClassModel();
    boolean end1In = false; boolean end2In = false;
    for (Iterator i$ = availClasses.iterator(); i$.hasNext(); ) { String cls = (String)i$.next();
      if ((!(end1In)) && (((cls.equalsIgnoreCase(lnk.getEnd1ClassName())) || (classModel.isDescendant(cls, lnk.getEnd1ClassName())))))
        end1In = true;

      if ((!(end2In)) && (((cls.equalsIgnoreCase(lnk.getEnd2ClassName())) || (classModel.isDescendant(cls, lnk.getEnd2ClassName())))))
        end2In = true;

      if ((end1In) && (end2In)) {
        break;
      }

    }

    return ((end1In) && (end2In) && (availLinks.contains(lnk.getLinkClassName())));
  }

  private String exportAttr2CSV(CmdbClassModel classModel, String qualif, String delimiter, String header, String fileName, List<String> availClasses, List<String> availLinks)
  {
    String cls;
    List res;
    Iterator i$;
    CmdbAttribute at;
    String result = "";

    List attr = new ArrayList();
    for (Iterator i$ = availClasses.iterator(); i$.hasNext(); ) { cls = (String)i$.next();
      res = CmdbClassModelUtil.getAttributesByQualifier(classModel, cls, qualif);
      if (res != null)
        for (i$ = res.iterator(); i$.hasNext(); ) { at = (CmdbAttribute)i$.next();
          attr.add(getAttrDisplayStr(classModel, at, cls, delimiter));
        }
    }

    for (i$ = availLinks.iterator(); i$.hasNext(); ) { cls = (String)i$.next();
      res = CmdbClassModelUtil.getAttributesByQualifier(classModel, cls, qualif);
      if (res != null)
        for (i$ = res.iterator(); i$.hasNext(); ) { at = (CmdbAttribute)i$.next();
          attr.add(getAttrDisplayStr(classModel, at, cls, delimiter));
        }

    }

    if (!(attr.isEmpty())) {
      String at;
      PrintWriter fw = null;
      try {
        fw = new PrintWriter(new FileWriter(new File(fileName)));
        fw.println(header);
        for (Iterator i$ = attr.iterator(); i$.hasNext(); ) { at = (String)i$.next();
          fw.println(at);
        }
        fw.flush();
      }
      catch (FileNotFoundException e) {
        result = result + "Cannot create file [" + fileName + "]:" + e.getMessage();
        at = result;

        return at;
      }
      catch (IOException e)
      {
        result = result + "Failed to export Class Model to file [" + fileName + "] due to the following error: " + e.getMessage();
        at = result;

        return at;
      }
      finally
      {
        if (fw != null)
          fw.close();
      }
    }

    return result;
  }

  private String getAttrDisplayStr(CmdbClassModel classModel, CmdbAttribute attr, String cls, String delimiter) {
    if ((classModel == null) || (attr == null) || (StringUtils.isEmpty(cls))) return "";

    String isKey = (attr.hasQualifier(com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs.ID_ATTRIBUTE.getName())) ? "True" : "";
    String descr = "\"" + attr.getDescription() + "\"";
    String result = CmdbClassModelUtil.getCmdbClassDisplayName(classModel, cls) + delimiter + CmdbClassModelUtil.getAttributeDisplayName(attr) + delimiter + isKey + delimiter + attr.getResolvedType().getDisplayName() + delimiter + CmdbClassModelUtil.getAttributeDefaultValue(classModel, attr) + delimiter + descr;

    return result;
  }

  private String exportEnums2CSV(CmdbClassModel classModel, String delimiter, String header, String fileName) {
    int SIZE_LIMIT = 5;
    String result = "";

    List enums = new ArrayList();

    ReadOnlyIterator it = classModel.getAllTypeDefs().getIterator();
    List tdefs = new ArrayList();
    while (it.hasNext())
      tdefs.add(it.next());

    Collections.sort(tdefs, new Comparator(this) {
      public int compare(, CmdbTypeDef o2) {
        if ((o1 == null) || (o2 == null)) return 0;

        return o1.getDisplayName().compareTo(o2.getDisplayName());
      }

    });
    for (Iterator i$ = tdefs.iterator(); i$.hasNext(); ) { List vals;
      ReadOnlyIterator iter;
      label213: String descr;
      CmdbTypeDef td = (CmdbTypeDef)i$.next();
      if (td instanceof CmdbEnum) {
        CmdbEnum enm = (CmdbEnum)td;
        vals = new ArrayList(enm.getSize());
        iter = enm.getEnumerators();
        while (true) { if (!(iter.hasNext())) break label213;
          if (vals.size() >= 5) break;
          vals.add(((CmdbEnumEntry)iter.next()).getEnumValue().toString());
        }

        vals.add("...");

        descr = "\"" + enm.getDescription() + "\"";
        label422: enums.add(enm.getDisplayName() + delimiter + vals.toString().replaceAll(",", ";") + delimiter + descr);
      }
      else if (td instanceof CmdbList) {
        CmdbList lst = (CmdbList)td;
        vals = new ArrayList(lst.getSize());
        iter = lst.getValuesIterator();
        while (true) { if (!(iter.hasNext())) break label422;
          if (vals.size() >= 5) break;
          vals.add(((CmdbListEntry)iter.next()).getListValue().toString());
        }

        vals.add("...");

        descr = "\"" + lst.getDescription() + "\"";
        enums.add(lst.getDisplayName() + delimiter + vals.toString().replaceAll(",", ";") + delimiter + descr);
      }
    }

    if (!(enums.isEmpty())) {
      String at;
      PrintWriter fw = null;
      try {
        fw = new PrintWriter(new FileWriter(new File(fileName)));
        fw.println(header);
        for (Iterator i$ = enums.iterator(); i$.hasNext(); ) { at = (String)i$.next();
          fw.println(at);
        }
        fw.flush();
      }
      catch (FileNotFoundException e) {
        result = result + "Cannot create file [" + fileName + "]:" + e.getMessage();
        at = result;

        return at;
      }
      catch (IOException e)
      {
        result = result + "Failed to export Class Model to file [" + fileName + "] due to the following error: " + e.getMessage();
        at = result;

        return at;
      }
      finally
      {
        if (fw != null)
          fw.close();
      }
    }

    return result;
  }

  private String sortXML(String xml) throws JDOMException, IOException {
    SAXBuilder saxBuilder = new SAXBuilder();
    Document document = saxBuilder.build(new StringReader(xml));
    sortXMLByName(document.getRootElement());
    XMLOutputter xmlOutputter = new XMLOutputter();
    xmlOutputter.setIndent("\t");
    xmlOutputter.setNewlines(true);
    StringWriter stringWriter = new StringWriter();
    xmlOutputter.output(document, stringWriter);
    xml = stringWriter.toString();
    return xml;
  }

  private void sortXMLByName(Element element)
  {
    removeWhiteSpace(element);
    for (Iterator i$ = element.getChildren().iterator(); i$.hasNext(); ) { Object child = i$.next();
      sortXMLByName((Element)child);
    }

    List children = new ArrayList(element.getChildren());
    Map namedChildren = getNamedChildrenNames(children);
    Set processedChildrenTypes = new HashSet();
    for (Iterator i$ = children.iterator(); i$.hasNext(); ) { Element child = (Element)i$.next();
      String childName = child.getName();
      String attributeName = (String)namedChildren.get(childName);
      if (attributeName != null)
      {
        List childrenWithTheSameName = new ArrayList(element.getChildren(childName));
        Collections.sort(childrenWithTheSameName, new Comparator(this, attributeName) {
          public int compare(, Element e2) {
            return e1.getAttributeValue(this.val$attributeName).compareToIgnoreCase(e2.getAttributeValue(this.val$attributeName));
          }

        });
        element.removeChildren(childName);
        for (Iterator i$ = childrenWithTheSameName.iterator(); i$.hasNext(); ) { Element child1 = (Element)i$.next();
          element.addContent(child1);
        }
        namedChildren.remove(childName);
        processedChildrenTypes.add(childName);
      } else if (!(processedChildrenTypes.contains(childName)))
      {
        element.removeContent(child);
        element.addContent(child);
      }
    }
  }

  private void removeWhiteSpace(Element element)
  {
    Iterator childrenIt = element.getContent().iterator();
    while (childrenIt.hasNext()) {
      Object child = childrenIt.next();
      if ((child instanceof Text) && 
        (((Text)child).getTextNormalize().length() == 0))
        childrenIt.remove();
    }
  }

  private Map<String, String> getNamedChildrenNames(List<Element> children)
  {
    Map childrenNames = new HashMap();
    for (Iterator i$ = children.iterator(); i$.hasNext(); ) { Element child = (Element)i$.next();
      String[] arr$ = { "name", "class-name" }; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String attributeName = arr$[i$];
        Attribute nameAttributeValue = child.getAttribute(attributeName);
        if (nameAttributeValue != null) {
          childrenNames.put(child.getName(), attributeName);
          break;
        }
      }
    }
    return childrenNames;
  }

  @ManagedOperation(description="Creates new CI type")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="CI type name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="baseClassName", description="Base CI type name")})
  public String createCIType(Integer customerID, String className, String baseClassName)
  {
    CmdbClassDefinition classDef = CmdbClassFactory.createClassDefinition(className, baseClassName);
    ClassModelUpdateCreateOrUpdateCmdbClass op = new ClassModelUpdateCreateOrUpdateCmdbClass(classDef);
    try {
      invokeOperation(op, customerID);
    } catch (Exception e) {
      return Exceptions.toString(e);
    }

    return retrieveCmdbClassXml(customerID, className);
  }
}