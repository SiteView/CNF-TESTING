package com.mercury.topaz.cmdb.server.base.jmx.enrichmentbusinessview;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.enrichment.admin.operation.update.businessview.impl.EnrichmentUpdateRemoveEnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.command.impl.EnrichmentCommandAdHocBusinessViewCalculator;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.query.impl.EnrichmentQueryGetResultCount;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.update.impl.EnrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewObject;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.businessview.impl.EnrichmentQueryGetEnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.businessview.impl.EnrichmentQueryGetEnrichmentBusinessViewDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.result.EnrichmentResultCount;
import com.mercury.topaz.cmdb.shared.enrichment.definition.util.EnrichmentDefinitionXmlBuilder;
import com.mercury.topaz.cmdb.shared.enrichment.definition.util.impl.EnrichmentDefinitionXmlBuilderFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.PropertyCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetClassAffectedPatterns;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetPattern;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.ResultEntry;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=CMDB Business View Enrichment Services", description="CMDB Business View Enrichment Services")
public class EnrichmentBusinessViewJmxServices extends AbstractCmdbJmx
  implements EnrichmentBusinessViewJmxServicesInterface
{
  private static Log _infoLogger = CmdbLogFactory.getCMDBInfoLog();

  @ManagedOperation(description="Calculate Business View Enrichment")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String calculateAdHocEnrichment(Integer customerID, String enrichmentName)
  {
    setCustomerID(customerID);
    EnrichmentBusinessViewDefinition enrichmentDefinition = retrieveEnrichmentDefinition(enrichmentName);
    if (enrichmentDefinition == null) {
      return "The business view enrichment " + enrichmentName + " does not exist";
    }

    EnrichmentCommandAdHocBusinessViewCalculator command = new EnrichmentCommandAdHocBusinessViewCalculator(enrichmentName);
    invokeOperation(command);
    return "operation succeeded";
  }

  @ManagedOperation(description="Show Business View Enrichment definition as xml")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String exportEnrichment(Integer customerID, String enrichmentName)
  {
    setCustomerID(customerID);
    EnrichmentBusinessViewDefinition enrichmentDefinition = retrieveEnrichmentDefinition(enrichmentName);
    if (enrichmentDefinition == null)
      return "The business view enrichment " + enrichmentName + " does not exist";

    EnrichmentDefinitionXmlBuilder enrichmentDefinitionXmlBuilder = EnrichmentDefinitionXmlBuilderFactory.create();
    return enrichmentDefinitionXmlBuilder.toXml((EnrichmentDefinition)enrichmentDefinition);
  }

  @ManagedOperation(description="Show list of Business View Enrichments defined in CMDB")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String retrieveAllEnrichmentNames(Integer customerID)
  {
    setCustomerID(customerID);
    EnrichmentQueryGetEnrichmentBusinessViewDefinitions query = new EnrichmentQueryGetEnrichmentBusinessViewDefinitions();
    invokeOperation(query);
    EnrichmentBusinessViewDefinitions definitions = query.getEnrichmentDefinitions();
    if (definitions == null)
      return "There are no business view enrichments defined in CMDB!";

    StringBuffer result = new StringBuffer();
    result.append("Business View Enrichment defined in CMDB:\n");
    int count = 0;
    ReadOnlyIterator itr = definitions.getElementsIterator();
    while (itr.hasNext()) {
      EnrichmentBusinessViewDefinition definition = (EnrichmentBusinessViewDefinition)itr.next();
      result.append(definition.getEnrichmentName() + '\n');
      ++count;
    }
    result.append("\nTotal number of business view enrichments: " + count);
    return result.toString();
  }

  @ManagedOperation(description="Remove Business View Enrichment")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String removeEnrichment(Integer customerID, String enrichmentName)
  {
    setCustomerID(customerID);
    EnrichmentBusinessViewDefinition enrichmentDefinition = retrieveEnrichmentDefinition(enrichmentName);
    if (enrichmentDefinition == null) {
      return "The business view enrichment " + enrichmentName + " does not exist";
    }

    EnrichmentUpdateRemoveEnrichmentBusinessViewDefinition remove = new EnrichmentUpdateRemoveEnrichmentBusinessViewDefinition(enrichmentName);
    invokeOperation(remove);
    return "operation succeeded";
  }

  @ManagedOperation(description="Remove Business View Enrichment Results")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String removeEnrichmentResults(Integer customerID, String enrichmentName)
  {
    setCustomerID(customerID);
    EnrichmentBusinessViewDefinition enrichmentDefinition = retrieveEnrichmentDefinition(enrichmentName);
    if (enrichmentDefinition == null) {
      return "The business view enrichment " + enrichmentName + " does not exist";
    }

    EnrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment remove = new EnrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment(enrichmentName);
    invokeOperation(remove);
    return "operation succeeded";
  }

  @ManagedOperation(description="Retrieve Business View Enrichment Result counts")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String retrieveEnrichmentResultCount(Integer customerID, String enrichmentName)
  {
    setCustomerID(customerID);
    EnrichmentResultCount count = findEnrichmentResultCount(enrichmentName);
    if (count == null)
      return "The business view enrichment " + enrichmentName + " does not exist";

    return String.valueOf(count.size());
  }

  protected EnrichmentResultCount findEnrichmentResultCount(String enrichmentName) {
    EnrichmentBusinessViewDefinition enrichmentDefinition = retrieveEnrichmentDefinition(enrichmentName);
    if (enrichmentDefinition == null) {
      return null;
    }

    EnrichmentQueryGetResultCount query = new EnrichmentQueryGetResultCount((EnrichmentDefinition)enrichmentDefinition);
    invokeOperation(query);
    return query.getResultCount();
  }

  private EnrichmentBusinessViewDefinition retrieveEnrichmentDefinition(String enrichmentName) {
    EnrichmentQueryGetEnrichmentBusinessViewDefinition enrichmentQueryGetEnrichmentDefinition = new EnrichmentQueryGetEnrichmentBusinessViewDefinition(enrichmentName);
    invokeOperation(enrichmentQueryGetEnrichmentDefinition);
    EnrichmentBusinessViewDefinition enrichmentDefinition = enrichmentQueryGetEnrichmentDefinition.getEnrichmentDefinition();
    if (enrichmentDefinition == null) {
      String msg = "Business View Enrichment: " + enrichmentName + " doesn't exist in CMDB!";
      _infoLogger.info(msg);
      return null;
    }
    return enrichmentDefinition;
  }

  @ManagedOperation(description="Retrieve Business View Enrichment Result counts per element number")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="enrichmentName", description="Enrichment name")})
  public String retrieveEnrichmentResultCountByElementNumbers(Integer customerID, String enrichmentName)
  {
    setCustomerID(customerID);
    EnrichmentResultCount rcount = findEnrichmentResultCount(enrichmentName);
    StringBuffer result = new StringBuffer();
    if (rcount == null)
      return "The business view enrichment " + enrichmentName + " does not exist";

    result.append("Objects Entries:\n");
    ReadOnlyIterator oItr = rcount.getObjectResultEntriesIterator();
    while (oItr.hasNext()) {
      ResultEntry oEntry = (ResultEntry)oItr.next();
      result.append("Element Number:" + oEntry.getElementNumber() + "\tcount:" + oEntry.size() + '\n');
    }

    result.append("Links Entries:\n");
    ReadOnlyIterator lItr = rcount.getLinkResultEntriesIterator();
    while (lItr.hasNext()) {
      ResultEntry lEntry = (ResultEntry)lItr.next();
      result.append("Element Number:" + lEntry.getElementNumber() + "\tcount:" + lEntry.size() + '\n');
    }
    return result.toString();
  }

  @ManagedOperation(description="Retrieve Pattern names of pattern that use the valid link logical_application->depends_on->object")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String retrievePatternWithOldBusinessViewLink(Integer customerID)
  {
    setCustomerID(customerID);

    TqlQueryGetClassAffectedPatterns affectedPatterns = new TqlQueryGetClassAffectedPatterns("logical_application");
    invokeOperation(affectedPatterns);
    ArrayList patternNames = affectedPatterns.getPatternNames();
    StringBuffer result = new StringBuffer();
    result.append("The following patterns contains the link [logical_application->depends_on->object] :\n");

    Map allApplicationsProperties = fillApplicationProperties(getCustomerID().getID());
    boolean found = false;
    for (Iterator i$ = patternNames.iterator(); i$.hasNext(); ) { Object patternName = i$.next();
      found = false;
      TqlQueryGetPattern getPattern = new TqlQueryGetPattern((String)patternName);
      invokeOperation(getPattern);
      Pattern affectedPattern = getPattern.getPattern();
      ReadOnlyIterator patternLinkItr = affectedPattern.getPatternGraph().getLinksIterator();
      while (patternLinkItr.hasNext()) {
        PatternLink link = (PatternLink)patternLinkItr.next();
        if (link.getLinkCondition().getClassCondition().getClassName().equals("depends_on")) {
          PatternElementNumber end1Number = link.getEnd1Number();
          PatternElementNumber end2Number = link.getEnd2Number();
          PatternNode end1 = affectedPattern.getPatternGraph().getNode(end1Number);
          PatternNode end2 = affectedPattern.getPatternGraph().getNode(end2Number);
          ElementPropertiesCondition propertiesCondition = PatternConditionFactory.createElementPropertiesCondition();
          if (getCmdbClassModel().isTypeOf("logical_application", end1.getCondition().getClassCondition().getClassName())) {
            propertiesCondition = end1.getCondition().getPropertiesCondition();
          }
          else if (getCmdbClassModel().isTypeOf("logical_application", end2.getCondition().getClassCondition().getClassName()))
            propertiesCondition = end2.getCondition().getPropertiesCondition();

          ReadOnlyIterator itr = propertiesCondition.getIterator();
          while (itr.hasNext()) {
            PropertyCondition property = (PropertyCondition)itr.next();
            if ((allApplicationsProperties.containsKey(property.getPropertyName())) && 
              (((Set)allApplicationsProperties.get(property.getPropertyName())).contains(property.getPropertyValue())))
              found = true;
          }

        }

        if (found)
          result.append(patternName + "\n");
      }

    }

    return result.toString();
  }

  private Map<String, Set> fillApplicationProperties(int customerID) {
    Map applicationProperties = new HashMap();
    EnrichmentQueryGetEnrichmentBusinessViewDefinitions query = new EnrichmentQueryGetEnrichmentBusinessViewDefinitions();
    invokeOperation(query, Integer.valueOf(customerID));

    ReadOnlyIterator itr = query.getEnrichmentDefinitions().getElementsIterator();
    while (itr.hasNext()) {
      EnrichmentBusinessViewDefinition definition = (EnrichmentBusinessViewDefinition)itr.next();
      EnrichmentBusinessViewObject bvObject = definition.getBusinessViewObject();
      CmdbProperties properties = bvObject.getProperties();
      ReadOnlyIterator propertiesItr = properties.getPropertiesIterator();
      while (propertiesItr.hasNext()) {
        CmdbProperty prop = (CmdbProperty)propertiesItr.next();
        if (applicationProperties.containsKey(prop.getKey())) {
          ((Set)applicationProperties.get(prop.getKey())).add(prop.getValue());
        } else {
          Set values = new HashSet();
          values.add(prop.getValue());
          applicationProperties.put(prop.getKey(), values);
        }
      }
    }
    if (applicationProperties.containsKey("user_label"))
      applicationProperties.put("display_label", applicationProperties.get("user_label"));

    return applicationProperties;
  }
}