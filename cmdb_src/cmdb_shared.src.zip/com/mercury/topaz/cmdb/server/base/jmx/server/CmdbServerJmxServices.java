package com.mercury.topaz.cmdb.server.base.jmx.server;

import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.server.manage.rpm.StopOperation;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.API;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.monitor.operation.query.impl.DumpOperationStatisticsOperation;
import com.mercury.topaz.cmdb.shared.manage.monitor.operation.query.impl.DumpServerSnapshotToLog;
import com.mercury.topaz.cmdb.shared.manage.monitor.operation.query.impl.ExecuteRequestTimeoutCallbacks;
import com.mercury.topaz.cmdb.shared.manage.monitor.operation.query.impl.ResetOperationStatisticsOperation;
import com.mercury.topaz.cmdb.shared.manage.monitor.operation.query.impl.ServerMonitorQueryGetCmdbStatus;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.query.impl.GetAllQuotas;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl.QuotaUpdateChangeCustomerQuota;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl.QuotaUpdateChangeServerQuota;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=CMDB Server Services", description="CMDB Server Services")
public class CmdbServerJmxServices extends AbstractCmdbJmx
  implements CmdbServerJmxServicesInterface
{
  @ManagedOperation(description="Dump CMDB Server Snapshot to log file")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="hostName", description="if empty, local host will be used"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="processName", description="<html><table><tr><td>Either select process from the list below or</td></tr><tr><td>type in controller process name: cmdb, mam, mercury_as etc.</td></tr><tr><td>(if empty, JBoss process name will be used - single JVM assumed)</td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=dumpServerSnapshotToLog&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mercury_as'>JBoss</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=dumpServerSnapshotToLog&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb'>CMDB</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=dumpServerSnapshotToLog&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mam'>MAM</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=dumpServerSnapshotToLog&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=fcmdb'>Federation</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=dumpServerSnapshotToLog&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb_res_utils'>Res Utils</a></td></tr></table></html>")})
  public String dumpServerSnapshotToLog(String hostName, String processName)
  {
    DumpServerSnapshotToLog op = new DumpServerSnapshotToLog(hostName, processName);
    invokeOperation(op, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    return op.getServerMonitorInfo();
  }

  @ManagedOperation(description="Get formatted CMDB Server Snapshot")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="hostName", description="if empty, local host will be used"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="processName", description="<html><table><tr><td>Either select process from the list below or</td></tr><tr><td>type in controller process name: cmdb, mam, mercury_as etc.</td></tr><tr><td>(if empty, JBoss process name will be used - single JVM assumed)</td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=getFormattedServerSnapshot&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mercury_as'>JBoss</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=getFormattedServerSnapshot&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb'>CMDB</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=getFormattedServerSnapshot&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mam'>MAM</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=getFormattedServerSnapshot&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=fcmdb'>Federation</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=getFormattedServerSnapshot&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb_res_utils'>Res Utils</a></td></tr></table></html>")})
  public String getFormattedServerSnapshot(String hostName, String processName)
  {
    ServerMonitorQueryGetCmdbStatus getFrameworkStatus = new ServerMonitorQueryGetCmdbStatus(hostName, processName, true);
    invokeOperation(getFrameworkStatus, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    return getFrameworkStatus.getServerMonitorInfo();
  }

  @ManagedOperation(description="Get CMDB Server Snapshot")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="hostName", description="if empty, local host will be used"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="processName", description="<html><table><tr><td>Either select process from the list below or</td></tr><tr><td>type in controller process name: cmdb, mam, mercury_as etc.</td></tr><tr><td>(if empty, JBoss process name will be used - single JVM assumed)</td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=getServerSnapshot&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mercury_as'>JBoss</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=getServerSnapshot&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb'>CMDB</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=getServerSnapshot&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mam'>MAM</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=getServerSnapshot&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=fcmdb'>Federation</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=getServerSnapshot&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb_res_utils'>Res Utils</a></td></tr></table></html>")})
  public String getServerSnapshot(String hostName, String processName)
  {
    ServerMonitorQueryGetCmdbStatus getFrameworkStatus = new ServerMonitorQueryGetCmdbStatus(hostName, processName, false);
    invokeOperation(getFrameworkStatus, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    return getFrameworkStatus.getServerMonitorInfo();
  }

  @ManagedOperation(description="Execute request timeout callbacks")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="hostName", description="if empty, local host will be used"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="processName", description="<html><table><tr><td>Either select process from the list below or</td></tr><tr><td>type in controller process name: cmdb, mam, mercury_as etc.</td></tr><tr><td>(if empty, JBoss process name will be used - single JVM assumed)</td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=executeRequestTimeoutCallbacks&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mercury_as'>JBoss</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=executeRequestTimeoutCallbacks&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb'>CMDB</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=executeRequestTimeoutCallbacks&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mam'>MAM</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=executeRequestTimeoutCallbacks&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=fcmdb'>Federation</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=executeRequestTimeoutCallbacks&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb_res_utils'>Res Utils</a></td></tr></table></html>")})
  public void executeRequestTimeoutCallbacks(String hostName, String processName)
  {
    FrameworkOperation op = new ExecuteRequestTimeoutCallbacks(hostName, processName);
    invokeOperation(op, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
  }

  @ManagedOperation(description="Stop operation")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="operationID", description="can be obtained from server snapshot"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="hostName", description="if empty, local host will be used"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="processName", description="controller process name: cmdb, mam, mercury_as etc.")})
  public void stopOperation(int operationID, String hostName, String processName)
  {
    FrameworkOperation op = new StopOperation(operationID, hostName, processName);
    invokeOperation(op, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
  }

  @ManagedOperation(description="Dump CMDB Server Operation Statistics to the screen")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="hostName", description="if empty, local host will be used"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="processName", description="<html><table><tr><td>Either select process from the list below or</td></tr><tr><td>type in controller process name: cmdb, mam, mercury_as etc.</td></tr><tr><td>(if empty, JBoss process name will be used - single JVM assumed)</td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=dumpOperationStatistics&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mercury_as'>JBoss</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=dumpOperationStatistics&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb'>CMDB</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=dumpOperationStatistics&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mam'>MAM</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=dumpOperationStatistics&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=fcmdb'>Federation</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=dumpOperationStatistics&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb_res_utils'>Res Utils</a></td></tr></table></html>")})
  public String dumpOperationStatistics(String hostName, String processName)
  {
    DumpOperationStatisticsOperation op = new DumpOperationStatisticsOperation(hostName, processName);
    invokeOperation(op, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    return XmlUtils.convertStringWithXmlTags(op.getServerMonitorInfo());
  }

  @ManagedOperation(description="Reset CMDB Server Operation Statistics and write dump to log (cmdb.operation.statistics.log)")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="hostName", description="if empty, local host will be used"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="processName", description="<html><table><tr><td>Either select process from the list below or</td></tr><tr><td>type in controller process name: cmdb, mam, mercury_as etc.</td></tr><tr><td>(if empty, JBoss process name will be used - single JVM assumed)</td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=resetOperationStatistics&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mercury_as'>JBoss</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=resetOperationStatistics&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb'>CMDB</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=resetOperationStatistics&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=mam'>MAM</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=resetOperationStatistics&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=fcmdb'>Federation</a></td></tr><tr><td><a href='HtmlAdaptor?action=invokeOpByName&name=Topaz%3Aservice%3DCMDB+Server+Services&methodName=resetOperationStatistics&argType=java.lang.String&arg0=&argType=java.lang.String&arg1=cmdb_res_utils'>Res Utils</a></td></tr></table></html>")})
  public void resetOperationStatistics(String hostName, String processName)
  {
    ResetOperationStatisticsOperation op = new ResetOperationStatisticsOperation(hostName, processName);
    invokeOperation(op, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
  }

  @ManagedOperation(description="Get quotas and counts")
  public String retrieveCurrentQuotasAndCounts()
  {
    GetAllQuotas op = new GetAllQuotas();
    invokeOperation(op, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    Map quotaAndCountInfo = op.getCustomerQuotas();
    Map serverQuotaAndCountInfo = op.getServerQuotas();

    StringBuilder sb = new StringBuilder();
    Set serverQuotas = serverQuotaAndCountInfo.keySet();
    sb.append("\n SERVER QUOTAS: ");
    for (Iterator i$ = serverQuotas.iterator(); i$.hasNext(); ) { String serverQuotaName = (String)i$.next();
      QuotaCount serverQuotaCount = (QuotaCount)serverQuotaAndCountInfo.get(serverQuotaName);
      sb.append("\n   quota name: ").append(serverQuotaName);
      sb.append(" , count: ").append(serverQuotaCount.getCount());
      sb.append(" , quota: ").append(serverQuotaCount.getQuota());
    }

    sb.append("\n\nCUSTOMER QUOTAS: ");

    Set customerIDS = quotaAndCountInfo.keySet();
    for (Iterator i$ = customerIDS.iterator(); i$.hasNext(); ) { CmdbCustomerID customerID = (CmdbCustomerID)i$.next();
      sb.append("\nCUSTOMER ID: ").append(customerID);
      CustomerQuotasAndCounts customerQuotasAndCounts = (CustomerQuotasAndCounts)quotaAndCountInfo.get(customerID);
      Set quotaNames = customerQuotasAndCounts.getQuotaNames();
      for (Iterator i$ = quotaNames.iterator(); i$.hasNext(); ) { String quotaName = (String)i$.next();
        QuotaCount quotaCount = customerQuotasAndCounts.getQuotaCount(quotaName);
        sb.append("\n   quota name: ").append(quotaName);
        sb.append(" , count: ").append(quotaCount.getCount());
        sb.append(" , quota: ").append(quotaCount.getQuota());
      }
    }
    return sb.toString();
  }

  @ManagedOperation(description="Set Server Quota (temporary till next restart of CMDB Server)")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="quotaName", description="Server Quota Name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="quota", description="New Quota Value")})
  public String defineServerQuota(String quotaName, int quota)
  {
    QuotaUpdateChangeServerQuota changeServerQuota = new QuotaUpdateChangeServerQuota(quotaName.trim(), quota);
    invokeOperation(changeServerQuota, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
    return "operation succeeded";
  }

  @ManagedOperation(description="Set Customer Quota (temporary till next load of this customer)")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="quotaName", description="Server Quota Name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="quota", description="New Quota Value")})
  public String defineCustomerQuota(Integer customerID, String quotaName, int quota)
  {
    QuotaUpdateChangeCustomerQuota changeCustomerQuota = new QuotaUpdateChangeCustomerQuota(createCustomerID(customerID), quotaName.trim(), quota);

    invokeOperation(changeCustomerQuota, customerID);
    return "operation succeeded";
  }
}