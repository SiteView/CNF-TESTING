package com.mercury.topaz.cmdb.server.base.jmx.server;

public abstract interface CmdbServerJmxServicesInterface
{
  public abstract String getServerSnapshot(String paramString1, String paramString2);

  public abstract String dumpServerSnapshotToLog(String paramString1, String paramString2);

  public abstract String dumpOperationStatistics(String paramString1, String paramString2);

  public abstract void resetOperationStatistics(String paramString1, String paramString2);

  public abstract String retrieveCurrentQuotasAndCounts();

  public abstract String defineServerQuota(String paramString, int paramInt);

  public abstract String defineCustomerQuota(Integer paramInteger, String paramString, int paramInt);

  public abstract void executeRequestTimeoutCallbacks(String paramString1, String paramString2);
}