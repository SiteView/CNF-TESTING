package com.mercury.topaz.cmdb.server.base.jmx.common;

public abstract interface CommonJmxServicesInterface
{
  public abstract String retrieveCustomerCapacity(Integer paramInteger);

  public abstract String retrieveCMDBCapacity();
}