package com.mercury.topaz.cmdb.server.base.jmx.dal;

import com.mercury.infra.utils.db.pools.ConnectionManager;
import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.environment.BasicLocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.environment.subsystem.impl.DalCmdbSubsystemEnvironment;
import com.mercury.topaz.cmdb.server.manage.settings.InternalSettings;
import com.mercury.topaz.cmdb.server.upgrade.operation.RunUpgraderOperation;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl.CmdbCustomerQueryGetCmdbVersion;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl.CmdbCustomerQueryGetDbContext;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl.CmdbCustomerQueryGetSubsystemEnvironment;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.update.impl.CmdbCustomerUpdateOptimizeStorage;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.update.impl.CmdbCustomerUpdateSetCmdbVersion;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.update.impl.CmdbCustomerUpdateUpdateSubsystemEnvironment;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=CMDB Dal services", description="CMDB Dal services")
public class CmdbDalJmxServices extends AbstractCmdbJmx
  implements CmdbDalJmxServicesInterface
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalJmxServices.class);

  @ManagedOperation(description="Set disable coarse grain elements insert")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="disableCoarseGrainElementsInsert", description="Disable coarse grain elements insert value")})
  public void setDisableCoarseGrainElementsInsert(Integer customerID, boolean disableCoarseGrainElementsInsert)
  {
    CmdbCustomerID cmdbCustomerID = createCustomerID(customerID);

    DalCmdbSubsystemEnvironment subsystemEnvironment = new DalCmdbSubsystemEnvironment(disableCoarseGrainElementsInsert);
    CmdbCustomerUpdateUpdateSubsystemEnvironment updateSubsystemEnvironment = new CmdbCustomerUpdateUpdateSubsystemEnvironment(cmdbCustomerID, subsystemEnvironment);

    invokeOperation(updateSubsystemEnvironment, customerID);
  }

  @ManagedOperation(description="Is disable coarse grain elements insert")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public boolean isDisableCoarseGrainElementsInsert(Integer customerID)
  {
    CmdbCustomerQueryGetSubsystemEnvironment getSubsystemEnvironmentQuery = new CmdbCustomerQueryGetSubsystemEnvironment(FrameworkConstants.Subsystem.DAL);
    invokeOperation(getSubsystemEnvironmentQuery, customerID);

    DalCmdbSubsystemEnvironment dalSubsystemEnvironment = (DalCmdbSubsystemEnvironment)getSubsystemEnvironmentQuery.getSubsystemEnvironment();
    return dalSubsystemEnvironment.isDisableCoarseGrainElementsInsert();
  }

  @ManagedOperation(description="Run DB statistics")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public void runStatistics(Integer customerID)
  {
    CmdbCustomerID cmdbCustomerID = createCustomerID(customerID);

    CmdbCustomerUpdateOptimizeStorage updateOptimizeStorage = new CmdbCustomerUpdateOptimizeStorage(cmdbCustomerID);
    invokeOperation(updateOptimizeStorage, customerID);
  }

  @ManagedOperation(description="Get cmdb version")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="detailed", description="is detailed report")})
  public String getCmdbVersion(Integer customerID, boolean detailed)
  {
    CmdbCustomerQueryGetCmdbVersion cmdbCustomerQueryGetCmdbVersion = new CmdbCustomerQueryGetCmdbVersion(detailed);
    invokeOperation(cmdbCustomerQueryGetCmdbVersion, customerID);

    return cmdbCustomerQueryGetCmdbVersion.getCmdbVersion();
  }

  @ManagedOperation(description="Run given upgrader within the given service")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="upgraderFullName", description="upgrader full name (as listed in getCmdbVersion()) "), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="serviceName", description="type in controller service name: MAMBASIC, MAMPACKAGER, MAMDISCOVERY, etc... (if empty, CMDB service name will be used)")})
  public String runUpgrader(Integer customerID, String upgraderFullName, String serviceName)
  {
    RunUpgraderOperation ruo = new RunUpgraderOperation(upgraderFullName, "", "8.0.0.0", serviceName);
    invokeOperation(ruo, customerID);
    return "Success. " + upgraderFullName + " = " + "8.0.0.0";
  }

  @ManagedOperation(description="set internal setting")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="key", description="key"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="value", description="description")})
  public void setInternalSetting(Integer customerID, String key, String value)
  {
    setCustomerID(customerID);
    InternalSettings internalSettings = InternalSettings.create(new BasicLocalEnvironment(getCustomerID()));
    internalSettings.setSystemParameter(key, value);
  }

  @ManagedOperation(description="get internal setting")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String getInternalSettings(Integer customerID) {
    setCustomerID(customerID);
    InternalSettings internalSettings = InternalSettings.create(new BasicLocalEnvironment(getCustomerID()));
    Map map = internalSettings.retreiveSettings();
    StringBuilder sb = new StringBuilder("<table border=1><tr><th><b>key</b></th><th><b>value</b></th></tr>");
    for (Iterator i$ = map.keySet().iterator(); i$.hasNext(); ) { String key = (String)i$.next();
      sb.append("<tr><td>").append(key).append("</td><td>").append((String)map.get(key)).append("</td></tr>");
    }
    sb.append("</table>");
    return String.valueOf(sb);
  }

  @ManagedOperation(description="Set cmdb version")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="upgradeableName", description="the name of the upgradeable subsystem to set the version for (keep null to set CMDB version)"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="version", description="version")})
  public String setCmdbVersion(Integer customerID, String upgradeableName, String version)
  {
    CmdbCustomerUpdateSetCmdbVersion setCmdbVersionOperation = new CmdbCustomerUpdateSetCmdbVersion(upgradeableName, version);
    invokeOperation(setCmdbVersionOperation, customerID);

    return "Operation completed";
  }

  @ManagedOperation(description="Get db context")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String getDbContext(Integer customerID)
  {
    CmdbCustomerQueryGetDbContext getDbContextQuery = new CmdbCustomerQueryGetDbContext();
    invokeOperation(getDbContextQuery, customerID);

    DbContext dbContext = getDbContextQuery.getDbContext();
    return dbContext.toString();
  }

  @ManagedOperation(description="Isolate customer from consolidated mode to seperate mode")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="hostName", description="Host name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="sid", description="Sid"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="port", description="Port"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="userName", description="User name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="password", description="Password")})
  public String isolateCustomer(Integer customerId, String hostName, String sid, String port, String userName, String password)
  {
    String resultMsg = "success";
    try
    {
      DbContext dbContext = createDbContext(hostName, sid, port, userName, password);
      String errorMsg = isolateCustomer(customerId, dbContext);

      if ((errorMsg != null) && (errorMsg.length() != 0)) {
        resultMsg = "Can't isolate customer [" + customerId + "], due to error [" + errorMsg + "] !!!";
      }

      return resultMsg;
    }
    catch (Exception e) {
      throw new CmdbDalException("Can't isolate customer [" + customerId + "], due to exception: " + e, e);
    }
  }

  private DbContext createDbContext(String hostName, String sid, String port, String userName, String password)
  {
    DBType dbType = DBType.ORACLE;
    String dbName = "";

    return new DbContext(dbType, hostName, dbName, userName, password, hostName, sid, port);
  }

  private String isolateCustomer(Integer customerID, DbContext dbContext) throws Exception {
    Connection connection = null;
    CallableStatement callableStatement = null;
    try
    {
      connection = ConnectionManager.getPrivateConnection(dbContext);
      connection.setAutoCommit(true);

      String sql = "{CALL CDM_SEPERATE_CUSTOMER_DATA(" + customerID + ", ?, ?)}";
      callableStatement = connection.prepareCall(sql);
      callableStatement.registerOutParameter(1, 4);
      callableStatement.registerOutParameter(2, 12);

      callableStatement.execute();

      String str1 = callableStatement.getString(2);

      return str1;
    }
    finally
    {
      try
      {
        if (callableStatement != null) {
          callableStatement.close();
        }

        if (connection != null)
          ConnectionManager.releasePrivateConnection(connection);
      }
      catch (Exception e)
      {
        _logger.error("Can't perform isolateCustomer finally code, due to exception: " + e, e);
      }
    }
  }
}