package com.mercury.topaz.cmdb.server.base.jmx.model;

import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.server.base.jmx.PatternByIdHelper;
import com.mercury.topaz.cmdb.server.model.operation.command.topology.impl.ModelQueryGatherConnectivityStatistics;
import com.mercury.topaz.cmdb.server.model.operation.command.topology.impl.ModelTopologyCommandAnalyzeMetisOutput;
import com.mercury.topaz.cmdb.server.model.operation.command.topology.impl.ModelTopologyCommandPrepareTopologyFiles;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryGetInstancesCount;
import com.mercury.topaz.cmdb.server.model.operation.update.UnlockEntireModel;
import com.mercury.topaz.cmdb.server.model.util.ClassConnectivityAnalyzer;
import com.mercury.topaz.cmdb.server.model.util.ClassConnectivityData;
import com.mercury.topaz.cmdb.server.util.db.tables.CmdbGetInconsistencyInModelTablesDbUtil;
import com.mercury.topaz.cmdb.server.util.db.tables.CmdbGetInconsistencyInModelTablesDbUtilFactory;
import com.mercury.topaz.cmdb.server.util.jmx.JMXUtils;
import com.mercury.topaz.cmdb.shared.base.CmdbConstants.Property;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl.CmdbCustomerQueryGetDbContext;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.link.id.impl.CmdbLinkIdsFactory;
import com.mercury.topaz.cmdb.shared.model.notification.definition.CmdbModelNotificationDefinition;
import com.mercury.topaz.cmdb.shared.model.notification.definition.CmdbModelNotificationDefinitions;
import com.mercury.topaz.cmdb.shared.model.notification.definition.CmdbModelNotificationID;
import com.mercury.topaz.cmdb.shared.model.notification.definition.impl.CmdbModelNotificationFactory;
import com.mercury.topaz.cmdb.shared.model.notification.definition.priority.ModelNotificationPriorityType;
import com.mercury.topaz.cmdb.shared.model.notification.operation.impl.CmdbModelNotificationGetAllModelNotificationDefinitions;
import com.mercury.topaz.cmdb.shared.model.notification.operation.impl.CmdbModelNotificationGetModelNotificationDefinition;
import com.mercury.topaz.cmdb.shared.model.notification.util.CmdbModelNotificationXmlUtil;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsStrict;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCardinality;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultMapUtils;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=CMDB Model Services", description="CMDB Model Services")
public class ModelJmxServices extends AbstractCmdbJmx
{
  private static Log _infoLogger = CmdbLogFactory.getCMDBInfoLog();
  private Changer _changer;

  public ModelJmxServices()
  {
    this._changer = ChangerFactory.createChanger("UCMDB", "JMX");
  }

  @ManagedOperation(description="Returns instances count")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="Class name (host, link etc..)"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="isDerived", description="is derived")})
  public String retrieveInstancesCount(Integer customerID, String className, boolean isDerived)
    throws Exception
  {
    setCustomerID(customerID);
    CmdbClass cmdbClass = retrieveClass(className);
    if (cmdbClass == null)
      return "The class " + className + " doesn't exist in class model";

    ModelQueryGetInstancesCount query = new ModelQueryGetInstancesCount(className, isDerived);
    invokeOperation(query);
    return String.valueOf(query.getInstancesCount());
  }

  @ManagedOperation(description="Retrieves all objects of a certain type")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="Class Name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="includeDerived", description="Whether to include instances of derived types as well"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="noConditions", description="Mark false to specify property conditions")})
  public String retrieveObjectsOfType(Integer customerID, String className, boolean includeDerived, boolean noConditions)
  {
    setCustomerID(customerID);
    if (noConditions)
      return getAllInstancesOfClass(className, includeDerived);

    return getInstancesOfClassWithConditions(className, includeDerived);
  }

  private String getAllInstancesOfClass(String className, boolean includeDerived)
  {
    TqlResultMap tqlResultMap;
    PatternNode node = PatternGraphFactory.createPatternNode(1, "", className, includeDerived, true, null, null);
    ModifiablePatternGraph pGraph = PatternGraphFactory.createModifiableGraph();
    pGraph.addNode(node);
    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    ElementSimpleLayout elementLayout = PatternLayoutFactory.createElementSimpleLayout();
    elementLayout.addPropertiesQulifiers(CmdbAttributeQualifierDefs.ID_ATTRIBUTE.getName());
    patternLayout.setElementLayout(node.getElementNumber(), elementLayout);
    Pattern pattern = PatternDefinitionFactory.createPattern("", "JMX_Retrieve_Objects_By_Type", PatternGroupId.PATTERN_GROUP_ALL, pGraph);

    TqlQueryGetAdHocMap getResult = new TqlQueryGetAdHocMap(pattern, patternLayout);
    invokeOperation(getResult);

    if (getResult.isDividedToChunks())
      tqlResultMap = TqlResultMapUtils.getResultInChunks(getResult.getChunkRequest(), createOperationExecutor(), true);
    else {
      tqlResultMap = getResult.getResultMap();
    }

    if (!(tqlResultMap.containsElementNumber(node.getElementNumber())))
      return "There are no instances of class " + className;

    CmdbObjects objects = tqlResultMap.getObjects(node.getElementNumber());
    if ((objects == null) || (objects.isEmpty()))
      return "There are no instances of class " + className;

    return JMXUtils.createListOfObjects(objects);
  }

  private String getInstancesOfClassWithConditions(String className, boolean includeDerived) {
    String attrName;
    StringBuilder result = new StringBuilder();
    CmdbClass objectType = retrieveClass(className);
    CmdbAttributes allAttributes = objectType.getAllAttributes();
    result.append("</pre><h3>Retrieving objects of type ").append(className).append("</h3>\n");
    JMXUtils.startUcmdbJmxForm(result, "RetrieveObjectsByProperties", ModelJmxServices.class);
    result.append("<input name=\"className\" value=\"").append(className).append("\" type=\"hidden\">\n");
    result.append("<input name=\"includeDerived\" value=\"").append(includeDerived).append("\" type=\"hidden\">\n");
    result.append("<table border=\"0\" cellspacing=\"0\" cellpadding=\"2\">\n");
    result.append("<caption align=\"left\"><b>Properties</b></caption>\n");
    Set sortedAttrNames = new TreeSet();
    for (ReadOnlyIterator allAttrIt = allAttributes.getIterator(); allAttrIt.hasNext(); ) {
      attrName = ((CmdbAttributeDefinition)allAttrIt.next()).getName();
      sortedAttrNames.add(attrName);
    }
    for (Iterator i$ = sortedAttrNames.iterator(); i$.hasNext(); ) { attrName = (String)i$.next();
      result.append("<tr><td>").append(attrName).append("</td>");
      appendOperatorCombo(result, attrName);
      result.append("<td><input name=\"_val_").append(attrName).append("\" type=\"text\"></td></tr>\n");
    }
    result.append("</table>\n");
    result.append("<p><input value=\"Query\" type=\"submit\">\n");
    result.append("</form><pre>\n");
    return result.toString();
  }

  private void appendOperatorCombo(StringBuilder result, String attrName) {
    result.append("<td><select name=\"_op_").append(attrName).append("\">\n");
    result.append("    <option value=\"None\"/>\n");
    result.append("    <option value=\"Equals\">Equals</option>\n");
    result.append("    <option value=\"NotEquals\">Not equals</option>\n");
    result.append("    <option value=\"Like\">Like</option>\n");
    result.append("</select></td>\n");
  }

  @ManagedOperation(description="Retrieves object's properties")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="objectID", description="Object ID")})
  public String retrieveObjectProperties(Integer customerID, String objectID)
  {
    setCustomerID(customerID);
    PatternByIdHelper patternHelper = new PatternByIdHelper();
    patternHelper.createPattern();

    StringBuilder result = new StringBuilder();
    String returnMessage = patternHelper.setPatternId(objectID);
    if (returnMessage != null)
      return returnMessage;
    try
    {
      CmdbObject object = patternHelper.getObject(Integer.valueOf(getIntCustomerID()));
      if (object == null) {
        _infoLogger.info("Retrieve Object Properties :objectID:" + objectID + " doesn't exist in CMDB!");
        return "There is no object with id:" + objectID + " in cmdb!";
      }
      result.append("</pre><h3>Object ").append(objectID).append(" of type ").append(JMXUtils.generateCmdbClassHyperlink(object.getType())).append("</h3>\n");

      result.append("<table cellpadding=\"5\"><tr>\n");
      result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "getObjectNeighbors", new Object[] { objectID, Boolean.valueOf(true) })).append("\">");

      result.append("<input value=\"--> Neighbors\" type=\"submit\">\n");
      result.append("</form></td>");
      result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "getObjectNeighbors", new Object[] { objectID, Boolean.valueOf(false) })).append("\">");

      result.append("<input value=\"<-- Neighbors\" type=\"submit\">\n");
      result.append("</form></td>");
      result.append("<td>");
      JMXUtils.startUcmdbJmxForm(result, "WorkBasket?step=addObject&id=" + objectID, getClass());
      result.append("<input value=\"Add to Basket\" type=\"submit\">\n");
      result.append("</form></td>");
      result.append("<SCRIPT LANGUAGE=\"JavaScript\">\n");
      result.append("  function confirmDelete() {\n");
      result.append("    return confirm(\"The ").append(object.getType()).append(" object will be deleted forever!");
      result.append(" There is no way to undo this action!");
      result.append(" Are you sure?\")\n");
      result.append("  }\n");
      result.append("</SCRIPT>\n");
      result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "removeCMDBObject", new Object[] { objectID })).append("\" onSubmit=\"return confirmDelete()\">");

      result.append("<input value=\"Delete Object\" type=\"submit\">\n");
      result.append("</form></td>");
      result.append("</tr></table>");

      JMXUtils.startUcmdbJmxForm(result, "CreateLinkedObjectForm", getClass());
      result.append("<input name=\"end1Id\" type=\"hidden\" value=\"").append(objectID).append("\">\n");
      result.append("<input name=\"end1Class\" type=\"hidden\" value=\"").append(object.getType()).append("\">\n");
      result.append("<input value=\"Create Linked Object\" type=\"submit\">\n");
      result.append("Of type:");
      result.append("<input name=\"end2Class\" type=\"text\">\n");
      result.append("</form>\n");

      result.append(displayObjectProperties(object));
      result.append("<pre>");
    } catch (Exception e) {
      _infoLogger.info("Retrieve Object Properties :objectID:" + objectID + " failed!" + e);
      return "Retrieve Object Properties for objectID:" + objectID + " failed!" + e.getMessage();
    }

    return result.toString();
  }

  @ManagedOperation(description="Retrieves link's properties")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="linkID", description="Link ID")})
  public String retrieveLinkProperties(Integer customerID, String linkID)
  {
    setCustomerID(customerID);
    CmdbLinkID id = CmdbLinkID.Factory.restoreLinkID(linkID.toLowerCase());
    CmdbGraph graph = queryTriple(null, id, null);
    CmdbLink link = graph.getLink(id);
    if (link == null)
      return "Link " + linkID + " does not exist in CMDB";

    CmdbObject end1 = graph.getObject(link.getEnd1());
    CmdbObject end2 = graph.getObject(link.getEnd2());
    StringBuilder result = new StringBuilder();
    String linkType = link.getType();
    result.append("</pre><h3>Link ").append(linkID).append(" of type ").append(JMXUtils.generateCmdbClassHyperlink(linkType)).append("</h3>\n");

    result.append("between<p>");
    result.append(JMXUtils.generateShortObjectLine(end1)).append("<p>");
    result.append("and<p>");
    result.append(JMXUtils.generateShortObjectLine(end2)).append("<p>");
    result.append("<table cellpadding=\"5\"><tr>\n");
    result.append("<SCRIPT LANGUAGE=\"JavaScript\">\n");
    result.append("  function confirmDelete() {\n");
    result.append("    return confirm(\"The ").append(linkType).append(" link will be deleted forever!");
    result.append(" There is no way to undo this action!");
    result.append(" Are you sure?\")\n");
    result.append("  }\n");
    result.append("</SCRIPT>\n");
    result.append("<td><form method=\"post\" action=\"").append(JMXUtils.generateMethodHyperlink(getClass(), "removeCMDBLink", new Object[] { linkID })).append("\" onSubmit=\"return confirmDelete()\">");

    result.append("<input value=\"Delete Link\" type=\"submit\">\n");
    result.append("</form></td>");
    result.append("</tr></table>");
    result.append(displayObjectProperties(link));
    result.append("<pre>");
    return result.toString();
  }

  private CmdbGraph queryTriple(CmdbObjectID end1Id, CmdbLinkID linkId, CmdbObjectID end2Id) {
    ElementCondition node1Condition;
    ElementCondition node2Condition;
    ElementCondition linkCondition;
    TqlResultMap tqlResultMap;
    ElementClassCondition objectClassCondition = PatternConditionFactory.createElementClassCondition("object", true);

    ModifiablePatternGraph pGraph = PatternGraphFactory.createModifiableGraph();

    if (end1Id != null) {
      node1Condition = PatternConditionFactory.createElementCondition(objectClassCondition, null, CmdbObjectIdsFactory.createSingleIdCollection(end1Id));
    }
    else
      node1Condition = PatternConditionFactory.createElementCondition(objectClassCondition);

    PatternElementNumber end1NodeNumber = PatternElementNumberFactory.createElementNumber(1);
    ModifiablePatternNode node1 = PatternGraphFactory.createModifiablePatternNode(end1NodeNumber, node1Condition, true, null, "");

    pGraph.addNode(node1);

    if (end2Id != null) {
      node2Condition = PatternConditionFactory.createElementCondition(objectClassCondition, null, CmdbObjectIdsFactory.createSingleIdCollection(end2Id));
    }
    else
      node2Condition = PatternConditionFactory.createElementCondition(objectClassCondition);

    PatternElementNumber end2NodeNumber = PatternElementNumberFactory.createElementNumber(2);
    ModifiablePatternNode node2 = PatternGraphFactory.createModifiablePatternNode(end2NodeNumber, node2Condition, true, null, "");

    pGraph.addNode(node2);

    ElementClassCondition linkClassCondition = PatternConditionFactory.createElementClassCondition("link", true);

    if (linkId != null) {
      linkCondition = PatternConditionFactory.createElementCondition(linkClassCondition, null, CmdbLinkIdsFactory.createSingleIdCollection(linkId), false);
    }
    else
      linkCondition = PatternConditionFactory.createElementCondition(linkClassCondition);

    PatternElementNumber linkNumber = PatternElementNumberFactory.createElementNumber(3);
    PatternLink link = PatternGraphFactory.createPatternLink(linkNumber, end1NodeNumber, end2NodeNumber, linkCondition, true);
    pGraph.addLink(link);
    ModifiableNodeLinksCondition node1LinksCondition = PatternConditionFactory.createNodeLinksCondition();
    LinkCardinality node1LinkCardinality = PatternConditionFactory.createLinkCardinality(3, 1, -1);

    node1LinksCondition.addLinkCardinality(node1LinkCardinality);
    node1.setLinksCondition(node1LinksCondition);
    ModifiableNodeLinksCondition node2LinksCondition = PatternConditionFactory.createNodeLinksCondition();
    LinkCardinality node2LinkCardinality = PatternConditionFactory.createLinkCardinality(3, 1, -1);

    node2LinksCondition.addLinkCardinality(node2LinkCardinality);
    node2.setLinksCondition(node2LinksCondition);
    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    ElementSimpleLayout elementLayout = PatternLayoutFactory.createElementSimpleLayout();
    elementLayout.setAllLayer(true);
    patternLayout.setElementLayout(end1NodeNumber, elementLayout);
    patternLayout.setElementLayout(end2NodeNumber, elementLayout);
    patternLayout.setElementLayout(linkNumber, elementLayout);
    Pattern pattern = PatternDefinitionFactory.createPattern("", "JMXGetTriple", PatternGroupId.PATTERN_GROUP_ALL, pGraph);

    TqlQueryGetAdHocMap getResult = new TqlQueryGetAdHocMap(pattern, patternLayout);
    invokeOperation(getResult);

    if (getResult.isDividedToChunks())
      tqlResultMap = TqlResultMapUtils.getResultInChunks(getResult.getChunkRequest(), createOperationExecutor(), true);
    else
      tqlResultMap = getResult.getResultMap();

    return TqlResultMapUtils.convertTqlMapToGraph(tqlResultMap);
  }

  private String displayObjectProperties(CmdbData<?> object) {
    StringBuilder list = new StringBuilder();
    ReadOnlyIterator propertiesItr = object.getPropertiesIterator();
    Map allPropertiesSorted = new TreeMap();
    while (propertiesItr.hasNext()) {
      CmdbProperty property = (CmdbProperty)propertiesItr.next();
      allPropertiesSorted.put(property.getKey(), property);
    }
    CmdbClass cmdbClass = retrieveClass(object.getType());
    list.append("<table border=\"0\">\n");
    Iterator i$ = allPropertiesSorted.keySet().iterator();
    while (true) { String propertyName;
      Object propertyValue;
      while (true) { if (!(i$.hasNext())) break label238; propertyName = (String)i$.next();
        CmdbProperty property = (CmdbProperty)allPropertiesSorted.get(propertyName);
        propertyValue = property.getValue();
        if (!(CmdbConstants.Property.EmptyValue.equals(propertyValue)))
          break;
      }
      list.append("<tr><td>").append(propertyName).append("</td>");
      if ((propertyName.equals("root_container")) || (cmdbClass.getAttributeByName(propertyName).hasQualifier(CmdbAttributeQualifierDefs.CONTAINED_BY.getName())))
      {
        propertyValue = JMXUtils.generateRetrieveObjectPropertiesHyperlink(propertyValue.toString());
      }

      list.append("<td>").append(propertyValue).append("</td></tr>\n");
    }
    label238: list.append("</table>\n");
    return list.toString();
  }

  @ManagedOperation(description="Retrieves object's neighbors")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="objectID", description="Object ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="outgoing", description="Neighbors connected with outgoing or incoming links")})
  public String getObjectNeighbors(Integer customerID, String objectID, boolean outgoing)
  {
    CmdbObjectID id;
    CmdbObject object;
    setCustomerID(customerID);
    try
    {
      id = CmdbObjectID.Factory.restoreObjectID(objectID.toLowerCase());
    } catch (Exception ex) {
      return "The object id " + objectID + " is not a valid object id";
    }
    String outgoingOrIncoming = (outgoing) ? "outgoing" : "incoming";
    CmdbObjectID end1Id = (outgoing) ? id : null;
    CmdbObjectID end2Id = (outgoing) ? null : id;
    CmdbGraph graph = queryTriple(end1Id, null, end2Id);
    try
    {
      object = graph.getObject(id);
    } catch (NoSuchElementException e) {
      return "Object has no " + outgoingOrIncoming + " links";
    }
    StringBuilder result = new StringBuilder();
    result.append("<h4>").append(outgoingOrIncoming).append(" neighbors for ").append(object.getType()).append(" ").append(objectID).append("</h4>\n");

    Collection links = graph.getLinksBySource(id);
    for (Iterator i$ = links.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
      CmdbObjectID otherEndId = (CmdbObjectID)link.getOtherEnd(id);
      CmdbObject neighbor = graph.getObject(otherEndId);
      result.append(JMXUtils.generateShortObjectLine(neighbor));
      result.append("\tlinked with ").append(JMXUtils.generateShortObjectLine(link)).append("\n");
    }
    return result.toString();
  }

  @ManagedOperation(description="Creates an object in CMDB")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="Object's type")})
  public String createObject(Integer customerID, String className)
  {
    setCustomerID(customerID);
    return JMXUtils.createCI(className, getClass());
  }

  private void removeObjectsByIds(CmdbObjectIds cmdbObjectIds) {
    ModelUpdateRemoveObjectsIfExist removeObjects = new ModelUpdateRemoveObjectsIfExist(cmdbObjectIds, this._changer);
    invokeOperation(removeObjects);
  }

  @ManagedOperation(description="Removes a CMDB Object from the model")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="objectID", description="Object ID")})
  public String removeCMDBObject(Integer customerID, String objectID)
  {
    CmdbObjectID cmdbObjectID;
    setCustomerID(customerID);
    try
    {
      cmdbObjectID = CmdbObjectID.Factory.restoreObjectID(objectID.toLowerCase());
    }
    catch (Exception ex) {
      return "The object id " + objectID + " is not a valid object id";
    }
    ModelUpdateRemoveObjectsStrict removeObject = new ModelUpdateRemoveObjectsStrict(cmdbObjectID, this._changer);
    invokeOperation(removeObject, customerID);
    return "Object " + objectID + " deleted";
  }

  @ManagedOperation(description="Removes a CMDB link from the model")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="linkID", description="Link ID")})
  public String removeCMDBLink(Integer customerID, String linkID)
    throws IllegalArgumentException
  {
    setCustomerID(customerID);
    CmdbLinkID id = CmdbLinkID.Factory.restoreLinkID(linkID.toLowerCase());
    CmdbGraph graph = queryTriple(null, id, null);
    CmdbLink link = graph.getLink(id);
    if (link == null)
      return "Link " + linkID + " does not exist in CMDB";

    ModelUpdateRemoveLinksStrict op = new ModelUpdateRemoveLinksStrict(link, this._changer);
    invokeOperation(op);
    return "Link (ID = " + linkID + ") deleted";
  }

  @ManagedOperation(description="Removes all objects of the given type and returns their count")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="Class name (host ip etc..)"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="chunkSize", description="Chunk size"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="isDerived", description="is derived")})
  public String deleteByClassType(Integer customerID, String className, int chunkSize, boolean isDerived)
    throws Exception
  {
    TqlResultMap tqlResultMap;
    setCustomerID(customerID);
    CmdbClass cmdbClass = retrieveClass(className);
    if (cmdbClass == null) {
      return "The class " + className + " doesn't exist in class model";
    }

    PatternNode node = PatternGraphFactory.createPatternNode(1, "", className, isDerived, true, null, null);
    ModifiablePatternGraph pGraph = PatternGraphFactory.createModifiableGraph();
    pGraph.addNode(node);
    Pattern pattern = PatternDefinitionFactory.createPattern("", "JMX_Remove_Objects_By_Type", PatternGroupId.PATTERN_GROUP_ALL, pGraph);

    TqlQueryGetAdHocMap getResult = new TqlQueryGetAdHocMap(pattern, PatternLayoutFactory.createLayout());
    invokeOperation(getResult, customerID);

    if (getResult.isDividedToChunks())
      tqlResultMap = TqlResultMapUtils.getResultInChunks(getResult.getChunkRequest(), createOperationExecutor(), true);
    else {
      tqlResultMap = getResult.getResultMap();
    }

    PatternElementNumber elementNumber = PatternElementNumberFactory.createElementNumber(1);
    if (tqlResultMap.containsElementNumber(elementNumber)) {
      CmdbObjects cmdbObjects = tqlResultMap.getObjects(elementNumber);
      int objects2RemoveSize = cmdbObjects.size();
      int totalChunksNumber = objects2RemoveSize / chunkSize + 1;
      int chunksNumber = 1;

      if (_infoLogger.isInfoEnabled()) {
        _infoLogger.info("Started to delete objects by class. Total chunks " + totalChunksNumber + " of " + chunkSize + " object/s.");
      }

      CmdbObjectIds cmdbObjectIds = CmdbObjectIdsFactory.create();
      for (ReadOnlyIterator iter = cmdbObjects.getObjectsIterator(); iter.hasNext(); ) {
        CmdbObject cmdbObject = (CmdbObject)iter.next();
        cmdbObjectIds.add((CmdbObjectID)cmdbObject.getID());

        if (cmdbObjectIds.size() == chunkSize) {
          removeObjectsByIds(cmdbObjectIds);

          cmdbObjectIds.clear();

          if (_infoLogger.isInfoEnabled())
            _infoLogger.info("successfully removed chunk " + (chunksNumber++) + " of " + chunkSize + " object/s out of " + totalChunksNumber + " chunks");
        }

      }

      if (!(cmdbObjectIds.isEmpty())) {
        removeObjectsByIds(cmdbObjectIds);

        if (_infoLogger.isInfoEnabled())
          _infoLogger.info("successfully removed chunk " + chunksNumber + " of " + cmdbObjectIds.size() + " object/s out of " + totalChunksNumber + " chunks");

      }

      return String.valueOf(cmdbObjects.size());
    }
    if (_infoLogger.isInfoEnabled())
      _infoLogger.info("There are no results/instances for class " + className);

    return String.valueOf(0);
  }

  @ManagedOperation(description="Get Model Notification Definition")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="name", description="name")})
  public String getModelNotificationDefinition(Integer customerID, String name)
  {
    setCustomerID(customerID);
    CmdbModelNotificationID modelNotificationID = CmdbModelNotificationFactory.createModelNotificationID(name);
    CmdbModelNotificationGetModelNotificationDefinition getModelNotificationDefinition = new CmdbModelNotificationGetModelNotificationDefinition(modelNotificationID);

    invokeOperation(getModelNotificationDefinition, customerID);
    CmdbModelNotificationDefinition modelNotificationDefinition = getModelNotificationDefinition.getModelNotificationDefinition();

    if (modelNotificationDefinition == null) {
      return "The model notification " + name + " doesn't exist";
    }

    String result = CmdbModelNotificationXmlUtil.toXml(modelNotificationDefinition);
    return XmlUtils.convertStringWithXmlTags(result);
  }

  @ManagedOperation(description="Get Model Notification Definitions")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String getModelNotificationDefinitions(Integer customerID)
  {
    setCustomerID(customerID);
    CmdbModelNotificationGetAllModelNotificationDefinitions getModelNotificationDefinitions = new CmdbModelNotificationGetAllModelNotificationDefinitions();

    invokeOperation(getModelNotificationDefinitions, customerID);
    CmdbModelNotificationDefinitions modelNotificationDefinitions = getModelNotificationDefinitions.getModelNotificationDefinitions();

    return buildModelNotificationDefinitionsString(modelNotificationDefinitions);
  }

  @ManagedOperation(description="Get Model Connectivity Data")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String getModelConnectivityData(Integer customerID)
  {
    setCustomerID(customerID);
    ModelQueryGatherConnectivityStatistics gatherConnectivityStatistics = new ModelQueryGatherConnectivityStatistics();

    invokeOperation(gatherConnectivityStatistics);

    CmdbClassModel cmdbClassModel = getCmdbClassModel();

    ClassConnectivityData classConnectivityData = gatherConnectivityStatistics.getClassConnectivityData();
    ClassConnectivityAnalyzer classConnectivityAnalyzer = new ClassConnectivityAnalyzer(classConnectivityData, cmdbClassModel);

    StringBuilder str = new StringBuilder("Model Connectivity Data\n************************\n\n");

    for (ReadOnlyIterator classIter = cmdbClassModel.getAllClasses().getIterator(); classIter.hasNext(); )
    {
      CmdbClass cmdbClass = (CmdbClass)classIter.next();
      String type = cmdbClass.getName();
      int strictCount = classConnectivityAnalyzer.getCountByType(type, false);
      int derivedCount = classConnectivityAnalyzer.getCountByType(type, true);
      float strictConn = classConnectivityAnalyzer.getAvrConnectivityByType(type, false);
      float derivedConn = classConnectivityAnalyzer.getAvrConnectivityByType(type, true);

      str.append("Type [").append(type).append("]\tStrict class count [").append(strictCount).append("]\tDerived class count [").append(derivedCount).append("]\tStrict avr connectivity [").append(strictConn).append("]\tDerived avr connectivity [").append(derivedConn).append("]\n");
    }

    return str.toString();
  }

  private String buildModelNotificationDefinitionsString(CmdbModelNotificationDefinitions modelNotificationDefinitions)
  {
    StringBuilder output = new StringBuilder();

    output.append("The deployed model notification definitions are:\n");

    ReadOnlyIterator modelNotificationsIterator = modelNotificationDefinitions.getReadOnlyIterator();
    while (modelNotificationsIterator.hasNext()) {
      CmdbModelNotificationDefinition modelNotificationDefinition = (CmdbModelNotificationDefinition)modelNotificationsIterator.next();

      output.append("\n");
      output.append("name: ").append(modelNotificationDefinition.getID());
      output.append(", display name: ").append(modelNotificationDefinition.getDisplayName());
      output.append(", description: ").append(modelNotificationDefinition.getDescription());
      output.append(", priority: ").append(modelNotificationDefinition.getPriorityType().toString());
    }

    return output.toString();
  }

  @ManagedOperation(description="Create Metis Input Files")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="directoryPath", description="Directory Path"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="classNames", description="Class Names (separated by spaces)"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="edgeWeightByClassName", description="Special edge weights by link class name (separated by spaces)")})
  public String createMetisInputFiles(Integer customerID, String directoryPath, String classNames, String edgeWeightByClassName)
  {
    setCustomerID(customerID);
    Map map = null;
    if (edgeWeightByClassName.length() > 0) {
      map = new HashMap();
      String[] classesToWeights = edgeWeightByClassName.split(" ");
      for (int i = 0; i < classesToWeights.length - 1; i += 2) {
        String type = classesToWeights[i];
        Integer weight = new Integer(classesToWeights[(i + 1)]);
        map.put(type, weight);
      }
    }
    ModelTopologyCommandPrepareTopologyFiles prepareTopologyFiles = new ModelTopologyCommandPrepareTopologyFiles(classNames.split(" "), directoryPath, map);

    invokeOperation(prepareTopologyFiles);

    return "Files were succesfully created";
  }

  @ManagedOperation(description="Analyse Metis Output File")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="directoryPath", description="Directory Path"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="metisOutputFileName", description="Metis output file name")})
  public String analyseMetisPartitioning(Integer customerID, String directoryPath, String metisOutputFileName)
  {
    setCustomerID(customerID);
    ModelTopologyCommandAnalyzeMetisOutput analyzeMetisOutput = new ModelTopologyCommandAnalyzeMetisOutput(directoryPath, metisOutputFileName);

    invokeOperation(analyzeMetisOutput);

    return "Analasis file was succesfully created";
  }

  @ManagedOperation(description="Check model consistency in DB")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="isConsolidate", description="Consolidated Customer"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="path", description="File Path")})
  public String checkModelConsistency(Integer customerID, boolean isConsolidate, String path)
  {
    setCustomerID(customerID);
    CmdbCustomerQueryGetDbContext getDbContextQuery = new CmdbCustomerQueryGetDbContext();
    invokeOperation(getDbContextQuery);

    DbContext dbContext = getDbContextQuery.getDbContext();
    try {
      CmdbGetInconsistencyInModelTablesDbUtil util = CmdbGetInconsistencyInModelTablesDbUtilFactory.getInconsistencyInModelTablesDBUtil(dbContext, getIntCustomerID(), isConsolidate, path);

      return util.getInconsistencyInModel(); } catch (CmdbException ex) {
    }
    return "Failed to report inconsistency in class model to file [" + path + "] due to the following error: " + ex.getMessage();
  }

  @ManagedOperation(description="Check links consistency in DB")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="isConsolidate", description="Consolidated Customer"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="path", description="File Path")})
  public String checkLinksConsistency(Integer customerID, boolean isConsolidate, String path)
  {
    setCustomerID(customerID);
    CmdbCustomerQueryGetDbContext getDbContextQuery = new CmdbCustomerQueryGetDbContext();
    invokeOperation(getDbContextQuery);

    DbContext dbContext = getDbContextQuery.getDbContext();
    try {
      CmdbGetInconsistencyInModelTablesDbUtil util = CmdbGetInconsistencyInModelTablesDbUtilFactory.getInconsistencyInModelTablesDBUtil(dbContext, getIntCustomerID(), isConsolidate, path);

      return util.getInconsistencyLinks(); } catch (CmdbException ex) {
    }
    return "Failed to report inconsistency links to file [" + path + "] due to the following error: " + ex.getMessage();
  }

  @ManagedOperation(description="Unlocks entire data model; to be used with extreme care")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public void unlockEntireModel(Integer customerID)
  {
    setCustomerID(customerID);
    invokeOperation(new UnlockEntireModel());
  }

  private CmdbClass retrieveClass(String className) {
    CmdbClassModel classModel = getCmdbClassModel();
    return classModel.getClass(className);
  }

  @ManagedOperation(description="Show basket contents")
  public String showBasket() {
    return "</pre><script type=\"text/javascript\">window.location=\"/ucmdb-jmx/WorkBasket\"</script><pre>";
  }
}