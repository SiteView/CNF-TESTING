package com.mercury.topaz.cmdb.server.base.jmx.systemhealth;

public abstract interface SystemHealthJmxServicesInterface
{
  public abstract String getMonitorData(String paramString, boolean paramBoolean);
}