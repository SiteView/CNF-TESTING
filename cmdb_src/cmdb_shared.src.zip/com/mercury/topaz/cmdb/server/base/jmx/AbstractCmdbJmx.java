package com.mercury.topaz.cmdb.server.base.jmx;

import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.util.jmx.JMXUtils;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Default;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID.Factory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkGlobalOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.ProcessOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.util.AbstractOperationExecutor;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import java.io.PrintWriter;
import java.io.StringWriter;

public abstract class AbstractCmdbJmx
{
  protected static final String SUCCEED = "operation succeeded";

  protected final CmdbResponse invokeOperation(FrameworkOperation operation, CmdbContext context)
  {
    CmdbApi cmdbapi = getAPI(operation);
    return cmdbapi.executeCMDBOperation(operation, context);
  }

  protected final CmdbResponse invokeOperation(FrameworkOperation operation, CmdbContext context, boolean isSynchronic) {
    CmdbApi cmdbApi = getAPI(operation);
    return cmdbApi.executeCMDBOperation(operation, context, isSynchronic);
  }

  protected final void invokeOperation(FrameworkOperation operation) {
    invokeOperation(operation, JMXUtils.getThreadContext());
  }

  protected final void invokeOperation(FrameworkOperation operation, boolean isSynchronic) {
    invokeOperation(operation, JMXUtils.getThreadContext(), isSynchronic);
  }

  protected final CmdbResponse invokeOperation(FrameworkOperation operation, Integer customerID) {
    return invokeOperation(operation, createContext(customerID));
  }

  protected final CmdbResponse invokeOperation(FrameworkOperation operation, Integer customerID, boolean isSynchronic) {
    return invokeOperation(operation, createContext(customerID), isSynchronic);
  }

  protected void setCustomerID(Integer customerID) {
    JMXUtils.setContext(createContext(customerID));
  }

  protected CmdbContext getContext() {
    return JMXUtils.getThreadContext();
  }

  protected CmdbCustomerID getCustomerID() {
    return JMXUtils.getCustomerID();
  }

  protected int getIntCustomerID() {
    return JMXUtils.getCustomerIDInt();
  }

  protected MamCustomerID createCustomerID(Integer customerID) {
    if (customerID == null)
      customerID = Integer.valueOf(FrameworkConstants.Customer.Default.ID.getID());

    return ((MamCustomerID)CmdbCustomerID.Factory.createCMDBCustomerID(customerID.intValue()));
  }

  protected MamContext createContext(Integer customerID) {
    return ((MamContext)CmdbContextFactory.createCmdbContext(createCustomerID(customerID), 1, "JMX"));
  }

  protected CmdbApi getAPI(FrameworkOperation operation)
  {
    CmdbApi cmdbapi;
    if (operation instanceof ProcessOperation)
      cmdbapi = CmdbApiFactory.createCMDBAPI((ProcessOperation)operation);
    else if (operation instanceof FrameworkGlobalOperation)
      cmdbapi = CmdbApiFactory.createCMDBAPI(CmdbApi.RMI_TYPE);
    else
      cmdbapi = CmdbApiFactory.createCMDBAPI();

    return cmdbapi;
  }

  protected OperationExecutor createOperationExecutor()
  {
    return new AbstractOperationExecutor(this, getCustomerID()) {
    };
  }

  protected CmdbClassModel getCmdbClassModel() {
    return ClassModelProvider.getInstance(getCustomerID()).getClassModel();
  }

  protected DataFactory getDataFactory() {
    CmdbClassModel classModel = getCmdbClassModel();
    return DataFactoryCreator.create(classModel);
  }

  protected String getThisJMXName() {
    return JMXUtils.getJMXName(super.getClass());
  }

  public static String createStringFromException(Throwable e, String[] prefix) {
    if (null == e)
      return "";
    StringWriter stringWriter = new StringWriter();
    String[] arr$ = prefix; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String prefixI = arr$[i$];
      stringWriter.append(prefixI);
    }
    PrintWriter printWriter = new PrintWriter(stringWriter);
    stringWriter.append(e.getMessage()).append("\n");
    e.printStackTrace(printWriter);

    return stringWriter.getBuffer().toString();
  }
}