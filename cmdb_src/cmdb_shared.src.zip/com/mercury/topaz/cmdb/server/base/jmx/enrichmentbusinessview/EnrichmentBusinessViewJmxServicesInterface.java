package com.mercury.topaz.cmdb.server.base.jmx.enrichmentbusinessview;

public abstract interface EnrichmentBusinessViewJmxServicesInterface
{
  public abstract String calculateAdHocEnrichment(Integer paramInteger, String paramString);

  public abstract String exportEnrichment(Integer paramInteger, String paramString);

  public abstract String retrieveAllEnrichmentNames(Integer paramInteger);

  public abstract String removeEnrichment(Integer paramInteger, String paramString);

  public abstract String removeEnrichmentResults(Integer paramInteger, String paramString);

  public abstract String retrieveEnrichmentResultCount(Integer paramInteger, String paramString);

  public abstract String retrieveEnrichmentResultCountByElementNumbers(Integer paramInteger, String paramString);
}