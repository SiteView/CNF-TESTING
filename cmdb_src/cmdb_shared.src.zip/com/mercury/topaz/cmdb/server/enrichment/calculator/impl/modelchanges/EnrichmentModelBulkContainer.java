package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;

public class EnrichmentModelBulkContainer
{
  ModelUpdateBulksOptimistic _modelUpdateBulks;
  long _currentModelChangesNum;

  public EnrichmentModelBulkContainer(ModelUpdateBulksOptimistic modelUpdateBulks, long currentModelChangesNum)
  {
    setModelUpdateBulks(modelUpdateBulks);
    setCurrentModelChangesNum(currentModelChangesNum);
  }

  public ModelUpdateBulksOptimistic getModelUpdateBulks() {
    return this._modelUpdateBulks;
  }

  public void setModelUpdateBulks(ModelUpdateBulksOptimistic modelUpdateBulks) {
    this._modelUpdateBulks = modelUpdateBulks;
  }

  public long getCurrentModelChangesNum() {
    return this._currentModelChangesNum;
  }

  public void setCurrentModelChangesNum(long currentModelChangesNum) {
    this._currentModelChangesNum = currentModelChangesNum;
  }
}