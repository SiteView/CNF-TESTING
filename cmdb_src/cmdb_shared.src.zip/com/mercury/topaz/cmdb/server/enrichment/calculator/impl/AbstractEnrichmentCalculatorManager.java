package com.mercury.topaz.cmdb.server.enrichment.calculator.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges.EnrichmentCreateLinks;
import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges.EnrichmentCreateObjects;
import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges.EnrichmentModelBulkContainer;
import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges.EnrichmentRemoveLinks;
import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges.EnrichmentRemoveObjects;
import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges.EnrichmentTouchLinks;
import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges.EnrichmentTouchObjects;
import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges.EnrichmentUpdateLinks;
import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges.EnrichmentUpdateObjects;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.EnrichmentPatternInstance;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.EnrichmentPatternInstances;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.chunks.InstancesChunkerForEnrichment;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.chunks.impl.InstancesChunkerForEnrichmentFactory;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.impl.EnrichmentPatternInstanceFactory;
import com.mercury.topaz.cmdb.server.enrichment.util.EnrichmentRemoveResultsUtil;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.CmdbConstants.Enrichment.Action;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentAction;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentActions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentAttribute;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentImmutableAttributes;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentLink;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentObject;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.id.CmdbEnrichmentID;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.id.impl.CmdbEnrichmentIDFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentExpression;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentNodeNumber2CmdbData;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentNodeNumber2CmdbDatas;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.impl.EnrichmentNodeNumber2CmdbDataFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.impl.EnrichmentQueryGetEnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.util.impl.EnrichmentUtil;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.ChangerType;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.ModelUpdateRemoveGraph;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksStrict;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ConditionOperator;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.PropertyCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumbers;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocGraph;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetInstances;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetPattern;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.instance.PatternInstance;
import com.mercury.topaz.cmdb.shared.tql.result.instance.PatternInstances;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.ResultEntry;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultMapUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.HashSet;
import java.util.Iterator;

public abstract class AbstractEnrichmentCalculatorManager extends CmdbSubsystemManagerImpl
{
  private static Log _logger = LogFactory.getEasyLog(AbstractEnrichmentCalculatorManager.class);
  protected static Log _enrichmentLogger = LogFactory.getEasyLog("cmdb.enrichment.appender");
  private long _modelChangesChunkSize = 0L;

  AbstractEnrichmentCalculatorManager(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  protected long getAllowedMaxCisChanges(EnrichmentDefinition enrichmentDefinition) {
    SettingsReader settingsReader = getSettingsReader();

    long maxAllowedLinksCreating = (enrichmentDefinition.getEnrichmentType() == 1) ? settingsReader.getLong("enrichment.max.allowed.cis.changes", 1000000L) : settingsReader.getLong("enrichment.business.view.max.allowed.links.creating", 15000L);

    return maxAllowedLinksCreating;
  }

  protected boolean fuseOk(EnrichmentDefinition enrichmentDefinition, ModelUpdateOperations listPerOperation)
  {
    long currentCisChanges = getCisChangesNumber(listPerOperation);
    long maxAllowedCisChanges = getAllowedMaxCisChanges(enrichmentDefinition);
    if (currentCisChanges > maxAllowedCisChanges) {
      String msg = enrichmentDefinition.getEnrichmentName() + " -- " + "The number of changes to model " + currentCisChanges + " is greater than the max allowed changes " + maxAllowedCisChanges;

      _enrichmentLogger.error(msg);
      _logger.error(msg);
      return false;
    }
    return true;
  }

  private static long getCisChangesNumber(ModelUpdateOperations listPerOperation) {
    long currentCisChanges = listPerOperation.getObjects4Create().size() + listPerOperation.getObjects4Update().size() + listPerOperation.getObjectsIDs4Touch().size() + listPerOperation.getObjectsIDs4remove().size() + listPerOperation.getLinks4Create().size() + listPerOperation.getLinks4Update().size() + listPerOperation.getLinksIds4Touch().size() + listPerOperation.getLinks4Remove().size();

    return currentCisChanges;
  }

  protected void fillListPerOperation(EnrichmentDefinition enrichmentDefinition, Pattern pattern, TqlResultMap requiredObjects, ModelUpdateOperations listPerOperation)
  {
    InstancesChunkerForEnrichment instancesChunker = InstancesChunkerForEnrichmentFactory.createInstancesChunkerForEnrichment(enrichmentDefinition, pattern, requiredObjects, this);

    while (instancesChunker.hasNextInstances()) {
      PatternInstances patternInstances = instancesChunker.getNextInstances();
      long inMemoryCalculateCisChunkSize = getEnrichmentInMemoryCalculateCisChunkSize();
      if (patternInstances != null) {
        ReadOnlyIterator iterInstances = patternInstances.getInstancesIterator();
        while (iterInstances.hasNext()) {
          PatternInstance patternInstance = (PatternInstance)iterInstances.next();
          if (_logger.isDebugEnabled()) {
            _logger.debug("start fillListPerOperation for patternInstance " + patternInstance);
          }

          fillListPerOperation(enrichmentDefinition, patternInstance, listPerOperation);

          inMemoryCalculateAndUpdateModelByChunks(enrichmentDefinition, listPerOperation, inMemoryCalculateCisChunkSize);

          if (_logger.isDebugEnabled())
            _logger.debug("finish fillListPerOperation for patternInstance " + patternInstance);
        }
      }
    }
  }

  private void inMemoryCalculateAndUpdateModelByChunks(EnrichmentDefinition enrichmentDefinition, ModelUpdateOperations listPerOperation, long inMemoryCalculateCisChunkSize)
  {
    long currentCisChanges = getCisChangesNumber(listPerOperation);
    if (currentCisChanges >= inMemoryCalculateCisChunkSize) {
      createModelOperations(enrichmentDefinition, listPerOperation);
      if (_logger.isDebugEnabled())
        _logger.debug("update to model " + currentCisChanges + " changes (calculation in memory by chunks)");
    }
  }

  protected long getEnrichmentInMemoryCalculateCisChunkSize()
  {
    SettingsReader settingsReader = getSettingsReader();
    long maxAllowedLinksCreating = settingsReader.getLong("enrichment.in.memory.calculate.cis.chunk.size", 50000L);

    return maxAllowedLinksCreating;
  }

  private void fillListPerOperation(EnrichmentDefinition enrichmentDefinition, PatternInstance patternInstance, ModelUpdateOperations listPerOperation)
  {
    EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas = fillsPatternNodeNumbers(patternInstance);

    EnrichmentActions orderEnrichmentActions = enrichmentDefinition.getOrderEnrichmentActions();
    ReadOnlyIterator iterOrderEnrichmentActions = orderEnrichmentActions.getElementsIterator();
    while (iterOrderEnrichmentActions.hasNext()) {
      EnrichmentAction enrichmentAction = (EnrichmentAction)iterOrderEnrichmentActions.next();
      if (enrichmentAction instanceof EnrichmentObject) {
        if (_logger.isDebugEnabled()) {
          _logger.debug("start fillObjectsPerOperation for enrichmentAction " + enrichmentAction);
        }

        fillObjectsPerOperation(enrichmentDefinition.getEnrichmentName(), enrichmentAction, nodeNumber2CmdbDatas, listPerOperation);

        if (_logger.isDebugEnabled())
          _logger.debug("finish fillObjectsPerOperation for enrichmentAction " + enrichmentAction);

      }
      else if (enrichmentAction instanceof EnrichmentLink) {
        if (_logger.isDebugEnabled()) {
          _logger.debug("start fillLinksPerOperation for enrichmentAction " + enrichmentAction);
        }

        fillLinksPerOperation(enrichmentDefinition.getEnrichmentName(), enrichmentAction, nodeNumber2CmdbDatas, listPerOperation);

        if (_logger.isDebugEnabled())
          _logger.debug("finish fillLinksPerOperation for enrichmentAction " + enrichmentAction);
      }
      else
      {
        throw new IllegalArgumentException("Unsupported action type " + enrichmentAction.getClass().getName());
      }
    }
  }

  private void fillObjectsPerOperation(String enrichmentName, EnrichmentAction enrichmentAction, EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas, ModelUpdateOperations listPerOperation)
  {
    CmdbObject cmdbObject;
    CmdbObjects cmdbObjects;
    if (_logger.isDebugEnabled())
      _logger.debug("start fillObjectsPerOperation for enrichmentName " + enrichmentName + ", enrichmentAction " + enrichmentAction);

    if (enrichmentAction.getAction().equals(CmdbConstants.Enrichment.Action.CREATE)) {
      cmdbObject = createObject(enrichmentName, (EnrichmentObject)enrichmentAction, nodeNumber2CmdbDatas);

      fillNodeNumber2CmdbObject(nodeNumber2CmdbDatas, enrichmentAction.getNodeNumber(), cmdbObject);

      HashSet cmdbObjects4CreateHashSet = listPerOperation.getObjects4CreateHashSet();
      if (!(cmdbObjects4CreateHashSet.contains(cmdbObject.getID()))) {
        cmdbObjects = listPerOperation.getObjects4Create();
        cmdbObjects.add(cmdbObject);
        cmdbObjects4CreateHashSet.add(cmdbObject.getID());
      }
    }
    else if (enrichmentAction.getAction().equals(CmdbConstants.Enrichment.Action.UPDATE)) {
      cmdbObject = updateObject((EnrichmentObject)enrichmentAction, nodeNumber2CmdbDatas);

      fillNodeNumber2CmdbObject(nodeNumber2CmdbDatas, enrichmentAction.getNodeNumber(), cmdbObject);

      HashSet cmdbObjects4UpdateHashSet = listPerOperation.getObjects4UpdateHashSet();
      if (!(cmdbObjects4UpdateHashSet.contains(cmdbObject.getID()))) {
        cmdbObjects = listPerOperation.getObjects4Update();
        cmdbObjects.add(cmdbObject);
        cmdbObjects4UpdateHashSet.add(cmdbObject.getID());
      }
    } else {
      CmdbObjectIds cmdbObjectsIds;
      if (enrichmentAction.getAction().equals(CmdbConstants.Enrichment.Action.TOUCH)) {
        cmdbObject = (CmdbObject)nodeNumber2CmdbDatas.get(enrichmentAction.getNodeNumber());
        HashSet cmdbObjects4TouchHashSet = listPerOperation.getObjects4TouchHashSet();
        if (!(cmdbObjects4TouchHashSet.contains(cmdbObject.getID()))) {
          cmdbObjectsIds = listPerOperation.getObjectsIDs4Touch();
          cmdbObjectsIds.add((CmdbObjectID)cmdbObject.getID());
          cmdbObjects4TouchHashSet.add(cmdbObject.getID());
        }
      }
      else if (enrichmentAction.getAction().equals(CmdbConstants.Enrichment.Action.REMOVE)) {
        cmdbObject = (CmdbObject)nodeNumber2CmdbDatas.get(enrichmentAction.getNodeNumber());
        HashSet cmdbObjects4RemoveHashSet = listPerOperation.getObjects4RemoveHashSet();
        if (!(cmdbObjects4RemoveHashSet.contains(cmdbObject.getID()))) {
          cmdbObjectsIds = listPerOperation.getObjectsIDs4remove();
          cmdbObjectsIds.add((CmdbObjectID)cmdbObject.getID());
          cmdbObjects4RemoveHashSet.add(cmdbObject.getID());
        }
      }
      else {
        throw new IllegalArgumentException("Unsupported action type " + enrichmentAction.getAction()); }
    }
    if (_logger.isDebugEnabled())
      _logger.debug("finish fillObjectsPerOperation for enrichmentName " + enrichmentName + ", enrichmentAction " + enrichmentAction);
  }

  private void fillLinksPerOperation(String enrichmentName, EnrichmentAction enrichmentAction, EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas, ModelUpdateOperations listPerOperation)
  {
    CmdbLink cmdbLink;
    CmdbLinks cmdbLinks;
    if (_logger.isDebugEnabled())
      _logger.debug("start fillLinksPerOperation for enrichmentName " + enrichmentName + ", enrichmentAction " + enrichmentAction);

    if (enrichmentAction.getAction().equals(CmdbConstants.Enrichment.Action.CREATE)) {
      cmdbLink = createLink(enrichmentName, (EnrichmentLink)enrichmentAction, nodeNumber2CmdbDatas);

      fillNodeNumber2CmdbLink(nodeNumber2CmdbDatas, enrichmentAction.getNodeNumber(), cmdbLink);

      HashSet cmdbLinks4CreateHashSet = listPerOperation.getLinks4CreateHashSet();
      if (!(cmdbLinks4CreateHashSet.contains(cmdbLink.getID()))) {
        cmdbLinks = listPerOperation.getLinks4Create();
        cmdbLinks.add(cmdbLink);
        cmdbLinks4CreateHashSet.add(cmdbLink.getID());
      }
    }
    else if (enrichmentAction.getAction().equals(CmdbConstants.Enrichment.Action.UPDATE)) {
      cmdbLink = updateLink((EnrichmentLink)enrichmentAction, nodeNumber2CmdbDatas);

      fillNodeNumber2CmdbLink(nodeNumber2CmdbDatas, enrichmentAction.getNodeNumber(), cmdbLink);

      HashSet cmdbLinks4UpdateHashSet = listPerOperation.getLinks4UpdateHashSet();
      if (!(cmdbLinks4UpdateHashSet.contains(cmdbLink.getID()))) {
        cmdbLinks = listPerOperation.getLinks4Update();
        cmdbLinks.add(cmdbLink);
        cmdbLinks4UpdateHashSet.add(cmdbLink.getID());
      }
    }
    else if (enrichmentAction.getAction().equals(CmdbConstants.Enrichment.Action.TOUCH)) {
      cmdbLink = (CmdbLink)nodeNumber2CmdbDatas.get(enrichmentAction.getNodeNumber());
      HashSet cmdbLinks4TouchHashSet = listPerOperation.getLinks4TouchHashSet();
      if (!(cmdbLinks4TouchHashSet.contains(cmdbLink.getID()))) {
        CmdbLinkIds cmdbLinksIds = listPerOperation.getLinksIds4Touch();
        cmdbLinksIds.add((CmdbLinkID)cmdbLink.getID());
        cmdbLinks4TouchHashSet.add(cmdbLink.getID());
      }
    }
    else if (enrichmentAction.getAction().equals(CmdbConstants.Enrichment.Action.REMOVE)) {
      cmdbLink = (CmdbLink)nodeNumber2CmdbDatas.get(enrichmentAction.getNodeNumber());
      HashSet cmdbLinks4RemoveHashSet = listPerOperation.getLinks4RemoveHashSet();
      if (!(cmdbLinks4RemoveHashSet.contains(cmdbLink.getID()))) {
        cmdbLinks = listPerOperation.getLinks4Remove();
        cmdbLinks.add(cmdbLink);
        cmdbLinks4RemoveHashSet.add(cmdbLink.getID());
      }
    }
    else {
      throw new IllegalArgumentException("Unsupported action " + enrichmentAction.getAction());
    }
    if (_logger.isDebugEnabled())
      _logger.debug("finish fillLinksPerOperation for enrichmentName " + enrichmentName + ", enrichmentAction " + enrichmentAction);
  }

  private EnrichmentNodeNumber2CmdbDatas fillsPatternNodeNumbers(PatternInstance patternInstance)
  {
    EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas = EnrichmentNodeNumber2CmdbDataFactory.createNodeNumber2CmdbDatas();
    ReadOnlyIterator iterResultEntries = patternInstance.getDataResultEntryIterator();
    while (iterResultEntries.hasNext()) {
      ResultEntry resultEntry = (ResultEntry)iterResultEntries.next();
      PatternElementNumber patternElementId = resultEntry.getElementNumber();
      CmdbData cmdbData = patternInstance.getData(patternElementId);
      EnrichmentNodeNumber2CmdbData patternNodeNumber2CmdbData = EnrichmentNodeNumber2CmdbDataFactory.create(patternElementId, cmdbData);

      nodeNumber2CmdbDatas.add(patternNodeNumber2CmdbData);
    }
    return nodeNumber2CmdbDatas;
  }

  private EnrichmentNodeNumber2CmdbDatas fillNodeNumber2CmdbObject(EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas, PatternElementNumber elementNumber, CmdbObject cmdbObject)
  {
    if (_logger.isDebugEnabled()) {
      _logger.debug("start EnrichmentNodeNumber2CmdbDatas for cmdbObject " + cmdbObject.getID());
    }

    if (!(nodeNumber2CmdbDatas.contains(elementNumber))) {
      nodeNumber2CmdbDatas.add(EnrichmentNodeNumber2CmdbDataFactory.create(elementNumber, cmdbObject));
    }
    else {
      CmdbProperties cmdbProperties = mergeProperties(nodeNumber2CmdbDatas, elementNumber, cmdbObject);

      CmdbObject cmdbConcatObject = restoreObject((CmdbObjectID)cmdbObject.getID(), cmdbObject.getType(), cmdbProperties);

      nodeNumber2CmdbDatas.remove(elementNumber);
      nodeNumber2CmdbDatas.add(EnrichmentNodeNumber2CmdbDataFactory.create(elementNumber, cmdbConcatObject));
    }

    if (_logger.isDebugEnabled())
      _logger.debug("finish EnrichmentNodeNumber2CmdbDatas for cmdbObject " + cmdbObject.getID());

    return nodeNumber2CmdbDatas;
  }

  private EnrichmentNodeNumber2CmdbDatas fillNodeNumber2CmdbLink(EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas, PatternElementNumber elementNumber, CmdbLink cmdbLink)
  {
    if (_logger.isDebugEnabled())
      _logger.debug("start fillNodeNumber2CmdbLink for cmdbLink " + cmdbLink.getID());

    if (!(nodeNumber2CmdbDatas.contains(elementNumber))) {
      EnrichmentNodeNumber2CmdbData enrichmentNodeNumber2CmdbData = EnrichmentNodeNumber2CmdbDataFactory.create(elementNumber, cmdbLink);
      nodeNumber2CmdbDatas.add(enrichmentNodeNumber2CmdbData);
    }
    else {
      CmdbProperties cmdbProperties = mergeProperties(nodeNumber2CmdbDatas, elementNumber, cmdbLink);

      CmdbLink cmdbConcatLink = restoreLink((CmdbLinkID)cmdbLink.getID(), cmdbLink.getType(), cmdbLink.getEnd1(), cmdbLink.getEnd2(), cmdbProperties);

      nodeNumber2CmdbDatas.remove(elementNumber);
      EnrichmentNodeNumber2CmdbData enrichmentNodeNumber2CmdbData = EnrichmentNodeNumber2CmdbDataFactory.create(elementNumber, cmdbConcatLink);
      nodeNumber2CmdbDatas.add(enrichmentNodeNumber2CmdbData);
    }
    if (_logger.isDebugEnabled())
      _logger.debug("finish fillNodeNumber2CmdbLink for cmdbLink " + cmdbLink.getID());

    return nodeNumber2CmdbDatas;
  }

  private CmdbProperties mergeProperties(EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas, PatternElementNumber elementNumber, CmdbData cmdbDataIn) {
    CmdbProperty cmdbProperty;
    if (_logger.isDebugEnabled())
      _logger.debug("start mergeProperties for elementNumber " + elementNumber);

    CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
    CmdbData cmdbData = nodeNumber2CmdbDatas.get(elementNumber);
    ReadOnlyIterator iterProperties = cmdbData.getPropertiesIterator();
    while (iterProperties.hasNext()) {
      cmdbProperty = (CmdbProperty)iterProperties.next();
      cmdbProperties.add(cmdbProperty);
    }
    iterProperties = cmdbDataIn.getPropertiesIterator();
    while (iterProperties.hasNext()) {
      cmdbProperty = (CmdbProperty)iterProperties.next();
      if (!(cmdbProperties.contains(cmdbProperty.getKey())))
        cmdbProperties.add(cmdbProperty);
    }

    if (_logger.isDebugEnabled())
      _logger.debug("finish mergeProperties for elementNumber " + elementNumber);

    return cmdbProperties;
  }

  private CmdbObject restoreObject(CmdbObjectID cmdbObjectID, String type, CmdbProperties cmdbProperties) {
    return getDataFactory().restoreObject(cmdbObjectID, type, cmdbProperties);
  }

  private CmdbLink restoreLink(CmdbLinkID cmdbLinkID, String type, CmdbObjectID end1, CmdbObjectID end2, CmdbProperties cmdbProperties) {
    return getDataFactory().restoreLink(cmdbLinkID, type, end1, end2, cmdbProperties);
  }

  private CmdbObject createObject(String enrichmentName, EnrichmentObject enrichmentObject, EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas)
  {
    if (_logger.isDebugEnabled())
      _logger.debug("start createObject for enrichmentName " + enrichmentName);

    CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
    EnrichmentImmutableAttributes enrichmentAttributes = enrichmentObject.getEnrichmentAttributes();
    if ((enrichmentAttributes != null) && (!(enrichmentAttributes.isEmpty()))) {
      ReadOnlyIterator iter = enrichmentAttributes.getElementsIterator();
      while (iter.hasNext()) {
        EnrichmentAttribute enrichmentAttribute = (EnrichmentAttribute)iter.next();
        EnrichmentExpression enrichmentExpression = enrichmentAttribute.getEnrichmentExpression();
        Object value = enrichmentExpression.getCalculateExpression(nodeNumber2CmdbDatas);
        String attributeName = enrichmentAttribute.getAttributeName();
        CmdbProperty cmdbProperty = EnrichmentUtil.createProperty(enrichmentObject.getClassName(), attributeName, value, getSynchronizedClassModel());
        cmdbProperties.add(cmdbProperty);
      }
    }
    CmdbProperty cmdbProperty = createDataSourceProperty(enrichmentName);
    cmdbProperties.add(cmdbProperty);

    CmdbObject cmdbObject = getDataFactory().createObject(enrichmentObject.getClassName(), cmdbProperties);

    if (_logger.isDebugEnabled())
      _logger.debug("finish createObject for enrichmentName " + enrichmentName + ", cmdbObject " + cmdbObject.getID());

    return cmdbObject;
  }

  private CmdbObject updateObject(EnrichmentObject enrichmentObject, EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas)
  {
    if (_logger.isDebugEnabled())
      _logger.debug("start updateObject");

    CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
    EnrichmentImmutableAttributes enrichmentAttributes = enrichmentObject.getEnrichmentAttributes();
    if ((enrichmentAttributes != null) && (!(enrichmentAttributes.isEmpty()))) {
      ReadOnlyIterator iter = enrichmentAttributes.getElementsIterator();
      while (iter.hasNext()) {
        EnrichmentAttribute enrichmentAttribute = (EnrichmentAttribute)iter.next();
        EnrichmentExpression enrichmentExpression = enrichmentAttribute.getEnrichmentExpression();
        Object value = enrichmentExpression.getCalculateExpression(nodeNumber2CmdbDatas);
        String attributeName = enrichmentAttribute.getAttributeName();
        CmdbProperty cmdbProperty = EnrichmentUtil.createProperty(enrichmentObject.getClassName(), attributeName, value, getSynchronizedClassModel());
        cmdbProperties.add(cmdbProperty);
      }
    }

    CmdbObject cmdbObject = (CmdbObject)nodeNumber2CmdbDatas.get(enrichmentObject.getNodeNumber());
    DataFactory dataFactory = DataFactoryCreator.create(getSynchronizedClassModel());
    cmdbObject = dataFactory.restoreObject((CmdbObjectID)cmdbObject.getID(), cmdbObject.getType(), cmdbProperties);

    if (_logger.isDebugEnabled())
      _logger.debug("finish updateObject for cmdbObject " + cmdbObject.getID());

    return cmdbObject;
  }

  private CmdbLink createLink(String enrichmentName, EnrichmentLink enrichmentLink, EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas)
  {
    if (_logger.isDebugEnabled())
      _logger.debug("start createLink for enrichmentName " + enrichmentName);

    PatternElementNumber linkEnd1 = enrichmentLink.getNodeNumberEnd1();
    PatternElementNumber linkEnd2 = enrichmentLink.getNodeNumberEnd2();

    CmdbObject obj1 = (CmdbObject)nodeNumber2CmdbDatas.get(linkEnd1);
    CmdbObject obj2 = (CmdbObject)nodeNumber2CmdbDatas.get(linkEnd2);

    CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
    EnrichmentImmutableAttributes enrichmentAttributes = enrichmentLink.getEnrichmentAttributes();
    if ((enrichmentAttributes != null) && (!(enrichmentAttributes.isEmpty()))) {
      ReadOnlyIterator iter = enrichmentAttributes.getElementsIterator();
      while (iter.hasNext()) {
        EnrichmentAttribute enrichmentAttribute = (EnrichmentAttribute)iter.next();
        EnrichmentExpression enrichmentExpression = enrichmentAttribute.getEnrichmentExpression();
        Object value = enrichmentExpression.getCalculateExpression(nodeNumber2CmdbDatas);
        String attributeName = enrichmentAttribute.getAttributeName();
        CmdbProperty cmdbProperty = EnrichmentUtil.createProperty(enrichmentLink.getClassName(), attributeName, value, getSynchronizedClassModel());
        cmdbProperties.add(cmdbProperty);
      }
    }
    CmdbProperty cmdbProperty = createDataSourceProperty(enrichmentName);
    cmdbProperties.add(cmdbProperty);

    CmdbLink cmdbLink = getDataFactory().createLink(enrichmentLink.getClassName(), (CmdbObjectID)obj1.getID(), (CmdbObjectID)obj2.getID(), cmdbProperties);

    if (_logger.isDebugEnabled())
      _logger.debug("finish createLink for enrichmentName " + enrichmentName + ", cmdbLink " + cmdbLink.getID());

    return cmdbLink;
  }

  private CmdbLink updateLink(EnrichmentLink enrichmentLink, EnrichmentNodeNumber2CmdbDatas nodeNumber2CmdbDatas) {
    if (_logger.isDebugEnabled())
      _logger.debug("start updateLink");

    CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
    EnrichmentImmutableAttributes enrichmentAttributes = enrichmentLink.getEnrichmentAttributes();
    if ((enrichmentAttributes != null) && (!(enrichmentAttributes.isEmpty()))) {
      ReadOnlyIterator iter = enrichmentAttributes.getElementsIterator();
      while (iter.hasNext()) {
        EnrichmentAttribute enrichmentAttribute = (EnrichmentAttribute)iter.next();
        EnrichmentExpression enrichmentExpression = enrichmentAttribute.getEnrichmentExpression();
        Object value = enrichmentExpression.getCalculateExpression(nodeNumber2CmdbDatas);
        String attributeName = enrichmentAttribute.getAttributeName();
        CmdbProperty cmdbProperty = EnrichmentUtil.createProperty(enrichmentLink.getClassName(), attributeName, value, getSynchronizedClassModel());
        cmdbProperties.add(cmdbProperty);
      }
    }

    CmdbLink cmdbLink = (CmdbLink)nodeNumber2CmdbDatas.get(enrichmentLink.getNodeNumber());
    DataFactory dataFactory = DataFactoryCreator.create(getSynchronizedClassModel());
    cmdbLink = dataFactory.restoreLink((CmdbLinkID)cmdbLink.getID(), cmdbLink.getType(), cmdbLink.getEnd1(), cmdbLink.getEnd2(), cmdbProperties);

    if (_logger.isDebugEnabled())
      _logger.debug("finish updateLink for cmdbLink " + cmdbLink.getID());

    return cmdbLink;
  }

  private PatternInstances getInstances(EnrichmentDefinition enrichmentDefinition, Pattern pattern, TqlResultMap requiredObjects) {
    PatternInstances patternInstances;
    PatternElementNumbers dstNodeNumbers = enrichmentDefinition.getDestPatternNodeNumbers();

    if (_logger.isDebugEnabled()) {
      _logger.debug("getInstances patternId: " + pattern.getID() + ", dstNodeNumbers: " + dstNodeNumbers + ", requiredObjects: " + requiredObjects);
    }

    Pattern pattern4GetInstances = enrichmentDefinition.getPattern4GetInstances(pattern);

    if (dstNodeNumbers.size() == 1) {
      if (requiredObjects == null) {
        TqlQueryGetResultMap tqlQueryGetResultMap = new TqlQueryGetResultMap(pattern.getID());
        executeOperation(tqlQueryGetResultMap);
        if (tqlQueryGetResultMap.isDividedToChunks()) {
          requiredObjects = TqlResultMapUtils.getResultInChunks(tqlQueryGetResultMap.getChunkRequest(), this, true);
        }
        else
          requiredObjects = tqlQueryGetResultMap.getResultMap();
      }

      PatternElementNumber patternElementNumber = (PatternElementNumber)dstNodeNumbers.getElementIdsIterator().next();
      patternInstances = getResultInstances(pattern, requiredObjects, patternElementNumber);
    }
    else
    {
      TqlQueryGetInstances tqlQueryGetInstances;
      if (requiredObjects == null) {
        tqlQueryGetInstances = new TqlQueryGetInstances(pattern.getID(), dstNodeNumbers, enrichmentDefinition.getPatternLayout());
      }
      else
        tqlQueryGetInstances = new TqlQueryGetInstances(pattern.getID(), dstNodeNumbers, requiredObjects, enrichmentDefinition.getPatternLayout(), pattern4GetInstances);

      executeOperation(tqlQueryGetInstances);
      patternInstances = tqlQueryGetInstances.getResultInstances();
    }
    if (_logger.isDebugEnabled())
      _logger.debug("patternInstances: " + patternInstances);

    return patternInstances;
  }

  private EnrichmentPatternInstances getResultInstances(Pattern pattern, TqlResultMap requiredObjects, PatternElementNumber patternElementNumber)
  {
    EnrichmentPatternInstances enrichmentPatternInstances = EnrichmentPatternInstanceFactory.createEnrichmentPatternInstances();

    if (requiredObjects.containsElementNumber(patternElementNumber)) {
      EnrichmentPatternInstance enrichmentPatternInstance;
      if (pattern.getPatternGraph().isNode(patternElementNumber)) {
        CmdbObjects cmdbObjects = requiredObjects.getObjects(patternElementNumber);
        ReadOnlyIterator iterObjects = cmdbObjects.getObjectsIterator();
        while (iterObjects.hasNext()) {
          CmdbObject cmdbObject = (CmdbObject)iterObjects.next();
          enrichmentPatternInstance = EnrichmentPatternInstanceFactory.createEnrichmentPatternInstance();
          enrichmentPatternInstance.addObject(patternElementNumber, cmdbObject);
          enrichmentPatternInstances.add(enrichmentPatternInstance);
        }
      }
      else {
        CmdbLinks cmdbLinks = requiredObjects.getLinks(patternElementNumber);
        ReadOnlyIterator iterLinks = cmdbLinks.getLinksIterator();
        while (iterLinks.hasNext()) {
          CmdbLink cmdbLink = (CmdbLink)iterLinks.next();
          enrichmentPatternInstance = EnrichmentPatternInstanceFactory.createEnrichmentPatternInstance();
          enrichmentPatternInstance.addLink(patternElementNumber, cmdbLink);
          enrichmentPatternInstances.add(enrichmentPatternInstance);
        }
      }
    }
    return enrichmentPatternInstances;
  }

  protected static Changer createChanger(String enrichmentName) {
    String shortName = getShortEnrichmentName(enrichmentName);
    Changer changer = ChangerFactory.createChanger(ChangerType.ENRICHMENT.getType(), "Enrichment's rule: " + shortName);
    return changer;
  }

  protected void createModelOperations(EnrichmentDefinition enrichmentDefinition, ModelUpdateOperations listPerOperation) {
    if (_logger.isDebugEnabled()) {
      _logger.debug("listPerOperation: " + listPerOperation);
    }

    if (fuseOk(enrichmentDefinition, listPerOperation)) {
      Changer changer = createChanger(enrichmentDefinition.getEnrichmentName());
      ModelUpdateBulksOptimistic modelUpdateBulks = new ModelUpdateBulksOptimistic(changer);
      long currentModelChangesNum = 0L;
      EnrichmentModelBulkContainer bulkContainer = new EnrichmentModelBulkContainer(modelUpdateBulks, currentModelChangesNum);

      CmdbObjects objects2Create = listPerOperation.getObjects4Create();
      EnrichmentCreateObjects enrichmentCreateObjects = new EnrichmentCreateObjects(this, enrichmentDefinition, objects2Create, bulkContainer, changer, getModelChangesChunkSize());

      bulkContainer = enrichmentCreateObjects.fillBulk();

      CmdbObjects objects2Update = listPerOperation.getObjects4Update();
      EnrichmentUpdateObjects enrichmentUpdateObjects = new EnrichmentUpdateObjects(this, enrichmentDefinition, objects2Update, bulkContainer, changer, getModelChangesChunkSize());

      bulkContainer = enrichmentUpdateObjects.fillBulk();

      CmdbObjectIds objectsIDs2remove = listPerOperation.getObjectsIDs4remove();
      EnrichmentRemoveObjects enrichmentRemoveObjects = new EnrichmentRemoveObjects(this, enrichmentDefinition, objectsIDs2remove, bulkContainer, changer, getModelChangesChunkSize());

      bulkContainer = enrichmentRemoveObjects.fillBulk();

      CmdbLinks links2Create = listPerOperation.getLinks4Create();
      EnrichmentCreateLinks enrichmentCreateLinks = new EnrichmentCreateLinks(this, enrichmentDefinition, links2Create, bulkContainer, changer, getModelChangesChunkSize());

      bulkContainer = enrichmentCreateLinks.fillBulk();

      CmdbLinks links2Update = listPerOperation.getLinks4Update();
      EnrichmentUpdateLinks enrichmentUpdateLinks = new EnrichmentUpdateLinks(this, enrichmentDefinition, links2Update, bulkContainer, changer, getModelChangesChunkSize());

      bulkContainer = enrichmentUpdateLinks.fillBulk();

      CmdbLinks links2Remove = listPerOperation.getLinks4Remove();
      EnrichmentRemoveLinks enrichmentRemoveLinks = new EnrichmentRemoveLinks(this, enrichmentDefinition, links2Remove, bulkContainer, changer, getModelChangesChunkSize());

      bulkContainer = enrichmentRemoveLinks.fillBulk();

      updateObjectsAndLinks2Model(bulkContainer.getModelUpdateBulks());

      CmdbObjectIds objects2Touch = listPerOperation.getObjectsIDs4Touch();
      new EnrichmentTouchObjects(this, enrichmentDefinition, objects2Touch, changer, getModelChangesChunkSize()).executeUpdate();

      CmdbLinkIds links2Touch = listPerOperation.getLinksIds4Touch();
      new EnrichmentTouchLinks(this, enrichmentDefinition, links2Touch, changer, getModelChangesChunkSize()).executeUpdate();

      listPerOperation.init();
    }
  }

  private long getModelChangesChunkSize() {
    if (this._modelChangesChunkSize == 0L) {
      SettingsReader settingsReader = getSettingsReader();
      this._modelChangesChunkSize = settingsReader.getLong("enrichment.model.changes.chunk.size", 50000L);
    }

    return this._modelChangesChunkSize;
  }

  protected void updateObjectsAndLinks2Model(ModelUpdateBulksOptimistic modelUpdateBulks) {
    if (_logger.isDebugEnabled())
      _logger.debug("modelUpdateOperations: " + modelUpdateBulks);

    executeAsynchronousOperation(modelUpdateBulks);
  }

  public void removeObjectsAndLinksCreatedByEnrichment(String enrichmentName)
  {
    Pattern pattern = EnrichmentRemoveResultsUtil.retrieveLinksCreatedByEnrichment(enrichmentName);
    removeLinksCreatedByEnrichment(enrichmentName, pattern);

    pattern = EnrichmentRemoveResultsUtil.createObjectsCreatedByEnrichmentPattern(enrichmentName);
    removeObjectsCreatedByEnrichment(enrichmentName, pattern);
  }

  private void removeLinksCreatedByEnrichment(String enrichmentName, Pattern pattern)
  {
    PatternElementNumber patternElementNumberLink = EnrichmentRemoveResultsUtil.LINK_ELEMENT_NUMBER;
    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    patternLayout.setElementLayout(patternElementNumberLink, elementSimpleLayout);

    TqlQueryGetAdHocMap tqlQueryGetAdHocMap = new TqlQueryGetAdHocMap(pattern, patternLayout);
    executeOperation(tqlQueryGetAdHocMap);
    if (tqlQueryGetAdHocMap.isDividedToChunks()) {
      _logger.warn("Don't handle remove links when result return by chunks");
    } else {
      TqlResultMap tqlResultMap = tqlQueryGetAdHocMap.getResultMap();
      if (tqlResultMap.linksSize() > 0) {
        CmdbLinks cmdbLinks = tqlResultMap.getLinks(patternElementNumberLink);

        Changer changer = createChanger(enrichmentName);
        ModelUpdateRemoveLinksStrict modelUpdateRemoveLinks = new ModelUpdateRemoveLinksStrict(cmdbLinks, changer);
        executeOperation(modelUpdateRemoveLinks);
      }

      if (_enrichmentLogger.isInfoEnabled()) {
        int linksAmount = tqlResultMap.linksSize();
        _enrichmentLogger.info(enrichmentName + " -- " + "removed " + linksAmount + " link/s");
      }
    }
  }

  private void removeObjectsCreatedByEnrichment(String enrichmentName, Pattern pattern)
  {
    PatternElementNumber patternElementNumberNode = EnrichmentRemoveResultsUtil.NODE_ELEMENT_NUMBER;
    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    patternLayout.setElementLayout(patternElementNumberNode, elementSimpleLayout);

    CmdbGraph cmdbGraph = getAdHocGraph(pattern, patternLayout);
    Changer changer = createChanger(enrichmentName);
    ModelUpdateRemoveGraph modelUpdateRemoveGraph = new ModelUpdateRemoveGraph(cmdbGraph, changer);
    executeOperation(modelUpdateRemoveGraph);

    if (_enrichmentLogger.isInfoEnabled()) {
      int objectsAmount = 0;
      if (cmdbGraph.hasRoots())
        objectsAmount = cmdbGraph.getObjectsAmount();

      _enrichmentLogger.info(enrichmentName + " -- " + "removed " + objectsAmount + " object/s");
    }
  }

  protected SettingsReader getSettingsReader() {
    return getLocalEnvironment().getSettingsReader();
  }

  protected static String getShortEnrichmentName(String enrichmentName) {
    String shortName = enrichmentName;
    if (shortName.length() > 50) {
      CmdbEnrichmentID enrichmentID = CmdbEnrichmentIDFactory.createObjectID(enrichmentName);
      shortName = enrichmentID.getDigest().toString();
    }
    return shortName;
  }

  private static String getDataSourceValue(String enrichmentName)
  {
    String dataSourceValue = "enrichment." + getShortEnrichmentName(enrichmentName);
    return dataSourceValue;
  }

  protected CmdbProperty createDataSourceProperty(String enrichmentName) {
    String dataSourceValue = getDataSourceValue(enrichmentName);
    CmdbProperty cmdbProperty = EnrichmentUtil.createProperty(CmdbSimpleTypes.CmdbString, "data_source", dataSourceValue);
    return cmdbProperty;
  }

  public static ElementPropertiesCondition getDataSourceCondition(String enrichmentName) {
    String dataSourceValue = getDataSourceValue(enrichmentName);
    ModifiableElementPropertiesCondition propertiesCondition = PatternConditionFactory.createElementPropertiesCondition();
    PropertyCondition propertyCondition = PatternConditionFactory.createPropertyCondition("data_source", ConditionOperator.EQUEL, dataSourceValue, false);
    propertiesCondition.addPropertyCondition(propertyCondition);
    return propertiesCondition;
  }

  protected EnrichmentDefinition retrieveEnrichmentDefinitionByEnrichmentName(String enrichmentName) {
    EnrichmentQueryGetEnrichmentDefinition enrichmentQueryGetEnrichmentDefinition = new EnrichmentQueryGetEnrichmentDefinition(enrichmentName);
    executeOperation(enrichmentQueryGetEnrichmentDefinition);
    EnrichmentDefinition enrichmentDefinition = enrichmentQueryGetEnrichmentDefinition.getEnrichmentDefinition();

    return enrichmentDefinition;
  }

  protected Pattern retrievePatternById(EnrichmentDefinition enrichmentDefinition)
  {
    CmdbPatternID patternId = enrichmentDefinition.getOriginalPatternId();
    TqlQueryGetPattern tqlQueryGetPattern = new TqlQueryGetPattern(patternId, true);
    executeOperation(tqlQueryGetPattern);
    Pattern pattern = tqlQueryGetPattern.getPattern();
    if (pattern == null)
      throw new EnrichmentValidationException(enrichmentDefinition.getEnrichmentName() + " -- " + "Pattern " + patternId + " for Enrichment " + enrichmentDefinition.getEnrichmentName() + " doesn't exist in the model", ErrorCode.MISSING_PATTERN);

    return pattern;
  }

  protected CmdbGraph getAdHocGraph(Pattern pattern, PatternLayout patternLayout)
  {
    TqlQueryGetAdHocGraph tqlQueryGetAdHocGraph = new TqlQueryGetAdHocGraph(pattern, patternLayout);
    executeOperation(tqlQueryGetAdHocGraph);
    CmdbGraph cmdbGraph = tqlQueryGetAdHocGraph.getResultGraph();
    return cmdbGraph;
  }
}