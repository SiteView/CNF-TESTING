package com.mercury.topaz.cmdb.server.enrichment.definition.task;

public class EnrichmentDefinitionTask
{
  public static final String NAME = "Enrichment Definition Task";
}