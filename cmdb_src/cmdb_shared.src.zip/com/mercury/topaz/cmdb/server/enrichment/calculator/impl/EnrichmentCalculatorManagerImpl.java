package com.mercury.topaz.cmdb.server.enrichment.calculator.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadMultiWrite;
import com.mercury.topaz.cmdb.server.enrichment.calculator.EnrichmentCalculatorManager;
import com.mercury.topaz.cmdb.server.enrichment.calculator.tqlnotification.impl.EnrichmentPatternResultChangeListenerImpl;
import com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl.EnrichmentUpdateEnrichmentDefinitionIsCalculated;
import com.mercury.topaz.cmdb.server.enrichment.util.EnrichmentResultCountUtil;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.tql.manager.TqlResultUtilsManager;
import com.mercury.topaz.cmdb.server.tql.operation.command.impl.TqlCommandSchedulerStartPattern;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.id.CmdbEnrichmentID;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.impl.EnrichmentQueryGetEnrichmentDefinitionsByPatternId;
import com.mercury.topaz.cmdb.shared.enrichment.definition.result.EnrichmentResultCount;
import com.mercury.topaz.cmdb.shared.notification.filter.CmdbNotificationFilter;
import com.mercury.topaz.cmdb.shared.notification.operation.command.impl.DeploymentCommandRegisterFineGrainedListener;
import com.mercury.topaz.cmdb.shared.tql.change.TqlNotificationData;
import com.mercury.topaz.cmdb.shared.tql.change.filter.impl.TqlNotificationFilterFactory;
import com.mercury.topaz.cmdb.shared.tql.change.impl.TqlChangeAddElement;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultCount;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultCount;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.version.CmdbPatternVersion;
import com.mercury.topaz.cmdb.shared.tql.result.version.CmdbResultVersion;
import com.mercury.topaz.cmdb.shared.tql.result.version.CmdbVersion;
import com.mercury.topaz.cmdb.shared.tql.result.version.impl.CmdbVersionFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

class EnrichmentCalculatorManagerImpl extends AbstractEnrichmentCalculatorManager
  implements EnrichmentCalculatorManager, MultiReadMultiWrite
{
  private static Log _logger = LogFactory.getEasyLog(EnrichmentCalculatorManagerImpl.class);

  EnrichmentCalculatorManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public void startUp() {
    try {
      Framework.getInstance().allocateThreadPool(this, ServerApiFacade.getSettingsReader().getInt("enrichment.calculator.manager.async.thread.pool.size", 5));

      register2PatternCalculationsChanges();

      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: EnrichmentCalculatorManager is started up properly!!!");
    }
    catch (Exception ex) {
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: EnrichmentCalculatorManager failed to start up!!!");
      _logger.error("EnrichmentCalculatorManager failed to start up", ex);
    }
  }

  public void shutdown() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: EnrichmentCalculatorManager is shutdown properly!!!");
  }

  private void register2PatternCalculationsChanges()
  {
    EnrichmentPatternResultChangeListenerImpl enrichmentPatternResultChangeListener = new EnrichmentPatternResultChangeListenerImpl(getLocalEnvironment().getCustomerID());
    CmdbNotificationFilter cmdbNotificationFilter = TqlNotificationFilterFactory.createFilter(PatternGroupId.PATTERN_GROUP_SERVERDATA);
    DeploymentCommandRegisterFineGrainedListener deploymentCommandRegisterFineGrainedListener = new DeploymentCommandRegisterFineGrainedListener(enrichmentPatternResultChangeListener, cmdbNotificationFilter);

    executeOperation(deploymentCommandRegisterFineGrainedListener);
  }

  public void calculateEnrichment(CmdbEnrichmentID cmdbEnrichmentID, int tqlNotification)
  {
    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(cmdbEnrichmentID + " -- " + "Trigger the calculate enrichment");

    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinitionByEnrichmentName(cmdbEnrichmentID.getEnrichmentName());

    Pattern pattern = retrievePatternById(enrichmentDefinition);
    CmdbPatternID patternId = pattern.getID();

    CmdbPatternVersion patternVersion = CmdbVersionFactory.createPatternVersion(2L);
    CmdbResultVersion resultVersion = TqlResultUtilsManager.FIRST_CALCULATION_PATTERN_RESULT_VERSION;
    CmdbVersion cmdbVersion = CmdbVersionFactory.createVersion(patternVersion, resultVersion);

    if (isCalculateRequired(enrichmentDefinition, patternId, tqlNotification, cmdbVersion))
    {
      TqlQueryGetResultMap getMap = getResultMap(enrichmentDefinition.getOriginalPatternId(), enrichmentDefinition.getPatternLayout());

      if (getMap.isDividedToChunks()) {
        TqlNotificationData tqlNotificationData = new TqlChangeAddElement(pattern, null, cmdbVersion);
        calculateEnrichment(tqlNotificationData, 0, enrichmentDefinition);
      }
      else {
        TqlResultMap tqlResultMap = getMap.getResultMap();
        cmdbVersion = tqlResultMap.getCmdbVersion();
        TqlNotificationData tqlNotificationData = new TqlChangeAddElement(pattern, tqlResultMap, cmdbVersion);
        calculateEnrichment(tqlNotificationData, tqlNotification, enrichmentDefinition);
      }
    }
    else
    {
      startCalculatePattern(patternId);
    }
  }

  public void calculateEnrichment(TqlNotificationData tqlNotificationData, int tqlNotification)
  {
    Pattern pattern = tqlNotificationData.getPattern();
    CmdbPatternID patternId = pattern.getID();

    EnrichmentDefinitions enrichmentDefinitions = retrieveEnrichmentDefinitionsByPatternId(patternId);
    ReadOnlyIterator iterDefinitions = enrichmentDefinitions.getElementsIterator();
    while (iterDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterDefinitions.next();
      calculateEnrichment(tqlNotificationData, tqlNotification, enrichmentDefinition);
    }
  }

  private void calculateEnrichment(TqlNotificationData tqlNotificationData, int tqlNotification, EnrichmentDefinition enrichmentDefinition) {
    CmdbVersion cmdbVersion = tqlNotificationData.getVersion();
    Pattern pattern = tqlNotificationData.getPattern();
    CmdbPatternID patternId = pattern.getID();

    if (isCalculateRequired(enrichmentDefinition, patternId, tqlNotification, cmdbVersion))
      try
      {
        setEnrichmentDefinitionIsCalculated(enrichmentDefinition, false);

        if (_enrichmentLogger.isInfoEnabled()) {
          _enrichmentLogger.info(enrichmentDefinition.getEnrichmentName() + " -- " + "Start calculate enrichment related to pattern: " + patternId + " with version " + cmdbVersion);
        }

        if (_logger.isDebugEnabled()) {
          _logger.debug(enrichmentDefinition.getEnrichmentName() + " -- " + "Start fillListPerOperation for enrichment");
        }

        ModelUpdateOperations listPerOperation = new ModelUpdateOperations();

        TqlResultMap requiredObjects = tqlNotificationData.getChanges();

        fillListPerOperation(enrichmentDefinition, pattern, requiredObjects, listPerOperation);

        if (_logger.isDebugEnabled()) {
          _logger.debug(enrichmentDefinition.getEnrichmentName() + " -- " + "Finished fillListPerOperation for enrichment");
        }

        createModelOperations(enrichmentDefinition, listPerOperation);

        setEnrichmentDefinitionIsCalculated(enrichmentDefinition, true);

        if (_enrichmentLogger.isInfoEnabled())
          _enrichmentLogger.info(enrichmentDefinition.getEnrichmentName() + " -- " + "Finished calculate enrichment related to pattern: " + patternId);
      }
      catch (Exception ex)
      {
        String msg = enrichmentDefinition.getEnrichmentName() + " -- " + "Failed to calculate enrichment related to pattern: " + patternId;
        _logger.error(msg, ex);
        _enrichmentLogger.error(msg, ex);
      }
  }

  private boolean isCalculateRequired(EnrichmentDefinition enrichmentDefinition, CmdbPatternID patternId, int tqlNotification, CmdbVersion cmdbVersion)
  {
    if (tqlNotification != 3) {
      String msg = enrichmentDefinition.getEnrichmentName() + " -- " + "Didn't calculate the enrichment that is related to the pattern: " + patternId + " since ";
      if (!(enrichmentDefinition.getIsActive())) {
        if (_enrichmentLogger.isInfoEnabled())
          _enrichmentLogger.info(msg + "enrichment is not active");

        return false;
      }
      if ((enrichmentDefinition.getIsCalculated()) && (TqlResultUtilsManager.FIRST_CALCULATION_PATTERN_RESULT_VERSION.equals(cmdbVersion.getResultVersion()))) {
        if (_enrichmentLogger.isInfoEnabled())
          _enrichmentLogger.info(msg + "enrichment was calculated before");

        return false;
      }
      if (TqlResultUtilsManager.NOT_CALCULATED_PATTERN_RESULT_VERSION.equals(cmdbVersion.getResultVersion())) {
        if (_enrichmentLogger.isInfoEnabled())
          _enrichmentLogger.info(msg + "pattern is not calculated yet");

        return false;
      }
    }
    return true;
  }

  protected void setEnrichmentDefinitionIsCalculated(EnrichmentDefinition enrichmentDefinition, boolean isCalculated) {
    EnrichmentUpdateEnrichmentDefinitionIsCalculated enrichmentUpdateEnrichmentDefinitionIsCalculated = new EnrichmentUpdateEnrichmentDefinitionIsCalculated(enrichmentDefinition, isCalculated);

    executeOperation(enrichmentUpdateEnrichmentDefinitionIsCalculated);
  }

  public EnrichmentResultCount getResultCount(EnrichmentDefinition enrichmentDefinition)
  {
    Pattern pattern = retrievePatternById(enrichmentDefinition);

    ModifiablePatternGraph patternGraph = EnrichmentResultCountUtil.createGraph(enrichmentDefinition, pattern);

    TqlResultCount result = getResultCount(enrichmentDefinition, patternGraph);

    return EnrichmentResultCountUtil.convertTqlResultCount2EnrichmentResultCount(patternGraph, result);
  }

  protected EnrichmentDefinitions retrieveEnrichmentDefinitionsByPatternId(CmdbPatternID patternId)
  {
    EnrichmentQueryGetEnrichmentDefinitionsByPatternId enrichmentGetEnrichmentDefinitionsByPatternId = new EnrichmentQueryGetEnrichmentDefinitionsByPatternId(patternId);
    executeOperation(enrichmentGetEnrichmentDefinitionsByPatternId);

    return enrichmentGetEnrichmentDefinitionsByPatternId.getEnrichmentDefinitions();
  }

  protected TqlQueryGetResultMap getResultMap(CmdbPatternID patternID, PatternLayout patternLayout) {
    TqlQueryGetResultMap getMap = new TqlQueryGetResultMap(patternID, patternLayout);
    executeOperation(getMap);
    return getMap;
  }

  protected void startCalculatePattern(CmdbPatternID patternID) {
    TqlCommandSchedulerStartPattern startCalculatePattern = new TqlCommandSchedulerStartPattern(patternID);
    executeOperation(startCalculatePattern);
  }

  protected TqlResultCount getResultCount(EnrichmentDefinition enrichmentDefinition, PatternGraph patternGraph) {
    ModifiablePattern pattern = PatternDefinitionFactory.createPattern(enrichmentDefinition.getEnrichmentName() + "adhoc", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    TqlQueryGetResultCount adHocCalculate = new TqlQueryGetResultCount(pattern, false);
    executeOperation(adHocCalculate);
    return adHocCalculate.getResultCount();
  }

  public String getName() {
    return "Enrichment Calculator Task";
  }
}