package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.link.id.impl.CmdbLinkIdsFactory;

public class EnrichmentTouchLinks extends AbstractEnrichmentTouch
{
  private CmdbLinkIds _linksIds2Touch = CmdbLinkIdsFactory.create();

  public EnrichmentTouchLinks(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, CmdbLinkIds linksIds2Touch, Changer changer, long modelChangesChunkSize)
  {
    super(operationExecutor, enrichmentDefinition, changer, modelChangesChunkSize, " link/s");

    this._linksIds2Touch.add(linksIds2Touch);
  }

  protected boolean isEmpty() {
    return this._linksIds2Touch.isEmpty();
  }

  protected int size() {
    return this._linksIds2Touch.size();
  }

  protected CmdbIDsCollection getIds2Touch() {
    return this._linksIds2Touch;
  }
}