package com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class EnrichmentUpdateRemoveEnrichmentBusinessViewDefinitionFromRepository extends AbstractEnrichmentDefinitionUpdate
{
  private String _enrichmentName;

  public EnrichmentUpdateRemoveEnrichmentBusinessViewDefinitionFromRepository(String enrichmentName)
  {
    setEnrichmentName(enrichmentName);
  }

  public String getOperationName()
  {
    return "Enrichment Update: Remove business view enrichment{enrichmentName=" + getEnrichmentName() + '}';
  }

  public void doEnrichmentExecute(EnrichmentDefinitionManager enrichmentDefinitionManager, CmdbResponse response)
  {
    enrichmentDefinitionManager.removeEnrichmentBusinessViewDefinition(getEnrichmentName(), true);
  }

  protected void updateValidation(EnrichmentDefinitionManager enrichmentDefinitionManager)
  {
  }

  public String getShortAuditMessage()
  {
    return "Remove " + getEnrichmentName() + " business view enrichment definition";
  }

  public String getDetailedAuditMessage()
  {
    return "Remove " + getEnrichmentName() + " bisiness view enrichment definition";
  }

  public String getEnrichmentName()
  {
    return this._enrichmentName;
  }

  private void setEnrichmentName(String enrichmentName) {
    if (enrichmentName == null)
      throw new IllegalArgumentException("Enrichment name can't be null");

    this._enrichmentName = enrichmentName;
  }
}