package com.mercury.topaz.cmdb.server.enrichment.admin;

import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;

public abstract interface EnrichmentAdminManager extends CmdbSubsystemManager
{
  public abstract void addEnrichmentDefinition(EnrichmentDefinition paramEnrichmentDefinition);

  public abstract void addOrUpdateEnrichmentDefinition(EnrichmentDefinition paramEnrichmentDefinition);

  public abstract void updateEnrichmentDefinition(EnrichmentDefinition paramEnrichmentDefinition);

  public abstract void removeEnrichmentDefinition(String paramString);

  public abstract void activateEnrichmentDefinition(String paramString);

  public abstract void deactivateEnrichmentDefinition(String paramString);

  public abstract boolean isUpdatePatternValid(Pattern paramPattern);

  public abstract void removeEnrichmentDefinitionsByPatternId(CmdbPatternID paramCmdbPatternID);

  public abstract void updateEnrichmentDefinitionsByPattern(Pattern paramPattern);

  public abstract void addEnrichmentDefinition(EnrichmentBusinessViewDefinition paramEnrichmentBusinessViewDefinition);

  public abstract void addOrUpdateEnrichmentDefinition(EnrichmentBusinessViewDefinition paramEnrichmentBusinessViewDefinition);

  public abstract void updateEnrichmentDefinition(EnrichmentBusinessViewDefinition paramEnrichmentBusinessViewDefinition);

  public abstract void removeEnrichmentBusinessViewDefinition(String paramString);

  public abstract Pattern retrievePatternById(CmdbPatternID paramCmdbPatternID);

  public abstract Pattern retrievePatternByName(String paramString);
}