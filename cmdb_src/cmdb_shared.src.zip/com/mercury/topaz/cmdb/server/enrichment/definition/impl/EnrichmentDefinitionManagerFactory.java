package com.mercury.topaz.cmdb.server.enrichment.definition.impl;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public class EnrichmentDefinitionManagerFactory extends AbstractSubsystemManagerFactory
{
  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new EnrichmentDefinitionManagerImpl(localEnvironment);
  }
}