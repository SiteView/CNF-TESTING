package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

abstract class AbstractEnrichmentUpdateLinks extends AbstractEnrichmentUpdate
{
  private CmdbLinks _links;

  public AbstractEnrichmentUpdateLinks(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, CmdbLinks links, EnrichmentModelBulkContainer enrichmentModelBulkContainer, Changer changer, String action, long modelChangesChunkSize)
  {
    super(operationExecutor, enrichmentDefinition, enrichmentModelBulkContainer, changer, action, modelChangesChunkSize, " link/s");
    setLinks(links);
  }

  protected boolean isEmpty() {
    return getLinks().isEmpty();
  }

  protected int size() {
    return getLinks().size();
  }

  protected abstract void addOptimisticModelUpdateOperation(CmdbLinks paramCmdbLinks);

  protected void fillBulkByChunks() {
    long modelChangesChunkSize = getModelChangesChunkSize();
    ModelUpdateBulksOptimistic modelUpdateBulks = getBulkContainer().getModelUpdateBulks();
    long currentModelChangesNum = getBulkContainer().getCurrentModelChangesNum();

    CmdbLinks links2UpdateChunk = CmdbLinkFactory.createLinks();
    ReadOnlyIterator iterLinks = getLinks().getLinksIterator();
    while (iterLinks.hasNext()) {
      CmdbLink link = (CmdbLink)iterLinks.next();
      links2UpdateChunk.add(link);
      currentModelChangesNum += 1L;
      if (currentModelChangesNum == modelChangesChunkSize)
      {
        addOptimisticModelUpdateOperation(links2UpdateChunk);
        updateObjectsAndLinks2Model(modelUpdateBulks);

        modelUpdateBulks = new ModelUpdateBulksOptimistic(getChanger());
        getBulkContainer().setModelUpdateBulks(modelUpdateBulks);
        links2UpdateChunk.clear();
        currentModelChangesNum = 0L;
      }
    }
    if (currentModelChangesNum > 0L)
      addOptimisticModelUpdateOperation(links2UpdateChunk);

    getBulkContainer().setCurrentModelChangesNum(currentModelChangesNum);
  }

  protected CmdbLinks getLinks()
  {
    return this._links;
  }

  private void setLinks(CmdbLinks links) {
    this._links = links;
  }
}