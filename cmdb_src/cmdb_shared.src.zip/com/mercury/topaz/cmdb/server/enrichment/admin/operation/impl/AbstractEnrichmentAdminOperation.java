package com.mercury.topaz.cmdb.server.enrichment.admin.operation.impl;

import com.mercury.topaz.cmdb.server.enrichment.admin.EnrichmentAdminManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.enrichment.admin.operation.EnrichmentAdminOperation;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCmdbOperation;

public abstract class AbstractEnrichmentAdminOperation extends AbstractCmdbOperation
  implements EnrichmentAdminOperation
{
  protected void doExecute(SubsystemManager manager, CmdbResponse response)
    throws EnrichmentValidationException
  {
    enrichmentExecute((EnrichmentAdminManager)manager, response);
  }

  public String getExecutionTaskQueueName()
  {
    return "Enrichment Admin Task";
  }
}