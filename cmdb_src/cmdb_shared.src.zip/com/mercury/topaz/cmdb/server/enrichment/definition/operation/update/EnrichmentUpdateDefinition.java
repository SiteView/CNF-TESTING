package com.mercury.topaz.cmdb.server.enrichment.definition.operation.update;

import com.mercury.topaz.cmdb.server.enrichment.definition.operation.EnrichmentDefinitionOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;

public abstract interface EnrichmentUpdateDefinition
{
}