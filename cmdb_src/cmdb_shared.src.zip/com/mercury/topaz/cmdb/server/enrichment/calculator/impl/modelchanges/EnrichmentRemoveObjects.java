package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsIfExist;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class EnrichmentRemoveObjects extends AbstractEnrichmentUpdate
{
  private CmdbObjectIds _objectsIDs2remove;

  public EnrichmentRemoveObjects(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, CmdbObjectIds objectsIDs2remove, EnrichmentModelBulkContainer enrichmentModelBulkContainer, Changer changer, long modelChangesChunkSize)
  {
    super(operationExecutor, enrichmentDefinition, enrichmentModelBulkContainer, changer, "remove ", modelChangesChunkSize, " object/s");
    setObjectsIDs2remove(objectsIDs2remove);
  }

  protected boolean isEmpty() {
    return getObjectsIDs2remove().isEmpty();
  }

  protected int size() {
    return getObjectsIDs2remove().size();
  }

  protected void fillBulkByChunks() {
    long modelChangesChunkSize = getModelChangesChunkSize();
    ModelUpdateBulksOptimistic modelUpdateBulks = getBulkContainer().getModelUpdateBulks();
    long currentModelChangesNum = getBulkContainer().getCurrentModelChangesNum();

    CmdbObjectIds objectIds2RemoveChunk = CmdbObjectIdsFactory.createIdsList();
    ReadOnlyIterator iterObjects = getObjectsIDs2remove().getIdsIterator();
    while (iterObjects.hasNext()) {
      CmdbObjectID objectId = (CmdbObjectID)iterObjects.next();
      objectIds2RemoveChunk.add(objectId);
      currentModelChangesNum += 1L;
      if (currentModelChangesNum == modelChangesChunkSize)
      {
        addOptimisticModelUpdateOperation(objectIds2RemoveChunk);
        updateObjectsAndLinks2Model(modelUpdateBulks);

        modelUpdateBulks = new ModelUpdateBulksOptimistic(getChanger());
        getBulkContainer().setModelUpdateBulks(modelUpdateBulks);
        objectIds2RemoveChunk.clear();
        currentModelChangesNum = 0L;
      }
    }
    if (currentModelChangesNum > 0L)
      addOptimisticModelUpdateOperation(objectIds2RemoveChunk);

    getBulkContainer().setCurrentModelChangesNum(currentModelChangesNum);
  }

  protected void addOptimisticModelUpdateOperation() {
    addOptimisticModelUpdateOperation(getObjectsIDs2remove());
  }

  private void addOptimisticModelUpdateOperation(CmdbObjectIds objectsIDs2remove) {
    ModelUpdateRemoveObjectsIfExist modelUpdateRemoveObjectsIfExist = new ModelUpdateRemoveObjectsIfExist(objectsIDs2remove, getChanger());
    getBulkContainer().getModelUpdateBulks().addOptimisticModelUpdateOperation(modelUpdateRemoveObjectsIfExist);
  }

  private CmdbObjectIds getObjectsIDs2remove()
  {
    return this._objectsIDs2remove;
  }

  private void setObjectsIDs2remove(CmdbObjectIds objectsIDs2remove) {
    this._objectsIDs2remove = objectsIDs2remove;
  }
}