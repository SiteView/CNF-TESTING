package com.mercury.topaz.cmdb.server.enrichment.calculator.tqlnotification.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.command.impl.EnrichmentCommandCalculator;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.tql.change.TqlNotificationData;
import com.mercury.topaz.cmdb.shared.tql.change.manage.AbstractTqlChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.result.version.CmdbVersion;

public class EnrichmentPatternResultChangeListenerImpl extends AbstractTqlChangeListenerFineGrained
{
  private static Log _logger = LogFactory.getEasyLog(EnrichmentPatternResultChangeListenerImpl.class);

  public EnrichmentPatternResultChangeListenerImpl(CmdbCustomerID customerID)
  {
    super(customerID);
  }

  public void onAdd(TqlNotificationData tqlNotificationData)
  {
    EnrichmentCommandCalculator enrichmentCommandCalculator;
    try
    {
      enrichmentCommandCalculator = new EnrichmentCommandCalculator(tqlNotificationData, 1);
      executeAsynchronousOperation(enrichmentCommandCalculator);
    }
    catch (CmdbResponseException ex) {
      _logger.error("Failed to EnrichmentPatternResultChangeListenerImpl.onAdd()", ex);
    }
  }

  public void onUpdate(TqlNotificationData tqlNotificationData)
  {
    EnrichmentCommandCalculator enrichmentCommandCalculator;
    try
    {
      enrichmentCommandCalculator = new EnrichmentCommandCalculator(tqlNotificationData, 2);
      executeAsynchronousOperation(enrichmentCommandCalculator);
    }
    catch (CmdbResponseException ex) {
      _logger.error("Failed to EnrichmentPatternResultChangeListenerImpl.onAdd()", ex);
    }
  }

  public void onRemove(TqlNotificationData tqlNotificationData)
  {
  }

  public void onChunkedNotification(CmdbVersion cmdbVersion, Pattern pattern)
  {
  }

  public void onStartDeployment()
  {
  }

  public void onFinishDeployment()
  {
  }
}