package com.mercury.topaz.cmdb.server.enrichment.calculator.instances.chunks;

import com.mercury.topaz.cmdb.shared.tql.result.instance.PatternInstances;

public abstract interface InstancesChunkerForEnrichment
{
  public abstract boolean hasNextInstances();

  public abstract PatternInstances getNextInstances();
}