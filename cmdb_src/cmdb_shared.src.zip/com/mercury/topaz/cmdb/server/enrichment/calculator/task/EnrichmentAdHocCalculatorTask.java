package com.mercury.topaz.cmdb.server.enrichment.calculator.task;

public class EnrichmentAdHocCalculatorTask
{
  public static final String NAME = "Enrichment Ad Hoc Calculator Task";
}