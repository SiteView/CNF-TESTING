package com.mercury.topaz.cmdb.server.enrichment.definition;

import com.mercury.topaz.cmdb.server.enrichment.definition.persistence.EnrichmentPersistenceManager;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLinks;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitionsShallow;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.id.CmdbEnrichmentID;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPatternIDPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbStringPropertyValues;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;

public abstract interface EnrichmentDefinitionManager extends EnrichmentPersistenceManager
{
  public static final String ENRICHMENT = "enrichment";
  public static final char CLASS_NAME_DELIMETER = 46;

  public abstract EnrichmentDefinition updateEnrichmentDefinition(EnrichmentDefinition paramEnrichmentDefinition);

  public abstract EnrichmentDefinition updateEnrichmentDefinitionIsCalculated(EnrichmentDefinition paramEnrichmentDefinition, boolean paramBoolean);

  public abstract EnrichmentDefinition getEnrichmentDefinitionByName(String paramString);

  public abstract EnrichmentDefinitions retrieveEnrichmentDefinitions();

  public abstract EnrichmentBusinessViewDefinitions retrieveEnrichmentBusinessViewDefinitions();

  public abstract EnrichmentDefinitions retrieveEnrichmentDefinitionsByPatternId(CmdbPatternID paramCmdbPatternID);

  public abstract EnrichmentDefinitions retrieveEnrichmentDefinitionsAllByPatternId(CmdbPatternID paramCmdbPatternID);

  public abstract EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsByPatternId(CmdbPatternID paramCmdbPatternID);

  public abstract EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsByPatternIds(CmdbPatternIDPropertyValues paramCmdbPatternIDPropertyValues);

  public abstract EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsUsingClass(String paramString);

  public abstract EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsUsingClasses(CmdbStringPropertyValues paramCmdbStringPropertyValues);

  public abstract EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsUsingAttribute(String paramString1, String paramString2);

  public abstract EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsUsingAttributes(String paramString, CmdbStringPropertyValues paramCmdbStringPropertyValues);

  public abstract EnrichmentDefinitionsShallow getInvalidShallowEnrichmentDefinitions(Pattern paramPattern, CmdbEnrichmentID paramCmdbEnrichmentID);

  public abstract Pattern retrievePatternById(CmdbPatternID paramCmdbPatternID);

  public abstract Pattern retrievePatternByName(String paramString);

  public abstract boolean isUpdatePatternValid(Pattern paramPattern);

  public abstract EnrichmentBusinessViewDefinition addEnrichmentDefinition(EnrichmentBusinessViewDefinition paramEnrichmentBusinessViewDefinition);

  public abstract EnrichmentBusinessViewDefinition updateEnrichmentDefinition(EnrichmentBusinessViewDefinition paramEnrichmentBusinessViewDefinition);

  public abstract EnrichmentBusinessViewDefinition removeEnrichmentBusinessViewDefinition(String paramString, boolean paramBoolean);

  public abstract EnrichmentBusinessViewDefinition getEnrichmentBusinessViewDefinitionByName(String paramString);

  public abstract EnrichmentBusinessViewDefinition retrieveEnrichmentBusinessViewDefinitionByPatternName(String paramString);

  public abstract EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsUsingValidLinks(CmdbValidLinks paramCmdbValidLinks);

  public abstract boolean isAnyEnrichmentContainsValidLink(CmdbValidLink paramCmdbValidLink);
}