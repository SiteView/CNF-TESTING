package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;

public class EnrichmentTouchObjects extends AbstractEnrichmentTouch
{
  private CmdbObjectIds _objectsIds2Touch = CmdbObjectIdsFactory.create();

  public EnrichmentTouchObjects(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, CmdbObjectIds objectsIds2Touch, Changer changer, long modelChangesChunkSize)
  {
    super(operationExecutor, enrichmentDefinition, changer, modelChangesChunkSize, " object/s");

    this._objectsIds2Touch.add(objectsIds2Touch);
  }

  protected boolean isEmpty()
  {
    return this._objectsIds2Touch.isEmpty();
  }

  protected int size()
  {
    return this._objectsIds2Touch.size();
  }

  protected CmdbIDsCollection getIds2Touch()
  {
    return this._objectsIds2Touch;
  }
}