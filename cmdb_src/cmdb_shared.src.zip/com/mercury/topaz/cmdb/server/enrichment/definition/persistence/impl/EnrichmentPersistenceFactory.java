package com.mercury.topaz.cmdb.server.enrichment.definition.persistence.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.persistence.EnrichmentPersistenceManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;

public class EnrichmentPersistenceFactory
{
  public static EnrichmentPersistenceManager create(LocalEnvironment localEnvironment)
  {
    return new EnrichmentPersistenceImpl(localEnvironment);
  }
}