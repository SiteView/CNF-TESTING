package com.mercury.topaz.cmdb.server.enrichment.definition.operation.query.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.Properties;

public class EnrichmentQueryGetEnrichmentDefinitionKPI extends AbstractEnrichmentDefinitionQuery
{
  private static final String KEY_ENRICHMENT_DEFINITION_KPI = "enrichment definition KPI";
  private Properties _enrichmentDefinitionKPI;

  public String getOperationName()
  {
    return "Enrichment Query: Get enrichment KPI";
  }

  public void enrichmentExecuteQuery(EnrichmentDefinitionManager enrichmentDefinitionManager, CmdbResponse response)
  {
    int enrichmentDefinitionCount = enrichmentDefinitionManager.retrieveEnrichmentDefinitions().size();
    Properties properties = new Properties();
    properties.put("count", Integer.valueOf(enrichmentDefinitionCount));
    response.addResult("enrichment definition KPI", properties);
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
    Properties enrichmentDefinitionKPI = (Properties)response.getResult("enrichment definition KPI");
    setEnrichmentDefinitionKPI(enrichmentDefinitionKPI);
  }

  public Properties getEnrichmentDefinitionKPI()
  {
    return this._enrichmentDefinitionKPI;
  }

  private void setEnrichmentDefinitionKPI(Properties enrichmentDefinitionKPI) {
    this._enrichmentDefinitionKPI = enrichmentDefinitionKPI;
  }
}