package com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class EnrichmentUpdateUpdateEnrichmentBusinessViewDefinitionToRepository extends AbstractEnrichmentUpdateEnrichmentBusinessViewDefinition
{
  public EnrichmentUpdateUpdateEnrichmentBusinessViewDefinitionToRepository(EnrichmentBusinessViewDefinition enrichmentDefinition)
  {
    setEnrichmentDefinition(enrichmentDefinition);
  }

  public String getOperationName()
  {
    return "Enrichment Update: Update business view enrichment {EnrichmentDefinition=" + getEnrichmentDefinition() + '}';
  }

  public void doEnrichmentExecute(EnrichmentDefinitionManager enrichmentDefinitionManager, CmdbResponse response)
  {
    super.doEnrichmentExecute(enrichmentDefinitionManager, response);

    EnrichmentBusinessViewDefinition enrichmentDefinition = enrichmentDefinitionManager.updateEnrichmentDefinition(getEnrichmentDefinition());
    setEnrichmentDefinition(enrichmentDefinition);
  }

  public String getShortAuditMessage()
  {
    return "Update " + getEnrichmentDefinition().getEnrichmentName() + " business view enrichment definition";
  }

  public String getDetailedAuditMessage()
  {
    return "Update " + getEnrichmentDefinition() + " business view enrichment definition";
  }
}