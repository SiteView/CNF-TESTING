package com.mercury.topaz.cmdb.server.enrichment.definition.persistence;

import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;

public abstract interface EnrichmentPersistenceManager extends CmdbSubsystemManager
{
  public abstract EnrichmentDefinition addEnrichmentDefinition(EnrichmentDefinition paramEnrichmentDefinition);

  public abstract EnrichmentDefinition updateEnrichmentDefinitionRoot(EnrichmentDefinition paramEnrichmentDefinition1, EnrichmentDefinition paramEnrichmentDefinition2);

  public abstract EnrichmentDefinition removeEnrichmentDefinition(String paramString, boolean paramBoolean);

  public abstract EnrichmentDefinitions retrieveAllEnrichmentDefinitions();
}