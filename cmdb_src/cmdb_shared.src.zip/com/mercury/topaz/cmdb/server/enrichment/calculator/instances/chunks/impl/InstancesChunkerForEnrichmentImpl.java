package com.mercury.topaz.cmdb.server.enrichment.calculator.instances.chunks.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.AbstractEnrichmentCalculatorManager;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.EnrichmentPatternInstance;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.EnrichmentPatternInstances;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.chunks.InstancesChunkerForEnrichment;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.impl.EnrichmentPatternInstanceFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumbers;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetInstances;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetInstancesChunk;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultMap;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultMapChunk;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.chunk.ChunkRequest;
import com.mercury.topaz.cmdb.shared.tql.result.instance.PatternInstances;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Iterator;

public class InstancesChunkerForEnrichmentImpl
  implements InstancesChunkerForEnrichment
{
  private EnrichmentDefinition enrichmentDefinition;
  private Pattern pattern;
  private TqlResultMap requiredObjects;
  private static Log _logger = LogFactory.getEasyLog(AbstractEnrichmentCalculatorManager.class);
  private AbstractEnrichmentCalculatorManager manager;
  private ChunkRequest nextChunkRequest;
  private boolean isFirstCalculation;

  public InstancesChunkerForEnrichmentImpl(EnrichmentDefinition enrichmentDefinition, Pattern pattern, TqlResultMap requiredObjects, AbstractEnrichmentCalculatorManager manager)
  {
    this.enrichmentDefinition = enrichmentDefinition;
    this.pattern = pattern;
    this.requiredObjects = requiredObjects;
    this.manager = manager;
    this.isFirstCalculation = true;
  }

  public boolean hasNextInstances() {
    return ((this.isFirstCalculation) || ((this.nextChunkRequest != null) && (this.nextChunkRequest.hasNext())));
  }

  public PatternInstances getNextInstances()
  {
    PatternInstances patternInstances;
    PatternElementNumbers dstNodeNumbers = this.enrichmentDefinition.getDestPatternNodeNumbers();

    if (_logger.isDebugEnabled()) {
      _logger.debug("getInstances patternId: " + this.pattern.getID() + ", dstNodeNumbers: " + dstNodeNumbers + ", requiredObjects: " + this.requiredObjects);
    }

    Pattern pattern4GetInstances = this.enrichmentDefinition.getPattern4GetInstances(this.pattern);

    if (dstNodeNumbers.size() == 1) {
      handle1Node();
      PatternElementNumber patternElementNumber = (PatternElementNumber)dstNodeNumbers.getElementIdsIterator().next();
      patternInstances = getResultInstances(this.pattern, this.requiredObjects, patternElementNumber);
    }
    else {
      patternInstances = handleMoreThan1Node(dstNodeNumbers, pattern4GetInstances);
    }
    if (_logger.isDebugEnabled())
      _logger.debug("patternInstances: " + patternInstances);

    return patternInstances;
  }

  private void handle1Node() {
    if (this.isFirstCalculation) {
      if (this.requiredObjects == null) {
        TqlQueryGetResultMap tqlQueryGetResultMap = new TqlQueryGetResultMap(this.pattern.getID());
        this.manager.executeOperation(tqlQueryGetResultMap);
        if (tqlQueryGetResultMap.isDividedToChunks()) {
          ChunkRequest firstChunkRequest = tqlQueryGetResultMap.getChunkRequest();
          getFirstMapChunk(firstChunkRequest);
        }
        else {
          this.requiredObjects = tqlQueryGetResultMap.getResultMap();
        }
      }
      this.isFirstCalculation = false;
    }
    else {
      getNextMapChunk();
    }
  }

  private void getFirstMapChunk(ChunkRequest chunkRequest) {
    getMapChunk(chunkRequest);
    this.nextChunkRequest = chunkRequest;
  }

  private void getMapChunk(ChunkRequest chunkRequest) {
    TqlQueryGetResultMapChunk getChunk = new TqlQueryGetResultMapChunk(chunkRequest);
    this.manager.executeOperation(getChunk);
    this.requiredObjects = getChunk.getResultMap();
  }

  private void getNextMapChunk() {
    this.nextChunkRequest = this.nextChunkRequest.next();
    getMapChunk(this.nextChunkRequest);
  }

  private PatternInstances handleMoreThan1Node(PatternElementNumbers dstNodeNumbers, Pattern pattern4GetInstances)
  {
    PatternInstances patternInstances;
    if (this.isFirstCalculation) {
      TqlQueryGetInstances tqlQueryGetInstances;
      if (this.requiredObjects == null) {
        tqlQueryGetInstances = new TqlQueryGetInstances(this.pattern.getID(), dstNodeNumbers, this.enrichmentDefinition.getPatternLayout());
      }
      else
        tqlQueryGetInstances = new TqlQueryGetInstances(this.pattern.getID(), dstNodeNumbers, this.requiredObjects, this.enrichmentDefinition.getPatternLayout(), pattern4GetInstances);

      this.manager.executeOperation(tqlQueryGetInstances);
      if (tqlQueryGetInstances.isDividedToChunks()) {
        ChunkRequest firstChunkRequest = tqlQueryGetInstances.getChunkRequest();
        patternInstances = getNextInstancesChunk(firstChunkRequest);
      }
      else {
        patternInstances = tqlQueryGetInstances.getResultInstances();
      }
      this.isFirstCalculation = false;
    }
    else {
      patternInstances = getNextInstancesChunk(this.nextChunkRequest);
    }
    return patternInstances;
  }

  private PatternInstances getNextInstancesChunk(ChunkRequest chunkRequest) {
    TqlQueryGetInstancesChunk getChunk = new TqlQueryGetInstancesChunk(chunkRequest, this.enrichmentDefinition.getPatternLayout());
    this.manager.executeOperation(getChunk);
    this.nextChunkRequest = getChunk.getOutputChunkRequest();
    return getChunk.getResultInstances();
  }

  private EnrichmentPatternInstances getResultInstances(Pattern pattern, TqlResultMap requiredObjects, PatternElementNumber patternElementNumber)
  {
    EnrichmentPatternInstances enrichmentPatternInstances = EnrichmentPatternInstanceFactory.createEnrichmentPatternInstances();

    if (requiredObjects.containsElementNumber(patternElementNumber)) {
      EnrichmentPatternInstance enrichmentPatternInstance;
      if (pattern.getPatternGraph().isNode(patternElementNumber)) {
        CmdbObjects cmdbObjects = requiredObjects.getObjects(patternElementNumber);
        ReadOnlyIterator iterObjects = cmdbObjects.getObjectsIterator();
        while (iterObjects.hasNext()) {
          CmdbObject cmdbObject = (CmdbObject)iterObjects.next();
          enrichmentPatternInstance = EnrichmentPatternInstanceFactory.createEnrichmentPatternInstance();
          enrichmentPatternInstance.addObject(patternElementNumber, cmdbObject);
          enrichmentPatternInstances.add(enrichmentPatternInstance);
        }
      }
      else {
        CmdbLinks cmdbLinks = requiredObjects.getLinks(patternElementNumber);
        ReadOnlyIterator iterLinks = cmdbLinks.getLinksIterator();
        while (iterLinks.hasNext()) {
          CmdbLink cmdbLink = (CmdbLink)iterLinks.next();
          enrichmentPatternInstance = EnrichmentPatternInstanceFactory.createEnrichmentPatternInstance();
          enrichmentPatternInstance.addLink(patternElementNumber, cmdbLink);
          enrichmentPatternInstances.add(enrichmentPatternInstance);
        }
      }
    }
    return enrichmentPatternInstances;
  }
}