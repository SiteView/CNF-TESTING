package com.mercury.topaz.cmdb.server.enrichment.admin.operation.update.impl;

import com.mercury.topaz.cmdb.server.enrichment.admin.EnrichmentAdminManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;

public class EnrichmentUpdateUpdatePattern extends AbstractEnrichmentAdminUpdate
{
  private Pattern _newPattern;

  public EnrichmentUpdateUpdatePattern(Pattern newPattern)
  {
    setNewPattern(newPattern);
  }

  public String getOperationName()
  {
    return "Enrichment Update: Update pattern{new pattern=" + getNewPattern() + '}';
  }

  public void doEnrichmentExecute(EnrichmentAdminManager enrichmentAdminManager, CmdbResponse response)
  {
    if (enrichmentAdminManager.isUpdatePatternValid(getNewPattern())) {
      enrichmentAdminManager.updateEnrichmentDefinitionsByPattern(getNewPattern());
    }
    else
      throw new IllegalArgumentException("This changed Pattern (Enrichment) is not valid. pattern: " + getNewPattern().getName());
  }

  protected void updateValidation(EnrichmentAdminManager enrichmentAdminManager)
  {
  }

  public String getShortAuditMessage()
  {
    return "Update " + getNewPattern().getName() + " enrichment's pattern";
  }

  public String getDetailedAuditMessage()
  {
    return "Update with new enrichment's pattern " + getNewPattern();
  }

  public Pattern getNewPattern() {
    return this._newPattern;
  }

  private void setNewPattern(Pattern newPattern) {
    if (newPattern == null)
      throw new IllegalArgumentException("New pattern can't be null");

    this._newPattern = newPattern;
  }
}