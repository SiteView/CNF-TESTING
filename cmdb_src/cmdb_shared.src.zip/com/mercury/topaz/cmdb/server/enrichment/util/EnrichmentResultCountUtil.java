package com.mercury.topaz.cmdb.server.enrichment.util;

import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.AbstractEnrichmentCalculatorManager;
import com.mercury.topaz.cmdb.shared.base.CmdbConstants.Enrichment.Action;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalOperator;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentActions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentImmutableActions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentLink;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentObject;
import com.mercury.topaz.cmdb.shared.enrichment.definition.result.EnrichmentModifiableResultCount;
import com.mercury.topaz.cmdb.shared.enrichment.definition.result.EnrichmentResultCount;
import com.mercury.topaz.cmdb.shared.enrichment.definition.result.impl.EnrichmentResultFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternElement;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCardinality;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultCount;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.ResultEntry;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.impl.ResultEntryFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.HashMap;

public class EnrichmentResultCountUtil
{
  private static final Integer INITAL_COUNT = new Integer(1);

  public static ModifiablePatternGraph createGraph(EnrichmentDefinition enrichmentDefinition, Pattern pattern)
  {
    ModifiablePatternGraph graph = pattern.getPatternGraph().toModifiableGraph();
    makeElementsPatternInvissible(graph);

    handleCreateLinksAndObjects(enrichmentDefinition, graph);

    return graph;
  }

  public static EnrichmentResultCount convertTqlResultCount2EnrichmentResultCount(PatternGraph patternGraph, TqlResultCount result) {
    ResultEntry resultEntry;
    EnrichmentModifiableResultCount resultCount = EnrichmentResultFactory.createModifiableResultCount();

    HashMap class2count = calculateClass2Count(patternGraph, result);

    for (ReadOnlyIterator iter = result.getObjectResultEntriesIterator(); iter.hasNext(); ) {
      resultEntry = (ResultEntry)iter.next();
      String className = patternGraph.getElementClass(resultEntry.getElementNumber());
      Integer count = (Integer)class2count.get(className);
      ResultEntry countResultEntry = ResultEntryFactory.createResultEntryCount(resultEntry.getElementNumber(), resultEntry.size() / count.intValue());
      resultCount.addObjectEntry(countResultEntry);
    }
    for (iter = result.getLinkResultEntriesIterator(); iter.hasNext(); ) {
      resultEntry = (ResultEntry)iter.next();
      PatternElementNumber linkElementNum = resultEntry.getElementNumber();
      String linkFullName = getLinkFullName(patternGraph, linkElementNum);
      Integer count = (Integer)class2count.get(linkFullName);
      ResultEntry countResultEntry = ResultEntryFactory.createResultEntryCount(resultEntry.getElementNumber(), resultEntry.size() / count.intValue());
      resultCount.addLinkEntry(countResultEntry);
    }
    return resultCount;
  }

  private static String getLinkFullName(PatternGraph patternGraph, PatternElementNumber linkElementNum) {
    String linkClassName = patternGraph.getElementClass(linkElementNum);
    PatternLink patternLink = patternGraph.getLink(linkElementNum);
    PatternElementNumber end1 = patternLink.getEnd1Number();
    String end1ClassName = patternGraph.getElementClass(end1);
    PatternElementNumber end2 = patternLink.getEnd2Number();
    String end2ClassName = patternGraph.getElementClass(end2);
    String fullName = linkClassName + '.' + end1ClassName + '.' + end2ClassName;
    return fullName;
  }

  private static HashMap calculateClass2Count(PatternGraph patternGraph, TqlResultCount result)
  {
    HashMap class2Count = calculateDuplicateNodes(patternGraph, result);

    calculateDuplicateLinks(patternGraph, result, class2Count);

    return class2Count;
  }

  private static HashMap calculateDuplicateNodes(PatternGraph patternGraph, TqlResultCount result) {
    HashMap class2Count = new HashMap();
    for (ReadOnlyIterator iter = result.getObjectResultEntriesIterator(); iter.hasNext(); ) {
      ResultEntry resultEntry = (ResultEntry)iter.next();
      String className = patternGraph.getElementClass(resultEntry.getElementNumber());
      Integer count = (Integer)class2Count.get(className);
      if (count == null) {
        count = INITAL_COUNT;
      }
      else
        count = new Integer(count.intValue() + 1);

      class2Count.put(className, count);
    }
    return class2Count;
  }

  private static void calculateDuplicateLinks(PatternGraph patternGraph, TqlResultCount result, HashMap class2Count) {
    for (ReadOnlyIterator iter = result.getLinkResultEntriesIterator(); iter.hasNext(); ) {
      ResultEntry resultEntry = (ResultEntry)iter.next();

      PatternElementNumber linkElementNum = resultEntry.getElementNumber();
      PatternLink patternLink = patternGraph.getLink(linkElementNum);
      PatternElementNumber end1 = patternLink.getEnd1Number();
      String end1ClassName = patternGraph.getElementClass(end1);
      PatternElementNumber end2 = patternLink.getEnd2Number();
      String end2ClassName = patternGraph.getElementClass(end2);
      String linkFullName = getLinkFullName(patternGraph, linkElementNum);

      Integer linkCount = (Integer)class2Count.get(linkFullName);
      if (linkCount == null) {
        linkCount = INITAL_COUNT;
      }
      else {
        Integer end1Count = (Integer)class2Count.get(end1ClassName);
        Integer end2Count = (Integer)class2Count.get(end2ClassName);
        if (end1Count != null) {
          if (end2Count != null) {
            linkCount = (end1Count.intValue() > end2Count.intValue()) ? end1Count : end2Count;
          }
          else
            linkCount = end1Count;

        }
        else if (end2Count != null)
          linkCount = end2Count;
      }

      class2Count.put(linkFullName, linkCount);
    }
  }

  private static void makeElementsPatternInvissible(ModifiablePatternGraph graph) {
    ReadOnlyIterator iterElements = graph.getElementsIterator();
    while (iterElements.hasNext()) {
      ModifiablePatternElement patternElement = (ModifiablePatternElement)iterElements.next();
      patternElement.setIsVisible(false);
    }
  }

  private static void handleCreateLinksAndObjects(EnrichmentDefinition enrichmentDefinition, ModifiablePatternGraph graph) {
    ReadOnlyIterator iterLinks = enrichmentDefinition.getEnrichmentActions().getEnrichmentLinksIterator();
    while (iterLinks.hasNext()) {
      EnrichmentLink enrichmentLink = (EnrichmentLink)iterLinks.next();
      if (enrichmentLink.getAction().equals(CmdbConstants.Enrichment.Action.CREATE)) {
        PatternElementNumber end1 = enrichmentLink.getNodeNumberEnd1();
        PatternElementNumber end2 = enrichmentLink.getNodeNumberEnd2();
        ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition(enrichmentLink.getClassName(), false);
        ElementPropertiesCondition propertiesCondition = AbstractEnrichmentCalculatorManager.getDataSourceCondition(enrichmentDefinition.getEnrichmentName());
        ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, propertiesCondition);
        PatternLink patternLink = PatternGraphFactory.createPatternLink(enrichmentLink.getNodeNumber(), end1, end2, elementCondition, true, null);

        addEnds(enrichmentDefinition, graph, enrichmentLink);
        graph.addLink(patternLink);
      }
    }
  }

  private static void addEnds(EnrichmentDefinition enrichmentDefinition, ModifiablePatternGraph graph, EnrichmentLink enrichmentLink) {
    PatternElementNumber linkNum = enrichmentLink.getNodeNumber();
    PatternElementNumber end1 = enrichmentLink.getNodeNumberEnd1();
    PatternElementNumber end2 = enrichmentLink.getNodeNumberEnd2();
    addEnds(enrichmentDefinition, graph, end1, linkNum);
    addEnds(enrichmentDefinition, graph, end2, linkNum);
  }

  private static void addEnds(EnrichmentDefinition enrichmentDefinition, ModifiablePatternGraph graph, PatternElementNumber nodeNum, PatternElementNumber linkNum)
  {
    if (enrichmentDefinition.getOrderEnrichmentActions().containsByNodeNumber(nodeNum)) {
      EnrichmentActions enrichmentActions = enrichmentDefinition.getEnrichmentActions();
      addEnd(enrichmentDefinition, graph, nodeNum, linkNum, enrichmentActions.getEnrichmentObjectByNodeNumber(nodeNum).getClassName());
    }
    else {
      addCardinality2PatternNode(graph, nodeNum, linkNum);
    }
  }

  private static void addEnd(EnrichmentDefinition enrichmentDefinition, ModifiablePatternGraph graph, PatternElementNumber nodeNum, PatternElementNumber linkNum, String className) {
    LinkCardinality linkCardinality = PatternConditionFactory.createLinkCardinality(linkNum.getNumber(), 1, -1);
    if (!(graph.hasDefinitionElement(nodeNum))) {
      ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition(className, false);
      ElementPropertiesCondition propertiesCondition = AbstractEnrichmentCalculatorManager.getDataSourceCondition(enrichmentDefinition.getEnrichmentName());
      ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, propertiesCondition);
      ModifiableNodeLinksCondition linksCondition = PatternConditionFactory.createNodeLinksCondition();
      linksCondition.addLinkCardinality(linkCardinality);
      PatternNode patternNode = PatternGraphFactory.createPatternNode(nodeNum, elementCondition, true, linksCondition);
      graph.addNode(patternNode);
    }
    else {
      ModifiablePatternNode modifiablePatternNode = graph.getModifiableNode(nodeNum);
      ModifiableNodeLinksCondition modifiableNodeLinksCondition = modifiablePatternNode.getModifiableLinksCondition();
      modifiableNodeLinksCondition.addLogicalOperator(LogicalOperator.AND);
      modifiableNodeLinksCondition.addLinkCardinality(linkCardinality);
    }
  }

  private static void addCardinality2PatternNode(ModifiablePatternGraph graph, PatternElementNumber nodeNum, PatternElementNumber linkNum)
  {
    ModifiablePatternNode patternNode = graph.getModifiableNode(nodeNum);

    LinkCardinality linkCardinality = PatternConditionFactory.createLinkCardinality(linkNum.getNumber(), 1, -1);
    ModifiableNodeLinksCondition modifiableNodeLinksCondition = patternNode.getModifiableLinksCondition();
    if (modifiableNodeLinksCondition == null) {
      modifiableNodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
      patternNode.setLinksCondition(modifiableNodeLinksCondition);
    }
    else if (modifiableNodeLinksCondition.getNumberOfElements() > 0) {
      modifiableNodeLinksCondition.addLogicalOperator(LogicalOperator.AND);
    }
    modifiableNodeLinksCondition.addLinkCardinality(linkCardinality);
  }
}