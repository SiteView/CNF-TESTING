package com.mercury.topaz.cmdb.server.enrichment.admin.operation.update.impl;

import com.mercury.topaz.cmdb.server.enrichment.admin.EnrichmentAdminManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;

public class EnrichmentUpdateRemovePattern extends AbstractEnrichmentAdminUpdate
{
  private Pattern _pattern;

  public EnrichmentUpdateRemovePattern(Pattern pattern)
  {
    setPattern(pattern);
  }

  public String getOperationName()
  {
    return "Enrichment Update: Remove enrichment{cmdbPattern=" + getPattern() + '}';
  }

  public void doEnrichmentExecute(EnrichmentAdminManager enrichmentAdminManager, CmdbResponse response)
  {
    enrichmentAdminManager.removeEnrichmentDefinitionsByPatternId(getPattern().getID());
  }

  protected void updateValidation(EnrichmentAdminManager enrichmentAdminManager)
  {
  }

  public String getShortAuditMessage()
  {
    return "Remove " + getPattern().getName() + " enrichment's pattern";
  }

  public String getDetailedAuditMessage()
  {
    return "Remove " + getPattern() + " enrichment's pattern";
  }

  public Pattern getPattern()
  {
    return this._pattern;
  }

  private void setPattern(Pattern pattern) {
    if (pattern == null)
      throw new IllegalArgumentException("Pattern can't be null");

    this._pattern = pattern;
  }
}