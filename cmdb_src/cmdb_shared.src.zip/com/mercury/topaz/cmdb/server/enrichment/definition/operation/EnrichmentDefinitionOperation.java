package com.mercury.topaz.cmdb.server.enrichment.definition.operation;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.CmdbOperation;

public abstract interface EnrichmentDefinitionOperation extends CmdbOperation
{
  public abstract void enrichmentExecute(EnrichmentDefinitionManager paramEnrichmentDefinitionManager, CmdbResponse paramCmdbResponse)
    throws EnrichmentValidationException;
}