package com.mercury.topaz.cmdb.server.enrichment.calculator.instances;

import com.mercury.topaz.cmdb.shared.tql.result.instance.PatternInstances;

public abstract interface EnrichmentPatternInstances extends PatternInstances
{
}