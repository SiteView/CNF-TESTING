package com.mercury.topaz.cmdb.server.enrichment.calculator.instances.chunks.impl;

import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.AbstractEnrichmentCalculatorManager;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.chunks.InstancesChunkerForEnrichment;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;

public class InstancesChunkerForEnrichmentFactory
{
  public static InstancesChunkerForEnrichment createInstancesChunkerForEnrichment(EnrichmentDefinition enrichmentDefinition, Pattern pattern, TqlResultMap requiredObjects, AbstractEnrichmentCalculatorManager manager)
  {
    return new InstancesChunkerForEnrichmentImpl(enrichmentDefinition, pattern, requiredObjects, manager);
  }
}