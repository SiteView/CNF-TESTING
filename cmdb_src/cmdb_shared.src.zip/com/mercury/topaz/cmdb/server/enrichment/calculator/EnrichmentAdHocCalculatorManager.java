package com.mercury.topaz.cmdb.server.enrichment.calculator;

import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public abstract interface EnrichmentAdHocCalculatorManager extends CmdbSubsystemManager
{
  public abstract void calculateAdHocEnrichment(String paramString);

  public abstract void calculateAdHocEnrichmentBusinessView(String paramString);
}