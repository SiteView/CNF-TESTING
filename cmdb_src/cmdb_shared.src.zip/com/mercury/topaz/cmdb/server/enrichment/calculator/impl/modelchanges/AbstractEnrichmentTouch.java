package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.aging.operation.update.ModelUpdateMarkDataAsAccessed;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

abstract class AbstractEnrichmentTouch extends AbstractEnrichmentAction
{
  public AbstractEnrichmentTouch(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, Changer changer, long modelChangesChunkSize, String type)
  {
    super(operationExecutor, enrichmentDefinition, changer, "touch ", modelChangesChunkSize, type);
  }

  public void executeUpdate() {
    if (!(isEmpty())) {
      if (size() <= getModelChangesChunkSize())
        executeUpdate(getIds2Touch());
      else {
        executeUpdateByChunks(getIds2Touch());
      }

      if (_enrichmentLogger.isInfoEnabled()) {
        String msg = getEnrichmentDefinition().getEnrichmentName() + " -- " + "enrichment definition " + getAction() + size() + getType();

        _enrichmentLogger.info(msg);
      }
    }
  }

  private void executeUpdate(CmdbIDsCollection ids2Touch) {
    executeAsynchronousOperation(new ModelUpdateMarkDataAsAccessed(ids2Touch, getChanger()));
  }

  private void executeUpdateByChunks(CmdbIDsCollection ids2Touch) {
    long modelChangesChunkSize = getModelChangesChunkSize();
    long currentModelChangesNum = 0L;
    CmdbDataIDs ids2TouchChunk = CmdbDataIdsFactory.create();
    ReadOnlyIterator ids2TouchIter = ids2Touch.getIdsIterator();
    while (ids2TouchIter.hasNext()) {
      CmdbDataID dataId = (CmdbDataID)ids2TouchIter.next();
      ids2TouchChunk.add(dataId);
      currentModelChangesNum += 1L;
      if (currentModelChangesNum == modelChangesChunkSize)
      {
        executeUpdate(ids2TouchChunk);

        ids2TouchChunk.clear();
        currentModelChangesNum = 0L;
      }
    }
  }

  protected abstract CmdbIDsCollection getIds2Touch();
}