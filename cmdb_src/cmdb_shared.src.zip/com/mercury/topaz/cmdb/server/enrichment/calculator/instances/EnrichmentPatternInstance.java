package com.mercury.topaz.cmdb.server.enrichment.calculator.instances;

import com.mercury.topaz.cmdb.shared.tql.result.instance.PatternModifiableInstance;

public abstract interface EnrichmentPatternInstance extends PatternModifiableInstance
{
}