package com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class EnrichmentUpdateUpdateEnrichmentDefinitionToRepository extends AbstractEnrichmentUpdateEnrichmentDefinition
{
  public EnrichmentUpdateUpdateEnrichmentDefinitionToRepository(EnrichmentDefinition enrichmentDefinition)
  {
    setEnrichmentDefinition(enrichmentDefinition);
  }

  public String getOperationName()
  {
    return "Enrichment Update: Update enrichment {EnrichmentDefinition=" + getEnrichmentDefinition() + '}';
  }

  public void doEnrichmentExecute(EnrichmentDefinitionManager enrichmentDefinitionManager, CmdbResponse response)
  {
    super.doEnrichmentExecute(enrichmentDefinitionManager, response);

    EnrichmentDefinition enrichmentDefinition = enrichmentDefinitionManager.updateEnrichmentDefinition(getEnrichmentDefinition());
    setEnrichmentDefinition(enrichmentDefinition);
  }

  public String getShortAuditMessage()
  {
    return "Update " + getEnrichmentDefinition().getEnrichmentName() + " enrichment definition";
  }

  public String getDetailedAuditMessage()
  {
    return "Update " + getEnrichmentDefinition() + " enrichment definition";
  }
}