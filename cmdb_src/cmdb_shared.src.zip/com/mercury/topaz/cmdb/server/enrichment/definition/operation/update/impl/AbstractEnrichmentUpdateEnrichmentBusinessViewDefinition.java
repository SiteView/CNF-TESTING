package com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

class AbstractEnrichmentUpdateEnrichmentBusinessViewDefinition extends AbstractEnrichmentDefinitionUpdate
{
  private EnrichmentBusinessViewDefinition _enrichmentDefinition;

  public String getOperationName()
  {
    return "Enrichment Update: Add/Update business view enrichment{EnrichmentDefinition=" + getEnrichmentDefinition() + '}';
  }

  protected void doEnrichmentExecute(EnrichmentDefinitionManager enrichmentDefinitionManager, CmdbResponse response)
    throws EnrichmentValidationException
  {
    updateValidation(enrichmentDefinitionManager);
  }

  protected void updateValidation(EnrichmentDefinitionManager enrichmentDefinitionManager)
    throws EnrichmentValidationException
  {
  }

  public EnrichmentBusinessViewDefinition getEnrichmentDefinition()
  {
    return this._enrichmentDefinition;
  }

  protected void setEnrichmentDefinition(EnrichmentBusinessViewDefinition enrichmentDefinition) {
    if (enrichmentDefinition == null)
      throw new IllegalArgumentException("Enrichment definition can't be null");

    this._enrichmentDefinition = enrichmentDefinition;
  }
}