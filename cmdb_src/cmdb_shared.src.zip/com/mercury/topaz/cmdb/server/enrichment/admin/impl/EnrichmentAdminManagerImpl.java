package com.mercury.topaz.cmdb.server.enrichment.admin.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.enrichment.admin.EnrichmentAdminManager;
import com.mercury.topaz.cmdb.server.enrichment.admin.tqlnotification.impl.EnrichmentPatternDefinitionChangeListenerImpl;
import com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl.EnrichmentUpdateAddEnrichmentBusinessViewDefinitionToRepository;
import com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl.EnrichmentUpdateAddEnrichmentDefinitionToRepository;
import com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl.EnrichmentUpdateRemoveEnrichmentBusinessViewDefinitionFromRepository;
import com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl.EnrichmentUpdateRemoveEnrichmentDefinitionFromRepository;
import com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl.EnrichmentUpdateUpdateEnrichmentBusinessViewDefinitionToRepository;
import com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl.EnrichmentUpdateUpdateEnrichmentDefinitionToRepository;
import com.mercury.topaz.cmdb.server.enrichment.util.EnrichmentPatternValidityUtil;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.command.impl.EnrichmentCommandCalculator;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.command.impl.EnrichmentsCommandCalculator;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.update.impl.EnrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.id.CmdbEnrichmentID;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.impl.EnrichmentDefinitionFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.businessview.impl.EnrichmentQueryGetEnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.impl.EnrichmentQueryGetEnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.impl.EnrichmentQueryGetEnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.impl.EnrichmentQueryGetEnrichmentDefinitionsAllByPatternId;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.impl.EnrichmentQueryGetEnrichmentDefinitionsByPatternId;
import com.mercury.topaz.cmdb.shared.notification.operation.command.impl.DeploymentCommandRegisterFineGrainedListener;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.PatternState;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetPattern;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdateAddOrUpdatePatternLayout;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdatePatternUpdate;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Collection;

class EnrichmentAdminManagerImpl extends CmdbSubsystemManagerImpl
  implements EnrichmentAdminManager, SingleReadSingleWrite
{
  private static Log _logger = LogFactory.getEasyLog(EnrichmentAdminManagerImpl.class);
  private static Log _enrichmentLogger = LogFactory.getEasyLog("cmdb.enrichment.appender");

  EnrichmentAdminManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public void startUp() {
    register2PatternDefinitionsChanges();
    calculateEnrichments();

    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: EnrichmentAdminManager is started up properly!!!");
  }

  public void shutdown() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: EnrichmentAdminManager is shutdown properly!!!");
  }

  protected void register2PatternDefinitionsChanges()
  {
    EnrichmentPatternDefinitionChangeListenerImpl enrichmentPatternDefinitionChangeListenerImpl = new EnrichmentPatternDefinitionChangeListenerImpl(getLocalEnvironment().getCustomerID());

    register2PatternDefinitionsChanges(enrichmentPatternDefinitionChangeListenerImpl);
  }

  protected void register2PatternDefinitionsChanges(EnrichmentPatternDefinitionChangeListenerImpl enrichmentPatternDefinitionChangeListenerImpl)
  {
    DeploymentCommandRegisterFineGrainedListener deploymentCommandRegisterFineGrainedListener = new DeploymentCommandRegisterFineGrainedListener(enrichmentPatternDefinitionChangeListenerImpl);

    executeOperation(deploymentCommandRegisterFineGrainedListener);
  }

  public void addEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition)
  {
    enrichmentDefinition = addEnrichmentDefinitionToRepository(enrichmentDefinition);

    CmdbPatternID patternId = enrichmentDefinition.getOriginalPatternId();
    Pattern pattern = retrievePatternById(patternId, true);

    handlePatternOnAddEnrichment(enrichmentDefinition, pattern);

    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(enrichmentDefinition.getEnrichmentName() + " -- " + "add enrichment definition");
  }

  public void addOrUpdateEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition)
  {
    if (retrieveEnrichmentDefinitionByName(enrichmentDefinition.getEnrichmentName()) == null)
      addEnrichmentDefinition(enrichmentDefinition);
    else
      updateEnrichmentDefinition(enrichmentDefinition);
  }

  public void updateEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition)
  {
    enrichmentDefinition = updateEnrichmentDefinitionToRepository(enrichmentDefinition);

    CmdbPatternID patternId = enrichmentDefinition.getOriginalPatternId();
    Pattern pattern = retrievePatternById(patternId, true);

    handlePatternOnUpdateEnrichment(enrichmentDefinition, pattern);

    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(enrichmentDefinition.getEnrichmentName() + " -- " + "update enrichment definition");
  }

  public void removeEnrichmentDefinition(String enrichmentName)
  {
    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinitionByName(enrichmentName);
    if (enrichmentDefinition == null) {
      if (_logger.isInfoEnabled())
        _logger.info(enrichmentName + " -- " + "Trying to remove nonexisting enrichment");

      return;
    }
    removeEnrichmentDefinitionFromRepository(enrichmentDefinition);

    CmdbPatternID patternId = enrichmentDefinition.getOriginalPatternId();
    Pattern pattern = retrievePatternById(patternId, false);

    handlePatternOnRemoveEnrichment(enrichmentDefinition, pattern);

    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(enrichmentDefinition.getEnrichmentName() + " -- " + "remove enrichment definition");
  }

  public void updateEnrichmentDefinitionsByPattern(Pattern newPattern)
  {
    Pattern oldPattern = retrievePatternById(newPattern.getID(), true);
    EnrichmentDefinitions enrichmentDefinitions = retrieveEnrichmentDefinitionsByPatternId(oldPattern.getID());
    ReadOnlyIterator iterEnrichmentDefinitions = enrichmentDefinitions.getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();
      validateEnrichment(enrichmentDefinition, newPattern);
      updateEnrichmentDefinition(enrichmentDefinition);
    }
  }

  public void removeEnrichmentDefinitionsByPatternId(CmdbPatternID patternId)
  {
    EnrichmentDefinitions enrichmentDefinitions = retrieveEnrichmentDefinitionsAllByPatternId(patternId);
    ReadOnlyIterator iterEnrichmentDefinitions = enrichmentDefinitions.getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();
      String enrichmentName = enrichmentDefinition.getEnrichmentName();
      if (enrichmentDefinition.getEnrichmentType() == 1)
        removeEnrichmentDefinition(enrichmentName);
      else
        removeEnrichmentBusinessViewDefinition(enrichmentName);
    }
  }

  protected void validateEnrichment(EnrichmentDefinition enrichmentDefinition, Pattern pattern)
  {
    enrichmentDefinition.validate(getSynchronizedClassModel(), pattern);
  }

  public void activateEnrichmentDefinition(String enrichmentName)
  {
    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinitionByName(enrichmentName);
    EnrichmentDefinition newEnrichmentDefinition = EnrichmentDefinitionFactory.create(enrichmentDefinition.getEnrichmentName(), enrichmentDefinition.getOriginalPatternId(), true, enrichmentDefinition.getEnrichmentActions());

    updateEnrichmentDefinition(newEnrichmentDefinition);
  }

  public void deactivateEnrichmentDefinition(String enrichmentName)
  {
    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinitionByName(enrichmentName);
    EnrichmentDefinition newEnrichmentDefinition = EnrichmentDefinitionFactory.create(enrichmentDefinition.getEnrichmentName(), enrichmentDefinition.getOriginalPatternId(), false, enrichmentDefinition.getDescription(), false, enrichmentDefinition.getEnrichmentActions());

    updateEnrichmentDefinition(newEnrichmentDefinition);
  }

  private void handlePatternOnAddEnrichment(EnrichmentDefinition enrichmentDefinition, Pattern pattern) {
    EnrichmentDefinitions enrichmentDefinitions = retrieveEnrichmentDefinitionsByPatternId(pattern.getID());

    PatternLayout patternLayout = addPatternLayout(enrichmentDefinition, enrichmentDefinition.getPatternLayout(), true);

    if (enrichmentDefinition.getIsActive()) {
      ModifiablePattern modifiablePattern = pattern.toModifiablePattern();
      modifiablePattern.setDefaultLayout(patternLayout);

      activatePattern(enrichmentDefinition.getEnrichmentId(), modifiablePattern, true, enrichmentDefinitions);

      calculateEnrichment(enrichmentDefinition.getEnrichmentId(), 3);
    }
  }

  private void handlePatternOnUpdateEnrichment(EnrichmentDefinition enrichmentDefinition, Pattern pattern) {
    EnrichmentDefinitions enrichmentDefinitions = retrieveEnrichmentDefinitionsByPatternId(pattern.getID());

    PatternLayout patternLayout = updatePatternLayout(enrichmentDefinition, enrichmentDefinitions);

    ModifiablePattern modifiablePattern = pattern.toModifiablePattern();
    modifiablePattern.setDefaultLayout(patternLayout);

    if (enrichmentDefinition.getIsActive())
    {
      activatePattern(enrichmentDefinition.getEnrichmentId(), modifiablePattern, true, enrichmentDefinitions);

      calculateEnrichment(enrichmentDefinition.getEnrichmentId(), 3);
    }
    else {
      activatePattern(enrichmentDefinition.getEnrichmentId(), modifiablePattern, false, enrichmentDefinitions);
    }
  }

  private void handlePatternOnRemoveEnrichment(EnrichmentDefinition enrichmentDefinition, Pattern pattern) {
    if (pattern != null) {
      EnrichmentDefinitions enrichmentDefinitions = retrieveEnrichmentDefinitionsByPatternId(pattern.getID());

      PatternLayout patternLayout = removePatternLayout(enrichmentDefinition, enrichmentDefinitions);

      if (enrichmentDefinition.getIsActive()) {
        ModifiablePattern modifiablePattern = pattern.toModifiablePattern();
        modifiablePattern.setDefaultLayout(patternLayout);

        activatePattern(enrichmentDefinition.getEnrichmentId(), modifiablePattern, false, enrichmentDefinitions);
      }
    }
  }

  protected PatternLayout updatePatternLayout(EnrichmentDefinition enrichmentDefinition, EnrichmentDefinitions enrichmentDefinitions) {
    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    ReadOnlyIterator iterDefinitions = enrichmentDefinitions.getElementsIterator();
    while (iterDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinitionIter = (EnrichmentDefinition)iterDefinitions.next();
      if (!(enrichmentDefinitionIter.getEnrichmentId().equals(enrichmentDefinition.getEnrichmentId()))) {
        patternLayout.append(enrichmentDefinitionIter.getPatternLayout());
      }

    }

    patternLayout.append(enrichmentDefinition.getPatternLayout());

    patternLayout = addPatternLayout(enrichmentDefinition, patternLayout, false);

    return patternLayout;
  }

  protected PatternLayout removePatternLayout(EnrichmentDefinition enrichmentDefinition, EnrichmentDefinitions enrichmentDefinitions) {
    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    ReadOnlyIterator iterDefinitions = enrichmentDefinitions.getElementsIterator();
    while (iterDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinitionIter = (EnrichmentDefinition)iterDefinitions.next();
      if (!(enrichmentDefinitionIter.getEnrichmentId().equals(enrichmentDefinition.getEnrichmentId())))
        patternLayout.append(enrichmentDefinitionIter.getPatternLayout());

    }

    patternLayout = addPatternLayout(enrichmentDefinition, patternLayout, false);

    return patternLayout;
  }

  protected void activatePattern(CmdbEnrichmentID cmdbEnrichmentID, ModifiablePattern pattern, boolean active, EnrichmentDefinitions enrichmentDefinitions)
  {
    ReadOnlyIterator iterEnrichments = enrichmentDefinitions.getElementsIterator();
    while (iterEnrichments.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichments.next();
      if ((!(enrichmentDefinition.getEnrichmentId().equals(cmdbEnrichmentID))) && 
        (enrichmentDefinition.getIsActive())) {
        return;
      }

    }

    PatternState patternState = PatternDefinitionFactory.createPatternState(false, active, pattern.getState().getPriority(), false);
    pattern.setState(patternState);
    updatePattern(pattern);
  }

  public boolean isUpdatePatternValid(Pattern newPattern)
  {
    Pattern oldPattern = retrievePatternById(newPattern.getID(), true);
    EnrichmentDefinitions enrichmentDefinitions = retrieveEnrichmentDefinitionsByPatternId(oldPattern.getID());
    return EnrichmentPatternValidityUtil.isUpdatePatternValid(newPattern, oldPattern, enrichmentDefinitions);
  }

  protected void calculateEnrichments()
  {
    EnrichmentDefinitions enrichmentDefinitions = retrieveEnrichmentDefinitions();
    ReadOnlyIterator iterDefionitions = enrichmentDefinitions.getElementsIterator();
    Collection enrichmentIDs = new ArrayList(enrichmentDefinitions.size());
    while (iterDefionitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterDefionitions.next();
      enrichmentIDs.add(enrichmentDefinition.getEnrichmentId());
    }
    EnrichmentsCommandCalculator enrichmentsCommandCalculator = new EnrichmentsCommandCalculator(enrichmentIDs, 1);
    executeAsynchronousOperation(enrichmentsCommandCalculator);
  }

  protected EnrichmentDefinitions retrieveEnrichmentDefinitions() {
    EnrichmentQueryGetEnrichmentDefinitions enrichmentQueryGetEnrichmentDefinitions = new EnrichmentQueryGetEnrichmentDefinitions();
    executeOperation(enrichmentQueryGetEnrichmentDefinitions);

    return enrichmentQueryGetEnrichmentDefinitions.getEnrichmentDefinitions();
  }

  protected void updatePattern(Pattern pattern) {
    TqlUpdatePatternUpdate tqlUpdatePatternUpdate = new TqlUpdatePatternUpdate(pattern);
    executeOperation(tqlUpdatePatternUpdate);
  }

  protected EnrichmentDefinition addEnrichmentDefinitionToRepository(EnrichmentDefinition enrichmentDefinition) {
    EnrichmentUpdateAddEnrichmentDefinitionToRepository enrichmentUpdateAddEnrichmentDefinitionToRepository = new EnrichmentUpdateAddEnrichmentDefinitionToRepository(enrichmentDefinition);

    executeOperation(enrichmentUpdateAddEnrichmentDefinitionToRepository);
    return enrichmentUpdateAddEnrichmentDefinitionToRepository.getEnrichmentDefinition();
  }

  protected EnrichmentBusinessViewDefinition addEnrichmentDefinitionToRepository(EnrichmentBusinessViewDefinition enrichmentDefinition) {
    EnrichmentUpdateAddEnrichmentBusinessViewDefinitionToRepository enrichmentUpdateAddEnrichmentDefinitionToRepository = new EnrichmentUpdateAddEnrichmentBusinessViewDefinitionToRepository(enrichmentDefinition);

    executeOperation(enrichmentUpdateAddEnrichmentDefinitionToRepository);
    return enrichmentUpdateAddEnrichmentDefinitionToRepository.getEnrichmentDefinition();
  }

  protected EnrichmentDefinition updateEnrichmentDefinitionToRepository(EnrichmentDefinition enrichmentDefinition) {
    EnrichmentUpdateUpdateEnrichmentDefinitionToRepository enrichmentUpdateUpdateEnrichmentDefinitionToRepository = new EnrichmentUpdateUpdateEnrichmentDefinitionToRepository(enrichmentDefinition);

    executeOperation(enrichmentUpdateUpdateEnrichmentDefinitionToRepository);
    return enrichmentUpdateUpdateEnrichmentDefinitionToRepository.getEnrichmentDefinition();
  }

  protected EnrichmentBusinessViewDefinition updateEnrichmentDefinitionToRepository(EnrichmentBusinessViewDefinition enrichmentDefinition) {
    EnrichmentUpdateUpdateEnrichmentBusinessViewDefinitionToRepository enrichmentUpdateUpdateEnrichmentDefinitionToRepository = new EnrichmentUpdateUpdateEnrichmentBusinessViewDefinitionToRepository(enrichmentDefinition);

    executeOperation(enrichmentUpdateUpdateEnrichmentDefinitionToRepository);
    return enrichmentUpdateUpdateEnrichmentDefinitionToRepository.getEnrichmentDefinition();
  }

  protected void removeEnrichmentDefinitionFromRepository(EnrichmentDefinition enrichmentDefinition) {
    EnrichmentUpdateRemoveEnrichmentDefinitionFromRepository enrichmentUpdateRemoveEnrichmentDefinitionFromRepository = new EnrichmentUpdateRemoveEnrichmentDefinitionFromRepository(enrichmentDefinition.getEnrichmentName());

    executeOperation(enrichmentUpdateRemoveEnrichmentDefinitionFromRepository);
  }

  protected void removeEnrichmentResultsFromRepository(EnrichmentBusinessViewDefinition enrichmentDefinition) {
    EnrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment enrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment = new EnrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment(enrichmentDefinition.getEnrichmentName());

    executeOperation(enrichmentUpdateRemoveObjectsAndLinksCreatedByEnrichment);
  }

  protected void removeEnrichmentDefinitionFromRepository(EnrichmentBusinessViewDefinition enrichmentDefinition) {
    EnrichmentUpdateRemoveEnrichmentBusinessViewDefinitionFromRepository enrichmentUpdateRemoveEnrichmentDefinitionFromRepository = new EnrichmentUpdateRemoveEnrichmentBusinessViewDefinitionFromRepository(enrichmentDefinition.getEnrichmentName());

    executeOperation(enrichmentUpdateRemoveEnrichmentDefinitionFromRepository);
  }

  protected PatternLayout addPatternLayout(EnrichmentDefinition enrichmentDefinition, PatternLayout patternLayout, boolean add) {
    TqlUpdateAddOrUpdatePatternLayout tqlUpdateAddOrUpdatePatternLayout = new TqlUpdateAddOrUpdatePatternLayout(enrichmentDefinition.getOriginalPatternId(), patternLayout, add);

    executeOperation(tqlUpdateAddOrUpdatePatternLayout);

    return tqlUpdateAddOrUpdatePatternLayout.getPatternLayout();
  }

  protected void calculateEnrichment(CmdbEnrichmentID cmdbEnrichmentID, int tqlNotification)
  {
    EnrichmentCommandCalculator enrichmentCommandCalculator = new EnrichmentCommandCalculator(cmdbEnrichmentID, tqlNotification);
    executeAsynchronousOperation(enrichmentCommandCalculator);
  }

  protected EnrichmentDefinitions retrieveEnrichmentDefinitionsByPatternId(CmdbPatternID patternId) {
    EnrichmentQueryGetEnrichmentDefinitionsByPatternId enrichmentGetEnrichmentDefinitionsByPatternId = new EnrichmentQueryGetEnrichmentDefinitionsByPatternId(patternId);

    executeOperation(enrichmentGetEnrichmentDefinitionsByPatternId);

    return enrichmentGetEnrichmentDefinitionsByPatternId.getEnrichmentDefinitions();
  }

  protected EnrichmentDefinitions retrieveEnrichmentDefinitionsAllByPatternId(CmdbPatternID patternId) {
    EnrichmentQueryGetEnrichmentDefinitionsAllByPatternId enrichmentGetEnrichmentDefinitionsByPatternId = new EnrichmentQueryGetEnrichmentDefinitionsAllByPatternId(patternId);

    executeOperation(enrichmentGetEnrichmentDefinitionsByPatternId);
    return enrichmentGetEnrichmentDefinitionsByPatternId.getEnrichmentDefinitions();
  }

  protected EnrichmentDefinition retrieveEnrichmentDefinitionByName(String enrichmentName) {
    EnrichmentQueryGetEnrichmentDefinition enrichmentQueryGetEnrichmentDefinition = new EnrichmentQueryGetEnrichmentDefinition(enrichmentName);
    executeOperation(enrichmentQueryGetEnrichmentDefinition);

    return enrichmentQueryGetEnrichmentDefinition.getEnrichmentDefinition();
  }

  protected Pattern retrievePatternById(CmdbPatternID patternId, boolean withException)
  {
    TqlQueryGetPattern tqlQueryGetPattern = new TqlQueryGetPattern(patternId, false);
    executeOperation(tqlQueryGetPattern);
    Pattern pattern = tqlQueryGetPattern.getPattern();
    if ((withException) && (pattern == null))
      throw new IllegalArgumentException("Pattern " + patternId + " doesn't exist in the repository");

    return tqlQueryGetPattern.getPattern();
  }

  public void addEnrichmentDefinition(EnrichmentBusinessViewDefinition enrichmentDefinition)
  {
    addEnrichmentDefinitionToRepository(enrichmentDefinition);

    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(enrichmentDefinition.getEnrichmentName() + " -- " + "add business view enrichment definition");
  }

  public void addOrUpdateEnrichmentDefinition(EnrichmentBusinessViewDefinition enrichmentDefinition)
  {
    if (retrieveEnrichmentBusinessViewDefinitionByName(enrichmentDefinition.getEnrichmentName()) == null)
      addEnrichmentDefinition(enrichmentDefinition);
    else
      updateEnrichmentDefinition(enrichmentDefinition);
  }

  public void updateEnrichmentDefinition(EnrichmentBusinessViewDefinition enrichmentDefinition)
  {
    updateEnrichmentDefinitionToRepository(enrichmentDefinition);

    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(enrichmentDefinition.getEnrichmentName() + " -- " + "update business view enrichment definition");
  }

  public void removeEnrichmentBusinessViewDefinition(String enrichmentName)
  {
    EnrichmentBusinessViewDefinition enrichmentDefinition = retrieveEnrichmentBusinessViewDefinitionByName(enrichmentName);
    if (enrichmentDefinition == null) {
      if (_logger.isInfoEnabled())
        _logger.info(enrichmentName + " -- " + "Trying to remove nonexisting business view enrichment");

      return;
    }
    removeEnrichmentResultsFromRepository(enrichmentDefinition);
    removeEnrichmentDefinitionFromRepository(enrichmentDefinition);

    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(enrichmentDefinition.getEnrichmentName() + " -- " + "remove business view enrichment definition and its results");
  }

  protected EnrichmentBusinessViewDefinition retrieveEnrichmentBusinessViewDefinitionByName(String enrichmentName)
  {
    EnrichmentQueryGetEnrichmentBusinessViewDefinition enrichmentQueryGetEnrichmentBusinessViewDefinition = new EnrichmentQueryGetEnrichmentBusinessViewDefinition(enrichmentName);

    executeOperation(enrichmentQueryGetEnrichmentBusinessViewDefinition);

    return enrichmentQueryGetEnrichmentBusinessViewDefinition.getEnrichmentDefinition();
  }

  public Pattern retrievePatternById(CmdbPatternID patternId)
  {
    TqlQueryGetPattern tqlQueryGetPattern = new TqlQueryGetPattern(patternId, true);
    executeOperation(tqlQueryGetPattern);
    return tqlQueryGetPattern.getPattern();
  }

  public Pattern retrievePatternByName(String patternName)
  {
    TqlQueryGetPattern tqlQueryGetPattern = new TqlQueryGetPattern(patternName, true);
    executeOperation(tqlQueryGetPattern);
    return tqlQueryGetPattern.getPattern();
  }

  public String getName() {
    return "Enrichment Admin Task";
  }
}