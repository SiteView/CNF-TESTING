package com.mercury.topaz.cmdb.server.enrichment.calculator.instances.impl;

import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.EnrichmentPatternInstances;
import com.mercury.topaz.cmdb.shared.tql.result.impl.AbstractPatternInstances;

class EnrichmentPatternInstancesImpl extends AbstractPatternInstances
  implements EnrichmentPatternInstances
{
}