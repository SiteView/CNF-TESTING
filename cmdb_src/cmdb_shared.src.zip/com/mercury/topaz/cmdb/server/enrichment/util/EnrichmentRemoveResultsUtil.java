package com.mercury.topaz.cmdb.server.enrichment.util;

import com.mercury.topaz.cmdb.server.enrichment.calculator.impl.AbstractEnrichmentCalculatorManager;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;

public class EnrichmentRemoveResultsUtil
{
  public static final PatternElementNumber NODE_ELEMENT_NUMBER = PatternElementNumberFactory.createElementNumber(1);
  public static final PatternElementNumber LINK_ELEMENT_NUMBER = PatternElementNumberFactory.createElementNumber(3);

  public static Pattern retrieveLinksCreatedByEnrichment(String enrichmentName)
  {
    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();

    ModifiableNodeLinksCondition nodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
    int linkNumber = LINK_ELEMENT_NUMBER.getNumber();
    nodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(linkNumber, 1, -1));

    PatternElementNumber patternElementNumber1 = PatternElementNumberFactory.createElementNumber(1);
    ElementClassCondition elementClassCondition1 = PatternConditionFactory.createElementClassCondition("object", true);
    ElementCondition elementCondition1 = PatternConditionFactory.createElementCondition(elementClassCondition1);
    PatternNode patternNode1 = PatternGraphFactory.createModifiablePatternNode(patternElementNumber1, elementCondition1, false, nodeLinksCondition, "links created by enrichemnt " + enrichmentName);
    patternGraph.addNode(patternNode1);
    PatternElementNumber patternElementNumber2 = PatternElementNumberFactory.createElementNumber(2);
    ElementClassCondition elementClassCondition2 = PatternConditionFactory.createElementClassCondition("object", true);
    ElementCondition elementCondition2 = PatternConditionFactory.createElementCondition(elementClassCondition2);
    PatternNode patternNode2 = PatternGraphFactory.createModifiablePatternNode(patternElementNumber2, elementCondition2, false, nodeLinksCondition, "links created by enrichemnt " + enrichmentName);
    patternGraph.addNode(patternNode2);
    ElementClassCondition elementClassConditionLink = PatternConditionFactory.createElementClassCondition("link", true);
    ElementPropertiesCondition elementPropertiesCondition = AbstractEnrichmentCalculatorManager.getDataSourceCondition(enrichmentName);
    ElementCondition elementConditionLink = PatternConditionFactory.createElementCondition(elementClassConditionLink, elementPropertiesCondition);
    PatternLink patternLink = PatternGraphFactory.createModifiablePatternLink(LINK_ELEMENT_NUMBER.getNumber(), patternElementNumber1.getNumber(), patternElementNumber2.getNumber(), elementConditionLink, true, "links created by enrichemnt " + enrichmentName);
    patternGraph.addLink(patternLink);

    Pattern pattern = PatternDefinitionFactory.createPattern("mercury", "links created by enrichemnt " + enrichmentName, PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    return pattern;
  }

  public static Pattern createObjectsCreatedByEnrichmentPattern(String enrichmentName)
  {
    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition("object", true);
    ElementPropertiesCondition elementPropertiesCondition = AbstractEnrichmentCalculatorManager.getDataSourceCondition(enrichmentName);
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, elementPropertiesCondition);
    PatternNode patternNode = PatternGraphFactory.createModifiablePatternNode(NODE_ELEMENT_NUMBER, elementCondition, true, null, "objects created by enrichemnt " + enrichmentName);
    patternGraph.addNode(patternNode);

    Pattern pattern = PatternDefinitionFactory.createPattern("mercury", "objects created by enrichemnt " + enrichmentName, PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    return pattern;
  }
}