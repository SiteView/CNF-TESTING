package com.mercury.topaz.cmdb.server.enrichment.calculator.task;

public class EnrichmentCalculatorTask
{
  public static final String NAME = "Enrichment Calculator Task";
}