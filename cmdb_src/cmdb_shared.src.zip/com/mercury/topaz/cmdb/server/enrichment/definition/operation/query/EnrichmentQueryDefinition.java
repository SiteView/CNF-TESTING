package com.mercury.topaz.cmdb.server.enrichment.definition.operation.query;

import com.mercury.topaz.cmdb.server.enrichment.definition.operation.EnrichmentDefinitionOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;

public abstract interface EnrichmentQueryDefinition
{
}