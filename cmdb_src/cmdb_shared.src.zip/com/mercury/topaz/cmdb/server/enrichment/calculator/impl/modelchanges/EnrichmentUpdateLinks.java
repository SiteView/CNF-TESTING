package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.update.ModelUpdateLinksIfExist;

public class EnrichmentUpdateLinks extends AbstractEnrichmentUpdateLinks
{
  public EnrichmentUpdateLinks(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, CmdbLinks links2Create, EnrichmentModelBulkContainer enrichmentModelBulkContainer, Changer changer, long modelChangesChunkSize)
  {
    super(operationExecutor, enrichmentDefinition, links2Create, enrichmentModelBulkContainer, changer, "update ", modelChangesChunkSize);
  }

  protected void addOptimisticModelUpdateOperation() {
    addOptimisticModelUpdateOperation(getLinks());
  }

  protected void addOptimisticModelUpdateOperation(CmdbLinks links) {
    ModelUpdateLinksIfExist modelUpdateLinksIfExist = new ModelUpdateLinksIfExist(links, getChanger());
    getBulkContainer().getModelUpdateBulks().addOptimisticModelUpdateOperation(modelUpdateLinksIfExist);
  }
}