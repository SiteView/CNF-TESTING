package com.mercury.topaz.cmdb.server.enrichment.calculator.instances.impl;

import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.EnrichmentPatternInstance;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.LinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.result.ModifiableResultContainer;
import com.mercury.topaz.cmdb.shared.tql.result.ResultContainer;
import com.mercury.topaz.cmdb.shared.tql.result.impl.AbstractPatternInstance;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.CmdbLinkModifiableResultEntry;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.CmdbObjectModifiableResultEntry;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.impl.ResultEntryFactory;
import java.util.List;

class EnrichmentPatternInstanceImpl extends AbstractPatternInstance
  implements EnrichmentPatternInstance
{
  public void addObject(PatternElementNumber key, CmdbObject object)
  {
    if (containsElementNumber(key)) {
      throw new IllegalArgumentException(key + " key, already containsElementNumber another object. In instance only one object is allowed in each result entry.");
    }

    CmdbObjectModifiableResultEntry modifiableResultEntry = ResultEntryFactory.createCmdbObjectModifiableResultEntry(key);
    modifiableResultEntry.add(object);
    addObjectResultEntry(modifiableResultEntry);
  }

  private void addObjectResultEntry(CmdbObjectModifiableResultEntry modifiableResultEntry) {
    getObjectResultEntries().add(modifiableResultEntry);
  }

  public void addLink(PatternElementNumber key, CmdbLink link)
  {
    if (containsElementNumber(key)) {
      throw new IllegalArgumentException(key + " key, already containsElementNumber another link. In instance only one link is allowed in each result entry.");
    }

    CmdbLinkModifiableResultEntry modifiableResultEntry = ResultEntryFactory.createCmdbLinkModifiableResultEntry(key, getLinksDictionary().getEnd1NumberOfLink(key), getLinksDictionary().getEnd2NumberOfLink(key));
    modifiableResultEntry.add(link);
    addLinkResultEntry(modifiableResultEntry);
  }

  private void addLinkResultEntry(CmdbLinkModifiableResultEntry modifiableResultEntry) {
    getLinkResultEntries().add(modifiableResultEntry);
  }

  public boolean isModifiable() {
    return true;
  }

  public ModifiableResultContainer createModifiableCopy() {
    throw new UnsupportedOperationException("Not implemented");
  }

  public ResultContainer createReadOnlyCopy() {
    throw new UnsupportedOperationException("Not implemented");
  }
}