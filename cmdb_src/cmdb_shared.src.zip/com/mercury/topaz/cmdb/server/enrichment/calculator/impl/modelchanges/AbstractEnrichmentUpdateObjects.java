package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

abstract class AbstractEnrichmentUpdateObjects extends AbstractEnrichmentUpdate
{
  private CmdbObjects _objects;

  public AbstractEnrichmentUpdateObjects(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, CmdbObjects objects, EnrichmentModelBulkContainer enrichmentModelBulkContainer, Changer changer, String action, long modelChangesChunkSize)
  {
    super(operationExecutor, enrichmentDefinition, enrichmentModelBulkContainer, changer, action, modelChangesChunkSize, " object/s");
    setObjects(objects);
  }

  protected boolean isEmpty() {
    return getObjects().isEmpty();
  }

  protected int size() {
    return getObjects().size();
  }

  protected abstract void addOptimisticModelUpdateOperation(CmdbObjects paramCmdbObjects);

  protected void fillBulkByChunks() {
    long modelChangesChunkSize = getModelChangesChunkSize();
    ModelUpdateBulksOptimistic modelUpdateBulks = getBulkContainer().getModelUpdateBulks();
    long currentModelChangesNum = getBulkContainer().getCurrentModelChangesNum();

    CmdbObjects objects2UpdateChunk = CmdbObjectFactory.createObjects();
    ReadOnlyIterator iterObjects = getObjects().getObjectsIterator();
    while (iterObjects.hasNext()) {
      CmdbObject object = (CmdbObject)iterObjects.next();
      objects2UpdateChunk.add(object);
      currentModelChangesNum += 1L;
      if (currentModelChangesNum == modelChangesChunkSize)
      {
        addOptimisticModelUpdateOperation(objects2UpdateChunk);
        updateObjectsAndLinks2Model(modelUpdateBulks);

        modelUpdateBulks = new ModelUpdateBulksOptimistic(getChanger());
        getBulkContainer().setModelUpdateBulks(modelUpdateBulks);
        objects2UpdateChunk.clear();
        currentModelChangesNum = 0L;
      }
    }
    if (currentModelChangesNum > 0L)
      addOptimisticModelUpdateOperation(objects2UpdateChunk);

    getBulkContainer().setCurrentModelChangesNum(currentModelChangesNum);
  }

  protected CmdbObjects getObjects()
  {
    return this._objects;
  }

  private void setObjects(CmdbObjects objects) {
    this._objects = objects;
  }
}