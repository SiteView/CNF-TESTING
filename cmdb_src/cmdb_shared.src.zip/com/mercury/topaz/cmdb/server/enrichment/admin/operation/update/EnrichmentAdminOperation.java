package com.mercury.topaz.cmdb.server.enrichment.admin.operation.update;

import com.mercury.topaz.cmdb.server.enrichment.admin.EnrichmentAdminManager;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.CmdbOperation;

public abstract interface EnrichmentAdminOperation extends CmdbOperation
{
  public abstract void enrichmentExecute(EnrichmentAdminManager paramEnrichmentAdminManager, CmdbResponse paramCmdbResponse)
    throws EnrichmentValidationException;
}