package com.mercury.topaz.cmdb.server.enrichment.definition.persistence.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadSingleWrite;
import com.mercury.topaz.cmdb.server.enrichment.definition.persistence.EnrichmentPersistenceManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.server.tql.calculator.topology.subgraph.SubGraphCalculator;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.id.CmdbEnrichmentID;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.id.impl.CmdbEnrichmentIDFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.impl.EnrichmentDefinitionFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.memento.EnrichmentDefinitionMemento;
import com.mercury.topaz.cmdb.shared.enrichment.definition.memento.EnrichmentDefinitionsMemento;
import com.mercury.topaz.cmdb.shared.enrichment.definition.memento.impl.EnrichmentDefinitionMementoFactory;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentException;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.graph.ModifiableCMDBGraph;
import com.mercury.topaz.cmdb.shared.model.graph.impl.CmdbGraphFactory;
import com.mercury.topaz.cmdb.shared.model.graph.iterator.CmdbGraphIterator;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.ModelUpdateAddGraph;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.ModelUpdateRemoveGraph;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.graph.update.ModelUpdateAddOrUpdateGraph;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.update.ModelUpdateObjectsIfExist;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ConditionOperator;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternNodeSubGraphParameter;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternNodeWithSubGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.triple.PatternTriple;
import com.mercury.topaz.cmdb.shared.tql.definition.triple.PatternTriplets;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocGraph;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;

class EnrichmentPersistenceImpl extends CmdbSubsystemManagerImpl
  implements EnrichmentPersistenceManager, MultiReadSingleWrite
{
  private static Log _logger = LogFactory.getEasyLog(EnrichmentPersistenceImpl.class);
  private EnrichmentDefinitions _enrichmentDefinitions;
  private CmdbObject _enrichmentDefinitionsObject;
  private static final int ENRICHMENT_DEPTH = 9;

  EnrichmentPersistenceImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public void startUp() {
    loadEnrichments();
  }

  public void shutdown() {
  }

  private static String getShortEnrichmentName(String enrichmentName) {
    String shortName = enrichmentName;
    if (shortName.length() > 50) {
      CmdbEnrichmentID enrichmentID = CmdbEnrichmentIDFactory.createObjectID(enrichmentName);
      shortName = enrichmentID.getDigest().toString();
    }
    return shortName;
  }

  private Changer createChanger(String enrichmentName) {
    Changer changer = ChangerFactory.createChanger("UCMDB", "Customer " + getCustomerID() + "; Enrichment " + getShortEnrichmentName(enrichmentName));

    return changer;
  }

  public EnrichmentDefinition addEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition)
  {
    EnrichmentDefinitionMemento enrichmentDefinitionMemento = EnrichmentDefinitionMementoFactory.create(getDataFactory());
    CmdbGraph cmdbGraph = enrichmentDefinitionMemento.toCmdbGraph(enrichmentDefinition, getEnrichmentDefinitionsObject());
    Changer changer = createChanger(enrichmentDefinition.getEnrichmentName());
    ModelUpdateAddOrUpdateGraph modelUpdateAddGraph = new ModelUpdateAddOrUpdateGraph(cmdbGraph, changer);
    modelUpdateAddGraph.setUserOperation(true);
    executeOperation(modelUpdateAddGraph);

    if (_logger.isDebugEnabled())
      _logger.debug("add enrichment definition: " + enrichmentDefinition);

    getEnrichmentDefinitions().add(enrichmentDefinition);
    return enrichmentDefinition;
  }

  public EnrichmentDefinition updateEnrichmentDefinitionRoot(EnrichmentDefinition enrichmentDefinition, EnrichmentDefinition enrichmentDefinitionOld)
  {
    if (!(enrichmentDefinition.getEnrichmentId().equals(enrichmentDefinitionOld.getEnrichmentId()))) {
      throw new IllegalArgumentException("Try to update Enrichments with different ids " + enrichmentDefinition.getEnrichmentId() + ", " + enrichmentDefinitionOld.getEnrichmentId());
    }

    EnrichmentDefinitionMemento enrichmentDefinitionMemento = EnrichmentDefinitionMementoFactory.create(getDataFactory());
    Changer changer = createChanger(enrichmentDefinition.getEnrichmentName());
    ModelUpdateObjectsIfExist modelUpdateObjects = new ModelUpdateObjectsIfExist(enrichmentDefinitionMemento.toCmdbObject(enrichmentDefinition, 0), changer);

    modelUpdateObjects.setUserOperation(true);
    executeOperation(modelUpdateObjects);

    getEnrichmentDefinitions().set(enrichmentDefinition);
    return enrichmentDefinition;
  }

  public EnrichmentDefinition removeEnrichmentDefinition(String enrichmentName, boolean withRoot)
  {
    CmdbGraph cmdbGraph = loadEnrichmentDefinition(enrichmentName);

    if (!(withRoot)) {
      CmdbObjectID cmdbObjectID = (CmdbObjectID)cmdbGraph.getRoot().getID();
      try {
        ModifiableCMDBGraph modifiableCMDBGraph = CmdbGraphFactory.createModifiableCMDBGraph(cmdbGraph);
        modifiableCMDBGraph.removeObject(cmdbObjectID);
        cmdbGraph = modifiableCMDBGraph.toReadOnlyCMDBGraph();
      } catch (CloneNotSupportedException ex) {
        throw new EnrichmentException("Failed to remove enrichment definition without root", ex);
      }
    }

    Changer changer = createChanger(enrichmentName);
    ModelUpdateRemoveGraph modelUpdateRemoveGraph = new ModelUpdateRemoveGraph(cmdbGraph, changer);
    modelUpdateRemoveGraph.setUserOperation(true);
    executeOperation(modelUpdateRemoveGraph);

    getEnrichmentDefinitions().remove(enrichmentName);
    if (_logger.isDebugEnabled())
      _logger.debug("remove enrichment definition: " + enrichmentName);

    return null;
  }

  public EnrichmentDefinitions retrieveAllEnrichmentDefinitions()
  {
    return getEnrichmentDefinitions();
  }

  private void loadEnrichments()
  {
    EnrichmentDefinitions enrichmentDefinitions;
    EnrichmentDefinitionsMemento enrichmentDefinitionsMemento;
    Pattern pattern = EnrichmentPersistenceUtils.createGetAllEnrichmentsPattern();

    PatternLayout patternLayout = EnrichmentPersistenceUtils.createGetAllEnrichmentsLayout();

    CmdbGraph cmdbGraph = getAdHocGraph(pattern, patternLayout);

    if (cmdbGraph.hasRoots()) {
      enrichmentDefinitionsMemento = EnrichmentDefinitionMementoFactory.createEnrichmentDefinitionsMemento(getDataFactory());

      CmdbGraphIterator cmdbGraphIterator = cmdbGraph.getGraphIterator();
      enrichmentDefinitions = (EnrichmentDefinitions)enrichmentDefinitionsMemento.fromCmdbGraph(cmdbGraphIterator);
    }
    else {
      enrichmentDefinitions = EnrichmentDefinitionFactory.createEnrichmentDefinitions(String.valueOf(getCustomerID()));
      enrichmentDefinitionsMemento = EnrichmentDefinitionMementoFactory.createEnrichmentDefinitionsMemento(getDataFactory());

      cmdbGraph = enrichmentDefinitionsMemento.toCmdbGraph(enrichmentDefinitions);
      Changer changer = ChangerFactory.createChanger("UCMDB", "customer " + getCustomerID());
      ModelUpdateAddGraph modelUpdateAddGraph = new ModelUpdateAddGraph(cmdbGraph, changer);
      modelUpdateAddGraph.setUserOperation(true);
      executeOperation(modelUpdateAddGraph);

      if (_logger.isDebugEnabled())
        _logger.debug("Had created the enrichment definitions object per customer");
    }

    setEnrichmentDefinitions(enrichmentDefinitions);
    setEnrichmentDefinitionsObject(cmdbGraph.getRoot());
  }

  private CmdbGraph loadEnrichmentDefinition(String enrichmentName)
  {
    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();

    ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition(EnrichmentDefinition.ENRICHMENT_DEFINITION, false);

    ModifiableElementPropertiesCondition propCondition = PatternConditionFactory.createElementPropertiesCondition();
    propCondition.addPropertyCondition(PatternConditionFactory.createPropertyCondition("enrichmentName", ConditionOperator.EQUEL, enrichmentName, false));

    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, propCondition);

    PatternNodeSubGraphParameter subGraphParameter = createSubGraphParam();
    PatternElementNumber elementNumber = PatternElementNumberFactory.createElementNumber(10);
    PatternNodeWithSubGraph subGraphNode = PatternGraphFactory.createSubGraphNode(elementNumber, elementCondition, true, PatternConditionFactory.createNodeLinksCondition(), "name", subGraphParameter);

    patternGraph.addNode(subGraphNode);

    Pattern pattern = PatternDefinitionFactory.createPattern("mercury", "enrichment definition", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    PatternLayout patternLayout = PatternLayoutFactory.createLayout();

    return getAdHocGraph(pattern, patternLayout);
  }

  private PatternNodeSubGraphParameter createSubGraphParam() {
    PatternTriplets triples = PatternGraphFactory.createTriplets();
    PatternNode srcNode = PatternGraphFactory.createPatternNode(11, "", "object", true, true, null, null);
    PatternNode dstNode = PatternGraphFactory.createPatternNode(12, "", "object", true, true, null, null);
    PatternLink linkSub = PatternGraphFactory.createPatternLink(13, 11, 12, "", "link", true, true, null);
    PatternTriple tripel = PatternGraphFactory.createTriple(srcNode, linkSub, dstNode);
    triples.add(tripel);
    return PatternGraphFactory.createSubGraphParameter("name", 9, triples, SubGraphCalculator.INNER_OBJECTS_NUMBER, SubGraphCalculator.INNER_LINKS_NUMBER, SubGraphCalculator.FROM_SOURCE_LINK_NUMBER, SubGraphCalculator.TO_SOURCE_LINK_NUMBER);
  }

  protected TqlResultMap getAdHocMap(Pattern pattern, PatternLayout patternLayout)
  {
    TqlQueryGetAdHocMap tqlQueryGetAdHocMap = new TqlQueryGetAdHocMap(pattern, patternLayout);
    executeOperation(tqlQueryGetAdHocMap);

    return tqlQueryGetAdHocMap.getResultMap();
  }

  protected CmdbGraph getAdHocGraph(Pattern pattern, PatternLayout patternLayout)
  {
    TqlQueryGetAdHocGraph tqlQueryGetAdHocGraph = new TqlQueryGetAdHocGraph(pattern, patternLayout);
    executeOperation(tqlQueryGetAdHocGraph);

    return tqlQueryGetAdHocGraph.getResultGraph();
  }

  private EnrichmentDefinitions getEnrichmentDefinitions() {
    return this._enrichmentDefinitions;
  }

  private void setEnrichmentDefinitions(EnrichmentDefinitions enrichmentDefinitions) {
    this._enrichmentDefinitions = enrichmentDefinitions;
  }

  private CmdbObject getEnrichmentDefinitionsObject() {
    return this._enrichmentDefinitionsObject;
  }

  private void setEnrichmentDefinitionsObject(CmdbObject enrichmentDefinitionsObject) {
    this._enrichmentDefinitionsObject = enrichmentDefinitionsObject;
  }

  public String getName() {
    return null;
  }
}