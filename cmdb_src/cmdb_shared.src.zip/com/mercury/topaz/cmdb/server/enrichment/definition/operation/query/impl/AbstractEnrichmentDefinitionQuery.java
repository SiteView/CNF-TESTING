package com.mercury.topaz.cmdb.server.enrichment.definition.operation.query.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.impl.AbstractEnrichmentDefinitionOperation;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.EnrichmentQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractEnrichmentDefinitionQuery extends AbstractEnrichmentDefinitionOperation
  implements EnrichmentQuery
{
  public void enrichmentExecute(EnrichmentDefinitionManager enrichmentDefinitionManager, CmdbResponse response)
  {
    enrichmentExecuteQuery(enrichmentDefinitionManager, response);
  }
}