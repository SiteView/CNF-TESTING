package com.mercury.topaz.cmdb.server.enrichment.calculator;

import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.id.CmdbEnrichmentID;
import com.mercury.topaz.cmdb.shared.enrichment.definition.result.EnrichmentResultCount;
import com.mercury.topaz.cmdb.shared.tql.change.TqlNotificationData;

public abstract interface EnrichmentCalculatorManager extends CmdbSubsystemManager
{
  public abstract void calculateEnrichment(TqlNotificationData paramTqlNotificationData, int paramInt);

  public abstract void calculateEnrichment(CmdbEnrichmentID paramCmdbEnrichmentID, int paramInt);

  public abstract void removeObjectsAndLinksCreatedByEnrichment(String paramString);

  public abstract EnrichmentResultCount getResultCount(EnrichmentDefinition paramEnrichmentDefinition);
}