package com.mercury.topaz.cmdb.server.enrichment.admin.tqlnotification.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.enrichment.admin.operation.update.impl.EnrichmentUpdateRemovePattern;
import com.mercury.topaz.cmdb.server.enrichment.admin.operation.update.impl.EnrichmentUpdateUpdatePattern;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.tql.change.impl.TqlChangeAddAdmin;
import com.mercury.topaz.cmdb.shared.tql.change.impl.TqlChangeRemoveAdmin;
import com.mercury.topaz.cmdb.shared.tql.change.impl.TqlChangeUpdateAdmin;
import com.mercury.topaz.cmdb.shared.tql.change.manage.AbstractTqlAdminChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;

public class EnrichmentPatternDefinitionChangeListenerImpl extends AbstractTqlAdminChangeListenerFineGrained
{
  private static Log _logger = LogFactory.getEasyLog(EnrichmentPatternDefinitionChangeListenerImpl.class);

  public EnrichmentPatternDefinitionChangeListenerImpl(CmdbCustomerID customerID)
  {
    super(customerID);
  }

  public void onAdd(TqlChangeAddAdmin tqlChangeAddAdmin)
  {
  }

  public void onRemove(TqlChangeRemoveAdmin tqlChangeRemoveAdmin)
  {
    EnrichmentUpdateRemovePattern operation;
    try
    {
      operation = new EnrichmentUpdateRemovePattern(tqlChangeRemoveAdmin.getPattern());
      executeAsynchronousOperation(operation);
    }
    catch (CmdbResponseException ex) {
      _logger.error("Failed to EnrichmentPatternDefinitionChangeListenerImpl.onRemove()", ex);
    }
  }

  public void onUpdate(TqlChangeUpdateAdmin tqlChangeUpdateAdmin)
  {
    Pattern previousPattern;
    try
    {
      previousPattern = tqlChangeUpdateAdmin.getPreviousPattern();
      Pattern newPattern = tqlChangeUpdateAdmin.getPattern();
      PatternGraph previousPatternGraph = previousPattern.getPatternGraph();
      PatternGraph newPatternGraph = newPattern.getPatternGraph();
      if (!(previousPatternGraph.equals(newPatternGraph))) {
        EnrichmentUpdateUpdatePattern operation = new EnrichmentUpdateUpdatePattern(newPattern);
        executeAsynchronousOperation(operation);
      }
    }
    catch (CmdbResponseException ex) {
      _logger.error("Failed to EnrichmentPatternDefinitionChangeListenerImpl.onUpdate()", ex);
    }
  }

  public void onStartDeployment()
  {
  }

  public void onFinishDeployment()
  {
  }
}