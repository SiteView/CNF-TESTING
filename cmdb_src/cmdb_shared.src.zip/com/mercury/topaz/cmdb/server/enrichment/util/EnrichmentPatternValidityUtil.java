package com.mercury.topaz.cmdb.server.enrichment.util;

import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentAction;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentActions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentAttribute;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentImmutableAttributes;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentLink;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentObject;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentComplexOperand;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentComplexOperands;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentExpression;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.HashSet;
import java.util.NoSuchElementException;

public class EnrichmentPatternValidityUtil
{
  public static boolean isUpdatePatternValid(Pattern newPattern, Pattern oldPattern, EnrichmentDefinitions enrichmentDefinitions)
  {
    ReadOnlyIterator iterEnrichmentDefinitions = enrichmentDefinitions.getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();
      if (!(isUpdatePatternValid4EnrichmentDefinition(enrichmentDefinition, oldPattern, newPattern)))
        return false;
    }

    return true;
  }

  public static boolean isUpdatePatternValid4EnrichmentDefinition(EnrichmentDefinition enrichmentDefinition, Pattern oldPattern, Pattern newPattern)
  {
    PatternGraph oldPatternGraph = oldPattern.getPatternGraph();
    PatternGraph newPatternGraph = newPattern.getPatternGraph();
    EnrichmentActions enrichmentActions = enrichmentDefinition.getEnrichmentActions();
    ReadOnlyIterator iterActions = enrichmentActions.getElementsIterator();
    while (iterActions.hasNext()) {
      EnrichmentAction enrichmentAction = (EnrichmentAction)iterActions.next();

      if (!(areEndsValidAndIsClassWasNotChanged(enrichmentDefinition, enrichmentAction, oldPatternGraph, newPatternGraph))) {
        return false;
      }

    }

    return (areRelevantPatternNodesWereNotChanged(enrichmentActions, oldPatternGraph, newPatternGraph));
  }

  private static boolean areEndsValidAndIsClassWasNotChanged(EnrichmentDefinition enrichmentDefinition, EnrichmentAction enrichmentAction, PatternGraph oldPatternGraph, PatternGraph newPatternGraph)
  {
    if (!(areEndsValid(enrichmentDefinition, enrichmentAction, oldPatternGraph, newPatternGraph))) {
      return false;
    }

    return (isClassWasNotChanged(enrichmentDefinition.getEnrichmentActions(), enrichmentAction, oldPatternGraph, newPatternGraph));
  }

  private static boolean areEndsValid(EnrichmentDefinition enrichmentDefinition, EnrichmentAction enrichmentAction, PatternGraph oldPatternGraph, PatternGraph newPatternGraph)
  {
    if (!(enrichmentAction instanceof EnrichmentLink)) break label145;
    EnrichmentLink enrichmentLink = (EnrichmentLink)enrichmentAction;
    PatternElementNumber end1 = enrichmentLink.getNodeNumberEnd1();
    PatternElementNumber end2 = enrichmentLink.getNodeNumberEnd2();
    if ((!(existInEnrichmentDefinition(enrichmentDefinition, end1))) && (!(newPatternGraph.hasDefinitionElement(end1))))
    {
      return false;
    }
    if ((!(existInEnrichmentDefinition(enrichmentDefinition, end2))) && (!(newPatternGraph.hasDefinitionElement(end2))))
    {
      return false;
    }

    if ((newPatternGraph.hasDefinitionElement(end1)) && (!(oldPatternGraph.getElementClass(end1).equals(newPatternGraph.getElementClass(end1)))))
    {
      return false;
    }

    label145: return ((!(newPatternGraph.hasDefinitionElement(end2))) || (oldPatternGraph.getElementClass(end2).equals(newPatternGraph.getElementClass(end2))));
  }

  private static boolean isClassWasNotChanged(EnrichmentActions enrichmentActions, EnrichmentAction enrichmentAction, PatternGraph oldPatternGraph, PatternGraph newPatternGraph)
  {
    EnrichmentImmutableAttributes enrichmentAttributes = enrichmentAction.getEnrichmentAttributes();
    if (enrichmentAttributes != null) {
      ReadOnlyIterator iterAttributes = enrichmentAttributes.getElementsIterator();
      while (iterAttributes.hasNext()) {
        EnrichmentAttribute enrichmentAttribute = (EnrichmentAttribute)iterAttributes.next();
        EnrichmentExpression enrichmentExpression = enrichmentAttribute.getEnrichmentExpression();
        EnrichmentComplexOperands enrichmentComplexOperands = enrichmentExpression.getEnrichmentComplexOperands();
        ReadOnlyIterator iterComplexOperands = enrichmentComplexOperands.getElementsIterator();
        while (iterComplexOperands.hasNext()) {
          EnrichmentComplexOperand enrichmentComplexOperand = (EnrichmentComplexOperand)iterComplexOperands.next();
          try {
            String className = enrichmentComplexOperand.getClassName(enrichmentActions, newPatternGraph);
            String classNameOrig = oldPatternGraph.getElementClass(enrichmentComplexOperand.getNodeNumber());
            if (!(className.equals(classNameOrig)))
              return false;
          }
          catch (NoSuchElementException ex)
          {
            return false;
          }
        }
      }
    }
    return true;
  }

  private static boolean areRelevantPatternNodesWereNotChanged(EnrichmentActions enrichmentActions, PatternGraph oldPatternGraph, PatternGraph newPatternGraph)
  {
    HashSet enrichmentNodeNumbers = fillAllObjectsNodeNumbers(enrichmentActions);

    ReadOnlyIterator iterLinks = oldPatternGraph.getLinkNumbersIterator();
    while (iterLinks.hasNext()) {
      PatternElementNumber patternLinkNumber = (PatternElementNumber)iterLinks.next();
      if (newPatternGraph.hasDefinitionElement(patternLinkNumber)) {
        PatternLink patternLink = newPatternGraph.getLink(patternLinkNumber);
        PatternElementNumber end1 = patternLink.getEnd1Number();
        PatternElementNumber end2 = patternLink.getEnd2Number();
        if (enrichmentNodeNumbers.contains(end1)) {
          if (!(oldPatternGraph.getElementClass(patternLinkNumber).equals(newPatternGraph.getElementClass(patternLinkNumber))))
            return false;

          if (!(oldPatternGraph.getElementClass(end1).equals(newPatternGraph.getElementClass(end1))))
            return false;

          if (!(oldPatternGraph.getElementClass(end2).equals(newPatternGraph.getElementClass(end2))))
            return false;
        }

        if (enrichmentNodeNumbers.contains(end2)) {
          if (!(oldPatternGraph.getElementClass(patternLinkNumber).equals(newPatternGraph.getElementClass(patternLinkNumber))))
            return false;

          if (!(oldPatternGraph.getElementClass(end1).equals(newPatternGraph.getElementClass(end1))))
            return false;

          if (!(oldPatternGraph.getElementClass(end2).equals(newPatternGraph.getElementClass(end2))))
            return false;
        }
      }
    }

    return true;
  }

  private static boolean existInEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition, PatternElementNumber nodeNumber)
  {
    EnrichmentActions enrichmentActions = enrichmentDefinition.getEnrichmentActions();
    ReadOnlyIterator iterActions = enrichmentActions.getElementsIterator();
    while (iterActions.hasNext()) {
      EnrichmentAction enrichmentAction = (EnrichmentAction)iterActions.next();
      if (enrichmentAction.getNodeNumber().equals(nodeNumber))
        return true;
    }

    return false;
  }

  private static HashSet fillAllObjectsNodeNumbers(EnrichmentActions enrichmentActions)
  {
    HashSet enrichmentNodeNumbers = new HashSet();
    ReadOnlyIterator iterActions = enrichmentActions.getEnrichmentObjectsIterator();
    while (iterActions.hasNext()) {
      EnrichmentObject enrichmentObject = (EnrichmentObject)iterActions.next();
      PatternElementNumber elementNumber = enrichmentObject.getNodeNumber();
      enrichmentNodeNumbers.add(elementNumber);
    }
    iterActions = enrichmentActions.getEnrichmentLinksIterator();
    while (iterActions.hasNext()) {
      EnrichmentLink enrichmentLink = (EnrichmentLink)iterActions.next();
      PatternElementNumber end1 = enrichmentLink.getNodeNumberEnd1();
      PatternElementNumber end2 = enrichmentLink.getNodeNumberEnd2();
      enrichmentNodeNumbers.add(end1);
      enrichmentNodeNumbers.add(end2);
    }
    return enrichmentNodeNumbers;
  }
}