package com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

class AbstractEnrichmentUpdateEnrichmentDefinition extends AbstractEnrichmentDefinitionUpdate
{
  private EnrichmentDefinition _enrichmentDefinition;

  public String getOperationName()
  {
    return "Enrichment Update: Add/Update enrichment{EnrichmentDefinition=" + getEnrichmentDefinition() + '}';
  }

  protected void doEnrichmentExecute(EnrichmentDefinitionManager enrichmentDefinitionManager, CmdbResponse response)
    throws EnrichmentValidationException
  {
    updateValidation(enrichmentDefinitionManager);
  }

  protected void updateValidation(EnrichmentDefinitionManager enrichmentDefinitionManager)
    throws EnrichmentValidationException
  {
  }

  public EnrichmentDefinition getEnrichmentDefinition()
  {
    return this._enrichmentDefinition;
  }

  protected void setEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition) {
    if (enrichmentDefinition == null)
      throw new IllegalArgumentException("Enrichment definition can't be null");

    this._enrichmentDefinition = enrichmentDefinition;
  }
}