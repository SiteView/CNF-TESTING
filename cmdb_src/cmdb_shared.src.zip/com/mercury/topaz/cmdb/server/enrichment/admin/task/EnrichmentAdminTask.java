package com.mercury.topaz.cmdb.server.enrichment.admin.task;

public class EnrichmentAdminTask
{
  public static final String NAME = "Enrichment Admin Task";
}