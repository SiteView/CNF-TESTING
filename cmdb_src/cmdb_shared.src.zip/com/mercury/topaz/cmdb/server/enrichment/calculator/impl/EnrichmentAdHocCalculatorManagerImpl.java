package com.mercury.topaz.cmdb.server.enrichment.calculator.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadMultiWrite;
import com.mercury.topaz.cmdb.server.enrichment.calculator.EnrichmentAdHocCalculatorManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalOperator;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewLink;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewLinks;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewObject;
import com.mercury.topaz.cmdb.shared.enrichment.definition.operation.query.businessview.impl.EnrichmentQueryGetEnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.PatternState;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.CmdbPatternIDFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultMap;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdateAddPatternToResultRepository;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultMapUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

class EnrichmentAdHocCalculatorManagerImpl extends AbstractEnrichmentCalculatorManager
  implements EnrichmentAdHocCalculatorManager, MultiReadMultiWrite
{
  private static Log _logger = LogFactory.getEasyLog(EnrichmentAdHocCalculatorManagerImpl.class);
  private static final PatternElementNumber ELEMENT_NUMBER_1ST = PatternElementNumberFactory.createElementNumber(1);
  private static final PatternElementNumber ELEMENT_NUMBER_2ND = PatternElementNumberFactory.createElementNumber(2);
  private static final PatternElementNumber ELEMENT_NUMBER_LINK1 = PatternElementNumberFactory.createElementNumber(3);
  private static final PatternElementNumber ELEMENT_NUMBER_LINK2 = PatternElementNumberFactory.createElementNumber(4);

  EnrichmentAdHocCalculatorManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public void startUp() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: EnrichmentAdHocCalculatorManager is started up properly!!!");
  }

  public void shutdown() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: EnrichmentAdHocCalculatorManager is shutdown properly!!!");
  }

  protected boolean fuseOk(EnrichmentDefinition enrichmentDefinition, ModelUpdateOperations listPerOperation)
  {
    if (enrichmentDefinition.getEnrichmentType() == 1)
      return super.fuseOk(enrichmentDefinition, listPerOperation);

    CmdbLinks cmdbLinks4Create = listPerOperation.getLinks4Create();

    long createLinksNumber = cmdbLinks4Create.size();
    long maxAllowedLinksCreating = getAllowedMaxCisChanges(enrichmentDefinition);
    if (createLinksNumber > maxAllowedLinksCreating) {
      String msg = enrichmentDefinition.getEnrichmentName() + " -- " + "The number of links creating to model " + createLinksNumber + " is greater than the max allowed create links " + maxAllowedLinksCreating;

      _enrichmentLogger.error(msg);
      _logger.error(msg);
      return false;
    }
    return true;
  }

  public void calculateAdHocEnrichment(String enrichmentName)
  {
    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(enrichmentName + " -- " + "Calculate ad hoc enrichment");

    EnrichmentDefinition enrichmentDefinition = retrieveEnrichmentDefinitionByEnrichmentName(enrichmentName);
    if (enrichmentDefinition == null) {
      _enrichmentLogger.error("could not find enrichment:" + enrichmentName);
      throw new IllegalArgumentException("enrichment: " + enrichmentName + " does not exist in the repository");
    }
    Pattern pattern = retrievePatternById(enrichmentDefinition);

    calculateAdHocEnrichment(pattern, enrichmentDefinition);

    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(enrichmentName + " -- " + "Finished ad hoc calculate enrichment related to pattern: " + pattern.getID());
  }

  public void calculateAdHocEnrichmentBusinessView(String enrichmentName)
  {
    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(enrichmentName + " -- " + "Calculate ad hoc business view enrichment");

    EnrichmentBusinessViewDefinition enrichmentDefinition = retrieveEnrichmentBusinessViewDefinitionByEnrichmentName(enrichmentName);
    if (enrichmentDefinition == null) {
      String msg = enrichmentName + " -- " + " was removed, therefore remove the enrichment's results. " + "Please remove the scheduler related to this enrichment";

      _enrichmentLogger.error(msg);
      _logger.error(msg);

      removeObjectsAndLinksCreatedByEnrichment(enrichmentName);
      return;
    }

    Pattern pattern = retrievePatternById((EnrichmentDefinition)enrichmentDefinition);

    calculateAdHocEnrichment(pattern, enrichmentDefinition);

    if (_enrichmentLogger.isInfoEnabled())
      _enrichmentLogger.info(enrichmentName + " -- " + "Finished ad hoc calculate business view enrichment related to pattern: " + pattern.getID());
  }

  private void calculateAdHocEnrichment(Pattern pattern, EnrichmentDefinition enrichmentDefinition)
  {
    pattern = createTempPatternIfRequired(pattern);

    CmdbPatternID patternId = pattern.getID();
    try {
      ModelUpdateOperations listPerOperation = new ModelUpdateOperations();

      fillListPerOperation(enrichmentDefinition, pattern, null, listPerOperation);

      createModelOperations(enrichmentDefinition, listPerOperation);
    } catch (Exception ex) {
      String msg = enrichmentDefinition.getEnrichmentName() + " -- " + "Failed to ad hoc calculate enrichment related to pattern: " + patternId;

      _logger.error(msg, ex);
      _enrichmentLogger.error(msg, ex);
    }
  }

  private void calculateAdHocEnrichment(Pattern pattern, EnrichmentBusinessViewDefinition enrichmentDefinition) {
    pattern = createTempPatternIfRequired(pattern);

    CmdbPatternID patternId = pattern.getID();
    try {
      ModelUpdateOperations listPerOperation = new ModelUpdateOperations();

      fillListPerOperation(enrichmentDefinition, pattern, null, listPerOperation);

      createModelOperations((EnrichmentDefinition)enrichmentDefinition, listPerOperation);
    } catch (Exception ex) {
      String msg = enrichmentDefinition.getEnrichmentName() + " -- " + "Failed to ad hoc calculate enrichment related to pattern: " + patternId;

      _logger.error(msg, ex);
      _enrichmentLogger.error(msg, ex);
    }
  }

  private Pattern createTempPatternIfRequired(Pattern pattern) {
    if (!(pattern.getState().isActive()))
    {
      CmdbPatternID cmdbPatternID = pattern.getID();
      cmdbPatternID = CmdbPatternIDFactory.createObjectID("" + cmdbPatternID + new Date().getTime());
      pattern = PatternDefinitionFactory.createFromPattern(cmdbPatternID.getPatternName(), pattern, pattern.getGroupId());
      TqlUpdateAddPatternToResultRepository tqlQueryGetAdHocMap = new TqlUpdateAddPatternToResultRepository(pattern, 600000L);
      executeOperation(tqlQueryGetAdHocMap);
    }
    return pattern;
  }

  protected void fillListPerOperation(EnrichmentBusinessViewDefinition enrichmentBusinessViewDefinition, Pattern pattern, TqlResultMap requiredObjects, ModelUpdateOperations listPerOperation)
  {
    HashMap node2ObjectsMap = getResultsPerNode(enrichmentBusinessViewDefinition, pattern, requiredObjects);

    CmdbObject cmdbCreateObject = createObject(enrichmentBusinessViewDefinition);

    fillPrevResultsLinkIds(enrichmentBusinessViewDefinition, listPerOperation);

    if ((node2ObjectsMap != null) && (!(node2ObjectsMap.isEmpty()))) {
      for (Iterator i$ = node2ObjectsMap.keySet().iterator(); i$.hasNext(); ) { Object obj = i$.next();
        PatternElementNumber elementNumber = (PatternElementNumber)obj;
        CmdbObjects cmdbObjects = (CmdbObjects)node2ObjectsMap.get(elementNumber);
        if (_logger.isDebugEnabled()) {
          _logger.debug(enrichmentBusinessViewDefinition.getEnrichmentName() + " -- " + "start fillCreateLinks for patternInstance " + cmdbObjects);
        }

        fillCreateLinks(enrichmentBusinessViewDefinition, cmdbCreateObject, elementNumber, cmdbObjects, listPerOperation);

        if (_logger.isDebugEnabled())
          _logger.debug(enrichmentBusinessViewDefinition.getEnrichmentName() + " -- " + "finish fillCreateLinks for patternInstance " + cmdbObjects);

      }

      CmdbLinks cmdbLinks4Create = listPerOperation.getLinks4Create();
      if (!(cmdbLinks4Create.isEmpty()))
        addObjectToListPerOperation(cmdbCreateObject, listPerOperation);
    }
  }

  private HashMap getResultsPerNode(EnrichmentBusinessViewDefinition enrichmentDefinition, Pattern pattern, TqlResultMap requiredObjects)
  {
    EnrichmentBusinessViewLinks businessViewLinks = enrichmentDefinition.getBusinessViewLinks();

    checkRequiredObjectsDoesntContainRemovedNode(enrichmentDefinition, pattern);

    if (_logger.isDebugEnabled()) {
      _logger.debug(enrichmentDefinition.getEnrichmentName() + " -- " + "getInstances patternId: " + pattern.getID() + ", businessViewLinks: " + businessViewLinks + ", requiredObjects: " + requiredObjects);
    }

    if (requiredObjects == null) {
      TqlQueryGetResultMap tqlQueryGetResultMap = new TqlQueryGetResultMap(pattern.getID());
      executeOperation(tqlQueryGetResultMap);
      if (tqlQueryGetResultMap.isDividedToChunks())
        requiredObjects = TqlResultMapUtils.getResultInChunks(tqlQueryGetResultMap.getChunkRequest(), this, true);
      else
        requiredObjects = tqlQueryGetResultMap.getResultMap();
    }

    HashMap node2Objects = getResultsPerNode(requiredObjects, businessViewLinks);
    if (_logger.isDebugEnabled())
      _logger.debug(enrichmentDefinition.getEnrichmentName() + " -- " + "patternInstances: " + node2Objects);

    return node2Objects;
  }

  private HashMap getResultsPerNode(TqlResultMap requiredObjects, EnrichmentBusinessViewLinks businessViewLinks)
  {
    HashMap node2Objects = new HashMap();
    ReadOnlyIterator iterBusinessViewLinks = businessViewLinks.getElementsIterator();
    while (iterBusinessViewLinks.hasNext()) {
      EnrichmentBusinessViewLink businessViewLink = (EnrichmentBusinessViewLink)iterBusinessViewLinks.next();
      PatternElementNumber elementNumber = businessViewLink.getEndNodeNumber();
      if (requiredObjects.containsElementNumber(elementNumber))
        node2Objects.put(elementNumber, requiredObjects.getObjects(elementNumber));
    }

    return node2Objects;
  }

  private void checkRequiredObjectsDoesntContainRemovedNode(EnrichmentBusinessViewDefinition enrichmentDefinition, Pattern pattern) {
    EnrichmentBusinessViewLinks businessViewLinks = enrichmentDefinition.getBusinessViewLinks();
    PatternGraph patternGraph = pattern.getPatternGraph();

    ReadOnlyIterator iterBusinessViewLinks = businessViewLinks.getElementsIterator();
    while (iterBusinessViewLinks.hasNext()) {
      EnrichmentBusinessViewLink businessViewLink = (EnrichmentBusinessViewLink)iterBusinessViewLinks.next();
      PatternElementNumber elementNumber = businessViewLink.getEndNodeNumber();
      if (!(patternGraph.hasDefinitionElement(elementNumber))) {
        String msg = enrichmentDefinition.getEnrichmentName() + " -- " + "node number " + elementNumber + " was removed from tql definition and the related enrichment was not updated. The calculation has no harm." + " Please update the corresponded tql/view or update the enrichment (update the business view enrichment through the view)";

        _enrichmentLogger.error(msg);
        _logger.error(msg);
      }
    }
  }

  private CmdbObject createObject(EnrichmentBusinessViewDefinition enrichmentDefinition) {
    EnrichmentBusinessViewObject businessViewObject = enrichmentDefinition.getBusinessViewObject();
    CmdbProperty cmdbProperty = createDataSourceProperty(enrichmentDefinition.getEnrichmentName());
    CmdbProperties objectProperties = businessViewObject.getProperties();
    objectProperties.add(cmdbProperty);
    return getDataFactory().createObject(businessViewObject.getClassName(), objectProperties);
  }

  private void addObjectToListPerOperation(CmdbObject cmdbObject, ModelUpdateOperations listPerOperation) {
    HashSet cmdbObjects4CreateHashSet = listPerOperation.getObjects4CreateHashSet();
    if (!(cmdbObjects4CreateHashSet.contains(cmdbObject.getID()))) {
      CmdbObjects cmdbObjects = listPerOperation.getObjects4Create();
      cmdbObjects.add(cmdbObject);
      cmdbObjects4CreateHashSet.add(cmdbObject.getID());
    }
  }

  private void fillCreateLinks(EnrichmentBusinessViewDefinition enrichmentDefinition, CmdbObject createObject, PatternElementNumber elementNumber, CmdbObjects cmdbObjects, ModelUpdateOperations listPerOperation)
  {
    EnrichmentBusinessViewLink businessViewLink = enrichmentDefinition.getBusinessViewLinks().getBusinessViewLinkByNodeNumber(elementNumber);

    CmdbProperty cmdbProperty = createDataSourceProperty(enrichmentDefinition.getEnrichmentName());
    CmdbProperties linkProperties = businessViewLink.getProperties();
    linkProperties.add(cmdbProperty);

    String linkClassName = businessViewLink.getClassName();
    boolean isCreateObjectEnd1 = businessViewLink.isCreateObjectEnd1();
    ReadOnlyIterator iterObjects = cmdbObjects.getObjectsIterator();
    while (iterObjects.hasNext()) {
      CmdbLink cmdbLink;
      CmdbObject cmdbObject = (CmdbObject)iterObjects.next();

      if (isCreateObjectEnd1)
        cmdbLink = getDataFactory().createLink(linkClassName, (CmdbObjectID)createObject.getID(), (CmdbObjectID)cmdbObject.getID(), linkProperties);
      else {
        cmdbLink = getDataFactory().createLink(linkClassName, (CmdbObjectID)cmdbObject.getID(), (CmdbObjectID)createObject.getID(), linkProperties);
      }

      HashSet cmdbLinks4CreateSet = listPerOperation.getLinks4CreateHashSet();
      HashSet cmdbLinks4RemoveSet = listPerOperation.getLinks4RemoveHashSet();
      CmdbLinkID cmdbLinkID = (CmdbLinkID)cmdbLink.getID();

      if (!(cmdbLinks4CreateSet.contains(cmdbLinkID))) {
        CmdbLinks cmdbLinks;
        if (!(cmdbLinks4RemoveSet.contains(cmdbLinkID))) {
          cmdbLinks = listPerOperation.getLinks4Create();
          cmdbLinks.add(cmdbLink);
          cmdbLinks4CreateSet.add(cmdbLink.getID());
        } else {
          cmdbLinks = listPerOperation.getLinks4Remove();
          cmdbLinks.remove((CmdbDataID)cmdbLink.getID());
          cmdbLinks4RemoveSet.remove(cmdbLink.getID());
        }
      }
    }
  }

  private void fillPrevResultsLinkIds(EnrichmentBusinessViewDefinition enrichmentBusinessViewDefinition, ModelUpdateOperations listPerOperation) {
    CmdbGraph cmdbGraph = getPreviousResults(enrichmentBusinessViewDefinition);

    CmdbLinks cmdbLinks4Remove = listPerOperation.getLinks4Remove();
    HashSet cmdbLinks4RemoveHashSet = listPerOperation.getLinks4RemoveHashSet();

    ReadOnlyIterator iterLinksPrev = cmdbGraph.getLinksIterator();
    while (iterLinksPrev.hasNext()) {
      CmdbLink link = (CmdbLink)iterLinksPrev.next();
      cmdbLinks4Remove.add(link);
      cmdbLinks4RemoveHashSet.add(link.getID());
    }
  }

  private CmdbGraph getPreviousResults(EnrichmentBusinessViewDefinition enrichmentBusinessViewDefinition) {
    Pattern pattern = createResultsPattern(enrichmentBusinessViewDefinition);
    PatternLayout layout = PatternLayoutFactory.createLayout();
    return getAdHocGraph(pattern, layout);
  }

  private Pattern createResultsPattern(EnrichmentBusinessViewDefinition enrichmentBusinessViewDefinition) {
    ModifiableNodeLinksCondition nodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
    int linkNumber1 = ELEMENT_NUMBER_LINK1.getNumber();
    nodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(linkNumber1, 1, -1));
    nodeLinksCondition.addLogicalOperator(LogicalOperator.OR);
    int linkNumber2 = ELEMENT_NUMBER_LINK2.getNumber();
    nodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(linkNumber2, 1, -1));

    EnrichmentBusinessViewObject enrichmentBusinessViewObject = enrichmentBusinessViewDefinition.getBusinessViewObject();
    String objectClassName = enrichmentBusinessViewObject.getClassName();
    CmdbProperties objectProperties = enrichmentBusinessViewObject.getProperties();

    ElementClassCondition classCondition1 = PatternConditionFactory.createElementClassCondition(objectClassName, true);
    ElementClassCondition classConditionLink = PatternConditionFactory.createElementClassCondition("link", true);

    ElementPropertiesCondition propertiesCondition = AbstractEnrichmentCalculatorManager.getDataSourceCondition(enrichmentBusinessViewDefinition.getEnrichmentName());

    CmdbObjectIds idsCondition = CmdbObjectIdsFactory.create();
    DataFactory dataFactory = DataFactoryCreator.create(getSynchronizedClassModel());
    CmdbObjectID objectID = dataFactory.createObjectID(objectClassName, objectProperties);
    idsCondition.add(objectID);
    ElementCondition elementCondition1 = PatternConditionFactory.createElementCondition(classCondition1, propertiesCondition, idsCondition);
    ElementCondition elementCondition2 = PatternConditionFactory.createElementCondition("it_world", true);
    ElementCondition elementConditionLink = PatternConditionFactory.createElementCondition(classConditionLink, propertiesCondition);

    PatternNode patternNode1 = PatternGraphFactory.createPatternNode(ELEMENT_NUMBER_1ST, elementCondition1, false, nodeLinksCondition);
    PatternNode patternNode2 = PatternGraphFactory.createPatternNode(ELEMENT_NUMBER_2ND, elementCondition2, false, nodeLinksCondition);
    PatternLink patternLink1 = PatternGraphFactory.createPatternLink(ELEMENT_NUMBER_LINK1, ELEMENT_NUMBER_1ST, ELEMENT_NUMBER_2ND, elementConditionLink, true);

    PatternLink patternLink2 = PatternGraphFactory.createPatternLink(ELEMENT_NUMBER_LINK2, ELEMENT_NUMBER_2ND, ELEMENT_NUMBER_1ST, elementConditionLink, true);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(patternNode1);
    patternGraph.addNode(patternNode2);
    patternGraph.addLink(patternLink1);
    patternGraph.addLink(patternLink2);

    return PatternDefinitionFactory.createPattern("", "businessViewResults", PatternGroupId.PATTERN_GROUP_SERVERDATA, patternGraph);
  }

  protected EnrichmentBusinessViewDefinition retrieveEnrichmentBusinessViewDefinitionByEnrichmentName(String enrichmentName) {
    EnrichmentQueryGetEnrichmentBusinessViewDefinition enrichmentQueryGetEnrichmentDefinition = new EnrichmentQueryGetEnrichmentBusinessViewDefinition(enrichmentName);

    executeOperation(enrichmentQueryGetEnrichmentDefinition);

    return enrichmentQueryGetEnrichmentDefinition.getEnrichmentDefinition();
  }

  public String getName() {
    return "Enrichment Ad Hoc Calculator Task";
  }
}