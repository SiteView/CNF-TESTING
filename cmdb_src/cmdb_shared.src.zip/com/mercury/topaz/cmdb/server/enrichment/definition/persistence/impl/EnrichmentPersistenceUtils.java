package com.mercury.topaz.cmdb.server.enrichment.definition.persistence.impl;

import com.mercury.topaz.cmdb.server.resource.ResourcePersistenceHandler;
import com.mercury.topaz.cmdb.server.tql.calculator.topology.subgraph.SubGraphCalculator;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentActions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentAttribute;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentAttributes;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentLink;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentObject;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentAggregateExpression;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentComplexOperand;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentRegularExpression;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentSimpleOperand;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentSingleExpression;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ConditionOperator;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternNodeSubGraphParameter;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternNodeWithSubGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementTypeLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.triple.PatternTriple;
import com.mercury.topaz.cmdb.shared.tql.definition.triple.PatternTriplets;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class EnrichmentPersistenceUtils
{
  private static final int ENRICHMENT_DEPTH = 9;
  private static final int ROOT_NODE_NUMBER = 14;

  public static ResourcePersistenceHandler<EnrichmentDefinition> createEnrichmentPersistenceHandler()
  {
    return new EnrichmentPersistenceHandler();
  }

  public static Pattern createGetAllEnrichmentsPattern() {
    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();

    ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition(EnrichmentDefinitions.ENRICHMENT_DEFINITIONS, false);

    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition);

    PatternNodeSubGraphParameter subGraphParameter = createSubGraphParam();
    PatternElementNumber elementNumber = PatternElementNumberFactory.createElementNumber(14);
    PatternNodeWithSubGraph subGraphNode = PatternGraphFactory.createSubGraphNode(elementNumber, elementCondition, true, PatternConditionFactory.createNodeLinksCondition(), "name", subGraphParameter);

    patternGraph.addNode(subGraphNode);

    Pattern pattern = PatternDefinitionFactory.createPattern("mercury", "enrichment definitions", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    return pattern;
  }

  private static PatternNodeSubGraphParameter createSubGraphParam() {
    PatternTriplets triples = PatternGraphFactory.createTriplets();
    PatternNode srcNode = PatternGraphFactory.createPatternNode(11, "", "object", true, true, null, null);

    PatternNode dstNode = PatternGraphFactory.createPatternNode(12, "", "object", true, true, null, null);

    PatternLink linkSub = PatternGraphFactory.createPatternLink(13, 11, 12, "", "link", true, true, null);

    PatternTriple tripel = PatternGraphFactory.createTriple(srcNode, linkSub, dstNode);
    triples.add(tripel);
    return PatternGraphFactory.createSubGraphParameter("name", 9, triples, SubGraphCalculator.INNER_OBJECTS_NUMBER, SubGraphCalculator.INNER_LINKS_NUMBER, SubGraphCalculator.FROM_SOURCE_LINK_NUMBER, SubGraphCalculator.TO_SOURCE_LINK_NUMBER);
  }

  public static PatternLayout createGetAllEnrichmentsLayout()
  {
    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    ElementSimpleLayout rootSimpleLayout = getLayoutByClass(EnrichmentDefinitions.ENRICHMENT_DEFINITIONS);
    ElementTypeLayout typeLayout = createEnrichmentTypeLayout();
    patternLayout.setElementLayout(PatternElementNumberFactory.createElementNumber(14), rootSimpleLayout);
    patternLayout.setElementLayout(SubGraphCalculator.INNER_OBJECTS_NUMBER, typeLayout);
    return patternLayout;
  }

  public static Pattern createGetSingleEnrichmentPattern(String enrichmentName) {
    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();

    ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition(EnrichmentDefinition.ENRICHMENT_DEFINITION, false);
    ModifiableElementPropertiesCondition propCondition = PatternConditionFactory.createElementPropertiesCondition();
    propCondition.addPropertyCondition(PatternConditionFactory.createPropertyCondition("enrichmentName", ConditionOperator.EQUEL, enrichmentName, false));
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, propCondition);

    PatternNodeSubGraphParameter subGraphParameter = createSubGraphParam();

    PatternElementNumber elementNumber = PatternElementNumberFactory.createElementNumber(10);
    PatternNodeWithSubGraph subGraphNode = PatternGraphFactory.createSubGraphNode(elementNumber, elementCondition, true, PatternConditionFactory.createNodeLinksCondition(), "name", subGraphParameter);

    patternGraph.addNode(subGraphNode);

    return PatternDefinitionFactory.createPattern("mercury", "enrichment definition [" + enrichmentName + "]", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);
  }

  private static ElementSimpleLayout getLayoutByClass(String className)
  {
    ElementSimpleLayout simpleLayout = PatternLayoutFactory.createElementSimpleLayout();

    CmdbAttributes cmdbAttributes = ClassModelProvider.getClassModell().getClass(className).getClassAttributes();
    ReadOnlyIterator iter = cmdbAttributes.getIterator();
    while (iter.hasNext()) {
      CmdbAttribute cmdbAttribute = (CmdbAttribute)iter.next();
      simpleLayout.addKey(cmdbAttribute.getName());
    }
    return simpleLayout;
  }

  private static ElementTypeLayout createEnrichmentTypeLayout() {
    ElementTypeLayout typeLayout = PatternLayoutFactory.createTypeLayout();

    String[] classNames = { EnrichmentDefinition.ENRICHMENT_DEFINITION, EnrichmentActions.ENRICHMENT_ACTIONS, EnrichmentObject.ENRICHMENT_OBJECT, EnrichmentLink.ENRICHMENT_LINK, EnrichmentAttributes.ENRICHMENT_ATTRIBUTES, EnrichmentAttribute.ENRICHMENT_ATTRIBUTE, EnrichmentAggregateExpression.ENRICHMENT_AGGREGATED_EXPRESSION, EnrichmentRegularExpression.ENRICHMENT_REGULAR_EXPRESSION, EnrichmentSingleExpression.ENRICHMENT_SINGLE_EXPRESSION, EnrichmentComplexOperand.ENRICHMENT_COMPLEX_OPERAND, EnrichmentSimpleOperand.ENRICHMENT_SIMPLE_OPERAND };

    String[] arr$ = classNames; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String className = arr$[i$];
      ElementSimpleLayout simpleLayout = getLayoutByClass(className);
      typeLayout.addSimpleLayout(className, simpleLayout);
    }
    return typeLayout;
  }
}