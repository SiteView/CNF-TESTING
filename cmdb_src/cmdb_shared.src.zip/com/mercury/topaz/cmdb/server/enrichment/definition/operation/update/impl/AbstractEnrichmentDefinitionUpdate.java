package com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.server.enrichment.definition.operation.impl.AbstractEnrichmentDefinitionOperation;
import com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.EnrichmentUpdateDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractEnrichmentDefinitionUpdate extends AbstractEnrichmentDefinitionOperation
  implements EnrichmentUpdateDefinition
{
  public final void enrichmentExecute(EnrichmentDefinitionManager enrichmentDefinitionManager, CmdbResponse response)
    throws EnrichmentValidationException
  {
    doEnrichmentExecute(enrichmentDefinitionManager, response);
  }

  protected abstract void doEnrichmentExecute(EnrichmentDefinitionManager paramEnrichmentDefinitionManager, CmdbResponse paramCmdbResponse)
    throws EnrichmentValidationException;

  protected abstract void updateValidation(EnrichmentDefinitionManager paramEnrichmentDefinitionManager)
    throws EnrichmentValidationException;
}