package com.mercury.topaz.cmdb.server.enrichment.calculator.instances.impl;

import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.EnrichmentPatternInstance;
import com.mercury.topaz.cmdb.server.enrichment.calculator.instances.EnrichmentPatternInstances;

public class EnrichmentPatternInstanceFactory
{
  public static EnrichmentPatternInstances createEnrichmentPatternInstances()
  {
    return new EnrichmentPatternInstancesImpl();
  }

  public static EnrichmentPatternInstance createEnrichmentPatternInstance() {
    return new EnrichmentPatternInstanceImpl();
  }
}