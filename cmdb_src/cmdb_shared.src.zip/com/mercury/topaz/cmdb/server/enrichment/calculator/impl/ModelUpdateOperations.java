package com.mercury.topaz.cmdb.server.enrichment.calculator.impl;

import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.link.id.impl.CmdbLinkIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

class ModelUpdateOperations
{
  protected static final int CREATE_OBJECTS_POS = 0;
  protected static final int UPDATE_OBJECTS_POS = 1;
  protected static final int TOUCH_OBJECTS_POS = 2;
  protected static final int REMOVE_OBJECTS_POS = 3;
  protected static final int CREATE_LINKS_POS = 4;
  protected static final int UPDATE_LINKS_POS = 5;
  protected static final int TOUCH_LINKS_POS = 6;
  protected static final int REMOVE_LINKS_POS = 7;
  protected static final int CREATE_OBJECTS_MAP_POS = 8;
  protected static final int UPDATE_OBJECTS_MAP_POS = 9;
  protected static final int TOUCH_OBJECTS_MAP_POS = 10;
  protected static final int REMOVE_OBJECTS_MAP_POS = 11;
  protected static final int CREATE_LINKS_MAP_POS = 12;
  protected static final int UPDATE_LINKS_MAP_POS = 13;
  protected static final int TOUCH_LINKS_MAP_POS = 14;
  protected static final int REMOVE_LINKS_MAP_POS = 15;
  private List _listPerOperation;

  public ModelUpdateOperations()
  {
    setListPerOperation(new ArrayList());
    createModelUpdateOperations();
  }

  private void createModelUpdateOperations() {
    CmdbObjects cmdbObjects4Create = CmdbObjectFactory.createObjects();
    CmdbObjects cmdbObjects4Update = CmdbObjectFactory.createObjects();
    CmdbObjectIds cmdbObjectsIDs4Touch = CmdbObjectIdsFactory.create();
    CmdbObjectIds cmdbObjectsIDs4Remove = CmdbObjectIdsFactory.create();

    CmdbLinks cmdbLinks4Create = CmdbLinkFactory.createLinks();
    CmdbLinks cmdbLinks4Update = CmdbLinkFactory.createLinks();
    CmdbLinkIds cmdbLinks4Touch = CmdbLinkIdsFactory.create();
    CmdbLinks cmdbLinks4Remove = CmdbLinkFactory.createLinks();

    HashSet cmdbObjects4CreateHashSet = new HashSet();
    HashSet cmdbObjects4UpdateHashSet = new HashSet();
    HashSet cmdbObjects4TouchHashSet = new HashSet();
    HashSet cmdbObjects4RemoveHashSet = new HashSet();

    HashSet cmdbLinks4CreateHashSet = new HashSet();
    HashSet cmdbLinks4UpdateHashSet = new HashSet();
    HashSet cmdbLinks4TouchHashSet = new HashSet();
    HashSet cmdbLinks4RemoveHashSet = new HashSet();

    List listPerOperation = getListPerOperation();

    listPerOperation.add(cmdbObjects4Create);
    listPerOperation.add(cmdbObjects4Update);
    listPerOperation.add(cmdbObjectsIDs4Touch);
    listPerOperation.add(cmdbObjectsIDs4Remove);

    listPerOperation.add(cmdbLinks4Create);
    listPerOperation.add(cmdbLinks4Update);
    listPerOperation.add(cmdbLinks4Touch);
    listPerOperation.add(cmdbLinks4Remove);

    listPerOperation.add(cmdbObjects4CreateHashSet);
    listPerOperation.add(cmdbObjects4UpdateHashSet);
    listPerOperation.add(cmdbObjects4TouchHashSet);
    listPerOperation.add(cmdbObjects4RemoveHashSet);

    listPerOperation.add(cmdbLinks4CreateHashSet);
    listPerOperation.add(cmdbLinks4UpdateHashSet);
    listPerOperation.add(cmdbLinks4TouchHashSet);
    listPerOperation.add(cmdbLinks4RemoveHashSet);
  }

  protected void init() {
    List listPerOperation = getListPerOperation();

    listPerOperation.set(0, CmdbObjectFactory.createObjects());
    listPerOperation.set(1, CmdbObjectFactory.createObjects());
    listPerOperation.set(2, CmdbObjectIdsFactory.create());
    listPerOperation.set(3, CmdbObjectIdsFactory.create());

    listPerOperation.set(4, CmdbLinkFactory.createLinks());
    listPerOperation.set(5, CmdbLinkFactory.createLinks());
    listPerOperation.set(6, CmdbLinkIdsFactory.create());
    listPerOperation.set(7, CmdbLinkFactory.createLinks());

    listPerOperation.set(8, new HashSet());
    listPerOperation.set(9, new HashSet());
    listPerOperation.set(10, new HashSet());
    listPerOperation.set(11, new HashSet());

    listPerOperation.set(12, new HashSet());
    listPerOperation.set(13, new HashSet());
    listPerOperation.set(14, new HashSet());
    listPerOperation.set(15, new HashSet());
  }

  public CmdbObjects getObjects4Create()
  {
    return ((CmdbObjects)getListPerOperation().get(0));
  }

  public CmdbObjects getObjects4Update() {
    return ((CmdbObjects)getListPerOperation().get(1));
  }

  public CmdbObjectIds getObjectsIDs4Touch() {
    return ((CmdbObjectIds)getListPerOperation().get(2));
  }

  public CmdbObjectIds getObjectsIDs4remove() {
    return ((CmdbObjectIds)getListPerOperation().get(3));
  }

  public CmdbLinks getLinks4Create()
  {
    return ((CmdbLinks)getListPerOperation().get(4));
  }

  public CmdbLinks getLinks4Update() {
    return ((CmdbLinks)getListPerOperation().get(5));
  }

  public CmdbLinkIds getLinksIds4Touch() {
    return ((CmdbLinkIds)getListPerOperation().get(6));
  }

  public CmdbLinks getLinks4Remove() {
    return ((CmdbLinks)getListPerOperation().get(7));
  }

  public HashSet getObjects4CreateHashSet()
  {
    return ((HashSet)getListPerOperation().get(8));
  }

  public HashSet getObjects4UpdateHashSet() {
    return ((HashSet)getListPerOperation().get(9));
  }

  public HashSet getObjects4TouchHashSet() {
    return ((HashSet)getListPerOperation().get(10));
  }

  public HashSet getObjects4RemoveHashSet() {
    return ((HashSet)getListPerOperation().get(11));
  }

  public HashSet getLinks4CreateHashSet()
  {
    return ((HashSet)getListPerOperation().get(12));
  }

  public HashSet getLinks4UpdateHashSet() {
    return ((HashSet)getListPerOperation().get(13));
  }

  public HashSet getLinks4TouchHashSet() {
    return ((HashSet)getListPerOperation().get(14));
  }

  public HashSet getLinks4RemoveHashSet() {
    return ((HashSet)getListPerOperation().get(15));
  }

  private List getListPerOperation()
  {
    return this._listPerOperation;
  }

  private void setListPerOperation(List listPerOperation) {
    this._listPerOperation = listPerOperation;
  }
}