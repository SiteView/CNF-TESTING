package com.mercury.topaz.cmdb.server.enrichment.admin.impl;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public class EnrichmentAdminManagerFactory extends AbstractSubsystemManagerFactory
{
  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new EnrichmentAdminManagerImpl(localEnvironment);
  }
}