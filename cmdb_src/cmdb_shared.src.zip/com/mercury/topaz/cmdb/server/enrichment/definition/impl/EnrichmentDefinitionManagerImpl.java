package com.mercury.topaz.cmdb.server.enrichment.definition.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadMultiWrite;
import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.server.enrichment.definition.persistence.EnrichmentPersistenceManager;
import com.mercury.topaz.cmdb.server.enrichment.definition.persistence.impl.EnrichmentPersistenceFactory;
import com.mercury.topaz.cmdb.server.enrichment.util.EnrichmentPatternValidityUtil;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.impl.CmdbClassModelUtil;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLinks;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentAction;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentActions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentAttribute;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitionShallow;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinitionsShallow;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentImmutableActions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentImmutableAttributes;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentLink;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentMutableDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.EnrichmentBusinessViewDefinitions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.businessview.impl.EnrichmentBusinessViewDefinitionFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.id.CmdbEnrichmentID;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.impl.EnrichmentDefinitionFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.impl.EnrichmentDefinitionShallowFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentComplexOperand;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentComplexOperands;
import com.mercury.topaz.cmdb.shared.enrichment.definition.expression.EnrichmentExpression;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPatternIDPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbStringPropertyValues;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.PatternState;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.CmdbPatternIDFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetPattern;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdatePatternRemove;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdatePatternUpdate;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

class EnrichmentDefinitionManagerImpl extends CmdbSubsystemManagerImpl
  implements EnrichmentDefinitionManager, MultiReadMultiWrite
{
  private static Log _logger;
  private EnrichmentDefinitions _enrichmentDefinitions;
  private EnrichmentBusinessViewDefinitions _enrichmentBusinessViewDefinitions;
  private Map<String, List<String>> tql2EnrichmentName;
  EnrichmentPersistenceManager _enrichmentPersistenceManager;

  EnrichmentDefinitionManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
    this.tql2EnrichmentName = new HashMap();
    setEnrichmentPersistenceManager(EnrichmentPersistenceFactory.create(localEnvironment));
  }

  public void startUp() {
    getEnrichmentPersistenceManager().startUp();

    retrieveAndSplitEnrichmentDefinitions();

    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: EnrichmentDefinitionManager is started up properly!!!");
  }

  public void shutdown() {
    getEnrichmentPersistenceManager().shutdown();
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: EnrichmentDefinitionManager is shutdown properly!!!");
  }

  private void mapEnrichmentByTqlName(EnrichmentDefinition enrichmentDefinition) {
    String tqlName = enrichmentDefinition.getTqlName();
    List names = (List)this.tql2EnrichmentName.get(tqlName);
    if (names == null) {
      names = new ArrayList(1);
      names.add(enrichmentDefinition.getEnrichmentName());
      this.tql2EnrichmentName.put(tqlName, names);
    } else {
      names.add(enrichmentDefinition.getEnrichmentName());
    }
  }

  private void unmapEnrichmentByTqlName(EnrichmentDefinition enrichmentDefinition) {
    String tqlName = enrichmentDefinition.getTqlName();
    List names = (List)this.tql2EnrichmentName.get(tqlName);
    if (names != null) {
      names.remove(enrichmentDefinition.getEnrichmentName());
      if (names.isEmpty())
        this.tql2EnrichmentName.remove(tqlName);
    }
  }

  private void onDeactivateEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition)
  {
    List names = (List)this.tql2EnrichmentName.get(enrichmentDefinition.getTqlName());
    if ((!($assertionsDisabled)) && (names == null)) throw new AssertionError();
    if ((!($assertionsDisabled)) && (names.isEmpty())) throw new AssertionError();
    Iterator i$ = names.iterator();
    while (true) { String name;
      while (true) { if (!(i$.hasNext())) break label145; name = (String)i$.next();
        if (!(name.equals(enrichmentDefinition.getEnrichmentName())))
          break;
      }

      EnrichmentDefinition other = getEnrichmentDefinitionByName(name);
      if ((!($assertionsDisabled)) && (other == null)) throw new AssertionError();
      if (other.getIsActive())
        return;

    }

    label145: deactivatePatternByName(enrichmentDefinition.getTqlName());
  }

  private void onActivateEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition) {
    activatePatternByName(enrichmentDefinition.getTqlName());
  }

  private void retrieveAndSplitEnrichmentDefinitions() {
    EnrichmentDefinitions allEnrichmentDefinitions = getAllEnrichmentDefinitions();

    EnrichmentDefinitions enrichmentDefinitions = EnrichmentDefinitionFactory.createEnrichmentDefinitions(String.valueOf(getCustomerID()));
    EnrichmentBusinessViewDefinitions enrichmentBusinessViewDefinitions = EnrichmentBusinessViewDefinitionFactory.createEnrichmentBusinessViewDefinitions(String.valueOf(getCustomerID()));

    ReadOnlyIterator iterDefinitions = allEnrichmentDefinitions.getElementsIterator();
    while (iterDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterDefinitions.next();
      if (enrichmentDefinition.getEnrichmentType() == 1) {
        enrichmentDefinitions.add(enrichmentDefinition);
        mapEnrichmentByTqlName(enrichmentDefinition);
      } else {
        try {
          EnrichmentBusinessViewDefinition enrichmentBusinessViewDefinition = EnrichmentBusinessViewDefinitionFactory.create(enrichmentDefinition);
          enrichmentBusinessViewDefinitions.add(enrichmentBusinessViewDefinition);
        }
        catch (Exception ex) {
          _logger.error(enrichmentDefinition.getEnrichmentName() + " -- " + "Failed to load business view enrichment due to " + ex);
        }
      }
    }
    setEnrichmentDefinitions(enrichmentDefinitions);
    setEnrichmentBusinessViewDefinitions(enrichmentBusinessViewDefinitions);
  }

  public Pattern retrievePatternById(CmdbPatternID patternId)
  {
    TqlQueryGetPattern tqlQueryGetPattern = new TqlQueryGetPattern(patternId, true);
    executeOperation(tqlQueryGetPattern);
    return tqlQueryGetPattern.getPattern();
  }

  public Pattern retrievePatternByName(String patternName)
  {
    TqlQueryGetPattern tqlQueryGetPattern = new TqlQueryGetPattern(patternName, true);
    executeOperation(tqlQueryGetPattern);
    return tqlQueryGetPattern.getPattern();
  }

  public void removePatternByID(CmdbPatternID cmdbPatternID)
  {
    TqlUpdatePatternRemove tqlUpdatePatternRemove = new TqlUpdatePatternRemove(cmdbPatternID);
    executeOperation(tqlUpdatePatternRemove);
  }

  private void deactivatePatternByName(String patternName) {
    TqlQueryGetPattern query = new TqlQueryGetPattern(CmdbPatternIDFactory.createObjectID(patternName), true);
    executeOperation(query);
    Pattern p = query.getPattern();
    if (p == null) {
      _logger.error("Pattern :" + patternName + " doesn't exist in CMDB!");
      return;
    }
    if (!(p.getState().isActive())) {
      _logger.info("Pattern :" + patternName + " is already not active!");
      return;
    }

    ModifiablePattern mp = p.toModifiablePattern();
    mp.setState(PatternDefinitionFactory.createPatternState(p.getState().isPresist(), false, p.getState().getPriority(), p.getState().isNotificationOnly()));

    TqlUpdatePatternUpdate update = new TqlUpdatePatternUpdate(mp);
    executeOperation(update);
  }

  private void activatePatternByName(String patternName) {
    TqlQueryGetPattern query = new TqlQueryGetPattern(CmdbPatternIDFactory.createObjectID(patternName), true);
    executeOperation(query);
    Pattern p = query.getPattern();
    if (p == null) {
      _logger.error("Pattern :" + patternName + " doesn't exist in CMDB!");
      return;
    }
    if (p.getState().isActive()) {
      _logger.info("Pattern :" + patternName + " is already active!");
      return;
    }

    ModifiablePattern mp = p.toModifiablePattern();
    mp.setState(PatternDefinitionFactory.createPatternState(p.getState().isPresist(), true, p.getState().getPriority(), p.getState().isNotificationOnly()));

    TqlUpdatePatternUpdate update = new TqlUpdatePatternUpdate(mp);
    executeOperation(update);
  }

  public EnrichmentDefinition addEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition)
  {
    if (getEnrichmentDefinitions().containsByName(enrichmentDefinition.getEnrichmentName())) {
      throw new EnrichmentValidationException(enrichmentDefinition.getEnrichmentName() + " -- " + "Enrichment definition add failure. " + enrichmentDefinition.getEnrichmentName() + " is already exist", ErrorCode.ALREADY_EXIST_ENRICHMENT);
    }

    EnrichmentMutableDefinition enrichmentMutableDefinition = enrichmentDefinition.toEnrichmentMutableDefinition();
    enrichmentMutableDefinition.setIsCalculated(false);

    addEnrichmentDefinition2Persistency(enrichmentMutableDefinition);

    getEnrichmentDefinitions().add(enrichmentMutableDefinition);
    mapEnrichmentByTqlName(enrichmentDefinition);

    return enrichmentMutableDefinition;
  }

  protected void addEnrichmentDefinition2Persistency(EnrichmentDefinition enrichmentDefinition) {
    getEnrichmentPersistenceManager().addEnrichmentDefinition(enrichmentDefinition);
  }

  public EnrichmentBusinessViewDefinition addEnrichmentDefinition(EnrichmentBusinessViewDefinition enrichmentDefinition)
  {
    if (getEnrichmentBusinessViewDefinitions().containsByName(enrichmentDefinition.getEnrichmentName())) {
      throw new EnrichmentValidationException(enrichmentDefinition.getEnrichmentName() + " -- " + "Enrichment business view definition add failure. " + enrichmentDefinition.getEnrichmentName() + " is already exist", ErrorCode.ALREADY_EXIST_ENRICHMENT);
    }

    getEnrichmentBusinessViewDefinitions().add(enrichmentDefinition);

    addEnrichmentDefinition2Persistency((EnrichmentDefinition)enrichmentDefinition);

    return enrichmentDefinition;
  }

  public EnrichmentDefinition updateEnrichmentDefinitionRoot(EnrichmentDefinition enrichmentDefinition, EnrichmentDefinition enrichmentDefinitionOld) {
    EnrichmentMutableDefinition enrichmentMutableDefinition = enrichmentDefinition.toEnrichmentMutableDefinition();
    enrichmentMutableDefinition.setIsCalculated(false);
    getEnrichmentPersistenceManager().updateEnrichmentDefinitionRoot(enrichmentMutableDefinition, enrichmentDefinitionOld);

    return enrichmentDefinition;
  }

  public EnrichmentDefinition updateEnrichmentDefinitionIsCalculated(EnrichmentDefinition enrichmentDefinition, boolean isCalculated)
  {
    EnrichmentMutableDefinition enrichmentMutableDefinition = enrichmentDefinition.toEnrichmentMutableDefinition();
    enrichmentMutableDefinition.setIsCalculated(isCalculated);
    getEnrichmentDefinitions().set(enrichmentMutableDefinition);

    getEnrichmentPersistenceManager().updateEnrichmentDefinitionRoot(enrichmentMutableDefinition, enrichmentDefinition);

    return enrichmentMutableDefinition;
  }

  public EnrichmentDefinition updateEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition)
  {
    if ((!(getEnrichmentDefinitions().containsByName(enrichmentDefinition.getEnrichmentName()))) && (!(getEnrichmentBusinessViewDefinitions().containsByName(enrichmentDefinition.getEnrichmentName()))))
    {
      throw new EnrichmentValidationException(enrichmentDefinition.getEnrichmentName() + " -- " + "Enrichment definition update failure. " + enrichmentDefinition.getEnrichmentName() + " doesn't exist", ErrorCode.MISSING_ENRICHMENT);
    }

    EnrichmentDefinition enrichmentDefinitionOld = getEnrichmentDefinitionByName(enrichmentDefinition.getEnrichmentName());
    boolean equalsNotAttributeClass = enrichmentDefinition.equalsNotAttributeClass(enrichmentDefinitionOld);
    boolean equalsAttributeClassOnly = enrichmentDefinition.equalsAttributeClassOnly(enrichmentDefinitionOld);

    if ((!(equalsNotAttributeClass)) || (!(equalsAttributeClassOnly)))
    {
      if (!(equalsNotAttributeClass)) {
        removeEnrichmentDefinition(enrichmentDefinition.getEnrichmentName(), false);

        addEnrichmentDefinition2Persistency(enrichmentDefinition);
      }
      if (!(equalsAttributeClassOnly))
      {
        updateEnrichmentDefinitionRoot(enrichmentDefinition, enrichmentDefinitionOld);
      }

      if (getEnrichmentDefinitions().containsByName(enrichmentDefinition.getEnrichmentName()))
        getEnrichmentDefinitions().remove(enrichmentDefinition.getEnrichmentName());

      getEnrichmentDefinitions().add(enrichmentDefinition);

      unmapEnrichmentByTqlName(enrichmentDefinitionOld);
      mapEnrichmentByTqlName(enrichmentDefinition);

      if (enrichmentDefinitionOld.getIsActive()) {
        if (!(enrichmentDefinition.getIsActive()))
          onDeactivateEnrichmentDefinition(enrichmentDefinition);

      }
      else if (enrichmentDefinition.getIsActive())
        onActivateEnrichmentDefinition(enrichmentDefinition);

    }

    return enrichmentDefinition;
  }

  public EnrichmentBusinessViewDefinition updateEnrichmentDefinition(EnrichmentBusinessViewDefinition enrichmentDefinition)
  {
    if (!(getEnrichmentBusinessViewDefinitions().containsByName(enrichmentDefinition.getEnrichmentName()))) {
      throw new EnrichmentValidationException(enrichmentDefinition.getEnrichmentName() + " -- " + "Enrichment business view definition update failure. " + enrichmentDefinition.getEnrichmentName() + " doesn't exist", ErrorCode.MISSING_ENRICHMENT);
    }

    EnrichmentBusinessViewDefinition enrichmentDefinitionOld = getEnrichmentBusinessViewDefinitionByName(enrichmentDefinition.getEnrichmentName());
    boolean equalsNotAttributeClass = ((EnrichmentDefinition)enrichmentDefinition).equalsNotAttributeClass((EnrichmentDefinition)enrichmentDefinitionOld);
    boolean equalsAttributeClassOnly = ((EnrichmentDefinition)enrichmentDefinition).equalsAttributeClassOnly((EnrichmentDefinition)enrichmentDefinitionOld);

    if ((!(equalsNotAttributeClass)) || (!(equalsAttributeClassOnly)))
    {
      if (!(equalsNotAttributeClass)) {
        removeEnrichmentBusinessViewDefinition(enrichmentDefinition.getEnrichmentName(), false);

        addEnrichmentDefinition2Persistency((EnrichmentDefinition)enrichmentDefinition);
      }
      if (!(equalsAttributeClassOnly))
      {
        updateEnrichmentDefinitionRoot((EnrichmentDefinition)enrichmentDefinition, (EnrichmentDefinition)enrichmentDefinitionOld);
      }

      if (getEnrichmentBusinessViewDefinitions().containsByName(enrichmentDefinition.getEnrichmentName()))
        getEnrichmentBusinessViewDefinitions().remove(enrichmentDefinition.getEnrichmentName());

      getEnrichmentBusinessViewDefinitions().add(enrichmentDefinition);
    }
    return enrichmentDefinition;
  }

  public EnrichmentDefinition removeEnrichmentDefinition(String enrichmentName, boolean withRoot)
  {
    if (getEnrichmentDefinitions().containsByName(enrichmentName)) {
      EnrichmentDefinition enrichmentDefinition = getEnrichmentDefinitions().get(enrichmentName);

      getEnrichmentDefinitions().remove(enrichmentName);

      unmapEnrichmentByTqlName(enrichmentDefinition);

      removePersistency(enrichmentName, withRoot);

      return enrichmentDefinition;
    }
    return null;
  }

  protected void removePersistency(String enrichmentName, boolean withRoot) {
    getEnrichmentPersistenceManager().removeEnrichmentDefinition(enrichmentName, withRoot);
  }

  public EnrichmentBusinessViewDefinition removeEnrichmentBusinessViewDefinition(String enrichmentName, boolean withRoot)
  {
    if (getEnrichmentBusinessViewDefinitions().containsByName(enrichmentName)) {
      EnrichmentBusinessViewDefinition enrichmentDefinition = getEnrichmentBusinessViewDefinitions().get(enrichmentName);

      getEnrichmentBusinessViewDefinitions().remove(enrichmentName);

      removePersistency(enrichmentName, withRoot);

      return enrichmentDefinition;
    }
    return null;
  }

  public EnrichmentDefinition getEnrichmentDefinitionByName(String enrichmentName)
  {
    return getEnrichmentDefinitions().get(enrichmentName);
  }

  public EnrichmentBusinessViewDefinition getEnrichmentBusinessViewDefinitionByName(String enrichmentName)
  {
    return getEnrichmentBusinessViewDefinitions().get(enrichmentName);
  }

  public EnrichmentDefinitions retrieveAllEnrichmentDefinitions()
  {
    EnrichmentDefinitions enrichmentDefinitions = retrieveEnrichmentDefinitions();
    EnrichmentBusinessViewDefinitions enrichmentBusinessViewDefinitions = retrieveEnrichmentBusinessViewDefinitions();
    ReadOnlyIterator iterEnrichmentDefinitions = enrichmentBusinessViewDefinitions.getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentBusinessViewDefinition enrichmentDefinition = (EnrichmentBusinessViewDefinition)iterEnrichmentDefinitions.next();
      enrichmentDefinitions.add(enrichmentDefinition);
    }
    return enrichmentDefinitions;
  }

  public EnrichmentDefinitions retrieveEnrichmentDefinitions()
  {
    return ((EnrichmentDefinitions)getEnrichmentDefinitions().clone());
  }

  public EnrichmentBusinessViewDefinitions retrieveEnrichmentBusinessViewDefinitions()
  {
    return ((EnrichmentBusinessViewDefinitions)getEnrichmentBusinessViewDefinitions().clone());
  }

  public EnrichmentBusinessViewDefinition retrieveEnrichmentBusinessViewDefinitionByPatternName(String patternName)
  {
    EnrichmentBusinessViewDefinitions enrichmentDefinitions = retrieveEnrichmentBusinessViewDefinitions();
    ReadOnlyIterator iterEnrichmentDefinitions = enrichmentDefinitions.getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentBusinessViewDefinition enrichmentDefinition = (EnrichmentBusinessViewDefinition)iterEnrichmentDefinitions.next();
      if (enrichmentDefinition.getPatternName().equals(patternName))
        return enrichmentDefinition;
    }

    return null;
  }

  public EnrichmentDefinitions retrieveEnrichmentDefinitionsByPatternId(CmdbPatternID patternId)
  {
    EnrichmentDefinitions enrichmentDefinitions = EnrichmentDefinitionFactory.createEnrichmentDefinitions(String.valueOf(getCustomerID()));
    EnrichmentDefinitions enrichmentDefinitionsAll = getEnrichmentDefinitions();
    ReadOnlyIterator iterEnrichmentDefinitions = enrichmentDefinitionsAll.getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();
      if (enrichmentDefinition.getOriginalPatternId().equals(patternId))
        enrichmentDefinitions.add(enrichmentDefinition);
    }

    return enrichmentDefinitions;
  }

  public EnrichmentDefinitions retrieveEnrichmentDefinitionsAllByPatternId(CmdbPatternID patternId)
  {
    EnrichmentDefinitions enrichmentDefinitions = EnrichmentDefinitionFactory.createEnrichmentDefinitions(String.valueOf(getCustomerID()));
    EnrichmentDefinitions enrichmentDefinitionsAll = retrieveAllEnrichmentDefinitions();
    ReadOnlyIterator iterEnrichmentDefinitions = enrichmentDefinitionsAll.getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();
      if (enrichmentDefinition.getOriginalPatternId().equals(patternId))
        enrichmentDefinitions.add(enrichmentDefinition);
    }

    return enrichmentDefinitions;
  }

  public EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsByPatternId(CmdbPatternID patternId)
  {
    EnrichmentDefinitionsShallow enrichmentDefinitions = EnrichmentDefinitionShallowFactory.createEnrichmentDefinitionsShallow();

    ReadOnlyIterator iterEnrichmentDefinitions = getEnrichmentDefinitions().getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();
      if (enrichmentDefinition.getOriginalPatternId().getPatternName().equals(patternId.getPatternName()))
        enrichmentDefinitions.add(enrichmentDefinition);
    }

    return enrichmentDefinitions;
  }

  public EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsByPatternIds(CmdbPatternIDPropertyValues patternIds)
  {
    EnrichmentDefinitionsShallow enrichmentDefinitions = EnrichmentDefinitionShallowFactory.createEnrichmentDefinitionsShallow();

    ReadOnlyIterator iterPatternIds = patternIds.valuesIterator();
    while (iterPatternIds.hasNext()) {
      CmdbPatternID patternId = (CmdbPatternID)iterPatternIds.next();
      EnrichmentDefinitionsShallow enrichmentDefinitions4PatternId = getShallowEnrichmentDefinitionsByPatternId(patternId);
      ReadOnlyIterator iterEnrichment4PatternId = enrichmentDefinitions4PatternId.getElementsIterator();
      while (iterEnrichment4PatternId.hasNext()) {
        EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichment4PatternId.next();
        if (!(enrichmentDefinitions.containsById(enrichmentDefinition.getEnrichmentId())))
          enrichmentDefinitions.add(enrichmentDefinition);
      }
    }

    return enrichmentDefinitions;
  }

  public EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsUsingClass(String className)
  {
    EnrichmentDefinitionsShallow enrichmentDefinitions = EnrichmentDefinitionShallowFactory.createEnrichmentDefinitionsShallow();

    CmdbClassModel cmdbClassModel = getSynchronizedClassModel();

    ReadOnlyIterator iterEnrichmentDefinitions = getEnrichmentDefinitions().getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();
      try
      {
        CmdbPatternID patternId = enrichmentDefinition.getOriginalPatternId();
        Pattern pattern = retrievePatternById(patternId);
        if (pattern == null) {
          _logger.warn("Pattern " + patternId + " doesn't exist in the repository");
        }
        else if (isEnrichmentDefinitionUsingClass(enrichmentDefinition, className, cmdbClassModel, pattern))
          enrichmentDefinitions.add(enrichmentDefinition);
      }
      catch (Exception e)
      {
        _logger.warn("Failed to determine whether enrichment " + enrichmentDefinition.getEnrichmentName() + " is using class " + className, e);
      }
    }

    return enrichmentDefinitions;
  }

  public EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsUsingValidLinks(CmdbValidLinks validLinks) {
    EnrichmentDefinitionsShallow enrichmentDefinitions = EnrichmentDefinitionShallowFactory.createEnrichmentDefinitionsShallow();

    CmdbClassModel cmdbClassModel = getSynchronizedClassModel();
    CmdbValidLinks validLinksWithoutAncestors = CmdbClassModelUtil.getValidLinksWithoutAncestors(cmdbClassModel, validLinks);

    ReadOnlyIterator iterEnrichmentDefinitions = getEnrichmentDefinitions().getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();

      CmdbPatternID patternId = enrichmentDefinition.getOriginalPatternId();
      Pattern pattern = retrievePatternById(patternId);
      if (pattern == null) {
        _logger.warn("Pattern " + patternId + " doesn't exist in the repository");
      } else {
        ReadOnlyIterator validLinksIterator = validLinksWithoutAncestors.getIterator();
        boolean enrichmentDefAdded = false;
        while ((validLinksIterator.hasNext()) && (!(enrichmentDefAdded))) {
          CmdbValidLink validLink = (CmdbValidLink)validLinksIterator.next();

          if (isEnrichmentDefinitionUsingValidLink(enrichmentDefinition, validLink, cmdbClassModel, pattern))
          {
            enrichmentDefinitions.add(enrichmentDefinition);
            enrichmentDefAdded = true;
          }
        }
      }
    }
    return enrichmentDefinitions;
  }

  public boolean isAnyEnrichmentContainsValidLink(CmdbValidLink cmdbValidLink)
  {
    CmdbClassModel cmdbClassModel = getSynchronizedClassModel();
    boolean contains = false;
    if (CmdbClassModelUtil.isOnlyOneValidLinkExistForCombination(cmdbClassModel, cmdbValidLink.getEnd1ClassName(), cmdbValidLink.getEnd2ClassName(), cmdbValidLink.getLinkClassName()))
    {
      ReadOnlyIterator iterEnrichmentDefinitions = getEnrichmentDefinitions().getElementsIterator();
      while ((iterEnrichmentDefinitions.hasNext()) && (!(contains))) {
        EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();
        try
        {
          CmdbPatternID patternId = enrichmentDefinition.getOriginalPatternId();
          Pattern pattern = retrievePatternById(patternId);
          if (pattern == null) {
            _logger.warn("Pattern " + patternId + " doesn't exist in the repository");
          }
          else if (isEnrichmentDefinitionUsingValidLink(enrichmentDefinition, cmdbValidLink, cmdbClassModel, pattern))
          {
            contains = true;
          }
        }
        catch (Exception e) {
          _logger.warn("Failed to determine whether enrichment " + enrichmentDefinition.getEnrichmentName() + " is using valid link " + cmdbValidLink, e);
        }
      }
    }

    return contains;
  }

  private boolean isEnrichmentDefinitionUsingValidLink(EnrichmentDefinition enrichmentDefinition, CmdbValidLink validLink, CmdbClassModel cmdbClassModel, Pattern pattern) {
    EnrichmentActions enrichmentActions = enrichmentDefinition.getEnrichmentActions();
    ReadOnlyIterator iterActions = enrichmentActions.getEnrichmentLinksIterator();
    while (iterActions.hasNext()) {
      EnrichmentAction enrichmentAction = (EnrichmentAction)iterActions.next();
      EnrichmentLink enrichmentLink = (EnrichmentLink)enrichmentAction;
      String linkClassName = enrichmentLink.getClassName();

      if (isTypeOf(cmdbClassModel, validLink.getLinkClassName(), linkClassName)) {
        PatternElementNumber end1NodeNumber = enrichmentLink.getNodeNumberEnd1();
        PatternElementNumber end2NodeNumber = enrichmentLink.getNodeNumberEnd2();
        String end1ClassName = getNodeNumberObjectClassName(end1NodeNumber, enrichmentDefinition, pattern);
        String end2ClassName = getNodeNumberObjectClassName(end2NodeNumber, enrichmentDefinition, pattern);
        if ((isTypeOf(cmdbClassModel, validLink.getEnd1ClassName(), end1ClassName)) && (isTypeOf(cmdbClassModel, validLink.getEnd2ClassName(), end2ClassName)) && (CmdbClassModelUtil.isOnlyOneValidLinkExistForCombination(cmdbClassModel, end1ClassName, end2ClassName, linkClassName)))
        {
          return true;
        }
      }
    }
    return false;
  }

  private String getNodeNumberObjectClassName(PatternElementNumber end1NodeNumber, EnrichmentDefinition enrichmentDefinition, Pattern pattern)
  {
    String classNodeNumberName;
    if (pattern.getPatternGraph().hasDefinitionElement(end1NodeNumber)) {
      PatternNode patternNode = pattern.getPatternGraph().getNode(end1NodeNumber);
      classNodeNumberName = patternNode.getCondition().getClassCondition().getClassName();
    } else {
      EnrichmentImmutableActions actions = enrichmentDefinition.getEnrichmentActions();
      EnrichmentAction action = actions.getEnrichmentActionByNodeNumber(end1NodeNumber);
      if (action == null)
        throw new IllegalArgumentException("Node number doesn't exist in enrichment and pattern definitions");

      classNodeNumberName = action.getClassName();
    }
    return classNodeNumberName;
  }

  public EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsUsingClasses(CmdbStringPropertyValues classNames)
  {
    EnrichmentDefinitionsShallow enrichmentDefinitions = EnrichmentDefinitionShallowFactory.createEnrichmentDefinitionsShallow();

    ReadOnlyIterator iterClassNames = classNames.valuesIterator();
    while (iterClassNames.hasNext()) {
      String className = (String)iterClassNames.next();
      EnrichmentDefinitionsShallow shalowEnrichmentDefinitions = getShallowEnrichmentDefinitionsUsingClass(className);
      ReadOnlyIterator iterEnrichmentDefinitions4className = shalowEnrichmentDefinitions.getElementsIterator();
      while (iterEnrichmentDefinitions4className.hasNext()) {
        EnrichmentDefinitionShallow shalowEnrichmentDefinition = (EnrichmentDefinitionShallow)iterEnrichmentDefinitions4className.next();
        if (!(enrichmentDefinitions.containsById(shalowEnrichmentDefinition.getEnrichmentId())))
          enrichmentDefinitions.add(shalowEnrichmentDefinition);
      }
    }

    return enrichmentDefinitions;
  }

  private boolean isEnrichmentDefinitionUsingClass(EnrichmentDefinition enrichmentDefinition, String className, CmdbClassModel cmdbClassModel, Pattern pattern)
  {
    EnrichmentActions enrichmentActions = enrichmentDefinition.getEnrichmentActions();
    ReadOnlyIterator iterActions = enrichmentActions.getElementsIterator();
    while (iterActions.hasNext()) {
      EnrichmentAction enrichmentAction = (EnrichmentAction)iterActions.next();

      if (isTypeOf(cmdbClassModel, className, enrichmentAction.getClassName()))
        return true;

      boolean isEnrichmentAttributesUsingClass = isEnrichmentAttributesUsingClass(enrichmentActions, enrichmentAction, className, cmdbClassModel, pattern);

      if (isEnrichmentAttributesUsingClass)
        return true;

    }

    return false;
  }

  private boolean isEnrichmentAttributesUsingClass(EnrichmentActions enrichmentActions, EnrichmentAction enrichmentAction, String className, CmdbClassModel cmdbClassModel, Pattern pattern)
  {
    EnrichmentImmutableAttributes enrichmentAttributes = enrichmentAction.getEnrichmentAttributes();
    if (enrichmentAttributes != null) {
      ReadOnlyIterator iterAttributes = enrichmentAttributes.getElementsIterator();
      while (iterAttributes.hasNext()) {
        EnrichmentAttribute enrichmentAttribute = (EnrichmentAttribute)iterAttributes.next();
        EnrichmentExpression enrichmentExpression = enrichmentAttribute.getEnrichmentExpression();
        EnrichmentComplexOperands enrichmentComplexOperands = enrichmentExpression.getEnrichmentComplexOperands();
        ReadOnlyIterator iterComplexOperands = enrichmentComplexOperands.getElementsIterator();
        while (iterComplexOperands.hasNext()) {
          EnrichmentComplexOperand enrichmentComplexOperand = (EnrichmentComplexOperand)iterComplexOperands.next();
          PatternGraph patternGraph = pattern.getPatternGraph();
          String patternClassName = enrichmentComplexOperand.getClassName(enrichmentActions, patternGraph);

          if (isTypeOf(cmdbClassModel, className, patternClassName))
            return true;
        }
      }
    }

    return false;
  }

  protected boolean isTypeOf(CmdbClassModel cmdbClassModel, String superClassName, String subClassName)
  {
    return cmdbClassModel.isTypeOf(superClassName, subClassName);
  }

  public EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsUsingAttribute(String className, String attributeName)
  {
    EnrichmentDefinitionsShallow enrichmentDefinitions = EnrichmentDefinitionShallowFactory.createEnrichmentDefinitionsShallow();

    CmdbClassModel cmdbClassModel = getSynchronizedClassModel();

    ReadOnlyIterator iterEnrichmentDefinitions = getEnrichmentDefinitions().getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();
      try
      {
        CmdbPatternID patternId = enrichmentDefinition.getOriginalPatternId();
        Pattern pattern = retrievePatternById(patternId);
        if (pattern == null) {
          _logger.warn("Pattern " + patternId + " doesn't exist in the repository");
        }
        else if (isEnrichmentDefinitionUsingAttribute(enrichmentDefinition, className, attributeName, cmdbClassModel, pattern))
        {
          enrichmentDefinitions.add(enrichmentDefinition);
        }
      }
      catch (Exception e) {
        _logger.warn("Failed to determine whether enrichment " + enrichmentDefinition.getEnrichmentName() + " is using attribute " + attributeName + " of class " + className, e);
      }
    }

    return enrichmentDefinitions;
  }

  public EnrichmentDefinitionsShallow getShallowEnrichmentDefinitionsUsingAttributes(String className, CmdbStringPropertyValues attributeNames)
  {
    EnrichmentDefinitionsShallow enrichmentDefinitions = EnrichmentDefinitionShallowFactory.createEnrichmentDefinitionsShallow();

    ReadOnlyIterator iterAttributeNames = attributeNames.valuesIterator();
    while (iterAttributeNames.hasNext()) {
      String attributeName = (String)iterAttributeNames.next();
      EnrichmentDefinitionsShallow shallowEnrichmentDefinitions4Attribute = getShallowEnrichmentDefinitionsUsingAttribute(className, attributeName);
      ReadOnlyIterator iterEnrichmentNames4Attribute = shallowEnrichmentDefinitions4Attribute.getElementsIterator();
      while (iterEnrichmentNames4Attribute.hasNext()) {
        EnrichmentDefinitionShallow enrichmentDefinition4Attribute = (EnrichmentDefinitionShallow)iterEnrichmentNames4Attribute.next();
        if (!(enrichmentDefinitions.containsById(enrichmentDefinition4Attribute.getEnrichmentId())))
          enrichmentDefinitions.add(enrichmentDefinition4Attribute);
      }
    }

    return enrichmentDefinitions;
  }

  public boolean isUpdatePatternValid(Pattern newPattern)
  {
    Pattern oldPattern = retrievePatternById(newPattern.getID());
    if (oldPattern == null)
      throw new IllegalArgumentException("Pattern " + newPattern.getName() + " doesn't exist in the repository");

    EnrichmentDefinitions enrichmentDefinitions = retrieveEnrichmentDefinitionsByPatternId(oldPattern.getID());
    return EnrichmentPatternValidityUtil.isUpdatePatternValid(newPattern, oldPattern, enrichmentDefinitions);
  }

  private boolean isEnrichmentDefinitionUsingAttribute(EnrichmentDefinition enrichmentDefinition, String className, String attributeName, CmdbClassModel cmdbClassModel, Pattern pattern)
  {
    EnrichmentActions enrichmentActions = enrichmentDefinition.getEnrichmentActions();
    ReadOnlyIterator iterActions = enrichmentActions.getElementsIterator();
    while (iterActions.hasNext()) {
      EnrichmentAction enrichmentAction = (EnrichmentAction)iterActions.next();
      boolean isEnrichmentAttributesUsingAttribute = isEnrichmentAttributesUsingAttribute(enrichmentActions, enrichmentAction, className, attributeName, cmdbClassModel, pattern);

      if (isEnrichmentAttributesUsingAttribute)
        return true;
    }

    return false;
  }

  private boolean isEnrichmentAttributesUsingAttribute(EnrichmentActions enrichmentActions, EnrichmentAction enrichmentAction, String className, String attributeName, CmdbClassModel cmdbClassModel, Pattern pattern)
  {
    EnrichmentImmutableAttributes enrichmentAttributes = enrichmentAction.getEnrichmentAttributes();
    if (enrichmentAttributes != null) {
      ReadOnlyIterator iterAttributes = enrichmentAttributes.getElementsIterator();
      while (iterAttributes.hasNext()) {
        EnrichmentAttribute enrichmentAttribute = (EnrichmentAttribute)iterAttributes.next();

        if ((isTypeOf(cmdbClassModel, className, enrichmentAction.getClassName())) && (enrichmentAttribute.getAttributeName().equals(attributeName)))
        {
          return true;
        }
        EnrichmentExpression enrichmentExpression = enrichmentAttribute.getEnrichmentExpression();
        EnrichmentComplexOperands enrichmentComplexOperands = enrichmentExpression.getEnrichmentComplexOperands();
        ReadOnlyIterator iterComplexOperands = enrichmentComplexOperands.getElementsIterator();
        while (iterComplexOperands.hasNext()) {
          EnrichmentComplexOperand enrichmentComplexOperand = (EnrichmentComplexOperand)iterComplexOperands.next();
          String patternClassName = enrichmentComplexOperand.getClassName(enrichmentActions, pattern.getPatternGraph());

          if ((isTypeOf(cmdbClassModel, className, patternClassName)) && (enrichmentComplexOperand.getAttributeName().equals(attributeName)))
          {
            return true;
          }
        }
      }
    }

    return false;
  }

  public EnrichmentDefinitionsShallow getInvalidShallowEnrichmentDefinitions(Pattern newPattern, CmdbEnrichmentID enrichmentId)
  {
    Pattern oldPattern = retrievePatternById(newPattern.getID());
    if (oldPattern == null)
      throw new IllegalArgumentException("Pattern " + newPattern.getName() + " doesn't exist in the repository");

    EnrichmentDefinitionsShallow enrichmentDefinitions = EnrichmentDefinitionShallowFactory.createEnrichmentDefinitionsShallow();
    ReadOnlyIterator iterEnrichmentDefinitions = retrieveEnrichmentDefinitionsByPatternId(oldPattern.getID()).getElementsIterator();
    while (iterEnrichmentDefinitions.hasNext()) {
      EnrichmentDefinition enrichmentDefinition = (EnrichmentDefinition)iterEnrichmentDefinitions.next();
      if (!(enrichmentDefinition.getEnrichmentId().equals(enrichmentId)))
        try {
          enrichmentDefinition.validate(getSynchronizedClassModel(), newPattern);
          if (!(EnrichmentPatternValidityUtil.isUpdatePatternValid4EnrichmentDefinition(enrichmentDefinition, oldPattern, newPattern)))
          {
            enrichmentDefinitions.add(enrichmentDefinition);
          }
        }
        catch (EnrichmentValidationException ex) {
          enrichmentDefinitions.add(enrichmentDefinition);
        }
    }

    return enrichmentDefinitions;
  }

  private EnrichmentDefinitions getEnrichmentDefinitions()
  {
    return this._enrichmentDefinitions;
  }

  private EnrichmentDefinitions getAllEnrichmentDefinitions() {
    return getEnrichmentPersistenceManager().retrieveAllEnrichmentDefinitions();
  }

  protected void setEnrichmentDefinitions(EnrichmentDefinitions enrichmentDefinitions) {
    if (enrichmentDefinitions == null)
      throw new IllegalArgumentException("enrichmentDefinitions can't be null");

    this._enrichmentDefinitions = enrichmentDefinitions;
  }

  private EnrichmentBusinessViewDefinitions getEnrichmentBusinessViewDefinitions() {
    return this._enrichmentBusinessViewDefinitions;
  }

  protected void setEnrichmentBusinessViewDefinitions(EnrichmentBusinessViewDefinitions enrichmentBusinessViewDefinitions) {
    if (enrichmentBusinessViewDefinitions == null)
      throw new IllegalArgumentException("enrichmentBusinessViewDefinitions can't be null");

    this._enrichmentBusinessViewDefinitions = enrichmentBusinessViewDefinitions;
  }

  public EnrichmentPersistenceManager getEnrichmentPersistenceManager() {
    return this._enrichmentPersistenceManager;
  }

  private void setEnrichmentPersistenceManager(EnrichmentPersistenceManager enrichmentPersistenceManager) {
    if (enrichmentPersistenceManager == null)
      throw new IllegalArgumentException("enrichmentPersistenceManager can't be null");

    this._enrichmentPersistenceManager = enrichmentPersistenceManager;
  }

  public String getName() {
    return "Enrichment Definition Task";
  }

  static
  {
    _logger = LogFactory.getEasyLog(EnrichmentDefinitionManagerImpl.class);
  }
}