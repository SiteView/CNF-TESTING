package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddOrUpdateLinks;

public class EnrichmentCreateLinks extends AbstractEnrichmentUpdateLinks
{
  public EnrichmentCreateLinks(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, CmdbLinks links2Create, EnrichmentModelBulkContainer enrichmentModelBulkContainer, Changer changer, long modelChangesChunkSize)
  {
    super(operationExecutor, enrichmentDefinition, links2Create, enrichmentModelBulkContainer, changer, "add ", modelChangesChunkSize);
  }

  protected void addOptimisticModelUpdateOperation() {
    addOptimisticModelUpdateOperation(getLinks());
  }

  protected void addOptimisticModelUpdateOperation(CmdbLinks links) {
    ModelUpdateAddOrUpdateLinks modelUpdateAddOrUpdateLinks = new ModelUpdateAddOrUpdateLinks(links, getChanger());
    getBulkContainer().getModelUpdateBulks().addOptimisticModelUpdateOperation(modelUpdateAddOrUpdateLinks);
  }
}