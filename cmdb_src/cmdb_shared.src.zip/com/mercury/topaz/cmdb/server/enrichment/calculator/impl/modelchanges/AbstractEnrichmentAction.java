package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;

abstract class AbstractEnrichmentAction
{
  protected static Log _logger = LogFactory.getEasyLog(AbstractEnrichmentAction.class);
  protected static Log _enrichmentLogger = LogFactory.getEasyLog("cmdb.enrichment.appender");
  OperationExecutor _operationExecutor;
  private EnrichmentDefinition _enrichmentDefinition;
  private Changer _changer;
  private String _action;
  private long _modelChangesChunkSize;
  private String _type;

  public AbstractEnrichmentAction(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, Changer changer, String action, long modelChangesChunkSize, String type)
  {
    setOperationExecutor(operationExecutor);
    setEnrichmentDefinition(enrichmentDefinition);
    setChanger(changer);
    setAction(action);
    setModelChangesChunkSize(modelChangesChunkSize);
    setType(type); }

  protected abstract boolean isEmpty();

  protected abstract int size();

  protected void executeAsynchronousOperation(FrameworkOperation operation) {
    if (_logger.isDebugEnabled())
      _logger.debug("modelUpdateOperations: " + operation);

    getOperationExecutor().executeAsynchronousOperation(operation);
  }

  protected OperationExecutor getOperationExecutor()
  {
    return this._operationExecutor;
  }

  private void setOperationExecutor(OperationExecutor operationExecutor) {
    this._operationExecutor = operationExecutor;
  }

  protected EnrichmentDefinition getEnrichmentDefinition() {
    return this._enrichmentDefinition;
  }

  private void setEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition) {
    this._enrichmentDefinition = enrichmentDefinition;
  }

  protected Changer getChanger() {
    return this._changer;
  }

  private void setChanger(Changer changer) {
    this._changer = changer;
  }

  protected String getAction() {
    return this._action;
  }

  private void setAction(String action) {
    this._action = action;
  }

  protected long getModelChangesChunkSize() {
    return this._modelChangesChunkSize;
  }

  private void setModelChangesChunkSize(long modelChangesChunkSize) {
    this._modelChangesChunkSize = modelChangesChunkSize;
  }

  protected String getType() {
    return this._type;
  }

  private void setType(String type) {
    this._type = type;
  }
}