package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;

abstract class AbstractEnrichmentUpdate extends AbstractEnrichmentAction
{
  private static Log _logger = LogFactory.getEasyLog(AbstractEnrichmentUpdate.class);
  private static Log _enrichmentLogger = LogFactory.getEasyLog("cmdb.enrichment.appender");
  private EnrichmentModelBulkContainer _enrichmentModelBulkContainer;

  public AbstractEnrichmentUpdate(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, EnrichmentModelBulkContainer enrichmentModelBulkContainer, Changer changer, String action, long modelChangesChunkSize, String type)
  {
    super(operationExecutor, enrichmentDefinition, changer, action, modelChangesChunkSize, type);
    setBulkContainer(enrichmentModelBulkContainer); } 
  protected abstract boolean isEmpty();

  protected abstract int size();

  protected abstract void fillBulkByChunks();

  protected abstract void addOptimisticModelUpdateOperation();

  public EnrichmentModelBulkContainer fillBulk() { long modelChangesChunkSize = getModelChangesChunkSize();
    long currentModelChangesNum = getBulkContainer().getCurrentModelChangesNum();

    if (!(isEmpty())) {
      if (currentModelChangesNum + size() <= modelChangesChunkSize) {
        addOptimisticModelUpdateOperation();
        currentModelChangesNum += size();
        getBulkContainer().setCurrentModelChangesNum(currentModelChangesNum);
      }
      else {
        fillBulkByChunks();
      }
      if (_enrichmentLogger.isInfoEnabled()) {
        String msg = getEnrichmentDefinition().getEnrichmentName() + " -- " + "enrichment definition " + getAction() + size() + getType();

        _enrichmentLogger.info(msg);
      }
    }
    return getBulkContainer();
  }

  protected void updateObjectsAndLinks2Model(ModelUpdateBulksOptimistic modelUpdateBulks) {
    if (_logger.isDebugEnabled())
      _logger.debug("modelUpdateOperations: " + modelUpdateBulks);

    getOperationExecutor().executeAsynchronousOperation(modelUpdateBulks);
  }

  protected EnrichmentModelBulkContainer getBulkContainer()
  {
    return this._enrichmentModelBulkContainer;
  }

  private void setBulkContainer(EnrichmentModelBulkContainer enrichmentModelBulkContainer) {
    this._enrichmentModelBulkContainer = enrichmentModelBulkContainer;
  }
}