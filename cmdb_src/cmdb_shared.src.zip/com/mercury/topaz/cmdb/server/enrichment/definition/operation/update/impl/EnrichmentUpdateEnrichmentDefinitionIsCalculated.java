package com.mercury.topaz.cmdb.server.enrichment.definition.operation.update.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class EnrichmentUpdateEnrichmentDefinitionIsCalculated extends AbstractEnrichmentDefinitionUpdate
{
  private EnrichmentDefinition _enrichmentDefinition;
  private boolean _isCalculated;

  public EnrichmentUpdateEnrichmentDefinitionIsCalculated(EnrichmentDefinition enrichmentDefinition, boolean isCalculated)
  {
    setEnrichmentDefinition(enrichmentDefinition);
    setIsCalculated(isCalculated);
  }

  public String getOperationName()
  {
    return "Enrichment Update: Update enrichment is calculated {EnrichmentDefinition=" + getEnrichmentDefinition() + '}';
  }

  protected void updateValidation(EnrichmentDefinitionManager enrichmentDefinitionManager)
    throws EnrichmentValidationException
  {
  }

  public void doEnrichmentExecute(EnrichmentDefinitionManager enrichmentDefinitionManager, CmdbResponse response)
  {
    EnrichmentDefinition enrichmentDefinition = enrichmentDefinitionManager.updateEnrichmentDefinitionIsCalculated(getEnrichmentDefinition(), getIsCalculated());
    setEnrichmentDefinition(enrichmentDefinition);
  }

  public String getExecutionTaskQueueName()
  {
    return "Enrichment Definition Task";
  }

  public String getShortAuditMessage()
  {
    return "Update " + getEnrichmentDefinition().getEnrichmentName() + " enrichment definition";
  }

  public String getDetailedAuditMessage()
  {
    return "Update " + getEnrichmentDefinition() + " enrichment definition";
  }

  public EnrichmentDefinition getEnrichmentDefinition()
  {
    return this._enrichmentDefinition;
  }

  protected void setEnrichmentDefinition(EnrichmentDefinition enrichmentDefinition) {
    if (enrichmentDefinition == null)
      throw new IllegalArgumentException("Enrichment definition can't be null");

    this._enrichmentDefinition = enrichmentDefinition;
  }

  public boolean getIsCalculated() {
    return this._isCalculated;
  }

  protected void setIsCalculated(boolean isCalculated) {
    this._isCalculated = isCalculated;
  }
}