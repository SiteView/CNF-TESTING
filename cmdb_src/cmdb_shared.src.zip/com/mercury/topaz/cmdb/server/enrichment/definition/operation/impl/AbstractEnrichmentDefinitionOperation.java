package com.mercury.topaz.cmdb.server.enrichment.definition.operation.impl;

import com.mercury.topaz.cmdb.server.enrichment.definition.EnrichmentDefinitionManager;
import com.mercury.topaz.cmdb.server.enrichment.definition.operation.EnrichmentDefinitionOperation;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCmdbOperation;

public abstract class AbstractEnrichmentDefinitionOperation extends AbstractCmdbOperation
  implements EnrichmentDefinitionOperation
{
  protected void doExecute(SubsystemManager manager, CmdbResponse response)
    throws EnrichmentValidationException
  {
    enrichmentExecute((EnrichmentDefinitionManager)manager, response);
  }

  public String getExecutionTaskQueueName()
  {
    return "Enrichment Definition Task";
  }
}