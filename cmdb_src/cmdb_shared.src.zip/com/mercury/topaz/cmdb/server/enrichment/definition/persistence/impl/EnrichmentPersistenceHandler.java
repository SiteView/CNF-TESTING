package com.mercury.topaz.cmdb.server.enrichment.definition.persistence.impl;

import com.mercury.topaz.cmdb.server.resource.impl.AbstractResourcePersistenceHandler;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.common.CmdbMemento;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.memento.impl.EnrichmentDefinitionMementoFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;

class EnrichmentPersistenceHandler extends AbstractResourcePersistenceHandler<EnrichmentDefinition>
{
  protected CmdbMemento getResourceListMemento()
  {
    DataFactory dataFactory = DataFactoryCreator.create(ClassModelProvider.getClassModell());
    return EnrichmentDefinitionMementoFactory.create(dataFactory);
  }

  protected CmdbMemento getResourceMemento() {
    DataFactory dataFactory = DataFactoryCreator.create(ClassModelProvider.getClassModell());
    return EnrichmentDefinitionMementoFactory.create(dataFactory);
  }

  protected Pattern getAllResourcesPattern() {
    return EnrichmentPersistenceUtils.createGetAllEnrichmentsPattern();
  }

  protected PatternLayout getAllResourcesPatternLayout() {
    return EnrichmentPersistenceUtils.createGetAllEnrichmentsLayout();
  }
}