package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddOrUpdateObjects;

public class EnrichmentCreateObjects extends AbstractEnrichmentUpdateObjects
{
  public EnrichmentCreateObjects(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, CmdbObjects objects2Create, EnrichmentModelBulkContainer enrichmentModelBulkContainer, Changer changer, long modelChangesChunkSize)
  {
    super(operationExecutor, enrichmentDefinition, objects2Create, enrichmentModelBulkContainer, changer, "add ", modelChangesChunkSize);
  }

  protected void addOptimisticModelUpdateOperation() {
    addOptimisticModelUpdateOperation(getObjects());
  }

  protected void addOptimisticModelUpdateOperation(CmdbObjects objects) {
    ModelUpdateAddOrUpdateObjects modelUpdateAddOrUpdateObjects = new ModelUpdateAddOrUpdateObjects(objects, getChanger());
    getBulkContainer().getModelUpdateBulks().addOptimisticModelUpdateOperation(modelUpdateAddOrUpdateObjects);
  }
}