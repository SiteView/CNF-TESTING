package com.mercury.topaz.cmdb.server.enrichment.calculator.impl.modelchanges;

import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.update.ModelUpdateObjectsIfExist;

public class EnrichmentUpdateObjects extends AbstractEnrichmentUpdateObjects
{
  public EnrichmentUpdateObjects(OperationExecutor operationExecutor, EnrichmentDefinition enrichmentDefinition, CmdbObjects objects2Update, EnrichmentModelBulkContainer enrichmentModelBulkContainer, Changer changer, long modelChangesChunkSize)
  {
    super(operationExecutor, enrichmentDefinition, objects2Update, enrichmentModelBulkContainer, changer, "update ", modelChangesChunkSize);
  }

  protected void addOptimisticModelUpdateOperation() {
    addOptimisticModelUpdateOperation(getObjects());
  }

  protected void addOptimisticModelUpdateOperation(CmdbObjects objects) {
    ModelUpdateObjectsIfExist modelUpdateObjectsIfExist = new ModelUpdateObjectsIfExist(objects, getChanger());
    getBulkContainer().getModelUpdateBulks().addOptimisticModelUpdateOperation(modelUpdateObjectsIfExist);
  }
}