package com.mercury.topaz.cmdb.server.enrichment.admin.operation.update.impl;

import com.mercury.topaz.cmdb.server.enrichment.admin.EnrichmentAdminManager;
import com.mercury.topaz.cmdb.server.enrichment.admin.operation.impl.AbstractEnrichmentAdminOperation;
import com.mercury.topaz.cmdb.server.enrichment.admin.operation.update.EnrichmentUpdateAdmin;
import com.mercury.topaz.cmdb.shared.enrichment.exception.EnrichmentValidationException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractEnrichmentAdminUpdate extends AbstractEnrichmentAdminOperation
  implements EnrichmentUpdateAdmin
{
  public final void enrichmentExecute(EnrichmentAdminManager enrichmentAdminManager, CmdbResponse response)
    throws EnrichmentValidationException
  {
    doEnrichmentExecute(enrichmentAdminManager, response);
  }

  protected abstract void doEnrichmentExecute(EnrichmentAdminManager paramEnrichmentAdminManager, CmdbResponse paramCmdbResponse)
    throws EnrichmentValidationException;

  protected abstract void updateValidation(EnrichmentAdminManager paramEnrichmentAdminManager)
    throws EnrichmentValidationException;
}