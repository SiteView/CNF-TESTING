package com.mercury.topaz.cmdb.server;

import java.io.PrintWriter;
import java.io.StringWriter;

public class ExceptionUtil
{
  public static String getMessageWithStackTrace(Throwable e, String[] prefix)
  {
    if (null == e)
      return "";
    StringWriter stringWriter = new StringWriter();
    String[] arr$ = prefix; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String prefixI = arr$[i$];
      stringWriter.append(prefixI);
    }
    PrintWriter printWriter = new PrintWriter(stringWriter);
    stringWriter.append(e.getMessage()).append("\n");
    e.printStackTrace(printWriter);

    return stringWriter.getBuffer().toString();
  }
}