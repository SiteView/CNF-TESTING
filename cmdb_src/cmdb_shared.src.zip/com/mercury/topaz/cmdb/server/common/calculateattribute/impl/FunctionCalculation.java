package com.mercury.topaz.cmdb.server.common.calculateattribute.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.common.calculateattribute.AttributeNameList;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.object.layout.ObjectLayout;
import com.mercury.topaz.cmdb.shared.model.object.layout.impl.ObjectLayoutFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.HashMap;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class FunctionCalculation extends AbstractCalculable
{
  private String _function;
  private static Random random = new Random();

  public FunctionCalculation(CmdbClassModel cmdbClassModel, DataFactory dataFactory, String function)
  {
    super(cmdbClassModel, dataFactory);
    this._function = function;
  }

  protected String calculateAttribute(String className, Object cmdbDataOrCmdbProperties, String function, String defaultValue)
  {
    if (function == null)
      return defaultValue;

    if ((cmdbDataOrCmdbProperties == null) || (className == null))
      return function;

    if ((cmdbDataOrCmdbProperties instanceof CmdbData) && (!(className.equals(((CmdbData)cmdbDataOrCmdbProperties).getType())))) {
      throw new IllegalArgumentException("There's a contrudiction between type " + className + " to type in data " + className);
    }

    String value = defaultValue;
    try
    {
      function = clear(function);
      if (isCorrected(function))
      {
        HashMap regExps = new HashMap();
        function = getRegExpFunctions(function, regExps);

        value = calculateAttribute(className, cmdbDataOrCmdbProperties, function, regExps, defaultValue);

        if (value.equals("")) {
          if (_logger.isDebugEnabled())
            _logger.debug("Can not calculate attribute for class: " + className + " by function: " + function + " (probably it is empty)");

          value = defaultValue;
        }

      }
      else if (_logger.isDebugEnabled()) {
        _logger.debug("calculateAttributesOnCreate(CmdbObject, ...). class: " + className + " function is NOT correct: " + function);
      }
    }
    catch (Exception exception)
    {
      if (_logger.isInfoEnabled())
        _logger.info("calculateAttributesOnCreate(CmdbObject, ...). class: " + className + " function: " + function, exception);
    }

    return value;
  }

  public String calculateAttribute(String className, Object cmdbDataOrCmdbProperties, String defaultValue) {
    if (this._function == null)
      return defaultValue;

    if ((cmdbDataOrCmdbProperties == null) || (className == null))
      return this._function;

    if ((cmdbDataOrCmdbProperties instanceof CmdbData) && (!(className.equals(((CmdbData)cmdbDataOrCmdbProperties).getType()))))
    {
      throw new IllegalArgumentException("There's a contrudiction between type " + className + " to type in data " + className);
    }

    String value = defaultValue;
    try
    {
      this._function = clear(this._function);
      if (isCorrected(this._function))
      {
        HashMap regExps = new HashMap();
        this._function = getRegExpFunctions(this._function, regExps);

        value = calculateAttribute(className, cmdbDataOrCmdbProperties, this._function, regExps, defaultValue);

        if (value.equals("")) {
          if (_logger.isDebugEnabled())
            _logger.debug("Can not calculate attribute for class: " + className + " by function: " + this._function + " (probably it is empty)");

          value = defaultValue;
        }
      }
      else if (_logger.isDebugEnabled()) {
        _logger.debug("calculateAttributesOnCreate(CmdbObject, ...). class: " + className + " function is NOT correct: " + this._function);
      }
    }
    catch (Exception exception)
    {
      if (_logger.isInfoEnabled())
        _logger.info("calculateAttributesOnCreate(CmdbObject, ...). class: " + className + " function: " + this._function, exception);
    }

    return value;
  }

  public AttributeNameList getAllUsedAttributes(String className)
  {
    AttributeNameList attributeNameList = AttributeNameListFactory.createCalculatedAttribute();
    if (this._function != null) {
      CmdbAttributes cmdbAttributes = getCmdbClassModel().getClass(className).getAllAttributes();
      ReadOnlyIterator iterAttributes = cmdbAttributes.getIterator();
      while (iterAttributes.hasNext()) {
        CmdbAttribute cmdbAttribute = (CmdbAttribute)iterAttributes.next();
        String attributeName = cmdbAttribute.getName();
        int index = this._function.indexOf(attributeName);
        if ((index != -1) && (isLiterallyEqual(this._function, attributeName)))
          addAttribute(attributeNameList, attributeName);
      }
    }

    return attributeNameList;
  }

  protected ObjectLayout getMissingAttributes(AttributeNameList attributeNameList, Object cmdbDataOrCmdbProperties)
  {
    CmdbProperties cmdbProperties = null;
    if (cmdbDataOrCmdbProperties instanceof CmdbData)
      cmdbProperties = ((CmdbData)cmdbDataOrCmdbProperties).getUnmodifiableProperties();
    else if (cmdbDataOrCmdbProperties instanceof CmdbProperties)
      cmdbProperties = (CmdbProperties)cmdbDataOrCmdbProperties;
    else {
      throw new IllegalArgumentException("...");
    }

    ObjectLayout objectLayout = ObjectLayoutFactory.create();
    ReadOnlyIterator iterAttributes = attributeNameList.getElementsIterator();
    while (iterAttributes.hasNext()) {
      String attrName = (String)iterAttributes.next();
      if ((cmdbProperties.get(attrName) == null) && (!("root_class".equals(attrName))))
      {
        addLayout(objectLayout, attrName);
      }
    }
    return objectLayout;
  }

  private String clear(String function)
  {
    StringBuffer clearFunction = new StringBuffer(50);
    clearFunction.append('(');

    function = function.trim();
    for (int i = 0; i < function.length(); ++i) {
      char ch = function.charAt(i);
      if (ch != '\n') { if (ch == '\t')
          break label63:

        label63: clearFunction.append(ch);
      }
    }
    clearFunction.append(')');
    return clearFunction.toString();
  }

  private boolean isCorrected(String function)
  {
    int openBrackets = 0;
    for (int i = 0; i < function.length(); ++i) {
      char ch = function.charAt(i);

      if (ch == '(') {
        ++openBrackets;
      }
      else if (ch == ')') {
        --openBrackets;
        if (openBrackets < 0)
        {
          return false;
        }
      }
    }

    return (openBrackets == 0);
  }

  private String getRegExpFunctions(String function, HashMap regulerExpressions)
  {
    int index = function.indexOf("RegExp(");
    if (index >= 0) {
      int ob = 0;
      int cb = 0;

      int i = index + "RegExp".length();
      for (; i < function.length(); ++i) {
        char ch = function.charAt(i);
        if (ch == ')') {
          ++cb;
        }
        else if (ch == '(')
          ++ob;

        if (cb == ob)
          break;

      }

      if (cb != ob) {
        throw new IllegalArgumentException("regular expression functoin illegal in " + function);
      }

      String regExp = function.substring(index + "RegExp".length(), i + 1);

      String key = "RegExp" + random.nextFloat();

      function = function.substring(0, index) + '(' + key + ')' + function.substring(i + 1);

      regulerExpressions.put(key, regExp);
      function = getRegExpFunctions(function, regulerExpressions);
    }
    return function;
  }

  private String calculateAttribute(String className, Object cmdbDataOrCmdbProperties, String function, HashMap regExps, String defaultValue)
  {
    int functionLength = function.length();
    if (functionLength <= 0) {
      return "";
    }

    if ((function.charAt(0) == '(') && (function.charAt(functionLength - 1) == ')'))
    {
      function = function.substring(1, functionLength - 1);
    }

    int endExp = function.indexOf(41);
    while (endExp >= 0) {
      int beginExp = function.lastIndexOf(40, endExp);
      String expression = function.substring(beginExp + 1, endExp);

      String calculatedExpression = calculateExpression(className, cmdbDataOrCmdbProperties, regExps, expression, defaultValue);

      function = function.substring(0, beginExp) + calculatedExpression + function.substring(endExp + 1);

      endExp = function.indexOf(41);
    }

    return calculateExpression(className, cmdbDataOrCmdbProperties, regExps, function, defaultValue);
  }

  private String calculateExpression(String className, Object cmdbDataOrCmdbProperties, HashMap regExps, String expression, String defaultValue)
  {
    String orExpression = "";

    StringTokenizer expToken = new StringTokenizer(expression, "|");
    while (expToken.hasMoreTokens()) {
      String subExpression = expToken.nextToken();

      orExpression = orExpression + calculateANDExpression(className, cmdbDataOrCmdbProperties, subExpression, regExps, defaultValue).trim();

      if (!(orExpression.equals("")))
        return orExpression;
    }

    return orExpression;
  }

  private String calculateANDExpression(String className, Object cmdbDataOrCmdbProperties, String expression, HashMap regExps, String defaultValue)
  {
    String result = "";

    if (regExps.get(expression) == null) {
      StringTokenizer addToken = new StringTokenizer(expression, "&");

      while (addToken.hasMoreTokens())
      {
        String fullAttrName = addToken.nextToken();

        int index = fullAttrName.indexOf(46);
        if ((index > 0) && (index < fullAttrName.length()))
        {
          int classNameIndex = fullAttrName.indexOf(className);
          String prefix = "";
          if (classNameIndex > 0) {
            prefix = fullAttrName.substring(0, classNameIndex);
          }

          String attrName = fullAttrName.substring(index + 1);
          if (cmdbDataOrCmdbProperties != null) {
            Object value = getAttributeValue(className, cmdbDataOrCmdbProperties, attrName);
            if (value.equals(attrName)) {
              result = result + fullAttrName;
            }
            else {
              result = result + prefix;
              result = result + value;
            }
          }
          else
          {
            result = result + fullAttrName;
          }
        }
        else
        {
          Object value = getAttributeValue(className, cmdbDataOrCmdbProperties, fullAttrName);
          result = result + value;
        }
      }
    }
    else
    {
      String regExpFunction = (String)regExps.get(expression);
      String truncRegExp = getTruncExpression(regExpFunction);

      String regX = getRegxExpression(regExpFunction);

      int regxgroup = getTruncLength(regExpFunction);
      result = calculateAttribute(className, cmdbDataOrCmdbProperties, truncRegExp, defaultValue);
      if (result.equals(defaultValue))
        result = "";

      result = calculateRegXExpression(result, regX, regxgroup);
    }
    return result;
  }

  private String getTruncExpression(String expression)
  {
    int delIndex = expression.indexOf(",");
    return '(' + expression.substring(1, delIndex).trim() + ')';
  }

  private String getRegxExpression(String expression) {
    int firstDelIndex = expression.indexOf(",");
    int secondDelIndex = expression.lastIndexOf(",");
    return expression.substring(firstDelIndex + 1, secondDelIndex);
  }

  private int getTruncLength(String expression)
  {
    int delIndex = expression.lastIndexOf(",");
    int closedBracketIndex = expression.lastIndexOf(")");
    int length = -1;
    try {
      String lengthStr = expression.substring(delIndex + 1, closedBracketIndex);
      length = Integer.parseInt(lengthStr.trim());
    }
    catch (Exception exception) {
    }
    return length;
  }

  private String calculateRegXExpression(String expression, String regx, int group)
  {
    String result = "";
    if (expression.length() == 0)
      return result;

    try
    {
      Pattern p = Pattern.compile(regx);
      Matcher m = p.matcher(expression);
      boolean b = m.find();
      if (b)
        result = m.group(group);
    }
    catch (PatternSyntaxException e)
    {
      _logger.fatal("calculateRegXExpression failed! ", e);
    }
    return result;
  }

  private boolean isLiterallyEqual(String function, String attributeName)
  {
    int indexStart = function.indexOf(attributeName);
    do {
      int indexEnd = indexStart + attributeName.length();
      if ((((indexStart == 0) || (function.charAt(indexStart - 1) == '|') || (function.charAt(indexStart - 1) == '&') || (function.charAt(indexStart - 1) == ' ') || (function.charAt(indexStart - 1) == '(') || (function.charAt(indexStart - 1) == '.'))) && (((indexEnd == function.length()) || (function.charAt(indexEnd) == '|') || (function.charAt(indexEnd) == '&') || (function.charAt(indexEnd) == ' ') || (function.charAt(indexEnd) == ')') || (function.charAt(indexEnd) == ','))))
      {
        return true;
      }
      indexStart = function.indexOf(attributeName, indexStart + 1); }
    while (indexStart > 0);
    return false;
  }

  private void addAttribute(AttributeNameList attributeNameList, String token) {
    token = getAttrName(token);
    if ((token.length() > 0) && 
      (!(attributeNameList.contains(token))))
      attributeNameList.add(token);
  }

  private String getAttrName(String token)
  {
    int dotIndex = token.indexOf(".");
    if (dotIndex != -1)
      token = token.substring(dotIndex + 1);

    return token;
  }
}