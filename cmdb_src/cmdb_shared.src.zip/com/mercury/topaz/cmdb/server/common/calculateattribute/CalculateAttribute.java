package com.mercury.topaz.cmdb.server.common.calculateattribute;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.common.calculateattribute.CalculateAttributeStatic;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;

public abstract interface CalculateAttribute extends CalculateAttributeStatic
{
  public abstract boolean isCalculateRequired(CmdbData paramCmdbData);

  public abstract void enrichLayoutForClass(String paramString, ElementSimpleLayout paramElementSimpleLayout);

  public abstract ElementSimpleLayout getLayoutForClassAndAttribute(String paramString1, String paramString2);

  public abstract CmdbObjects calculateAttributesOnUpdate(CmdbObjects paramCmdbObjects);

  public abstract CmdbProperties calculateAttributesOnUpdate(CmdbData paramCmdbData1, CmdbData paramCmdbData2);

  public abstract CmdbProperties calculateAttributeOnUpdate(CmdbData paramCmdbData, CmdbAttribute paramCmdbAttribute);

  public abstract CmdbLinks calculateAttributesOnUpdate(CmdbLinks paramCmdbLinks);

  public abstract String calcuateAttribute(String paramString, CmdbProperties paramCmdbProperties, CmdbAttribute paramCmdbAttribute);

  public abstract CmdbProperty createTruncatedProperty(CmdbAttribute paramCmdbAttribute, String paramString);
}