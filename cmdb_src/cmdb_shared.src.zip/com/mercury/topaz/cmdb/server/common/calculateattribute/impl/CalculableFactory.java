package com.mercury.topaz.cmdb.server.common.calculateattribute.impl;

import com.mercury.topaz.cmdb.server.common.calculateattribute.Calculable;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItem;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItems;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;

public class CalculableFactory
{
  public static Calculable createConditionCalculation(CmdbClassModel cmdbClassModel, DataFactory dataFactory, String condition)
  {
    return new ConditionCalculation(cmdbClassModel, dataFactory, condition);
  }

  public static Calculable createFunctionCalculation(CmdbClassModel cmdbClassModel, DataFactory dataFactory, String function) {
    return new FunctionCalculation(cmdbClassModel, dataFactory, function);
  }

  public static Calculable createCalculable(CmdbAttributeQualifier calcAttributeQualifier, CmdbClassModel cmdbClassModel, DataFactory dataFactory) {
    String function = null;
    if (calcAttributeQualifier != null) {
      DataItems dataItems = calcAttributeQualifier.getDataItems();
      DataItem dataItemFunction = dataItems.getDataItemByName("FUNCTION");
      DataItem dataItemPrefix = dataItems.getDataItemByName("PREFIX");
      DataItem dataItemCondition = dataItems.getDataItemByName("CONDITION");
      if (dataItemCondition != null)
        return new ConditionCalculation(cmdbClassModel, dataFactory, (String)dataItemCondition.getValue());

      if (dataItemPrefix != null)
        function = ((String)dataItemPrefix.getValue()) + '|' + dataItemFunction.getValue();
      else
        function = (String)dataItemFunction.getValue();
    }

    return new FunctionCalculation(cmdbClassModel, dataFactory, function);
  }
}