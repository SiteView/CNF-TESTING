package com.mercury.topaz.cmdb.server.common.calculateattribute.impl;

import com.mercury.topaz.cmdb.server.common.calculateattribute.AttributeNameList;
import com.mercury.topaz.cmdb.server.common.calculateattribute.Calculable;
import com.mercury.topaz.cmdb.server.common.calculateattribute.CalculateAttribute;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.common.calculateattribute.impl.AbstractCalculateAttribute;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.object.layout.ObjectLayout;
import com.mercury.topaz.cmdb.shared.model.object.layout.impl.ObjectLayoutFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocGraph;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.EmptyIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

class CalculateAttributeImpl extends AbstractCalculateAttribute
  implements CalculateAttribute
{
  private Map _functionMap;
  protected CmdbSubsystemManager _subsystemManager;

  public CalculateAttributeImpl(CmdbSubsystemManager subsystemManager)
  {
    super(subsystemManager.getSynchronizedClassModel());
    setSubsystemMgr(subsystemManager);
  }

  public CalculateAttributeImpl(CmdbClassModel classModel) {
    super(classModel);
  }

  protected void setSubsystemMgr(CmdbSubsystemManager subsystemManager) {
    if (subsystemManager == null)
      throw new IllegalArgumentException("subsystemManager can't be null");

    this._subsystemManager = subsystemManager;
  }

  protected CmdbSubsystemManager getSubsystemMgr() {
    return this._subsystemManager;
  }

  private void setFunctionMap(Map functionMap) {
    if (functionMap == null)
      throw new IllegalArgumentException("functionMap can't be null");

    this._functionMap = functionMap;
  }

  private Map getFunctionMap() {
    if (this._functionMap == null)
      setFunctionMap(new HashMap());

    return this._functionMap;
  }

  public AttributeNameList getAttributeNameListByCalculable(String className, Calculable calculable) {
    AttributeNameList attributeNameList = (AttributeNameList)getFunctionMap().get(calculable);
    if (attributeNameList == null) {
      attributeNameList = calculable.getAllUsedAttributes(className);
      getFunctionMap().put(calculable, attributeNameList);
    }
    return attributeNameList;
  }

  private List getCalculablesByClass(String className)
  {
    List calculablesList = new ArrayList();
    CmdbAttributes cmdbAttributes = getAttributesWithCalculateAttributeQualifierByClass(className);
    ReadOnlyIterator iterAttributes = cmdbAttributes.getIterator();
    while (iterAttributes.hasNext()) {
      CmdbAttribute cmdbAttribute = (CmdbAttribute)iterAttributes.next();
      Calculable calculable = getCalculableByAttribute(cmdbAttribute);
      if ((calculable != null) && (!(calculablesList.contains(calculable))))
        calculablesList.add(calculable);
    }

    return calculablesList;
  }

  private Calculable getCalculableByClassAndAttribute(String className, String attributeName) {
    CmdbAttribute cmdbAttribute = getCmdbClassModel().getClass(className).getAttributeByName(attributeName);
    Calculable calculable = getCalculableByAttribute(cmdbAttribute);
    return calculable;
  }

  private CmdbAttributes getAttributesWithCalculateAttributeQualifierByClass(String className) {
    CmdbClass cmdbClass = getCmdbClassModel().getClass(className);
    CmdbAttributes cmdbAttributes = cmdbClass.getAttributesByQualifier(CmdbAttributeQualifierDefs.CALCULATED_ATTRIBUTE);
    return cmdbAttributes;
  }

  protected ElementSimpleLayout getAllUsedAttributes(String className)
  {
    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();

    List calculables = getCalculablesByClass(className);
    for (Iterator i$ = calculables.iterator(); i$.hasNext(); ) { Calculable calculable = (Calculable)i$.next();

      AttributeNameList attributeNameList = calculable.getAllUsedAttributes(className);
      ReadOnlyIterator iterAttrNames = attributeNameList.getElementsIterator();
      while (iterAttrNames.hasNext()) {
        String attributeName = (String)iterAttrNames.next();
        if (!(elementSimpleLayout.contains(attributeName)))
          elementSimpleLayout.addKey(attributeName);
      }

    }

    CmdbAttributes cmdbAttributes = getAttributesWithCalculateAttributeQualifierByClass(className);
    ReadOnlyIterator iterCalcAttrs = cmdbAttributes.getIterator();
    while (iterCalcAttrs.hasNext()) {
      CmdbAttribute cmdbAttribute = (CmdbAttribute)iterCalcAttrs.next();
      String attributeName = cmdbAttribute.getName();
      if (!(elementSimpleLayout.contains(attributeName)))
        elementSimpleLayout.addKey(attributeName);
    }

    return elementSimpleLayout;
  }

  protected ElementSimpleLayout getRelevantAttributes(String className, ElementSimpleLayout elementSimpleLayoutIn)
  {
    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();

    CmdbAttributes cmdbAttributes = getAttributesWithCalculateAttributeQualifierByClass(className);
    ReadOnlyIterator iterCalcAttrs = cmdbAttributes.getIterator();
    while (iterCalcAttrs.hasNext()) {
      CmdbAttribute cmdbAttribute = (CmdbAttribute)iterCalcAttrs.next();

      Calculable calculable = getCalculableByAttribute(cmdbAttribute);
      AttributeNameList attributeNameList = calculable.getAllUsedAttributes(className);
      if (doChangedPropertiesInfluenceCalculateAttribute(attributeNameList, elementSimpleLayoutIn))
      {
        ReadOnlyIterator iterAttrNames = attributeNameList.getElementsIterator();
        while (iterAttrNames.hasNext()) {
          attributeName = (String)iterAttrNames.next();
          if (!(elementSimpleLayout.contains(attributeName)))
            elementSimpleLayout.addKey(attributeName);

        }

        String attributeName = cmdbAttribute.getName();
        if (!(elementSimpleLayout.contains(attributeName)))
          elementSimpleLayout.addKey(attributeName);
      }
    }

    return elementSimpleLayout;
  }

  private boolean doChangedPropertiesInfluenceCalculateAttribute(AttributeNameList attributeNameList, ElementSimpleLayout elementSimpleLayoutIn) {
    ReadOnlyIterator iterAttributes = attributeNameList.getElementsIterator();
    while (iterAttributes.hasNext()) {
      String attribute = (String)iterAttributes.next();
      if (elementSimpleLayoutIn.contains(attribute))
        return true;
    }

    return false;
  }

  private boolean isRequiredCalculate(CmdbAttribute cmdbAttribute, CmdbData cmdbData) {
    String className = cmdbData.getType();
    Calculable calculable = getCalculableByAttribute(cmdbAttribute);
    AttributeNameList attributeNameList = calculable.getAllUsedAttributes(className);

    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    ReadOnlyIterator iterProperties = cmdbData.getPropertiesIterator();
    while (iterProperties.hasNext()) {
      String propertyName = ((CmdbProperty)iterProperties.next()).getKey();
      elementSimpleLayout.addKey(propertyName);
    }

    return doChangedPropertiesInfluenceCalculateAttribute(attributeNameList, elementSimpleLayout);
  }

  protected boolean areAttributes4CalculateExist(AttributeNameList attributeNameList, CmdbData cmdbData)
  {
    if (attributeNameList.size() > cmdbData.getPropertiesAmount())
    {
      ReadOnlyIterator iterProperties = cmdbData.getPropertiesIterator();
      while (iterProperties.hasNext()) {
        CmdbProperty cmdbProperty = (CmdbProperty)iterProperties.next();
        if (attributeNameList.contains(cmdbProperty.getKey()))
          return true;
      }

    }
    else
    {
      ReadOnlyIterator iterAttributes = attributeNameList.getElementsIterator();
      while (iterAttributes.hasNext()) {
        String attributeName = (String)iterAttributes.next();
        if (cmdbData.getProperty(attributeName) != null)
          return true;
      }
    }

    return false;
  }

  private void addLayout(ObjectLayout objectLayout, String key) {
    if (!(objectLayout.contains(key)))
      objectLayout.addKey(key);
  }

  protected ObjectLayout getMissingAttributes(AttributeNameList attributeNameList, CmdbData cmdbData)
  {
    ObjectLayout objectLayout = ObjectLayoutFactory.create();
    ReadOnlyIterator iterAttributes = attributeNameList.getElementsIterator();
    while (iterAttributes.hasNext()) {
      String attrName = (String)iterAttributes.next();
      if ((cmdbData.getProperty(attrName) == null) && (!("root_class".equals(attrName))))
        addLayout(objectLayout, attrName);
    }

    return objectLayout;
  }

  protected ObjectLayout getMissingAttributes(AttributeNameList attributeNameList, CmdbProperties cmdbProperties) {
    ObjectLayout objectLayout = ObjectLayoutFactory.create();
    ReadOnlyIterator iterAttributes = attributeNameList.getElementsIterator();
    while (iterAttributes.hasNext()) {
      String attrName = (String)iterAttributes.next();
      if ((cmdbProperties.get(attrName) == null) && (!("root_class".equals(attrName))))
        addLayout(objectLayout, attrName);
    }

    return objectLayout;
  }

  public void enrichLayoutForClass(String className, ElementSimpleLayout elementSimpleLayout) {
    ElementSimpleLayout layoutForAttrCalculation = getRelevantAttributes(className, elementSimpleLayout);
    for (ReadOnlyIterator keyItr = layoutForAttrCalculation.getKeysIterator(); keyItr.hasNext(); )
      elementSimpleLayout.addKey((String)keyItr.next());
  }

  public ElementSimpleLayout getLayoutForClassAndAttribute(String className, String attributeName)
  {
    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();

    elementSimpleLayout.addKey(attributeName);
    Calculable calculable = getCalculableByClassAndAttribute(className, attributeName);
    AttributeNameList attributeNameList = calculable.getAllUsedAttributes(className);
    for (ReadOnlyIterator keyItr = attributeNameList.getElementsIterator(); keyItr.hasNext(); )
      elementSimpleLayout.addKey((String)keyItr.next());

    return elementSimpleLayout;
  }

  public CmdbProperties calculateAttributesOnUpdate(CmdbData cmdbData, CmdbData changedData) {
    CmdbProperties propertiesWithCalculatedAttributes = CmdbPropertyFactory.createProperties();

    CmdbAttributes cmdbAttributes = getAttributesWithCalculateAttributeQualifierByClass(cmdbData.getType());
    ReadOnlyIterator iterAttributes = cmdbAttributes.getIterator();
    while (iterAttributes.hasNext()) {
      CmdbAttribute cmdbAttribute = (CmdbAttribute)iterAttributes.next();
      if (isRequiredCalculate(cmdbAttribute, changedData)) {
        String calculateAttr = calculateAttribute(cmdbData, cmdbAttribute);
        addCalculatedProperty(propertiesWithCalculatedAttributes, EmptyIterator.getInstance(), cmdbAttribute, calculateAttr);
      }
    }
    return propertiesWithCalculatedAttributes;
  }

  public CmdbProperties calculateAttributeOnUpdate(CmdbData cmdbData, CmdbAttribute cmdbAttribute)
  {
    CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();

    String calculateAttr = calculateAttribute(cmdbData, cmdbAttribute);
    CmdbProperty cmdbProperty = createTruncatedProperty(cmdbAttribute, calculateAttr);
    cmdbProperties.add(cmdbProperty);

    return cmdbProperties;
  }

  private String calculateAttribute(CmdbData cmdbData, CmdbAttribute cmdbAttribute)
  {
    String className = cmdbData.getType();
    Calculable calculable = getCalculableByAttribute(cmdbAttribute);

    AttributeNameList attributeNameList = getAttributeNameListByCalculable(className, calculable);
    ObjectLayout objectLayout = getMissingAttributes(attributeNameList, cmdbData);
    if (!(objectLayout.isEmpty()))
      throw new IllegalArgumentException("object/link [" + cmdbData + " ] has no all required properties in order to calculate attributes, needed layout: " + objectLayout);

    String calculateAttr = calculable.calculateAttribute(className, cmdbData, "");
    return calculateAttr;
  }

  public String calcuateAttribute(String className, CmdbProperties properties, CmdbAttribute cmdbAttribute)
  {
    Calculable calculable = getCalculableByAttribute(cmdbAttribute);

    AttributeNameList attributeNameList = getAttributeNameListByCalculable(className, calculable);
    ObjectLayout objectLayout = getMissingAttributes(attributeNameList, properties);
    if (!(objectLayout.isEmpty()))
      throw new IllegalArgumentException("cant calculate attribute " + cmdbAttribute.getName() + "for class " + className + " and properties " + properties + " -   not all required properties exust in order to calculate attributes, needed layout: " + objectLayout);

    String calculateAttr = calculable.calculateAttribute(className, properties, "");
    return calculateAttr;
  }

  public CmdbObjects calculateAttributesOnUpdate(CmdbObjects cmdbObjects)
  {
    if (cmdbObjects == null)
      throw new IllegalArgumentException("cmdbObjects can't be null");

    boolean isCalculateRequired = isCalculateRequired(cmdbObjects.getObjectsIterator());
    if (!(isCalculateRequired))
      return cmdbObjects;

    CmdbObjects cmdbObjectsWithCalculatedAttributes = CmdbObjectFactory.createObjects();
    Map classObject2RetrieveFromDbMap = new HashMap();

    ReadOnlyIterator iterObjects = cmdbObjects.getObjectsIterator();
    while (iterObjects.hasNext()) {
      CmdbObject cmdbObject = (CmdbObject)iterObjects.next();
      String className = cmdbObject.getType();
      CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
      CmdbAttributes cmdbAttributes = getAttributesWithCalculateAttributeQualifierByClass(className);
      ReadOnlyIterator iterAttributes = cmdbAttributes.getIterator();
      while (iterAttributes.hasNext()) {
        CmdbAttribute cmdbAttribute = (CmdbAttribute)iterAttributes.next();
        if (isCalculateRequired(cmdbObject)) {
          recalcCalculateAttr(cmdbProperties, classObject2RetrieveFromDbMap, cmdbObject, cmdbAttribute);
        }
        else
          addObject(cmdbObjectsWithCalculatedAttributes, cmdbObject);
      }

      if (cmdbAttributes.isEmpty()) {
        addObject(cmdbObjectsWithCalculatedAttributes, cmdbObject);
      }
      else if (!(cmdbProperties.isEmpty())) {
        CmdbObject cmdbObjectWithCalculatedAttributes = getDataFactory().restoreObject((CmdbObjectID)cmdbObject.getID(), className, cmdbProperties);
        addObject(cmdbObjectsWithCalculatedAttributes, cmdbObjectWithCalculatedAttributes);
      }

    }

    calculateObjects(cmdbObjectsWithCalculatedAttributes, classObject2RetrieveFromDbMap);

    return cmdbObjectsWithCalculatedAttributes;
  }

  private void recalcCalculateAttr(CmdbProperties cmdbProperties, Map classObject2RetrieveFromDbMap, CmdbObject cmdbObject, CmdbAttribute cmdbAttribute) {
    String className = cmdbObject.getType();
    Calculable calculable = getCalculableByAttribute(cmdbAttribute);
    AttributeNameList attributeNameList = getAttributeNameListByCalculable(className, calculable);
    ObjectLayout objectLayout = getMissingAttributes(attributeNameList, cmdbObject);
    if (objectLayout.isEmpty()) {
      String calculateAttr = calculable.calculateAttribute(className, cmdbObject, "");
      addCalculatedProperty(cmdbProperties, cmdbObject.getPropertiesIterator(), cmdbAttribute, calculateAttr);
    }
    else
    {
      CmdbObjects cmdbObjectsToCalculate = (CmdbObjects)classObject2RetrieveFromDbMap.get(className);
      if (cmdbObjectsToCalculate == null) {
        cmdbObjectsToCalculate = CmdbObjectFactory.createObjects();
        classObject2RetrieveFromDbMap.put(className, cmdbObjectsToCalculate);
      }
      addObject(cmdbObjectsToCalculate, cmdbObject);
    }
  }

  private void calculateObjects(CmdbObjects cmdbObjects, Map classObject2RetrieveFromDbMap)
  {
    Iterator iter = classObject2RetrieveFromDbMap.keySet().iterator();
    while (iter.hasNext()) {
      String className = (String)iter.next();
      CmdbObjects cmdbObjectsToCalculate = (CmdbObjects)classObject2RetrieveFromDbMap.get(className);

      ReadOnlyIterator cmdbObjectsFromDbIter = retrieveObjectsByTql(className, cmdbObjectsToCalculate);

      CmdbObjects cmdbMergedObjects = merge1stTo2nd(cmdbObjectsToCalculate, cmdbObjectsFromDbIter);

      calculateObjects(cmdbObjects, cmdbMergedObjects);
    }
  }

  private void addIds(CmdbObjectIds ids, CmdbObjectID cmdbObjectID) {
    if (!(ids.contains(cmdbObjectID)))
      ids.add(cmdbObjectID);
  }

  private ReadOnlyIterator retrieveObjectsByTql(String className, CmdbObjects cmdbObjectsToCalculate)
  {
    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();

    CmdbObjectIds ids = CmdbObjectIdsFactory.create();
    ReadOnlyIterator iterObjects = cmdbObjectsToCalculate.getObjectsIterator();
    while (iterObjects.hasNext()) {
      CmdbObject cmdbObject = (CmdbObject)iterObjects.next();
      addIds(ids, (CmdbObjectID)cmdbObject.getID());
    }

    PatternElementNumber patternElementNumber = PatternElementNumberFactory.createElementNumber(1);
    ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition(className, false);
    ElementPropertiesCondition propertiesCondition = PatternConditionFactory.createElementPropertiesCondition();
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, propertiesCondition, ids);
    PatternNode patternNode = PatternGraphFactory.createModifiablePatternNode(patternElementNumber, elementCondition, true, null, "calculate attribute");
    patternGraph.addNode(patternNode);

    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("mercury", "calculate attribute", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    ElementSimpleLayout elementSimpleLayout = getAllUsedAttributes(className);
    patternLayout.setElementLayout(patternElementNumber, elementSimpleLayout);

    CmdbGraph cmdbGraph = getAdHocGraph(pattern, patternLayout);
    return cmdbGraph.getObjectsIterator();
  }

  protected CmdbGraph getAdHocGraph(Pattern pattern, PatternLayout patternLayout)
  {
    TqlQueryGetAdHocGraph tqlQueryGetAdHocGraph = new TqlQueryGetAdHocGraph(pattern, patternLayout);
    CmdbSubsystemManager subsystemManager = getSubsystemMgr();
    if (subsystemManager == null)
      throw new IllegalArgumentException("subsystemManager is null. Probably use the inproper CTOR. need CTOR(CmdbSubsystemManager) used CTOR(CmdbClassModel)");

    subsystemManager.executeOperation(tqlQueryGetAdHocGraph);
    CmdbGraph cmdbGraph = tqlQueryGetAdHocGraph.getResultGraph();

    return cmdbGraph;
  }

  public CmdbLinks calculateAttributesOnUpdate(CmdbLinks cmdbLinks)
  {
    boolean isCalculateRequired = isCalculateRequired(cmdbLinks.getLinksIterator());
    if (!(isCalculateRequired))
      return cmdbLinks;

    CmdbLinks cmdbLinksWithCalculatedAttributes = CmdbLinkFactory.createLinks();
    Map classObject2RetrieveFromDbMap = new HashMap();

    ReadOnlyIterator iterLinks = cmdbLinks.getLinksIterator();
    while (iterLinks.hasNext()) {
      CmdbLink cmdbLink = (CmdbLink)iterLinks.next();
      String className = cmdbLink.getType();
      CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
      CmdbAttributes cmdbAttributes = getAttributesWithCalculateAttributeQualifierByClass(className);
      ReadOnlyIterator iterAttributes = cmdbAttributes.getIterator();
      while (iterAttributes.hasNext()) {
        CmdbAttribute cmdbAttribute = (CmdbAttribute)iterAttributes.next();
        if (isCalculateRequired(cmdbLink)) {
          recalcCalculateAttr(cmdbProperties, classObject2RetrieveFromDbMap, cmdbLink, cmdbAttribute);
        }
        else
          addLink(cmdbLinksWithCalculatedAttributes, cmdbLink);
      }

      if (cmdbAttributes.isEmpty()) {
        addLink(cmdbLinksWithCalculatedAttributes, cmdbLink);
      }
      else if (!(cmdbProperties.isEmpty())) {
        CmdbLink cmdbLinkWithCalculatedAttributes = getDataFactory().restoreLink((CmdbLinkID)cmdbLink.getID(), cmdbLink.getType(), cmdbLink.getEnd1(), cmdbLink.getEnd2(), cmdbProperties);
        addLink(cmdbLinksWithCalculatedAttributes, cmdbLinkWithCalculatedAttributes);
      }

    }

    calculateLinks(cmdbLinksWithCalculatedAttributes, classObject2RetrieveFromDbMap);

    return cmdbLinksWithCalculatedAttributes;
  }

  private void recalcCalculateAttr(CmdbProperties cmdbProperties, Map classObject2RetrieveFromDbMap, CmdbLink cmdbLink, CmdbAttribute cmdbAttribute) {
    String className = cmdbLink.getType();

    Calculable calculable = getCalculableByAttribute(cmdbAttribute);
    AttributeNameList attributeNameList = getAttributeNameListByCalculable(className, calculable);
    ObjectLayout objectLayout = getMissingAttributes(attributeNameList, cmdbLink);
    if (objectLayout.isEmpty()) {
      String calculateAttr = calculable.calculateAttribute(className, cmdbLink, "");
      addCalculatedProperty(cmdbProperties, cmdbLink.getPropertiesIterator(), cmdbAttribute, calculateAttr);
    }
    else
    {
      CmdbLinks cmdbLinksToCalculate = (CmdbLinks)classObject2RetrieveFromDbMap.get(className);
      if (cmdbLinksToCalculate == null) {
        cmdbLinksToCalculate = CmdbLinkFactory.createLinks();
        classObject2RetrieveFromDbMap.put(className, cmdbLinksToCalculate);
      }
      addLink(cmdbLinksToCalculate, cmdbLink);
    }
  }

  private void calculateLinks(CmdbLinks cmdbLinks, Map classObject2RetrieveFromDbMap)
  {
    Iterator iter = classObject2RetrieveFromDbMap.keySet().iterator();
    while (iter.hasNext()) {
      String className = (String)iter.next();
      CmdbLinks cmdbLinksToCalculate = (CmdbLinks)classObject2RetrieveFromDbMap.get(className);

      ReadOnlyIterator cmdbLinksFromDbIter = retrieveLinksByTql(className, cmdbLinksToCalculate);

      CmdbLinks cmdbMergedLinks = merge1stTo2nd(cmdbLinksToCalculate, cmdbLinksFromDbIter);

      calculateLinks(cmdbLinks, cmdbMergedLinks);
    }
  }

  private ReadOnlyIterator retrieveLinksByTql(String className, CmdbLinks cmdbLinksToCalculate) {
    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();

    CmdbObjectIds idsEnd1 = CmdbObjectIdsFactory.create();
    CmdbObjectIds idsEnd2 = CmdbObjectIdsFactory.create();
    ReadOnlyIterator iterLinks = cmdbLinksToCalculate.getLinksIterator();
    while (iterLinks.hasNext()) {
      CmdbLink cmdbLink = (CmdbLink)iterLinks.next();
      addIds(idsEnd1, cmdbLink.getEnd1());
      addIds(idsEnd2, cmdbLink.getEnd2());
    }

    PatternElementNumber link = PatternElementNumberFactory.createElementNumber(3);
    ModifiableNodeLinksCondition linksCondition = PatternConditionFactory.createNodeLinksCondition();
    linksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(link.getNumber(), 1, -1));

    PatternElementNumber node1 = PatternElementNumberFactory.createElementNumber(1);
    ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition("object", true);
    ElementPropertiesCondition propertiesCondition = PatternConditionFactory.createElementPropertiesCondition();
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, propertiesCondition, idsEnd1);
    PatternNode patternNode = PatternGraphFactory.createModifiablePatternNode(node1, elementCondition, false, linksCondition, "calculate attribute");
    patternGraph.addNode(patternNode);

    PatternElementNumber node2 = PatternElementNumberFactory.createElementNumber(2);
    elementClassCondition = PatternConditionFactory.createElementClassCondition("object", true);
    elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, propertiesCondition, idsEnd2);
    patternNode = PatternGraphFactory.createModifiablePatternNode(node2, elementCondition, false, linksCondition, "calculate attribute");
    patternGraph.addNode(patternNode);

    elementClassCondition = PatternConditionFactory.createElementClassCondition(className, false);
    elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition);
    PatternLink patternLink = PatternGraphFactory.createModifiablePatternLink(3, 1, 2, elementCondition, true, "calculate attribute");
    patternGraph.addLink(patternLink);

    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("mercury", "calculate attribute", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    ElementSimpleLayout elementSimpleLayout = getAllUsedAttributes(className);
    patternLayout.setElementLayout(link, elementSimpleLayout);

    CmdbGraph cmdbGraph = getAdHocGraph(pattern, patternLayout);
    return cmdbGraph.getLinksIterator();
  }

  private CmdbObjects merge1stTo2nd(CmdbObjects cmdbObjects, ReadOnlyIterator cmdbObjects2Iter) {
    CmdbObjects mergedObjects = CmdbObjectFactory.createObjects();
    while (cmdbObjects2Iter.hasNext()) {
      CmdbObject cmdbObject2 = (CmdbObject)cmdbObjects2Iter.next();
      CmdbObject cmdbObject1 = (CmdbObject)cmdbObjects.get((CmdbDataID)cmdbObject2.getID());
      CmdbObject mergedObject = merge1stTo2nd(cmdbObject1, cmdbObject2);
      mergedObjects.add(mergedObject);
    }
    return mergedObjects;
  }

  private CmdbObject merge1stTo2nd(CmdbObject cmdbObject1, CmdbObject cmdbObject2) {
    CmdbProperties mergedProperties = merge1stTo2nd(cmdbObject1.getPropertiesIterator(), cmdbObject2.getPropertiesIterator());
    CmdbObject mergedObject = getDataFactory().restoreObject((CmdbObjectID)cmdbObject1.getID(), cmdbObject1.getType(), mergedProperties);
    return mergedObject;
  }

  private CmdbLinks merge1stTo2nd(CmdbLinks cmdbLinks1, ReadOnlyIterator cmdbLinks2Iter) {
    CmdbLinks mergedLinks = CmdbLinkFactory.createLinks();
    while (cmdbLinks2Iter.hasNext()) {
      CmdbLink cmdbLink2 = (CmdbLink)cmdbLinks2Iter.next();

      if (cmdbLinks1.contains((CmdbDataID)cmdbLink2.getID())) {
        CmdbLink cmdbLink1 = (CmdbLink)cmdbLinks1.get((CmdbDataID)cmdbLink2.getID());
        CmdbLink mergedLink = merge1stTo2nd(cmdbLink1, cmdbLink2);
        mergedLinks.add(mergedLink);
      }
    }
    return mergedLinks;
  }

  private CmdbLink merge1stTo2nd(CmdbLink cmdbLink1, CmdbLink cmdbLink2) {
    CmdbProperties mergedProperties = merge1stTo2nd(cmdbLink1.getPropertiesIterator(), cmdbLink2.getPropertiesIterator());
    CmdbLink mergedLink = getDataFactory().restoreLink((CmdbLinkID)cmdbLink1.getID(), cmdbLink1.getType(), cmdbLink1.getEnd1(), cmdbLink1.getEnd2(), mergedProperties);
    return mergedLink;
  }

  private CmdbProperties merge1stTo2nd(ReadOnlyIterator cmdbPropertiesIter1, ReadOnlyIterator cmdbPropertiesIter2) {
    CmdbProperty cmdbProperety;
    CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
    while (cmdbPropertiesIter1.hasNext()) {
      cmdbProperety = (CmdbProperty)cmdbPropertiesIter1.next();
      cmdbProperties.add(cmdbProperety);
    }
    while (cmdbPropertiesIter2.hasNext()) {
      cmdbProperety = (CmdbProperty)cmdbPropertiesIter2.next();
      if (!(cmdbProperties.contains(cmdbProperety.getKey())))
        cmdbProperties.add(cmdbProperety);
    }

    return cmdbProperties;
  }

  private boolean isCalculateRequired(ReadOnlyIterator iterDatas)
  {
    while (iterDatas.hasNext()) {
      CmdbData cmdbData = (CmdbData)iterDatas.next();
      if (isCalculateRequired(cmdbData))
        return true;
    }

    return false;
  }

  public boolean isCalculateRequired(CmdbData cmdbData) {
    String className = cmdbData.getType();
    CmdbAttributes cmdbAttributes = getAttributesWithCalculateAttributeQualifierByClass(className);

    List calculables = new ArrayList();
    ReadOnlyIterator iterAttributes = cmdbAttributes.getIterator();
    while (iterAttributes.hasNext()) {
      CmdbAttribute cmdbAttribute = (CmdbAttribute)iterAttributes.next();

      Calculable calculable = getCalculableByAttribute(cmdbAttribute);
      if ((calculable != null) && (!(calculables.contains(calculable)))) {
        calculables.add(calculable);
        AttributeNameList attributeNameList = getAttributeNameListByCalculable(className, calculable);
        if (areAttributes4CalculateExist(attributeNameList, cmdbData))
          return true;
      }

    }

    return false;
  }
}