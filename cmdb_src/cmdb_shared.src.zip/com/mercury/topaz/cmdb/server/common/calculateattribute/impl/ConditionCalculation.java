package com.mercury.topaz.cmdb.server.common.calculateattribute.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.common.calculateattribute.AttributeNameList;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.xml.sax.InputSource;

public class ConditionCalculation extends AbstractCalculable
{
  private static final String ATTR_TAG = "ATTR_NAME";
  private static final String VALUE_TAG = "VALUE";
  private static final String PICTURE_TAG = "PICTURE";
  private String _condition;
  private String _attributeName;
  private Map _properties;

  public ConditionCalculation(CmdbClassModel cmdbClassModel, DataFactory dataFactory, String condition)
  {
    super(cmdbClassModel, dataFactory);
    setCondition(condition);
    setAttributeName("");
    setProperties(new HashMap());
    parseCondition();
  }

  public String calculateAttribute(String className, Object cmdbDataOrCmdbProperties, String defaultValue) {
    Object attributeValue = getAttributeValue(className, cmdbDataOrCmdbProperties, getAttributeName());
    if ((attributeValue != null) && (getProperties().get(attributeValue.toString()) != null))
      return ((String)getProperties().get(attributeValue.toString()));

    return "";
  }

  public AttributeNameList getAllUsedAttributes(String className) {
    AttributeNameList attributeNameList = AttributeNameListFactory.createCalculatedAttribute();
    attributeNameList.add(this._attributeName);
    return attributeNameList;
  }

  private void setCondition(String condition) {
    this._condition = condition;
  }

  private String getCondition() {
    return this._condition;
  }

  private void parseCondition()
  {
    if ((getCondition() != null) && (getCondition().length() > 0)) {
      Document doc;
      try {
        doc = new SAXBuilder().build(new InputSource(new StringReader(getCondition())));
      } catch (Exception e) {
        _logger.error("cannot parse condition " + getCondition(), e);
        return;
      }
      Element rootElement = doc.getRootElement();
      setAttributeName(rootElement.getAttributeValue("ATTR_NAME"));
      List elements = rootElement.getChildren();

      for (Iterator i$ = elements.iterator(); i$.hasNext(); ) { Element element = (Element)i$.next();
        String value = element.getAttributeValue("VALUE");
        String picture = element.getAttributeValue("PICTURE");
        getProperties().put(value, picture);
      }
    }
  }

  public void setAttributeName(String attributeName) {
    this._attributeName = attributeName;
  }

  public String getAttributeName() {
    return this._attributeName;
  }

  public Map getProperties() {
    return this._properties;
  }

  public void setProperties(Map properties) {
    this._properties = properties;
  }
}