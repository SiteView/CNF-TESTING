package com.mercury.topaz.cmdb.server.common.calculateattribute.impl;

import com.mercury.topaz.cmdb.server.common.calculateattribute.CalculateAttribute;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.shared.bean.factory.CmdbImmutableBeanFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;

public class CalculateAttributeFactory extends CmdbImmutableBeanFactory
{
  public static CalculateAttribute createCalculatedAttribute(CmdbSubsystemManager subsystemManager)
  {
    return new CalculateAttributeImpl(subsystemManager);
  }

  public static CalculateAttribute createCalculatedAttribute(CmdbClassModel classModel) {
    return new CalculateAttributeImpl(classModel);
  }
}