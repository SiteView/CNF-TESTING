package com.mercury.topaz.cmdb.server.common.calculateattribute;

import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.List;

public abstract interface AttributeNameList extends List
{
  public abstract void add(String paramString);

  public abstract boolean addAll(AttributeNameList paramAttributeNameList);

  public abstract Object remove(int paramInt);

  public abstract int indexOf(String paramString);

  public abstract ReadOnlyIterator getElementsIterator();

  public abstract boolean isEmpty();

  public abstract int size();

  public abstract boolean contains(String paramString);
}