package com.mercury.topaz.cmdb.server.common.calculateattribute.impl;

import com.mercury.topaz.cmdb.server.common.calculateattribute.AttributeNameList;
import com.mercury.topaz.cmdb.shared.bean.factory.CmdbImmutableBeanFactory;

public class AttributeNameListFactory extends CmdbImmutableBeanFactory
{
  public static AttributeNameList createCalculatedAttribute()
  {
    return new AttributeNameListImpl();
  }
}