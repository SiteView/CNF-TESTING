package com.mercury.topaz.cmdb.server.common.calculateattribute;

public abstract interface Calculable
{
  public abstract String calculateAttribute(String paramString1, Object paramObject, String paramString2);

  public abstract AttributeNameList getAllUsedAttributes(String paramString);
}