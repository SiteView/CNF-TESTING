package com.mercury.topaz.cmdb.server.common.calculateattribute.impl;

import com.mercury.topaz.cmdb.server.common.calculateattribute.AttributeNameList;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.EmptyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.util.ArrayList;

class AttributeNameListImpl extends ArrayList
  implements AttributeNameList
{
  public void add(String attrName)
  {
    super.add(attrName);
  }

  public boolean addAll(AttributeNameList attributeNameList)
  {
    return super.addAll(attributeNameList);
  }

  public Object remove(int index)
  {
    return super.remove(index);
  }

  public int indexOf(String attrName)
  {
    return super.indexOf(attrName);
  }

  public ReadOnlyIterator getElementsIterator()
  {
    if (isEmpty()) {
      return EmptyIterator.getInstance();
    }

    return new ReadOnlyIteratorImpl(iterator());
  }

  public boolean isEmpty()
  {
    return super.isEmpty();
  }

  public int size()
  {
    return super.size();
  }

  public boolean contains(String attrName)
  {
    return super.contains(attrName);
  }
}