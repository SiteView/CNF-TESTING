package com.mercury.topaz.cmdb.server.common.calculateattribute.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.common.calculateattribute.Calculable;
import com.mercury.topaz.cmdb.shared.base.CmdbConstants.Property;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.object.layout.ObjectLayout;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public abstract class AbstractCalculable
  implements Calculable
{
  protected static final String EMPTY = "";
  protected static Log _logger = LogFactory.getEasyLog(AbstractCalculable.class);
  protected CmdbClassModel _cmdbClassModel;
  private DataFactory _dataFactory;

  public AbstractCalculable(CmdbClassModel cmdbClassModel, DataFactory dataFactory)
  {
    setCmdbClassModel(cmdbClassModel);
    setDataFactory(dataFactory);
  }

  private void setCmdbClassModel(CmdbClassModel cmdbClassModel) {
    if (cmdbClassModel == null)
      throw new IllegalArgumentException("cmdbClassModel can't be null");

    this._cmdbClassModel = cmdbClassModel;
  }

  protected CmdbClassModel getCmdbClassModel() {
    return this._cmdbClassModel;
  }

  protected void setDataFactory() {
    if (getCmdbClassModel() == null)
      throw new IllegalArgumentException("cmdbClassModel can't be null");

    this._dataFactory = DataFactoryCreator.create(getCmdbClassModel());
  }

  protected void setDataFactory(DataFactory dataFactory) {
    if (dataFactory == null)
      throw new IllegalArgumentException("dataFactory can't be null");

    this._dataFactory = dataFactory;
  }

  protected DataFactory getDataFactory() {
    return this._dataFactory;
  }

  protected Object getAttributeValue(String className, Object cmdbDataOrCmdbProperties, String attributeName)
  {
    Object value;
    try
    {
      if (attributeName.equals("root_class"))
        return getCmdbClassModel().getClass(className).getDisplayName();

      CmdbAttributeDefinition cmdbAttributeDefinition = null;
      CmdbClass cmdbClass = getCmdbClassModel().getClass(className);
      CmdbAttributes cmdbAttributes = cmdbClass.getAllAttributes();
      ReadOnlyIterator attributesIter = cmdbAttributes.getIterator();
      while (attributesIter.hasNext()) {
        CmdbAttributeDefinition nextAttrDefinition = (CmdbAttributeDefinition)attributesIter.next();
        if (nextAttrDefinition.getName().equals(attributeName.trim())) {
          cmdbAttributeDefinition = nextAttrDefinition;
          break;
        }
      }

      if (cmdbAttributeDefinition != null) {
        value = getProperty(cmdbDataOrCmdbProperties, attributeName);

        if ((value != null) && (!(value.equals(CmdbConstants.Property.EmptyValue)))) break label142;
        return "";
      }

      label142: value = attributeName;
    }
    catch (Exception exception)
    {
      return "";
    }
    return value;
  }

  protected Object getProperty(Object object, String attributeName) {
    if (object instanceof CmdbData)
      return ((CmdbData)object).getProperty(attributeName.trim()).getValue();

    if (((CmdbProperties)object).contains(attributeName.trim()))
      return ((CmdbProperties)object).get(attributeName.trim()).getValue();

    return CmdbConstants.Property.EmptyValue;
  }

  protected void addLayout(ObjectLayout objectLayout, String key) {
    if (!(objectLayout.contains(key)))
      objectLayout.addKey(key);
  }
}