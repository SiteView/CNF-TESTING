package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.lock.ConcurrentReadSingleWrite;
import com.mercury.topaz.cmdb.server.classmodel.ClassModelManager;
import com.mercury.topaz.cmdb.server.classmodel.CmdbModifiableClassModel;
import com.mercury.topaz.cmdb.server.classmodel.CmdbNotifiableClassModel;
import com.mercury.topaz.cmdb.server.dal.dao.CmdbDalClassModelDAO;
import com.mercury.topaz.cmdb.server.dal.dao.impl.CmdbDalDAOFactory;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.ClassModelChangesJMSAdapter;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher.JMSPublisher;
import com.mercury.topaz.cmdb.server.util.CmdbClassModelDefinitionFromResourcesLoader;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.change.id.ChangeListenerID;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModelDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLinks;
import com.mercury.topaz.cmdb.shared.classmodel.change.manage.CmdbClassModelChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.exception.ClassModelException;
import com.mercury.topaz.cmdb.shared.classmodel.exception.ClassModelValidationException;
import com.mercury.topaz.cmdb.shared.classmodel.impl.CmdbClassModelFactory;
import com.mercury.topaz.cmdb.shared.classmodel.impl.CmdbClassTopologicalSort;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDefs;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLinks;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.notification.service.util.ChangesPublisher;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

class ClassModelManagerImpl extends CmdbSubsystemManagerImpl
  implements ClassModelManager, ConcurrentReadSingleWrite
{
  private static Log _logger = LogFactory.getEasyLog(ClassModelManagerImpl.class);
  private static Log _classModelShortAuditLogger = CmdbLogFactory.getClassModelShortAuditLog();
  private CmdbClassModelDelegator _classModelDelegator;
  private final CmdbDalClassModelDAO _classModelDAO;
  private DataFactory _dataFactory;
  private CmdbNotifiableClassModel _temporaryClassModel;
  private CmdbChangeListenerCorseGrained _classModelListenerAdapter;

  public ClassModelManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
    this._classModelDAO = CmdbDalDAOFactory.createClassModelDAO(localEnvironment);
    this._classModelListenerAdapter = createClassModelListenerAdapter(localEnvironment.getCustomerID(), localEnvironment.getGlobalEnvironment().getJmsPublisher());
  }

  private static String getClassModelDeploymentXMLFileName(SettingsReader settingsReader)
  {
    return settingsReader.getTopazHome() + settingsReader.getString("dal.classmodel.deployment.file.name", "/cmdb/classmodel/deployment/classmodel_deployment.xml");
  }

  private static CmdbChangeListenerCorseGrained createClassModelListenerAdapter(CmdbCustomerID customerID, JMSPublisher jmsPublisher)
  {
    return new ClassModelChangesJMSAdapter(customerID, jmsPublisher);
  }

  public synchronized CmdbClassModel getSynchronizedClassModel() {
    return getClassModel();
  }

  public synchronized CmdbNotifiableClassModel getClassModelClone() throws ClassModelException {
    if (this._temporaryClassModel == null)
      this._temporaryClassModel = CmdbModifiableClassModelFactory.createNotifiableClassModel(getUnwrappedClassModel());

    return this._temporaryClassModel;
  }

  public synchronized CmdbClassModel getClassModel()
  {
    return getClassModelDelegator();
  }

  public synchronized CmdbClassModel getClassModelSnapshot() {
    return getUnwrappedClassModel();
  }

  private synchronized CmdbClassModel getUnwrappedClassModel() {
    return getClassModelDelegator().getClassModel();
  }

  public synchronized DataFactory getDataFactory()
  {
    return this._dataFactory;
  }

  public synchronized void commitUpdates()
    throws ClassModelException
  {
    if (!(isClassModelCloneExists())) {
      _logger.warn("commit update was performed on empty class model !!!");
      return;
    }
    CmdbChanges changes = getClassModelClone().getChanges();
    try {
      saveChangesInPersistency(changes, getClassModelDAO(), getClassModelClone());
    } catch (CmdbException e) {
      rollBackUpdates();
      throw e;
    }
    if (!(changes.isEmpty())) {
      setClassModel((CmdbClassModel)getClassModelClone().getDeepReadOnlyCopy());
      print2AuditLog(changes);
    }
    removeClassModelClone();
  }

  /**
   * @deprecated
   */
  public synchronized void commitUpdatesWithoutSavingToPersistency()
    throws ClassModelException
  {
    if (!(isClassModelCloneExists())) {
      _logger.warn("commit update was performed on empty class model !!!");
      return;
    }

    CmdbChanges changes = getClassModelClone().getChanges();
    if (!(changes.isEmpty())) {
      setClassModel((CmdbClassModel)getClassModelClone().getDeepReadOnlyCopy());
      print2AuditLog(changes);
    }
    removeClassModelClone();
  }

  private void print2AuditLog(CmdbChanges changes) {
    _classModelShortAuditLogger.info("The changes in class model are: " + changes);
  }

  private void saveChangesInPersistency(CmdbChanges changes, CmdbDalClassModelDAO classModelDAO, CmdbClassModel classModel) {
    PersistencyHandler persistencyHandler = new PersistencyHandler(classModelDAO, classModel);
    ChangesPublisher.publish(persistencyHandler, changes);
  }

  public void rollBackUpdates()
  {
    removeClassModelClone();
  }

  private synchronized CmdbClassModelDelegator getClassModelDelegator() {
    return this._classModelDelegator;
  }

  private synchronized void setClassModelDelegator(CmdbClassModelDelegator classModelDelegator) {
    this._classModelDelegator = classModelDelegator;
  }

  private synchronized CmdbClassModel loadClassModelFromPersistency() throws ClassModelException {
    CmdbClassModelDefinition classModelDefinition = getClassModelDAO().getClassModelDefinition();
    if (_logger.isInfoEnabled()) {
      _logger.info("class model was loaded from persistency [ number of typedefs: " + classModelDefinition.getAllTypeDefs().getSize() + " ], [ number of classes: " + classModelDefinition.getAllClassDefinitiones().getSize() + " ], [ number of valid links: " + classModelDefinition.getAllValidLinks().getSize() + " ]");
    }

    return CmdbClassModelFactory.createClassModel(classModelDefinition);
  }

  private void recalculateCalculatedValidLinks(CmdbModifiableClassModel modifiableClassModel) {
    ReadOnlyIterator calculatedLinksItr = modifiableClassModel.getAllCalculatedLinks().getIterator();
    while (calculatedLinksItr.hasNext()) {
      CmdbCalculatedLink calculatedLink = (CmdbCalculatedLink)calculatedLinksItr.next();
      CmdbValidLinks calculatedValidLinks = calculatedLink.getCalculatedValidLinks();
      ReadOnlyIterator validLinksItr = calculatedValidLinks.getIterator();
      while (validLinksItr.hasNext())
        modifiableClassModel.addCalculatedValidLink((CmdbValidLink)validLinksItr.next());
    }

    commitUpdates();
  }

  private synchronized void setClassModel(CmdbClassModel classModel) {
    if (getClassModelDelegator() == null) {
      setClassModelDelegator(new CmdbClassModelDelegatorImpl(classModel));
      ClassModelProvider.getInstance(getLocalEnvironment()).setLocalClassModel(getClassModelDelegator());
    } else {
      getClassModelDelegator().setClassModel(classModel);
    }
  }

  public void startUp() {
    CmdbNotificationForbiddenClassesRepositoryHelper.init();
    init();
    CmdbLogFactory.getCMDBInfoLog().info("about to register class model listeners ...");
    registerListener(this._classModelListenerAdapter);
    CmdbLogFactory.getStartupLog().info("Customer [" + getCustomerID() + "]: ClassModel Manager is started up properly !!!");
  }

  public void shutdown() {
    CmdbLogFactory.getCMDBInfoLog().info("about to unregister class model listeners ...");
    unregisterListener(this._classModelListenerAdapter);
    CmdbLogFactory.getStartupLog().info("Customer [" + getCustomerID() + "]: ClassModel Manager is shutdown properly !!!");
  }

  public synchronized void init() {
    removeClassModelClone();
    CmdbClassModel classModel = loadClassModelFromPersistency();
    setClassModel(classModel);
    recalculateCalculatedValidLinks(getClassModelClone());
    setDataFactory(DataFactoryCreator.create(getClassModel()));
    CmdbClasses classes = classModel.getAllClasses();
    if ((classes == null) || (classes.getSize() == 0))
      deployClassModel();
  }

  private synchronized void deployClassModel()
  {
    int numberOfClasses = 0;
    int numberOfValidLinks = 0;
    int numberOfTypeDefs = 0;
    int numberOfCalcLinks = 0;
    try
    {
      CmdbClassModelDefinition classModelDefinitionToDeploy = CmdbClassModelDefinitionFromResourcesLoader.getClassModelDefinition();
      if (classModelDefinitionToDeploy == null) {
        return;
      }

      CmdbTypeDefs typeDefs = classModelDefinitionToDeploy.getAllTypeDefs();
      if (typeDefs != null) {
        numberOfTypeDefs = typeDefs.getSize();
        ReadOnlyIterator typefItr = typeDefs.getIterator();
        while (typefItr.hasNext()) {
          CmdbTypeDef typeDef = (CmdbTypeDef)typefItr.next();
          try {
            getClassModelClone().addTypeDef(typeDef);
          } catch (ClassModelValidationException e) {
            _logger.error("Can't add type definition [" + typeDef.getName() + "] - validation error !!! ", e);
          }
        }
      }

      CmdbClasses cmdbClasses = classModelDefinitionToDeploy.getAllClassDefinitiones();
      if (cmdbClasses != null) {
        numberOfClasses = cmdbClasses.getSize();
        CmdbClasses sortedClasses = getSortedClasses(cmdbClasses);

        ReadOnlyIterator classesItr = sortedClasses.getIterator();
        while (classesItr.hasNext()) {
          CmdbClassDefinition classDefinition = (CmdbClassDefinition)classesItr.next();
          try {
            getClassModelClone().addClass(classDefinition);
          } catch (ClassModelValidationException e) {
            _logger.error("Can't add class [" + classDefinition.getName() + "] - validation error !!!", e);
          }
        }
      }

      CmdbValidLinks validLinks = classModelDefinitionToDeploy.getAllValidLinks();
      if (validLinks != null) {
        numberOfValidLinks = validLinks.getSize();
        ReadOnlyIterator validLinksItr = validLinks.getIterator();
        while (validLinksItr.hasNext()) {
          CmdbValidLink validLink = (CmdbValidLink)validLinksItr.next();
          try {
            getClassModelClone().addValidLink(validLink);
          } catch (ClassModelValidationException e) {
            _logger.error("cannot add valid link: class [" + validLink.getLinkClassName() + "], end1 [" + validLink.getEnd1ClassName() + "], end2 [" + validLink.getEnd2ClassName() + "] - validation error !!!", e);
          }
        }
      }

      CmdbCalculatedLinks calculatedLinks = classModelDefinitionToDeploy.getAllCalculatedLinks();
      if (calculatedLinks != null) {
        numberOfCalcLinks = calculatedLinks.getSize();
        ReadOnlyIterator calcLinksItr = calculatedLinks.getIterator();
        while (calcLinksItr.hasNext()) {
          CmdbCalculatedLink calcLink = (CmdbCalculatedLink)calcLinksItr.next();
          try {
            getClassModelClone().addCalculatedLinkWithClass(calcLink);
            CmdbValidLinks calculatedValidLinks = calcLink.getCalculatedValidLinks();
            ReadOnlyIterator itrCalcValidLinks = calculatedValidLinks.getIterator();
            while (itrCalcValidLinks.hasNext())
              getClassModelClone().addCalculatedValidLink((CmdbValidLink)itrCalcValidLinks.next());
          }
          catch (ClassModelValidationException e) {
            _logger.error("cannot add calculated link [" + calcLink.getName() + "] - validation error !!!", e);
          }
        }
      }
    } catch (RuntimeException e) {
      rollBackUpdates();
      throw e;
    }

    commitUpdates();

    if (_logger.isInfoEnabled())
      _logger.info("deployment of class model was sucessfully finished, there were deployed: " + numberOfTypeDefs + " type defs, " + numberOfClasses + " classes, " + numberOfValidLinks + " valid links");
  }

  private static CmdbClasses getSortedClasses(CmdbClasses unsortedClasses)
  {
    if (!(unsortedClasses.containsClass("root")))
    {
      return unsortedClasses;
    }

    CmdbClassTopologicalSort topologicalSort = new CmdbClassTopologicalSort(unsortedClasses, "none");
    CmdbClasses invalidClasses = topologicalSort.getInvalidClasses();
    if (invalidClasses.getSize() != 0) {
      StringBuffer sb = new StringBuffer("cannot deploy class model: these classes inherit from unknown classes: ");
      ReadOnlyIterator itr = invalidClasses.getIterator();
      while (itr.hasNext()) {
        CmdbClassDefinition classDefinition = (CmdbClassDefinition)itr.next();
        sb.append(classDefinition.getName()).append(", ");
      }
      throw new ClassModelValidationException(sb.toString(), ErrorCode.CLASS_INHERIT_FROM_UNKNOWN_CLASS);
    }
    return topologicalSort.getSortedClasses();
  }

  private synchronized boolean isClassModelCloneExists() {
    return (this._temporaryClassModel != null);
  }

  private synchronized void removeClassModelClone() {
    this._temporaryClassModel = null;
  }

  private synchronized void setDataFactory(DataFactory dataFactory) {
    if (dataFactory == null)
      throw new IllegalArgumentException("data factory is null !!!");

    this._dataFactory = dataFactory;
  }

  public CmdbDalClassModelDAO getClassModelDAO() {
    return this._classModelDAO;
  }

  public String getName()
  {
    return "Class Model Task";
  }

  private static class PersistencyHandler
  implements CmdbClassModelChangeListenerFineGrained
  {
    private CmdbDalClassModelDAO _classModelDAO;
    private CmdbClassModel _classModel;

    public PersistencyHandler(CmdbDalClassModelDAO classModelDAO, CmdbClassModel classModel)
    {
      setClassModelDAO(classModelDAO);
      setClassModel(classModel);
    }

    public void onAddClass(CmdbClassDefinition cmdbClassDefinition) {
      CmdbClass newClass = getClassModel().getClass(cmdbClassDefinition.getName());
      getClassModelDAO().addClass(newClass);
    }

    public void onRemoveClass(CmdbClassDefinition cmdbClass) {
      getClassModelDAO().removeClass(getClassModel().getClass(cmdbClass.getName()));
    }

    public void onUpdateClass(CmdbClassDefinition cmdbClassDefinition) {
      CmdbClass updatedClass = getClassModel().getClass(cmdbClassDefinition.getName());
      getClassModelDAO().updateClass(updatedClass);
    }

    public void onAddValidLink(CmdbValidLink validLink) {
      getClassModelDAO().addValidLink(validLink);
    }

    public void onUpdateValidLink(CmdbValidLink validLink) {
      getClassModelDAO().updateValidLink(validLink);
    }

    public void onRemoveValidLink(CmdbValidLink validLink) {
      getClassModelDAO().removeValidLink(validLink);
    }

    public void onAddTypeDef(CmdbTypeDef typeDef) {
      getClassModelDAO().addTypeDef(typeDef);
    }

    public void onUpdateTypeDef(CmdbTypeDef typeDef) {
      getClassModelDAO().updateTypeDef(typeDef);
    }

    public void onRemoveTypeDef(CmdbTypeDef typeDef) {
      getClassModelDAO().removeTypeDef(typeDef);
    }

    public void onAddCalculatedLink(CmdbCalculatedLink calculatedLink) {
      CmdbClass cmdbClass = getClassModel().getClass(calculatedLink.getName());
      getClassModelDAO().addCalculatedLink(calculatedLink, cmdbClass);
    }

    public void onRemoveCalculatedLink(CmdbCalculatedLink calculatedLink) {
      CmdbClass cmdbClass = getClassModel().getClass(calculatedLink.getName());
      getClassModelDAO().removeCalculatedLink(calculatedLink, cmdbClass);
    }

    public void onUpdateCalculatedLink(CmdbCalculatedLink calculatdLink) {
      getClassModelDAO().updateCalculatedLink(calculatdLink);
    }

    public void onClassesDestinationsConfigChange() {
    }

    public void onAddCalculatedValidLink(CmdbValidLink validLink) {
    }

    public void onRemoveCalculatedValidLink(CmdbValidLink validLink) {
    }

    public void onStartDeployment() {
    }

    public void onFinishDeployment() {
    }

    public FrameworkConstants.Subsystem getSubsystem() {
      throw new UnsupportedOperationException("not supported yet !!!");
    }

    public ChangeListenerID getID() {
      throw new UnsupportedOperationException("not supported yet !!!");
    }

    public CmdbCustomerID getCustomerID() {
      throw new UnsupportedOperationException("not supported yet !!!");
    }

    public void startUp() {
      throw new UnsupportedOperationException("not supported yet !!!");
    }

    public void shutdown() {
      throw new UnsupportedOperationException("not supported yet !!!");
    }

    private CmdbDalClassModelDAO getClassModelDAO() {
      return this._classModelDAO;
    }

    private void setClassModelDAO(CmdbDalClassModelDAO classModelDAO) {
      if (classModelDAO == null)
        throw new IllegalArgumentException("class model DAO is null !!!");

      this._classModelDAO = classModelDAO;
    }

    private CmdbClassModel getClassModel() {
      return this._classModel;
    }

    private void setClassModel(CmdbClassModel classModel) {
      if (classModel == null)
        throw new IllegalArgumentException("class model is null !!!");

      this._classModel = classModel;
    }
  }
}