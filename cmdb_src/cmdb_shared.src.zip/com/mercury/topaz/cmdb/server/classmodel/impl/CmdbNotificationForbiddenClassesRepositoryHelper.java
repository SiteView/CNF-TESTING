package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.infra.utils.environment.Environment;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.exception.ClassModelValidationException;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class CmdbNotificationForbiddenClassesRepositoryHelper
{
  private static Log _logger = LogFactory.getEasyLog(CmdbNotificationForbiddenClassesRepositoryHelper.class);
  public static final String CONFIGURATION_DIRECTORY = "conf" + File.separator;
  public static final String DEFAULT_NOTIFICATION_FORBIDDEN_CLASSES_DEFS_FILE_NAME = "notific-forbidden-classes.xml";
  private static Set<String> _notificationForbiddenClasses;
  private static boolean _isOverride = false;
  private static volatile NotificationForbiddenClassesDef _notificationForbiddenDefs;

  public static void constructNotificationForbiddenClassesRepository(CmdbClassModel classModel)
  {
    expandForbiddenClassesByIsDerived(getNotificationForbiddenDefs(), classModel);
  }

  public static void init()
  {
    String msg;
    if (isOverride())
      return;
    try
    {
      String systemPath = Environment.getInstance().getEnvironmentHomePath() + File.separator + CONFIGURATION_DIRECTORY;
      String fileName = "notific-forbidden-classes.xml";
      File xmlFile = new File(systemPath + fileName);
      FileInputStream fis = new FileInputStream(xmlFile);
      NotificationForbiddenClassesDef defs = (NotificationForbiddenClassesDef)XmlUtils.fromXML(fis, NotificationForbiddenClassesDef.class);
      fis.close();
      setNotificationForbiddenDefs(defs);
    } catch (FileNotFoundException e) {
      msg = "Notification forbiden classes definition file not found: notific-forbidden-classes.xml";
      _logger.warn(msg);
      setNotificationForbiddenDefs(new NotificationForbiddenClassesDef());
    } catch (Exception e) {
      msg = "Notification forbiden classes definition file corrupted: notific-forbidden-classes.xml";
      _logger.error(msg, e);
      setNotificationForbiddenDefs(new NotificationForbiddenClassesDef()); }
  }

  private static void expandForbiddenClassesByIsDerived(NotificationForbiddenClassesDef defs, CmdbClassModel classModel) {
    Iterator forbiddenClassesIt;
    try {
      forbiddenClassesIt = defs.getNotificationForbiddenClasses().iterator();
      HashSet forbiddenClasses = new HashSet();
      while (forbiddenClassesIt.hasNext()) {
        NotificationForbiddenClass forbiddenClass = (NotificationForbiddenClass)forbiddenClassesIt.next();
        String className = forbiddenClass.getClassName();
        forbiddenClasses.add(className);
        try {
          if (forbiddenClass.includeDerivedClasses()) {
            CmdbClasses desClasses = classModel.getAllDescendentClasses(className);
            ReadOnlyIterator desClassesIt = desClasses.getIterator();
            while (desClassesIt.hasNext())
              forbiddenClasses.add(((CmdbClass)desClassesIt.next()).getName());
          }
        }
        catch (ClassModelValidationException e) {
          _logger.error("Notification forbidden class not found in class model: " + className, e);
        }
      }
      if (_logger.isDebugEnabled())
        _logger.debug(" Notification forbidden classes: " + forbiddenClasses.toString());

      setNotificationForbiddenClasses(forbiddenClasses);
    } catch (Exception e) {
      _logger.warn(e);
    }
  }

  public static Set<String> getNotificationForbiddenClasses()
  {
    return _notificationForbiddenClasses;
  }

  private static void setNotificationForbiddenClasses(Set<String> notificationForbiddenClasses) {
    _notificationForbiddenClasses = notificationForbiddenClasses;
  }

  private static NotificationForbiddenClassesDef getNotificationForbiddenDefs() {
    return _notificationForbiddenDefs;
  }

  private static void setNotificationForbiddenDefs(NotificationForbiddenClassesDef notificationForbiddenDefs) {
    _notificationForbiddenDefs = notificationForbiddenDefs;
  }

  public static boolean isNotificationForbiddenClass(String cmdbClassName) {
    return getNotificationForbiddenClasses().contains(cmdbClassName);
  }

  public static void overrideNotificationForbidenClassesDefs(NotificationForbiddenClassesDef def)
  {
    setOverride(true);
    setNotificationForbiddenDefs(def);
  }

  private static boolean isOverride() {
    return _isOverride;
  }

  private static void setOverride(boolean override) {
    _isOverride = override;
  }

  public static class NotificationForbiddenClass
  {
    private String _className;
    private boolean _includeDerivedClasses;

    public String getClassName()
    {
      return this._className;
    }

    public void setClassName(String className) {
      this._className = className;
    }

    public boolean includeDerivedClasses() {
      return this._includeDerivedClasses;
    }

    public void setIncludeDerivedClasses(boolean derived) {
      this._includeDerivedClasses = derived;
    }
  }

  public static class NotificationForbiddenClassesDef
  implements IUnmarshallable, IMarshallable
  {
    private ArrayList<CmdbNotificationForbiddenClassesRepositoryHelper.NotificationForbiddenClass> _notificationForbiddenClasses = new ArrayList();
    public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.shared.classmodel.base.entity.impl.JiBX_bindingFactory|";

    public NotificationForbiddenClassesDef(ArrayList<CmdbNotificationForbiddenClassesRepositoryHelper.NotificationForbiddenClass> notificationForbiddenClasses)
    {
      this._notificationForbiddenClasses = notificationForbiddenClasses;
    }

    public List<CmdbNotificationForbiddenClassesRepositoryHelper.NotificationForbiddenClass> getNotificationForbiddenClasses() {
      return this._notificationForbiddenClasses;
    }
  }
}