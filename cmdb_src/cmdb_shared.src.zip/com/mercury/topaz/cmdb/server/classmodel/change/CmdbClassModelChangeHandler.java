package com.mercury.topaz.cmdb.server.classmodel.change;

import com.mercury.topaz.cmdb.shared.change.CmdbChangeHandler;
import com.mercury.topaz.cmdb.shared.classmodel.change.manage.CmdbClassModelChangeListenerFineGrained;

public abstract interface CmdbClassModelChangeHandler
{
}