package com.mercury.topaz.cmdb.server.classmodel.task;

public class ClassModelTask
{
  public static final String NAME = "Class Model Task";
}