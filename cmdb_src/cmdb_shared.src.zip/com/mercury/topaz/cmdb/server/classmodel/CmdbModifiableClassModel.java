package com.mercury.topaz.cmdb.server.classmodel;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;

public abstract interface CmdbModifiableClassModel
{
  public abstract void setClassesDestinationsConfig(ClassModelDestinationsConfig paramClassModelDestinationsConfig);

  public abstract void addCalculatedValidLink(CmdbValidLink paramCmdbValidLink);

  public abstract void removeCalculatedValidLink(CmdbValidLink paramCmdbValidLink);
}