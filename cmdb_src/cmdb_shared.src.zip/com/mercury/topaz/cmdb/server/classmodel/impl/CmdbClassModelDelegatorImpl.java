package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbNotificationForbiddenClassesRepository;
import com.mercury.topaz.cmdb.shared.classmodel.base.entity.ClassModelEntity;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CalculatedLinkTriplets;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLinks;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.group.CmdbClassGroup;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.group.CmdbClassGroups;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.definition.CmdbMethodQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDefs;
import com.mercury.topaz.cmdb.shared.classmodel.util.tree.CmdbClassTree;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLinks;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.util.timestamp.CmdbTimeStamp;
import java.util.Collection;
import java.util.List;

public class CmdbClassModelDelegatorImpl
  implements CmdbClassModelDelegator, CmdbNotificationForbiddenClassesRepository
{
  private CmdbClassModel _classModel;
  private boolean isOutdated;
  private transient CmdbClassModelDelegator.Updater updater;

  public CmdbClassModelDelegatorImpl(CmdbClassModel classModel)
  {
    this.isOutdated = false;

    setClassModel(classModel);
  }

  public CmdbClassModelDelegatorImpl(CmdbClassModel classModel, CmdbClassModelDelegator.Updater updater) {
    this(classModel);
    this.updater = updater;
  }

  public synchronized void setOutdated() {
    this.isOutdated = true;
  }

  public synchronized CmdbClassModel getClassModel() {
    if ((this.isOutdated) && (this.updater != null)) {
      this._classModel = this.updater.getUpdatedClassModel();
      this.isOutdated = false;
    }
    return this._classModel;
  }

  public synchronized void setClassModel(CmdbClassModel classModel) {
    if (classModel == null)
      throw new IllegalArgumentException("class model is null !!!");

    this._classModel = classModel;
  }

  public boolean isNotificationForbiddenClass(String cmdbClassName) {
    return ((CmdbNotificationForbiddenClassesRepository)getClassModel()).isNotificationForbiddenClass(cmdbClassName);
  }

  public CmdbClasses<CmdbClass> getClassesByQualifier(String qualifierName) {
    return getClassModel().getClassesByQualifier(qualifierName);
  }

  public CmdbClasses<CmdbClass> getAllDescendentClasses(String className) {
    return getClassModel().getAllDescendentClasses(className);
  }

  public CmdbClassQualifierDefs getAllClassQualifierDefs() {
    return getClassModel().getAllClassQualifierDefs();
  }

  public CmdbClassQualifierDefs getAllUserClassQualifierDefs() {
    return getClassModel().getAllUserClassQualifierDefs();
  }

  public CmdbAttributeQualifierDefs getAllAttributeQualifierDefs() {
    return getClassModel().getAllAttributeQualifierDefs();
  }

  public CmdbMethodQualifierDefs getAllMethodQualifierDefs() {
    return getClassModel().getAllMethodQualifierDefs();
  }

  public CmdbClasses<CmdbClassDefinition> getAllClassDefinitiones() {
    return getClassModel().getAllClassDefinitiones();
  }

  public CmdbClasses<CmdbClass> getAllClasses() {
    return getClassModel().getAllClasses();
  }

  public CmdbTimeStamp getCmdbTimeStamp() {
    return getClassModel().getCmdbTimeStamp();
  }

  public boolean isChanged(CmdbTimeStamp classModelTimeStamp) {
    return getClassModel().isChanged(classModelTimeStamp);
  }

  public CmdbClassGroups getAllClassGroups() {
    return getClassModel().getAllClassGroups();
  }

  public CmdbValidLinks getAllValidLinks() {
    return getClassModel().getAllValidLinks();
  }

  public CmdbTypeDefs getAllTypeDefs() {
    return getClassModel().getAllTypeDefs();
  }

  public CmdbCalculatedLinks getAllCalculatedLinks() {
    return getClassModel().getAllCalculatedLinks();
  }

  public ClassModelEntity getDeepReadOnlyCopy() {
    return getClassModel().getDeepReadOnlyCopy();
  }

  public int getHierarchyDistance(String class1Name, String class2Name) {
    return getClassModel().getHierarchyDistance(class1Name, class2Name);
  }

  public CmdbClassTree getClassTree() {
    return getClassModel().getClassTree();
  }

  public CmdbClass getClass(String qualifiedClassName) {
    return getClassModel().getClass(qualifiedClassName);
  }

  public CmdbValidLinks getAllValidLinksByFilter(String linkClassName, boolean isDerivedLink, String end1, boolean isDerivedEnd1, String end2, boolean isDerivedEnd2)
  {
    return getClassModel().getAllValidLinksByFilter(linkClassName, isDerivedLink, end1, isDerivedEnd1, end2, isDerivedEnd2);
  }

  public CmdbValidLinks getAllValidLinks(String end1, String end2) {
    return getClassModel().getAllValidLinks(end1, end2);
  }

  public CmdbValidLinks getAllPossibleValidLinks(String end1, String end2) {
    return getClassModel().getAllPossibleValidLinks(end1, end2);
  }

  public Collection<String> getAllPossibleLinks(String end1, String end2) {
    return getClassModel().getAllPossibleLinks(end1, end2);
  }

  public List<CmdbClass> getCmdbClassAncestors(CmdbClass leafCmdbClass) {
    return getClassModel().getCmdbClassAncestors(leafCmdbClass);
  }

  public boolean isSimpleCalculatedLink(String linkClassName) {
    return getClassModel().isSimpleCalculatedLink(linkClassName);
  }

  public boolean isSimpleCalculatedLink(ElementClassCondition classCondition) {
    return getClassModel().isSimpleCalculatedLink(classCondition);
  }

  public CalculatedLinkTriplets getTripletsForLink(ElementClassCondition classCondition) {
    return getClassModel().getTripletsForLink(classCondition);
  }

  public CmdbValidLinks getAllConcreteValidLinks(String end1, String end2) {
    return getClassModel().getAllConcreteValidLinks(end1, end2);
  }

  public boolean isLinkValid(String linkClassName, String end1, String end2) {
    return getClassModel().isLinkValid(linkClassName, end1, end2);
  }

  public boolean isLinkValidForConcreteLinkType(String linkClassName, String end1, String end2) {
    return getClassModel().isLinkValidForConcreteLinkType(linkClassName, end1, end2);
  }

  public CmdbValidLinks getAllValidLinksForEnd1(String end1) {
    return getClassModel().getAllValidLinksForEnd1(end1);
  }

  public CmdbValidLinks getAllValidLinksForEnd2(String end2) {
    return getClassModel().getAllValidLinksForEnd2(end2);
  }

  public CmdbClassGroup getClassGroup(String groupName) {
    return getClassModel().getClassGroup(groupName);
  }

  public CmdbClassGroups getClassGroups(String className) {
    return getClassModel().getClassGroups(className);
  }

  public CmdbClasses<CmdbClass> getClassesOfNameSpace(String nameSpace) {
    return getClassModel().getClassesOfNameSpace(nameSpace);
  }

  public boolean isDescendant(String superClassName, String subClassName) {
    return getClassModel().isDescendant(superClassName, subClassName);
  }

  public boolean isTypeOf(String superClassName, String subClassName)
  {
    return getClassModel().isTypeOf(superClassName, subClassName);
  }

  public boolean isLeaf(String className)
  {
    return getClassModel().isLeaf(className);
  }

  public CmdbClass resolveCmdbClassDefinition(CmdbClassDefinition cmdbClassDefinition) {
    return getClassModel().resolveCmdbClassDefinition(cmdbClassDefinition);
  }

  public ClassModelDestinationsConfig getClassesDestinationsConfig() {
    return getClassModel().getClassesDestinationsConfig();
  }

  public CmdbValidLinks getCalculatedValidLinks() {
    return getClassModel().getCalculatedValidLinks();
  }

  public boolean equals(Object o)
  {
    if (this == o) return true;
    if (!(o instanceof CmdbClassModelDelegatorImpl)) return false;

    CmdbClassModelDelegatorImpl that = (CmdbClassModelDelegatorImpl)o;

    if (this._classModel != null) if (this._classModel.equals(that._classModel)) break label52; 
    label52: return (that._classModel == null);
  }

  public int hashCode()
  {
    return ((this._classModel != null) ? this._classModel.hashCode() : 0);
  }
}