package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.classmodel.CmdbModifiableClassModel;
import com.mercury.topaz.cmdb.server.classmodel.CmdbModifiableClassModelDefinition;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl.ClassDestinationsConfigFactory;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModelDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.base.entity.ClassModelEntity;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.definition.CmdbMethodQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.exception.ClassModelValidationException;
import com.mercury.topaz.cmdb.shared.classmodel.impl.AbstractClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.impl.CmdbClassModelFactory;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDefs;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbModifiableValidLinks;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLinks;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.impl.CmdbValidLinkFactory;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.definition.CmdbValidLinkQualifierDef;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

class CmdbModifiableClassModelImpl extends AbstractClassModel
  implements CmdbModifiableClassModel
{
  private static Log _logger = LogFactory.getEasyLog(CmdbModifiableClassModelImpl.class);
  private DataFactory _dataFactory;
  private CmdbClassModel _readOnlyClassModel;
  private CmdbModifiableClassModelDefinition _modifiableClassModelDefinition;
  private CmdbModifiableValidLinks _calculatedValidLinks;

  CmdbModifiableClassModelImpl(CmdbClassModel classModel)
  {
    this._readOnlyClassModel = new CmdbClassModelWrapper(this);
    setModifiableClassModelDefinition(new CmdbModifiableClassModelDefinitionImpl(classModel));
    setClassModelDefinition(getModifiableClassModelDefinition().getReadOnlyClassDefinition());
    setMapOfClasses(((AbstractClassModel)classModel).getCloneMapOfClasses());
    setDataFactory(DataFactoryCreator.create(this));
    super.setClassesDestinationsConfig(ClassDestinationsConfigFactory.createModifiableClassesDestinationsConfig(classModel.getClassesDestinationsConfig()));
    setModifiableCalculatedValidLinks(CmdbValidLinkFactory.createValidLinks(classModel.getCalculatedValidLinks()));
    setCalculatedValidLinks(getModifiableCalculatedValidLinks().getReadOnlyValidLinks());
  }

  public CmdbClassModel getReadOnlyClassModel() {
    return this._readOnlyClassModel;
  }

  public ClassModelEntity getDeepReadOnlyCopy() {
    return CmdbClassModelFactory.createReadOnlyClassModel(this);
  }

  public CmdbClassModelDefinition getReadOnlyClassDefinition() {
    return getModifiableClassModelDefinition().getReadOnlyClassDefinition();
  }

  public CmdbClassDefinition updateClass(CmdbClassDefinition cmdbClassDefinition) {
    CmdbClassDefinition updatedClassDefinition = getModifiableClassModelDefinition().updateClass(cmdbClassDefinition);
    if (_logger.isInfoEnabled())
      _logger.info("class: " + updatedClassDefinition.getName() + " was updated !!!");

    CmdbClass updatedClass = createCmdbClass(updatedClassDefinition, getDataFactory());
    addClassToMapOfClasses(updatedClass);
    return updatedClassDefinition;
  }

  public CmdbClassDefinition addOrUpdate(CmdbClassDefinition cmdbClass) {
    return getModifiableClassModelDefinition().addOrUpdate(cmdbClass);
  }

  public CmdbClassDefinition addClass(CmdbClassDefinition cmdbClassDefinition) throws ClassModelValidationException
  {
    if (getClass(cmdbClassDefinition.getName()) != null)
      throw new ClassModelValidationException("class with name: " + cmdbClassDefinition.getName() + " already exists !!!", ErrorCode.CLASS_ALREADY_EXISTS);

    CmdbClass cmdbClass = createCmdbClass(cmdbClassDefinition, getDataFactory());
    addClassToMapOfClasses(cmdbClass);

    CmdbClassDefinition addedClassDefinition = getModifiableClassModelDefinition().addClass(cmdbClassDefinition);
    if (_logger.isInfoEnabled())
      _logger.info("class with name: " + cmdbClassDefinition.getName() + " was added !!!");

    return addedClassDefinition;
  }

  public CmdbClassDefinition removeClass(String qualifiedName) throws ClassModelValidationException {
    if (!(isClassExist(qualifiedName)))
      throw new ClassModelValidationException("cannot remove class: " + qualifiedName + " class doesn't exist !!!", ErrorCode.CLASS_NOT_IN_CLASS_MODEL);

    if (!(isLeaf(qualifiedName)))
      throw new ClassModelValidationException("cannot remove class: " + qualifiedName + " because it is not leaf !!!", ErrorCode.ACTION_NOT_ALLOWED_IF_DESCENDANTS_EXIST);

    deleteClass(qualifiedName);
    CmdbClassDefinition removedClassDefinition = getModifiableClassModelDefinition().removeClass(qualifiedName);
    if (_logger.isInfoEnabled())
      _logger.info("class with name: " + removedClassDefinition.getName() + " was removed !!!");

    return removedClassDefinition;
  }

  public CmdbValidLink addValidLink(CmdbValidLink validLink) throws ClassModelValidationException {
    if (validLink == null)
      throw new IllegalArgumentException("valid link is null !!!");

    if (isValidLinkExist(validLink))
      throw new ClassModelValidationException("cannot add valid link: " + validLink + " - it already exists !!!", ErrorCode.VALIDLINK_ALREADY_EXISTS);

    String error = "";
    if (!(isClassExist(validLink.getLinkClassName())))
    {
      error = error + "link class name [" + validLink.getLinkClassName() + "] doesn't exist ";
    }
    if (!(isClassExist(validLink.getEnd1ClassName())))
    {
      if (error.length() != 0)
        error = error + " , ";

      error = error + "end1 class name [" + validLink.getEnd1ClassName() + "] doesn't exist";
    }
    if (!(isClassExist(validLink.getEnd2ClassName())))
    {
      if (error.length() != 0)
        error = error + " , ";

      error = error + "end2 class name [" + validLink.getEnd2ClassName() + "] doesn't exist";
    }
    CmdbValidLink addedValidLink = getModifiableClassModelDefinition().addValidLink((CmdbValidLink)validLink.getDeepReadOnlyCopy());

    if (error.length() != 0)
      _logger.error("invalid valid link was added. " + validLink + " has these errors: " + error);

    return addedValidLink;
  }

  public CmdbValidLink updateValidLink(CmdbValidLink validLink) throws ClassModelValidationException {
    if (validLink == null)
      throw new IllegalArgumentException("valid link is null !!!");

    if (!(isValidLinkExist(validLink))) {
      throw new ClassModelValidationException("cannot update valid link:" + validLink + " - it doesn't exist !!!", ErrorCode.VALIDLINK_DOESNT_EXIST);
    }

    CmdbValidLink updatedValidLink = getModifiableClassModelDefinition().updateValidLink((CmdbValidLink)validLink.getDeepReadOnlyCopy());

    return updatedValidLink;
  }

  public CmdbValidLink addOrUpdateValidLink(CmdbValidLink validLink) throws ClassModelValidationException {
    if (validLink == null)
      throw new IllegalArgumentException("valid link is null !!!");

    if (isValidLinkExist(validLink))
      return updateValidLink(validLink);

    return addValidLink(validLink);
  }

  private boolean isClassExist(String className)
  {
    return (getClass(className) != null);
  }

  private boolean isValidLinkExist(CmdbValidLink validLink)
  {
    return getModifiableClassModelDefinition().getAllValidLinks().hasValidLink(validLink.getLinkClassName(), validLink.getEnd1ClassName(), validLink.getEnd2ClassName());
  }

  public boolean removeValidLink(CmdbValidLink validLink) throws ClassModelValidationException {
    return getModifiableClassModelDefinition().removeValidLink(validLink);
  }

  public CmdbTypeDef addTypeDef(CmdbTypeDef typeDef) throws ClassModelValidationException {
    if (getModifiableClassModelDefinition().getAllTypeDefs().getCmdbTypeDefByName(typeDef.getName()) != null)
      throw new ClassModelValidationException("cannot add typedef: " + typeDef.getName() + " ,it already exists!!!", ErrorCode.TYPEDEF_ALREADY_EXISTS);

    return getModifiableClassModelDefinition().addTypeDef(typeDef);
  }

  public CmdbTypeDef removeTypeDef(String typeDefName) throws ClassModelValidationException
  {
    CmdbClasses allClasses = getModifiableClassModelDefinition().getAllClassDefinitiones();
    ReadOnlyIterator classesItr = allClasses.getIterator();
    while (classesItr.hasNext()) {
      CmdbClassDefinition classDefinition = (CmdbClassDefinition)classesItr.next();
      CmdbAttributes attributeDefinitins = classDefinition.getClassAttributes();
      if (attributeDefinitins != null) {
        ReadOnlyIterator attrItr = attributeDefinitins.getIterator();
        while (attrItr.hasNext()) {
          CmdbAttributeDefinition attributeDefinition = (CmdbAttributeDefinition)attrItr.next();
          if (typeDefName.equals(attributeDefinition.getType()))
            throw new ClassModelValidationException("cannot remove type def: " + typeDefName + " due to its usage in attribute: " + attributeDefinition.getName() + " in class: " + classDefinition.getName(), ErrorCode.ENUM_IS_IN_USE_CANT_REMOVE);
        }

      }

    }

    CmdbTypeDef removedTypeDef = getModifiableClassModelDefinition().removeTypeDef(typeDefName);
    if (removedTypeDef == null)
      throw new ClassModelValidationException("cannot remove typedef that doesn't exist", ErrorCode.TYPEDEF_DOESNT_EXIST);

    return removedTypeDef;
  }

  public CmdbTypeDef updateTypeDef(CmdbTypeDef typeDef) throws ClassModelValidationException {
    CmdbTypeDef removedTypeDef = getModifiableClassModelDefinition().removeTypeDef(typeDef.getName());
    if (removedTypeDef == null)
      throw new ClassModelValidationException("cannot update typedef that doesn't exist", ErrorCode.TYPEDEF_DOESNT_EXIST);

    return getModifiableClassModelDefinition().addTypeDef(typeDef);
  }

  public void addClassQualifierDef(CmdbClassQualifierDef classQualifier) {
    getModifiableClassModelDefinition().addClassQualifierDef(classQualifier);
  }

  public void addAttributeQualifierDef(CmdbAttributeQualifierDef attributeQualifier) {
    getModifiableClassModelDefinition().addAttributeQualifierDef(attributeQualifier);
  }

  public void addMethodQualifierDef(CmdbMethodQualifierDef methodQualifier) {
    getModifiableClassModelDefinition().addMethodQualifierDef(methodQualifier);
  }

  public void addValidLinkQualifierDef(CmdbValidLinkQualifierDef validLinkQualifier) {
    getModifiableClassModelDefinition().addValidLinkQualifierDef(validLinkQualifier);
  }

  public CmdbCalculatedLink addCalculatedLink(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    return getModifiableClassModelDefinition().addCalculatedLink(calculatedLink);
  }

  public CmdbCalculatedLink addCalculatedLinkWithClass(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    addClass(calculatedLink.getCmdbClass());
    return addCalculatedLink(calculatedLink);
  }

  public CmdbCalculatedLink removeCalculatedLink(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    return getModifiableClassModelDefinition().removeCalculatedLink(calculatedLink);
  }

  public CmdbCalculatedLink removeCalculatedLink(String linkClassName) throws ClassModelValidationException {
    return getModifiableClassModelDefinition().removeCalculatedLink(linkClassName);
  }

  public CmdbCalculatedLink updateCalculatedLink(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    return getModifiableClassModelDefinition().updateCalculatedLink(calculatedLink);
  }

  boolean isClassExists(CmdbClassDefinition cmdbClassDefinition) {
    return isClassExist(cmdbClassDefinition.getName());
  }

  private CmdbModifiableClassModelDefinition getModifiableClassModelDefinition() {
    return this._modifiableClassModelDefinition;
  }

  private void setModifiableClassModelDefinition(CmdbModifiableClassModelDefinition modifiableClassModelDefinition) {
    this._modifiableClassModelDefinition = modifiableClassModelDefinition;
  }

  public DataFactory getDataFactory() {
    return this._dataFactory;
  }

  private void setDataFactory(DataFactory dataFactory) {
    this._dataFactory = dataFactory;
  }

  public void setClassesDestinationsConfig(ClassModelDestinationsConfig config) {
    super.setClassesDestinationsConfig(config);
  }

  public void addCalculatedValidLink(CmdbValidLink calculatedValidLink) {
    getModifiableCalculatedValidLinks().add(calculatedValidLink);
    super.setCalculatedValidLinks(getModifiableCalculatedValidLinks());
  }

  public void removeCalculatedValidLink(CmdbValidLink calculatedValidLink) {
    getModifiableCalculatedValidLinks().removeById(calculatedValidLink);
    super.setCalculatedValidLinks(getModifiableCalculatedValidLinks());
  }

  protected CmdbModifiableValidLinks getModifiableCalculatedValidLinks() {
    return this._calculatedValidLinks;
  }

  protected void setModifiableCalculatedValidLinks(CmdbModifiableValidLinks calculatedValidLinks) {
    this._calculatedValidLinks = calculatedValidLinks;
  }
}