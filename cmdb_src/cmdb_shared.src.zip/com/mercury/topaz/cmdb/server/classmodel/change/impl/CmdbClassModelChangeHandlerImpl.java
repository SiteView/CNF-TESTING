package com.mercury.topaz.cmdb.server.classmodel.change.impl;

import com.mercury.topaz.cmdb.server.classmodel.change.CmdbClassModelChangeHandler;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.change.impl.AbstractCmdbChangeListener;
import com.mercury.topaz.cmdb.shared.change.impl.CmdbChangeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.change.impl.ClassModelChangeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;

public class CmdbClassModelChangeHandlerImpl extends AbstractCmdbChangeListener
  implements CmdbClassModelChangeHandler
{
  private CmdbChanges _changes;

  public CmdbClassModelChangeHandlerImpl()
  {
    super(FrameworkConstants.Subsystem.CLASS_MODEL, null);
    setChanges(CmdbChangeFactory.createCmdbChanges());
  }

  public CmdbChanges getChanges() {
    return this._changes;
  }

  public void clearChanges()
  {
    setChanges(CmdbChangeFactory.createCmdbChanges());
  }

  public void onStartDeployment()
  {
    clearChanges();
  }

  public void onFinishDeployment()
  {
  }

  public void onAddTypeDef(CmdbTypeDef typeDef)
  {
    getChanges().add(ClassModelChangeFactory.createAddTypeDefChange(typeDef));
  }

  public void onUpdateTypeDef(CmdbTypeDef typeDef) {
    getChanges().add(ClassModelChangeFactory.createUpdateTypeDefChange(typeDef));
  }

  public void onRemoveTypeDef(CmdbTypeDef typeDef) {
    getChanges().add(ClassModelChangeFactory.createRemoveTypeDefChange(typeDef));
  }

  public void onAddCalculatedLink(CmdbCalculatedLink calculatedLink) {
    getChanges().add(ClassModelChangeFactory.createAddCalculatedLinkChange(calculatedLink));
  }

  public void onRemoveCalculatedLink(CmdbCalculatedLink calculatedLink) {
    getChanges().add(ClassModelChangeFactory.createRemoveCalculatedLinkChange(calculatedLink));
  }

  public void onUpdateCalculatedLink(CmdbCalculatedLink calculatdLink) {
    getChanges().add(ClassModelChangeFactory.createUpdateCalculatedLinkChange(calculatdLink));
  }

  public void onAddClass(CmdbClassDefinition cmdbClass) {
    getChanges().add(ClassModelChangeFactory.createAddClassChange(cmdbClass));
  }

  public void onRemoveClass(CmdbClassDefinition cmdbClass) {
    getChanges().add(ClassModelChangeFactory.createRemoveClassChange(cmdbClass));
  }

  public void onUpdateClass(CmdbClassDefinition cmdbClass) {
    getChanges().add(ClassModelChangeFactory.createUpdateClassChange(cmdbClass));
  }

  public void onAddValidLink(CmdbValidLink validLink) {
    getChanges().add(ClassModelChangeFactory.createAddValidLinkChange(validLink));
  }

  public void onUpdateValidLink(CmdbValidLink validLink) {
    getChanges().add(ClassModelChangeFactory.createUpdateValidLinkChange(validLink));
  }

  public void onRemoveValidLink(CmdbValidLink validLink) {
    getChanges().add(ClassModelChangeFactory.createRemoveValidLinkChange(validLink));
  }

  public void onClassesDestinationsConfigChange() {
    getChanges().add(ClassModelChangeFactory.createClassesDestinationsConfigChange());
  }

  public void onAddCalculatedValidLink(CmdbValidLink validLink) {
    getChanges().add(ClassModelChangeFactory.createAddCalculatedValidLinkChange(validLink));
  }

  public void onRemoveCalculatedValidLink(CmdbValidLink validLink) {
    getChanges().add(ClassModelChangeFactory.createRemoveCalculatedValidLinkChange(validLink));
  }

  private void setChanges(CmdbChanges changes) {
    this._changes = changes;
  }
}