package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;

public abstract interface CmdbClassModelDelegator extends CmdbClassModel
{
  public abstract void setClassModel(CmdbClassModel paramCmdbClassModel);

  public abstract CmdbClassModel getClassModel();

  public abstract void setOutdated();

  public static abstract interface Updater
  {
    public abstract CmdbClassModel getUpdatedClassModel();
  }
}