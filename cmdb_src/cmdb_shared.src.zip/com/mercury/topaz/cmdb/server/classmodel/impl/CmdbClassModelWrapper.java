package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.base.entity.ClassModelEntity;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CalculatedLinkTriplets;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLinks;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.group.CmdbClassGroup;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.group.CmdbClassGroups;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.definition.CmdbMethodQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDefs;
import com.mercury.topaz.cmdb.shared.classmodel.util.tree.CmdbClassTree;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLinks;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.util.timestamp.CmdbTimeStamp;
import java.util.Collection;
import java.util.List;

class CmdbClassModelWrapper
  implements CmdbClassModel
{
  private CmdbClassModel _classModel;

  public CmdbClassModelWrapper(CmdbClassModel classModel)
  {
    this._classModel = classModel;
  }

  public CmdbClasses getClassesByQualifier(String qualifierName) {
    return this._classModel.getClassesByQualifier(qualifierName);
  }

  public CmdbClasses getAllDescendentClasses(String className) {
    return this._classModel.getAllDescendentClasses(className);
  }

  public CmdbClassQualifierDefs getAllClassQualifierDefs() {
    return this._classModel.getAllClassQualifierDefs();
  }

  public CmdbClassQualifierDefs getAllUserClassQualifierDefs() {
    return this._classModel.getAllUserClassQualifierDefs();
  }

  public CmdbAttributeQualifierDefs getAllAttributeQualifierDefs() {
    return this._classModel.getAllAttributeQualifierDefs();
  }

  public CmdbMethodQualifierDefs getAllMethodQualifierDefs() {
    return this._classModel.getAllMethodQualifierDefs();
  }

  public CmdbClasses getAllClassDefinitiones() {
    return this._classModel.getAllClassDefinitiones();
  }

  public CmdbClasses getAllClasses() {
    return this._classModel.getAllClasses();
  }

  public CmdbClassGroups getAllClassGroups() {
    return this._classModel.getAllClassGroups();
  }

  public CmdbTimeStamp getCmdbTimeStamp() {
    return this._classModel.getCmdbTimeStamp();
  }

  public boolean isChanged(CmdbTimeStamp classModelTimeStamp) {
    return this._classModel.isChanged(classModelTimeStamp);
  }

  public CmdbValidLinks getAllValidLinks() {
    return this._classModel.getAllValidLinks();
  }

  public CmdbTypeDefs getAllTypeDefs() {
    return this._classModel.getAllTypeDefs();
  }

  public CmdbCalculatedLinks getAllCalculatedLinks() {
    return this._classModel.getAllCalculatedLinks();
  }

  public ClassModelEntity getDeepReadOnlyCopy() {
    return this._classModel.getDeepReadOnlyCopy();
  }

  public int getHierarchyDistance(String class1Name, String class2Name) {
    return this._classModel.getHierarchyDistance(class1Name, class2Name);
  }

  public CmdbClassTree getClassTree() {
    return this._classModel.getClassTree();
  }

  public CmdbClass getClass(String qualifiedClassName) {
    return this._classModel.getClass(qualifiedClassName);
  }

  public CmdbValidLinks getAllValidLinksByFilter(String linkClassName, boolean isDerivedLink, String end1, boolean isDerivedEnd1, String end2, boolean isDerivedEnd2)
  {
    return this._classModel.getAllValidLinksByFilter(linkClassName, isDerivedLink, end1, isDerivedEnd1, end2, isDerivedEnd2);
  }

  public CmdbValidLinks getAllValidLinks(String end1, String end2) {
    return this._classModel.getAllValidLinks(end1, end2);
  }

  public CmdbValidLinks getAllPossibleValidLinks(String end1, String end2) {
    return this._classModel.getAllPossibleValidLinks(end1, end2);
  }

  public Collection getAllPossibleLinks(String end1, String end2) {
    return this._classModel.getAllPossibleLinks(end1, end2);
  }

  public List getCmdbClassAncestors(CmdbClass leafCmdbClass) {
    return this._classModel.getCmdbClassAncestors(leafCmdbClass);
  }

  public boolean isSimpleCalculatedLink(String linkClassName) {
    return this._classModel.isSimpleCalculatedLink(linkClassName);
  }

  public boolean isSimpleCalculatedLink(ElementClassCondition classCondition) {
    return this._classModel.isSimpleCalculatedLink(classCondition);
  }

  public CalculatedLinkTriplets getTripletsForLink(ElementClassCondition classCondition) {
    return this._classModel.getTripletsForLink(classCondition);
  }

  public CmdbValidLinks getAllConcreteValidLinks(String end1, String end2) {
    return this._classModel.getAllConcreteValidLinks(end1, end2);
  }

  public boolean isLinkValid(String linkClassName, String end1, String end2) {
    return this._classModel.isLinkValid(linkClassName, end1, end2);
  }

  public boolean isLinkValidForConcreteLinkType(String linkClassName, String end1, String end2) {
    return this._classModel.isLinkValidForConcreteLinkType(linkClassName, end1, end2);
  }

  public CmdbValidLinks getAllValidLinksForEnd1(String end1) {
    return this._classModel.getAllValidLinksForEnd1(end1);
  }

  public CmdbValidLinks getAllValidLinksForEnd2(String end2) {
    return this._classModel.getAllValidLinksForEnd2(end2);
  }

  public CmdbClassGroup getClassGroup(String groupName) {
    return this._classModel.getClassGroup(groupName);
  }

  public CmdbClassGroups getClassGroups(String className) {
    return this._classModel.getClassGroups(className);
  }

  public CmdbClasses getClassesOfNameSpace(String nameSpace) {
    return this._classModel.getClassesOfNameSpace(nameSpace);
  }

  public boolean isDescendant(String superClassName, String subClassName) {
    return this._classModel.isDescendant(superClassName, subClassName);
  }

  public boolean isTypeOf(String superClassName, String subClassName) {
    return this._classModel.isTypeOf(superClassName, subClassName);
  }

  public boolean isLeaf(String className)
  {
    return this._classModel.isLeaf(className);
  }

  public CmdbClass resolveCmdbClassDefinition(CmdbClassDefinition cmdbClassDefinition) {
    return this._classModel.resolveCmdbClassDefinition(cmdbClassDefinition);
  }

  public ClassModelDestinationsConfig getClassesDestinationsConfig() {
    return this._classModel.getClassesDestinationsConfig();
  }

  public CmdbValidLinks getCalculatedValidLinks() {
    return this._classModel.getCalculatedValidLinks();
  }
}