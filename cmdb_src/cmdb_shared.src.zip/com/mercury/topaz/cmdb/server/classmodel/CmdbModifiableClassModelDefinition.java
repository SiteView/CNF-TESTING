package com.mercury.topaz.cmdb.server.classmodel;

import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModelDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.definition.CmdbMethodQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.exception.ClassModelValidationException;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.definition.CmdbValidLinkQualifierDef;

public abstract interface CmdbModifiableClassModelDefinition extends CmdbClassModelDefinition
{
  public abstract CmdbClassModelDefinition getReadOnlyClassDefinition();

  public abstract CmdbClassDefinition updateClass(CmdbClassDefinition paramCmdbClassDefinition);

  public abstract CmdbClassDefinition addOrUpdate(CmdbClassDefinition paramCmdbClassDefinition);

  public abstract CmdbClassDefinition addClass(CmdbClassDefinition paramCmdbClassDefinition)
    throws ClassModelValidationException;

  public abstract CmdbClassDefinition removeClass(String paramString)
    throws ClassModelValidationException;

  public abstract CmdbValidLink addValidLink(CmdbValidLink paramCmdbValidLink)
    throws ClassModelValidationException;

  public abstract CmdbValidLink updateValidLink(CmdbValidLink paramCmdbValidLink)
    throws ClassModelValidationException;

  public abstract CmdbValidLink addOrUpdateValidLink(CmdbValidLink paramCmdbValidLink)
    throws ClassModelValidationException;

  public abstract boolean removeValidLink(CmdbValidLink paramCmdbValidLink)
    throws ClassModelValidationException;

  public abstract CmdbTypeDef addTypeDef(CmdbTypeDef paramCmdbTypeDef)
    throws ClassModelValidationException;

  public abstract CmdbTypeDef removeTypeDef(String paramString)
    throws ClassModelValidationException;

  public abstract CmdbTypeDef updateTypeDef(CmdbTypeDef paramCmdbTypeDef)
    throws ClassModelValidationException;

  public abstract void addClassQualifierDef(CmdbClassQualifierDef paramCmdbClassQualifierDef);

  public abstract void addAttributeQualifierDef(CmdbAttributeQualifierDef paramCmdbAttributeQualifierDef);

  public abstract void addMethodQualifierDef(CmdbMethodQualifierDef paramCmdbMethodQualifierDef);

  public abstract void addValidLinkQualifierDef(CmdbValidLinkQualifierDef paramCmdbValidLinkQualifierDef);

  public abstract CmdbCalculatedLink addCalculatedLink(CmdbCalculatedLink paramCmdbCalculatedLink)
    throws ClassModelValidationException;

  public abstract CmdbCalculatedLink addCalculatedLinkWithClass(CmdbCalculatedLink paramCmdbCalculatedLink)
    throws ClassModelValidationException;

  public abstract CmdbCalculatedLink removeCalculatedLink(CmdbCalculatedLink paramCmdbCalculatedLink)
    throws ClassModelValidationException;

  public abstract CmdbCalculatedLink removeCalculatedLink(String paramString)
    throws ClassModelValidationException;

  public abstract CmdbCalculatedLink updateCalculatedLink(CmdbCalculatedLink paramCmdbCalculatedLink)
    throws ClassModelValidationException;
}