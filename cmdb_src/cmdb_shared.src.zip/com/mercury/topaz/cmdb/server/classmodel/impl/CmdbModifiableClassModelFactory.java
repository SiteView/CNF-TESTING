package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.topaz.cmdb.server.classmodel.CmdbModifiableClassModel;
import com.mercury.topaz.cmdb.server.classmodel.CmdbModifiableClassModelDefinition;
import com.mercury.topaz.cmdb.server.classmodel.CmdbNotifiableClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModelDefinition;

public final class CmdbModifiableClassModelFactory
{
  public static CmdbNotifiableClassModel createNotifiableClassModel(CmdbClassModel classModel)
  {
    return new CmdbNotifiableClassModelImpl(classModel);
  }

  public static CmdbModifiableClassModel createModifiableClassModel(CmdbClassModel classModel) {
    return new CmdbModifiableClassModelImpl(classModel);
  }

  public static CmdbModifiableClassModelDefinition createClassModelDefinition() {
    return new CmdbModifiableClassModelDefinitionImpl();
  }

  public static CmdbModifiableClassModelDefinition createClassModelDefinition(CmdbClassModelDefinition cmdbClassModelDefinition) {
    return new CmdbModifiableClassModelDefinitionImpl(cmdbClassModelDefinition);
  }
}