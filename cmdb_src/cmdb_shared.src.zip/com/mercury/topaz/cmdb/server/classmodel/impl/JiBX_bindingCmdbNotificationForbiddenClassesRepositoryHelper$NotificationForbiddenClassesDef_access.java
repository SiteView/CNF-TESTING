package com.mercury.topaz.cmdb.server.classmodel.impl;

import org.jibx.runtime.IMarshaller;
import org.jibx.runtime.IUnmarshaller;

public class NotificationForbiddenClassesDef_access
  implements IUnmarshaller, IMarshaller
{
}