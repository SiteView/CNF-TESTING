package com.mercury.topaz.cmdb.server.classmodel;

import com.mercury.topaz.cmdb.server.dal.dao.CmdbDalClassModelDAO;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.exception.ClassModelException;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;

public abstract interface ClassModelManager extends CmdbSubsystemManager
{
  public abstract CmdbNotifiableClassModel getClassModelClone()
    throws ClassModelException;

  public abstract void init();

  public abstract CmdbClassModel getClassModel();

  public abstract CmdbClassModel getClassModelSnapshot();

  public abstract DataFactory getDataFactory();

  public abstract CmdbDalClassModelDAO getClassModelDAO();

  public abstract void commitUpdates()
    throws ClassModelException;

  /**
   * @deprecated
   */
  public abstract void commitUpdatesWithoutSavingToPersistency()
    throws ClassModelException;

  public abstract void rollBackUpdates();
}