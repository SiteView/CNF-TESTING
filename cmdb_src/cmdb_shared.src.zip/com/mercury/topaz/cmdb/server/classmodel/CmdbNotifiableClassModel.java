package com.mercury.topaz.cmdb.server.classmodel;

import com.mercury.topaz.cmdb.shared.change.CmdbChangeHandler;

public abstract interface CmdbNotifiableClassModel
{
}