package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverride;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverrideDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeOverrides;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.impl.CmdbAttributeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.exception.ClassModelException;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class ClassModelUtil
{
  public static CmdbModifiableAttributes filterPersistentAttributes(CmdbAttributes attributes)
  {
    CmdbModifiableAttributes persistentAttrs = CmdbAttributeFactory.createAttributes();

    ReadOnlyIterator attributesIter = attributes.getIterator();
    while (attributesIter.hasNext()) {
      CmdbAttribute attribute = (CmdbAttribute)attributesIter.next();

      if (isPersistentAttribute(attribute))
        persistentAttrs.add(attribute);
    }

    return persistentAttrs;
  }

  public static CmdbAttributes extractPersistentAttributes(CmdbAttributes attributes) {
    return filterPersistentAttributes(attributes);
  }

  public static CmdbAttributes extractPersistentAttributes(CmdbClass cl) {
    return extractPersistentAttributes(null, cl, false);
  }

  public static CmdbAttributes extractAllPersistentAttributes(CmdbClass cl) {
    return extractPersistentAttributes(null, cl, true);
  }

  private static CmdbAttributes extractPersistentAttributes(CmdbAttributes attributes, CmdbClass cl, boolean allAttributes) {
    if (allAttributes)
      attributes = cl.getAllAttributes();
    else {
      attributes = cl.getClassAttributes();
    }

    CmdbModifiableAttributes persistentAttrs = filterPersistentAttributes(attributes);

    CmdbAttributeOverrides overrides = cl.getClassDefinition().getAllAttributeOverrides();
    ReadOnlyIterator iterator = overrides.getIterator();
    while (true) { CmdbAttributeOverrideDefinition overrideDef;
      while (true) { if (!(iterator.hasNext())) break label132;
        overrideDef = (CmdbAttributeOverrideDefinition)iterator.next();
        if (overrideDef.getQualifiers().containsQualifier(CmdbAttributeQualifierDefs.MIRRORED.getName()))
          break;
      }

      String attrName = overrideDef.getName();
      CmdbAttribute attribute = getAttributeByName(attrName, cl);

      if (isPersistentAttribute(attribute))
        persistentAttrs.add(attribute);

    }

    label132: return persistentAttrs;
  }

  public static CmdbAttribute getAttributeByName(String attributeName, CmdbClass cmdbClass)
  {
    CmdbAttribute attr = cmdbClass.getClassAttributes().getAttributeByName(attributeName);
    if (attr == null) {
      CmdbClass baseClass = getAttributeBaseClass(attributeName, cmdbClass);
      attr = baseClass.getClassAttributes().getAttributeByName(attributeName);
    }
    return attr;
  }

  public static CmdbAttribute getAttributeByName(String attributeName, String className) {
    CmdbClass attributeClass = getCmdbClassByName(className);
    return getAttributeByName(attributeName, attributeClass);
  }

  public static boolean isPersistentAttribute(CmdbAttribute attribute) {
    return (!(isStaticAttribute(attribute)));
  }

  public static CmdbClass getAttributeBaseClass(String attributeName, CmdbClass cmdbClass) {
    return getAttributeClass(attributeName, cmdbClass, false);
  }

  public static CmdbClass getAttributeClass(String attributeName, CmdbClass baseClass) {
    return getAttributeClass(attributeName, baseClass, true);
  }

  public static CmdbClass getAttributeClass(String attributeName, String baseClassName) {
    CmdbClass baseClass = getCmdbClassByName(baseClassName);
    return getAttributeClass(attributeName, baseClass);
  }

  public static CmdbClass getAttributeClass(String attributeName, CmdbClass cmdbClass, boolean derivedFirst) {
    boolean attributeMirrored = isAttributeMirrored(cmdbClass, attributeName);

    CmdbClass cl = cmdbClass;
    while (!(cl.getName().equals("none"))) {
      if ((cl.getClassAttributes().hasAttribute(attributeName)) || ((derivedFirst) && (attributeMirrored))) {
        return cl;
      }

      cl = cl.getResolvedSuperClass();
    }

    throw new CmdbException("Can't find cmdb class for attribute [" + attributeName + "] " + "from leaf class [" + cmdbClass.getName() + "]");
  }

  public static CmdbClass getCmdbClassByName(String className)
  {
    CmdbClassModel classModel = classModel();
    CmdbClass cmdbClass = classModel.getClass(className);
    if (cmdbClass == null)
      throw new ClassModelException("Cmdb class [" + className + "] doesn't exist in the class model!!!");

    return cmdbClass;
  }

  public static CmdbClassModel classModel() {
    return ClassModelProvider.getClassModell();
  }

  public static CmdbClassModel getDirectReference(CmdbClassModel classModel) {
    while (classModel instanceof CmdbClassModelDelegator)
      classModel = ((CmdbClassModelDelegator)classModel).getClassModel();

    return classModel;
  }

  public static boolean isAttributeMirrored(CmdbClass cl, String attributeName) {
    boolean attributeMirrored = false;
    CmdbAttributeOverrides overrides = cl.getClassDefinition().getAllAttributeOverrides();
    if (overrides.hasAttributeOverride(attributeName)) {
      CmdbAttributeOverrideDefinition overrideDef = overrides.getAttributeOverrideDefinitionByName(attributeName);

      CmdbAttributeQualifiers qualifiers = overrideDef.getQualifiers();
      if (qualifiers.containsQualifier(CmdbAttributeQualifierDefs.MIRRORED.getName()))
        attributeMirrored = true;
    }

    return attributeMirrored;
  }

  public static boolean isStaticAttribute(CmdbAttribute attribute) {
    return ((attribute.getQualifiers() != null) && (attribute.getQualifiers().containsQualifier(CmdbAttributeQualifierDefs.STATIC_ATTRIBUTE.getName())));
  }

  public static boolean isIndexedAttribute(CmdbAttributeOverride attribute) {
    CmdbAttributeQualifiers attributeQualifiers = attribute.getQualifiers();

    if (attributeQualifiers == null) {
      return false;
    }

    if (attributeQualifiers.containsQualifier(CmdbAttributeQualifierDefs.INDEXED_ATTRIBUTE.getName())) {
      return true;
    }

    return attributeQualifiers.containsQualifier(CmdbAttributeQualifierDefs.ID_ATTRIBUTE.getName());
  }

  public static boolean mustHaveContainer(CmdbObject ci) {
    CmdbClassModel classModel = classModel();
    CmdbClass cit = classModel.getClass(ci.getType());
    CmdbAttributes idAttributes = cit.getAttributesByQualifier(CmdbAttributeQualifierDefs.ID_ATTRIBUTE);
    if ((idAttributes == null) || (idAttributes.isEmpty())) {
      return false;
    }

    CmdbAttribute attribute = idAttributes.getAttributeByName("root_container");
    return (attribute != null);
  }
}