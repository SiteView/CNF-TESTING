package com.mercury.topaz.cmdb.server.classmodel.mock;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.base.entity.ClassModelEntity;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CalculatedLinkTriplets;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLinks;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.group.CmdbClassGroup;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.group.CmdbClassGroups;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.definition.CmdbMethodQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDefs;
import com.mercury.topaz.cmdb.shared.classmodel.util.tree.CmdbClassTree;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLinks;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.util.timestamp.CmdbTimeStamp;
import java.util.Collection;
import java.util.List;

public class MockClassModel
  implements CmdbClassModel
{
  private ClassModelDestinationsConfig _classModelDestinationsConfig;
  private boolean shouldReturnNullAsCmdbClass;

  public MockClassModel(ClassModelDestinationsConfig classModelDestinationsConfig, boolean shouldReturnNullAsCmdbClass)
  {
    this._classModelDestinationsConfig = classModelDestinationsConfig;
    this.shouldReturnNullAsCmdbClass = shouldReturnNullAsCmdbClass;
  }

  public MockClassModel() {
    this.shouldReturnNullAsCmdbClass = false;
  }

  public String toXml() {
    throw new UnsupportedOperationException();
  }

  public CmdbClasses getClassesByQualifier(String qualifierName) {
    throw new UnsupportedOperationException();
  }

  public CmdbClasses getAllDescendentClasses(String className) {
    throw new UnsupportedOperationException();
  }

  public boolean isTypeOf(String superClassName, String subClassName) {
    throw new UnsupportedOperationException();
  }

  public ClassModelEntity getDeepReadOnlyCopy() {
    throw new UnsupportedOperationException();
  }

  public int getHierarchyDistance(String class1Name, String class2Name) {
    throw new UnsupportedOperationException();
  }

  public CmdbClassTree getClassTree() {
    throw new UnsupportedOperationException();
  }

  public CmdbClassQualifierDefs getAllClassQualifierDefs() {
    throw new UnsupportedOperationException();
  }

  public CmdbClassQualifierDefs getAllUserClassQualifierDefs() {
    throw new UnsupportedOperationException();
  }

  public CmdbAttributeQualifierDefs getAllAttributeQualifierDefs() {
    throw new UnsupportedOperationException();
  }

  public CmdbMethodQualifierDefs getAllMethodQualifierDefs() {
    throw new UnsupportedOperationException();
  }

  public CmdbClasses getAllClassDefinitiones() {
    throw new UnsupportedOperationException();
  }

  public CmdbClasses getAllClasses() {
    throw new UnsupportedOperationException();
  }

  public CmdbTimeStamp getCmdbTimeStamp() {
    throw new UnsupportedOperationException();
  }

  public boolean isChanged(CmdbTimeStamp classModelTimeStamp) {
    throw new UnsupportedOperationException();
  }

  public CmdbClassGroups getAllClassGroups() {
    throw new UnsupportedOperationException();
  }

  public CmdbValidLinks getAllValidLinks() {
    throw new UnsupportedOperationException();
  }

  public CmdbTypeDefs getAllTypeDefs() {
    throw new UnsupportedOperationException();
  }

  public CmdbCalculatedLinks getAllCalculatedLinks() {
    throw new UnsupportedOperationException();
  }

  public CmdbClass getClass(String qualifiedClassName) {
    if (this.shouldReturnNullAsCmdbClass)
      return null;

    throw new UnsupportedOperationException();
  }

  public CmdbValidLinks getAllValidLinksByFilter(String linkClassName, boolean isDerivedLink, String end1, boolean isDerivedEnd1, String end2, boolean isDerivedEnd2)
  {
    throw new UnsupportedOperationException();
  }

  public CmdbValidLinks getAllValidLinks(String end1, String end2) {
    throw new UnsupportedOperationException();
  }

  public CmdbValidLinks getAllPossibleValidLinks(String end1, String end2) {
    throw new UnsupportedOperationException();
  }

  public Collection getAllPossibleLinks(String end1, String end2) {
    throw new UnsupportedOperationException();
  }

  public List getCmdbClassAncestors(CmdbClass leafCmdbClass) {
    throw new UnsupportedOperationException();
  }

  public boolean isSimpleCalculatedLink(String linkClassName) {
    throw new UnsupportedOperationException();
  }

  public boolean isSimpleCalculatedLink(ElementClassCondition classCondition) {
    throw new UnsupportedOperationException();
  }

  public CalculatedLinkTriplets getTripletsForLink(ElementClassCondition classCondition) {
    return null;
  }

  public CmdbValidLinks getAllConcreteValidLinks(String end1, String end2) {
    throw new UnsupportedOperationException();
  }

  public boolean isLinkValid(String linkClassName, String end1, String end2) {
    throw new UnsupportedOperationException();
  }

  public boolean isLinkValidForConcreteLinkType(String linkClassName, String end1, String end2) {
    throw new UnsupportedOperationException();
  }

  public CmdbValidLinks getAllValidLinksForEnd1(String end1) {
    throw new UnsupportedOperationException();
  }

  public CmdbValidLinks getAllValidLinksForEnd2(String end2) {
    throw new UnsupportedOperationException();
  }

  public CmdbClassGroup getClassGroup(String groupName) {
    throw new UnsupportedOperationException();
  }

  public CmdbClassGroups getClassGroups(String className) {
    throw new UnsupportedOperationException();
  }

  public CmdbClasses getClassesOfNameSpace(String nameSpace) {
    throw new UnsupportedOperationException();
  }

  public boolean isDescendant(String superClassName, String subClassName) {
    throw new UnsupportedOperationException();
  }

  public boolean isLeaf(String className) {
    throw new UnsupportedOperationException();
  }

  public CmdbClass resolveCmdbClassDefinition(CmdbClassDefinition cmdbClassDefinition) {
    throw new UnsupportedOperationException();
  }

  public ClassModelDestinationsConfig getClassesDestinationsConfig() {
    return this._classModelDestinationsConfig;
  }

  public CmdbValidLinks getCalculatedValidLinks() {
    throw new UnsupportedOperationException();
  }
}