package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.topaz.cmdb.server.classmodel.CmdbNotifiableClassModel;
import com.mercury.topaz.cmdb.server.classmodel.change.CmdbClassModelChangeHandler;
import com.mercury.topaz.cmdb.server.classmodel.change.impl.CmdbClassModelChangeHandlerImpl;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.exception.ClassModelValidationException;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;

class CmdbNotifiableClassModelImpl extends CmdbModifiableClassModelImpl
  implements CmdbNotifiableClassModel
{
  private CmdbClassModelChangeHandler _changeHandler;

  CmdbNotifiableClassModelImpl(CmdbClassModel classModel)
  {
    super(classModel);
    setChangeHandler(new CmdbClassModelChangeHandlerImpl());
  }

  public CmdbChanges getChanges() {
    return getChangeHandler().getChanges();
  }

  public void clearChanges() {
    getChangeHandler().clearChanges();
  }

  public CmdbTypeDef addTypeDef(CmdbTypeDef typeDef) throws ClassModelValidationException {
    CmdbTypeDef addedTypeDef = super.addTypeDef(typeDef);
    getChangeHandler().onAddTypeDef(addedTypeDef);
    return addedTypeDef;
  }

  public CmdbTypeDef removeTypeDef(String typeDefName) throws ClassModelValidationException {
    CmdbTypeDef typeDef = super.removeTypeDef(typeDefName);
    if (typeDef != null)
      getChangeHandler().onRemoveTypeDef(typeDef);

    return typeDef;
  }

  public CmdbTypeDef updateTypeDef(CmdbTypeDef typeDef) throws ClassModelValidationException {
    CmdbTypeDef updatedTypeDef = super.updateTypeDef(typeDef);
    getChangeHandler().onUpdateTypeDef(updatedTypeDef);
    return typeDef;
  }

  public CmdbClassDefinition addClass(CmdbClassDefinition cmdbClass) throws ClassModelValidationException {
    CmdbClassDefinition addClassDefinition = super.addClass(cmdbClass);
    getChangeHandler().onAddClass(addClassDefinition);
    return addClassDefinition;
  }

  public CmdbClassDefinition removeClass(String qualifiedName) throws ClassModelValidationException {
    CmdbClassDefinition remCmdbClass = super.removeClass(qualifiedName);
    getChangeHandler().onRemoveClass(remCmdbClass);
    return remCmdbClass;
  }

  public CmdbClassDefinition updateClass(CmdbClassDefinition cmdbClass) {
    CmdbClassDefinition updateClassDefinition = super.updateClass(cmdbClass);
    getChangeHandler().onUpdateClass(updateClassDefinition);
    return updateClassDefinition;
  }

  public CmdbClassDefinition addOrUpdate(CmdbClassDefinition cmdbClass) {
    if (isClassExists(cmdbClass))
      return updateClass(cmdbClass);

    return addClass(cmdbClass);
  }

  public CmdbValidLink addValidLink(CmdbValidLink validLink) throws ClassModelValidationException
  {
    CmdbValidLink addedValidLink = super.addValidLink(validLink);
    getChangeHandler().onAddValidLink(addedValidLink);
    return addedValidLink;
  }

  public CmdbValidLink updateValidLink(CmdbValidLink validLink) throws ClassModelValidationException {
    CmdbValidLink updatedValidLink = super.updateValidLink(validLink);
    getChangeHandler().onUpdateValidLink(updatedValidLink);
    return updatedValidLink;
  }

  public boolean removeValidLink(CmdbValidLink validLink) throws ClassModelValidationException {
    boolean isExist = super.removeValidLink(validLink);
    getChangeHandler().onRemoveValidLink((CmdbValidLink)validLink.getDeepReadOnlyCopy());
    return isExist;
  }

  private CmdbClassModelChangeHandler getChangeHandler() {
    return this._changeHandler;
  }

  private void setChangeHandler(CmdbClassModelChangeHandler changeHandler) {
    this._changeHandler = changeHandler;
  }

  public void setClassesDestinationsConfig(ClassModelDestinationsConfig config) {
    super.setClassesDestinationsConfig(config);
    getChangeHandler().onClassesDestinationsConfigChange();
  }

  public CmdbCalculatedLink addCalculatedLink(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    CmdbCalculatedLink addCalculatedLink = super.addCalculatedLink(calculatedLink);
    getChangeHandler().onAddCalculatedLink(addCalculatedLink);
    return addCalculatedLink;
  }

  public CmdbCalculatedLink addCalculatedLinkWithClass(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    super.addClass(calculatedLink.getCmdbClass());
    return addCalculatedLink(calculatedLink);
  }

  public CmdbCalculatedLink removeCalculatedLink(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    CmdbCalculatedLink removeCalculatedLink = super.removeCalculatedLink(calculatedLink);
    getChangeHandler().onRemoveCalculatedLink(removeCalculatedLink);
    return removeCalculatedLink;
  }

  public CmdbCalculatedLink removeCalculatedLink(String linkClassName) throws ClassModelValidationException {
    CmdbCalculatedLink removeCalculatedLink = super.removeCalculatedLink(linkClassName);
    getChangeHandler().onRemoveCalculatedLink(removeCalculatedLink);
    return removeCalculatedLink;
  }

  public CmdbCalculatedLink updateCalculatedLink(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    CmdbCalculatedLink updatedCalcLink = super.updateCalculatedLink(calculatedLink);
    getChangeHandler().onUpdateCalculatedLink(updatedCalcLink);
    return updatedCalcLink;
  }

  public void addCalculatedValidLink(CmdbValidLink calculatedValidLink) {
    super.addCalculatedValidLink(calculatedValidLink);
    getChangeHandler().onAddCalculatedValidLink(calculatedValidLink);
  }

  public void removeCalculatedValidLink(CmdbValidLink calculatedValidLink) {
    super.removeCalculatedValidLink(calculatedValidLink);
    getChangeHandler().onRemoveCalculatedValidLink(calculatedValidLink);
  }
}