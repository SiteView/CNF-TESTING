package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public class ClassModelManagerFactory extends AbstractSubsystemManagerFactory
{
  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new ClassModelManagerImpl(localEnvironment);
  }
}