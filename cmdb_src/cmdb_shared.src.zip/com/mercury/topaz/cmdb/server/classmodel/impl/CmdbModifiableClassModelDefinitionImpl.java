package com.mercury.topaz.cmdb.server.classmodel.impl;

import com.mercury.topaz.cmdb.server.classmodel.CmdbModifiableClassModelDefinition;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModelDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.base.entity.ClassModelEntity;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLinks;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbModifiableCalculatedLinks;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.impl.CmdbCalculatedLinkFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbModifiableClasses;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.group.CmdbClassGroups;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.impl.CmdbClassFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.definition.CmdbMethodQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.method.qualifier.definition.CmdbMethodQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.exception.ClassModelValidationException;
import com.mercury.topaz.cmdb.shared.classmodel.impl.AbstractClassModelDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.impl.CmdbClassModelFactory;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbModifiableTypeDefs;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDefs;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.impl.CmdbTypeDefFactory;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbModifiableValidLinks;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLinks;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.impl.CmdbValidLinkFactory;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.qualifier.definition.CmdbValidLinkQualifierDef;

class CmdbModifiableClassModelDefinitionImpl extends AbstractClassModelDefinition
  implements CmdbModifiableClassModelDefinition
{
  private CmdbModifiableTypeDefs _modifiableTypeDefs;
  private CmdbModifiableClasses _modifiableClasses;
  private CmdbModifiableValidLinks _modifiableValidLinks;
  private CmdbModifiableCalculatedLinks _modifiableCalculatedLinks;
  private CmdbClassModelDefinition _readOnlyClassModelDefinition;

  CmdbModifiableClassModelDefinitionImpl()
  {
    setModifiableClasses(CmdbClassFactory.createClasses());
    setModifiableValidLinks(CmdbValidLinkFactory.createValidLinks());
    setModifiableTypeDefs(CmdbTypeDefFactory.createTypeDefs());
    setModifiableCalculatedLink(CmdbCalculatedLinkFactory.createCalculatedLinks());
    initReadOnly();
  }

  CmdbModifiableClassModelDefinitionImpl(CmdbClasses classes, CmdbValidLinks validLinks, CmdbTypeDefs typeDefs, CmdbCalculatedLinks calculatedLinks) {
    setModifiableClasses(CmdbClassFactory.createClasses(classes));
    setModifiableValidLinks(CmdbValidLinkFactory.createValidLinks(validLinks));
    setModifiableTypeDefs(CmdbTypeDefFactory.createTypeDefs(typeDefs));
    setModifiableCalculatedLink(CmdbCalculatedLinkFactory.createCalculatedLinks(calculatedLinks));
    initReadOnly();
  }

  CmdbModifiableClassModelDefinitionImpl(CmdbClassModelDefinition classModelDefinition) {
    this(classModelDefinition.getAllClassDefinitiones(), classModelDefinition.getAllValidLinks(), classModelDefinition.getAllTypeDefs(), classModelDefinition.getAllCalculatedLinks());
  }

  private void initReadOnly()
  {
    setClasses(getModifiableClasses().getReadOnlyClasses());
    setValidLinks(getModifiableValidLinks().getReadOnlyValidLinks());
    setTypeDefs(getModifiableTypeDefs().getReadOnlyTypeDefs());
    setCalculatedLinks(getModifiableCalculatedLinks().getReadOnlyCalculatedLinks());
    this._readOnlyClassModelDefinition = new CmdbClassDefinitionWrapper(this, null);
  }

  public CmdbClassModelDefinition getReadOnlyClassDefinition() {
    return this._readOnlyClassModelDefinition;
  }

  public CmdbClassDefinition updateClass(CmdbClassDefinition cmdbClassDefinition) {
    CmdbClassDefinition updatedClassDefinition = CmdbClassFactory.createClassDefinition(cmdbClassDefinition);
    if (!(getModifiableClasses().updateClass(updatedClassDefinition)))
      throw new ClassModelValidationException("cannot update class: " + cmdbClassDefinition.getName() + " , class doesn't exists !!!", ErrorCode.CLASS_NOT_IN_CLASS_MODEL);

    return updatedClassDefinition;
  }

  public CmdbClassDefinition addOrUpdate(CmdbClassDefinition cmdbClass) {
    throw new UnsupportedOperationException("");
  }

  public CmdbClassDefinition addClass(CmdbClassDefinition cmdbClass) throws ClassModelValidationException {
    CmdbClassDefinition classDefinition = CmdbClassFactory.createClassDefinition(cmdbClass);
    getModifiableClasses().add(classDefinition);
    return classDefinition;
  }

  public CmdbClassDefinition removeClass(String qualifiedName) throws ClassModelValidationException {
    CmdbClassDefinition classDefinition = getModifiableClasses().removeClassByName(qualifiedName);
    if (classDefinition == null)
      return null;

    return ((CmdbClassDefinition)classDefinition.getDeepReadOnlyCopy());
  }

  public CmdbValidLink addValidLink(CmdbValidLink validLink) throws ClassModelValidationException {
    getModifiableValidLinks().add(validLink);
    return validLink;
  }

  public CmdbValidLink updateValidLink(CmdbValidLink validLink) throws ClassModelValidationException {
    getModifiableValidLinks().update(validLink);
    return validLink;
  }

  public CmdbValidLink addOrUpdateValidLink(CmdbValidLink validLink) throws ClassModelValidationException {
    getModifiableValidLinks().addOrUpdate(validLink);
    return validLink;
  }

  public boolean removeValidLink(CmdbValidLink validLink) throws ClassModelValidationException {
    return getModifiableValidLinks().removeById(validLink);
  }

  public CmdbTypeDef addTypeDef(CmdbTypeDef typeDef) throws ClassModelValidationException {
    CmdbTypeDef typeDefToAdd = (CmdbTypeDef)typeDef.getDeepReadOnlyCopy();
    getModifiableTypeDefs().add(typeDefToAdd);
    return typeDefToAdd;
  }

  public CmdbTypeDef removeTypeDef(String typeDefName) throws ClassModelValidationException {
    return getModifiableTypeDefs().removeByName(typeDefName);
  }

  public CmdbTypeDef updateTypeDef(CmdbTypeDef typeDef) throws ClassModelValidationException {
    removeTypeDef(typeDef.getName());
    return addTypeDef(typeDef);
  }

  public void addClassQualifierDef(CmdbClassQualifierDef classQualifier) {
    throw new UnsupportedOperationException("");
  }

  public void addAttributeQualifierDef(CmdbAttributeQualifierDef attributeQualifier) {
    throw new UnsupportedOperationException("");
  }

  public void addMethodQualifierDef(CmdbMethodQualifierDef methodQualifier) {
    throw new UnsupportedOperationException("");
  }

  public void addValidLinkQualifierDef(CmdbValidLinkQualifierDef validLinkQualifier) {
    throw new UnsupportedOperationException("");
  }

  public CmdbCalculatedLink addCalculatedLink(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    getModifiableCalculatedLinks().add(calculatedLink);
    return calculatedLink;
  }

  public CmdbCalculatedLink addCalculatedLinkWithClass(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    addClass(calculatedLink.getCmdbClass());
    return addCalculatedLink(calculatedLink);
  }

  public CmdbCalculatedLink removeCalculatedLink(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    getModifiableCalculatedLinks().remove(calculatedLink);
    return calculatedLink;
  }

  public CmdbCalculatedLink removeCalculatedLink(String linkClassName) throws ClassModelValidationException {
    return getModifiableCalculatedLinks().removeByLinkName(linkClassName);
  }

  public CmdbCalculatedLink updateCalculatedLink(CmdbCalculatedLink calculatedLink) throws ClassModelValidationException {
    CmdbCalculatedLink updatedCalcLink = CmdbCalculatedLinkFactory.createCalculatedLinkDefinition(calculatedLink);
    if (!(getModifiableCalculatedLinks().update(updatedCalcLink)))
      throw new ClassModelValidationException("cannot update calcualed link: " + updatedCalcLink.getName() + " , calculated link doesn't exists !!!", ErrorCode.CLASS_NOT_IN_CLASS_MODEL);

    return updatedCalcLink;
  }

  private CmdbModifiableTypeDefs getModifiableTypeDefs() {
    return this._modifiableTypeDefs;
  }

  private void setModifiableTypeDefs(CmdbModifiableTypeDefs modifiableTypeDefs) {
    this._modifiableTypeDefs = modifiableTypeDefs;
  }

  private CmdbModifiableClasses getModifiableClasses() {
    return this._modifiableClasses;
  }

  private void setModifiableClasses(CmdbModifiableClasses modifiableClasses) {
    this._modifiableClasses = modifiableClasses;
  }

  public CmdbModifiableValidLinks getModifiableValidLinks() {
    return this._modifiableValidLinks;
  }

  private void setModifiableValidLinks(CmdbModifiableValidLinks modifiableValidLinks) {
    this._modifiableValidLinks = modifiableValidLinks;
  }

  private CmdbModifiableCalculatedLinks getModifiableCalculatedLinks() {
    return this._modifiableCalculatedLinks;
  }

  private void setModifiableCalculatedLink(CmdbModifiableCalculatedLinks modifiableCalculatedLinks) {
    this._modifiableCalculatedLinks = modifiableCalculatedLinks;
  }

  public ClassModelEntity getDeepReadOnlyCopy() {
    return CmdbClassModelFactory.createReadOnlyCmdbClassModelDefinition(this);
  }

  private class CmdbClassDefinitionWrapper
  implements CmdbClassModelDefinition {
    public CmdbClassQualifierDefs getAllClassQualifierDefs() {
      return CmdbModifiableClassModelDefinitionImpl.access$101(this.this$0);
    }

    public CmdbClassQualifierDefs getAllUserClassQualifierDefs() {
      return CmdbModifiableClassModelDefinitionImpl.access$201(this.this$0);
    }

    public CmdbAttributeQualifierDefs getAllAttributeQualifierDefs() {
      return CmdbModifiableClassModelDefinitionImpl.access$301(this.this$0);
    }

    public CmdbMethodQualifierDefs getAllMethodQualifierDefs() {
      return CmdbModifiableClassModelDefinitionImpl.access$401(this.this$0);
    }

    public CmdbClasses getAllClassDefinitiones() {
      return CmdbModifiableClassModelDefinitionImpl.access$501(this.this$0);
    }

    public CmdbClassGroups getAllClassGroups() {
      return CmdbModifiableClassModelDefinitionImpl.access$601(this.this$0);
    }

    public CmdbValidLinks getAllValidLinks() {
      return CmdbModifiableClassModelDefinitionImpl.access$701(this.this$0);
    }

    public CmdbTypeDefs getAllTypeDefs() {
      return CmdbModifiableClassModelDefinitionImpl.access$801(this.this$0);
    }

    public CmdbCalculatedLinks getAllCalculatedLinks() {
      return CmdbModifiableClassModelDefinitionImpl.access$901(this.this$0);
    }

    public ClassModelEntity getDeepReadOnlyCopy() {
      return this.this$0.getDeepReadOnlyCopy();
    }
  }
}