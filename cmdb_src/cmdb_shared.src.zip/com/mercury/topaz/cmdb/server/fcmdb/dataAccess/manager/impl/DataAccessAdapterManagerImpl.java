package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadSingleWrite;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;

public class DataAccessAdapterManagerImpl extends CmdbSubsystemManagerImpl
  implements DataAccessAdapterManager, MultiReadSingleWrite
{
  private final int _ftqlAllowedNumberOfObjectsFromDataStore;
  private final int _replicationAllowedNumberOfObjectsFromDataStore;

  DataAccessAdapterManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
    SettingsReader settingsReader = localEnvironment.getSettingsReader();
    this._ftqlAllowedNumberOfObjectsFromDataStore = settingsReader.getInt("quota.ftql.max.number.of.objects.in.external.result", 1000000);
    this._replicationAllowedNumberOfObjectsFromDataStore = settingsReader.getInt("quota.replication.max.number.of.objects.in.external.result", 20);
  }

  public void startUp() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Federation Data Access Manager is started up properly !!!");
  }

  public void shutdown()
  {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Federation Data Access Manager is shutdown properly !!!");
  }

  public int getReplicationAllowedNumberOfObjectsFromDataStore()
  {
    return this._replicationAllowedNumberOfObjectsFromDataStore;
  }

  public int getFtqlAllowedNumberOfObjectsFromDataStore() {
    return this._ftqlAllowedNumberOfObjectsFromDataStore;
  }

  public String getName() {
    return "Data Access Adapter Task";
  }
}