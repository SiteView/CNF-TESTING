package com.mercury.topaz.cmdb.server.fcmdb.base.log;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;

public class FCmdbLogFactory
{
  public static Log getFcmdbLog()
  {
    return LogFactory.getEasyLog("fcmdb");
  }

  public static Log getFcmdbFtqlCalcLog() {
    return LogFactory.getEasyLog("fcmdb.ftql.calc");
  }

  public static Log getFcmdbConfigAuditLog() {
    return LogFactory.getEasyLog("fcmdb.config.audit");
  }

  public static Log getFcmdbLifecycleLog() {
    return LogFactory.getEasyLog("fcmdb.lifecycle");
  }

  public static Log getFcmdbMappingEngineLog() {
    return LogFactory.getEasyLog("fcmdb.mapping.engine");
  }

  public static Log getFcmdbStatisticsLog() {
    return LogFactory.getEasyLog("fcmdb.statistics");
  }
}