package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.ModifiableFederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateFederationConfgOperation;

public class ConfigUpdateSynchUnitConfigRemove extends AbstractConfigUpdateFederationConfgOperation
{
  private String _synchUnitConfigId;

  public ConfigUpdateSynchUnitConfigRemove(String synchUnitConfigId)
  {
    setSynchUnitConfigId(synchUnitConfigId); }

  public String getSynchUnitConfigId() {
    return this._synchUnitConfigId;
  }

  private void setSynchUnitConfigId(String synchUnitConfigId) {
    if (synchUnitConfigId == null)
      throw new IllegalArgumentException("Synch ubit config id is null");

    this._synchUnitConfigId = synchUnitConfigId;
  }

  protected void updateConfig(ModifiableFederationConfigDef federationConfigDef, ConfigUpdateManager configUpdateManager)
  {
    federationConfigDef.removeSynchronizationConfigUnitDef(getSynchUnitConfigId());
  }

  public String getOperationName() {
    return "Config Update: Remove Synch Unit Config";
  }
}