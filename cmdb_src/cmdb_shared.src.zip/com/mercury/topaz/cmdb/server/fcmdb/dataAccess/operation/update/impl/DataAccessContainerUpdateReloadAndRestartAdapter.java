package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.Collection;
import java.util.Iterator;

public class DataAccessContainerUpdateReloadAndRestartAdapter extends DataAccessContainerUpdateLoadOrReloadAdapterCodeBase
{
  public DataAccessContainerUpdateReloadAndRestartAdapter(String adapterId)
  {
    super(adapterId);
  }

  public String getOperationName() {
    return "data access operation: load or reload and restart adapter code base";
  }

  public void dataAccessContainerExecute(DataAccessContainerManager dataAccessContainerManager, CmdbResponse response) throws AdapterAccessException {
    Collection destinatiosRemoved = removeAllDestinationForAdapter(dataAccessContainerManager);
    addAndStartDestinations(destinatiosRemoved, dataAccessContainerManager);
  }

  private void addAndStartDestinations(Iterable<DestinationConfig> removedDesinationIDs, DataAccessContainerManager dataAccessContainerManager) {
    RuntimeException exception = null;
    for (Iterator i$ = removedDesinationIDs.iterator(); i$.hasNext(); ) { DestinationConfig destinationConfig = (DestinationConfig)i$.next();
      try {
        dataAccessContainerManager.getStartedBasicDataAdapterWrapper(destinationConfig);
      } catch (RuntimeException e) {
        _log.error(e);
        exception = e;
      }
    }
    if (null != exception)
      throw exception;
  }
}