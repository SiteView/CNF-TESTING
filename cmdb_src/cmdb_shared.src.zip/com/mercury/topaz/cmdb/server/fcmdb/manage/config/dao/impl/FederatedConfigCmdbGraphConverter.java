package com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.util.ConfigEncryptionUtil;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AdapterConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ClassAttributesConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.SourceConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.SynchConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.SynchConfigUnit;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.TargetConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.TqlNameConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.AdapterCapabilitiesDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.AdapterConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.ClassAttributesConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.ClassesAttributesConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.DestinationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.FederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.SourceConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.SynchConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.SynchConfigUnitDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.TargetConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.TqlNameConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.impl.ConfigDefFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.impl.FederationConfigBuilder;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.xml.ConfigXmlUtil;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.graph.ModifiableCMDBGraph;
import com.mercury.topaz.cmdb.shared.model.graph.impl.CmdbGraphFactory;
import com.mercury.topaz.cmdb.shared.model.graph.iterator.CmdbGraphIterator;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyValuesFactory;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbStringPropertyValues;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultMapUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FederatedConfigCmdbGraphConverter
{
  public static final String FEDERATION_CONFIG_CLASS = "federation_config";
  public static final String UCMDB_SUPPORTED_CLASSES_PROP = "ucmdb_supported_classes";
  public static final String SYNCH_CONFIG_CLASS = "synch_config";
  public static final String ADAPTER_CONFIG_CLASS = "adapter_config";
  public static final String ADAPTER_ID_PROP = "adapter_id";
  public static final String JAVA_CLASS_NAME_PROP = "java_class_name";
  public static final String ADAPTER_CAPABILITES_XML_PROP = "adapter_capabilities_xml";
  public static final String FIELDS_PROP = "connect_fields";
  public static final String DEFAULT_MAPPING_ENGINE_PROP = "default_mapping_engine";
  public static final String DESTINATION_CONFIG_CLASS = "destination_config";
  public static final String DESTINATION_ID_PROP = "destination_id";
  public static final String HOST_PROP = "host";
  public static final String PORT_PROP = "port";
  public static final String URL_PROP = "url";
  public static final String USERNAME_PROP = "username";
  public static final String PASSWORD_PROP = "password";
  public static final String CUSTOMER_ID_PROP = "customer_id";
  private static final String QUERY_NAMES_PROP = "queries";
  private static final String CLASSES_PROP = "classes";
  private static final String CLASSES_ATTRIBUTES_PROP = "classes_attributes";
  public static final String SYNCH_CONFIG_UNIT_CLASS = "synch_config_unit";
  public static final String TARGET_CLASS = "target";
  public static final String SOURCE_CLASS = "source";
  public static final String SOURCE_QUERY_CONFIG_CLASS = "source_query_config";
  public static final String SYNCH_CONFIG_UNIT_ID_PROP = "synch_config_unit_id";
  public static final String QUERY_NAME_PROP = "query_name";
  public static final String IS_EXCLUSIVE_PROP = "is_exclusive";
  public static final String FCMDB_CONF_COMPOSITION_CLASS = "fcmdb_conf_composition";
  public static final String FCMDB_CONF_AGGREGATION_CLASS = "fcmdb_conf_aggregation";

  public static FederationConfig convertTqlResultMapToFederationConfig(TqlResultMap federationTqlResultMap)
  {
    CmdbGraph federationConfigGraph = TqlResultMapUtils.convertTqlMapToGraph(federationTqlResultMap);
    return convertCmdbGraphToFederationConfig(federationConfigGraph);
  }

  public static FederationConfig convertCmdbGraphToFederationConfig(CmdbGraph federationGraph) {
    if ((federationGraph == null) || (!(federationGraph.hasObjects())))
      return null;

    CmdbObject federationConfigObj = federationGraph.getRoot();
    ClassesAttributesConfigDef ucmdbSupportedClassConfig = createUcmdbSupportedClassesFromObj(federationConfigObj);

    Set adaptersConfigDefSet = new HashSet();
    Set destinationConfigDefSet = new HashSet();
    List synchConfigUnitDefsList = new ArrayList();
    SynchConfigDef syncConfigDef = null;
    CmdbGraphIterator rootIterator = federationGraph.getGraphIterator((CmdbObjectID)federationConfigObj.getID());
    while (rootIterator.hasNextChild()) {
      CmdbGraphIterator nextChildIterator = rootIterator.nextChildIterator();
      CmdbObject curChild = nextChildIterator.getCurrentObject();
      String curChildType = curChild.getType();
      if (curChildType.equals("adapter_config")) {
        AdapterConfigDef curAdapterConfigDef = createAdapterConfigDefFromObject(nextChildIterator);
        adaptersConfigDefSet.add(curAdapterConfigDef);
      } else if (curChildType.equals("destination_config")) {
        String adapterId = null;
        CmdbGraphIterator destIterator = federationGraph.getGraphIterator((CmdbObjectID)curChild.getID());
        if (destIterator.hasNextChild()) {
          CmdbObject adapterConfigObject = destIterator.nextChildIterator().getCurrentObject();
          adapterId = (String)adapterConfigObject.getProperty("adapter_id").getValue();
        }
        DestinationConfigDef destinationConfigDef = createDestinationConfigDefFromObject(curChild, adapterId);
        destinationConfigDefSet.add(destinationConfigDef);
      } else if (curChildType.equals("synch_config")) {
        CmdbGraphIterator syncIterator = federationGraph.getGraphIterator((CmdbObjectID)curChild.getID());
        while (syncIterator.hasNextChild()) {
          CmdbGraphIterator synchUnitIterator = syncIterator.nextChildIterator();
          CmdbObject synchUnitObj = synchUnitIterator.getCurrentObject();
          List sources = new ArrayList();
          List targets = new ArrayList();
          while (synchUnitIterator.hasNextChild()) {
            CmdbGraphIterator synchUnitChildIterator = synchUnitIterator.nextChildIterator();
            CmdbObject synchUnitChild = synchUnitChildIterator.getCurrentObject();
            String synchUnitChildType = synchUnitChild.getType();
            if (synchUnitChildType.equals("source")) {
              List tqlNames = new ArrayList();
              while (synchUnitChildIterator.hasNextChild()) {
                CmdbGraphIterator sourceChildIterator = synchUnitChildIterator.nextChildIterator();
                CmdbObject sourceChildObject = sourceChildIterator.getCurrentObject();
                String sourceChildType = sourceChildObject.getType();
                if (sourceChildType.equals("source_query_config")) {
                  TqlNameConfigDef tqlNameConfigDef = createTqlNameConfigDefFromObj(sourceChildObject);
                  tqlNames.add(tqlNameConfigDef);
                }
              }
              SourceConfigDef sourceConfigDef = createSourceConfigDefFromObject(synchUnitChild, tqlNames);
              sources.add(sourceConfigDef);
            } else if (synchUnitChildType.equals("target")) {
              TargetConfigDef targetConfigDef = createTargetConfigDef(synchUnitChild);
              targets.add(targetConfigDef);
            } else {
              throw new IllegalStateException(synchUnitChildType + " object type is not supposed as synch unit child");
            }
          }
          SynchConfigUnitDef synchConfigUnitDef = createSynchConfigUnitDefFromObject(synchUnitObj, sources, targets);
          synchConfigUnitDefsList.add(synchConfigUnitDef);
        }
        syncConfigDef = ConfigDefFactory.createSynchConfigDef(synchConfigUnitDefsList);
      } else {
        throw new IllegalStateException(curChildType + " object type is not suposed as federation config child");
      }
    }
    FederationConfigDef federationConfigDef = ConfigDefFactory.createFederationConfigDef(adaptersConfigDefSet, destinationConfigDefSet, syncConfigDef, ucmdbSupportedClassConfig);
    return FederationConfigBuilder.buildFederationConfig(federationConfigDef);
  }

  private static ClassesAttributesConfigDef createUcmdbSupportedClassesFromObj(CmdbObject federationConfigObj) {
    CmdbProperty ucmdbSupportedClassesProperty = federationConfigObj.getProperty("ucmdb_supported_classes");
    if ((ucmdbSupportedClassesProperty == null) || (ucmdbSupportedClassesProperty.isValueEmpty()))
      return null;

    return ConfigXmlUtil.fromXmlToClassesAttributesConfigDef((String)ucmdbSupportedClassesProperty.getValue());
  }

  private static SourceConfigDef createSourceConfigDefFromObject(CmdbObject sourceObj, List<TqlNameConfigDef> tqlNames) {
    return ConfigDefFactory.createSourceConfigDef(tqlNames, (String)sourceObj.getProperty("destination_id").getValue());
  }

  private static TqlNameConfigDef createTqlNameConfigDefFromObj(CmdbObject sourceQueryObj) {
    return ConfigDefFactory.createTqlNameConfigDef((String)sourceQueryObj.getProperty("query_name").getValue(), ((Boolean)sourceQueryObj.getProperty("is_exclusive").getValue()).booleanValue());
  }

  private static TargetConfigDef createTargetConfigDef(CmdbObject targetConfigObj) {
    return ConfigDefFactory.createTargetConfigDef((String)targetConfigObj.getProperty("destination_id").getValue());
  }

  private static SynchConfigUnitDef createSynchConfigUnitDefFromObject(CmdbObject synchUnitObj, List<SourceConfigDef> sourcesConfigs, List<TargetConfigDef> targetsConfigs) {
    return ConfigDefFactory.createSynchConfigUnitDef(sourcesConfigs, targetsConfigs, (String)synchUnitObj.getProperty("synch_config_unit_id").getValue());
  }

  private static DestinationConfigDef createDestinationConfigDefFromObject(CmdbObject destinationObj, String adapterId) {
    String destinationId = (String)destinationObj.getProperty("destination_id").getValue();
    CmdbProperty customerProperty = destinationObj.getProperty("customer_id");
    Integer customerId = null;
    if ((customerProperty != null) && (!(customerProperty.isValueEmpty())))
      customerId = (Integer)customerProperty.getValue();

    String hostName = null;
    CmdbProperty hostProperty = destinationObj.getProperty("host");
    if ((hostProperty != null) && (!(hostProperty.isValueEmpty())))
      hostName = (String)hostProperty.getValue();

    Integer port = null;
    CmdbProperty portProp = destinationObj.getProperty("port");
    if ((portProp != null) && (!(portProp.isValueEmpty())))
      port = (Integer)portProp.getValue();

    String url = null;
    CmdbProperty urlProp = destinationObj.getProperty("url");
    if ((urlProp != null) && (!(urlProp.isValueEmpty())))
      url = (String)urlProp.getValue();

    String userName = null;
    CmdbProperty userNameProp = destinationObj.getProperty("username");
    if ((userNameProp != null) && (!(userNameProp.isValueEmpty())))
      userName = (String)userNameProp.getValue();

    String password = null;
    CmdbProperty passwordProp = destinationObj.getProperty("password");
    if ((passwordProp != null) && (!(passwordProp.isValueEmpty())))
      password = ConfigEncryptionUtil.decryptPasswordUsingKeyFile((String)passwordProp.getValue());

    List queries = new ArrayList();
    CmdbProperty queryNamesProp = destinationObj.getProperty("queries");
    if ((queryNamesProp != null) && (!(queryNamesProp.isValueEmpty()))) {
      CmdbPropertyValues propertyValues = (CmdbPropertyValues)queryNamesProp.getValue();
      ReadOnlyIterator valuesIter = propertyValues.valuesIterator();
      while (valuesIter.hasNext())
        queries.add((String)valuesIter.next());
    }

    List classes = new ArrayList();
    CmdbProperty classesProp = destinationObj.getProperty("classes");
    if ((classesProp != null) && (!(classesProp.isValueEmpty()))) {
      CmdbPropertyValues propertyValues = (CmdbPropertyValues)classesProp.getValue();
      ReadOnlyIterator valuesIter = propertyValues.valuesIterator();
      while (valuesIter.hasNext())
        classes.add((String)valuesIter.next());
    }

    CmdbProperty clasesAttributesProperty = destinationObj.getProperty("classes_attributes");
    ClassesAttributesConfigDef classesAttributesConfigDef = null;
    if ((clasesAttributesProperty != null) && (!(clasesAttributesProperty.isValueEmpty()))) {
      String clasesAttributesXml = (String)clasesAttributesProperty.getValue();
      classesAttributesConfigDef = ConfigXmlUtil.fromXmlToClassesAttributesConfigDef(clasesAttributesXml);
    }
    return ConfigDefFactory.createDestinationConfigDef(destinationId, customerId.intValue(), adapterId, hostName, port, url, userName, password, queries, classes, classesAttributesConfigDef);
  }

  private static AdapterConfigDef createAdapterConfigDefFromObject(CmdbGraphIterator adapterObjIterator) {
    CmdbObject adapterObj = adapterObjIterator.getCurrentObject();
    CmdbProperty adapterCapabilitiesProperty = adapterObj.getProperty("adapter_capabilities_xml");
    AdapterCapabilitiesDef adapterCapabilitiesDef = null;
    if ((adapterCapabilitiesProperty != null) && (!(adapterCapabilitiesProperty.isValueEmpty()))) {
      String adapterCapabilitiesXml = (String)adapterCapabilitiesProperty.getValue();
      adapterCapabilitiesDef = ConfigXmlUtil.fromXmlToAdapterCapabilitiesDef(adapterCapabilitiesXml);
    }
    CmdbProperty cmdbProperty = adapterObj.getProperty("connect_fields");
    List fields = Collections.emptyList();
    if (!(cmdbProperty.isValueEmpty())) {
      CmdbPropertyValues fieldsValues = (CmdbPropertyValues)cmdbProperty.getValue();
      fields = new ArrayList(fieldsValues.size());
      ReadOnlyIterator fieldsIterator = fieldsValues.valuesIterator();
      while (fieldsIterator.hasNext())
        fields.add((String)fieldsIterator.next());

    }

    String defaultMappingEngine = null;
    CmdbProperty defaultMappingEngineProperty = adapterObj.getProperty("default_mapping_engine");
    if ((defaultMappingEngineProperty != null) && (!(defaultMappingEngineProperty.isValueEmpty())))
      defaultMappingEngine = (String)defaultMappingEngineProperty.getValue();

    return ConfigDefFactory.createAdapterConfigDef((String)adapterObj.getProperty("adapter_id").getValue(), (String)adapterObj.getProperty("java_class_name").getValue(), adapterCapabilitiesDef, fields, defaultMappingEngine);
  }

  public static CmdbGraph convertFederatedConfigToCmdbGraph(FederationConfig federationConfig, DataFactory dataFactory)
  {
    ModifiableCMDBGraph graph = CmdbGraphFactory.createModifiableCMDBGraph();
    CmdbObject federationConfigObj = createFederationConfigObject(dataFactory, federationConfig);
    graph.addObject(federationConfigObj);
    Map adapterObjects = addAdapters(federationConfig, dataFactory, graph, federationConfigObj);
    Map destinationsObjects = addDestinations(federationConfig, dataFactory, adapterObjects, graph, federationConfigObj);
    SynchConfig syncConfig = federationConfig.getSynchronizationConfig();
    if (syncConfig != null) {
      CmdbObject synchConifgObject = dataFactory.createObject("synch_config");
      graph.addObject(synchConifgObject);

      ReadOnlyIterator itr = syncConfig.getSynchConfigUnits();
      while (itr.hasNext()) {
        SynchConfigUnit syncConfigUnit = (SynchConfigUnit)itr.next();
        addSynchConfigUnitToCmdbGraph(syncConfigUnit, synchConifgObject, dataFactory, graph, destinationsObjects);
      }

      CmdbLink federationConfigToSynchConfigLink = createCompositionLink(dataFactory, (CmdbObjectID)federationConfigObj.getID(), (CmdbObjectID)synchConifgObject.getID());
      graph.addLink(federationConfigToSynchConfigLink);
    }
    return graph;
  }

  private static CmdbObject createFederationConfigObject(DataFactory dataFactory, FederationConfig federationConfig) {
    CmdbProperties properties = CmdbPropertyFactory.createProperties();
    if (federationConfig.getUcmdbSupportedClassesConfigSize() > 0) {
      Iterator supportedClasses = federationConfig.getUcmdbSupportedClassesConfig();
      ArrayList supportedClassesCollection = new ArrayList(federationConfig.getUcmdbSupportedClassesConfigSize());
      while (supportedClasses.hasNext())
        supportedClassesCollection.add((ClassAttributesConfigDef)((ClassAttributesConfig)supportedClasses.next()).toConfigDef());

      ClassesAttributesConfigDef classesAttributesConfigDef = ConfigDefFactory.createClassesAttributesConfigDef(supportedClassesCollection);
      String classesAttributesConfigDefString = ConfigXmlUtil.toXml(classesAttributesConfigDef);
      properties.add(CmdbPropertyFactory.createXmlProperty("ucmdb_supported_classes", classesAttributesConfigDefString));
    }
    else
    {
      properties.add(CmdbPropertyFactory.createEmptyProperty("ucmdb_supported_classes", CmdbSimpleTypes.CmdbXml));
    }
    return dataFactory.createObject("federation_config", properties);
  }

  private static void addSynchConfigUnitToCmdbGraph(SynchConfigUnit syncConfigUnit, CmdbObject synchUnitObj, DataFactory dataFactory, ModifiableCMDBGraph graph, Map<String, CmdbObject> destinationsObjects) {
    CmdbProperties properties = CmdbPropertyFactory.createProperties();
    properties.add(CmdbPropertyFactory.createProperty("synch_config_unit_id", syncConfigUnit.getSynchConfigUnitId()));
    CmdbObject synchConfigUnitObj = dataFactory.createObject("synch_config_unit", properties);
    graph.addObject(synchConfigUnitObj);

    addTargetsToCmdbGraph(syncConfigUnit, synchConfigUnitObj, dataFactory, graph, destinationsObjects);

    addSourceConfigsToCmdbGraph(syncConfigUnit, synchConfigUnitObj, dataFactory, graph, destinationsObjects);
    CmdbLink synchUnitToSynchConfigLink = createCompositionLink(dataFactory, (CmdbObjectID)synchUnitObj.getID(), (CmdbObjectID)synchConfigUnitObj.getID());
    graph.addLink(synchUnitToSynchConfigLink);
  }

  private static void addSourceConfigsToCmdbGraph(SynchConfigUnit syncConfigUnit, CmdbObject synchConfigUnitObj, DataFactory dataFactory, ModifiableCMDBGraph graph, Map<String, CmdbObject> destinationsObjects) {
    ReadOnlyIterator itr = syncConfigUnit.getSourcesConfig();
    while (itr.hasNext()) {
      SourceConfig sourceConfig = (SourceConfig)itr.next();
      CmdbProperties sourceProps = CmdbPropertyFactory.createProperties();
      sourceProps.add(CmdbPropertyFactory.createProperty("root_container", ((CmdbObjectID)synchConfigUnitObj.getID()).toString()));
      sourceProps.add(CmdbPropertyFactory.createProperty("destination_id", sourceConfig.getDestinationConfig().getDestinationId()));
      CmdbObject sourceObj = dataFactory.createObject("source", sourceProps);
      graph.addObject(sourceObj);
      CmdbObject destinationObj = (CmdbObject)destinationsObjects.get(sourceConfig.getDestinationConfig().getDestinationId());
      if (destinationObj != null) {
        ReadOnlyIterator tqlItr = sourceConfig.getTqlNames();
        while (tqlItr.hasNext()) {
          TqlNameConfig tqlNameConfig = (TqlNameConfig)tqlItr.next();
          CmdbProperties sourceQueryProps = CmdbPropertyFactory.createProperties();
          sourceQueryProps.add(CmdbPropertyFactory.createProperty("root_container", ((CmdbObjectID)sourceObj.getID()).toString()));
          sourceQueryProps.add(CmdbPropertyFactory.createProperty("query_name", tqlNameConfig.getName()));
          sourceQueryProps.add(CmdbPropertyFactory.createProperty("is_exclusive", Boolean.valueOf(tqlNameConfig.isExclusive())));
          CmdbObject sourceQueryConfigObj = dataFactory.createObject("source_query_config", sourceQueryProps);
          CmdbLink sourceQueryToSourceLink = createCompositionLink(dataFactory, (CmdbObjectID)sourceObj.getID(), (CmdbObjectID)sourceQueryConfigObj.getID());
          if (!(graph.containsObject((CmdbObjectID)sourceQueryConfigObj.getID())))
            graph.addObject(sourceQueryConfigObj);

          graph.addLink(sourceQueryToSourceLink);
        }
        CmdbLink sourceDestinationLink = createAggregationLink(dataFactory, (CmdbObjectID)sourceObj.getID(), (CmdbObjectID)destinationObj.getID());
        graph.addLink(sourceDestinationLink);
      }
      CmdbLink sourceToSynchUnitLink = createCompositionLink(dataFactory, (CmdbObjectID)synchConfigUnitObj.getID(), (CmdbObjectID)sourceObj.getID());
      graph.addLink(sourceToSynchUnitLink);
    }
  }

  private static void addTargetsToCmdbGraph(SynchConfigUnit syncConfigUnit, CmdbObject synchConfigUnitObj, DataFactory dataFactory, ModifiableCMDBGraph graph, Map<String, CmdbObject> destinationsObjects) {
    ReadOnlyIterator itr = syncConfigUnit.getTargetsConfig();
    while (itr.hasNext()) {
      TargetConfig targetConfig = (TargetConfig)itr.next();
      String destinationId = targetConfig.getDestinationConfig().getDestinationId();
      CmdbProperties targetProps = CmdbPropertyFactory.createProperties();
      targetProps.add(CmdbPropertyFactory.createProperty("root_container", ((CmdbObjectID)synchConfigUnitObj.getID()).toString()));
      targetProps.add(CmdbPropertyFactory.createProperty("destination_id", destinationId));
      CmdbObject targetObj = dataFactory.createObject("target", targetProps);
      CmdbLink configUnitTargetLink = createCompositionLink(dataFactory, (CmdbObjectID)synchConfigUnitObj.getID(), (CmdbObjectID)targetObj.getID());
      graph.addObject(targetObj);
      graph.addLink(configUnitTargetLink);
      CmdbObject destinationObj = (CmdbObject)destinationsObjects.get(targetConfig.getDestinationConfig().getDestinationId());
      if (destinationObj != null) {
        CmdbLink targetDestinationLink = createAggregationLink(dataFactory, (CmdbObjectID)targetObj.getID(), (CmdbObjectID)destinationObj.getID());
        graph.addLink(targetDestinationLink);
      }
    }
  }

  private static Map<String, CmdbObject> addAdapters(FederationConfig federationConfig, DataFactory dataFactory, ModifiableCMDBGraph graph, CmdbObject federationConfigObj)
  {
    ReadOnlyIterator adaptersItr = federationConfig.getAdaptersConfig();
    Map adapterObjects = new HashMap();
    while (adaptersItr.hasNext()) {
      AdapterConfig adapterConfig = (AdapterConfig)adaptersItr.next();
      CmdbObject adapterConfigObj = convertAdapterConfigToCmdbObject(adapterConfig, dataFactory);
      graph.addObject(adapterConfigObj);
      CmdbLink federationConfigAdapterLink = createCompositionLink(dataFactory, (CmdbObjectID)federationConfigObj.getID(), (CmdbObjectID)adapterConfigObj.getID());
      graph.addLink(federationConfigAdapterLink);
      adapterObjects.put(adapterConfig.getAdapterId(), adapterConfigObj);
    }
    return adapterObjects;
  }

  private static Map<String, CmdbObject> addDestinations(FederationConfig federationConfig, DataFactory dataFactory, Map<String, CmdbObject> adapterObjects, ModifiableCMDBGraph graph, CmdbObject federationConfigObj)
  {
    Map destinationsObjects = new HashMap();

    ReadOnlyIterator destinationsItr = federationConfig.getDestinationsConfig();
    while (destinationsItr.hasNext()) {
      DestinationConfig destinationConfig = (DestinationConfig)destinationsItr.next();
      String adapterId = destinationConfig.getAdapterConfig().getAdapterId();
      CmdbObject adapterObj = (CmdbObject)adapterObjects.get(adapterId);
      if (adapterObj != null)
      {
        CmdbObject destinationObj = convertDestinationConfigToCmdbObject(destinationConfig, dataFactory);
        graph.addObject(destinationObj);

        CmdbLink destinationToAdapterLink = createAggregationLink(dataFactory, (CmdbObjectID)destinationObj.getID(), (CmdbObjectID)adapterObj.getID());
        graph.addLink(destinationToAdapterLink);

        CmdbLink federationConfigDestinationLink = createCompositionLink(dataFactory, (CmdbObjectID)federationConfigObj.getID(), (CmdbObjectID)destinationObj.getID());
        graph.addLink(federationConfigDestinationLink);
        destinationsObjects.put(destinationConfig.getDestinationId(), destinationObj);
      }
    }
    return destinationsObjects;
  }

  public static CmdbLink createAggregationLink(DataFactory dataFactory, CmdbObjectID end1, CmdbObjectID end2) {
    return dataFactory.createLink("fcmdb_conf_aggregation", end1, end2);
  }

  public static CmdbLink createCompositionLink(DataFactory dataFactory, CmdbObjectID end1, CmdbObjectID end2) {
    return dataFactory.createLink("fcmdb_conf_composition", end1, end2);
  }

  public static CmdbObject convertAdapterConfigToCmdbObject(AdapterConfig adapterConfig, DataFactory dataFactory) {
    CmdbProperties properties = CmdbPropertyFactory.createProperties();
    properties.add(CmdbPropertyFactory.createProperty("adapter_id", adapterConfig.getAdapterId()));
    properties.add(CmdbPropertyFactory.createProperty("java_class_name", adapterConfig.getImplementationClassName()));
    if (adapterConfig.getAdapterCapabilities() != null) {
      String adapterCapabilitiesString = ConfigXmlUtil.toXml(adapterConfig.getAdapterCapabilities());
      properties.add(CmdbPropertyFactory.createXmlProperty("adapter_capabilities_xml", adapterCapabilitiesString));
    } else {
      properties.add(CmdbPropertyFactory.createEmptyProperty("adapter_capabilities_xml", CmdbSimpleTypes.CmdbXml));
    }
    if (adapterConfig.getDefaultMappingEngine() != null)
      properties.add(CmdbPropertyFactory.createProperty("default_mapping_engine", adapterConfig.getDefaultMappingEngine()));
    else
      properties.add(CmdbPropertyFactory.createEmptyProperty("default_mapping_engine", CmdbSimpleTypes.CmdbString));

    ReadOnlyIterator adapterFields = adapterConfig.getFields();
    CmdbStringPropertyValues fieldsValues = CmdbPropertyValuesFactory.createCmdbStringPropertyValues();
    while (adapterFields.hasNext())
      fieldsValues.add((String)adapterFields.next());

    properties.add(CmdbPropertyFactory.createProperty("connect_fields", fieldsValues));
    return dataFactory.createObject("adapter_config", properties);
  }

  public static CmdbObject convertDestinationConfigToCmdbObject(DestinationConfig destinationConfig, DataFactory dataFactory) {
    CmdbProperties properties = CmdbPropertyFactory.createProperties();
    properties.add(CmdbPropertyFactory.createProperty("destination_id", destinationConfig.getDestinationId()));
    if (destinationConfig.getHostName() != null)
      properties.add(CmdbPropertyFactory.createProperty("host", destinationConfig.getHostName()));

    if (destinationConfig.getPort() != null)
      properties.add(CmdbPropertyFactory.createProperty("port", destinationConfig.getPort()));

    if (destinationConfig.getUserName() != null)
      properties.add(CmdbPropertyFactory.createProperty("username", destinationConfig.getUserName()));

    if (destinationConfig.getPassword() != null) {
      String pass = destinationConfig.getPassword();
      pass = ConfigEncryptionUtil.encryptPasswordUsingKeyFile(pass);
      properties.add(CmdbPropertyFactory.createProperty("password", pass));
    }
    if (destinationConfig.getCustomerId() > 0)
      properties.add(CmdbPropertyFactory.createProperty("customer_id", Integer.valueOf(destinationConfig.getCustomerId())));

    if ((destinationConfig.getUrl() != null) && (destinationConfig.getUrl().length() > 0)) {
      properties.add(CmdbPropertyFactory.createProperty("url", destinationConfig.getUrl()));
    }

    if (destinationConfig.getQueriesSize() > 0) {
      CmdbStringPropertyValues queriesProperty = CmdbPropertyValuesFactory.createCmdbStringPropertyValues();
      ReadOnlyIterator queriesIterator = destinationConfig.getQueries();
      while (queriesIterator.hasNext())
        queriesProperty.add((String)queriesIterator.next());

      properties.add(CmdbPropertyFactory.createProperty("queries", queriesProperty));
    }
    if (destinationConfig.getClassesSize() > 0) {
      CmdbStringPropertyValues classesProperty = CmdbPropertyValuesFactory.createCmdbStringPropertyValues();
      ReadOnlyIterator classesIterator = destinationConfig.getClasses();
      while (classesIterator.hasNext())
        classesProperty.add((String)classesIterator.next());

      properties.add(CmdbPropertyFactory.createProperty("classes", classesProperty));
    }
    if (destinationConfig.getClassesAttibutesConfig() != null) {
      String classesAttibutesString = ConfigXmlUtil.toXml(destinationConfig.getClassesAttibutesConfig());
      properties.add(CmdbPropertyFactory.createXmlProperty("classes_attributes", classesAttibutesString));
    } else {
      properties.add(CmdbPropertyFactory.createEmptyProperty("classes_attributes", CmdbSimpleTypes.CmdbXml));
    }

    return dataFactory.createObject("destination_config", properties);
  }
}