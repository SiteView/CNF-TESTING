package com.mercury.topaz.cmdb.server.fcmdb.ftql.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStorePermutationInfo;

class DataStorePermutationInfoImpl
  implements DataStorePermutationInfo
{
  String _end1DataStore;
  String _end2DataStore;

  DataStorePermutationInfoImpl(String end1DataStore, String end2DataStore)
  {
    this._end1DataStore = end1DataStore;
    this._end2DataStore = end2DataStore;
  }

  public String getEnd1DataStore() {
    return this._end1DataStore;
  }

  public String getEnd2DataStore() {
    return this._end2DataStore;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    DataStorePermutationInfoImpl that = (DataStorePermutationInfoImpl)o;

    if (this._end1DataStore != null) if (this._end1DataStore.equals(that._end1DataStore)) break label62; 
    else if (that._end1DataStore == null) break label62;
    return false;

    if (this._end2DataStore != null) label62: if (this._end2DataStore.equals(that._end2DataStore)) break label93; 
    label93: return (that._end2DataStore == null);
  }

  public int hashCode()
  {
    int result = (this._end1DataStore != null) ? this._end1DataStore.hashCode() : 0;
    result = 29 * result + ((this._end2DataStore != null) ? this._end2DataStore.hashCode() : 0);
    return result;
  }
}