package com.mercury.topaz.cmdb.server.fcmdb.base.jmx.config;

import com.hp.ucmdb.federationspi.data.query.topology.QueryDefinition;
import com.mercury.topaz.cmdb.server.fcmdb.administration.operation.command.impl.AdministrationCommandReloadClassesCapabilities;
import com.mercury.topaz.cmdb.server.fcmdb.base.jmx.AbstractFcmdbJmx;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl.ConfigUpdateReload;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl.ConfigUpdateReplaceEncryptionKeyFile;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter;
import com.mercury.topaz.cmdb.server.fcmdb.util.XmlSchemaCreator;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.operation.query.impl.ClassModelQueryGetWholeClassModel;
import com.mercury.topaz.cmdb.shared.fcmdb.administration.operation.command.impl.AdministrationCommandDestinationConfigAdd;
import com.mercury.topaz.cmdb.shared.fcmdb.administration.operation.command.impl.AdministrationCommandReloadAndRestartAdapter;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.DestinationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.impl.ConfigDefFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.CmdbPatternIDFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetPattern;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import java.io.File;
import java.net.MalformedURLException;
import java.util.Arrays;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=FCmdb Config Services", description="FCmdb Config Services")
public class ConfigJmxServices extends AbstractFcmdbJmx
{
  @ManagedOperation(description="Load or reload (and start) adapter code base")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer id"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="adapterId", description="Adapter id")})
  public String loadOrReloadCodeBaseForAdapterIdAndStartAdapters(Integer customerID, String adapterId)
  {
    // Byte code:
    //   0: new 2	com/mercury/topaz/cmdb/shared/fcmdb/administration/operation/command/impl/AdministrationCommandReloadAndRestartAdapter
    //   3: dup
    //   4: aload_2
    //   5: invokespecial 3	com/mercury/topaz/cmdb/shared/fcmdb/administration/operation/command/impl/AdministrationCommandReloadAndRestartAdapter:<init>	(Ljava/lang/String;)V
    //   8: astore_3
    //   9: aload_0
    //   10: aload_3
    //   11: aload_1
    //   12: invokevirtual 4	com/mercury/topaz/cmdb/server/fcmdb/base/jmx/config/ConfigJmxServices:invokeOperation	(Lcom/mercury/topaz/cmdb/shared/manage/operation/FrameworkOperation;Ljava/lang/Integer;)Lcom/mercury/topaz/cmdb/shared/manage/CmdbResponse;
    //   15: pop
    //   16: new 5	java/lang/StringBuilder
    //   19: dup
    //   20: invokespecial 6	java/lang/StringBuilder:<init>	()V
    //   23: ldc 7
    //   25: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: aload_2
    //   29: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   32: ldc 9
    //   34: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: invokevirtual 10	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   40: areturn
    //   41: astore 4
    //   43: aload 4
    //   45: iconst_1
    //   46: anewarray 12	java/lang/String
    //   49: dup
    //   50: iconst_0
    //   51: new 5	java/lang/StringBuilder
    //   54: dup
    //   55: invokespecial 6	java/lang/StringBuilder:<init>	()V
    //   58: ldc 7
    //   60: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: aload_2
    //   64: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   67: ldc 13
    //   69: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: invokevirtual 10	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   75: aastore
    //   76: invokestatic 14	com/mercury/topaz/cmdb/server/fcmdb/base/jmx/config/ConfigJmxServices:createStringFromException	(Ljava/lang/Throwable;[Ljava/lang/String;)Ljava/lang/String;
    //   79: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   9	40	41	java/lang/Throwable
  }

  @ManagedOperation(description="Load or reload adapter code base")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer id"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="adapterId", description="Adapter id")})
  public String loadOrReloadCodeBaseForAdapterId(Integer customerID, String adapterId)
  {
    // Byte code:
    //   0: new 2	com/mercury/topaz/cmdb/shared/fcmdb/administration/operation/command/impl/AdministrationCommandReloadAndRestartAdapter
    //   3: dup
    //   4: aload_2
    //   5: invokespecial 3	com/mercury/topaz/cmdb/shared/fcmdb/administration/operation/command/impl/AdministrationCommandReloadAndRestartAdapter:<init>	(Ljava/lang/String;)V
    //   8: astore_3
    //   9: aload_0
    //   10: aload_3
    //   11: aload_1
    //   12: invokevirtual 4	com/mercury/topaz/cmdb/server/fcmdb/base/jmx/config/ConfigJmxServices:invokeOperation	(Lcom/mercury/topaz/cmdb/shared/manage/operation/FrameworkOperation;Ljava/lang/Integer;)Lcom/mercury/topaz/cmdb/shared/manage/CmdbResponse;
    //   15: pop
    //   16: new 5	java/lang/StringBuilder
    //   19: dup
    //   20: invokespecial 6	java/lang/StringBuilder:<init>	()V
    //   23: ldc 7
    //   25: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: aload_2
    //   29: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   32: ldc 9
    //   34: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: invokevirtual 10	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   40: areturn
    //   41: astore 4
    //   43: aload 4
    //   45: iconst_1
    //   46: anewarray 12	java/lang/String
    //   49: dup
    //   50: iconst_0
    //   51: new 5	java/lang/StringBuilder
    //   54: dup
    //   55: invokespecial 6	java/lang/StringBuilder:<init>	()V
    //   58: ldc 7
    //   60: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: aload_2
    //   64: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   67: ldc 13
    //   69: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: invokevirtual 10	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   75: aastore
    //   76: invokestatic 14	com/mercury/topaz/cmdb/server/fcmdb/base/jmx/config/ConfigJmxServices:createStringFromException	(Ljava/lang/Throwable;[Ljava/lang/String;)Ljava/lang/String;
    //   79: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   9	40	41	java/lang/Throwable
  }

  @ManagedOperation(description="Reload federation configuration")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerId", description="Customer id")})
  public String reloadConfiguration(int customerID)
  {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: invokestatic 15	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   5: invokespecial 16	com/mercury/topaz/cmdb/server/fcmdb/base/jmx/config/ConfigJmxServices:privateReloadConfiguration	(Ljava/lang/Integer;)Ljava/lang/String;
    //   8: areturn
    //   9: astore_2
    //   10: aload_0
    //   11: iload_1
    //   12: invokestatic 15	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   15: invokespecial 16	com/mercury/topaz/cmdb/server/fcmdb/base/jmx/config/ConfigJmxServices:privateReloadConfiguration	(Ljava/lang/Integer;)Ljava/lang/String;
    //   18: areturn
    //   19: astore_3
    //   20: aload_3
    //   21: iconst_1
    //   22: anewarray 12	java/lang/String
    //   25: dup
    //   26: iconst_0
    //   27: ldc 18
    //   29: aastore
    //   30: invokestatic 14	com/mercury/topaz/cmdb/server/fcmdb/base/jmx/config/ConfigJmxServices:createStringFromException	(Ljava/lang/Throwable;[Ljava/lang/String;)Ljava/lang/String;
    //   33: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	8	9	java/lang/Exception
    //   10	18	19	java/lang/Exception
  }

  @ManagedOperation(description="Add a new data store")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="adapterId", description="Adapter ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="dataStoreName", description="Data Store name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="hostName", description="Host name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="port", description="Port"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="dburl", description="Database URL"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="userName", description="User name"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="password", description="Password"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="classes", description="Supported classes (comma-separated)"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="queries", description="Supported queries (comma-separated)")})
  public String addDataStore(Integer customerID, String adapterId, String dataStoreName, String hostName, Integer port, String dburl, String userName, String password, String classes, String queries)
  {
    // Byte code:
    //   0: aload_3
    //   1: aload_1
    //   2: invokevirtual 19	java/lang/Integer:intValue	()I
    //   5: aload_2
    //   6: aload 4
    //   8: aload 5
    //   10: aload 6
    //   12: aload 7
    //   14: aload 8
    //   16: aload 10
    //   18: ldc 20
    //   20: invokevirtual 21	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   23: invokestatic 22	java/util/Arrays:asList	([Ljava/lang/Object;)Ljava/util/List;
    //   26: aload 9
    //   28: ldc 20
    //   30: invokevirtual 21	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   33: invokestatic 22	java/util/Arrays:asList	([Ljava/lang/Object;)Ljava/util/List;
    //   36: invokestatic 23	com/mercury/topaz/cmdb/shared/fcmdb/manage/config/definition/impl/ConfigDefFactory:createDestinationConfigDef	(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)Lcom/mercury/topaz/cmdb/shared/fcmdb/manage/config/definition/DestinationConfigDef;
    //   39: astore 11
    //   41: new 24	com/mercury/topaz/cmdb/shared/fcmdb/administration/operation/command/impl/AdministrationCommandDestinationConfigAdd
    //   44: dup
    //   45: aload 11
    //   47: invokespecial 25	com/mercury/topaz/cmdb/shared/fcmdb/administration/operation/command/impl/AdministrationCommandDestinationConfigAdd:<init>	(Lcom/mercury/topaz/cmdb/shared/fcmdb/manage/config/definition/DestinationConfigDef;)V
    //   50: astore 12
    //   52: aload_0
    //   53: aload 12
    //   55: aload_1
    //   56: invokevirtual 4	com/mercury/topaz/cmdb/server/fcmdb/base/jmx/config/ConfigJmxServices:invokeOperation	(Lcom/mercury/topaz/cmdb/shared/manage/operation/FrameworkOperation;Ljava/lang/Integer;)Lcom/mercury/topaz/cmdb/shared/manage/CmdbResponse;
    //   59: pop
    //   60: new 5	java/lang/StringBuilder
    //   63: dup
    //   64: invokespecial 6	java/lang/StringBuilder:<init>	()V
    //   67: ldc 26
    //   69: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: aload_2
    //   73: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: ldc 9
    //   78: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: invokevirtual 10	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   84: areturn
    //   85: astore 11
    //   87: aload 11
    //   89: iconst_1
    //   90: anewarray 12	java/lang/String
    //   93: dup
    //   94: iconst_0
    //   95: new 5	java/lang/StringBuilder
    //   98: dup
    //   99: invokespecial 6	java/lang/StringBuilder:<init>	()V
    //   102: ldc 26
    //   104: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   107: aload_2
    //   108: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: ldc 13
    //   113: invokevirtual 8	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: invokevirtual 10	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   119: aastore
    //   120: invokestatic 14	com/mercury/topaz/cmdb/server/fcmdb/base/jmx/config/ConfigJmxServices:createStringFromException	(Ljava/lang/Throwable;[Ljava/lang/String;)Ljava/lang/String;
    //   123: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	84	85	java/lang/Throwable
  }

  private String privateReloadConfiguration(Integer customerId)
  {
    ConfigUpdateReload configUpdateReload = new ConfigUpdateReload();
    AdministrationCommandReloadClassesCapabilities administrationCommandReloadClassesCapabilities = new AdministrationCommandReloadClassesCapabilities();
    invokeOperation(configUpdateReload, customerId);
    invokeOperation(administrationCommandReloadClassesCapabilities, customerId);
    return "reload was succesful !!!";
  }

  @ManagedOperation(description="Produce XML Schema for a tql. XML with this schema will be used in some target adapters for transformation purposes.")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerId", description="Customer id"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="tqlName", description="Name of the TQL Query")})
  public String createXMLSchemaFromTql(Integer customerId, String tqlName)
  {
    Pattern pattern = getPatternByName(customerId, tqlName);
    QueryDefinition queryDefinition = AdapterFPIConverter.convertPatternToQueryDefinition(pattern);
    CmdbClassModel classModel = classModel(customerId);
    XmlSchemaCreator xsdCreator = new XmlSchemaCreator(queryDefinition, classModel);
    return XmlUtils.convertStringWithXmlTags(xsdCreator.toSchema());
  }

  private CmdbClassModel classModel(Integer customerId) {
    ClassModelQueryGetWholeClassModel op = new ClassModelQueryGetWholeClassModel();
    invokeOperation(op, customerId);
    return op.getClassModel();
  }

  private Pattern getPatternByName(Integer customerId, String tqlName) {
    CmdbPatternID patternID = CmdbPatternIDFactory.createObjectID(tqlName);
    TqlQueryGetPattern getPattern = new TqlQueryGetPattern(patternID);
    invokeOperation(getPattern, customerId);
    return getPattern.getPattern();
  }

  @ManagedOperation(description="Generate a new key file for password encryption.\n Will load the key file into the application and encrypting the passwords using the new keyfile")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerId", description="Customer id")})
  public String generateNewKeyFile(Integer customerId)
  {
    try {
      invokeOperation(new ConfigUpdateReplaceEncryptionKeyFile(), customerId);
    } catch (Exception e) {
      return createStringFromException(e, new String[] { "failed changing key file" });
    }
    return "New keyfile generated and loaded successfully into application.";
  }

  @ManagedOperation(description="Import a new key file for  password encryption.\n Will replace the old key, load the new key file into the application and encrypting the passwords using the new keyfile")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerId", description="Customer id"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="newKeyFileLocation", description="Full path to new key")})
  public String importKeyFile(Integer customerId, String newKeyFileLocation)
  {
    try {
      invokeOperation(new ConfigUpdateReplaceEncryptionKeyFile(new File(newKeyFileLocation).toURL()), customerId);
    } catch (MalformedURLException e) {
      return createStringFromException(e, new String[] { "failed changing key file" });
    }
    return "Keyfile has loaded successfully into the application.";
  }
}