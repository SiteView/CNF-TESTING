package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.FTqlCalculationOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;

public abstract interface FTqlCalculationQuery
{
  public abstract void ftqlCalculationgExecuteQuery(FTqlCalculationManager paramFTqlCalculationManager, CmdbResponse paramCmdbResponse);
}