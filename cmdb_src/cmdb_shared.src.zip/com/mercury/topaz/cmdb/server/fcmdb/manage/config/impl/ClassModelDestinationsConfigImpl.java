package com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassAttributesDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ClassModelDestinationsConfigImpl
  implements ClassModelDestinationsConfig
{
  private Map<String, ClassDestinationsConfig> _classesMap;
  private Map<String, ClassAttributesDestinationsConfig> _classesAttributesMap;

  public ClassModelDestinationsConfigImpl()
  {
    this._classesMap = new HashMap();
    this._classesAttributesMap = new HashMap();
  }

  public ClassModelDestinationsConfigImpl(Collection<ClassDestinationsConfig> classesDestinationConfig, Collection<ClassAttributesDestinationsConfig> classAttributesDestinationsConfigs)
  {
    this._classesMap = new HashMap(classesDestinationConfig.size());
    for (Iterator i$ = classesDestinationConfig.iterator(); i$.hasNext(); ) { ClassDestinationsConfig classDestinationsConfig = (ClassDestinationsConfig)i$.next();
      this._classesMap.put(classDestinationsConfig.getClassName(), classDestinationsConfig);
    }
    this._classesAttributesMap = new HashMap();
    for (i$ = classAttributesDestinationsConfigs.iterator(); i$.hasNext(); ) { ClassAttributesDestinationsConfig classAttributesDestinationsConfig = (ClassAttributesDestinationsConfig)i$.next();
      this._classesAttributesMap.put(classAttributesDestinationsConfig.getClassName(), classAttributesDestinationsConfig);
    }
  }

  public Set<String> getAllExternalClasses()
  {
    return this._classesMap.keySet();
  }

  public Set<String> getAllExternalAttributes(String className) {
    ClassAttributesDestinationsConfig classAttributesDestinationsConfig = (ClassAttributesDestinationsConfig)this._classesAttributesMap.get(className);
    if (classAttributesDestinationsConfig == null)
      return Collections.EMPTY_SET;

    return new HashSet(classAttributesDestinationsConfig.getAttributes());
  }

  public Collection<String> getDestinationsForClass(String className) {
    ClassDestinationsConfig classDestinationsConfig = (ClassDestinationsConfig)this._classesMap.get(className);
    if (classDestinationsConfig != null)
      return classDestinationsConfig.getDestinations();

    return null;
  }

  public Collection<String> getDestinationsForClassAndAttribute(String className, String attribute) {
    ClassAttributesDestinationsConfig classAttributesDestinationsConfig = (ClassAttributesDestinationsConfig)this._classesAttributesMap.get(className);
    if (classAttributesDestinationsConfig != null)
      return classAttributesDestinationsConfig.getDestinations(attribute);

    return null;
  }

  public Iterator<ClassDestinationsConfig> getAllClassDestinationsConfig() {
    return this._classesMap.values().iterator();
  }

  public Iterator<ClassAttributesDestinationsConfig> getAllClassAttributesDestinationConfig() {
    return this._classesAttributesMap.values().iterator();
  }

  public ClassAttributesDestinationsConfig getClassAttributeDestinationConfig(String className) {
    return ((ClassAttributesDestinationsConfig)this._classesAttributesMap.get(className));
  }

  public boolean isEmpty() {
    return ((this._classesMap.isEmpty()) && (this._classesAttributesMap.isEmpty()));
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    ClassModelDestinationsConfigImpl that = (ClassModelDestinationsConfigImpl)o;

    if (this._classesAttributesMap != null) if (this._classesAttributesMap.equals(that._classesAttributesMap)) break label62; 
    else if (that._classesAttributesMap == null)
        break label62;
    return false;

    if (this._classesMap != null) label62: if (this._classesMap.equals(that._classesMap)) break label95;
    label95: return (that._classesMap == null);
  }

  public int hashCode()
  {
    int result = (this._classesMap != null) ? this._classesMap.hashCode() : 0;
    result = 29 * result + ((this._classesAttributesMap != null) ? this._classesAttributesMap.hashCode() : 0);
    return result;
  }
}