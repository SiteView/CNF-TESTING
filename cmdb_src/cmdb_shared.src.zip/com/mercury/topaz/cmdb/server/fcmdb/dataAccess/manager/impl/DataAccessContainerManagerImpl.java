package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.environment.DataAdapterEnvironment;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.hp.ucmdb.federationspi.mappingEngine.MappingEngine;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadSingleWrite;
import com.mercury.topaz.cmdb.server.fcmdb.base.log.FCmdbLogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.ResultStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.impl.AdapterStrategyContext;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.util.DataAdapterEnvironmentUtil;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.query.impl.ConfigQueryGetDestinationConfig;
import com.mercury.topaz.cmdb.server.fcmdb.util.ExceptionConverter;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.base.ParameterizedErrorCode;
import com.mercury.topaz.cmdb.shared.base.ParameterizedErrorCode.ErrorCodeProperty;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessFailedToCreateAdapterException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessFailedToStartAdapterException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessGeneralException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AdapterConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.AdapterConfigDef;
import com.mercury.topaz.cmdb.shared.util.filesystem.traverse.FilesTraverse;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DataAccessContainerManagerImpl extends CmdbSubsystemManagerImpl
  implements DataAccessContainerManager, MultiReadSingleWrite
{
  private static Log _log = LogFactory.getEasyLog(DataAccessContainerManagerImpl.class);
  private Map<String, BasicDataAdapterWrapper> _adapterMap;
  private AdapterStrategyContext _adapterStrategyContext;

  DataAccessContainerManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
    this._adapterMap = new HashMap();
    this._adapterStrategyContext = new AdapterStrategyContext();
  }

  public void startUp() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Federation Data Access Container Manager is started up properly !!!");
  }

  public void shutdown() {
    removeAllDestinations();
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Federation Data Access Manager is shutdown properly !!!");
  }

  public BasicDataAdapterWrapper getStartedBasicDataAdapterWrapper(String destinationId) {
    BasicDataAdapterWrapper dataAdapter = getDataAdapterFromStartedAdaptersMap(destinationId);
    if (dataAdapter == null) {
      DestinationConfig destinationConfig = getDestinationConfigByDestinationId(destinationId);
      if (destinationConfig != null) {
        dataAdapter = addStartAndReturnBasicDataAdapterWrapper(destinationConfig);
      } else {
        _log.error("No adapter for given target: " + destinationId);
        ParameterizedErrorCode errorCode = new ParameterizedErrorCode(ErrorCode.DATA_STORE_DOESNT_EXIST, new ParameterizedErrorCode.ErrorCodeProperty[] { new ParameterizedErrorCode.ErrorCodeProperty("dataStoreName", destinationId) });

        throw new AdapterAccessGeneralException("No adapter for given target: " + destinationId, errorCode);
      }
    }
    return dataAdapter;
  }

  private BasicDataAdapterWrapper getBasicDataAdapterWrapper(DestinationConfig destinationConfig) {
    BasicDataAdapterWrapper dataAdapter = getDataAdapterFromStartedAdaptersMap(destinationConfig.getDestinationId());
    if (dataAdapter == null)
      dataAdapter = createAdapterWrapper(destinationConfig);

    return dataAdapter;
  }

  public BasicDataAdapterWrapper getStartedBasicDataAdapterWrapper(DestinationConfig destinationConfig) {
    BasicDataAdapterWrapper dataAdapter = getDataAdapterFromStartedAdaptersMap(destinationConfig.getDestinationId());
    if (dataAdapter == null)
      dataAdapter = addStartAndReturnBasicDataAdapterWrapper(destinationConfig);

    return dataAdapter;
  }

  private BasicDataAdapterWrapper addStartAndReturnBasicDataAdapterWrapper(DestinationConfig destConfig) {
    BasicDataAdapterWrapper newAdapterWrapper;
    String destinationId = destConfig.getDestinationId();
    if (_log.isDebugEnabled()) {
      _log.debug("the adapter " + destConfig.getDestinationId() + "is not started yet. trying to start");
    }

    if (FCmdbLogFactory.getFcmdbConfigAuditLog().isInfoEnabled())
      FCmdbLogFactory.getFcmdbConfigAuditLog().info("Trying to create Data Adapter: targetId = <" + destinationId + "> destination = " + destConfig);
    try
    {
      newAdapterWrapper = createAdapterWrapper(destConfig);
      if (!(this._adapterStrategyContext.isAdapterExist(destConfig.getAdapterConfig().getAdapterId()))) {
        this._adapterStrategyContext.addAdapterCapabilities(destConfig.getAdapterConfig().getAdapterId(), destConfig.getAdapterConfig().getAdapterCapabilities(), newAdapterWrapper.getBasicDataAdapter());
      }

      if (FCmdbLogFactory.getFcmdbConfigAuditLog().isInfoEnabled())
        FCmdbLogFactory.getFcmdbConfigAuditLog().info("Data Adapter: targetId = <" + destinationId + "> created successfully.");
    }
    catch (Exception e) {
      String errorMessage = "Failed to create adapter <" + destinationId + ">.";
      FCmdbLogFactory.getFcmdbConfigAuditLog().error(errorMessage, e);
      _log.error(errorMessage, e);
      throw new AdapterAccessFailedToCreateAdapterException(errorMessage, e);
    }
    return startAdapter(destinationId, newAdapterWrapper);
  }

  private DestinationConfig getDestinationConfigByDestinationId(String destinationId) {
    ConfigQueryGetDestinationConfig op = new ConfigQueryGetDestinationConfig(destinationId);
    executeOperation(op);
    return op.getDestinationConfig();
  }

  public BasicDataAdapterWrapper createAdapterWrapper(DestinationConfig destinationConfig) {
    AdapterConfig adapterConfig = destinationConfig.getAdapterConfig();
    String adapterId = adapterConfig.getAdapterId();
    ClassLoader adapterClassLoader = createAdapterClassLoader(adapterId);
    return createAdapter(adapterId, adapterConfig.getImplementationClassName(), adapterClassLoader, destinationConfig);
  }

  private BasicDataAdapterWrapper createAdapter(String adapterId, String className, ClassLoader adapterClassLoader, DestinationConfig destinationConfig) throws AdapterAccessGeneralException {
    BasicDataAdapter basicAdapter = createBasicDataAdapter(className, adapterClassLoader);
    DataAdapterEnvironment env = DataAdapterEnvironmentUtil.createDataAdapterEnvironment(destinationConfig);
    return new BasicDataAdapterWrapperImpl(adapterId, basicAdapter, adapterClassLoader, env);
  }

  private BasicDataAdapter createBasicDataAdapter(String className, ClassLoader adapterClassLoader) {
    Class classDefinition;
    try {
      classDefinition = adapterClassLoader.loadClass(className);
      return ((BasicDataAdapter)classDefinition.newInstance());
    } catch (Exception e) {
      FCmdbLogFactory.getFcmdbConfigAuditLog().error("failed to create adaptger class named: " + className, e);
      throw new AdapterAccessGeneralException(e);
    }
  }

  public BasicDataAdapter getBasicDataAdapter(AdapterConfigDef adapterConfigDef) {
    String className = adapterConfigDef.getImplementationClassName();
    ClassLoader classLoader = createAdapterClassLoader(adapterConfigDef.getAdapterId());
    return createBasicDataAdapter(className, classLoader);
  }

  private ClassLoader createAdapterClassLoader(String adapterId) {
    AdapterCodeBaseTraverse adapterCodeBaseTraverse = new AdapterCodeBaseTraverse();
    FilesTraverse.traverse(DataAdapterEnvironmentUtil.createAdapterURL(adapterId), adapterCodeBaseTraverse);
    return new ChildFirstClassLoader(adapterCodeBaseTraverse.getUrls(), BasicDataAdapter.class.getClassLoader());
  }

  private BasicDataAdapterWrapper getDataAdapterFromStartedAdaptersMap(String targetId) {
    return ((BasicDataAdapterWrapper)this._adapterMap.get(targetId));
  }

  private BasicDataAdapterWrapper startAdapter(String targetId, BasicDataAdapterWrapper adapterWrapper) throws AdapterAccessException {
    DestinationConfig destConfig = getDestinationConfigByDestinationId(targetId);
    if (FCmdbLogFactory.getFcmdbConfigAuditLog().isInfoEnabled())
      FCmdbLogFactory.getFcmdbConfigAuditLog().info("Trying to start Data Adapter: targetId = <" + targetId + "> destination = " + destConfig);

    ClassLoader previousClassLoader = Thread.currentThread().getContextClassLoader();
    try {
      BasicDataAdapter newAdapter = adapterWrapper.getBasicDataAdapter();
      Thread.currentThread().setContextClassLoader(adapterWrapper.getAdapterClassLoader());
      newAdapter.start(adapterWrapper.getDataAdapterEnvironment());
      this._adapterMap.put(targetId, adapterWrapper);
      if (FCmdbLogFactory.getFcmdbConfigAuditLog().isInfoEnabled())
        FCmdbLogFactory.getFcmdbConfigAuditLog().info("Data Adapter: targetId = <" + targetId + "> started successfully.");

      BasicDataAdapterWrapper localBasicDataAdapterWrapper = adapterWrapper;

      return localBasicDataAdapterWrapper;
    }
    catch (Throwable e)
    {
      String errorMessage = "Failed to start adapter [" + targetId + "].";
      FCmdbLogFactory.getFcmdbConfigAuditLog().error(errorMessage, e);

      throw new AdapterAccessFailedToStartAdapterException(errorMessage, targetId, e);
    } finally {
      Thread.currentThread().setContextClassLoader(previousClassLoader);
    }
  }

  public BasicDataAdapterWrapper removeOrIgnoreDestination(String destinationId) throws AdapterAccessException {
    if (FCmdbLogFactory.getFcmdbConfigAuditLog().isInfoEnabled())
      FCmdbLogFactory.getFcmdbConfigAuditLog().info("remove Data Adapter: targetId = " + destinationId);

    BasicDataAdapterWrapper adapterToRemove = (BasicDataAdapterWrapper)this._adapterMap.remove(destinationId);
    if (adapterToRemove != null) {
      ClassLoader lastClassLoader = Thread.currentThread().getContextClassLoader();
      Thread.currentThread().setContextClassLoader(adapterToRemove.getAdapterClassLoader());
      try {
        adapterToRemove.getBasicDataAdapter().shutdown();
      } catch (DataAccessException e) {
        DestinationConfig destConfig;
        _log.error("failed to shutdown adapter for destination " + destinationId, e);

        throw ExceptionConverter.createAdapterAccessException(e, destConfig);
      } finally {
        Thread.currentThread().setContextClassLoader(lastClassLoader);
      }
    }
    return adapterToRemove;
  }

  public void removeAllDestinations() throws AdapterAccessException {
    for (Iterator i$ = this._adapterMap.values().iterator(); i$.hasNext(); ) { BasicDataAdapterWrapper dataAdapterWrapper = (BasicDataAdapterWrapper)i$.next();
      try {
        dataAdapterWrapper.getBasicDataAdapter().shutdown();
      } catch (DataAccessException e) {
        FCmdbLogFactory.getFcmdbConfigAuditLog().error("failed on shutdown of adapter " + dataAdapterWrapper.getBasicDataAdapter().getClass(), e);
      }
    }
    this._adapterMap.clear();
  }

  public MappingEngine obtainMappingEngine(String mappingEngineClassName, String srcTargetId, String trgTargetId) {
    StringBuffer errorBuffer = new StringBuffer();

    MappingEngine result = obtainMappingEngine(trgTargetId, mappingEngineClassName, errorBuffer);
    if (result == null)
      result = obtainMappingEngine(srcTargetId, mappingEngineClassName, errorBuffer);

    if (result == null) {
      _log.error("Couldn't load MappingEngine: [" + errorBuffer + "]");
      throw new AdapterAccessGeneralException("cannot load mapping engine class [" + mappingEngineClassName + "] for source data store [" + srcTargetId + "] and target data store [" + trgTargetId + "]: " + errorBuffer);
    }
    return result;
  }

  public MappingEngine obtainMappingEngine(String mappingEngineClassName, DestinationConfig destinationConfig)
  {
    BasicDataAdapterWrapper adapter = getBasicDataAdapterWrapper(destinationConfig);
    MappingEngine mappingEngine = null;
    try {
      mappingEngine = loadMappingEngineForTarget(mappingEngineClassName, adapter);
    } catch (Exception e) {
      _log.error("cannot load mapping engine class [" + mappingEngineClassName + "] for destination data store [" + destinationConfig.getDestinationId() + "]: " + e.getMessage());
    }
    return mappingEngine;
  }

  private MappingEngine obtainMappingEngine(String destinationId, String mappingEngineClassName, StringBuffer errorBuffer) {
    if (!(FtqlUtils.isExternalDataStore(destinationId))) {
      return null;
    }

    BasicDataAdapterWrapper trgDataAdapterWrapper = null;
    try {
      trgDataAdapterWrapper = getStartedBasicDataAdapterWrapper(destinationId);
      if (null == trgDataAdapterWrapper) {
        _log.info("couldn't find destination for <" + destinationId + ">!!");
        errorBuffer.append("couldn't find destination for <").append(destinationId).append(">!!");
        return null;
      }
    } catch (Exception e) {
      _log.info("couldn't find destination for <" + destinationId + ">!! " + e.getMessage());
      errorBuffer.append("couldn't find destination for <").append(destinationId).append(">!! ").append(e.getMessage());
    }
    MappingEngine mappingEngine = null;
    try {
      mappingEngine = loadMappingEngineForTarget(mappingEngineClassName, trgDataAdapterWrapper);
    } catch (Exception e) {
      errorBuffer.append("cannot load mapping engine class [").append(mappingEngineClassName).append("] for destination data store [").append(destinationId).append("]: ").append(e.getMessage());
    }
    return mappingEngine;
  }

  private MappingEngine loadMappingEngineForTarget(String mappingEngineClassName, BasicDataAdapterWrapper basicAdapter) throws NoSuchMethodException, ClassNotFoundException, IllegalAccessException, InvocationTargetException, InstantiationException {
    if (basicAdapter == null)
      throw new IllegalArgumentException("basicAdapter cannot be null!!");
    Class mappingEngineClass = basicAdapter.getAdapterClassLoader().loadClass(mappingEngineClassName);
    Constructor[] constructors = mappingEngineClass.getConstructors();
    boolean foundConstructorWithEnv = false;
    if (constructors != null) {
      Constructor[] arr$ = constructors; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Constructor constructor = arr$[i$];
        Class[] parameters = constructor.getParameterTypes();
        if ((parameters != null) && (parameters.length == 1) && 
          (parameters[0].equals(DataAdapterEnvironment.class))) {
          foundConstructorWithEnv = true;
          break;
        }
      }
    }

    if (foundConstructorWithEnv) {
      constructor = mappingEngineClass.getConstructor(new Class[] { DataAdapterEnvironment.class });
      return ((MappingEngine)constructor.newInstance(new Object[] { basicAdapter.getDataAdapterEnvironment() }));
    }

    Constructor constructor = mappingEngineClass.getConstructor(new Class[0]);
    return ((MappingEngine)constructor.newInstance(new Object[0]));
  }

  public void removeAdapterStrategy(String adapterId)
  {
    this._adapterStrategyContext.removeAdapter(adapterId);
  }

  public CalculationStrategy getCalculationStrategy(String adapterId) {
    return this._adapterStrategyContext.getCalculationStrategy(adapterId);
  }

  public ResultStrategy getResultStrategy(String adapterId) {
    return this._adapterStrategyContext.getResultStrategy(adapterId);
  }

  public String getName() {
    return "Data Access Container Task";
  }
}