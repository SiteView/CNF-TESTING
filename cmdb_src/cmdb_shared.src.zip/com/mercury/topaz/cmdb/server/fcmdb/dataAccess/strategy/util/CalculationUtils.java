package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.util;

import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.layout.CiSimpleLayoutDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.layout.FunctionalLayoutDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.layout.RelationSimpleLayoutDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.topology.OneNodeDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.topology.OneNodeTopologyDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.topology.OneNodeTopologyIdReconciliationDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.topology.OneNodeTopologyPropertyReconciliationDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.topology.PatternDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.topology.PatternTopologyDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.topology.PatternTopologyIdReconciliationDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.topology.PatternTopologyPropertyReconciliationDataAdapter;
import com.hp.ucmdb.federationspi.data.query.reconciliation.IdReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.IdReconciliationObject;
import com.hp.ucmdb.federationspi.data.query.reconciliation.PropertyReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.PropertyReconciliationObject;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationDataFactory;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationObject;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationObjectFactory;
import com.hp.ucmdb.federationspi.data.query.reconciliation.TopologyReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.TopologyReconciliationObject;
import com.hp.ucmdb.federationspi.data.query.reconciliation.VirtualLinkInfo;
import com.hp.ucmdb.federationspi.data.query.result.ExternalResultFactory;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyOneNodeResult;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyPatternResult;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyResult;
import com.hp.ucmdb.federationspi.data.query.topology.Condition;
import com.hp.ucmdb.federationspi.data.query.topology.QueryDefinition;
import com.hp.ucmdb.federationspi.data.query.topology.QueryNode;
import com.hp.ucmdb.federationspi.data.query.topology.Topology;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyFactory;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyQueryDefinition;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyQueryNode;
import com.hp.ucmdb.federationspi.data.query.types.CI;
import com.hp.ucmdb.federationspi.data.query.types.Element;
import com.hp.ucmdb.federationspi.data.query.types.ExternalCiId;
import com.hp.ucmdb.federationspi.data.query.types.ExternalIdFactory;
import com.hp.ucmdb.federationspi.data.query.types.ExternalRelationId;
import com.hp.ucmdb.federationspi.data.query.types.Property;
import com.hp.ucmdb.federationspi.data.query.types.ReconciliationIdFactory;
import com.hp.ucmdb.federationspi.data.query.types.Relation;
import com.hp.ucmdb.federationspi.data.query.types.TopologyCI;
import com.hp.ucmdb.federationspi.data.query.types.TopologyRelation;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.CmdbDataComparator;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.result.ExternalTopologyOneNodeResultImpl;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.result.ExternalTopologyPatternResultImpl;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.types.CIImpl;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.types.PropertyImpl;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.types.RelationImpl;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrapper;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrappers;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.impl.CmdbAttributeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreator;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreatorFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.adapter.util.AdapterLayoutUtils;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessGeneralException;
import com.mercury.topaz.cmdb.shared.fcmdb.ftql.mappingEngine.AbstractMappingEngine;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.ModelLinksFactory;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.graph.object.impl.ModelObjectsFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.function.LayoutFunction;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.function.impl.FunctionLayoutInMemoryCalculator;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.ElementSimpleLayoutImpl;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommandAttributeOrder;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class CalculationUtils
{
  private static Log _log = LogFactory.getEasyLog(CalculationStrategy.class);
  private static final String CMDB_RMI_ADAPTER = "com.mercury.topaz.adapters.cmdb.CmdbRmiAdapter.CmdbRmiAdapter";
  private static final String DATA_STORE_ATTRIBUTE = "data_source";

  private static CmdbObjects getObjectsLayout(FTqlDataAdapter adapter, ModelObjects objects, ElementSimpleLayout layout, String dataStore)
  {
    CiSimpleLayoutDataAdapter ciSimpleLayoutDataAdapter = (CiSimpleLayoutDataAdapter)adapter;
    CmdbObjects resultObjects = CmdbObjectFactory.createObjects();
    try {
      CmdbClassModel classModel = ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();

      Map propertiesMap = extractObjectsAdapterProperties(objects, layout, classModel);

      for (Iterator i$ = propertiesMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
        List externalIds = AdapterFPIConverter.convertModelObjectsToExternalIds((ModelObjects)curEntry.getKey());
        List resultCIs = ciSimpleLayoutDataAdapter.getCisLayout(externalIds, (Collection)curEntry.getValue());
        FederatedPropertyValidator federatedPropertyValidator = new FederatedPropertyValidator();
        verifyCIProperties(resultCIs, classModel, federatedPropertyValidator);
        resultObjects.add(updateDefaultCmdbObjectsPropertiesForLayout(resultCIs, layout, dataStore, classModel));
      }
    } catch (DataAccessException e) {
      throw new AdapterAccessGeneralException("failed to get objects layout", e);
    }
    return resultObjects;
  }

  private static void verifyCIProperties(List<CI> cis, CmdbClassModel classModel, FederatedPropertyValidator federatedPropertyValidator) {
    for (Iterator i$ = cis.iterator(); i$.hasNext(); ) { CI ci = (CI)i$.next();
      CmdbClass curClass = classModel.getClass(ci.getType());
      if (curClass == null)
        throw new AdapterAccessGeneralException("the class " + ci.getType() + " is not exist in class model");

      verifyProperties(ci.properties(), curClass, federatedPropertyValidator);
    }
  }

  private static void verifyProperties(Collection<Property> properties, CmdbClass curClass, FederatedPropertyValidator federatedPropertyValidator) {
    for (Iterator i$ = properties.iterator(); i$.hasNext(); ) { Property property = (Property)i$.next();
      CmdbAttribute attribute = curClass.getAttributeByName(property.getPropertyName());
      if (attribute == null)
        throw new AdapterAccessGeneralException("the attribute " + property.getPropertyName() + " doesn't exist in class " + curClass.getName());

      federatedPropertyValidator.set(attribute, (PropertyImpl)property);
      federatedPropertyValidator.validate();
    }
  }

  private static CmdbObjects getObjectsLayoutForRMIAdapter(FTqlDataAdapter adapter, ModelObjects objects, ElementSimpleLayout layout, String dataStore)
  {
    CiSimpleLayoutDataAdapter ciSimpleLayoutDataAdapter = (CiSimpleLayoutDataAdapter)adapter;
    CmdbObjects resultObjects = CmdbObjectFactory.createObjects();
    try {
      CmdbClassModel classModel = ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();

      Map propertiesMap = extractObjectsAdapterProperties(objects, layout, classModel);
      for (Iterator i$ = propertiesMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
        List externalIds = AdapterFPIConverter.convertModelObjectsToExternalIds((ModelObjects)curEntry.getKey());
        List resultCIs = ciSimpleLayoutDataAdapter.getCisLayout(externalIds, (Collection)curEntry.getValue());
        for (Iterator i$ = resultCIs.iterator(); i$.hasNext(); ) { CI ci = (CI)i$.next();
          ci.setStringProperty("data_source", dataStore);
        }
        resultObjects.add(AdapterFPIConverter.convertCisToCmdbObjects(resultCIs));
      }
    } catch (DataAccessException e) {
      throw new AdapterAccessGeneralException("failed to get objects layout", e);
    }
    return resultObjects;
  }

  private static Map<ModelObjects, Collection<String>> extractObjectsAdapterProperties(ModelObjects objects, ElementSimpleLayout layout, CmdbClassModel classModel) {
    Map resultMap = new HashMap();
    if (layout.isAllLayer()) {
      Map objectsByType = devideObjectsByType(objects);
      for (Iterator i$ = objectsByType.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
        Collection adapterProperties = extractAllClassProperties(classModel, (String)curEntry.getKey());
        resultMap.put(curEntry.getValue(), adapterProperties);
      }
    }
    else {
      Collection adapterProperties = extractAllLayoutKeys(layout);
      resultMap.put(objects, adapterProperties);
    }
    return resultMap;
  }

  private static Collection<String> extractAllLayoutKeys(ElementSimpleLayout layout) {
    Collection adapterProperties = new ArrayList();
    ReadOnlyIterator keysIterator = layout.getKeysIterator();
    while (keysIterator.hasNext())
      adapterProperties.add((String)keysIterator.next());

    return adapterProperties;
  }

  public static CmdbObjects getObjectsLayoutWithAddedCalculatedProperties(FTqlDataAdapter adapter, ModelObjects objects, ElementSimpleLayout layout, String dataStore)
  {
    if ((objects == null) || (objects.size() == 0))
      return CmdbObjectFactory.createObjects();

    if (adapter.getClass().getName().equals("com.mercury.topaz.adapters.cmdb.CmdbRmiAdapter.CmdbRmiAdapter")) {
      return getObjectsLayoutForRMIAdapter(adapter, objects, layout, dataStore);
    }

    if ((layout != null) && (!(layout.isAllLayer())) && (!(layout.isEmpty()))) {
      resultObjects = getObjectsLayoutResutWithCalculatedLayoutByType(adapter, objects, layout, dataStore);
    }
    else
      resultObjects = getObjectsLayout(adapter, objects, layout, dataStore);

    CmdbClassModel classModel = ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
    CmdbObjects resultObjects = AdapterLayoutUtils.updateResultWithCalculatedProperties(resultObjects, layout, classModel);
    return resultObjects;
  }

  public static CmdbLinks getLinksLayoutWithAddedCalculatedProperties(FTqlDataAdapter adapter, ModelLinks modelLinks, ElementSimpleLayout layout, String dataStore) {
    if ((modelLinks == null) || (modelLinks.size() == 0))
      return CmdbLinkFactory.createLinks();

    if (adapter.getClass().getName().equals("com.mercury.topaz.adapters.cmdb.CmdbRmiAdapter.CmdbRmiAdapter")) {
      return getLinksLayoutForRMIAdapter(adapter, modelLinks, layout);
    }

    if ((layout != null) && (!(layout.isAllLayer())) && (!(layout.isEmpty()))) {
      result = getLinksLayoutResutWithCalculatedLayoutByType(adapter, modelLinks, layout, dataStore);
    }
    else
      result = getLinksLayout(adapter, modelLinks, layout, dataStore);

    CmdbClassModel classModel = ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
    CmdbLinks result = AdapterLayoutUtils.updateResultWithCalculatedProperties(result, layout, classModel);
    return result;
  }

  private static CmdbObjects getObjectsLayoutResutWithCalculatedLayoutByType(FTqlDataAdapter adapter, ModelObjects objects, ElementSimpleLayout layout, String dataStore) {
    if (_log.isDebugEnabled())
      _log.debug("getExternalLayoutResutWithCalculatedLayoutByType : objects = " + objects + " layout =" + layout);

    CmdbClassModel classModel = ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
    Map objectsLayoutMap = devideObjectsByLayoutWithCalculatedAttributes(objects, layout, classModel);
    if (_log.isDebugEnabled())
      _log.debug("recieved  map with updated layouts : " + objectsLayoutMap);

    CmdbObjects result = CmdbObjectFactory.createObjects();
    for (Iterator i$ = objectsLayoutMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      CmdbObjects curResult = getObjectsLayout(adapter, (ModelObjects)entry.getValue(), (ElementSimpleLayout)entry.getKey(), dataStore);
      result.add(curResult);
    }
    return result;
  }

  private static CmdbLinks getLinksLayoutResutWithCalculatedLayoutByType(FTqlDataAdapter adapter, ModelLinks links, ElementSimpleLayout layout, String dataStore)
  {
    if (_log.isDebugEnabled())
      _log.debug("getLinksLayoutResutWithCalculatedLayoutByType : links = " + links + " layout =" + layout);

    CmdbClassModel classModel = ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
    Map linksLayoutMap = devideLinksByLayoutWithCalculatedAttributes(links, layout, classModel);
    if (_log.isDebugEnabled())
      _log.debug("recieved  map with updated layouts : " + linksLayoutMap);

    CmdbLinks result = CmdbLinkFactory.createLinks();
    for (Iterator i$ = linksLayoutMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      CmdbLinks curResult = getLinksLayout(adapter, (ModelLinks)entry.getValue(), (ElementSimpleLayout)entry.getKey(), dataStore);
      result.add(curResult);
    }
    return result;
  }

  private static Map<ElementSimpleLayout, ModelObjects> devideObjectsByLayoutWithCalculatedAttributes(ModelObjects objects, ElementSimpleLayout layout, CmdbClassModel classModel)
  {
    Map objectsByType = devideObjectsByType(objects);
    if (_log.isDebugEnabled())
      _log.debug("received objectsByType Map: " + objectsByType);

    Map layoutByType = getUpdatedLayoutsWithCalculatedPropertiesByType(objectsByType.keySet(), layout, classModel);
    if (_log.isDebugEnabled())
      _log.debug("updated layouts by type : " + layoutByType);

    Map objectsByLayoutMap = mergeObjectsBySameLayout(objectsByType, layoutByType);
    return objectsByLayoutMap;
  }

  private static Map<ElementSimpleLayout, ModelLinks> devideLinksByLayoutWithCalculatedAttributes(ModelLinks links, ElementSimpleLayout layout, CmdbClassModel classModel)
  {
    Map linksByType = devideLinksByType(links);
    Map layoutByType = getUpdatedLayoutsWithCalculatedPropertiesByType(linksByType.keySet(), layout, classModel);
    Map linksByLayoutMap = mergeLinksBySameLayout(linksByType, layoutByType);
    return linksByLayoutMap;
  }

  private static Map<String, ElementSimpleLayout> getUpdatedLayoutsWithCalculatedPropertiesByType(Set<String> types, ElementSimpleLayout layout, CmdbClassModel classModel)
  {
    Map layoutByType = new HashMap(types.size());
    for (Iterator i$ = types.iterator(); i$.hasNext(); ) { String type = (String)i$.next();
      ElementSimpleLayout curLayout = AdapterLayoutUtils.getLayoutWithCalculatedProperties(type, layout, classModel);
      layoutByType.put(type, curLayout);
    }
    return layoutByType;
  }

  private static Map<ElementSimpleLayout, ModelObjects> mergeObjectsBySameLayout(Map<String, ModelObjects> objectsByType, Map<String, ElementSimpleLayout> layoutByType) {
    Map objectsByLayout = new HashMap();
    for (Iterator i$ = layoutByType.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curLayoutEntry = (Map.Entry)i$.next();
      ModelObjects objectsForCurType = (ModelObjects)objectsByType.get(curLayoutEntry.getKey());
      if (objectsByLayout.containsKey(curLayoutEntry.getValue())) {
        ModelObjects existedObjects = (ModelObjects)objectsByLayout.get(curLayoutEntry.getValue());
        existedObjects.add(objectsForCurType);
      }
      else {
        objectsByLayout.put(curLayoutEntry.getValue(), objectsForCurType);
      }
    }
    return objectsByLayout;
  }

  private static Map<ElementSimpleLayout, ModelLinks> mergeLinksBySameLayout(Map<String, ModelLinks> linksByType, Map<String, ElementSimpleLayout> layoutByType)
  {
    Map linksByLayout = new HashMap();
    for (Iterator i$ = layoutByType.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curLayoutEntry = (Map.Entry)i$.next();
      ModelLinks linksForCurType = (ModelLinks)linksByType.get(curLayoutEntry.getKey());
      if (linksByLayout.containsKey(curLayoutEntry.getValue())) {
        ModelLinks existedLinks = (ModelLinks)linksByLayout.get(curLayoutEntry.getValue());
        existedLinks.add(linksForCurType);
      }
      else {
        linksByLayout.put(curLayoutEntry.getValue(), linksForCurType);
      }
    }
    return linksByLayout;
  }

  private static Map<String, ModelObjects> devideObjectsByType(ModelObjects objects)
  {
    Map objectsByType = new HashMap();
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { ModelObject curObject = (ModelObject)i$.next();
      ModelObjects curModelObjects = (ModelObjects)objectsByType.get(curObject.getType());
      if (curModelObjects == null) {
        curModelObjects = ModelObjectsFactory.create();
        objectsByType.put(curObject.getType(), curModelObjects);
      }
      curModelObjects.add(curObject);
    }
    return objectsByType;
  }

  private static Map<String, ModelLinks> devideLinksByType(ModelLinks links) {
    Map linksByType = new HashMap();
    for (Iterator i$ = links.iterator(); i$.hasNext(); ) { ModelLink curLink = (ModelLink)i$.next();
      ModelLinks curModelLinks = (ModelLinks)linksByType.get(curLink.getType());
      if (curModelLinks == null) {
        curModelLinks = ModelLinksFactory.createLinks();
        linksByType.put(curLink.getType(), curModelLinks);
      }
      curModelLinks.add(curLink);
    }
    return linksByType;
  }

  private static Map<String, List<Relation>> divideRelationsByTypes(List<Relation> relations) {
    Map relationsByType = new HashMap();
    for (Iterator i$ = relations.iterator(); i$.hasNext(); ) { Relation relation = (Relation)i$.next();
      List curRelations = (List)relationsByType.get(relation.getType());
      if (curRelations == null) {
        curRelations = new ArrayList();
        relationsByType.put(relation.getType(), curRelations);
      }
      curRelations.add(relation);
    }
    return relationsByType; }

  private static Map<String, List<CI>> divideCIsByTypes(List<CI> cis) {
    Map cisByType = new HashMap();
    for (Iterator i$ = cis.iterator(); i$.hasNext(); ) { CI ci = (CI)i$.next();
      List curCis = (List)cisByType.get(ci.getType());
      if (curCis == null) {
        curCis = new ArrayList();
        cisByType.put(ci.getType(), curCis);
      }
      curCis.add(ci);
    }
    return cisByType;
  }

  static CmdbObjects updateDefaultCmdbObjectsPropertiesForLayout(List<CI> resultCIs, ElementSimpleLayout layout, String dataStore, CmdbClassModel classModel) {
    if ((resultCIs == null) || (resultCIs.isEmpty()))
      return CmdbObjectFactory.createEmptyObjects();

    Map cisByType = divideCIsByTypes(resultCIs);
    for (Iterator i$ = cisByType.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
      CI firstCI = (CI)((List)curEntry.getValue()).get(0);
      if (updateDefaultCmdbPropertiesRequiered(firstCI, layout, classModel)) {
        PropertyCreator propertiesCreator = PropertyCreatorFactory.create();
        if (_log.isInfoEnabled())
          _log.info("get Default Cmdb Properties: adding all default properties");

        Collection existedProperties = createExistedPropertiesCollection(firstCI.properties());

        CmdbProperties defaultProperties = createDeafultPropertiesForType((String)curEntry.getKey(), dataStore, classModel, layout, existedProperties, propertiesCreator);

        for (Iterator i$ = ((List)curEntry.getValue()).iterator(); i$.hasNext(); ) { CI curCi = (CI)i$.next();
          CIImpl ciImpl = (CIImpl)curCi;
          ciImpl.addCmdbProperties(defaultProperties);
        }
      }
    }

    CmdbObjects resultObjects = AdapterFPIConverter.convertCisToCmdbObjects(resultCIs);
    return resultObjects;
  }

  static CmdbLinks updateDefaultCmdbLinksPropertiesForLayout(List<Relation> resultRelations, ElementSimpleLayout layout, String dataStore) {
    if ((resultRelations == null) || (resultRelations.isEmpty()))
      return CmdbLinkFactory.createEmptyLinks();

    CmdbClassModel classModel = ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
    Map relationsByType = divideRelationsByTypes(resultRelations);
    for (Iterator i$ = relationsByType.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
      Relation firstRelation = (Relation)((List)curEntry.getValue()).get(0);
      if (updateDefaultCmdbPropertiesRequiered(firstRelation, layout, classModel)) {
        PropertyCreator propertiesCreator = PropertyCreatorFactory.create();
        if (_log.isInfoEnabled()) {
          _log.info("get Default Cmdb Properties: adding all default properties");
        }

        Collection existedProperties = createExistedPropertiesCollection(firstRelation.properties());
        CmdbProperties defaultProperties = createDeafultPropertiesForType((String)curEntry.getKey(), dataStore, classModel, layout, existedProperties, propertiesCreator);

        for (Iterator i$ = ((List)curEntry.getValue()).iterator(); i$.hasNext(); ) { Relation curRelation = (Relation)i$.next();
          RelationImpl curRelationImpl = (RelationImpl)curRelation;
          curRelationImpl.addCmdbProperties(defaultProperties);
        }
      }
    }

    CmdbLinks resultLinks = AdapterFPIConverter.convertRelationsToCmdbLinks(resultRelations);

    return resultLinks;
  }

  private static Collection<String> createExistedPropertiesCollection(Collection<Property> properties) {
    Collection existedProperties = new HashSet(properties.size());
    for (Iterator i$ = properties.iterator(); i$.hasNext(); ) { Property property = (Property)i$.next();
      existedProperties.add(property.getPropertyName());
    }
    return existedProperties;
  }

  private static CmdbProperties createDeafultPropertiesForType(String curType, String dataStore, CmdbClassModel classModel, ElementSimpleLayout layout, Collection<String> existedProperties, PropertyCreator propertiesCreator)
  {
    CmdbProperties defaultProperties;
    CmdbClass curClass = classModel.getClass(curType);

    if (curClass != null) {
      CmdbModifiableAttributes attributes = CmdbAttributeFactory.createAttributes();
      if (layout.isAllLayer()) {
        CmdbAttributes allAttributes = curClass.getAllAttributes();
        ReadOnlyIterator allAttributesIterator = allAttributes.getIterator();
        while (allAttributesIterator.hasNext()) {
          CmdbAttributeDefinition curAttributeDefinition = (CmdbAttributeDefinition)allAttributesIterator.next();
          String curAttributeName = curAttributeDefinition.getName();
          if ((!(existedProperties.contains(curAttributeName))) || (curAttributeName.equals("data_source")))
            attributes.add(curAttributeDefinition);
        }
      }
      else
      {
        ReadOnlyIterator keys = layout.getKeysIterator();
        while (keys.hasNext()) {
          String key = (String)keys.next();
          if ((!(existedProperties.contains(key))) || (key.equals("data_source"))) {
            CmdbAttribute curAttribute = curClass.getAttributeByName(key);
            if (curAttribute != null)
              attributes.add(curAttribute);
          }
        }
      }

      defaultProperties = createDefaultPropertiesForAttributes(curType, dataStore, attributes, propertiesCreator);
    }
    else {
      defaultProperties = CmdbPropertyFactory.createProperties();
    }
    return defaultProperties;
  }

  private static CmdbProperties createDefaultPropertiesForAttributes(String type, String dataStore, CmdbAttributes attributes, PropertyCreator propertiesCreator)
  {
    CmdbProperties defaultProperties = CmdbPropertyFactory.createProperties();
    ReadOnlyIterator attributesIterator = attributes.getIterator();
    while (attributesIterator.hasNext()) {
      CmdbProperty prop;
      CmdbAttribute cmdbAttribute = (CmdbAttribute)attributesIterator.next();

      if (cmdbAttribute.getName().equals("root_class"))
        prop = propertiesCreator.createProperty(cmdbAttribute.getResolvedType(), cmdbAttribute.getName(), type);
      else if (cmdbAttribute.getName().equals("data_source")) {
        prop = propertiesCreator.createProperty(cmdbAttribute.getResolvedType(), cmdbAttribute.getName(), dataStore);
      }
      else {
        prop = propertiesCreator.createProperty(cmdbAttribute.getResolvedType(), cmdbAttribute.getName(), cmdbAttribute.getResolvedDefaultValue());
      }

      defaultProperties.add(prop);
    }
    return defaultProperties;
  }

  private static boolean updateDefaultCmdbPropertiesRequiered(Element curData, ElementSimpleLayout layout, CmdbClassModel classModel)
  {
    if ((layout == null) || ((layout.isEmpty()) && (!(layout.isAllLayer()))))
      return false;

    CmdbClass curClass = classModel.getClass(curData.getType());
    if (layout.isAllLayer()) {
      return (curClass.getAllAttributes().getSize() != curData.propertiesSize());
    }

    int numOfRequiredKeys = 0;
    for (ReadOnlyIterator iterator = layout.getKeysIterator(); iterator.hasNext(); iterator.next())
      ++numOfRequiredKeys;

    return (numOfRequiredKeys != curData.propertiesSize());
  }

  private static CmdbLinks getLinksLayout(FTqlDataAdapter adapter, ModelLinks modelLinks, ElementSimpleLayout layout, String dataStore)
  {
    CmdbLinks resultLinks = CmdbLinkFactory.createLinks();
    try {
      CmdbClassModel classModel = ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
      FederatedPropertyValidator federatedPropertyValidator = new FederatedPropertyValidator();
      Map propertiesMap = extractLinksAdapterProperties(modelLinks, layout, classModel);
      for (Iterator i$ = propertiesMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
        List externalIds = AdapterFPIConverter.convertModelLinksToExternalIds((ModelLinks)curEntry.getKey());
        List resultRelations = ((RelationSimpleLayoutDataAdapter)adapter).getRelationsLayout(externalIds, (Collection)curEntry.getValue());
        verifyRelationProperties(resultRelations, classModel, federatedPropertyValidator);
        resultLinks.add(updateDefaultCmdbLinksPropertiesForLayout(resultRelations, layout, dataStore));
      }
    } catch (DataAccessException e) {
      throw new AdapterAccessGeneralException("failed to get objects layout", e);
    }
    return resultLinks;
  }

  private static void verifyRelationProperties(List<Relation> relations, CmdbClassModel classModel, FederatedPropertyValidator federatedPropertyValidator)
  {
    for (Iterator i$ = relations.iterator(); i$.hasNext(); ) { Relation relation = (Relation)i$.next();
      CmdbClass curClass = classModel.getClass(relation.getType());
      if (curClass == null)
        throw new AdapterAccessGeneralException("the class " + relation.getType() + " is not exist in class model");

      verifyProperties(relation.properties(), curClass, federatedPropertyValidator);
    }
  }

  private static CmdbLinks getLinksLayoutForRMIAdapter(FTqlDataAdapter adapter, ModelLinks modelLinks, ElementSimpleLayout layout) {
    RelationSimpleLayoutDataAdapter relationSimpleLayoutDataAdapter = (RelationSimpleLayoutDataAdapter)adapter;
    CmdbLinks resultObjects = CmdbLinkFactory.createLinks();
    try {
      CmdbClassModel classModel = ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
      Map propertiesMap = extractLinksAdapterProperties(modelLinks, layout, classModel);
      for (Iterator i$ = propertiesMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
        List externalIds = AdapterFPIConverter.convertModelLinksToExternalIds((ModelLinks)curEntry.getKey());
        List resultRelations = relationSimpleLayoutDataAdapter.getRelationsLayout(externalIds, (Collection)curEntry.getValue());
        resultObjects.add(AdapterFPIConverter.convertRelationsToCmdbLinks(resultRelations));
      }
    } catch (DataAccessException e) {
      throw new AdapterAccessGeneralException("failed to get objects layout", e);
    }
    return resultObjects; }

  private static Map<ModelLinks, Collection<String>> extractLinksAdapterProperties(ModelLinks modelLinks, ElementSimpleLayout layout, CmdbClassModel classModel) {
    Map resultMap = new HashMap();

    if (layout.isAllLayer()) {
      Map linksByType = devideLinksByType(modelLinks);
      for (Iterator i$ = linksByType.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
        String type = (String)curEntry.getKey();
        Collection adapterProperties = extractAllClassProperties(classModel, type);
        resultMap.put(curEntry.getValue(), adapterProperties);
      }
    }
    else {
      Collection adapterProperties = extractAllLayoutKeys(layout);
      resultMap.put(modelLinks, adapterProperties);
    }
    return resultMap; }

  private static Collection<String> extractAllClassProperties(CmdbClassModel classModel, String type) {
    CmdbClass curClass = classModel.getClass(type);
    CmdbAttributes cmdbAttributes = curClass.getAllAttributes();
    Collection adapterProperties = new ArrayList(cmdbAttributes.getSize());
    ReadOnlyIterator attributeIterator = cmdbAttributes.getIterator();
    while (attributeIterator.hasNext()) {
      CmdbAttributeDefinition curAttributeDefinition = (CmdbAttributeDefinition)attributeIterator.next();
      adapterProperties.add(curAttributeDefinition.getName());
    }
    return adapterProperties;
  }

  public static CmdbObjects getInMemoryFunctionsLayout(FTqlDataAdapter adapter, ModelObjects groupByObjects, ModelLinks modelLinks, ModelObjects aggregatedObjects, LayoutFunctionWrappers wrappers, CalculationStrategy strategy, String dataStore) throws AdapterAccessException
  {
    CmdbObjects aggregatedObjectsWithProperties;
    ElementSimpleLayout elementSimpleLayout = createElementSimpleLayoutForFunctionLayoutInMemory(wrappers);

    if ((!(elementSimpleLayout.isEmpty())) || (elementSimpleLayout.isAllLayer())) {
      aggregatedObjectsWithProperties = CmdbObjectFactory.createObjects(aggregatedObjects.size());
      aggregatedObjectsWithProperties.add(strategy.getObjectsLayout(adapter, aggregatedObjects, elementSimpleLayout, dataStore));
    } else {
      aggregatedObjectsWithProperties = aggregatedObjects.toCmdbObjects();
    }
    return FunctionLayoutInMemoryCalculator.calculateObjectsFunctionLayout(groupByObjects, modelLinks, aggregatedObjectsWithProperties, wrappers);
  }

  public static ElementSimpleLayout createElementSimpleLayoutForFunctionLayoutInMemory(LayoutFunctionWrappers wrappers) {
    ElementSimpleLayout elementSimpleLayout = new ElementSimpleLayoutImpl();
    for (ReadOnlyIterator wrappersIterator = wrappers.getIterator(); wrappersIterator.hasNext(); ) {
      LayoutFunctionWrapper layoutFunctionWrapper = (LayoutFunctionWrapper)wrappersIterator.next();
      String attributeName = layoutFunctionWrapper.getLayoutFunction().getAttributeName();
      if ((attributeName != null) && (attributeName.length() > 0))
        elementSimpleLayout.addKey(attributeName);
    }

    return elementSimpleLayout;
  }

  public static CmdbObjectIds sortObjectsInMemory(FTqlDataAdapter adapter, ModelObjects objects, CmdbSortCommand sortCommand, CalculationStrategy calculationStrategy, String dataStore) throws AdapterAccessException {
    ElementSimpleLayout elementSimpleLayout = createElementSimpleLayoutFromSortCommand(sortCommand);
    CmdbObjects objectsToSort = calculationStrategy.getObjectsLayout(adapter, objects, elementSimpleLayout, dataStore);
    CmdbObjects sortedObjects = objectsToSort.sort(new CmdbDataComparator(sortCommand));
    return transferCmdbObjectsToCmdbObjectIds(sortedObjects);
  }

  public static CmdbObjectIds sortObjectsInMemory(FTqlDataAdapter adapter, ElementCondition elementCondition, CmdbSortCommand sortCommand, CalculationStrategy strategy, String dataStore) throws AdapterAccessException, DataAccessException
  {
    PatternElementNumber nodeNumber = PatternElementNumberFactory.createElementNumber(1);
    String nodeName = String.valueOf(nodeNumber.getNumber());
    TopologyQueryDefinition topologyQueryDefinition = AdapterFPIConverter.createQueryDefinitionByElementCondition(elementCondition, nodeName);
    ExternalTopologyResult topologyResult = strategy.calculateTopology(adapter, topologyQueryDefinition, null, null, null);
    Collection topologyCIs = AdapterFPIConverter.extractCIsFromExternalTopologyResult(topologyResult, nodeName);
    ModelObjects resultModelObjects = AdapterFPIConverter.convertTopologyCisToModelObjects(topologyCIs);
    return sortObjectsInMemory(adapter, resultModelObjects, sortCommand, strategy, dataStore);
  }

  public static CmdbLinks sortLinksInMemory(FTqlDataAdapter adapter, ModelLinks modelLinks, CmdbSortCommand sortCommand, CalculationStrategy strategy, String dataStore) throws AdapterAccessException
  {
    ElementSimpleLayout elementSimpleLayout = createElementSimpleLayoutFromSortCommand(sortCommand);
    CmdbLinks linksToSort = strategy.getLinksLayout(adapter, modelLinks, elementSimpleLayout, dataStore);
    CmdbLinks sortedLinks = sortCmdbLinks(linksToSort, sortCommand);

    return sortedLinks;
  }

  public static CmdbLinks sortCmdbLinks(CmdbLinks linksToSort, CmdbSortCommand sortCommand)
  {
    ArrayList linksList = new ArrayList(linksToSort.size());
    for (ReadOnlyIterator linksIterator = linksToSort.getLinksIterator(); linksIterator.hasNext(); )
      linksList.add(linksIterator.next());

    Collections.sort(linksList, new CmdbDataComparator(sortCommand));
    CmdbLinks cmdbLinks = CmdbLinkFactory.createLinks(linksList.size());
    for (Iterator i$ = linksList.iterator(); i$.hasNext(); ) { CmdbLink cmdbLink = (CmdbLink)i$.next();
      cmdbLinks.add(cmdbLink);
    }
    return cmdbLinks;
  }

  public static CmdbObjectIds transferCmdbObjectsToCmdbObjectIds(CmdbObjects sortedObjects)
  {
    CmdbObjectIds sortedIds = CmdbObjectIdsFactory.createIdsList(sortedObjects.size());
    ReadOnlyIterator objectsIterator = sortedObjects.getObjectsIterator();
    while (objectsIterator.hasNext())
      sortedIds.add((CmdbObjectID)((CmdbObject)objectsIterator.next()).getID());

    return sortedIds;
  }

  public static ElementSimpleLayout createElementSimpleLayoutFromSortCommand(CmdbSortCommand sortCommand) {
    ElementSimpleLayout layout = new ElementSimpleLayoutImpl();
    ReadOnlyIterator sortCommandAttributesIterator = sortCommand.getAttributeOrderIterator();
    while (sortCommandAttributesIterator.hasNext()) {
      CmdbSortCommandAttributeOrder sortCommandAttributeOrder = (CmdbSortCommandAttributeOrder)sortCommandAttributesIterator.next();
      layout.addKey(sortCommandAttributeOrder.getAttributeName());
    }
    return layout;
  }

  public static TopologyReconciliationData getTopologyReconciliationData(ReconciliationData reconciliationData)
  {
    TopologyReconciliationData topologyReconciliationData = null;
    if (reconciliationData != null)
      if (reconciliationData instanceof TopologyReconciliationData) {
        topologyReconciliationData = (TopologyReconciliationData)reconciliationData;
      }
      else if (reconciliationData instanceof IdReconciliationData) {
        topologyReconciliationData = createTopologyReconciliationDataFromReconciliationIdData((IdReconciliationData)reconciliationData);
      }
      else
        topologyReconciliationData = createTopologyRecocniliationDataFromReconciliationPropertiesData((PropertyReconciliationData)reconciliationData);


    return topologyReconciliationData;
  }

  private static TopologyReconciliationData createTopologyRecocniliationDataFromReconciliationPropertiesData(PropertyReconciliationData propertyReconciliationData) {
    String elementName = String.valueOf(AbstractMappingEngine.PRIMARY_NODE_ELEMENT_NUMBER.getNumber());
    QueryDefinition queryDefinition = createQueryDefintionFromPropertyReconciliationData(propertyReconciliationData, elementName);
    return ReconciliationDataFactory.createTopologyReconciliationData(propertyReconciliationData.getReconciliationClassName(), queryDefinition, new String[] { elementName });
  }

  private static QueryDefinition createQueryDefintionFromPropertyReconciliationData(PropertyReconciliationData reconciliationData, String elementName)
  {
    String reconciliationClassName = reconciliationData.getReconciliationClassName();
    Condition reconciliationCondition = reconciliationData.getReconciliationCondition();
    QueryDefinition queryDefinition = TopologyFactory.createQueryDefinition("tranlated property reconciliation");
    QueryNode queryNode = queryDefinition.addNode(elementName, reconciliationClassName);
    if (reconciliationCondition != null)
      queryNode.setPropertiesCondition(reconciliationCondition);

    queryNode.addProperties(reconciliationData.getReconciliationProperties());
    return queryDefinition;
  }

  private static TopologyReconciliationData createTopologyReconciliationDataFromReconciliationIdData(IdReconciliationData idReconciliationData) {
    String elementName = String.valueOf(AbstractMappingEngine.PRIMARY_NODE_ELEMENT_NUMBER.getNumber());
    QueryDefinition queryDefinition = TopologyFactory.createQueryDefinition("converted id reconciliation to topology");
    QueryNode queryNode = queryDefinition.addNode(elementName, idReconciliationData.getReconciliationClassName());
    if ((idReconciliationData.getIdsCondition() != null) && (idReconciliationData.getIdsCondition().size() > 0)) {
      List externalIds = AdapterFPIConverter.translateReconciliationIdsToExternalIds(idReconciliationData.getIdsCondition(), idReconciliationData.getReconciliationClassName());
      queryNode.setIdsCondition(externalIds);
    }
    return ReconciliationDataFactory.createTopologyReconciliationData(idReconciliationData.getReconciliationClassName(), queryDefinition, new String[] { elementName });
  }

  public static ExternalTopologyResult getOneNodeTopology(FTqlDataAdapter adapter, TopologyQueryDefinition topologyQueryDefinition, ReconciliationData reconciliationData, VirtualLinkInfo virtualLinkInfo) throws DataAccessException {
    if ((topologyQueryDefinition.getNodeAmount() == 1) && (topologyQueryDefinition.getLinkAmount() == 0)) {
      ExternalTopologyOneNodeResult externalTopologyResult;
      TopologyQueryNode node = (TopologyQueryNode)topologyQueryDefinition.getNodes().iterator().next();

      if (reconciliationData == null) {
        externalTopologyResult = ((OneNodeDataAdapter)adapter).getTopology(node);
      }
      else if (adapter instanceof OneNodeTopologyDataAdapter) {
        OneNodeTopologyDataAdapter elementTopologyDataAdapter = (OneNodeTopologyDataAdapter)adapter;
        externalTopologyResult = elementTopologyDataAdapter.getTopologyWithReconciliationData(node, virtualLinkInfo, getTopologyReconciliationData(reconciliationData));
        if (reconciliationData instanceof IdReconciliationData) {
          externalTopologyResult = transformTopologyResultContainIdReconciliationObjects(externalTopologyResult);
        }
        else if (reconciliationData instanceof PropertyReconciliationData)
          externalTopologyResult = transformTopologyResultContainPropertyReconciliationObjects(externalTopologyResult);

      }
      else if (reconciliationData instanceof IdReconciliationData) {
        externalTopologyResult = ((OneNodeTopologyIdReconciliationDataAdapter)adapter).getTopologyWithReconciliationData(node, virtualLinkInfo, (IdReconciliationData)reconciliationData);
      }
      else {
        externalTopologyResult = ((OneNodeTopologyPropertyReconciliationDataAdapter)adapter).getTopologyWithReconciliationData(node, virtualLinkInfo, (PropertyReconciliationData)reconciliationData);
      }

      return externalTopologyResult;
    }

    throw new AdapterAccessGeneralException("The topology calculation  is not supported in adapter " + adapter.getClass().getName());
  }

  public static ExternalTopologyResult getPatternTopology(FTqlDataAdapter adapter, TopologyQueryDefinition topologyQueryDefinition, ReconciliationData reconciliationData, String virtualLinkEndNodeNumber, VirtualLinkInfo virtualLinkInfo)
    throws DataAccessException
  {
    ExternalTopologyPatternResult externalTopologyResult;
    if (reconciliationData == null) {
      externalTopologyResult = ((PatternDataAdapter)adapter).getTopology(topologyQueryDefinition);
    }
    else if (adapter instanceof PatternTopologyDataAdapter) {
      PatternTopologyDataAdapter elementTopologyDataAdapter = (PatternTopologyDataAdapter)adapter;
      externalTopologyResult = elementTopologyDataAdapter.getTopologyWithReconciliationData(topologyQueryDefinition, virtualLinkEndNodeNumber, virtualLinkInfo, getTopologyReconciliationData(reconciliationData));
      if (reconciliationData instanceof IdReconciliationData) {
        externalTopologyResult = transformTopologyResultContainIdReconciliationObjects(externalTopologyResult, virtualLinkEndNodeNumber, topologyQueryDefinition);
      }
      else if (reconciliationData instanceof PropertyReconciliationData)
        externalTopologyResult = transformTopologyResultContainPropertyReconciliationObjects(externalTopologyResult, virtualLinkEndNodeNumber, topologyQueryDefinition);

    }
    else if (reconciliationData instanceof IdReconciliationData) {
      externalTopologyResult = ((PatternTopologyIdReconciliationDataAdapter)adapter).getTopologyWithReconciliationData(topologyQueryDefinition, virtualLinkEndNodeNumber, virtualLinkInfo, (IdReconciliationData)reconciliationData);
    }
    else {
      externalTopologyResult = ((PatternTopologyPropertyReconciliationDataAdapter)adapter).getTopologyWithReconciliationData(topologyQueryDefinition, virtualLinkEndNodeNumber, virtualLinkInfo, (PropertyReconciliationData)reconciliationData);
    }

    return externalTopologyResult;
  }

  private static ExternalTopologyPatternResult transformTopologyResultContainIdReconciliationObjects(ExternalTopologyPatternResult result, String virtualLinkEndNodeName, TopologyQueryDefinition queryDefinition) {
    ExternalTopologyPatternResultImpl resultImpl = (ExternalTopologyPatternResultImpl)result;
    ExternalTopologyPatternResult newResult = ExternalResultFactory.createExternalTopologyResult(queryDefinition);
    Collection objects = resultImpl.getCIsByName(virtualLinkEndNodeName);
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { TopologyCI object = (TopologyCI)i$.next();
      IdReconciliationObject[] transfomedReconciliationObjects = transformTopologyToIdReconciliationObjects(resultImpl.getReconciliationObjectsById((ExternalCiId)object.getId()));
      newResult.addCI(virtualLinkEndNodeName, (ExternalCiId)object.getId(), transfomedReconciliationObjects);
    }

    addTopologyToExternalResult(resultImpl.getTopology(), newResult, virtualLinkEndNodeName);
    return newResult;
  }

  private static void addTopologyToExternalResult(Topology topology, ExternalTopologyPatternResult result, String excludeNodeName) {
    Collection ciElementNames = topology.getCisElementNames();
    for (Iterator i$ = ciElementNames.iterator(); i$.hasNext(); ) { String ciElementName = (String)i$.next();
      if (!(ciElementName.equals(excludeNodeName))) {
        Collection objects = topology.getCIsByName(ciElementName);
        for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { TopologyCI curObject = (TopologyCI)i$.next();
          result.addCI(ciElementName, (ExternalCiId)curObject.getId(), new ReconciliationObject[0]);
        }
      }
    }
    Collection relationElementNames = topology.getRelationsElementNames();
    for (Iterator i$ = relationElementNames.iterator(); i$.hasNext(); ) { String relationElementName = (String)i$.next();
      Collection links = topology.getRelationsByName(relationElementName);
      for (Iterator i$ = links.iterator(); i$.hasNext(); ) { TopologyRelation curLink = (TopologyRelation)i$.next();
        result.addRelation(relationElementName, (ExternalRelationId)curLink.getId());
      }
    }
  }

  private static IdReconciliationObject[] transformTopologyToIdReconciliationObjects(Collection<ReconciliationObject> reconciliationObjects) {
    if (reconciliationObjects == null)
      return null;

    IdReconciliationObject[] resultObjects = new IdReconciliationObject[reconciliationObjects.size()];
    Iterator reconciliationObjectsIterator = reconciliationObjects.iterator();
    for (int i = 0; i < reconciliationObjects.size(); ++i) {
      TopologyReconciliationObject curReconciliationObject = (TopologyReconciliationObject)reconciliationObjectsIterator.next();
      if (curReconciliationObject.getReconciliationTopology().getAllCIs().size() > 1)
        throw new IllegalStateException("Can't transform topology reconciliation Object to Id reconciliation Object since it have more than one objects");

      TopologyCI curObject = (TopologyCI)curReconciliationObject.getReconciliationTopology().getCIsByName(curReconciliationObject.getReconciliationNodeNames()[0]).iterator().next();
      resultObjects[i] = ReconciliationObjectFactory.createIdReconciliationObject(ReconciliationIdFactory.createReconciliationCmdbId(ExternalIdFactory.restoreCmdbCiIDString((ExternalCiId)curObject.getId())));
    }
    return resultObjects;
  }

  private static PropertyReconciliationObject[] transformTopologyToPropertyReconciliationObjects(Collection<ReconciliationObject> reconciliationObjects) {
    if (reconciliationObjects == null)
      return null;

    PropertyReconciliationObject[] resultObjects = new PropertyReconciliationObject[reconciliationObjects.size()];
    for (int i = 0; i < reconciliationObjects.size(); ++i) {
      TopologyReconciliationObject curReconciliationObject = (TopologyReconciliationObject)reconciliationObjects.iterator().next();
      if (curReconciliationObject.getReconciliationTopology().getAllCIs().size() > 1)
        throw new IllegalStateException("Can't transform topology reconciliation Object to property reconciliation Object since it have more than one objects");

      TopologyCI curObject = (TopologyCI)curReconciliationObject.getReconciliationTopology().getCIsByName(curReconciliationObject.getReconciliationNodeNames()[0]).iterator().next();
      Collection properties = curObject.properties();
      resultObjects[i] = ReconciliationObjectFactory.createPropertyReconciliationObject(curObject.getType(), new ArrayList(properties));
    }
    return resultObjects;
  }

  private static ExternalTopologyPatternResult transformTopologyResultContainPropertyReconciliationObjects(ExternalTopologyPatternResult result, String virtualLinkEndNodeName, TopologyQueryDefinition topologyQueryDefinition) {
    ExternalTopologyPatternResultImpl resultImpl = (ExternalTopologyPatternResultImpl)result;
    ExternalTopologyPatternResult newResult = ExternalResultFactory.createExternalTopologyResult(topologyQueryDefinition);

    Collection objects = resultImpl.getCIsByName(virtualLinkEndNodeName);
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { TopologyCI object = (TopologyCI)i$.next();
      PropertyReconciliationObject[] transfomedReconciliationObjects = transformTopologyToPropertyReconciliationObjects(resultImpl.getReconciliationObjectsById((ExternalCiId)object.getId()));
      newResult.addCI(virtualLinkEndNodeName, (ExternalCiId)object.getId(), transfomedReconciliationObjects);
    }

    addTopologyToExternalResult(resultImpl.getTopology(), newResult, virtualLinkEndNodeName);
    return newResult;
  }

  private static ExternalTopologyOneNodeResult transformTopologyResultContainIdReconciliationObjects(ExternalTopologyOneNodeResult result) {
    ExternalTopologyOneNodeResultImpl resultImpl = (ExternalTopologyOneNodeResultImpl)result;
    ExternalTopologyOneNodeResult newResult = ExternalResultFactory.createOneNodeExternalTopologyResult();
    Collection objects = resultImpl.getCIs();
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { TopologyCI object = (TopologyCI)i$.next();
      IdReconciliationObject[] transfomedReconciliationObjects = transformTopologyToIdReconciliationObjects(resultImpl.getReconciliationObjectsById((ExternalCiId)object.getId()));
      newResult.addObject((ExternalCiId)object.getId(), transfomedReconciliationObjects);
    }
    return newResult;
  }

  private static ExternalTopologyOneNodeResult transformTopologyResultContainPropertyReconciliationObjects(ExternalTopologyOneNodeResult result) {
    ExternalTopologyOneNodeResultImpl resultImpl = (ExternalTopologyOneNodeResultImpl)result;
    ExternalTopologyOneNodeResult newResult = ExternalResultFactory.createOneNodeExternalTopologyResult();
    Collection objects = resultImpl.getCIs();
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { TopologyCI object = (TopologyCI)i$.next();
      PropertyReconciliationObject[] transfomedReconciliationObjects = transformTopologyToPropertyReconciliationObjects(resultImpl.getReconciliationObjectsById((ExternalCiId)object.getId()));
      newResult.addObject((ExternalCiId)object.getId(), transfomedReconciliationObjects);
    }
    return newResult;
  }

  public static CmdbObjects getFunctionsLayoutByAdapter(FTqlDataAdapter adapter, ModelObjects groupByObjects, ModelLinks modelLinks, ModelObjects aggregatedObjects, LayoutFunctionWrappers wrappers) throws DataAccessException {
    List grouByIds = AdapterFPIConverter.convertModelObjectsToExternalIds(groupByObjects);
    List relations = AdapterFPIConverter.convertModelLinksToExternalIds(modelLinks);
    List aggregatedIds = AdapterFPIConverter.convertModelObjectsToExternalIds(aggregatedObjects);
    List functionsList = AdapterFPIConverter.convertLayoutFunctionWrappersToLayoutFunctions(wrappers);

    List resultCis = ((FunctionalLayoutDataAdapter)adapter).getFunctionsLayout(grouByIds, relations, aggregatedIds, functionsList);
    return AdapterFPIConverter.convertCisToCmdbObjects(resultCis);
  }
}