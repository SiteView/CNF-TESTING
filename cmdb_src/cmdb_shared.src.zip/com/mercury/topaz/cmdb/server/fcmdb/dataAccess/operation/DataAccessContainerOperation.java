package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.CmdbOperation;

public abstract interface DataAccessContainerOperation extends CmdbOperation
{
  public abstract void dataAccessContainerExecute(DataAccessContainerManager paramDataAccessContainerManager, CmdbResponse paramCmdbResponse)
    throws AdapterAccessException;
}