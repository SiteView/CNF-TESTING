package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.impl.AbstractDataAccessContainerOperation;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.DataAccessContainerQuery;

public abstract class AbstractDataAccessContainerQuery extends AbstractDataAccessContainerOperation
  implements DataAccessContainerQuery
{
}