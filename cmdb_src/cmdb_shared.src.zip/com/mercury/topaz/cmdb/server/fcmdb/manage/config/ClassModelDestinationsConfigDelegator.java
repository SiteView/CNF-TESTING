package com.mercury.topaz.cmdb.server.fcmdb.manage.config;

public abstract interface ClassModelDestinationsConfigDelegator extends ClassModelDestinationsConfig
{
  public abstract void setClassesDestinationsConfig(ClassModelDestinationsConfig paramClassModelDestinationsConfig);

  public abstract ClassModelDestinationsConfig getClassesDestinationsConfig();
}