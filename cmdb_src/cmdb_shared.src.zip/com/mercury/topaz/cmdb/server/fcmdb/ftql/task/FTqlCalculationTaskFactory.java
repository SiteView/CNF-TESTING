package com.mercury.topaz.cmdb.server.fcmdb.ftql.task;

public class FTqlCalculationTaskFactory
{
}