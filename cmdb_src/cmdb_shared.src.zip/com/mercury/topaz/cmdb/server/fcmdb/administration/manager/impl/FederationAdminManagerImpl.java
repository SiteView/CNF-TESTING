package com.mercury.topaz.cmdb.server.fcmdb.administration.manager.impl;

import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadSingleWrite;
import com.mercury.topaz.cmdb.server.base.itc.schedule.Scheduler;
import com.mercury.topaz.cmdb.server.fcmdb.administration.classmodelnotification.FederationConfigClassModelChangeListenerImpl;
import com.mercury.topaz.cmdb.server.fcmdb.administration.manager.FederationAdminManager;
import com.mercury.topaz.cmdb.server.fcmdb.administration.util.ConfigChangesUtil;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ClassCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ClassesCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.impl.ClassesCapabilitiesFactory;
import com.mercury.topaz.cmdb.shared.notification.operation.command.impl.DeploymentCommandRegisterFineGrainedListener;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class FederationAdminManagerImpl extends CmdbSubsystemManagerImpl
  implements FederationAdminManager, MultiReadSingleWrite
{
  private static final String TASK_NAME = "FederationAdminTask";
  public static Set<Integer> customerInUpgrades = Collections.synchronizedSet(new HashSet(5));

  public FederationAdminManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public void startUp() {
    initClassesCapabilities();
    register2ClassModelChanges();
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Federation Admin Manager is started up properly !!!");
  }

  private void initClassesCapabilities() {
    ClassModelDestinationsConfig classModelDestinationsConfig = ConfigChangesUtil.getClassesDestinationConfig();
    ClassesCapabilities classesCapabilities = createDefaultClassesCapabilities(classModelDestinationsConfig);
    ConfigChangesUtil.updateClassCapabilitiesCache(this, classesCapabilities);
    if (!(customerInUpgrades.contains(Integer.valueOf(getCustomerID().getID()))))
      ConfigChangesUtil.reloadClassesCapabilities(this);
  }

  protected void register2ClassModelChanges()
  {
    FederationConfigClassModelChangeListenerImpl classModelChangeListener = new FederationConfigClassModelChangeListenerImpl(getLocalEnvironment().getCustomerID());
    DeploymentCommandRegisterFineGrainedListener deploymentCommandRegisterFineGrainedListener = new DeploymentCommandRegisterFineGrainedListener(classModelChangeListener);

    executeOperation(deploymentCommandRegisterFineGrainedListener);
  }

  public ClassesCapabilities createDefaultClassesCapabilities(ClassModelDestinationsConfig classModelDestinationsConfig) {
    HashMap classesWithCapabilitiesMap = new HashMap();
    if (classModelDestinationsConfig != null) {
      CmdbClassModel classModel = getSynchronizedClassModel();
      Iterator classDestinationsConfigIterator = classModelDestinationsConfig.getAllClassDestinationsConfig();
      while (classDestinationsConfigIterator.hasNext()) {
        ClassDestinationsConfig classDestinationsConfig = (ClassDestinationsConfig)classDestinationsConfigIterator.next();
        ClassCapabilities curClassCapabilities = ConfigChangesUtil.createDefaultClassCapabilities(classDestinationsConfig.getClassName(), classModel);
        classesWithCapabilitiesMap.put(classDestinationsConfig.getClassName(), curClassCapabilities);
      }
    }
    return ClassesCapabilitiesFactory.createClassesCapabilities(classesWithCapabilitiesMap);
  }

  public void shutdown() {
    getLocalEnvironment().getScheduler().removePeriodicTask("FederationAdminTask");
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]:Federation Admin  Manager is shutdown properly !!!");
  }

  public String getName() {
    return "Federation Admin Task";
  }
}