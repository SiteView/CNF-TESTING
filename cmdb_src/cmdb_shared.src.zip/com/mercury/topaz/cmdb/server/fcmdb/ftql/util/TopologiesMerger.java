package com.mercury.topaz.cmdb.server.fcmdb.ftql.util;

import com.hp.ucmdb.federationspi.data.query.topology.QueryDefinition;
import com.hp.ucmdb.federationspi.data.query.topology.QueryLink;
import com.hp.ucmdb.federationspi.data.query.topology.QueryNode;
import com.hp.ucmdb.federationspi.data.query.topology.Topology;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyFactory;
import com.hp.ucmdb.federationspi.data.query.types.ExternalCiId;
import com.hp.ucmdb.federationspi.data.query.types.ExternalIdFactory;
import com.hp.ucmdb.federationspi.data.query.types.ExternalRelationId;
import com.hp.ucmdb.federationspi.data.query.types.Property;
import com.hp.ucmdb.federationspi.data.query.types.TopologyCI;
import com.hp.ucmdb.federationspi.data.query.types.TopologyRelation;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.types.ModifiableElement;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class TopologiesMerger
{
  private static Log log = LogFactory.getEasyLog(TopologiesMerger.class);
  private Topology first;
  private Topology second;
  private QueryDefinition query;
  private String rootName;
  private String id;
  private Topology result;
  private Map<ExternalCiId, ExternalCiId> old2new;

  public TopologiesMerger()
  {
    this.old2new = new HashMap(); }

  public TopologiesMerger first(Topology first) {
    this.first = first;
    return this;
  }

  public TopologiesMerger second(Topology second) {
    this.second = second;
    return this;
  }

  public TopologiesMerger query(QueryDefinition query) {
    this.query = query;
    return this;
  }

  public TopologiesMerger rootName(String rootName) {
    this.rootName = rootName;
    return this;
  }

  public TopologiesMerger id(String id) {
    this.id = id;
    return this;
  }

  public Topology merge() {
    if (log.isDebugEnabled()) {
      log.debug("Merging first: " + this.first + " and second: " + this.second);
    }

    this.result = TopologyFactory.createTopology(this.query);

    mergeCIs();

    mergeRelations();

    return this.result;
  }

  private void mergeRelations() {
    for (Iterator i$ = this.query.getLinkNames().iterator(); i$.hasNext(); ) { String relName = (String)i$.next();
      QueryLink link = (QueryLink)this.query.getLink(relName);
      Collection relations = this.first.getRelationsByName(relName);
      if (!(relations.isEmpty())) {
        addRelations(relations, link);
      } else {
        relations = this.second.getRelationsByName(relName);
        if (!(relations.isEmpty()))
          addRelations(relations, link);
      }
    }
  }

  private void addRelations(Collection<TopologyRelation> relations, QueryLink link)
  {
    Iterator i$ = relations.iterator();
    while (true) { TopologyRelation relation;
      ExternalCiId end1Id;
      ExternalCiId end2Id;
      while (true) { do { if (!(i$.hasNext())) return; relation = (TopologyRelation)i$.next();
          end1Id = (ExternalCiId)this.old2new.get(relation.getEnd1Id());
          end2Id = (ExternalCiId)this.old2new.get(relation.getEnd2Id());

          if ((end1Id == null) && (end2Id != null) && (((QueryNode)link.getEnd1()).getName().equals(this.rootName))) {
            end1Id = (ExternalCiId)((TopologyCI)this.result.getCIsByName(this.rootName).iterator().next()).getId();
            break label155: }  }
        while (end1Id == null); if (end2Id != null)
          break;
      }

      label155: ExternalRelationId newRelId = ExternalIdFactory.createExternalRelationId(relation.getType(), end1Id, end2Id, ((ExternalRelationId)relation.getId()).getProperties());

      TopologyRelation newRelation = this.result.addRelation(link.getName(), newRelId);

      for (Iterator i$ = link.getProperties().iterator(); i$.hasNext(); ) { String p = (String)i$.next();
        newRelation.setPropertyValue(p, relation.getPropertyValue(p));
      }
    }
  }

  private void mergeCIs() {
    Collection nodeNames = this.query.getNodeNames();
    for (Iterator i$ = nodeNames.iterator(); i$.hasNext(); ) { String nodeName = (String)i$.next();
      QueryNode queryNode = (QueryNode)this.query.getNode(nodeName);
      Collection firstCIs = this.first.getCIsByName(nodeName);
      if (!(firstCIs.isEmpty())) {
        if (!(this.rootName.equals(nodeName))) {
          addCis(firstCIs, queryNode);
        }
        else {
          TopologyCI firstRootCI = (TopologyCI)this.first.getCIsByName(this.rootName).iterator().next();
          addCI(queryNode, firstRootCI, this.id);
        }
      } else {
        Collection secondCIs = this.second.getCIsByName(nodeName);
        if (!(secondCIs.isEmpty()))
          addCis(secondCIs, queryNode);
      }
    }
  }

  private void addCis(Collection<TopologyCI> original, QueryNode queryNode)
  {
    for (Iterator i$ = original.iterator(); i$.hasNext(); ) { TopologyCI ci = (TopologyCI)i$.next();
      addCI(queryNode, ci, null);
    }
  }

  private void addCI(QueryNode queryNode, TopologyCI ci, String id)
  {
    TopologyCI newci;
    if (id == null)
      newci = this.result.addCI(queryNode.getName(), (ExternalCiId)ci.getId());
    else
      newci = this.result.addCI(queryNode.getName(), ExternalIdFactory.createExternalCmdbCiId(ci.getType(), id));

    for (Iterator i$ = queryNode.getProperties().iterator(); i$.hasNext(); ) { String p = (String)i$.next();
      Property prop = ci.getPropertyObject(p);
      if (prop != null) {
        ((ModifiableElement)newci).setProperty(p, prop.getPropertyType(), prop.getPropertyValue());
      }
      else
        newci.setPropertyValue(p, ci.getPropertyValue(p));
    }

    this.old2new.put(ci.getId(), newci.getId());
  }

  public TopologiesMerger invert() {
    Topology temp = this.first;
    this.first = this.second;
    this.second = temp;
    return this;
  }
}