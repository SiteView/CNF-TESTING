package com.mercury.topaz.cmdb.server.fcmdb.ftql.calculation.impl;

import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.TopologyReconciliationData;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyResult;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.util.CalculationUtils;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.LinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.DefaultLinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocServerCmdbTqlResult;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocServerTqlResult;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResult;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;

public class CmdbLocalAdapter
{
  public TqlResult invokeLocalCalculationWithoutReconciliation(PatternGraph patternGraph)
  {
    Pattern pattern = PatternDefinitionFactory.createPattern("", "Mercury's Ftql Component", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);
    TqlQueryGetAdHocServerCmdbTqlResult adHocServerTqlResult = new TqlQueryGetAdHocServerCmdbTqlResult(pattern);
    return getTqlResult(adHocServerTqlResult);
  }

  public ExternalTopologyResult invokeLocalAdHocExternalCalc(PatternGraph userGraph, PatternElementNumber virtualLinkEndNodeNumber, ReconciliationData reconciliationData)
  {
    TopologyReconciliationData topologyReconciliationData = CalculationUtils.getTopologyReconciliationData(reconciliationData);
    DataForCalculation dataForCalculation = new DataForCalculation(topologyReconciliationData, virtualLinkEndNodeNumber, userGraph);
    TqlResultMap resultMap = createAndRunUnifiedTqlWithReconciliationData(topologyReconciliationData, dataForCalculation);
    ExternalTopologyResult externalTopologyResult = FederatedPatternCalculatorUtils.createExternalResult(userGraph, reconciliationData, resultMap, dataForCalculation);
    return externalTopologyResult;
  }

  private TqlResultMap createAndRunUnifiedTqlWithReconciliationData(TopologyReconciliationData topologyReconciliationData, DataForCalculation dataForCalculation)
  {
    Pattern trgUserAndMappingCombinedPattern = FederatedPatternCalculatorUtils.integrateUserTqlIntoReconciliationData(topologyReconciliationData, dataForCalculation);
    TqlQueryGetAdHocMap tqlQueryGetAdHocMap = new TqlQueryGetAdHocMap(trgUserAndMappingCombinedPattern, null);
    TqlResultMap resultMap = getTqlResultMap(tqlQueryGetAdHocMap);

    return resultMap;
  }

  private TqlResultMap getTqlResultMap(TqlQueryGetAdHocMap adHocMap)
  {
    ServerApiFacade.executeOperation(adHocMap);

    if (adHocMap.isDividedToChunks()) {
      LinksDictionary linkDictionary = DefaultLinksDictionary.getInstance();
      return FtqlUtils.getResultMapInChunks(adHocMap.getChunkRequest(), linkDictionary);
    }

    TqlResultMap resultMap = adHocMap.getResultMap();

    return resultMap;
  }

  private TqlResult getTqlResult(TqlQueryGetAdHocServerTqlResult adHocServerTqlResult)
  {
    TqlResult result;
    ServerApiFacade.executeOperation(adHocServerTqlResult);

    if (adHocServerTqlResult.isDividedToChunks())
      result = FtqlUtils.getResultInChunks(adHocServerTqlResult.getChunkRequest());
    else
      result = adHocServerTqlResult.getServerTqlResult();

    return result;
  }
}