package com.mercury.topaz.cmdb.server.fcmdb.administration.periodic;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.server.base.itc.schedule.PeriodicTaskable;
import com.mercury.topaz.cmdb.server.fcmdb.administration.operation.FederationAdminOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;

public class FederationAdminPeriodicTaskable
  implements PeriodicTaskable
{
  private FederationAdminOperation operation;
  private CmdbApi cmdbApi;
  private CmdbContext context;
  private String taskName;
  private static final int CHECK_INTERVAL_IN_SEC = 300;

  public FederationAdminPeriodicTaskable(String taskName, FederationAdminOperation operation, CmdbApi cmdbApi, CmdbContext context)
  {
    setOperation(operation);
    setCmdbApi(cmdbApi);
    setContext(context);
    setTaskName(taskName);
  }

  public int getIntervalInSec()
  {
    return 300;
  }

  public void execute() {
    getCmdbApi().executeCMDBOperation(getOperation(), getContext(), false);
  }

  public Object getTaskId() {
    return getTaskName();
  }

  public FederationAdminOperation getOperation() {
    return this.operation;
  }

  void setOperation(FederationAdminOperation operation) {
    this.operation = operation;
  }

  public CmdbApi getCmdbApi() {
    return this.cmdbApi;
  }

  void setCmdbApi(CmdbApi cmdbApi) {
    this.cmdbApi = cmdbApi;
  }

  public CmdbContext getContext() {
    return this.context;
  }

  void setContext(CmdbContext context) {
    this.context = context;
  }

  public String getTaskName() {
    return this.taskName;
  }

  void setTaskName(String taskName) {
    this.taskName = taskName;
  }
}