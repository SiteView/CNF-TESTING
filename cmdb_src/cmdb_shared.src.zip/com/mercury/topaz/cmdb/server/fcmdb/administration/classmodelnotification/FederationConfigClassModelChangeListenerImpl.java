package com.mercury.topaz.cmdb.server.fcmdb.administration.classmodelnotification;

import com.mercury.topaz.cmdb.server.fcmdb.administration.operation.command.impl.AdministrationCommandReloadClassesCapabilitiesForClass;
import com.mercury.topaz.cmdb.shared.classmodel.calculatedlink.CmdbCalculatedLink;
import com.mercury.topaz.cmdb.shared.classmodel.change.manage.AbstractClassModelChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.validlink.CmdbValidLink;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class FederationConfigClassModelChangeListenerImpl extends AbstractClassModelChangeListenerFineGrained
{
  public FederationConfigClassModelChangeListenerImpl(CmdbCustomerID customerID)
  {
    super(customerID);
  }

  public void onAddClass(CmdbClassDefinition cmdbClass)
  {
  }

  public void onRemoveClass(CmdbClassDefinition cmdbClass)
  {
  }

  public void onUpdateClass(CmdbClassDefinition cmdbClass) {
    AdministrationCommandReloadClassesCapabilitiesForClass administrationCommandReloadClassesCapabilitiesForClass = new AdministrationCommandReloadClassesCapabilitiesForClass(cmdbClass);
    executeAsynchronousOperation(administrationCommandReloadClassesCapabilitiesForClass);
  }

  public void onAddValidLink(CmdbValidLink validLink)
  {
  }

  public void onUpdateValidLink(CmdbValidLink validLink)
  {
  }

  public void onRemoveValidLink(CmdbValidLink validLink)
  {
  }

  public void onAddTypeDef(CmdbTypeDef typeDef)
  {
  }

  public void onUpdateTypeDef(CmdbTypeDef typeDef)
  {
  }

  public void onRemoveTypeDef(CmdbTypeDef typeDef)
  {
  }

  public void onAddCalculatedLink(CmdbCalculatedLink calculatedLink)
  {
  }

  public void onRemoveCalculatedLink(CmdbCalculatedLink calculatedLink)
  {
  }

  public void onUpdateCalculatedLink(CmdbCalculatedLink calculatdLink)
  {
  }

  public void onClassesDestinationsConfigChange()
  {
  }

  public void onAddCalculatedValidLink(CmdbValidLink validLink)
  {
  }

  public void onRemoveCalculatedValidLink(CmdbValidLink validLink)
  {
  }

  public void onStartDeployment()
  {
  }

  public void onFinishDeployment()
  {
  }
}