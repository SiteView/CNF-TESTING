package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class ConfigUpdateReload extends AbstractConfigUpdateOperation
{
  public void updateConfigExecute(ConfigUpdateManager configUpdateManager, CmdbResponse cmdbResponse)
    throws CmdbException
  {
    configUpdateManager.reloadFederationConfig();
  }

  public String getOperationName() {
    return "Config Update: Reload";
  }
}