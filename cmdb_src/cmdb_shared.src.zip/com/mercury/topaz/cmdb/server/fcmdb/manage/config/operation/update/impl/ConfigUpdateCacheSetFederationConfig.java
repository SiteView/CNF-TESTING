package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigCacheManager;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateCacheOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class ConfigUpdateCacheSetFederationConfig extends AbstractConfigUpdateCacheOperation
{
  private FederationConfig _federationConfig;

  public ConfigUpdateCacheSetFederationConfig(FederationConfig federationConfig)
  {
    setFedeartionConfig(federationConfig);
  }

  private void setFedeartionConfig(FederationConfig federationConfig) {
    if (federationConfig == null)
      throw new IllegalArgumentException("The federation config is null");

    this._federationConfig = federationConfig;
  }

  public void updateConfigCacheExecute(ConfigCacheManager configCacheManager, CmdbResponse cmdbResponse) {
    configCacheManager.setFederationConfig(getFederationConfig());
  }

  private FederationConfig getFederationConfig() {
    return this._federationConfig;
  }

  public String getOperationName() {
    return "Config Update: Set Federation Config";
  }
}