package com.mercury.topaz.cmdb.server.fcmdb.ftql.util;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStoreClassInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.ElementDataStoresInfo;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.FederatedPatternGraphUtils;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.utils.PatternElementUtils;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Collection;
import java.util.Iterator;

public class IncompatibleIdsRemover
{
  public static PatternGraph removeIncompatibleIds(PatternGraph singleDataSourceGraph, FederatedPatternGraphUtils federatedPatternGraphUtils)
  {
    ModifiablePatternGraph graphWithoutIncompatibleIds = null;
    ReadOnlyIterator graphNodes = singleDataSourceGraph.getNodesIterator();
    while (graphNodes.hasNext()) {
      PatternNode graphNode = (PatternNode)graphNodes.next();
      PatternElementNumber currentNodeNumber = graphNode.getElementNumber();
      Collection nodeDataStoreInfo = federatedPatternGraphUtils.getElementDataStoreInfo(currentNodeNumber).getSupportedDataStoresInfo();
      if (hasIncompatibleIds(graphNode, nodeDataStoreInfo)) {
        if (graphWithoutIncompatibleIds == null)
          graphWithoutIncompatibleIds = singleDataSourceGraph.toModifiableGraph();

        removeIncompatibleIds(graphWithoutIncompatibleIds, currentNodeNumber, (DataStoreClassInfo)nodeDataStoreInfo.iterator().next());
      }
    }
    return getGraphWithoutIncompatibleIds(graphWithoutIncompatibleIds, singleDataSourceGraph);
  }

  private static void removeIncompatibleIds(ModifiablePatternGraph graphWithoutIncompatibleIds, PatternElementNumber nodeNumberToRemoveIncompatibeIds, DataStoreClassInfo nodeToRemoveIncompatibeIdsDataStoreInfo) {
    ModifiablePatternNode nodeToRemoveIncompatibeIds = graphWithoutIncompatibleIds.getModifiableNode(nodeNumberToRemoveIncompatibeIds);
    ElementCondition conditionWithIncompatibleIds = nodeToRemoveIncompatibeIds.getCondition();
    ElementCondition conditionWithoutIncompatibleIds = PatternConditionFactory.createElementConditionWithIdsCondition(conditionWithIncompatibleIds.getClassCondition(), conditionWithIncompatibleIds.getPropertiesCondition(), nodeToRemoveIncompatibeIdsDataStoreInfo.getElementIdsCondition());
    nodeToRemoveIncompatibeIds.setCondition(conditionWithoutIncompatibleIds);
  }

  private static boolean hasIncompatibleIds(PatternNode graphNode, Collection<DataStoreClassInfo> nodeSupportedDataStoresInfo) {
    if (!(PatternElementUtils.hasIdsCondition(graphNode)))
      return false;

    if (nodeSupportedDataStoresInfo.isEmpty())
    {
      return false;
    }
    int nodeIdsConditionSize = graphNode.getCondition().getIdsCondition().getIdsSize();
    DataStoreClassInfo nodeDataStoreClassInfo = (DataStoreClassInfo)nodeSupportedDataStoresInfo.iterator().next();
    int compatibleIdsSize = nodeDataStoreClassInfo.getElementIdsCondition().getIdsSize();

    return (nodeIdsConditionSize != compatibleIdsSize);
  }

  private static PatternGraph getGraphWithoutIncompatibleIds(ModifiablePatternGraph graphWithoutIncompatibleIds, PatternGraph originalGraph) {
    if (graphWithoutIncompatibleIds == null) {
      return originalGraph;
    }

    return graphWithoutIncompatibleIds;
  }
}