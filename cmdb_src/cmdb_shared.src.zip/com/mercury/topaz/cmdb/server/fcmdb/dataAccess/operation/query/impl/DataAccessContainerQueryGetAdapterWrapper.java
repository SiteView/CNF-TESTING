package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessContainerQueryGetAdapterWrapper extends AbstractDataAccessContainerQuery
{
  private DestinationConfig _destinationConfig;
  private BasicDataAdapterWrapper _adapterWrapper;

  public DataAccessContainerQueryGetAdapterWrapper(DestinationConfig destinationConfig)
  {
    setDestinationConfig(destinationConfig);
  }

  public String getOperationName() {
    return "DataAccessContainerQuery: Get Adapter Wrapper";
  }

  public void dataAccessContainerExecute(DataAccessContainerManager dataAccessContainerManager, CmdbResponse response) throws AdapterAccessException {
    setAdapterWrapper(dataAccessContainerManager.createAdapterWrapper(getDestinationConfig()));
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
  }

  private DestinationConfig getDestinationConfig() {
    return this._destinationConfig;
  }

  private void setDestinationConfig(DestinationConfig destinationConfig) {
    this._destinationConfig = destinationConfig;
  }

  public BasicDataAdapterWrapper getAdapterWrapper() {
    return this._adapterWrapper;
  }

  public void setAdapterWrapper(BasicDataAdapterWrapper adapterWrapper) {
    this._adapterWrapper = adapterWrapper;
  }
}