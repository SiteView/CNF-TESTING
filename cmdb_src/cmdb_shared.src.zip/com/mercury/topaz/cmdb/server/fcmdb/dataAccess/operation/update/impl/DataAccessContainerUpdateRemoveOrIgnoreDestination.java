package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.query.impl.ConfigQueryGetDestinationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessContainerUpdateRemoveOrIgnoreDestination extends AbstractDataAccessContainerUpdate
{
  private static Log _log = LogFactory.getEasyLog(DataAccessContainerUpdateRemoveOrIgnoreDestination.class);
  private String _destinationId;

  public DataAccessContainerUpdateRemoveOrIgnoreDestination(String destinationId)
  {
    setDestinationId(destinationId);
  }

  public String getOperationName() {
    return "DataAccessContainerUpdate: Remove Or Ignore Destination";
  }

  public String getDestinationId() {
    return this._destinationId;
  }

  protected void setDestinationId(String destinationId) {
    this._destinationId = destinationId;
  }

  protected DestinationConfig getDestinationConfig(DataAccessAdapterManager dataAccessManager)
  {
    ConfigQueryGetDestinationConfig op = new ConfigQueryGetDestinationConfig(getDestinationId());
    dataAccessManager.executeOperation(op);
    return op.getDestinationConfig();
  }

  public void dataAccessContainerExecute(DataAccessContainerManager dataAccessContainerManager, CmdbResponse response) throws AdapterAccessException {
    try {
      dataAccessContainerManager.removeOrIgnoreDestination(getDestinationId());
    } catch (AdapterAccessException e) {
      _log.error("failed to remove adapter for target " + getDestinationId(), e);
    }
  }
}