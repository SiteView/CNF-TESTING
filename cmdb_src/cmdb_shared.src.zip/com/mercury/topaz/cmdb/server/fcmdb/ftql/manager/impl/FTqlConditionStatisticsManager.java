package com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.fcmdb.base.log.FCmdbLogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.model.util.ClassConnectivityAnalyzer;
import com.mercury.topaz.cmdb.server.tql.calculator.DbQueryData;
import com.mercury.topaz.cmdb.server.tql.calculator.optimizations.condition.grader.impl.ConditionResultSizeAnalyzer;
import com.mercury.topaz.cmdb.server.tql.definition.StartPointPriority;
import com.mercury.topaz.cmdb.server.tql.manager.TqlConditionStatisticsManager;
import com.mercury.topaz.cmdb.server.util.time.CmdbTime;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.impl.CmdbClassModelUtil;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.util.impl.ConcurrentReaderHashMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FTqlConditionStatisticsManager
  implements TqlConditionStatisticsManager
{
  private Map<ElementCondition, DbQueryData> conditionsStatistics;
  private Map<ElementCondition, AverageData> averageVirtualLinksConnected;
  private SettingsReader settings;
  private CmdbClassModel classModel;
  private long lastNonValidRemoval;
  private static Log federatedStatisticsLog = FCmdbLogFactory.getFcmdbStatisticsLog();

  public FTqlConditionStatisticsManager()
  {
    this.conditionsStatistics = new ConcurrentReaderHashMap();
    this.averageVirtualLinksConnected = new HashMap();
    this.settings = ServerApiFacade.getSettingsReader();
    this.classModel = CmdbClassModelUtil.getCurrentClassModel();
    this.lastNonValidRemoval = CmdbTime.currentTimeMillis();
  }

  protected FTqlConditionStatisticsManager(Map<ElementCondition, DbQueryData> conditionsStatistics, Map<ElementCondition, AverageData> averageVirtualLinksConnected, SettingsReader settings, CmdbClassModel classModel)
  {
    this.conditionsStatistics = conditionsStatistics;
    this.averageVirtualLinksConnected = averageVirtualLinksConnected;
    this.settings = settings;
    this.classModel = classModel;
    this.lastNonValidRemoval = CmdbTime.currentTimeMillis();
  }

  public int getTypeCount(ElementClassCondition classCondition) {
    return 1000;
  }

  public void updateTypeCounts()
  {
  }

  public StartPointPriority getStartPointPriority(String className, String attributeName) {
    throw new UnsupportedOperationException("This operation is not supported by FTqlConditionStatisticsManager");
  }

  public void reloadStartPointPriorities() {
    throw new UnsupportedOperationException("This operation is not supported by FTqlConditionStatisticsManager");
  }

  public DbQueryData getQueryPerformance(ElementCondition elementCondition) {
    return ((DbQueryData)this.conditionsStatistics.get(elementCondition));
  }

  public void setQueryPerformance(ElementCondition elementCondition, DbQueryData queryData)
  {
    if (federatedStatisticsLog.isDebugEnabled()) {
      federatedStatisticsLog.debug("got query performance statistic data for condition: " + elementCondition + " " + queryData);
    }

    this.conditionsStatistics.put(elementCondition, queryData);

    if (timeToRemoveNonValid())
      removeNonValidQueryData();
  }

  private boolean timeToRemoveNonValid()
  {
    long currentTime = CmdbTime.currentTimeMillis();
    long timeFromLastNonValidRemoval = currentTime - this.lastNonValidRemoval;

    if (timeFromLastNonValidRemoval > getValidDurationTime()) {
      this.lastNonValidRemoval = currentTime;
      return true;
    }

    return false;
  }

  private long getValidDurationTime()
  {
    int validDurationTimeInMinutes = this.settings.getInt("tql.condition.max.relevant.time.min", 1440);

    return (1000 * validDurationTimeInMinutes);
  }

  public void removeNonValidQueryData()
  {
    ArrayList conditionsWithNonValidData = findConditionsWithNonValidData();
    removeConditionsWithNonValidData(conditionsWithNonValidData);
  }

  private void removeConditionsWithNonValidData(ArrayList<ElementCondition> conditionsWithNonValidData) {
    if (federatedStatisticsLog.isDebugEnabled())
      federatedStatisticsLog.debug("going to remove non valid statistics for conditions: " + conditionsWithNonValidData);

    for (Iterator i$ = conditionsWithNonValidData.iterator(); i$.hasNext(); ) { ElementCondition conditionWithNonValidData = (ElementCondition)i$.next();
      this.conditionsStatistics.remove(conditionWithNonValidData);
    }
  }

  private ArrayList<ElementCondition> findConditionsWithNonValidData() {
    Set statisticsEntries = this.conditionsStatistics.entrySet();
    ArrayList conditionsWithNonValidData = new ArrayList(statisticsEntries.size());
    for (Iterator i$ = statisticsEntries.iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      if (!(((DbQueryData)entry.getValue()).isValid()))
        conditionsWithNonValidData.add(entry.getKey());
    }

    return conditionsWithNonValidData;
  }

  public void updateClassConnectivityData() {
    throw new UnsupportedOperationException("This operation is not supported by FTqlConditionStatisticsManager, you should use updateAverageVirtualLinksConnected in federated tql");
  }

  public ClassConnectivityAnalyzer getClassConnectivityAnalyzer() {
    throw new UnsupportedOperationException("This operation is not supported by FTqlConditionStatisticsManager, you should use getAverageVirtualLinksConnected in federated tql");
  }

  public SettingsReader getLocalSettings() {
    return this.settings;
  }

  public CmdbClassModel getSynchronizedClassModel() {
    return this.classModel; }

  public void startUp() {
  }

  public long getDataStoreAverageTimeForSimilarConditions(ElementCondition condition, int numberOfPreConditionObjects) {
    long averageTimeForSimilarConditions = getDataStoreAverageTimeForSimilarConditionsByStatistics(condition);
    if (averageTimeForSimilarConditions == -1L) {
      if (federatedStatisticsLog.isDebugEnabled())
        federatedStatisticsLog.debug("there are no statistics similar to condition: " + condition + " going to get Data Store Average Time By number of Objects To Retrieve");

      return getDataStoreAverageTimeByObjectsToRetrieve(condition, numberOfPreConditionObjects);
    }
    if (federatedStatisticsLog.isDebugEnabled())
      federatedStatisticsLog.debug("there are statistics similar to condition: " + condition + " returns their avearge " + averageTimeForSimilarConditions);

    return averageTimeForSimilarConditions;
  }

  private long getDataStoreAverageTimeByObjectsToRetrieve(ElementCondition condition, int numberOfPreConditionObjects)
  {
    ConditionResultSizeAnalyzer conditionResultSizeAnalyzer = new ConditionResultSizeAnalyzer(this);
    int numberOfObjectsToRetrieve = conditionResultSizeAnalyzer.getEstimatedResultSizeForCondition(condition, numberOfPreConditionObjects);
    return ()(getEstimatedObjectRetrievalTime(condition) * numberOfObjectsToRetrieve);
  }

  private float getEstimatedObjectRetrievalTime(ElementCondition condition) {
    int localObjectRetrievalTime = 2;
    if (isFederatedElementCondition(condition))
      return (getFederatedObjectsRetrivalFactor() * localObjectRetrievalTime);

    return localObjectRetrievalTime;
  }

  private int getFederatedObjectsRetrivalFactor() {
    return 10;
  }

  private long getDataStoreAverageTimeForSimilarConditionsByStatistics(ElementCondition condition) {
    return -1L;
  }

  protected boolean isFederatedElementCondition(ElementCondition condition) {
    return FtqlUtils.isFederatedElementCondition(condition);
  }

  public float getAverageVirtualLinksConnected(ElementCondition condition) {
    AverageData averageData = (AverageData)this.averageVirtualLinksConnected.get(condition);
    if (averageData == null) {
      if (federatedStatisticsLog.isDebugEnabled())
        federatedStatisticsLog.debug("there is no averageData to condition: " + condition + " going to get average connectivity by name");

      ElementClassCondition classCondition = condition.getClassCondition();
      return getAverageConnectivityByName(classCondition.getClassName(), classCondition.isDerived());
    }

    if (federatedStatisticsLog.isDebugEnabled())
      federatedStatisticsLog.debug("there is averageData to condition " + condition + ": " + AverageData.access$000(averageData));

    return AverageData.access$000(averageData);
  }

  private float getAverageConnectivityByName(String className, boolean derived)
  {
    return 1000.0F;
  }

  public void reportVirtualLinksConnected(ElementCondition condition, int virtualLinksConnectedSize) {
    if (federatedStatisticsLog.isDebugEnabled())
      federatedStatisticsLog.debug("got report over condition " + condition + "virtual Links Connected Size data");

    AverageData currentAverageData = (AverageData)this.averageVirtualLinksConnected.get(condition);
    if (currentAverageData == null) {
      currentAverageData = new AverageData(this, virtualLinksConnectedSize, 1);
      this.averageVirtualLinksConnected.put(condition, currentAverageData);
    }
    else {
      AverageData.access$002(currentAverageData, computeNewAverage(AverageData.access$000(currentAverageData), virtualLinksConnectedSize, AverageData.access$100(currentAverageData)));
      AverageData.access$108(currentAverageData);
    }
  }

  private float computeNewAverage(float currentAverage, int virtualLinksConnectedSize, int numOfSummedObjects) {
    return ((currentAverage * numOfSummedObjects + virtualLinksConnectedSize) / (numOfSummedObjects + 1));
  }

  private class AverageData {
    private float currentAverage;
    private int numOfSummedObjects;

    public AverageData(, float paramFloat, int paramInt) {
      this.currentAverage = paramFloat;
      this.numOfSummedObjects = paramInt;
    }
  }
}