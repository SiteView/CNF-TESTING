package com.mercury.topaz.cmdb.server.fcmdb.manage.config;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public abstract interface ClassModelDestinationsConfig
{
  public abstract Collection<String> getDestinationsForClass(String paramString);

  public abstract Collection<String> getDestinationsForClassAndAttribute(String paramString1, String paramString2);

  public abstract Iterator<ClassDestinationsConfig> getAllClassDestinationsConfig();

  public abstract Iterator<ClassAttributesDestinationsConfig> getAllClassAttributesDestinationConfig();

  public abstract ClassAttributesDestinationsConfig getClassAttributeDestinationConfig(String paramString);

  public abstract Set<String> getAllExternalClasses();

  public abstract Set<String> getAllExternalAttributes(String paramString);

  public abstract boolean isEmpty();
}