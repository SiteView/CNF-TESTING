package com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager;

import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ClassesCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.util.timestamp.CmdbTimeStamp;

public abstract interface ConfigCacheManager extends SubsystemManager
{
  public abstract FederationConfig getFederationConfig();

  public abstract void setFederationConfig(FederationConfig paramFederationConfig);

  public abstract void setClassesCapabilities(ClassesCapabilities paramClassesCapabilities);

  public abstract ClassesCapabilities getClassesCapabilities();

  public abstract boolean isClassesCapabilitiesChanged(CmdbTimeStamp paramCmdbTimeStamp);
}