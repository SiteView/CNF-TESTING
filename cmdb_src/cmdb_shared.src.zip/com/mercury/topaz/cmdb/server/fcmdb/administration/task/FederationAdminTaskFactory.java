package com.mercury.topaz.cmdb.server.fcmdb.administration.task;

public class FederationAdminTaskFactory
{
}