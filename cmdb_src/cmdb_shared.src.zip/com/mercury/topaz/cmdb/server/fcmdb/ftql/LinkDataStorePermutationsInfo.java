package com.mercury.topaz.cmdb.server.fcmdb.ftql;

import java.io.Serializable;
import java.util.Collection;

public abstract interface LinkDataStorePermutationsInfo extends Serializable
{
  public abstract Collection<DataStorePermutationInfo> getDataStorePermutationsInfo();

  public abstract void addDataStorePermutationInfo(DataStorePermutationInfo paramDataStorePermutationInfo);

  public abstract void addDataStorePermutationInfo(String paramString1, String paramString2);
}