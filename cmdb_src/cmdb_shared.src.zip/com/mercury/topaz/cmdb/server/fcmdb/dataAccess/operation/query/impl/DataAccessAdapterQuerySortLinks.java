package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.ResultStrategy;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;

public class DataAccessAdapterQuerySortLinks extends AbstractDataAccessLifeCycleAdapterQuery
{
  private static Log _log = LogFactory.getEasyLog(DataAccessAdapterQuerySortLinks.class);
  private static final String KEY_RESULT_LINKS = "result_links";
  private CmdbSortCommand _sortCommand;
  private ModelLinks _inputLinks;
  private CmdbLinks _resultCmdbLinks;

  public DataAccessAdapterQuerySortLinks(String destinationId, ModelLinks modelLinks, CmdbSortCommand sortCommand)
  {
    super(destinationId);
    setInputLinks(modelLinks);
    setSortCommand(sortCommand);
  }

  protected StringBuilder getOutputInfo()
  {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("result links: ").append(getResultCmdbLinks());
    return stringBuilder;
  }

  protected StringBuilder getInputInfo() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" destination id: ").append(getDestinationId()).append(" model links ").append(getInputLinks()).append(" sort command: ").append(getSortCommand());
    return stringBuilder;
  }

  protected void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws AdapterAccessException, DataAccessException
  {
    CmdbLinks sortedCmdbLinks = sortLinks(dataAccessManager, getInputLinks(), getSortCommand());
    setResultCmdbLinks(sortedCmdbLinks);
    response.addResult("result_links", sortedCmdbLinks);
  }

  private CmdbLinks sortLinks(DataAccessAdapterManager dataAccessManager, ModelLinks modelLinks, CmdbSortCommand sortCommand)
    throws AdapterAccessException, DataAccessException
  {
    BasicDataAdapterWrapper adapterWrapper = getAdapter(dataAccessManager);
    BasicDataAdapter basicDataAdapter = adapterWrapper.getBasicDataAdapter();
    CalculationStrategy calculationStrategy = getCalculationStrategy(dataAccessManager, adapterWrapper.getAdapterId());
    ResultStrategy resultStrategy = getResultStrategy(dataAccessManager, adapterWrapper.getAdapterId());
    CmdbLinks sortedLinks = resultStrategy.sortLinks((FTqlDataAdapter)basicDataAdapter, modelLinks, sortCommand, calculationStrategy, getDestinationId());
    return sortedLinks;
  }

  public String getOperationName() {
    return "DataAccessAdapterQuery: Sort Links";
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    CmdbLinks sortedCmdbLinks = (CmdbLinks)response.getResult("result_links");
    setResultCmdbLinks(sortedCmdbLinks);
  }

  private CmdbSortCommand getSortCommand() {
    return this._sortCommand;
  }

  private void setSortCommand(CmdbSortCommand sortCommand) {
    if (sortCommand == null)
      throw new IllegalArgumentException("sortCommand was null");

    this._sortCommand = sortCommand;
  }

  private ModelLinks getInputLinks() {
    return this._inputLinks;
  }

  private void setInputLinks(ModelLinks inputLinks) {
    if (inputLinks == null)
      throw new IllegalArgumentException("inputLink was null");

    this._inputLinks = inputLinks;
  }

  public CmdbLinks getResultCmdbLinks() {
    return this._resultCmdbLinks;
  }

  private void setResultCmdbLinks(CmdbLinks resultCmdbLinks) {
    if (resultCmdbLinks == null)
      throw new IllegalArgumentException("resultCmdbLinks was null");

    this._resultCmdbLinks = resultCmdbLinks;
  }
}