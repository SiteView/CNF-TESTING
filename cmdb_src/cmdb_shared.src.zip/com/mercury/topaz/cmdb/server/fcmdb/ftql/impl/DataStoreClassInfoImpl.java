package com.mercury.topaz.cmdb.server.fcmdb.ftql.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStoreClassInfo;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;

class DataStoreClassInfoImpl
  implements DataStoreClassInfo
{
  private String _dataStore;
  private String _className;
  private ElementIdsCondition _ids;

  DataStoreClassInfoImpl(String dataStore, String className)
  {
    this._dataStore = dataStore;
    this._className = className;
    this._ids = null;
  }

  public DataStoreClassInfoImpl(String dataStore, String className, ElementIdsCondition ids) {
    this._dataStore = dataStore;
    this._className = className;
    this._ids = ids;
  }

  public String getDataStore()
  {
    return this._dataStore;
  }

  public String getClassName() {
    return this._className;
  }

  public ElementIdsCondition getElementIdsCondition() {
    return this._ids;
  }

  public boolean equals(Object o)
  {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    DataStoreClassInfoImpl that = (DataStoreClassInfoImpl)o;

    if (this._className != null) if (this._className.equals(that._className)) break label62; 
    else if (that._className == null) break label62;
    return false;

    if (this._dataStore != null) label62: if (this._dataStore.equals(that._dataStore)) break label95; 
    else if (that._dataStore == null) break label95;
    return false;

    if (this._ids != null) label95: if (this._ids.equals(that._ids)) break label128;
    label128: return (that._ids == null);
  }

  public int hashCode()
  {
    int result = (this._dataStore != null) ? this._dataStore.hashCode() : 0;
    result = 29 * result + ((this._className != null) ? this._className.hashCode() : 0);
    result = 29 * result + ((this._ids != null) ? this._ids.hashCode() : 0);
    return result;
  }
}