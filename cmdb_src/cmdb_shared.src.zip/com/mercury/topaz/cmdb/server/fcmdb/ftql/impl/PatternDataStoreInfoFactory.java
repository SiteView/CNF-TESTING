package com.mercury.topaz.cmdb.server.fcmdb.ftql.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStoreAttributeInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStoreClassInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStorePermutationInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.ElementDataStoresInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.LinkDataStorePermutationsInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.PatternDataStoresInfo;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;

public class PatternDataStoreInfoFactory
{
  public static PatternDataStoresInfo createPatternDataStoresInfo()
  {
    return new PatternDataStoresInfoImpl();
  }

  public static ElementDataStoresInfo createElementDataStoresInfo(String ucmdbClassName) {
    return new ElementDataStoresInfoImpl(ucmdbClassName); }

  public static DataStoreClassInfo createDataStoreClassInfo(String dataStore, String className) {
    return new DataStoreClassInfoImpl(dataStore, className);
  }

  public static DataStoreClassInfo createDataStoreClassInfo(String dataStore, String className, ElementIdsCondition ids)
  {
    return new DataStoreClassInfoImpl(dataStore, className, ids);
  }

  public static LinkDataStorePermutationsInfo createLinkDataStorePermutationsInfo() {
    return new LinkDataStorePermutationsInfoImpl(); }

  public static DataStorePermutationInfo createDataStorePermutationInfo(String end1DataStore, String end2DataStore) {
    return new DataStorePermutationInfoImpl(end1DataStore, end2DataStore);
  }

  public static DataStoreAttributeInfo createDataStoreAttributeInfo(String className, String attributeName, String dataStore) {
    return new DataStoreAttributeInfoImpl(className, attributeName, dataStore);
  }
}