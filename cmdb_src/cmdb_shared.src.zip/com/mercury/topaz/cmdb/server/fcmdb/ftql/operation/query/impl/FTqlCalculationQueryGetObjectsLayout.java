package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetObjectsLayout;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.model.operation.query.ModelQueryGetObjectsLayout;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.graph.object.impl.ModelObjectsFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.EmptyCmdbObjects;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FTqlCalculationQueryGetObjectsLayout extends AbstractFTqlCalculationQuery
  implements ModelQueryGetObjectsLayout
{
  private ElementSimpleLayout _objectLayout;
  private ModelObjects _objects;
  private CmdbObjects _outgoingObjects;
  private static String RESULT_KEY = "result_key";

  public FTqlCalculationQueryGetObjectsLayout(ElementSimpleLayout objectLayout, ModelObject object)
  {
    setObjectLayout(objectLayout);
    ModelObjects modelObjects = ModelObjectsFactory.create();
    modelObjects.add(object);
    setObjects(modelObjects);
  }

  public FTqlCalculationQueryGetObjectsLayout(ElementSimpleLayout objectLayout, ModelObjects objects)
  {
    setObjectLayout(objectLayout);
    setObjects(objects);
  }

  public String getOperationName()
  {
    return "FTql Calculation Query: Get Objects Layout";
  }

  public void ftqlCalculationgExecuteQuery(FTqlCalculationManager fTqlCalculationManager, CmdbResponse cmdbResponse)
  {
    CmdbObjects resultObjects;
    if ((getObjects() == null) || (getObjects().size() == 0)) {
      resultObjects = EmptyCmdbObjects.getInstance();
    }
    else {
      Map modelObjectsByDataSourceMap = FtqlUtils.classifyByDataSource(getObjects());
      resultObjects = CmdbObjectFactory.createObjects();
      for (Iterator i$ = modelObjectsByDataSourceMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        resultObjects.add(getObjectsLayout(fTqlCalculationManager, (String)entry.getKey(), (ModelObjects)entry.getValue(), getObjectLayout()));
      }
    }
    setOutgoingObjects(resultObjects);
    cmdbResponse.addResult(RESULT_KEY, resultObjects);
  }

  private CmdbObjects getObjectsLayout(FTqlCalculationManager fTqlCalculationManage, String dataStore, ModelObjects objects, ElementSimpleLayout layout) throws AdapterAccessException
  {
    if (!(FtqlUtils.isExternalDataStore(dataStore))) {
      ModelQueryGetObjectsLayout modelQueryGetObjectsLayout = ModelQueryFactory.getInternalModelQueryGetObjectsLayoutOperation(layout, objects);
      fTqlCalculationManage.executeOperation(modelQueryGetObjectsLayout);
      return modelQueryGetObjectsLayout.getOutgoingObjects();
    }
    DataAccessAdapterQueryGetObjectsLayout getObjectsLayout = new DataAccessAdapterQueryGetObjectsLayout(dataStore, layout, objects);
    fTqlCalculationManage.executeOperation(getObjectsLayout);
    return getObjectsLayout.getOutgoingObjects();
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setOutgoingObjects((CmdbObjects)response.getResult(RESULT_KEY));
  }

  private ElementSimpleLayout getObjectLayout()
  {
    return this._objectLayout;
  }

  private void setObjectLayout(ElementSimpleLayout objectLayout) {
    this._objectLayout = objectLayout;
  }

  public CmdbObjects getOutgoingObjects()
  {
    return this._outgoingObjects;
  }

  private void setOutgoingObjects(CmdbObjects outgoingObjects) {
    this._outgoingObjects = outgoingObjects;
  }

  private ModelObjects getObjects() {
    return this._objects;
  }

  private void setObjects(ModelObjects objects) {
    this._objects = objects;
  }
}