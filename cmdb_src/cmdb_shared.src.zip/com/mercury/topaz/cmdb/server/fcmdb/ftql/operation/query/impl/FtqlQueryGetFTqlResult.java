package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.FtqlQueryAdHocCalculator;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.FederatedPatternGraphUtils;
import com.mercury.topaz.cmdb.server.tql.definition.PatternCompiler;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResult;

public class FtqlQueryGetFTqlResult extends AbstractFTqlCalculationQuery
{
  private static final String KEY_FTQL_RESULT = "ftql_result";
  private PatternCompiler patternCompiler;
  private PatternLayout requiredLayout;
  private FederatedPatternGraphUtils graphFederatedUtils;
  private TqlResult ftqlResult;

  public FtqlQueryGetFTqlResult(PatternCompiler patternCompiler, PatternLayout requiredLayout, FederatedPatternGraphUtils graphFederatedUtils)
  {
    this.patternCompiler = patternCompiler;
    this.requiredLayout = requiredLayout;
    this.graphFederatedUtils = graphFederatedUtils;
  }

  public String getOperationName() {
    return "Ftql query: get ftql result for federated pattern: " + this.patternCompiler.getPattern().getName();
  }

  public void ftqlCalculationgExecuteQuery(FTqlCalculationManager fTqlCalculationManager, CmdbResponse cmdbResponse) {
    TqlResult ftqlResult = getFtqlResult(fTqlCalculationManager);
    setFtqlResult(ftqlResult);
    cmdbResponse.addResult("ftql_result", ftqlResult);
  }

  private TqlResult getFtqlResult(FTqlCalculationManager fTqlCalculationManager) {
    FtqlQueryAdHocCalculator calculator = new FtqlQueryAdHocCalculator(this.patternCompiler, this.requiredLayout, this.graphFederatedUtils);
    return calculator.calculateTql(fTqlCalculationManager);
  }

  private void setFtqlResult(TqlResult ftqlResult) {
    this.ftqlResult = ftqlResult;
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    TqlResult ftqlResult = (TqlResult)response.getResult("ftql_result");
    setFtqlResult(ftqlResult);
  }

  public TqlResult getFtqlResult() {
    return this.ftqlResult;
  }
}