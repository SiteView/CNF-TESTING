package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ModifiableClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl.ClassDestinationsConfigFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.util.ConfigUtil;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.DestinationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.ModifiableFederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateFederationConfgOperation;

public class ConfigUpdateDestinationConfigUpdate extends AbstractConfigUpdateFederationConfgOperation
{
  private DestinationConfigDef destinationConfigDef;

  public ConfigUpdateDestinationConfigUpdate(DestinationConfigDef destinationConfigDef)
  {
    setDestinationConfigDef(destinationConfigDef);
  }

  public String getOperationName() {
    return "Config Update: Destination Config Update";
  }

  private DestinationConfigDef getDestinationConfigDef()
  {
    return this.destinationConfigDef;
  }

  private void setDestinationConfigDef(DestinationConfigDef destinationConfigDef) {
    this.destinationConfigDef = destinationConfigDef;
  }

  protected void updateConfig(ModifiableFederationConfigDef federationConfigDef, ConfigUpdateManager configUpdateManager) {
    String destinationId = getDestinationConfigDef().getDestinationId();
    DestinationConfigDef prevDestinationConfigDef = ConfigUtil.getDestinationConfigDefById(federationConfigDef, destinationId);
    federationConfigDef.updateDestinationConfigDef(getDestinationConfigDef());
    ModifiableClassModelDestinationsConfig modifiableClassesDestinationsConfig = ClassDestinationsConfigFactory.createModifiableClassesDestinationsConfig(getClassesDestinationsConfig());
    boolean wasChanged = ConfigUtil.updateClassModelDestinationsConfig(modifiableClassesDestinationsConfig, prevDestinationConfigDef, getDestinationConfigDef());
    if (wasChanged) {
      ClassModelDestinationsConfig classModelDestinationsConfig = ClassDestinationsConfigFactory.createReadOnlyClassesDestinationsConfig(modifiableClassesDestinationsConfig);
      ConfigUtil.updateClassModelDestinationsConfigCache(classModelDestinationsConfig);
    }
    ConfigUtil.updateUcmdbSupportedClases(federationConfigDef, prevDestinationConfigDef, getDestinationConfigDef(), modifiableClassesDestinationsConfig);
  }
}