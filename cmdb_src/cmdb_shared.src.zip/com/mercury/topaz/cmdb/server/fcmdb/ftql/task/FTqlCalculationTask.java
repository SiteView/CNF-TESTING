package com.mercury.topaz.cmdb.server.fcmdb.ftql.task;

public class FTqlCalculationTask
{
  public static final String NAME = "FTql Calculation Task";
}