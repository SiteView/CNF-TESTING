package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.command.impl;

import com.hp.ucmdb.federationspi.adapter.replication.TargetDataAdapter;
import com.hp.ucmdb.federationspi.data.query.topology.QueryDefinition;
import com.hp.ucmdb.federationspi.data.replication.ReplicationLayoutResultActionData;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.query.impl.ConfigQueryGetDestinationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessAdapterCommandUpdateDestination extends AbstractDataAccessLifeCycleAdapterCommand
{
  private final String _destinationId;
  private final ReplicationLayoutResultActionData _actionData;
  private final QueryDefinition _queryDefinition;
  private final String _updatingAdapterId;
  private final boolean _isInstancesFlow;
  private static Log _log = LogFactory.getEasyLog(DataAccessAdapterCommandUpdateDestination.class);

  public DataAccessAdapterCommandUpdateDestination(String destinationId, QueryDefinition queryDefinition, ReplicationLayoutResultActionData actionData, String updatingAdapterId, boolean instancesFlow)
  {
    this._destinationId = destinationId;
    this._queryDefinition = queryDefinition;
    this._actionData = actionData;
    this._updatingAdapterId = updatingAdapterId;
    this._isInstancesFlow = instancesFlow;
  }

  public ReplicationLayoutResultActionData getDataForUpdate() {
    return this._actionData;
  }

  public String getOperationName() {
    return "Data Access Operation: update operation";
  }

  public void doDataAccessExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws DataAccessException
  {
    _log.debug("Execute DataAccessAdapterCommandUpdateDestination for targetId = " + getDestinationId());
    TargetDataAdapter adapter = (TargetDataAdapter)getAdapter(dataAccessManager).getBasicDataAdapter();

    adapter.updateData(getQueryDefinition(), getDataForUpdate(), getUpdatingAdapterId(), isInstancesFlow());
  }

  protected DestinationConfig getDestinationConfig(DataAccessAdapterManager dataAccessManager) {
    ConfigQueryGetDestinationConfig op = new ConfigQueryGetDestinationConfig(getDestinationId());
    dataAccessManager.executeOperation(op);
    return op.getDestinationConfig();
  }

  public String getDestinationId() {
    return this._destinationId;
  }

  public QueryDefinition getQueryDefinition() {
    return this._queryDefinition;
  }

  public String getUpdatingAdapterId() {
    return this._updatingAdapterId;
  }

  private boolean isInstancesFlow() {
    return this._isInstancesFlow;
  }
}