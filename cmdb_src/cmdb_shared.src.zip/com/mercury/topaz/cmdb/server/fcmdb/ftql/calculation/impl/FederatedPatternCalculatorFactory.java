package com.mercury.topaz.cmdb.server.fcmdb.ftql.calculation.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.calculation.FederatedPatternCalculator;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.impl.FTqlConditionStatisticsManager;

public class FederatedPatternCalculatorFactory
{
  public static FederatedPatternCalculator getFederatedPatternCalculator(FTqlConditionStatisticsManager statistics)
  {
    return new FederatedPatternCalculatorImpl(statistics);
  }
}