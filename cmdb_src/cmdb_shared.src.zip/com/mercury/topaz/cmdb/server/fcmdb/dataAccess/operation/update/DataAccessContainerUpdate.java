package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.update;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.DataAccessContainerOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;

public abstract interface DataAccessContainerUpdate
{
}