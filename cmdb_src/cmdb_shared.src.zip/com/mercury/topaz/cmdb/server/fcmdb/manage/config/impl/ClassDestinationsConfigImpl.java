package com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassDestinationsConfig;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class ClassDestinationsConfigImpl
  implements ClassDestinationsConfig, Serializable
{
  private String _className;
  private Collection<String> _destinations = new HashSet();

  public ClassDestinationsConfigImpl(ClassDestinationsConfig classDestinationsConfig)
  {
    setClassName(classDestinationsConfig.getClassName());
    Collection destinations = classDestinationsConfig.getDestinations();
    for (Iterator i$ = destinations.iterator(); i$.hasNext(); ) { String destination = (String)i$.next();
      addDestination(destination);
    }
  }

  ClassDestinationsConfigImpl(String className)
  {
    setClassName(className);
  }

  ClassDestinationsConfigImpl(String className, Collection<String> destinations) {
    setClassName(className);
    for (Iterator i$ = destinations.iterator(); i$.hasNext(); ) { String destination = (String)i$.next();
      addDestination(destination);
    }
  }

  private void addDestinationObject(Object destination) {
    addDestination((String)destination);
  }

  public boolean removeDestination(String destination)
  {
    return getDestinations().remove(destination);
  }

  protected void setClassName(String className) {
    if ((className == null) || (className.length() == 0))
      throw new IllegalArgumentException("className is null or empty ");

    this._className = className;
  }

  public String getClassName() {
    return this._className;
  }

  public Collection<String> getDestinations() {
    return this._destinations;
  }

  public Iterator getDestinationsIterator() {
    return this._destinations.iterator();
  }

  public int getDestinationsSize() {
    return this._destinations.size();
  }

  public boolean containsDestination(String destination) {
    return this._destinations.contains(destination);
  }

  public boolean isEmpty() {
    return ((this._destinations == null) || (this._destinations.isEmpty()));
  }

  public void addDestination(String destination) {
    this._destinations.add(destination);
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if ((o == null) || (super.getClass() != o.getClass())) return false;

    ClassDestinationsConfigImpl that = (ClassDestinationsConfigImpl)o;

    if (this._className != null) if (this._className.equals(that._className)) break label62; 
    else if (that._className == null) break label62; 
    return false;
    if (this._destinations != null) label62: if (this._destinations.equals(that._destinations)) break label95; 
    label95: return (that._destinations == null);
  }

  public int hashCode()
  {
    int result = (this._className != null) ? this._className.hashCode() : 0;
    result = 29 * result + ((this._destinations != null) ? this._destinations.hashCode() : 0);
    return result;
  }
}