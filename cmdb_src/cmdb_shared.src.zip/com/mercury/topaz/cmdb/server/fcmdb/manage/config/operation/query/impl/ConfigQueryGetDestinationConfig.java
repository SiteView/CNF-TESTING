package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigCacheManager;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.query.impl.AbstractConfigQueryOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class ConfigQueryGetDestinationConfig extends AbstractConfigQueryOperation
{
  private String _destinationId;
  private DestinationConfig _destinationConfig;
  private static String RESULT_DATA = "RESULT_DATA";

  public ConfigQueryGetDestinationConfig(String destinationId)
  {
    setDestinationId(destinationId);
  }

  private String getDestinationId() {
    return this._destinationId;
  }

  private void setDestinationId(String destinationId) {
    this._destinationId = destinationId;
  }

  public DestinationConfig getDestinationConfig() {
    return this._destinationConfig;
  }

  private void setDestinationConfig(DestinationConfig destinationConfig) {
    this._destinationConfig = destinationConfig;
  }

  public String getOperationName() {
    return "ConfigQuery: Get Destination Config";
  }

  public void configExecuteQuery(ConfigCacheManager configCacheManager, CmdbResponse cmdbResponse) {
    FederationConfig federationConfig = configCacheManager.getFederationConfig();
    ReadOnlyIterator iter = federationConfig.getDestinationsConfig();
    DestinationConfig result = null;
    while ((iter.hasNext()) && (result == null)) {
      DestinationConfig destinationConfig = (DestinationConfig)iter.next();
      if (getDestinationId().equals(destinationConfig.getDestinationId()))
        result = destinationConfig;
    }
    cmdbResponse.addResult(RESULT_DATA, result);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setDestinationConfig((DestinationConfig)response.getResult(RESULT_DATA));
  }
}