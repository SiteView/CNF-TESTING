package com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.impl;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public class ConfigUpdateManagerFactory extends AbstractSubsystemManagerFactory
{
  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new ConfigUpdateManagerImpl(localEnvironment);
  }
}