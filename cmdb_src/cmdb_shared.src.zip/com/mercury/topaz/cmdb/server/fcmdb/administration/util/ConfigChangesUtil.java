package com.mercury.topaz.cmdb.server.fcmdb.administration.util;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.fcmdb.administration.manager.FederationAdminManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetSupportedClassConfigs;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.update.impl.DataAccessContainerUpdateRemoveOrIgnoreDestination;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassAttributesDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl.ConfigUpdateCacheSetClassesCapabilities;
import com.mercury.topaz.cmdb.server.fcmdb.manage.info.operation.command.impl.SynchInfoCommandRemoveConcreteSynchInfos;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessGeneralException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.DataAccessContainerQueryGetAdapterCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AdapterCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AdapterConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ClassAttributesConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ClassCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ClassesAttributesConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ClassesCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DataStoreConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.SourceConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.SupportedClassConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.SynchConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.SynchConfigUnit;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.TargetConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.TqlNameConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.AdapterCapabilitiesDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.AdapterConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.impl.ConfigDefFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.impl.AdapterCapabilitiesConfigFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.impl.ClassCapabilitiesFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.impl.ClassesCapabilitiesFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.impl.ConfigFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.query.impl.ConfigQueryGetAutoSynchronizedConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.info.ConcreteSynchInfo;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.info.impl.SynchInfoFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ConfigChangesUtil
{
  private static Log _logger = LogFactory.getEasyLog(ConfigChangesUtil.class);
  private static final String ADAPTER_CLASSES_CCONFIG_TIME_OUT_KEY = "task.DataAccess.Manager.getAdapterClassesConfig.timeOut";

  public static void updateFederationInfo(FederationAdminManager federationAdminManager, FederationConfig savedFederationConfig, FederationConfig newFederationConfig, StringBuilder logMessage)
  {
    if ((savedFederationConfig != null) && (newFederationConfig != null)) {
      SynchConfig savedSynchConfig = savedFederationConfig.getSynchronizationConfig();
      if ((savedSynchConfig != null) && (savedSynchConfig.getSynchConfigUnitsSize() > 0)) {
        Set concreteSynchInfoToRemove = new HashSet();
        ReadOnlyIterator savedSynchConigUnits = savedSynchConfig.getSynchConfigUnits();
        Map newSynchConfigUnitsMap = createSynchConfigUnitsMap(newFederationConfig.getSynchronizationConfig());
        while (savedSynchConigUnits.hasNext()) {
          SynchConfigUnit savedSynchConfigUnit = (SynchConfigUnit)savedSynchConigUnits.next();
          SynchConfigUnit newSynchConfigUnit = (SynchConfigUnit)newSynchConfigUnitsMap.get(savedSynchConfigUnit.getSynchConfigUnitId());
          getConcreteSynchInfoToRemove(savedSynchConfigUnit, newSynchConfigUnit, concreteSynchInfoToRemove);
        }
        removeConcreteSynchInfo(federationAdminManager, concreteSynchInfoToRemove);
        if (logMessage != null)
          logMessage.append(" Updated Configuration Info: The following concrete synch info was removed ").append(concreteSynchInfoToRemove);
      }
    }
  }

  private static void getConcreteSynchInfoToRemove(SynchConfigUnit savedSynchConfigUnit, SynchConfigUnit newSynchConfigUnit, Set<ConcreteSynchInfo> concreteSynchInfoToRemove)
  {
    if ((savedSynchConfigUnit != null) && (newSynchConfigUnit != null)) {
      addConcreteSynchInfosForRemoveBySourcesDiff(savedSynchConfigUnit, newSynchConfigUnit, concreteSynchInfoToRemove);
      addConcreteSynchInfosForRemoveByTargetsDiff(savedSynchConfigUnit, newSynchConfigUnit, concreteSynchInfoToRemove);
    }
  }

  public static void updateFederationInfo(FederationAdminManager federationAdminManager, SynchConfigUnit savedSynchConfigUnit, SynchConfigUnit newSynchConfigUnit) {
    Set concreteSynchInfoToRemove = new HashSet();
    getConcreteSynchInfoToRemove(savedSynchConfigUnit, newSynchConfigUnit, concreteSynchInfoToRemove);
    removeConcreteSynchInfo(federationAdminManager, concreteSynchInfoToRemove);
  }

  private static void addConcreteSynchInfosForRemoveByTargetsDiff(SynchConfigUnit savedSynchConfigUnit, SynchConfigUnit newSynchConfigUnit, Set<ConcreteSynchInfo> concreteSynchInfoToRemove) {
    ReadOnlyIterator targets = savedSynchConfigUnit.getTargetsConfig();
    Map newTargets = createTargetsMap(newSynchConfigUnit);
    while (targets.hasNext()) {
      TargetConfig savedTarget = (TargetConfig)targets.next();
      TargetConfig newTarget = (TargetConfig)newTargets.get(savedTarget.getDestinationConfig().getDestinationId());
      if (newTarget != null) {
        if (!(isSameDestinationForInfo(savedTarget.getDestinationConfig(), newTarget.getDestinationConfig())))
          addConcreteSynchInfosForRemoveByTarget(savedTarget, savedSynchConfigUnit.getSourcesConfig(), concreteSynchInfoToRemove);

      }
      else
        addConcreteSynchInfosForRemoveByTarget(savedTarget, savedSynchConfigUnit.getSourcesConfig(), concreteSynchInfoToRemove);
    }
  }

  private static Map<String, TargetConfig> createTargetsMap(SynchConfigUnit newSynchConfigUnit)
  {
    Map resultMap = new HashMap();
    if (newSynchConfigUnit != null) {
      ReadOnlyIterator targets = newSynchConfigUnit.getTargetsConfig();
      while (targets.hasNext()) {
        TargetConfig target = (TargetConfig)targets.next();
        resultMap.put(target.getDestinationConfig().getDestinationId(), target);
      }
    }
    return resultMap;
  }

  public static void addConcreteSynchInfosForRemoveByTarget(TargetConfig savedTarget, ReadOnlyIterator sourcesConfig, Set<ConcreteSynchInfo> concreteSynchInfoToRemove) {
    while (sourcesConfig.hasNext())
      addConcreteSynchInfosForRemoveBySourceAndTarget((SourceConfig)sourcesConfig.next(), savedTarget, concreteSynchInfoToRemove);
  }

  public static void addConcreteSynchInfosForRemoveBySourceAndTarget(SourceConfig source, TargetConfig target, Set<ConcreteSynchInfo> concreteSynchInfoToRemove)
  {
    ReadOnlyIterator tqlNames = source.getTqlNames();
    while (tqlNames.hasNext()) {
      TqlNameConfig tqlName = (TqlNameConfig)tqlNames.next();
      addConcreteSynchInfoForRemove(source, target, tqlName.getName(), concreteSynchInfoToRemove);
    }
  }

  private static void addConcreteSynchInfosForRemoveBySourcesDiff(SynchConfigUnit savedSynchConfigUnit, SynchConfigUnit newSynchConfigUnit, Set<ConcreteSynchInfo> concreteSynchInfoToRemove) {
    ReadOnlyIterator sources = savedSynchConfigUnit.getSourcesConfig();
    Map newSources = createSourcesMap(newSynchConfigUnit);
    while (sources.hasNext()) {
      SourceConfig savedSource = (SourceConfig)sources.next();
      SourceConfig newSource = (SourceConfig)newSources.get(savedSource.getDestinationConfig().getDestinationId());
      if (newSource != null)
        if (isSameDestinationForInfo(savedSource.getDestinationConfig(), newSource.getDestinationConfig())) {
          Set queries = getDiffQueries(savedSource, newSource);
          if ((queries != null) && (!(queries.isEmpty())))
            addConcreteSynchInfosForRemoveBySourceAndQueries(savedSource, queries, savedSynchConfigUnit.getTargetsConfig(), concreteSynchInfoToRemove);
        }
        else
        {
          addConcreteSynchInfosForRemoveBySource(savedSource, savedSynchConfigUnit.getTargetsConfig(), concreteSynchInfoToRemove);
        }

      else
        addConcreteSynchInfosForRemoveBySource(savedSource, savedSynchConfigUnit.getTargetsConfig(), concreteSynchInfoToRemove);
    }
  }

  private static Set<String> getDiffQueries(SourceConfig savedSource, SourceConfig newSource)
  {
    Set savedQueries = createQueriesSet(savedSource);
    Set newQueries = createQueriesSet(newSource);
    savedQueries.removeAll(newQueries);
    return savedQueries;
  }

  private static Set<String> createQueriesSet(SourceConfig source) {
    Set queries = new HashSet(source.getTqlNamesSize());
    ReadOnlyIterator tqlNames = source.getTqlNames();
    while (tqlNames.hasNext())
      queries.add(((TqlNameConfig)tqlNames.next()).getName());

    return queries;
  }

  private static void addConcreteSynchInfosForRemoveBySourceAndQueries(SourceConfig savedSource, Set<String> queries, ReadOnlyIterator targetsConfig, Set<ConcreteSynchInfo> concreteSynchInfoToRemove) {
    while (targetsConfig.hasNext()) {
      TargetConfig target = (TargetConfig)targetsConfig.next();
      for (Iterator i$ = queries.iterator(); i$.hasNext(); ) { String query = (String)i$.next();
        addConcreteSynchInfoForRemove(savedSource, target, query, concreteSynchInfoToRemove);
      }
    }
  }

  public static void addConcreteSynchInfoForRemove(SourceConfig source, TargetConfig target, String query, Set<ConcreteSynchInfo> concreteSynchInfoToRemove) {
    concreteSynchInfoToRemove.add(SynchInfoFactory.createConcreteSynchInfo(query, source.getDestinationConfig().getDestinationId(), target.getDestinationConfig().getDestinationId()));
  }

  public static void addConcreteSynchInfosForRemoveBySource(SourceConfig savedSource, ReadOnlyIterator targetsConfig, Set<ConcreteSynchInfo> concreteSynchInfoToRemove) {
    while (targetsConfig.hasNext())
      addConcreteSynchInfosForRemoveBySourceAndTarget(savedSource, (TargetConfig)targetsConfig.next(), concreteSynchInfoToRemove);
  }

  public static boolean isSameDestinationForInfo(DestinationConfig savedDestinationConfig, DestinationConfig newDestinationConfig)
  {
    return ((savedDestinationConfig.getHostName().equals(newDestinationConfig.getHostName())) && (savedDestinationConfig.getCustomerId() == newDestinationConfig.getCustomerId()));
  }

  private static Map<String, SourceConfig> createSourcesMap(SynchConfigUnit newSynchConfigUnit)
  {
    Map resultMap = new HashMap();
    if (newSynchConfigUnit != null) {
      ReadOnlyIterator sources = newSynchConfigUnit.getSourcesConfig();
      while (sources.hasNext()) {
        SourceConfig curSourceConfig = (SourceConfig)sources.next();
        resultMap.put(curSourceConfig.getDestinationConfig().getDestinationId(), curSourceConfig);
      }
    }
    return resultMap;
  }

  private static Map<String, SynchConfigUnit> createSynchConfigUnitsMap(SynchConfig synchronizationConfig) {
    Map resultMap = new HashMap(0);
    if (synchronizationConfig != null) {
      ReadOnlyIterator synchConfigUnits = synchronizationConfig.getSynchConfigUnits();
      while (synchConfigUnits.hasNext()) {
        SynchConfigUnit syncConfigUnit = (SynchConfigUnit)synchConfigUnits.next();
        resultMap.put(syncConfigUnit.getSynchConfigUnitId(), syncConfigUnit);
      }
    }
    return resultMap;
  }

  public static void findDestinationsChanges(FederationAdminManager federationAdminManager, FederationConfig savedFederationConfig, FederationConfig newFederationConfig, StringBuilder logMessage) {
    if ((savedFederationConfig == null) && (newFederationConfig == null))
      return;

    List destinationsToRemove = new ArrayList();
    if (savedFederationConfig != null)
      if ((newFederationConfig == null) || (newFederationConfig.getDestinationsConfigSize() == 0)) {
        ReadOnlyIterator destiniationsIterator = savedFederationConfig.getDestinationsConfig();
        while (destiniationsIterator.hasNext())
          destinationsToRemove.add(((DestinationConfig)destiniationsIterator.next()).getDestinationId());
      }
      else
      {
        Map savedDestinations = new HashMap();
        ReadOnlyIterator destiniationsIterator = savedFederationConfig.getDestinationsConfig();
        while (destiniationsIterator.hasNext()) {
          DestinationConfig curDestinationConfig = (DestinationConfig)destiniationsIterator.next();
          savedDestinations.put(curDestinationConfig.getDestinationId(), curDestinationConfig);
        }
        ReadOnlyIterator newDestiniationsIterator = newFederationConfig.getDestinationsConfig();
        while (newDestiniationsIterator.hasNext()) {
          DestinationConfig newDestinatoinConfig = (DestinationConfig)newDestiniationsIterator.next();
          DestinationConfig savedDestinationConfig = (DestinationConfig)savedDestinations.remove(newDestinatoinConfig.getDestinationId());
          if ((savedDestinationConfig == null) || (!(isSameDestinationConfigIgnoreQueries(newDestinatoinConfig, savedDestinationConfig))))
            destinationsToRemove.add(newDestinatoinConfig.getDestinationId());
        }

        destinationsToRemove.addAll(savedDestinations.keySet());
      }

    removeDestinations(federationAdminManager, destinationsToRemove);

    if (logMessage != null)
      logMessage.append("Removed Destinations ").append(destinationsToRemove);
  }

  public static boolean isSameDestinationConfigIgnoreQueries(DestinationConfig destinationConfig1, DestinationConfig destinationConfig2)
  {
    return ((destinationConfig1 == destinationConfig2) || ((destinationConfig1 != null) && (destinationConfig2 != null) && (equals(destinationConfig1.getDestinationId(), destinationConfig2.getDestinationId())) && (equals(destinationConfig1.getAdapterConfig().toConfigDef(), destinationConfig2.getAdapterConfig().toConfigDef())) && (destinationConfig1.getCustomerId() == destinationConfig2.getCustomerId()) && (equals(destinationConfig1.getHostName(), destinationConfig2.getHostName())) && (equals(destinationConfig1.getPassword(), destinationConfig2.getPassword())) && (equals(destinationConfig1.getPort(), destinationConfig2.getPort())) && (equals(destinationConfig1.getUrl(), destinationConfig2.getUrl())) && (equals(destinationConfig1.getUserName(), destinationConfig2.getUserName()))));
  }

  private static <Type> boolean equals(Type o1, Type o2)
  {
    return ((((o1 != null) || (o2 == null))) && (((o2 != null) || (o1 == null))) && (((o1 == null) || (o1.equals(o2)))));
  }

  public static void removeDestinations(FederationAdminManager federationAdminManager, List<String> destinationsToRemove) {
    for (Iterator i$ = destinationsToRemove.iterator(); i$.hasNext(); ) { String aDestinationsToRemove = (String)i$.next();
      removeDestination(federationAdminManager, aDestinationsToRemove);
    }
  }

  public static void removeDestination(FederationAdminManager federationAdminManager, String destinationToRemove) {
    if (destinationToRemove != null) {
      DataAccessContainerUpdateRemoveOrIgnoreDestination dataAccessUpdateRemoveOrIgnoreDestination = new DataAccessContainerUpdateRemoveOrIgnoreDestination(destinationToRemove);
      federationAdminManager.executeOperation(dataAccessUpdateRemoveOrIgnoreDestination);
    }
  }

  public static FederationConfig getFederationConfig() {
    ConfigQueryGetAutoSynchronizedConfig configQueryGetAutoSynchronizedConfig = new ConfigQueryGetAutoSynchronizedConfig();
    ServerApiFacade.executeOperation(configQueryGetAutoSynchronizedConfig);
    return configQueryGetAutoSynchronizedConfig.getFederationConfig();
  }

  public static AdapterConfig getAdapterConfigByAdapterId(String adapterId) {
    FederationConfig federationConfig = getFederationConfig();
    ReadOnlyIterator adapterConfigs = federationConfig.getAdaptersConfig();
    while (adapterConfigs.hasNext()) {
      AdapterConfig curAdapterConfig = (AdapterConfig)adapterConfigs.next();
      if (curAdapterConfig.getAdapterId().equals(adapterId))
        return curAdapterConfig;
    }

    return null;
  }

  public static void removeConcreteSynchInfo(FederationAdminManager federationAdminManager, Set<ConcreteSynchInfo> synchInfoToRemove) {
    if ((synchInfoToRemove != null) && (!(synchInfoToRemove.isEmpty()))) {
      SynchInfoCommandRemoveConcreteSynchInfos removeConcreteSynchInfos = new SynchInfoCommandRemoveConcreteSynchInfos(synchInfoToRemove);
      federationAdminManager.executeOperation(removeConcreteSynchInfos);
    }
  }

  public static void updateClassCapabilitiesCache(FederationAdminManager federationAdminManager, ClassesCapabilities classesCapabilities) {
    ConfigUpdateCacheSetClassesCapabilities setClassesCapabilities = new ConfigUpdateCacheSetClassesCapabilities(classesCapabilities);
    federationAdminManager.executeOperation(setClassesCapabilities);
  }

  private static ClassesCapabilities createClassesCapabilities(FederationAdminManager federationAdminManager, ClassModelDestinationsConfig classModelDestinationsConfig) {
    Map classesConfigByDestionation = createClassesConfigByDestination(federationAdminManager, getFederationConfig());
    CmdbClassModel classModel = getClassModel();
    if (_logger.isDebugEnabled())
      _logger.debug("createClassesCapabilities: classesConfigByDestionation= " + classesConfigByDestionation);

    return createClassesCapabilities(classModelDestinationsConfig, classesConfigByDestionation, classModel);
  }

  static ClassesCapabilities createClassesCapabilities(ClassModelDestinationsConfig classesDestinationsConfig, Map<String, Map<String, SupportedClassConfig>> classesConfigByDestionation, CmdbClassModel classModel) {
    HashMap classesWithCapabilitiesMap = new HashMap();

    createClassCapabilitiesForExternalClasses(classesDestinationsConfig, classesConfigByDestionation, classModel, classesWithCapabilitiesMap);

    createClassCapabilitiesForExternalAttributes(classesDestinationsConfig, classesConfigByDestionation, classModel, classesWithCapabilitiesMap);

    return ClassesCapabilitiesFactory.createClassesCapabilities(classesWithCapabilitiesMap);
  }

  private static void createClassCapabilitiesForExternalAttributes(ClassModelDestinationsConfig classesDestinationsConfig, Map<String, Map<String, SupportedClassConfig>> classesConfigByDestionation, CmdbClassModel classModel, HashMap<String, ClassCapabilities> classesWithCapabilitiesMap) {
    Iterator classAttributeDestinationConfigIterator = classesDestinationsConfig.getAllClassAttributesDestinationConfig();
    while (classAttributeDestinationConfigIterator.hasNext()) {
      ClassAttributesDestinationsConfig classAttributesDestinationsConfig = (ClassAttributesDestinationsConfig)classAttributeDestinationConfigIterator.next();
      classesDestinationsConfig.getAllExternalClasses();
      Map supportedClasConfigsByAttribute = new HashMap();
      for (Iterator i$ = classAttributesDestinationsConfig.getAttributes().iterator(); i$.hasNext(); ) { String attributeName = (String)i$.next();
        Collection supportedClassConfigs = new ArrayList();
        for (Iterator i$ = classAttributesDestinationsConfig.getDestinations(attributeName).iterator(); i$.hasNext(); ) { String destinationId = (String)i$.next();
          Map supportedClassesConfig = (Map)classesConfigByDestionation.get(destinationId);
          SupportedClassConfig supportedClassConfig = null;
          if (supportedClassesConfig != null)
            supportedClassConfig = (SupportedClassConfig)supportedClassesConfig.get(classAttributesDestinationsConfig.getClassName());

          if (supportedClassConfig != null) {
            supportedClassConfigs.add(supportedClassConfig);
          }
          else {
            if (_logger.isDebugEnabled())
              _logger.error("createClassCapabilitiesForExternalAttributes: supported classes for destination [ " + destinationId + "] is empty. use default");

            supportedClassConfigs.add(AdapterCapabilitiesConfigFactory.createSupportedClassConfig(classAttributesDestinationsConfig.getClassName(), false, false));
          }
        }
        if (supportedClassConfigs.isEmpty()) {
          _logger.info("class " + classAttributesDestinationsConfig.getClassName() + " attribute " + attributeName + " has no supported classes. It will  be added as external with defaul capabilities");
          supportedClassConfigs.add(AdapterCapabilitiesConfigFactory.createSupportedClassConfig(classAttributesDestinationsConfig.getClassName(), false, false));
        }
        supportedClasConfigsByAttribute.put(attributeName, supportedClassConfigs);
        ClassCapabilities classCapabilities = ClassCapabilitiesFactory.createClassCapabilitiesForExternalAttributes(classAttributesDestinationsConfig.getClassName(), supportedClasConfigsByAttribute, classModel);
        classesWithCapabilitiesMap.put(classAttributesDestinationsConfig.getClassName(), classCapabilities);
      }
    }
  }

  private static void createClassCapabilitiesForExternalClasses(ClassModelDestinationsConfig classesDestinationsConfig, Map<String, Map<String, SupportedClassConfig>> classesConfigByDestionation, CmdbClassModel classModel, HashMap<String, ClassCapabilities> classesWithCapabilitiesMap) {
    Iterator classDestinationsConfigIterator = classesDestinationsConfig.getAllClassDestinationsConfig();
    while (classDestinationsConfigIterator.hasNext()) {
      ClassCapabilities classCapabilities;
      Collection supportedClassConfigs = new ArrayList();
      ClassDestinationsConfig curClassDestinationsConfig = (ClassDestinationsConfig)classDestinationsConfigIterator.next();
      for (Iterator i$ = curClassDestinationsConfig.getDestinations().iterator(); i$.hasNext(); ) { String destinationId = (String)i$.next();
        Map supportedClassesConfig = (Map)classesConfigByDestionation.get(destinationId);
        SupportedClassConfig supportedClassConfig = null;
        if (supportedClassesConfig != null)
          supportedClassConfig = (SupportedClassConfig)supportedClassesConfig.get(curClassDestinationsConfig.getClassName());

        if (supportedClassConfig != null) {
          supportedClassConfigs.add(supportedClassConfig);
        }
        else {
          if (_logger.isDebugEnabled())
            _logger.error("createClassesCapabilities: supported classes for destination [ " + destinationId + "] is empty. use default");

          supportedClassConfigs.add(AdapterCapabilitiesConfigFactory.createSupportedClassConfig(curClassDestinationsConfig.getClassName(), false, false));
        }
      }

      if (!(supportedClassConfigs.isEmpty())) {
        if (_logger.isDebugEnabled())
          _logger.error("createClassesCapabilities: add class capability for class = " + curClassDestinationsConfig.getClassName());

        classCapabilities = ClassCapabilitiesFactory.createClassCapabilitiesForExternalClass(curClassDestinationsConfig.getClassName(), supportedClassConfigs, classModel);
      }
      else {
        _logger.info("class " + curClassDestinationsConfig.getClassName() + "has no supported classes. It will  be added as external with defaul capabilities");
        classCapabilities = createDefaultClassCapabilities(curClassDestinationsConfig.getClassName(), classModel);
      }
      classesWithCapabilitiesMap.put(curClassDestinationsConfig.getClassName(), classCapabilities);
    }
  }

  public static ClassCapabilities createDefaultClassCapabilities(String className, CmdbClassModel classModel)
  {
    SupportedClassConfig supportedClassConfig = AdapterCapabilitiesConfigFactory.createSupportedClassConfig(className, false, false);
    ArrayList supportedClassConfigs = new ArrayList(1);
    supportedClassConfigs.add(supportedClassConfig);
    return ClassCapabilitiesFactory.createClassCapabilitiesForExternalClass(className, supportedClassConfigs, classModel);
  }

  public static CmdbClassModel getClassModel() {
    return ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
  }

  private static Map<String, Map<String, SupportedClassConfig>> createClassesConfigByDestination(FederationAdminManager federationAdminManager, FederationConfig federationConfig)
  {
    int timeoutCount = 0;
    long timeOut = federationAdminManager.getLocalSettings().getLong("task.DataAccess.Manager.getAdapterClassesConfig.timeOut", 20000L);
    Map classesConfigByDestination = new HashMap(federationConfig.getDestinationsConfigSize());
    ReadOnlyIterator destinationConfigsIterator = federationConfig.getDestinationsConfig();
    while (true) { DestinationConfig curDestinationConfig;
      while (true) { if ((!(destinationConfigsIterator.hasNext())) || (timeoutCount >= 3)) break label241;
        curDestinationConfig = (DestinationConfig)destinationConfigsIterator.next();
        AdapterCapabilities adapterCapabilities = curDestinationConfig.getAdapterConfig().getAdapterCapabilities();
        if ((adapterCapabilities == null) || (adapterCapabilities.getSupportFederatedQuery() != null))
          break;
      }
      DataAccessAdapterQueryGetSupportedClassConfigs getSupportedClassConfigs = new DataAccessAdapterQueryGetSupportedClassConfigs(curDestinationConfig, timeOut);
      try {
        federationAdminManager.executeOperation(getSupportedClassConfigs);
        Map supportedClassesConfig = getSupportedClassConfigs.getSupportedClassesConfig();
        classesConfigByDestination.put(curDestinationConfig.getDestinationId(), supportedClassesConfig);
      } catch (AdapterAccessGeneralException e) {
        _logger.debug("destination " + curDestinationConfig.getDestinationId() + " doesn't support federation query. failed on autodetection", e);
      } catch (Throwable e) {
        ++timeoutCount;
        _logger.error("get supportedClassesConfig for data store " + curDestinationConfig.getDestinationId() + " failed on time out", e);
      }
    }
    if (timeoutCount == 3)
      label241: _logger.error("number of timeouts exeeds the maximum in get supportedClassesConfig - terminate operation");

    return classesConfigByDestination;
  }

  public static void reloadClassesCapabilities(FederationAdminManager federationAdminManager) {
    ClassModelDestinationsConfig classModelDestinationsConfig = getClassesDestinationConfig();
    reloadClassesCapabilities(federationAdminManager, classModelDestinationsConfig);
  }

  public static void reloadClassesCapabilities(FederationAdminManager federationAdminManager, ClassModelDestinationsConfig classModelDestinationsConfig) {
    ClassesCapabilities classesCapabilities = createClassesCapabilities(federationAdminManager, classModelDestinationsConfig);
    updateClassCapabilitiesCache(federationAdminManager, classesCapabilities);
  }

  public static ClassModelDestinationsConfig getClassesDestinationConfig() {
    return ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel().getClassesDestinationsConfig();
  }

  public static AdapterConfigDef getAdapterConfigWithCapabilities(FederationAdminManager federationAdminManager, AdapterConfigDef adapterConfigDef) {
    AdapterCapabilitiesDef adapterCapabilitiesDef = adapterConfigDef.getAdapterCapabilities();
    if ((adapterCapabilitiesDef == null) || ((adapterCapabilitiesDef.getSupportFederatedQuery() == null) && (adapterCapabilitiesDef.getSupportReplicationData() == null))) {
      DataAccessContainerQueryGetAdapterCapabilities dataAccessContainerQueryGetAdapterCapabilities = new DataAccessContainerQueryGetAdapterCapabilities(adapterConfigDef);
      federationAdminManager.executeOperation(dataAccessContainerQueryGetAdapterCapabilities);
      adapterCapabilitiesDef = dataAccessContainerQueryGetAdapterCapabilities.getAdapterCapabilitiesDef();
      AdapterConfigDef modifiableAdapterConfigDef = ConfigDefFactory.createModifiableAdapterConfigDef(adapterConfigDef);
      modifiableAdapterConfigDef.setAdapterCapabilities(adapterCapabilitiesDef);
      return modifiableAdapterConfigDef;
    }
    if (_logger.isDebugEnabled())
      _logger.debug("Capabilities for [" + adapterConfigDef.getAdapterId() + "] is:\n" + adapterCapabilitiesDef);

    return adapterConfigDef;
  }

  public static DataStoreConfig convertDestinationConfigToDataStoreConfig(DestinationConfig destinationConfig) {
    DataStoreConfig dataStoreConfig = ConfigFactory.createDataStoreConfig(destinationConfig.getDestinationId());
    dataStoreConfig.setCustomerId(destinationConfig.getCustomerId());
    dataStoreConfig.setHostName(destinationConfig.getHostName());
    dataStoreConfig.setPassword(destinationConfig.getPassword());
    dataStoreConfig.setPort(destinationConfig.getPort());
    dataStoreConfig.setUrl(destinationConfig.getUrl());
    dataStoreConfig.setUserName(destinationConfig.getUserName());
    dataStoreConfig.setAdapterConfig(destinationConfig.getAdapterConfig());
    if (destinationConfig.getQueriesSize() > 0) {
      ReadOnlyIterator queries = destinationConfig.getQueries();
      while (queries.hasNext())
        dataStoreConfig.addQuery((String)queries.next());
    }

    if (destinationConfig.getClassesSize() > 0) {
      ReadOnlyIterator classes = destinationConfig.getClasses();
      while (classes.hasNext()) {
        String curClass = (String)classes.next();
        dataStoreConfig.addClass(curClass);
      }
    }
    ClassesAttributesConfig classesAttributesConfig = destinationConfig.getClassesAttibutesConfig();
    if (classesAttributesConfig != null) {
      Iterator classAttributesConfigIterator = classesAttributesConfig.getClassAttributes();
      while (classAttributesConfigIterator.hasNext()) {
        ClassAttributesConfig classAttributesConfig = (ClassAttributesConfig)classAttributesConfigIterator.next();
        dataStoreConfig.addClassWithArributes(classAttributesConfig.getClassName(), classAttributesConfig.getAttributes());
      }
    }
    return dataStoreConfig;
  }
}