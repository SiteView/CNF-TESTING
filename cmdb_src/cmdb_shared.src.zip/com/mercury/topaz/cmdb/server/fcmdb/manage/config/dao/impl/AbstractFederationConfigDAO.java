package com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao.FederationConfigDAO;

abstract class AbstractFederationConfigDAO
  implements FederationConfigDAO
{
}