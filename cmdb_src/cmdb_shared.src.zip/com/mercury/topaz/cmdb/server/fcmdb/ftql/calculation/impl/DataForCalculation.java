package com.mercury.topaz.cmdb.server.fcmdb.ftql.calculation.impl;

import com.hp.ucmdb.federationspi.data.query.reconciliation.TopologyReconciliationData;
import com.hp.ucmdb.federationspi.data.query.topology.QueryDefinition;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter.ElementNumberConverterFromMap;
import com.mercury.topaz.cmdb.server.tql.definition.impl.PatternGraphUtils;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class DataForCalculation
{
  private ReconciliationDataForCalculation reconciliationDataForCalculation;
  private UserGraphDataForCalculation userGraphDataForCalculation;

  public DataForCalculation(TopologyReconciliationData topologyReconciliationData, PatternElementNumber virtualLinkEndNodeNumber, PatternGraph userGraph)
  {
    this.reconciliationDataForCalculation = new ReconciliationDataForCalculation(topologyReconciliationData);
    this.userGraphDataForCalculation = new UserGraphDataForCalculation(virtualLinkEndNodeNumber, userGraph);
  }

  public Map<PatternElementNumber, String> getElementNumberToNodeNameMap() {
    return this.reconciliationDataForCalculation.getElementNumberToNodeNameMap();
  }

  public Map<String, PatternElementNumber> getNodeNameToElementNumberMap() {
    return this.reconciliationDataForCalculation.getNodeNameToElementNumberMap();
  }

  public String convertElementNumberToNodeName(PatternElementNumber elementNumber) {
    return this.reconciliationDataForCalculation.convertElementNumberToNodeName(elementNumber); }

  public PatternElementNumber convertNodeNameToElementNumber(String nodeName) {
    return this.reconciliationDataForCalculation.convertNodeNameToElementNumber(nodeName);
  }

  public Pattern getReconciliationPattern() {
    return this.reconciliationDataForCalculation.getReconciliationPattern();
  }

  public PatternElementNumber[] getReconciliationElementNumbers() {
    return this.reconciliationDataForCalculation.getReconciliationElementNumbers();
  }

  public PatternElementNumber getVirtualLinkEndNodeNumber() {
    return this.userGraphDataForCalculation.getVirtualLinkEndNodeNumber();
  }

  public PatternGraph getUserGraph() {
    return this.userGraphDataForCalculation.getUserGraph();
  }

  public PatternElementNumber convertDuplicateToOriginalNumber(PatternElementNumber duplicateElementNumber) {
    return this.userGraphDataForCalculation.convertDuplicateToOriginalNumber(duplicateElementNumber);
  }

  public PatternElementNumber getDuplicateUserGraphElementNumber(PatternElementNumber originalElementNumber, PatternGraph currentPatternGraph) {
    return this.userGraphDataForCalculation.getDuplicateUserGraphElementNumber(originalElementNumber, currentPatternGraph);
  }

  public List<PatternElementNumber> convertOriginalToDuplicateNumber(PatternElementNumber originalElementNumber) {
    return this.userGraphDataForCalculation.convertOriginalToDuplicateNumber(originalElementNumber); }

  public String getVirtualLinkEndType() {
    return this.userGraphDataForCalculation.getVirtualLinkEndType();
  }

  private static class UserGraphDataForCalculation {
    private PatternElementNumber virtualLinkEndNodeNumber;
    private PatternGraph userGraph;
    private Map<PatternElementNumber, PatternElementNumber> duplicateToOriginalElementMap = new HashMap();
    private Map<PatternElementNumber, List<PatternElementNumber>> originalToDuplicateElementsMap = new HashMap();
    private int startFrom = 2000;

    public UserGraphDataForCalculation(PatternElementNumber virtualLinkEndNodeNumber, PatternGraph userGraph) {
      this.virtualLinkEndNodeNumber = virtualLinkEndNodeNumber;
      this.userGraph = userGraph;
    }

    public PatternElementNumber getVirtualLinkEndNodeNumber()
    {
      return this.virtualLinkEndNodeNumber;
    }

    public PatternGraph getUserGraph() {
      return this.userGraph;
    }

    public String getVirtualLinkEndType() {
      return this.userGraph.getElementClass(this.virtualLinkEndNodeNumber);
    }

    public PatternElementNumber convertDuplicateToOriginalNumber(PatternElementNumber duplicateElementNumber) {
      return ((PatternElementNumber)this.duplicateToOriginalElementMap.get(duplicateElementNumber));
    }

    public List<PatternElementNumber> convertOriginalToDuplicateNumber(PatternElementNumber originalElementNumber) {
      return ((List)this.originalToDuplicateElementsMap.get(originalElementNumber));
    }

    public PatternElementNumber getDuplicateUserGraphElementNumber(PatternElementNumber originalElementNumber, PatternGraph currentPatternGraph) {
      PatternElementNumber freeElementNumber = PatternGraphUtils.findNoneUsedElementNumber(currentPatternGraph, this.startFrom);
      this.startFrom = (freeElementNumber.getNumber() + 1);
      this.duplicateToOriginalElementMap.put(freeElementNumber, originalElementNumber);
      List duplicateElements = (List)this.originalToDuplicateElementsMap.get(originalElementNumber);
      if (duplicateElements == null) {
        duplicateElements = new ArrayList();
        this.originalToDuplicateElementsMap.put(originalElementNumber, duplicateElements);
      }
      duplicateElements.add(freeElementNumber);
      return freeElementNumber;
    }
  }

  private static class ReconciliationDataForCalculation
  {
    private Pattern reconciliationPattern;
    private Map<String, PatternElementNumber> nodeNameToElementNumberMap;
    private Map<PatternElementNumber, String> elementNumberToNodeNameMap;
    private PatternElementNumber[] reconciliationElementNumbers;

    ReconciliationDataForCalculation(TopologyReconciliationData topologyReconciliationData)
    {
      init(topologyReconciliationData);
    }

    public Map<PatternElementNumber, String> getElementNumberToNodeNameMap() {
      return this.elementNumberToNodeNameMap;
    }

    public Map<String, PatternElementNumber> getNodeNameToElementNumberMap() {
      return this.nodeNameToElementNumberMap;
    }

    private Map<PatternElementNumber, String> convertMap(Map<String, PatternElementNumber> map) {
      Map convertedMap = new HashMap(map.size());
      for (Iterator i$ = map.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
        convertedMap.put(curEntry.getValue(), curEntry.getKey());
      }
      return convertedMap; }

    public String convertElementNumberToNodeName(PatternElementNumber elementNumber) {
      return ((String)this.elementNumberToNodeNameMap.get(elementNumber)); }

    public PatternElementNumber convertNodeNameToElementNumber(String nodeName) {
      return ((PatternElementNumber)this.nodeNameToElementNumberMap.get(nodeName));
    }

    public Pattern getReconciliationPattern() {
      return this.reconciliationPattern;
    }

    public PatternElementNumber[] getReconciliationElementNumbers() {
      return this.reconciliationElementNumbers;
    }

    private void init(TopologyReconciliationData topologyReconciliationData)
    {
      if (topologyReconciliationData != null) {
        this.nodeNameToElementNumberMap = createElementNumberConverterMap(topologyReconciliationData);
        this.reconciliationElementNumbers = createReconciliationElementNumbers(topologyReconciliationData, this.nodeNameToElementNumberMap);
        this.reconciliationPattern = AdapterFPIConverter.convertQueryDefinitionToPattern(topologyReconciliationData.getReconciliationQuery(), new AdapterFPIConverter.ElementNumberConverterFromMap(this.nodeNameToElementNumberMap));
      }
      this.elementNumberToNodeNameMap = convertMap(this.nodeNameToElementNumberMap);
    }

    private Map<String, PatternElementNumber> createElementNumberConverterMap(TopologyReconciliationData topologyReconciliationData) {
      PatternElementNumber freeElementNumber;
      int curElementNumber = 1000;

      QueryDefinition reconciliationQueryDefinition = topologyReconciliationData.getReconciliationQuery();
      Map targetTqlElementNumberConversionMap = new HashMap(reconciliationQueryDefinition.getLinkAmount() + reconciliationQueryDefinition.getNodeAmount());
      for (Iterator i$ = reconciliationQueryDefinition.getNodeNames().iterator(); i$.hasNext(); ) { String curNodeName = (String)i$.next();
        freeElementNumber = PatternElementNumberFactory.createElementNumber(curElementNumber);
        targetTqlElementNumberConversionMap.put(curNodeName, freeElementNumber);
        ++curElementNumber;
      }

      for (i$ = reconciliationQueryDefinition.getLinkNames().iterator(); i$.hasNext(); ) { String curLinkName = (String)i$.next();
        freeElementNumber = PatternElementNumberFactory.createElementNumber(curElementNumber);
        targetTqlElementNumberConversionMap.put(curLinkName, freeElementNumber);
        ++curElementNumber;
      }
      return targetTqlElementNumberConversionMap;
    }

    private PatternElementNumber[] createReconciliationElementNumbers(TopologyReconciliationData topologyReconciliationData, Map<String, PatternElementNumber> targetTqlElementNumberConversionMap) {
      String[] reconciliationElementNames = topologyReconciliationData.getReconciliationNodeNames();
      PatternElementNumber[] reconciliationElementNumbers = new PatternElementNumber[reconciliationElementNames.length];
      for (int i = 0; i < reconciliationElementNames.length; ++i)
        reconciliationElementNumbers[i] = ((PatternElementNumber)targetTqlElementNumberConversionMap.get(reconciliationElementNames[i]));

      return reconciliationElementNumbers;
    }
  }
}