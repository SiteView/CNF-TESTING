package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.impl;

import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.result.SortResultDataAdapter;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyQueryElement;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.ResultStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import java.util.List;

public class SortSupportCalculationStrategy
  implements ResultStrategy
{
  private static Log _logger = LogFactory.getEasyLog(SortSupportCalculationStrategy.class);

  public CmdbObjectIds sortObjects(FTqlDataAdapter adapter, ModelObjects objects, CmdbSortCommand sortCommand, CalculationStrategy calculationStrategy, String dataStore)
    throws AdapterAccessException, DataAccessException
  {
    List objectIds = AdapterFPIConverter.convertModelObjectsToExternalIds(objects);
    List sortCommandAttributeOrders = AdapterFPIConverter.convertCmdbSortCommand(sortCommand);

    List resulIds = ((SortResultDataAdapter)adapter).sortCis(objectIds, sortCommandAttributeOrders);
    return AdapterFPIConverter.convertExternalToCmdbObjectIds(resulIds);
  }

  public CmdbObjectIds sortObjects(FTqlDataAdapter adapter, ElementCondition elementCondition, CmdbSortCommand sortCommand, CalculationStrategy calculationStrategy, String dataStore) throws AdapterAccessException, DataAccessException {
    TopologyQueryElement topologyQueryElement = AdapterFPIConverter.convertElementConditionToTopologyQueryElement(elementCondition);
    List sortCommandAttributeOrders = AdapterFPIConverter.convertCmdbSortCommand(sortCommand);

    List resulIds = ((SortResultDataAdapter)adapter).sortCis(topologyQueryElement, sortCommandAttributeOrders);
    return AdapterFPIConverter.convertExternalToCmdbObjectIds(resulIds);
  }

  public CmdbLinks sortLinks(FTqlDataAdapter adapter, ModelLinks modelLinks, CmdbSortCommand sortCommand, CalculationStrategy calculationStrategy, String dataStore) throws AdapterAccessException, DataAccessException
  {
    List linkIds = AdapterFPIConverter.convertModelLinksToExternalIds(modelLinks);
    List sortCommandAttributeOrders = AdapterFPIConverter.convertCmdbSortCommand(sortCommand);

    List resulRelations = ((SortResultDataAdapter)adapter).sortRelations(linkIds, sortCommandAttributeOrders);
    return AdapterFPIConverter.convertRelationIdsToCmdbLinks(resulRelations);
  }
}