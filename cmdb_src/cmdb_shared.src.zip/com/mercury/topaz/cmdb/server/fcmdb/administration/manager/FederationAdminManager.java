package com.mercury.topaz.cmdb.server.fcmdb.administration.manager;

import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;

public abstract interface FederationAdminManager extends SubsystemManager
{
}