package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.util;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.types.PropertyImpl;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.TypeVisitor;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBytesType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDateType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDoubleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbFloatType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.Numeric;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessGeneralException;
import java.io.UnsupportedEncodingException;

public class FederatedPropertyValidator
  implements TypeVisitor
{
  private static Log _log = LogFactory.getEasyLog(FederatedPropertyValidator.class);
  private static final String CHARSET = "UTF-8";
  private CmdbAttribute _attribute;
  private PropertyImpl _property;

  public void set(CmdbAttribute attribute, PropertyImpl property)
  {
    setAttribute(attribute);
    setProperty(property);
  }

  public void visit(CmdbSimpleType simpleCmdbType) {
    if (!(getProperty().getType().equals(getAttribute().getResolvedType())))
      throw new AdapterAccessGeneralException(" property [" + getProperty() + "] has different type defintion in appropriate attribute [" + getAttribute() + "] ", ErrorCode.ATTRIBUTE_TYPE_MISMATCH);
  }

  public void visit(Numeric numericType)
  {
  }

  public void visit(CmdbIntegerType integerType)
  {
  }

  public void visit(CmdbLongType longType)
  {
  }

  public void visit(CmdbFloatType floatType) {
  }

  public void visit(CmdbStringType stringType) {
    if (!(getProperty().isValueEmpty())) {
      String value = (String)getProperty().getValue();
      if (value != null)
        try {
          byte[] byteValue = value.getBytes("UTF-8");
          int valueSize = byteValue.length;
          Integer attributeSizeLimit = getAttribute().getSizeLimit();
          int sizeLimit = (attributeSizeLimit == null) ? 50 : attributeSizeLimit.intValue();
          if (valueSize > sizeLimit) {
            _log.info(" property's value [" + getProperty() + "] has exceeded the size limit of the attribute [" + getAttribute() + "]. The value will be truncated");
            value = new String(byteValue, 0, Math.max(0, sizeLimit - 4), "UTF-8");
            getProperty().setValue(value);
          }
        } catch (UnsupportedEncodingException e) {
          throw new AdapterAccessGeneralException(e);
        }
    }
  }

  public void visit(CmdbXmlType xmlType)
  {
  }

  public void visit(CmdbEnum cmdbEnum) {
    if (!(getProperty().getType().equals(CmdbSimpleTypes.CmdbInteger)))
      throw new AdapterAccessGeneralException(" property [" + getProperty() + "] must be integer because attribute [" + getAttribute() + "] is cmdb cmdbenum ");

    if (!(getProperty().isValueEmpty())) {
      Integer propValue = (Integer)getProperty().getValue();
      if (!(cmdbEnum.hasKey(propValue.intValue())))
        throw new AdapterAccessGeneralException(" property [" + getProperty() + "] is defined as attribute [" + getAttribute() + "] of type cmdb cmdbenum. Property's value is not one of the defined cmdb cmdbenum keys  ");
    }
  }

  public void visit(CmdbTypeDef typeDef)
  {
  }

  public void visit(CmdbList cmdbList) {
    if (!(getProperty().getType().equals(cmdbList.getType())))
      throw new AdapterAccessGeneralException(" property [" + getProperty() + "] has different type defintion in appropriate cmdb list definition in attribute [" + getAttribute() + "] ", ErrorCode.ATTRIBUTE_TYPE_MISMATCH);

    if (!(getProperty().isValueEmpty())) {
      Object propValue = getProperty().getValue();
      if (!(cmdbList.hasValue(propValue)))
        throw new AdapterAccessGeneralException(" property [" + getProperty() + "] is defined as attribute [" + getAttribute() + "] of type cmdb list. Property's value is not one of the defined cmdb list values  ");
    }
  }

  public void visit(CmdbExternalResource externalResource)
  {
  }

  public void visit(CmdbBooleanType cmdbBooleanType) {
  }

  public void visit(CmdbDateType cmdbDateType) {
  }

  public void visit(CmdbDoubleType doubleType) {
  }

  public void visit(CmdbBytesType cmdbBytesType) {
  }

  public void visit(CmdbSimpleList cmdbSimpleList) {
  }

  public void visit(CmdbStringListType cmdbStringListType) {
  }

  public void visit(CmdbIntegerListType cmdbIntegerListType) {
  }

  public void validate() {
    getAttribute().getResolvedType().accept(this);
  }

  private CmdbAttribute getAttribute() {
    return this._attribute;
  }

  private void setAttribute(CmdbAttribute attribute) {
    this._attribute = attribute;
  }

  private PropertyImpl getProperty() {
    return this._property;
  }

  private void setProperty(PropertyImpl property) {
    this._property = property;
  }
}