package com.mercury.topaz.cmdb.server.fcmdb.ftql.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStoreAttributeInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStoreClassInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.ElementDataStoresInfo;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class ElementDataStoresInfoImpl
  implements ElementDataStoresInfo
{
  private String _ucmdbClassName;
  private List<DataStoreClassInfo> _dataStoreClassInfos;
  private Map<String, Set<DataStoreAttributeInfo>> _externalAttributeDataStoresMap;

  ElementDataStoresInfoImpl(String ucmdbClassName)
  {
    this._ucmdbClassName = ucmdbClassName;
    this._dataStoreClassInfos = new ArrayList();
    this._externalAttributeDataStoresMap = new HashMap();
  }

  public void addDataStoreClassInfo(DataStoreClassInfo dataStoreClassInfo) {
    this._dataStoreClassInfos.add(dataStoreClassInfo);
  }

  public Map<String, Set<DataStoreAttributeInfo>> getExternalAttributesWithDataStores() {
    return this._externalAttributeDataStoresMap;
  }

  public String getUcmdbClassName() {
    return this._ucmdbClassName;
  }

  public Collection<DataStoreClassInfo> getSupportedDataStoresInfo() {
    return this._dataStoreClassInfos;
  }

  public Set<String> getAllCoreDataStores() {
    Set allDataStores = new HashSet(this._dataStoreClassInfos.size());
    for (Iterator i$ = this._dataStoreClassInfos.iterator(); i$.hasNext(); ) { DataStoreClassInfo dataStoreClassInfo = (DataStoreClassInfo)i$.next();
      allDataStores.add(dataStoreClassInfo.getDataStore());
    }
    return allDataStores;
  }

  public Set<String> getAllDataStores() {
    Set allDataStores = new HashSet(this._dataStoreClassInfos.size());
    for (Iterator i$ = this._dataStoreClassInfos.iterator(); i$.hasNext(); ) { DataStoreClassInfo dataStoreClassInfo = (DataStoreClassInfo)i$.next();
      allDataStores.add(dataStoreClassInfo.getDataStore());
      for (Iterator i$ = this._externalAttributeDataStoresMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
        for (Iterator i$ = ((Set)curEntry.getValue()).iterator(); i$.hasNext(); ) { DataStoreAttributeInfo dataStoreAttributeInfo = (DataStoreAttributeInfo)i$.next();
          allDataStores.add(dataStoreAttributeInfo.getDataStore());
        }
      }
    }
    return allDataStores;
  }

  public Set<String> getAllExternalAttributes() {
    return this._externalAttributeDataStoresMap.keySet();
  }

  public boolean hasExternalAttributes() {
    return (!(this._externalAttributeDataStoresMap.isEmpty()));
  }

  public Set<DataStoreAttributeInfo> getDataStoresForExternalAttribute(String attributeName) {
    return ((Set)this._externalAttributeDataStoresMap.get(attributeName));
  }

  public void addExternalAttributeInfo(String attributeName, DataStoreAttributeInfo[] dataStoreAttributeInfos)
  {
    if (dataStoreAttributeInfos != null) {
      Set dataStores = getDataStoresSetForAttribute(attributeName);
      DataStoreAttributeInfo[] arr$ = dataStoreAttributeInfos; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { DataStoreAttributeInfo dataStoreAttributeInfo = arr$[i$];
        dataStores.add(dataStoreAttributeInfo);
      }
    }
  }

  public void addExternalAttributeInfo(String attributeName, Collection<DataStoreAttributeInfo> dataStoreAttributeInfos)
  {
    if ((dataStoreAttributeInfos != null) && (!(dataStoreAttributeInfos.isEmpty()))) {
      Set dataStores = getDataStoresSetForAttribute(attributeName);
      dataStores.addAll(dataStoreAttributeInfos);
    }
  }

  private Set<DataStoreAttributeInfo> getDataStoresSetForAttribute(String attributeName) {
    Set dataStores = (Set)this._externalAttributeDataStoresMap.get(attributeName);
    if (dataStores == null) {
      dataStores = new HashSet();
      this._externalAttributeDataStoresMap.put(attributeName, dataStores);
    }
    return dataStores;
  }

  public void addExternalAttributesInfo(Map<String, Set<DataStoreAttributeInfo>> externalAttributesMap)
  {
    for (Iterator i$ = externalAttributesMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
      Set dataStores = getDataStoresSetForAttribute((String)curEntry.getKey());
      dataStores.addAll((Collection)curEntry.getValue());
    }
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    ElementDataStoresInfoImpl that = (ElementDataStoresInfoImpl)o;

    if (this._dataStoreClassInfos != null) if (this._dataStoreClassInfos.equals(that._dataStoreClassInfos)) break label62; 
    else if (that._dataStoreClassInfos == null)
        break label62;
    return false;

    if (this._externalAttributeDataStoresMap != null) label62: if (this._externalAttributeDataStoresMap.equals(that._externalAttributeDataStoresMap)) break label95; 
    else if (that._externalAttributeDataStoresMap == null)
        break label95;
    return false;

    if (this._ucmdbClassName != null) label95: if (this._ucmdbClassName.equals(that._ucmdbClassName)) break label128;
    label128: return (that._ucmdbClassName == null);
  }

  public int hashCode()
  {
    int result = (this._ucmdbClassName != null) ? this._ucmdbClassName.hashCode() : 0;
    result = 29 * result + ((this._dataStoreClassInfos != null) ? this._dataStoreClassInfos.hashCode() : 0);
    result = 29 * result + ((this._externalAttributeDataStoresMap != null) ? this._externalAttributeDataStoresMap.hashCode() : 0);
    return result;
  }
}