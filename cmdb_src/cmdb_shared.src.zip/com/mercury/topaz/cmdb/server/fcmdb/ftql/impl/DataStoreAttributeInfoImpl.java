package com.mercury.topaz.cmdb.server.fcmdb.ftql.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStoreAttributeInfo;

public class DataStoreAttributeInfoImpl
  implements DataStoreAttributeInfo
{
  private String _dataStore;
  private String _className;
  private String _attributeName;

  DataStoreAttributeInfoImpl(String className, String attributeName, String dataStore)
  {
    this._dataStore = dataStore;
    this._className = className;
    this._attributeName = attributeName;
  }

  public String getDataStore() {
    return this._dataStore;
  }

  public String getClassName() {
    return this._className;
  }

  public String getAttributeName() {
    return this._attributeName;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    DataStoreAttributeInfoImpl that = (DataStoreAttributeInfoImpl)o;

    if (this._attributeName != null) if (this._attributeName.equals(that._attributeName)) break label62; 
    else if (that._attributeName == null) break label62;
    return false;

    if (this._className != null) label62: if (this._className.equals(that._className)) break label95; 
    else if (that._className == null) break label95;
    return false;

    if (this._dataStore != null) label95: if (this._dataStore.equals(that._dataStore)) break label128;
    label128: return (that._dataStore == null);
  }

  public int hashCode()
  {
    int result = (this._dataStore != null) ? this._dataStore.hashCode() : 0;
    result = 29 * result + ((this._className != null) ? this._className.hashCode() : 0);
    result = 29 * result + ((this._attributeName != null) ? this._attributeName.hashCode() : 0);
    return result;
  }
}