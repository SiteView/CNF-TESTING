package com.mercury.topaz.cmdb.server.fcmdb.manage.config;

import java.io.Serializable;
import java.util.Collection;

public abstract interface ClassAttributesDestinationsConfig extends Serializable
{
  public abstract String getClassName();

  public abstract boolean containsAttribute(String paramString);

  public abstract Collection<String> getAttributes();

  public abstract Collection<String> getDestinations(String paramString);

  public abstract int getDestinationsSize(String paramString);

  public abstract boolean containsDestination(String paramString1, String paramString2);

  public abstract void addAttributeDestination(String paramString1, String paramString2);

  public abstract void addAttributeDestinations(String paramString, Collection<String> paramCollection);

  public abstract boolean removeDataStoreForAttributes(String paramString, Collection<String> paramCollection);

  public abstract boolean removeDataStoreForAttributes(String paramString, String[] paramArrayOfString);

  public abstract void addDestinationAttributes(String paramString, Collection<String> paramCollection);

  public abstract boolean isEmpty();
}