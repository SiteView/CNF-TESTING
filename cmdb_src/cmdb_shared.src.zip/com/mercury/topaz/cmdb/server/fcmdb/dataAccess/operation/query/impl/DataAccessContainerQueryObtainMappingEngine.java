package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.mappingEngine.MappingEngine;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessContainerQueryObtainMappingEngine extends AbstractDataAccessContainerQuery
{
  private static final String RETRIEVE_RESULT = "Retrieve Result";
  private String _mappingEngineClassName;
  private String _srcDataStoreName;
  private String _trgDataStoreName;
  private MappingEngine _mappingEngine;

  public DataAccessContainerQueryObtainMappingEngine(String mappingEngineClassName, String srcDataStoreName, String trgDataStoreName)
  {
    setMappingEngineClassName(mappingEngineClassName);
    setSrcDataStoreName(srcDataStoreName);
    setTrgDataStoreName(trgDataStoreName);
  }

  private void setTrgDataStoreName(String trgDataStoreName) {
    if (trgDataStoreName == null)
      throw new IllegalArgumentException("target data store name is null or empty !!!");

    this._trgDataStoreName = trgDataStoreName;
  }

  public String getTrgDataStoreName() {
    return this._trgDataStoreName; }

  public String getOperationName() {
    return "data access query: get mapping engine instance";
  }

  private String getMappingEngineClassName()
  {
    return this._mappingEngineClassName;
  }

  private void setMappingEngineClassName(String mappingEngineClassName) {
    if ((mappingEngineClassName == null) || (mappingEngineClassName.length() == 0))
      throw new IllegalArgumentException("mapping engine java class name is null or empty !!!");

    this._mappingEngineClassName = mappingEngineClassName;
  }

  public String getSrcDataStoreName() {
    return this._srcDataStoreName;
  }

  private void setSrcDataStoreName(String srcDataStoreName) {
    if (srcDataStoreName == null)
      throw new IllegalArgumentException("source data store name is null or empty !!!");

    this._srcDataStoreName = srcDataStoreName;
  }

  public MappingEngine getMappingEngine() {
    return this._mappingEngine;
  }

  private void setMappingEngine(MappingEngine mappingEngine) {
    this._mappingEngine = mappingEngine;
  }

  public void dataAccessContainerExecute(DataAccessContainerManager dataAccessContainerManager, CmdbResponse response) throws AdapterAccessException {
    MappingEngine mappingEngine = dataAccessContainerManager.obtainMappingEngine(getMappingEngineClassName(), getSrcDataStoreName(), getTrgDataStoreName());
    response.addResult("Retrieve Result", mappingEngine);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setMappingEngine((MappingEngine)response.getResult("Retrieve Result"));
  }
}