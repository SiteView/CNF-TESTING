package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetFunctionsLayout;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetObjectsLayout;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.util.CalculationUtils;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.model.operation.query.ModelQueryGetFunctionsLayout;
import com.mercury.topaz.cmdb.server.model.operation.query.ModelQueryGetObjectsLayout;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryFactory;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrappers;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.function.impl.FunctionLayoutInMemoryCalculator;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FTqlCalculationQueryGetFunctionsLayout extends AbstractFTqlCalculationQuery
  implements ModelQueryGetFunctionsLayout
{
  private static final String KEY_RESULT_OBJECT = "result_objects";
  private ModelObjects _groupByObjects;
  private ModelObjects _aggregatedObjects;
  private ModelLinks _modelLinks;
  private LayoutFunctionWrappers _layoutFunctionWrappers;
  private CmdbObjects _resultObjects;

  public FTqlCalculationQueryGetFunctionsLayout(ModelObjects groupByObjects, ModelLinks modelLinks, ModelObjects aggregatedObjects, LayoutFunctionWrappers layoutFunctionWrappers)
  {
    setGroupByObjects(groupByObjects);
    setAggregatedObjects(aggregatedObjects);
    setModelLinks(modelLinks);
    setLayoutFunctionHandlers(layoutFunctionWrappers);
  }

  public void ftqlCalculationgExecuteQuery(FTqlCalculationManager fTqlCalculationManager, CmdbResponse cmdbResponse) {
    CmdbObjects cmdbObjects = getFunctionsLayout(fTqlCalculationManager);
    setResultObjects(cmdbObjects);
    cmdbResponse.addResult("result_objects", cmdbObjects); }

  private CmdbObjects getFunctionsLayout(FTqlCalculationManager fTqlCalculationManager) {
    CmdbObjects resultObjects;
    ClassModelDestinationsConfig classModelDestinationsConfig = FtqlUtils.getClassesDestinationsConfig();
    Map aggregatedClassifiedObjects = FtqlUtils.classifyByDataSource(getAggregatedObjects());
    Map groupByClassifiedObjects = FtqlUtils.classifyByDataSource(getGroupByObjects());

    if ((aggregatedClassifiedObjects.size() == 1) && (aggregatedClassifiedObjects.keySet().equals(groupByClassifiedObjects.keySet()))) {
      String dataStore = (String)aggregatedClassifiedObjects.keySet().iterator().next();
      if (!(FtqlUtils.isExternalDataStore(dataStore))) {
        ModelQueryGetFunctionsLayout modelQueryGetFunctionsLayout = ModelQueryFactory.getInternalModelQueryGetFunctionsLayoutOperation(getGroupByObjects(), getModelLinks(), getAggregatedObjects(), getLayoutFunctionHandlers());
        fTqlCalculationManager.executeOperation(modelQueryGetFunctionsLayout);
        resultObjects = modelQueryGetFunctionsLayout.getResultObjects();
      }
      else {
        DataAccessAdapterQueryGetFunctionsLayout getFunctionsLayout = new DataAccessAdapterQueryGetFunctionsLayout(dataStore, getGroupByObjects(), getModelLinks(), getAggregatedObjects(), getLayoutFunctionHandlers());
        fTqlCalculationManager.executeOperation(getFunctionsLayout);
        resultObjects = getFunctionsLayout.getResultObjects();
      }
    }
    else
    {
      CmdbObjects aggregatedObjectsWithProperties;
      ElementSimpleLayout elementSimpleLayout = CalculationUtils.createElementSimpleLayoutForFunctionLayoutInMemory(getLayoutFunctionHandlers());

      if (!(elementSimpleLayout.isEmpty())) {
        aggregatedObjectsWithProperties = CmdbObjectFactory.createObjects(getAggregatedObjects().size());
        for (Iterator i$ = aggregatedClassifiedObjects.entrySet().iterator(); i$.hasNext(); ) { CmdbObjects curObjects;
          Map.Entry entry = (Map.Entry)i$.next();

          String dataSource = (String)entry.getKey();
          ModelObjects curModelObjects = (ModelObjects)entry.getValue();

          if (!(FtqlUtils.isExternalDataStore(dataSource))) {
            ModelQueryGetObjectsLayout modelQueryGetObjectLayout = ModelQueryFactory.getInternalModelQueryGetObjectsLayoutOperation(elementSimpleLayout, curModelObjects);
            fTqlCalculationManager.executeOperation(modelQueryGetObjectLayout);
            curObjects = modelQueryGetObjectLayout.getOutgoingObjects();
          }
          else {
            DataAccessAdapterQueryGetObjectsLayout getObjectsLayout = new DataAccessAdapterQueryGetObjectsLayout(dataSource, elementSimpleLayout, curModelObjects);
            fTqlCalculationManager.executeOperation(getObjectsLayout);
            curObjects = getObjectsLayout.getOutgoingObjects();
          }
          aggregatedObjectsWithProperties.add(curObjects);
        }
      } else {
        aggregatedObjectsWithProperties = getAggregatedObjects().toCmdbObjects();
      }
      resultObjects = FunctionLayoutInMemoryCalculator.calculateObjectsFunctionLayout(getGroupByObjects(), getModelLinks(), aggregatedObjectsWithProperties, getLayoutFunctionHandlers());
    }
    return resultObjects;
  }

  public String getOperationName()
  {
    return "FTql Calculation Query: Get Functions Layout";
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    CmdbObjects cmdbObjects = (CmdbObjects)response.getResult("result_objects");
    setResultObjects(cmdbObjects);
  }

  private ModelObjects getGroupByObjects()
  {
    return this._groupByObjects;
  }

  private void setGroupByObjects(ModelObjects groupByObjects) {
    if (groupByObjects == null)
      throw new IllegalArgumentException("groupByObjects was null");

    if (groupByObjects.size() == 0)
      throw new IllegalArgumentException("groupByObjects was empty");

    this._groupByObjects = groupByObjects;
  }

  private ModelObjects getAggregatedObjects() {
    return this._aggregatedObjects;
  }

  private void setAggregatedObjects(ModelObjects aggregatedObjects) {
    if (aggregatedObjects == null)
      throw new IllegalArgumentException("aggregatedObjects was null");

    this._aggregatedObjects = aggregatedObjects;
  }

  private ModelLinks getModelLinks() {
    return this._modelLinks;
  }

  private void setModelLinks(ModelLinks modelLinks) {
    if (modelLinks == null)
      throw new IllegalArgumentException("modelLinks was null");

    this._modelLinks = modelLinks;
  }

  private LayoutFunctionWrappers getLayoutFunctionHandlers() {
    return this._layoutFunctionWrappers;
  }

  private void setLayoutFunctionHandlers(LayoutFunctionWrappers wrappers) {
    if (wrappers == null)
      throw new IllegalArgumentException("wrappers was null");

    this._layoutFunctionWrappers = wrappers;
  }

  public CmdbObjects getResultObjects() {
    return this._resultObjects;
  }

  private void setResultObjects(CmdbObjects resultObjects) {
    if (resultObjects == null)
      throw new IllegalArgumentException("resultObjects was null");

    this._resultObjects = resultObjects;
  }
}