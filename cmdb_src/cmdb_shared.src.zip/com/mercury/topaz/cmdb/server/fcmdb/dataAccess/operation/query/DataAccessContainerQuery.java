package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.DataAccessContainerOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;

public abstract interface DataAccessContainerQuery
{
}