package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ModifiableClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl.ClassDestinationsConfigFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.util.ConfigUtil;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.operation.query.impl.ClassModelQueryGetWholeClassModel;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.ModifiableFederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateFederationConfgOperation;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ConfigUpdateLocalUcmdbDataStore extends AbstractConfigUpdateFederationConfgOperation
{
  private Map<String, Collection<String>> _classesToAddUcmdbSupport = null;
  private Map<String, Collection<String>> _classesToRemoveUcmdbSupport = null;

  public ConfigUpdateLocalUcmdbDataStore(Map<String, Collection<String>> classesToAddUcmdbSupport, Map<String, Collection<String>> classesToRemoveUcmdbSupport)
  {
    this._classesToAddUcmdbSupport = classesToAddUcmdbSupport;
    this._classesToRemoveUcmdbSupport = classesToRemoveUcmdbSupport;
  }

  public String getOperationName()
  {
    return "Config Update Local Ucmdb Data Store";
  }

  protected void updateConfig(ModifiableFederationConfigDef federationConfigDef, ConfigUpdateManager configUpdateManager) {
    Iterator i$;
    Map.Entry curClassEntry;
    Iterator i$;
    String attribute;
    ModifiableClassModelDestinationsConfig classesDestinationsConfig = ClassDestinationsConfigFactory.createModifiableClassesDestinationsConfig(getClassesDestinationsConfig());
    if (this._classesToAddUcmdbSupport != null)
      for (i$ = this._classesToAddUcmdbSupport.entrySet().iterator(); i$.hasNext(); ) { curClassEntry = (Map.Entry)i$.next();
        if ((curClassEntry.getValue() == null) || (((Collection)curClassEntry.getValue()).isEmpty())) {
          Collection existedDestinations = classesDestinationsConfig.getDestinationsForClass((String)curClassEntry.getKey());
          if ((existedDestinations != null) && (!(existedDestinations.isEmpty()))) {
            classesDestinationsConfig.addDestinationForClass((String)curClassEntry.getKey(), "MERCURY_CMDB");
            federationConfigDef.addUcmdbSupportClass((String)curClassEntry.getKey());
          }
        }
        else {
          for (i$ = ((Collection)curClassEntry.getValue()).iterator(); i$.hasNext(); ) { attribute = (String)i$.next();
            Collection existedDestinations = classesDestinationsConfig.getDestinationsForClassAndAttribute((String)curClassEntry.getKey(), attribute);
            if ((existedDestinations != null) && (!(existedDestinations.isEmpty()))) {
              classesDestinationsConfig.addDestinationForClassAndAttribute((String)curClassEntry.getKey(), attribute, "MERCURY_CMDB");
              federationConfigDef.addUcmdbSupportClassAttribute((String)curClassEntry.getKey(), attribute);
            }
          }
        }
      }

    if (this._classesToRemoveUcmdbSupport != null)
      for (i$ = this._classesToRemoveUcmdbSupport.entrySet().iterator(); i$.hasNext(); ) { curClassEntry = (Map.Entry)i$.next();
        if ((curClassEntry.getValue() == null) || (((Collection)curClassEntry.getValue()).isEmpty())) {
          classesDestinationsConfig.removeDestinationForClass((String)curClassEntry.getKey(), "MERCURY_CMDB");
          federationConfigDef.removeUcmdbSupportClass((String)curClassEntry.getKey());
        }
        else {
          classesDestinationsConfig.removeDestinationForClassAndAttributes((String)curClassEntry.getKey(), "MERCURY_CMDB", (Collection)curClassEntry.getValue());
          for (i$ = ((Collection)curClassEntry.getValue()).iterator(); i$.hasNext(); ) { attribute = (String)i$.next();
            federationConfigDef.removeUcmdbSupportClassAttribute((String)curClassEntry.getKey(), attribute);
          }
        }
      }

    ConfigUtil.updateClassModelDestinationsConfigCache(classesDestinationsConfig);
  }

  protected ClassModelDestinationsConfig getClassesDestinationsConfig()
  {
    ClassModelQueryGetWholeClassModel getClassModel = new ClassModelQueryGetWholeClassModel();
    ServerApiFacade.executeOperation(getClassModel);
    return getClassModel.getClassModel().getClassesDestinationsConfig();
  }
}