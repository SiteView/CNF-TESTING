package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.ModifiableFederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.SynchConfigUnitDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateFederationConfgOperation;

public class ConfigUpdateSynchUnitConfigUpdate extends AbstractConfigUpdateFederationConfgOperation
{
  private SynchConfigUnitDef _synchConfigUnitDef;

  public ConfigUpdateSynchUnitConfigUpdate(SynchConfigUnitDef synchConfigUnitDef)
  {
    setSynchConfigUnitDef(synchConfigUnitDef);
  }

  private SynchConfigUnitDef getSynchConfigUnitDef() {
    return this._synchConfigUnitDef;
  }

  private void setSynchConfigUnitDef(SynchConfigUnitDef synchConfigUnitDef) {
    this._synchConfigUnitDef = synchConfigUnitDef;
  }

  public String getOperationName() {
    return "Config Update: Synch Unit Config Update";
  }

  protected void updateConfig(ModifiableFederationConfigDef federationConfigDef, ConfigUpdateManager configUpdateManager)
  {
    federationConfigDef.updateSynchronizationConfigUnitDef(getSynchConfigUnitDef());
  }
}