package com.mercury.topaz.cmdb.server.fcmdb.manage.config.load.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.load.FederationConfigurationLoader;
import com.mercury.topaz.cmdb.server.fcmdb.util.file.FileReaderUtil;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.FederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.exception.FConfigException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.xml.ConfigXmlUtil;
import java.io.IOException;

class XmlFileFederationLoaderImpl
  implements FederationConfigurationLoader
{
  private String _fullFileName;

  public XmlFileFederationLoaderImpl(String fullFileName)
  {
    setFullFileName(fullFileName); }

  public FederationConfigDef loadFederationConfigDef() {
    String federationConfigStr;
    try {
      federationConfigStr = FileReaderUtil.getFileContentAsString(getFullFileName());
      return ConfigXmlUtil.fromXmlToFederationConfigDef(federationConfigStr);
    } catch (IOException e) {
      throw new FConfigException("cannot load federation config from xml file [" + getFullFileName() + "] due to error : " + e.getMessage(), e);
    }
  }

  private String getFullFileName() {
    return this._fullFileName;
  }

  private void setFullFileName(String fullFileName) {
    if ((fullFileName == null) || (fullFileName.length() == 0))
      throw new IllegalArgumentException("federation config xml file name is empty or null !!!");

    this._fullFileName = fullFileName;
  }
}