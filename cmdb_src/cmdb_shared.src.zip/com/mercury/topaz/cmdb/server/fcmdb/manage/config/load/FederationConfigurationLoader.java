package com.mercury.topaz.cmdb.server.fcmdb.manage.config.load;

import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.FederationConfigDef;

public abstract interface FederationConfigurationLoader
{
  public abstract FederationConfigDef loadFederationConfigDef();
}