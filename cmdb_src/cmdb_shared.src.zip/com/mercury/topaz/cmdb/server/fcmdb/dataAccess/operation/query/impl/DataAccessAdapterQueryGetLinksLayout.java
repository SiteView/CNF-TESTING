package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessCommunicationException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;

public class DataAccessAdapterQueryGetLinksLayout extends AbstractDataAccessLifeCycleAdapterQuery
{
  private ElementSimpleLayout _layout;
  private CmdbLinks _resultLinks;
  private ModelLinks _modelLinks;
  protected static final String RESULT_KEY = "result_key";

  public DataAccessAdapterQueryGetLinksLayout(String destinationId, ModelLinks links, ElementSimpleLayout layout)
  {
    super(destinationId);
    setModelLinks(links);
    setLayout(layout);
  }

  protected StringBuilder getOutputInfo() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("resultLinks: ").append(getResultLinks());
    return stringBuilder;
  }

  protected StringBuilder getInputInfo() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" Destination id:").append(getDestinationId()).append(" ModelLinks: ").append(getModelLinks()).append(" layout: ").append(getLayout());
    return stringBuilder;
  }

  protected void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws AdapterAccessException
  {
    CmdbLinks resultLinks = getLinksLayout(dataAccessManager, getModelLinks(), getLayout());
    setResultLinks(resultLinks);
    response.addResult("result_key", resultLinks);
  }

  public String getOperationName()
  {
    return "DataAccessAdapterQuery: Get Links Layout";
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setResultLinks((CmdbLinks)response.getResult("result_key"));
  }

  public CmdbLinks getResultLinks() {
    return this._resultLinks;
  }

  private CmdbLinks getLinksLayout(DataAccessAdapterManager dataAccessManager, ModelLinks modelLinks, ElementSimpleLayout layout) throws AdapterAccessCommunicationException
  {
    BasicDataAdapterWrapper adapterWrapper = getAdapter(dataAccessManager);
    BasicDataAdapter adapter = adapterWrapper.getBasicDataAdapter();
    CalculationStrategy calculationStrategy = getCalculationStrategy(dataAccessManager, adapterWrapper.getAdapterId());
    return calculationStrategy.getLinksLayout((FTqlDataAdapter)adapter, modelLinks, layout, getDestinationId());
  }

  private ElementSimpleLayout getLayout()
  {
    return this._layout;
  }

  private void setLayout(ElementSimpleLayout layout) {
    this._layout = layout;
  }

  private void setResultLinks(CmdbLinks resultLinks)
  {
    this._resultLinks = resultLinks;
  }

  private ModelLinks getModelLinks() {
    return this._modelLinks;
  }

  private void setModelLinks(ModelLinks modelLinks) {
    this._modelLinks = modelLinks;
  }
}