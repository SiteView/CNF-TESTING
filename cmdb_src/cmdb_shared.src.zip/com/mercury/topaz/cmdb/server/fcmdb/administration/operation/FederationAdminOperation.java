package com.mercury.topaz.cmdb.server.fcmdb.administration.operation;

import com.mercury.topaz.cmdb.server.fcmdb.administration.manager.FederationAdminManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.CmdbOperation;

public abstract interface FederationAdminOperation extends CmdbOperation
{
  public abstract void federationAdminExecute(FederationAdminManager paramFederationAdminManager, CmdbResponse paramCmdbResponse)
    throws AdapterAccessException;
}