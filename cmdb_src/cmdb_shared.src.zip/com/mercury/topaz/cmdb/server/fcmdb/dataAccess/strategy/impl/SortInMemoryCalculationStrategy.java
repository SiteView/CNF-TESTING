package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.impl;

import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.ResultStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.util.CalculationUtils;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;

public class SortInMemoryCalculationStrategy
  implements ResultStrategy
{
  public CmdbObjectIds sortObjects(FTqlDataAdapter adapter, ModelObjects objects, CmdbSortCommand sortCommand, CalculationStrategy calculationStrategy, String dataStore)
    throws AdapterAccessException
  {
    return CalculationUtils.sortObjectsInMemory(adapter, objects, sortCommand, calculationStrategy, dataStore);
  }

  public CmdbObjectIds sortObjects(FTqlDataAdapter adapter, ElementCondition elementCondition, CmdbSortCommand sortCommand, CalculationStrategy calculationStrategy, String dataStore) throws AdapterAccessException, DataAccessException {
    return CalculationUtils.sortObjectsInMemory(adapter, elementCondition, sortCommand, calculationStrategy, dataStore);
  }

  public CmdbLinks sortLinks(FTqlDataAdapter adapter, ModelLinks links, CmdbSortCommand sortCommand, CalculationStrategy calculationStrategy, String dataStore) throws AdapterAccessException {
    return CalculationUtils.sortLinksInMemory(adapter, links, sortCommand, calculationStrategy, dataStore);
  }
}