package com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassAttributesDestinationsConfig;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ClassAttributesDestinationsConfigImpl
  implements ClassAttributesDestinationsConfig
{
  String _className;
  Map<String, Set<String>> _attributesDestinationMap;

  public ClassAttributesDestinationsConfigImpl(String className, Map<String, Set<String>> attributesDestinationMap)
  {
    this._className = className;
    this._attributesDestinationMap = attributesDestinationMap; }

  public ClassAttributesDestinationsConfigImpl(String className) {
    this._className = className;
    this._attributesDestinationMap = new HashMap();
  }

  public ClassAttributesDestinationsConfigImpl(ClassAttributesDestinationsConfig classAttributesDestinationsConfig) {
    this._className = classAttributesDestinationsConfig.getClassName();
    this._attributesDestinationMap = new HashMap();
    Collection attributes = classAttributesDestinationsConfig.getAttributes();
    for (Iterator i$ = attributes.iterator(); i$.hasNext(); ) { String attribute = (String)i$.next();
      addAttributeDestinations(attribute, classAttributesDestinationsConfig.getDestinations(attribute));
    }
  }

  public void addAttributeDestination(String attributeName, String destination) {
    Set destinations = (Set)this._attributesDestinationMap.get(attributeName);
    if (destinations == null) {
      destinations = new HashSet();
      this._attributesDestinationMap.put(attributeName, destinations);
    }
    destinations.add(destination);
  }

  public void addAttributeDestinations(String attributeName, Collection<String> destinationsToAdd) {
    if ((destinationsToAdd != null) && (!(destinationsToAdd.isEmpty()))) {
      Set destinations = (Set)this._attributesDestinationMap.get(attributeName);
      if (destinations == null) {
        destinations = new HashSet();
        this._attributesDestinationMap.put(attributeName, destinations);
      }
      destinations.addAll(destinationsToAdd);
    }
  }

  public void addDestinationAttributes(String destinationId, Collection<String> attributes) {
    for (Iterator i$ = attributes.iterator(); i$.hasNext(); ) { String attribute = (String)i$.next();
      addAttributeDestination(attribute, destinationId);
    }
  }

  public boolean isEmpty() {
    return this._attributesDestinationMap.isEmpty();
  }

  public boolean removeDataStoreForAttributes(String destinationId, Collection<String> attributes) {
    boolean wasRemoved = false;
    for (Iterator i$ = attributes.iterator(); i$.hasNext(); ) { String attribute = (String)i$.next();
      Collection dataStores = (Collection)this._attributesDestinationMap.get(attribute);
      if (dataStores != null)
        wasRemoved = (removeDataStoreForAttribute(attribute, destinationId)) || (wasRemoved);
    }

    return wasRemoved;
  }

  public boolean removeDataStoreForAttributes(String destinationId, String[] attributes) {
    boolean wasRemoved = false;
    String[] arr$ = attributes; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String attribute = arr$[i$];
      wasRemoved = (removeDataStoreForAttribute(attribute, destinationId)) || (wasRemoved);
    }
    return wasRemoved;
  }

  private boolean removeDataStoreForAttribute(String attribute, String destinationId) {
    boolean wasRemoved = false;
    Collection dataStores = (Collection)this._attributesDestinationMap.get(attribute);
    if (dataStores != null) {
      wasRemoved = dataStores.remove(destinationId);
      if ((dataStores.isEmpty()) || ((dataStores.size() == 1) && (dataStores.contains("MERCURY_CMDB"))))
        this._attributesDestinationMap.remove(attribute);
    }

    return wasRemoved;
  }

  public String getClassName() {
    return this._className;
  }

  public boolean containsAttribute(String attribute) {
    return this._attributesDestinationMap.containsKey(attribute);
  }

  public Collection<String> getAttributes() {
    return this._attributesDestinationMap.keySet();
  }

  public Collection<String> getDestinations(String attribute) {
    return ((Collection)this._attributesDestinationMap.get(attribute));
  }

  public int getDestinationsSize(String attribute) {
    if (containsAttribute(attribute))
      return ((Set)this._attributesDestinationMap.get(attribute)).size();

    return 0;
  }

  public boolean containsDestination(String attribute, String destination) {
    if (containsAttribute(attribute))
      return ((Set)this._attributesDestinationMap.get(attribute)).contains(destination);

    return false;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    ClassAttributesDestinationsConfigImpl that = (ClassAttributesDestinationsConfigImpl)o;

    if (this._attributesDestinationMap != null) if (this._attributesDestinationMap.equals(that._attributesDestinationMap)) break label62; 
    else if (that._attributesDestinationMap == null)
        break label62;
    return false;

    if (this._className != null) label62: if (this._className.equals(that._className)) break label95;
    label95: return (that._className == null);
  }

  public int hashCode()
  {
    int result = (this._className != null) ? this._className.hashCode() : 0;
    result = 29 * result + ((this._attributesDestinationMap != null) ? this._attributesDestinationMap.hashCode() : 0);
    return result;
  }
}