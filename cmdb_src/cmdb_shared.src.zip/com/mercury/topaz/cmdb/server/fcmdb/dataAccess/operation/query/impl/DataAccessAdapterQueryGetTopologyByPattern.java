package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.VirtualLinkInfo;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyResult;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyQueryDefinition;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessAdapterQueryGetTopologyByPattern extends AbstractDataAccessLifeCycleAdapterQuery
{
  private static final String RETRIEVE_RESULT = "Retrieve Result";
  private TopologyQueryDefinition _topologyQueryDefinition;
  private ReconciliationData _reconciliationData;
  private ExternalTopologyResult _topologyResult;
  private String _virtualLinkEndNodeName;
  private VirtualLinkInfo _virtualLinkInfo;

  public DataAccessAdapterQueryGetTopologyByPattern(String destinationId, TopologyQueryDefinition topologyQueryDefinition, String virtualLinkEndNodeName, ReconciliationData reconciliationData, VirtualLinkInfo virtualLinkInfo)
  {
    super(destinationId);
    setTopologyQueryDefinition(topologyQueryDefinition);
    setReconciliationData(reconciliationData);
    setVirtualLinkEndNodeName(virtualLinkEndNodeName);
    setVirtualLinkInfo(virtualLinkInfo);
  }

  public DataAccessAdapterQueryGetTopologyByPattern(String destinationId, TopologyQueryDefinition topologyQueryDefinition) {
    super(destinationId);
    setTopologyQueryDefinition(topologyQueryDefinition);
    setReconciliationData(null);
    setVirtualLinkEndNodeName(null);
    setVirtualLinkInfo(null);
  }

  public String getVirtualLinkEndNodeName() {
    return this._virtualLinkEndNodeName;
  }

  public void setVirtualLinkEndNodeName(String virtualLinkEndNodeName) {
    this._virtualLinkEndNodeName = virtualLinkEndNodeName;
  }

  public VirtualLinkInfo getVirtualLinkInfo() {
    return this._virtualLinkInfo;
  }

  public void setVirtualLinkInfo(VirtualLinkInfo virtualLinkInfo) {
    this._virtualLinkInfo = virtualLinkInfo;
  }

  public ReconciliationData getReconciliationData()
  {
    return this._reconciliationData;
  }

  public void setReconciliationData(ReconciliationData reconciliationData) {
    this._reconciliationData = reconciliationData;
  }

  public String getOperationName() {
    return "Data Access Query: Calculate By Pattern";
  }

  public void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws AdapterAccessException, DataAccessException {
    ExternalTopologyResult topologyResult = getTopology(dataAccessManager);
    response.addResult("Retrieve Result", topologyResult);
  }

  private ExternalTopologyResult getTopology(DataAccessAdapterManager dataAccessManager) throws AdapterAccessException, DataAccessException {
    BasicDataAdapterWrapper adapterWrapper = getAdapter(dataAccessManager);
    BasicDataAdapter adapter = adapterWrapper.getBasicDataAdapter();
    CalculationStrategy calculationStrategy = getCalculationStrategy(dataAccessManager, adapterWrapper.getAdapterId());
    return calculationStrategy.calculateTopology((FTqlDataAdapter)adapter, getTopologyQueryDefinition(), getReconciliationData(), getVirtualLinkEndNodeName(), getVirtualLinkInfo());
  }

  private void setTopologyQueryDefinition(TopologyQueryDefinition topologyQueryDefinition)
  {
    this._topologyQueryDefinition = topologyQueryDefinition;
  }

  public TopologyQueryDefinition getTopologyQueryDefinition() {
    return this._topologyQueryDefinition;
  }

  public ExternalTopologyResult getTopologyResult()
  {
    return this._topologyResult;
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    this._topologyResult = ((ExternalTopologyResult)response.getResult("Retrieve Result"));
  }

  protected StringBuilder getOutputInfo() {
    return new StringBuilder("Topology Result: ").append(getTopologyResult());
  }

  protected StringBuilder getInputInfo() {
    return new StringBuilder("Target ID: ").append(getDestinationId()).append(", Pattern Graph: ").append(getTopologyQueryDefinition()).append(",Reconciliation Data: ").append(getReconciliationData());
  }
}