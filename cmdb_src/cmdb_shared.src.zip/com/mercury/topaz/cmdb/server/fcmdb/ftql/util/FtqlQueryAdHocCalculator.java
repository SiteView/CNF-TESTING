package com.mercury.topaz.cmdb.server.fcmdb.ftql.util;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.fcmdb.base.log.FCmdbLogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.model.datasource.TqlExtendedModelDataSourceQuery;
import com.mercury.topaz.cmdb.server.tql.calculator.GeneralCalculationData;
import com.mercury.topaz.cmdb.server.tql.calculator.TqlCalculator;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.FederatedPatternGraphUtils;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.PatternGraphWithSingleDataStoreElements;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.attribute.ExtendedAttributeGraphTransformer;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.attribute.ExtendedAttributeResultTransformer;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.attribute.impl.ExtendedAttributeFactory;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.attribute.impl.ExtendedAttributesTqlResult;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.layout.ExtendedLayoutAnalyzer;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.layout.impl.ExtendedLayoutFactory;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.multiple.MultyDataSourceGraphMultiplier;
import com.mercury.topaz.cmdb.server.tql.calculator.federation.multiple.impl.MultyDataSourceGraphMultiplierFactory;
import com.mercury.topaz.cmdb.server.tql.calculator.impl.EmptyPreliminaryCalcData;
import com.mercury.topaz.cmdb.server.tql.calculator.impl.FederatedCalculationStateCreator;
import com.mercury.topaz.cmdb.server.tql.calculator.impl.GeneralCalculationDataFactory;
import com.mercury.topaz.cmdb.server.tql.calculator.impl.TqlCalculationFactory;
import com.mercury.topaz.cmdb.server.tql.definition.PatternCompiler;
import com.mercury.topaz.cmdb.server.tql.definition.impl.PatternCompilerFactory;
import com.mercury.topaz.cmdb.server.tql.definition.impl.PatternGraphUtils;
import com.mercury.topaz.cmdb.server.tql.result.impl.EmptyTqlServerResult;
import com.mercury.topaz.cmdb.server.tql.result.impl.TqlResultServerFactory;
import com.mercury.topaz.cmdb.server.tql.result.utils.impl.TqlResultServerUtils;
import com.mercury.topaz.cmdb.server.util.time.CmdbTime;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.LinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph.Utils;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocServerCmdbTqlResult;
import com.mercury.topaz.cmdb.shared.tql.result.TqlModifiableResult;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResult;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class FtqlQueryAdHocCalculator
{
  private PatternCompiler patternCompiler;
  private PatternLayout requiredLayout;
  private FederatedPatternGraphUtils originalGraphFederatedUtils;
  Log _log = FCmdbLogFactory.getFcmdbFtqlCalcLog();
  private StringBuilder _logMessage;
  private TqlCalculator calculator;
  private TqlExtendedModelDataSourceQuery federatedModelQuery;

  public FtqlQueryAdHocCalculator(PatternCompiler patternCompiler, PatternLayout requiredLayout, FederatedPatternGraphUtils originalGraphFederatedUtils)
  {
    this.patternCompiler = patternCompiler;
    this.requiredLayout = requiredLayout;
    this.originalGraphFederatedUtils = originalGraphFederatedUtils;
  }

  public TqlResult calculateTql(FTqlCalculationManager federatedManager)
  {
    TqlResult tqlResultNoLayout;
    this.federatedModelQuery = federatedManager.getDataSourceQuery();

    if (this._log.isInfoEnabled()) {
      this._logMessage = new StringBuilder("\n****  Start  FtqlQueryGetAdHocTqlResult [" + this.patternCompiler.getPattern().getID().getPatternName() + "] ****\n");
    }

    this.calculator = TqlCalculationFactory.getTqlCalculator(federatedManager.getSynchronizedClassModel(), federatedManager.getConditionStatisticsManager());
    try
    {
      long t0 = CmdbTime.currentTimeMillis();
      try
      {
        PatternGraph originalGraph = this.patternCompiler.getPattern().getPatternGraph();
        Collection graphsCollection = splitMultipleDataSourceElements(originalGraph, this.originalGraphFederatedUtils);
        graphsCollection = removeIncompatibleIds(graphsCollection);

        if (graphsCollection.size() == 1)
        {
          PatternGraphWithSingleDataStoreElements graphData = (PatternGraphWithSingleDataStoreElements)graphsCollection.iterator().next();
          tqlResultNoLayout = calculateGraphWithPotentiallyFederatedAttributes(graphData.graph, graphData.federatedPatternGraphUtils, createSubPatternCompiler(this.patternCompiler, "", graphData.graph));
        } else {
          List graphResList = new ArrayList(graphsCollection.size());

          if (this._log.isInfoEnabled()) {
            this._logMessage.append("Pattern contains elements with multiple data sources and was multipy to [").append(graphsCollection.size()).append("] graphs\n");
          }

          int counter = 0;
          for (Iterator i$ = graphsCollection.iterator(); i$.hasNext(); ) { PatternGraphWithSingleDataStoreElements graphWithSingleDataStoreElements = (PatternGraphWithSingleDataStoreElements)i$.next();
            if (this._log.isDebugEnabled())
              this._logMessage.append("Multipy graph [").append(PatternGraph.Utils.getGraphDescription(graphWithSingleDataStoreElements.graph)).append("] with the following data sources: " + graphWithSingleDataStoreElements.federatedPatternGraphUtils + " is calculated ...\n");
            else if (this._log.isInfoEnabled())
              this._logMessage.append("Multipy graph [").append(counter).append("] is calculated ...\n");

            TqlResult subResult = calculateSubPatternWithPotentiallyFederatedAttributes("" + (++counter), this.patternCompiler, graphWithSingleDataStoreElements.graph, graphWithSingleDataStoreElements.federatedPatternGraphUtils);
            graphResList.add(subResult);
          }
          tqlResultNoLayout = unifyTqlResults(graphResList, PatternGraphFactory.createGraphDictionary(this.patternCompiler.getPattern().getPatternGraph()));
        }

      }

      long t1 = CmdbTime.currentTimeMillis();

      if (this._log.isInfoEnabled())
        this._logMessage.append("Federated calculation ended, running time [").append(t1 - t0).append("ms], result size [").append(tqlResultNoLayout.size()).append("]\n");

    }
    finally
    {
      if (this._log.isInfoEnabled())
        this._log.info(this._logMessage);

    }

    if (tqlResultNoLayout instanceof ExtendedAttributesTqlResult) {
      return tqlResultNoLayout;
    }

    return new ExtendedAttributesTqlResult(tqlResultNoLayout, ExtendedLayoutFactory.createExtendedLayoutAnalyzer(this.originalGraphFederatedUtils));
  }

  private Collection<PatternGraphWithSingleDataStoreElements> removeIncompatibleIds(Collection<PatternGraphWithSingleDataStoreElements> graphsCollection)
  {
    for (Iterator i$ = graphsCollection.iterator(); i$.hasNext(); ) { PatternGraphWithSingleDataStoreElements graphWithSingleDataStoreElements = (PatternGraphWithSingleDataStoreElements)i$.next();
      removeIncompatibleIds(graphWithSingleDataStoreElements);
    }
    return graphsCollection;
  }

  private PatternGraphWithSingleDataStoreElements removeIncompatibleIds(PatternGraphWithSingleDataStoreElements graphWithSingleDataStoreElements) {
    graphWithSingleDataStoreElements.graph = IncompatibleIdsRemover.removeIncompatibleIds(graphWithSingleDataStoreElements.graph, graphWithSingleDataStoreElements.federatedPatternGraphUtils);
    return graphWithSingleDataStoreElements;
  }

  private TqlResult unifyTqlResults(List<TqlResult> graphResultsList, LinksDictionary graphDictionary) {
    TqlModifiableResult unifiedResult = TqlResultServerFactory.createModifiableResult(graphDictionary);
    ExtendedLayoutAnalyzer unifiedExtendedLayoutAnalyzer = null;
    for (Iterator i$ = graphResultsList.iterator(); i$.hasNext(); ) { TqlResult graphResult = (TqlResult)i$.next();
      TqlResultServerUtils.addReuslts(unifiedResult, graphResult);
      if (graphResult instanceof ExtendedAttributesTqlResult) {
        ExtendedLayoutAnalyzer currentExtendedLayoutAnalyzer = ((ExtendedAttributesTqlResult)graphResult).getExtendedLayoutAnalyzer();
        if (unifiedExtendedLayoutAnalyzer == null) {
          unifiedExtendedLayoutAnalyzer = currentExtendedLayoutAnalyzer;
        }
        else
          unifiedExtendedLayoutAnalyzer.unifyExtendedWithIdsData(currentExtendedLayoutAnalyzer);
      }

    }

    if (unifiedExtendedLayoutAnalyzer == null) {
      return unifiedResult;
    }

    return new ExtendedAttributesTqlResult(unifiedResult, unifiedExtendedLayoutAnalyzer);
  }

  private TqlResult calculateCmdbGraph(PatternCompiler patternCompiler)
  {
    TqlQueryGetAdHocServerCmdbTqlResult calculateCmdbGraph = new TqlQueryGetAdHocServerCmdbTqlResult(patternCompiler.getPattern());
    ServerApiFacade.executeOperation(calculateCmdbGraph);
    return calculateCmdbGraph.getServerTqlResult();
  }

  private Collection<PatternGraphWithSingleDataStoreElements> splitMultipleDataSourceElements(PatternGraph graphWithPotentillayMultipleDS, FederatedPatternGraphUtils originalGraphFederatedUtils) {
    MultyDataSourceGraphMultiplier multiplier = MultyDataSourceGraphMultiplierFactory.createMultyDataSourceGraphMultiplier();
    return multiplier.multiply(graphWithPotentillayMultipleDS, originalGraphFederatedUtils);
  }

  private TqlResult calculateGraphWithPotentiallyFederatedAttributes(PatternGraph graphToCalculate, FederatedPatternGraphUtils graphToCalculateFederatedUtils, PatternCompiler patternCompiler) {
    ExtendedAttributeGraphTransformer transformer = ExtendedAttributeFactory.createExtendedAttributeGraphTransformer();
    PatternGraphWithSingleDataStoreElements transformedGraphData = transformer.transform(graphToCalculate, graphToCalculateFederatedUtils);
    if (transformedGraphData.graph == graphToCalculate)
      return calculate(patternCompiler, graphToCalculateFederatedUtils);

    if (this._log.isInfoEnabled()) {
      this._logMessage.append("graph contains extended attributes");
      if (this._log.isDebugEnabled())
        this._logMessage.append(" and was transformed into:").append(PatternGraph.Utils.getGraphDescription(transformedGraphData.graph) + " with the following data sources: " + transformedGraphData.federatedPatternGraphUtils);

      this._logMessage.append("\n");
    }
    TqlResult transformedGraphResult = calculateSubPattern("WithoutExtendedAttributes", patternCompiler, transformedGraphData.graph, transformedGraphData.federatedPatternGraphUtils);
    return transformResultWithFederatedAttributes(graphToCalculate, transformedGraphData, transformedGraphResult, this.requiredLayout);
  }

  private TqlResult transformResultWithFederatedAttributes(PatternGraph originalGraph, PatternGraphWithSingleDataStoreElements transformedGraphData, TqlResult transformedGraphResult, PatternLayout layout)
  {
    ExtendedAttributeResultTransformer transformer = ExtendedAttributeFactory.createExtendedAttributeResultTransformer();
    return transformer.transform(originalGraph, this.originalGraphFederatedUtils, transformedGraphData.graph, transformedGraphData.federatedPatternGraphUtils, transformedGraphResult, layout);
  }

  private TqlResult calculateSubPattern(String subPatternNameSuffix, PatternCompiler originalPatternCompiler, PatternGraph graphToCalculate, FederatedPatternGraphUtils graphToCalculateFederatedUtils) {
    PatternCompiler curPatternCompiler = createSubPatternCompiler(originalPatternCompiler, subPatternNameSuffix, graphToCalculate);
    return calculate(curPatternCompiler, graphToCalculateFederatedUtils);
  }

  private TqlResult calculate(PatternCompiler patternCompiler, FederatedPatternGraphUtils graphToCalculateFederatedUtils) {
    return this.calculator.calculate(patternCompiler, EmptyTqlServerResult.getInstance(), this.federatedModelQuery, EmptyPreliminaryCalcData.getInstance(), createCalculationData(patternCompiler), new FederatedCalculationStateCreator(graphToCalculateFederatedUtils));
  }

  private TqlResult calculateSubPatternWithPotentiallyFederatedAttributes(String subPatternNameSuffix, PatternCompiler originalPatternCompiler, PatternGraph graphToCalculate, FederatedPatternGraphUtils graphToCalculateFederatedUtils)
  {
    if (graphToCalculateFederatedUtils.isFederated()) {
      curPatternCompiler = createSubPatternCompiler(originalPatternCompiler, subPatternNameSuffix, graphToCalculate);
      return calculateGraphWithPotentiallyFederatedAttributes(graphToCalculate, graphToCalculateFederatedUtils, curPatternCompiler);
    }

    graphToCalculate = PatternGraphUtils.getSimilarGraphWithOnlyVisibleElements(graphToCalculate);
    PatternCompiler curPatternCompiler = createSubPatternCompiler(originalPatternCompiler, subPatternNameSuffix, graphToCalculate);
    return calculateCmdbGraph(curPatternCompiler);
  }

  private PatternCompiler createSubPatternCompiler(PatternCompiler originalPatternCompiler, String subPatternNameSuffix, PatternGraph graphToCalculate)
  {
    Pattern pattern = PatternDefinitionFactory.createPattern("", originalPatternCompiler.getPattern().getName() + subPatternNameSuffix, originalPatternCompiler.getPattern().getGroupId(), graphToCalculate);
    return PatternCompilerFactory.createPatternCompiler(pattern);
  }

  private GeneralCalculationData createCalculationData(PatternCompiler patternCompiler) {
    return GeneralCalculationDataFactory.create(true, patternCompiler.getPattern());
  }
}