package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessContainerQueryGetCalculationStrategy extends AbstractDataAccessContainerQuery
{
  private String _adapterId;
  private CalculationStrategy _calculationStrategy;

  public DataAccessContainerQueryGetCalculationStrategy(String adapterId)
  {
    setAdapterId(adapterId);
  }

  private String getAdapterId() {
    return this._adapterId;
  }

  private void setAdapterId(String adapterId) {
    this._adapterId = adapterId;
  }

  public String getOperationName()
  {
    return "DataAccessContainerQuery: Get Calculation Strategy";
  }

  public void dataAccessContainerExecute(DataAccessContainerManager dataAccessContainerManager, CmdbResponse response) throws AdapterAccessException {
    setCalculationStrategy(dataAccessContainerManager.getCalculationStrategy(getAdapterId()));
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
  }

  public CalculationStrategy getCalculationStrategy() {
    return this._calculationStrategy;
  }

  private void setCalculationStrategy(CalculationStrategy calculationStrategy) {
    this._calculationStrategy = calculationStrategy;
  }
}