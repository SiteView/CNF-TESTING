package com.mercury.topaz.cmdb.server.fcmdb.ftql.calculation.impl;

import com.hp.ucmdb.federationspi.data.query.reconciliation.IdReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationObject;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationObjectFactory;
import com.hp.ucmdb.federationspi.data.query.reconciliation.TopologyReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.VirtualLinkInfo;
import com.hp.ucmdb.federationspi.data.query.result.ExternalResultFactory;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyOneNodeResult;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyPatternResult;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyResult;
import com.hp.ucmdb.federationspi.data.query.topology.Topology;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyQueryDefinition;
import com.hp.ucmdb.federationspi.data.query.types.ExternalCiId;
import com.hp.ucmdb.federationspi.data.query.types.ExternalIdFactory;
import com.hp.ucmdb.federationspi.data.query.types.ExternalRelationId;
import com.hp.ucmdb.federationspi.data.query.types.ReconciliationIdFactory;
import com.hp.ucmdb.federationspi.data.query.types.TopologyCI;
import com.hp.ucmdb.federationspi.data.query.types.TopologyRelation;
import com.hp.ucmdb.federationspi.mappingEngine.MappingEngine;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetTopologyByPattern;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.util.CalculationUtils;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.calculation.FederatedPatternCalculator;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.impl.FTqlConditionStatisticsManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.reconciliation.VirtualLinkInfoFactory;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.result.ExternalTopologyOneNodeResultImpl;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.result.ExternalTopologyPatternResultImpl;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.model.graph.link.impl.ModelLinkFactory;
import com.mercury.topaz.cmdb.server.tql.calculator.start.mapper.impl.GraphToConditionMapper;
import com.mercury.topaz.cmdb.server.tql.calculator.start.mapper.impl.ObjectToConditionMapperFactory;
import com.mercury.topaz.cmdb.server.tql.result.impl.EmptyTqlServerResult;
import com.mercury.topaz.cmdb.server.tql.result.impl.TqlResultServerFactory;
import com.mercury.topaz.cmdb.server.tql.result.utils.impl.TqlResultServerUtils;
import com.mercury.topaz.cmdb.shared.fcmdb.base.FCmdbException;
import com.mercury.topaz.cmdb.shared.fcmdb.ftql.exception.FCmdbExternalQuotaException;
import com.mercury.topaz.cmdb.shared.fcmdb.ftql.exception.FCmdbInternalQuotaException;
import com.mercury.topaz.cmdb.shared.fcmdb.ftql.util.ValidLinkIdentifier;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.ModelLinksFactory;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternElement;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.DefaultLinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.result.TqlModifiableResult;
import com.mercury.topaz.cmdb.shared.tql.result.TqlModifiableResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResult;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.impl.TqlResultFactory;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.CmdbResultEntryCreator;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.ModelLinkResultEntry;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.ModelObjectResultEntry;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.impl.CmdbResultEntryCreatorFactory;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultUtilsDbFacade;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class FederatedPatternCalculatorImpl
  implements FederatedPatternCalculator
{
  private ClassModelDestinationsConfig _classModelDestinationsConfig;
  private FTqlConditionStatisticsManager statistics;
  private CmdbLocalAdapter _cmdbLocalAdapter;
  private int _allowedNumberOfObjectsInUcmdbResult;
  private int _allowedNumberOfObjectsFromExternalSource;
  private static Log _log = LogFactory.getEasyLog(FederatedPatternCalculatorImpl.class);

  FederatedPatternCalculatorImpl(FTqlConditionStatisticsManager statistics)
  {
    setClassesDestinationsConfig(FtqlUtils.getClassesDestinationsConfig());
    SettingsReader settingsReader = ServerApiFacade.getSettingsReader();
    this.statistics = statistics;
    this._allowedNumberOfObjectsInUcmdbResult = settingsReader.getInt("quota.ftql.max.number.of.objects.in.internal.result", 1000000);
    this._allowedNumberOfObjectsFromExternalSource = settingsReader.getInt("quota.ftql.max.number.of.objects.in.external.result", 1000000);
    this._cmdbLocalAdapter = new CmdbLocalAdapter();
  }

  private void setClassesDestinationsConfig(ClassModelDestinationsConfig classModelDestinationsConfig)
  {
    this._classModelDestinationsConfig = classModelDestinationsConfig;
  }

  public TqlResult calculate(PatternGraph patternGraphToCalculate, ValidLinkIdentifier linkIdentifier, ModelObjects previousResultObjects, PatternLink virtualLink, String srcDataStore, String trgDataStore, boolean forward)
  {
    if (linkIdentifier == null)
      return calculate(patternGraphToCalculate, trgDataStore);
    try
    {
      ReconciliationData srcReconciliationData;
      ExternalTopologyResult srcMappingResult;
      ExternalTopologyResult trgComponentExternalResult;
      TqlModifiableResult result = null;
      PatternElementNumber trgElementNumber = (forward) ? virtualLink.getEnd2Number() : virtualLink.getEnd1Number();
      PatternElementNumber srcElementNumber = (forward) ? virtualLink.getEnd1Number() : virtualLink.getEnd2Number();
      MappingEngine mappingEngine = getMappingEngine(linkIdentifier, srcDataStore, trgDataStore);
      VirtualLinkInfo virtualLinkInfo = VirtualLinkInfoFactory.createVirtualLinkInfo(linkIdentifier.getLinkType(), linkIdentifier.getEnd1Type(), linkIdentifier.getEnd2Type());
      try
      {
        srcReconciliationData = mappingEngine.getReconciliationData(new ArrayList(), virtualLinkInfo);
      } catch (Exception e) {
        srcReconciliationData = null;
        if (_log.isInfoEnabled())
          _log.info("the mapping engine " + mappingEngine.getClass().getName() + " has no reconciliation rule for virtual link  " + virtualLinkInfo);
      }

      if (srcReconciliationData == null)
        return EmptyTqlServerResult.getInstance();

      String srcClassName = (forward) ? linkIdentifier.getEnd1Type() : linkIdentifier.getEnd2Type();

      if ((srcReconciliationData == null) || ((srcReconciliationData.getReconciliationClassName().equals(srcClassName)) && (srcReconciliationData instanceof IdReconciliationData) && (((IdReconciliationData)srcReconciliationData).getIdsCondition() == null)))
      {
        srcMappingResult = createExternalTopologyResultFromPreviousResult(previousResultObjects);
      } else {
        PatternGraph oneNodePattern = createOneNodePatternWithIdCondition(srcClassName, previousResultObjects, srcElementNumber);
        if (virtualLinkInfo.getLinkType().equals("extended_property_link")) {
          srcMappingResult = getExternalAttributeData(srcReconciliationData, srcElementNumber, oneNodePattern, srcDataStore);
        }
        else
          srcMappingResult = invokePatternCalculation(oneNodePattern, srcReconciliationData, virtualLinkInfo, srcElementNumber, srcDataStore);

      }

      fuse(srcDataStore, srcMappingResult, srcElementNumber);

      ReconciliationData targetReconciliationData = mappingEngine.getReconciliationData(srcMappingResult.getAllReconciliationObjects(), virtualLinkInfo);
      if (_log.isInfoEnabled()) {
        StringBuilder logMessage = new StringBuilder();
        logMessage.append("Retrieve trg mapping TQL\n");
        if (_log.isDebugEnabled()) {
          if (targetReconciliationData == null)
            logMessage.append("Trg Reconciliation Data [null]\n");
          else
            logMessage.append("Trg Reconciliation Data>\n").append(targetReconciliationData).append("\n");

        }

        logMessage.append("Invoke target unified pattern calculation\n");
        _log.info(logMessage);
      }

      if (virtualLinkInfo.getLinkType().equals("extended_property_link")) {
        trgComponentExternalResult = getExternalAttributeData(targetReconciliationData, trgElementNumber, patternGraphToCalculate, trgDataStore);
      }
      else {
        trgComponentExternalResult = invokePatternCalculation(patternGraphToCalculate, targetReconciliationData, virtualLinkInfo, trgElementNumber, trgDataStore);
      }

      fuse(trgDataStore, trgComponentExternalResult, trgElementNumber);

      if (!(trgComponentExternalResult.isEmpty()))
      {
        Map mappingExternalID = mappingEngine.connect(srcMappingResult, trgComponentExternalResult, virtualLinkInfo);
        TqlResult trgTqlResult = AdapterFPIConverter.convertExternalResultToTqlResut(trgComponentExternalResult, patternGraphToCalculate);
        Map mapping = AdapterFPIConverter.convertExternalToCmdbIdMap(mappingExternalID);

        ModelLinks connectingLinks = (forward) ? createVirtualLinks(mapping, linkIdentifier, previousResultObjects, trgTqlResult.getObjects(trgElementNumber)) : createReverseVirtualLinks(mapping, linkIdentifier, trgTqlResult.getObjects(trgElementNumber), previousResultObjects);

        if (_log.isInfoEnabled()) {
          _log.info("Creates [" + connectingLinks.size() + "] links");
          if (_log.isDebugEnabled()) {
            _log.debug("Links created >>>\n" + connectingLinks.toString() + "\n");
          }

        }

        this.statistics.reportVirtualLinksConnected(map(patternGraphToCalculate), connectingLinks.size());

        if (connectingLinks.size() > 0) {
          if (_log.isInfoEnabled())
            _log.info("Unify component result\n");

          result = TqlResultServerFactory.createModifiableResult(DefaultLinksDictionary.getInstance());
          TqlResultServerUtils.addToResult(result, trgTqlResult);
          result.addObjects(srcElementNumber, previousResultObjects);

          result.addLinks(virtualLink.getElementNumber(), connectingLinks);
        }
      }
      return ((result == null) ? TqlResultServerFactory.createModifiableResult(DefaultLinksDictionary.getInstance()) : result);
    }
    catch (RuntimeException e)
    {
      _log.error("failed to calculate pattern graph [" + patternGraphToCalculate + "] for srcDataStore[" + srcDataStore + "] for trgDataStore[" + trgDataStore + "]", e);
      throw e;
    }
  }

  private ExternalTopologyResult getExternalAttributeData(ReconciliationData targetReconciliationData, PatternElementNumber trgElementNumber, PatternGraph patternGraphToCalculate, String trgDataStore)
  {
    TopologyReconciliationData topologyReconciliationData = CalculationUtils.getTopologyReconciliationData(targetReconciliationData);
    DataForCalculation dataForCalculation = new DataForCalculation(topologyReconciliationData, trgElementNumber, patternGraphToCalculate);
    Pattern pattern = FederatedPatternCalculatorUtils.integrateUserTqlIntoReconciliationData(topologyReconciliationData, dataForCalculation);
    TqlResult tqlResult = calculate(pattern.getPatternGraph(), trgDataStore);
    TqlResultMap tqlResultMap = getLayoutForResult(tqlResult, pattern.getLayout(), pattern);
    ExternalTopologyResult trgComponentExternalResult = FederatedPatternCalculatorUtils.createExternalResult(patternGraphToCalculate, targetReconciliationData, tqlResultMap, dataForCalculation);
    return trgComponentExternalResult;
  }

  private TqlResultMap getLayoutForResult(TqlResult tqlResult, PatternLayout layout, Pattern pattern) {
    PatternElementNumber elementNumber;
    ElementLayout elementLayout;
    CmdbResultEntryCreator entryCreator = CmdbResultEntryCreatorFactory.createHashMapCreator();

    TqlModifiableResultMap modifiableResultMap = TqlResultFactory.createModifiableResultMap(entryCreator, PatternGraphFactory.createGraphDictionary(pattern.getPatternGraph()));

    for (ReadOnlyIterator iter = tqlResult.getObjectResultEntryIterator(); iter.hasNext(); ) {
      ModelObjectResultEntry resultEntry = (ModelObjectResultEntry)iter.next();

      elementNumber = resultEntry.getElementNumber();

      ModelObjects modelObjects = (ModelObjects)resultEntry.getObjects();

      elementLayout = layout.getElementLayout(resultEntry.getElementNumber());

      CmdbObjects objectsWithProperties = getObjectsLayout(pattern, elementNumber, modelObjects, tqlResult, elementLayout);

      if ((objectsWithProperties != null) && (objectsWithProperties.size() > 0)) {
        modifiableResultMap.addObjects(resultEntry.getElementNumber(), objectsWithProperties);
      }

    }

    for (iter = tqlResult.getLinkResultEntryIterator(); iter.hasNext(); ) {
      ModelLinkResultEntry resultEntry = (ModelLinkResultEntry)iter.next();

      elementNumber = resultEntry.getElementNumber();

      ModelLinks modelLinks = resultEntry.getLinks();

      elementLayout = layout.getElementLayout(resultEntry.getElementNumber());

      CmdbLinks linksWithProperties = getLinksLayout(pattern, elementNumber, modelLinks, tqlResult, elementLayout);

      if ((linksWithProperties != null) && (linksWithProperties.size() > 0)) {
        modifiableResultMap.addLinks(resultEntry.getElementNumber(), linksWithProperties);
      }

    }

    modifiableResultMap.setVersion(tqlResult.getCmdbVersion());

    return modifiableResultMap;
  }

  public CmdbObjects getObjectsLayout(Pattern pattern, PatternElementNumber elementNumber, ModelObjects modelObjects, TqlResult tqlResult, ElementLayout elementLayout)
  {
    if ((elementLayout == null) || (elementLayout.isEmpty())) {
      if (_log.isInfoEnabled())
        _log.info("elementLayout was null.");

      return convertModel2CmdbObjects(modelObjects);
    }
    return TqlResultUtilsDbFacade.getObjectsLayout(modelObjects, (ElementSimpleLayout)elementLayout);
  }

  private CmdbObjects convertModel2CmdbObjects(ModelObjects modelObjects)
  {
    CmdbObjects resultObjects = CmdbObjectFactory.createObjects();

    for (ReadOnlyIterator iter = modelObjects.getObjectsIterator(); iter.hasNext(); ) {
      ModelObject modelObject = (ModelObject)iter.next();
      CmdbObject cmdbObject = modelObject.toCmdbObject();
      resultObjects.add(cmdbObject);
    }

    return resultObjects;
  }

  private CmdbLinks convertModel2CmdbLinks(ModelLinks modelLinks)
  {
    CmdbLinks resultLinks = CmdbLinkFactory.createLinks();

    for (ReadOnlyIterator iter = modelLinks.getLinksIterator(); iter.hasNext(); ) {
      ModelLink modelLink = (ModelLink)iter.next();
      CmdbLink cmdbLink = modelLink.toCmdbLink();
      resultLinks.add(cmdbLink);
    }
    return resultLinks;
  }

  public CmdbLinks getLinksLayout(Pattern pattern, PatternElementNumber elementNumber, ModelLinks modelLinks, TqlResult tqlResult, ElementLayout elementLayout)
  {
    if ((elementLayout == null) || (elementLayout.isEmpty())) {
      if (_log.isInfoEnabled())
        _log.info("elementLayout was null.");

      return convertModel2CmdbLinks(modelLinks);
    }
    return TqlResultUtilsDbFacade.getLinksLayout(modelLinks, (ElementSimpleLayout)elementLayout);
  }

  private ElementCondition map(PatternGraph patternGraphToCalculate) {
    return ObjectToConditionMapperFactory.createGraphToConditionMapper().map(patternGraphToCalculate);
  }

  private ExternalTopologyResult invokePatternCalculation(PatternGraph patternGraphToCalculate, ReconciliationData reconciliationData, VirtualLinkInfo virtualLinkInfo, PatternElementNumber srcElementNumber, String dataStore) {
    if (!(FtqlUtils.isExternalDataStore(dataStore)))
      return this._cmdbLocalAdapter.invokeLocalAdHocExternalCalc(patternGraphToCalculate, srcElementNumber, reconciliationData);

    return invokeExtendedAdHocCalc(dataStore, patternGraphToCalculate, srcElementNumber, reconciliationData, virtualLinkInfo);
  }

  private PatternGraph createOneNodePatternWithIdCondition(String elementClass, ModelObjects objects, PatternElementNumber mapSrcElementNumber)
  {
    ModifiablePatternGraph oneNodePatternGraph = PatternGraphFactory.createModifiableGraph();
    Pattern oneNodePattern = PatternDefinitionFactory.createPattern("", "One Node src FTQL", PatternGroupId.PATTERN_GROUP_ALL, oneNodePatternGraph);
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClass, true);
    oneNodePatternGraph.addNode(PatternGraphFactory.createPatternNode(mapSrcElementNumber, elementCondition, true, null));
    if (objects == null)
      return oneNodePatternGraph;

    CmdbObjectIds conditionObjectIds = TqlResultServerUtils.extractObjectIds(objects);

    Pattern resultPattern = FtqlUtils.integrateObjectIdsConditionInPattern(oneNodePattern, mapSrcElementNumber, conditionObjectIds);
    return resultPattern.getPatternGraph();
  }

  private ExternalTopologyResult createExternalTopologyResultFromPreviousResult(ModelObjects previousResultObjects)
  {
    ExternalTopologyOneNodeResult externalTopologyResult = ExternalResultFactory.createOneNodeExternalTopologyResult();
    for (Iterator i$ = previousResultObjects.iterator(); i$.hasNext(); ) { ModelObject curObject = (ModelObject)i$.next();
      ExternalCiId curObjectExternalId = AdapterFPIConverter.convertModelObjectToExternalId(curObject);
      externalTopologyResult.addObject(curObjectExternalId, new ReconciliationObject[] { ReconciliationObjectFactory.createIdReconciliationObject(ReconciliationIdFactory.createReconciliationCmdbId(ExternalIdFactory.restoreCmdbCiIDString(curObjectExternalId))) });
    }
    return externalTopologyResult;
  }

  private MappingEngine getMappingEngine(ValidLinkIdentifier linkIdentifier, String srcDataStore, String trgDataStore)
  {
    String mappingEngineClassName = linkIdentifier.getMappingEngineClassName();
    if (mappingEngineClassName == null)
      throw new IllegalArgumentException("Unknown mapping engine for link " + linkIdentifier.toString());

    return FtqlUtils.getMappingEngine(mappingEngineClassName, srcDataStore, trgDataStore);
  }

  public TqlResult calculate(PatternGraph patternGraphToCalculate, String dataSource)
  {
    try {
      TqlResult result;
      if (!(FtqlUtils.isExternalDataStore(dataSource))) {
        result = this._cmdbLocalAdapter.invokeLocalCalculationWithoutReconciliation(patternGraphToCalculate);
      } else {
        ExternalTopologyResult externalTopologyResult = invokeExtendedAdHocCalc(dataSource, patternGraphToCalculate, null, null, null);
        result = AdapterFPIConverter.convertExternalResultToTqlResut(externalTopologyResult, patternGraphToCalculate);
      }
      return result;
    } catch (Throwable e) {
      _log.error("failed to calculate pattern graph [" + patternGraphToCalculate + "] for data store[" + dataSource + "]", e);
      throw new FCmdbException("failed to calculate pattern graph [" + patternGraphToCalculate + "] for data store[" + dataSource + "]", e);
    }
  }

  private ExternalTopologyResult invokeExtendedAdHocCalc(String destination, PatternGraph patternGraph, PatternElementNumber virtualLinkEndNodeNumber, ReconciliationData reconciliationData, VirtualLinkInfo virtualLinkInfo)
  {
    DataAccessAdapterQueryGetTopologyByPattern calculateByPattern;
    TopologyQueryDefinition topologyQueryDefinition = AdapterFPIConverter.convertPatternGraphToTopologyQueryDefinition(patternGraph, "quwry for " + destination);

    if (virtualLinkEndNodeNumber != null) {
      calculateByPattern = new DataAccessAdapterQueryGetTopologyByPattern(destination, topologyQueryDefinition, String.valueOf(virtualLinkEndNodeNumber.getNumber()), reconciliationData, virtualLinkInfo);
    }
    else
      calculateByPattern = new DataAccessAdapterQueryGetTopologyByPattern(destination, topologyQueryDefinition);

    ServerApiFacade.executeOperation(calculateByPattern);
    ExternalTopologyResult externalTopologyResult = calculateByPattern.getTopologyResult();
    filterIdsCondition(patternGraph, externalTopologyResult);
    return externalTopologyResult;
  }

  private void filterIdsCondition(PatternGraph patternGraph, ExternalTopologyResult externalTopologyResult) {
    ReadOnlyIterator elementNumbers = patternGraph.getElementNumbersIterator();
    while (elementNumbers.hasNext()) {
      PatternElementNumber elementNumber = (PatternElementNumber)elementNumbers.next();
      PatternElement patternElement = patternGraph.getDefinitionElement(elementNumber);
      ElementCondition elementCondition = patternElement.getCondition();
      ElementIdsCondition elementIdsCondition = elementCondition.getIdsCondition();
      if ((elementIdsCondition != null) && (elementIdsCondition.isNegate()))
        if (elementIdsCondition.isIdsOfCmdbObjects()) {
          CmdbObjectIds ids = elementIdsCondition.getIds();
          removeObjectsByIds(externalTopologyResult, ids, elementNumber, patternElement.getCondition().getClassCondition().getClassName());
        }
        else {
          CmdbLinkIds ids = elementIdsCondition.getLinkIds();
          removeLinksByIds(externalTopologyResult, ids, elementNumber);
        }
    }
  }

  private void removeLinksByIds(ExternalTopologyResult externalTopologyResult, CmdbLinkIds ids, PatternElementNumber elementNumber)
  {
    if (externalTopologyResult instanceof ExternalTopologyPatternResult) {
      String elementName = AdapterFPIConverter.convertElementNumberToElementName(elementNumber);
      ExternalTopologyPatternResultImpl externalTopologyPatternResult = (ExternalTopologyPatternResultImpl)externalTopologyResult;
      ReadOnlyIterator idsIterator = ids.getIdsIterator();
      Collection relations = externalTopologyPatternResult.getRelationByName(elementName);
      Set idsSet = new HashSet(ids.size());
      while (idsIterator.hasNext())
        idsSet.add(idsIterator.next());

      for (Iterator i$ = relations.iterator(); i$.hasNext(); ) { TopologyRelation relation = (TopologyRelation)i$.next();
        CmdbLinkID linkID = (CmdbLinkID)AdapterFPIConverter.convertRelationToCmdbLink(relation).getID();
        if (idsSet.contains(linkID))
          externalTopologyPatternResult.removeRelation(elementName, (ExternalRelationId)relation.getId());
      }
    }
  }

  private void removeObjectsByIds(ExternalTopologyResult externalTopologyResult, CmdbObjectIds ids, PatternElementNumber elementNumber, String type)
  {
    if (externalTopologyResult instanceof ExternalTopologyOneNodeResult) {
      ExternalTopologyOneNodeResultImpl oneNodeResult = (ExternalTopologyOneNodeResultImpl)externalTopologyResult;
      ReadOnlyIterator idsIterator = ids.getIdsIterator();
      while (idsIterator.hasNext())
        oneNodeResult.removeCI(AdapterFPIConverter.convertCmdbObjectIdAndTypeToExternalObjectId((CmdbObjectID)idsIterator.next(), type));
    }
    else
    {
      String elementName = AdapterFPIConverter.convertElementNumberToElementName(elementNumber);
      ExternalTopologyPatternResultImpl externalTopologyPatternResult = (ExternalTopologyPatternResultImpl)externalTopologyResult;
      ReadOnlyIterator idsIterator = ids.getIdsIterator();
      while (idsIterator.hasNext()) {
        CmdbObjectID id = (CmdbObjectID)idsIterator.next();
        externalTopologyPatternResult.removeCI(elementName, AdapterFPIConverter.convertCmdbObjectIdAndTypeToExternalObjectId(id, type));
      }
    }
  }

  public ClassModelDestinationsConfig getClassesDestinationsConfig()
  {
    return this._classModelDestinationsConfig;
  }

  private void fuse(String dataSource, ExternalTopologyResult result, PatternElementNumber elementNumber)
  {
    if (!(FtqlUtils.isExternalDataStore(dataSource))) {
      Collection objects = AdapterFPIConverter.extractCIsFromExternalTopologyResult(result, String.valueOf(elementNumber));
      int actualNumberOfObjects = objects.size();
      String type = null;
      if (!(objects.isEmpty())) {
        type = ((TopologyCI)objects.iterator().next()).getType();
      }

      if (actualNumberOfObjects > this._allowedNumberOfObjectsInUcmdbResult)
        throw new FCmdbInternalQuotaException(this._allowedNumberOfObjectsInUcmdbResult, actualNumberOfObjects, type);
    }
    else
    {
      int actualNumberOfObjects = AdapterFPIConverter.extractCIsFromExternalTopologyResult(result, String.valueOf(elementNumber)).size();
      if (actualNumberOfObjects > this._allowedNumberOfObjectsFromExternalSource) {
        StringBuilder ciTypes = new StringBuilder();
        if (result instanceof ExternalTopologyOneNodeResult) {
          Collection objects = ((ExternalTopologyOneNodeResultImpl)result).getCIs();
          if ((objects != null) && (objects.size() > 1))
            ciTypes.append(((TopologyCI)objects.iterator().next()).getType()).append("(").append(objects.size()).append(") ");
        }
        else
        {
          Topology topology = ((ExternalTopologyPatternResultImpl)result).getTopology();
          Collection cisElementNames = topology.getCisElementNames();
          for (Iterator i$ = cisElementNames.iterator(); i$.hasNext(); ) { String ciElementName = (String)i$.next();
            Collection objects = topology.getCIsByName(ciElementName);
            if ((objects != null) && (objects.size() > 1))
              ciTypes.append(((TopologyCI)objects.iterator().next()).getType()).append("(").append(objects.size()).append(") ");
          }
        }

        throw new FCmdbExternalQuotaException(this._allowedNumberOfObjectsFromExternalSource, actualNumberOfObjects, ciTypes.toString(), dataSource);
      }
    }
  }

  private ModelLinks createVirtualLinks(Map<CmdbObjectID, CmdbObjectIds> mapping, ValidLinkIdentifier linkIdentifier, ModelObjects end1Objects, ModelObjects end2Objects)
  {
    Map end1Map = createIdObjectMap(end1Objects);
    Map end2Map = createIdObjectMap(end2Objects);
    ModelLinks connectingLinks = ModelLinksFactory.createLinks();
    for (Iterator i$ = mapping.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      CmdbObjectID end1Id = (CmdbObjectID)entry.getKey();

      CmdbObjectIds end2Ids = (CmdbObjectIds)entry.getValue();
      for (ReadOnlyIterator end2IdIter = end2Ids.getIdsIterator(); end2IdIter.hasNext(); ) {
        CmdbObjectID end2Id = (CmdbObjectID)end2IdIter.next();

        connectingLinks.add(ModelLinkFactory.create(linkIdentifier.getLinkType(), (ModelObject)end1Map.get(end1Id), (ModelObject)end2Map.get(end2Id)));
      }
    }
    return connectingLinks;
  }

  private Map<CmdbObjectID, ModelObject> createIdObjectMap(ModelObjects modelObjects) {
    Map result = new HashMap(modelObjects.size());
    for (Iterator i$ = modelObjects.iterator(); i$.hasNext(); ) { ModelObject modelObject = (ModelObject)i$.next();
      result.put(modelObject.toCmdbObjectID(), modelObject);
    }
    return result;
  }

  private ModelLinks createReverseVirtualLinks(Map<CmdbObjectID, CmdbObjectIds> mapping, ValidLinkIdentifier linkIdentifier, ModelObjects end1Objects, ModelObjects end2Objects)
  {
    ModelLinks connectingLinks = ModelLinksFactory.createLinks();
    Map end1Map = createIdObjectMap(end1Objects);
    Map end2Map = createIdObjectMap(end2Objects);

    for (Iterator i$ = mapping.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      CmdbObjectID end2Id = (CmdbObjectID)entry.getKey();
      CmdbObjectIds end1Ids = (CmdbObjectIds)entry.getValue();
      for (ReadOnlyIterator end1IdIter = end1Ids.getIdsIterator(); end1IdIter.hasNext(); ) {
        CmdbObjectID end1Id = (CmdbObjectID)end1IdIter.next();

        connectingLinks.add(ModelLinkFactory.create(linkIdentifier.getLinkType(), (ModelObject)end1Map.get(end1Id), (ModelObject)end2Map.get(end2Id)));
      }
    }
    return connectingLinks;
  }
}