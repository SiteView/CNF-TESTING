package com.mercury.topaz.cmdb.server.fcmdb.ftql.manager;

import com.mercury.topaz.cmdb.server.model.datasource.TqlExtendedModelDataSourceQuery;
import com.mercury.topaz.cmdb.server.tql.manager.TqlConditionStatisticsManager;
import com.mercury.topaz.cmdb.server.tql.manager.TqlResultUtilsManager;

public abstract interface FTqlCalculationManager extends TqlResultUtilsManager
{
  public abstract TqlExtendedModelDataSourceQuery getDataSourceQuery();

  public abstract TqlConditionStatisticsManager getConditionStatisticsManager();
}