package com.mercury.topaz.cmdb.server.fcmdb.ftql.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.ElementDataStoresInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.LinkDataStorePermutationsInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.PatternDataStoresInfo;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

class PatternDataStoresInfoImpl
  implements PatternDataStoresInfo
{
  private Map<PatternElementNumber, ElementDataStoresInfo> _elementDataStoresInfoMap;
  private Map<PatternElementNumber, LinkDataStorePermutationsInfo> _linkDataStorePermutationsInfoMap;
  private boolean _isFederated;

  private PatternDataStoresInfoImpl(Map<PatternElementNumber, ElementDataStoresInfo> elementDataStoresInfoMap, Map<PatternElementNumber, LinkDataStorePermutationsInfo> linkDataStorePermutationsInfoMap, boolean federated)
  {
    this._elementDataStoresInfoMap = elementDataStoresInfoMap;
    this._linkDataStorePermutationsInfoMap = linkDataStorePermutationsInfoMap;
    this._isFederated = federated;
  }

  PatternDataStoresInfoImpl() {
    this._elementDataStoresInfoMap = new HashMap();
    this._linkDataStorePermutationsInfoMap = new HashMap();
    this._isFederated = false;
  }

  public int getNumberOfElementDataStoresInfo() {
    return this._elementDataStoresInfoMap.size();
  }

  public ElementDataStoresInfo getElementDataStoreInfo(PatternElementNumber elementNumber) {
    return ((ElementDataStoresInfo)this._elementDataStoresInfoMap.get(elementNumber));
  }

  public LinkDataStorePermutationsInfo getLinkDataStorePermutationsInfo(PatternElementNumber elementNumber) {
    return ((LinkDataStorePermutationsInfo)this._linkDataStorePermutationsInfoMap.get(elementNumber));
  }

  public int getNumberOfLinkDataStorePermutationsInfo() {
    return this._linkDataStorePermutationsInfoMap.size();
  }

  public boolean isFederated() {
    return this._isFederated;
  }

  public void addElementDataStoreInfo(PatternElementNumber elementNumber, ElementDataStoresInfo elementDataStoresInfo) {
    Set allElementDataStores = elementDataStoresInfo.getAllDataStores();
    if ((allElementDataStores.size() > 1) || (!(allElementDataStores.contains("MERCURY_CMDB"))) || (elementDataStoresInfo.hasExternalAttributes()))
      setIsFederated(true);

    this._elementDataStoresInfoMap.put(elementNumber, elementDataStoresInfo);
  }

  public void setIsFederated(boolean isFederated) {
    this._isFederated = isFederated; }

  public void addLinkDataStorePermutationsInfo(PatternElementNumber elementNumber, LinkDataStorePermutationsInfo linkDataStorePermutationsInfo) {
    this._linkDataStorePermutationsInfoMap.put(elementNumber, linkDataStorePermutationsInfo);
  }

  public PatternDataStoresInfo clone() {
    return new PatternDataStoresInfoImpl(new HashMap(this._elementDataStoresInfoMap), new HashMap(this._linkDataStorePermutationsInfoMap), this._isFederated);
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    PatternDataStoresInfoImpl that = (PatternDataStoresInfoImpl)o;

    if (this._isFederated != that._isFederated)
      return false;

    if (this._elementDataStoresInfoMap != null) if (this._elementDataStoresInfoMap.equals(that._elementDataStoresInfoMap)) break label75; 
    else if (that._elementDataStoresInfoMap == null)
        break label75;
    return false;

    if (this._linkDataStorePermutationsInfoMap != null) label75: if (this._linkDataStorePermutationsInfoMap.equals(that._linkDataStorePermutationsInfoMap))
        break label108;
    label108: return (that._linkDataStorePermutationsInfoMap == null);
  }

  public int hashCode()
  {
    int result = (this._elementDataStoresInfoMap != null) ? this._elementDataStoresInfoMap.hashCode() : 0;
    result = 29 * result + ((this._linkDataStorePermutationsInfoMap != null) ? this._linkDataStorePermutationsInfoMap.hashCode() : 0);
    result = 29 * result + ((this._isFederated) ? 1 : 0);
    return result;
  }

  public String toString() {
    String description = "";
    for (Iterator i$ = this._elementDataStoresInfoMap.keySet().iterator(); i$.hasNext(); ) { PatternElementNumber elementNumber = (PatternElementNumber)i$.next();
      description = description + "data stores for element " + elementNumber + ": " + ((ElementDataStoresInfo)this._elementDataStoresInfoMap.get(elementNumber)).getAllCoreDataStores() + ", ";
    }
    return description;
  }
}