package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.AdapterConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.ModifiableFederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateFederationConfgOperation;

public class ConfigUpdateAdapterConfigUpdate extends AbstractConfigUpdateFederationConfgOperation
{
  private AdapterConfigDef _adapterConfigDef;

  public ConfigUpdateAdapterConfigUpdate(AdapterConfigDef adapterConfigDef)
  {
    setAdapterConfigDef(adapterConfigDef);
  }

  public String getOperationName() {
    return "Config Update: Adapter Config Update";
  }

  private AdapterConfigDef getAdapterConfigDef()
  {
    return this._adapterConfigDef;
  }

  private void setAdapterConfigDef(AdapterConfigDef adapterConfigDef) {
    this._adapterConfigDef = adapterConfigDef;
  }

  protected void updateConfig(ModifiableFederationConfigDef federationConfigDef, ConfigUpdateManager configUpdateManager)
  {
    federationConfigDef.updateAdapterConfigDef(getAdapterConfigDef());
  }
}