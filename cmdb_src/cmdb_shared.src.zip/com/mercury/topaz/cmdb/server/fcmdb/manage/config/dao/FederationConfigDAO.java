package com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao;

import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;

public abstract interface FederationConfigDAO extends FederationConfigReadOnlyDAO
{
  public abstract void saveFederationConfig(FederationConfig paramFederationConfig);

  public abstract void removeFederationConfig();
}