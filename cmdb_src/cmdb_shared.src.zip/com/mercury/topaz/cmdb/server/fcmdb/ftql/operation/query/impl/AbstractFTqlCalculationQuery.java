package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.impl.AbstractFTqlCalculationOperation;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query.FTqlCalculationQuery;
import com.mercury.topaz.cmdb.shared.fcmdb.base.FCmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractFTqlCalculationQuery extends AbstractFTqlCalculationOperation
  implements FTqlCalculationQuery
{
  public void ftqlCalculationExecute(FTqlCalculationManager fTqlCalculationManager, CmdbResponse response)
    throws FCmdbException
  {
    ftqlCalculationgExecuteQuery(fTqlCalculationManager, response);
  }
}