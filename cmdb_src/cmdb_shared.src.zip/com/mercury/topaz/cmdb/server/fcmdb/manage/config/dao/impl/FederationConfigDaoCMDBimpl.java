package com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao.impl;

import com.mercury.topaz.cmdb.server.fcmdb.util.FClassModelUtil;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.classmodel.util.xml.XmlParser;
import com.mercury.topaz.cmdb.shared.fcmdb.base.FcmdbConstants.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.exception.FConfigException;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraph;
import com.mercury.topaz.cmdb.shared.model.graph.CmdbGraphTopologyDiff;
import com.mercury.topaz.cmdb.shared.model.graph.util.CmdbGraphUtil;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.graph.update.ModelUpdateAddOrUpdateGraph;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsIfExist;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.PatternXmlBuilder;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.CmdbPatternIDFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.Layout;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocGraph;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetPattern;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdatePatternCreate;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.IOException;
import java.io.InputStream;

class FederationConfigDaoCMDBimpl extends AbstractFederationConfigDAO
{
  private static final String FEDERATION_CONFIG_TQL_NAME = "federation_config";
  private static final String FEDERATION_CONFIG_PATH = "/federation/federation_config.xml";
  private DataFactory _dataFactory;
  private OperationExecutor _operationExecutor;

  public FederationConfigDaoCMDBimpl(OperationExecutor operationExecutor)
  {
    setOperationExecutor(operationExecutor);
  }

  public void startUp() {
    CmdbClassModel classModel = FClassModelUtil.getClassModel(getOperationExecutor());
    setDataFactory(DataFactoryCreator.create(classModel));
    CmdbPatternID configPatternID = getPatternIdOfConfigurationConfig();
    addPatternIfNotExist(configPatternID);
  }

  public void shutdown()
  {
  }

  public void saveFederationConfig(FederationConfig federationConfig) {
    CmdbGraph configGraph = getFederationConfigAsGraph();
    CmdbGraph federationAsCmdbGraph = FederatedConfigCmdbGraphConverter.convertFederatedConfigToCmdbGraph(federationConfig, getDataFactory());
    CmdbGraphTopologyDiff diff = CmdbGraphUtil.getGraphTopologyDiff(configGraph, federationAsCmdbGraph);
    ModelUpdateBulksOptimistic updateBulkOperation = createUpdateBulkOperation(diff, federationAsCmdbGraph);
    getOperationExecutor().executeOperation(updateBulkOperation);
  }

  private ModelUpdateBulksOptimistic createUpdateBulkOperation(CmdbGraphTopologyDiff diff, CmdbGraph addUpdateGraph)
  {
    ModelUpdateBulksOptimistic bulkOperation = new ModelUpdateBulksOptimistic(FcmdbConstants.FederationConfig.CHANGER);
    if ((diff != null) && (!(diff.isEmpty()))) {
      if (diff.getObjectsToRemoveSize() != 0) {
        CmdbObjectIds objectIdsToRemove = createCmdbObjectIdsFromIterator(diff.getObjectsToRemove());
        bulkOperation.addOptimisticModelUpdateOperation(new ModelUpdateRemoveObjectsIfExist(objectIdsToRemove, FcmdbConstants.FederationConfig.CHANGER));
      }
      if (diff.getLinksToRemoveSize() != 0) {
        CmdbLinks linksToRemove = createCmdbLinksFromIterator(diff.getLinksToRemove());
        bulkOperation.addOptimisticModelUpdateOperation(new ModelUpdateRemoveLinksIfExist(linksToRemove, FcmdbConstants.FederationConfig.CHANGER));
      }
    }
    ModelUpdateAddOrUpdateGraph modelUpdateAddOrUpdateGraph = new ModelUpdateAddOrUpdateGraph(addUpdateGraph, FcmdbConstants.FederationConfig.CHANGER);
    getOperationExecutor().executeOperation(modelUpdateAddOrUpdateGraph);
    return bulkOperation;
  }

  private CmdbLinks createCmdbLinksFromIterator(ReadOnlyIterator cmdbLinksIterator) {
    CmdbLinks links = CmdbLinkFactory.createLinks();
    while (cmdbLinksIterator.hasNext())
      links.add((CmdbLink)cmdbLinksIterator.next());

    return links;
  }

  private CmdbObjectIds createCmdbObjectIdsFromIterator(ReadOnlyIterator cmdbObjectsIterator)
  {
    CmdbObjectIds objectIds = CmdbObjectIdsFactory.create();
    while (cmdbObjectsIterator.hasNext())
      objectIds.add((CmdbObjectID)((CmdbObject)cmdbObjectsIterator.next()).getID());

    return objectIds;
  }

  private OperationExecutor getOperationExecutor() {
    return this._operationExecutor;
  }

  private void setOperationExecutor(OperationExecutor operationExecutor) {
    if (operationExecutor == null)
      throw new IllegalArgumentException("operation executor is null !!!");

    this._operationExecutor = operationExecutor;
  }

  public FederationConfig getFederationConfig() {
    CmdbGraph configGraph = getFederationConfigAsGraph();
    return FederatedConfigCmdbGraphConverter.convertCmdbGraphToFederationConfig(configGraph);
  }

  public void removeFederationConfig() {
    CmdbGraph fconfig = getFederationConfigAsGraph();
    CmdbObjectIds objectsIds = CmdbObjectIdsFactory.create();
    ReadOnlyIterator itr = fconfig.getObjectsIterator();
    while (itr.hasNext())
      objectsIds.add((CmdbObjectID)((CmdbObject)itr.next()).getID());

    if (!(objectsIds.isEmpty())) {
      ModelUpdateRemoveObjectsIfExist removeObjects = new ModelUpdateRemoveObjectsIfExist(objectsIds, FcmdbConstants.FederationConfig.CHANGER);
      getOperationExecutor().executeOperation(removeObjects);
    }
  }

  private CmdbGraph getFederationConfigAsGraph() {
    CmdbPatternID patternID = getPatternIdOfConfigurationConfig();
    return runTqlAdHocGraph(patternID, null);
  }

  private CmdbGraph runTqlAdHocGraph(CmdbPatternID patternID, Layout layout) {
    TqlQueryGetAdHocGraph tqlQueryGetAdHocGraph = new TqlQueryGetAdHocGraph(patternID, layout);
    getOperationExecutor().executeOperation(tqlQueryGetAdHocGraph);
    return tqlQueryGetAdHocGraph.getResultGraph();
  }

  private void addPatternIfNotExist(CmdbPatternID patternID) {
    if (!(isPatternExistsInCMDB(patternID)))
      try {
        InputStream federationConfigResource = getClass().getResourceAsStream("/federation/federation_config.xml");
        String tqlDefintionString = XmlParser.getStreamContent(federationConfigResource);
        Pattern tqlDefintion = PatternXmlBuilder.fromXml(tqlDefintionString);
        TqlUpdatePatternCreate createPattern = new TqlUpdatePatternCreate(tqlDefintion);
        getOperationExecutor().executeOperation(createPattern);
      } catch (IOException e) {
        throw new FConfigException("Failed to read tql definition from /federation/federation_config.xml", e);
      }
  }

  protected boolean isPatternExistsInCMDB(CmdbPatternID patternID)
  {
    TqlQueryGetPattern getPattern = new TqlQueryGetPattern(patternID, true);
    getOperationExecutor().executeOperation(getPattern);
    return (getPattern.getPattern() != null);
  }

  private CmdbPatternID getPatternIdOfConfigurationConfig() {
    return CmdbPatternIDFactory.createObjectID("federation_config");
  }

  private DataFactory getDataFactory() {
    return this._dataFactory;
  }

  void setDataFactory(DataFactory dataFactory) {
    if (dataFactory == null)
      throw new IllegalArgumentException("data factory is null !!!");

    this._dataFactory = dataFactory;
  }
}