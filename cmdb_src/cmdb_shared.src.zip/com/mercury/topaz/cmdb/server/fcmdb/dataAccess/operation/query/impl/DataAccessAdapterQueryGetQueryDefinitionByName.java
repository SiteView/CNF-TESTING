package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.replication.BasicSourceDataAdapter;
import com.hp.ucmdb.federationspi.data.query.topology.QueryDefinition;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessAdapterQueryGetQueryDefinitionByName extends AbstractDataAccessLifeCycleAdapterQuery
{
  private static final String RETRIEVE_RESULT = "Retrieve Result";
  private String _queryName;
  private QueryDefinition _queryDefinition;

  public DataAccessAdapterQueryGetQueryDefinitionByName(String destinationId, String queryName)
  {
    super(destinationId);
    setQueryName(queryName);
  }

  public String getQueryName() {
    return this._queryName;
  }

  public void setQueryName(String queryName) {
    this._queryName = queryName;
  }

  public String getOperationName() {
    return "Data Access Query: get query by name.";
  }

  public void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws AdapterAccessException, DataAccessException {
    QueryDefinition queryDefinition = getTopology(dataAccessManager);
    response.addResult("Retrieve Result", queryDefinition);
  }

  private QueryDefinition getTopology(DataAccessAdapterManager dataAccessManager) throws AdapterAccessException, DataAccessException {
    BasicDataAdapterWrapper adapterWrapper = getAdapter(dataAccessManager);
    BasicSourceDataAdapter adapter = (BasicSourceDataAdapter)adapterWrapper.getBasicDataAdapter();
    return adapter.getQueryByName(getQueryName());
  }

  private void setQueryDefinition(QueryDefinition queryDefinition)
  {
    this._queryDefinition = queryDefinition;
  }

  public QueryDefinition getQueryDefinition() {
    return this._queryDefinition;
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setQueryDefinition((QueryDefinition)response.getResult("Retrieve Result"));
  }

  protected StringBuilder getOutputInfo()
  {
    return new StringBuilder("Topology Result: ").append(getQueryDefinition());
  }

  protected StringBuilder getInputInfo() {
    return new StringBuilder("Target ID: ").append(getDestinationId()).append(",Query Name: ").append(getQueryName());
  }
}