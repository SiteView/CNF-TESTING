package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.impl;

import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.VirtualLinkInfo;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyResult;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyQueryDefinition;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.util.CalculationUtils;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrappers;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;

public class OneNodeSupportCalculationStrategy
  implements CalculationStrategy
{
  public ExternalTopologyResult calculateTopology(FTqlDataAdapter adapter, TopologyQueryDefinition topologyQueryDefinition, ReconciliationData reconciliationData, String virtualLinkEndNodeName, VirtualLinkInfo virtualLinkInfo)
    throws DataAccessException
  {
    return CalculationUtils.getOneNodeTopology(adapter, topologyQueryDefinition, reconciliationData, virtualLinkInfo);
  }

  public CmdbObjects getObjectsLayout(FTqlDataAdapter adapter, ModelObjects objects, ElementSimpleLayout layout, String dataStore) {
    return CalculationUtils.getObjectsLayoutWithAddedCalculatedProperties(adapter, objects, layout, dataStore);
  }

  public CmdbLinks getLinksLayout(FTqlDataAdapter adapter, ModelLinks links, ElementSimpleLayout layout, String dataStore) {
    throw new UnsupportedOperationException("Element topology data atpter doesn't support links layout");
  }

  public CmdbObjects getFunctionsLayout(FTqlDataAdapter adapter, ModelObjects groupByObjects, ModelLinks modelLinks, ModelObjects aggregatedObjects, LayoutFunctionWrappers wrappers, String dataStore) throws AdapterAccessException {
    throw new UnsupportedOperationException("Element topology data atpter doesn't support functions layout");
  }
}