package com.mercury.topaz.cmdb.server.fcmdb.manage.config.task;

public class FederationConfigCacheTask
{
  public static final String NAME = "Federation Config Cache Task";
}