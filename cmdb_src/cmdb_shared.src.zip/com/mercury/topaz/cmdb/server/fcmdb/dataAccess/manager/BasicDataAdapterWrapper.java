package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.environment.DataAdapterEnvironment;

public abstract interface BasicDataAdapterWrapper
{
  public abstract BasicDataAdapter getBasicDataAdapter();

  public abstract ClassLoader getAdapterClassLoader();

  public abstract String getAdapterId();

  public abstract DataAdapterEnvironment getDataAdapterEnvironment();
}