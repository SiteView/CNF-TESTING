package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetLinksLayout;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.model.operation.query.ModelQueryGetLinksLayout;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryFactory;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.ModelLinksFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FTqlCalculationQueryGetLinksLayout extends AbstractFTqlCalculationQuery
  implements ModelQueryGetLinksLayout
{
  private ElementSimpleLayout _layout;
  private CmdbLinks _resultLinks;
  private ModelLinks _modelLinks;
  protected static String RESULT_KEY = "result_key";

  public FTqlCalculationQueryGetLinksLayout(ElementSimpleLayout objectLayout, ModelLinks links)
  {
    setLayout(objectLayout);
    setModelLinks(links);
  }

  public FTqlCalculationQueryGetLinksLayout(ElementSimpleLayout objectLayout, ModelLink link) {
    setLayout(objectLayout);
    ModelLinks links = ModelLinksFactory.createLinks();
    links.add(link);
    setModelLinks(links);
  }

  public CmdbLinks getResultLinks()
  {
    return this._resultLinks;
  }

  private ElementSimpleLayout getLayout()
  {
    return this._layout;
  }

  private void setLayout(ElementSimpleLayout layout) {
    this._layout = layout;
  }

  private void setResultLinks(CmdbLinks resultLinks)
  {
    this._resultLinks = resultLinks;
  }

  private ModelLinks getModelLinks() {
    return this._modelLinks;
  }

  private void setModelLinks(ModelLinks modelLinks) {
    this._modelLinks = modelLinks;
  }

  public String getOperationName()
  {
    return "FTql Calculation Query: Get Links Layout";
  }

  public void ftqlCalculationgExecuteQuery(FTqlCalculationManager fTqlCalculationManager, CmdbResponse cmdbResponse) {
    ModelLinks virtualLinks = FtqlUtils.getVirtualLinks(getModelLinks());
    CmdbLinks resultLinks = virtualLinks.toCmdbLinks();
    if (virtualLinks.size() < getModelLinks().size()) {
      ModelLinks modelLinks = ModelLinksFactory.createLinks();
      ReadOnlyIterator modelLinksIterator = getModelLinks().getLinksIterator();
      while (modelLinksIterator.hasNext())
        modelLinks.add(modelLinksIterator.next());

      ReadOnlyIterator virtualLinksIterator = virtualLinks.getLinksIterator();
      while (virtualLinksIterator.hasNext())
        modelLinks.remove((ModelLink)virtualLinksIterator.next());

      Map modelLinksByDataSourceMap = FtqlUtils.classifyByDataSource(modelLinks);
      for (Iterator i$ = modelLinksByDataSourceMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        String destinationID = (String)entry.getKey();
        if (!(FtqlUtils.isExternalDataStore(destinationID))) {
          ModelQueryGetLinksLayout modelQueryGetLinksLayout = ModelQueryFactory.getInternalModelQueryGetLinksLayoutOperation(getLayout(), (ModelLinks)entry.getValue());
          fTqlCalculationManager.executeOperation(modelQueryGetLinksLayout);
          resultLinks.add(modelQueryGetLinksLayout.getResultLinks());
        }
        else {
          DataAccessAdapterQueryGetLinksLayout getLinksLayout = new DataAccessAdapterQueryGetLinksLayout(destinationID, (ModelLinks)entry.getValue(), getLayout());
          fTqlCalculationManager.executeOperation(getLinksLayout);
          resultLinks.add(getLinksLayout.getResultLinks());
        }
      }
    }
    setResultLinks(resultLinks);
    cmdbResponse.addResult(RESULT_KEY, resultLinks); }

  public void updateQueryWithResponse(CmdbResponse response) {
    setResultLinks((CmdbLinks)response.getResult(RESULT_KEY));
  }
}