package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ModifiableClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl.ClassDestinationsConfigFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.util.ConfigUtil;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.ModifiableFederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateConfigurationOperation;

public class ConfigUpdateFederationConfigUpdate extends AbstractConfigUpdateConfigurationOperation
{
  private FederationConfig _federationConfig;

  public ConfigUpdateFederationConfigUpdate(FederationConfig federationConfig)
  {
    setFederationConfig(federationConfig);
  }

  private void setFederationConfig(FederationConfig federationConfig) {
    this._federationConfig = federationConfig; }

  protected FederationConfig getFederationConfigForUpdate(ConfigUpdateManager configUpdateManager) {
    return this._federationConfig;
  }

  protected void updateConfig(ModifiableFederationConfigDef federationConfigDef, ConfigUpdateManager configUpdateManager) {
    FederationConfig prevFederationConfig = getCashedFederationConfig(configUpdateManager);
    ClassModelDestinationsConfig classModelDestinationsConfig = getClassesDestinationsConfig();
    ModifiableClassModelDestinationsConfig modifiableClassesDestinationsConfig = ClassDestinationsConfigFactory.createModifiableClassesDestinationsConfig(classModelDestinationsConfig);
    boolean wasChanged = ConfigUtil.updateClassModelDestinationsConfig(modifiableClassesDestinationsConfig, prevFederationConfig, this._federationConfig);
    if (wasChanged) {
      ClassModelDestinationsConfig newClassModelDestinationsConfig = ClassDestinationsConfigFactory.createReadOnlyClassesDestinationsConfig(modifiableClassesDestinationsConfig);
      ConfigUtil.updateClassModelDestinationsConfigCache(newClassModelDestinationsConfig);
    }
  }

  public String getOperationName() {
    return "Config Update: Federation Config Update";
  }
}