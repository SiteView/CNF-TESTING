package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.replication.SourceChangesDataAdapter;
import com.hp.ucmdb.federationspi.data.query.topology.QueryDefinition;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyFactory;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyIds;
import com.hp.ucmdb.federationspi.data.replication.ReplicationActionDataFactory;
import com.hp.ucmdb.federationspi.data.replication.ReplicationTopologyResultActionData;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.Collection;
import java.util.Date;

public class DataAccessAdapterQueryRetrieveByPatternFromChangesSource extends AbstractDataAccessLifeCycleAdapterQuery
{
  private static final String RETRIEVE_RESULT = "Retrieve Result";
  private final QueryDefinition _query;
  private final Date _fromDate;
  private ReplicationTopologyResultActionData _result;

  public DataAccessAdapterQueryRetrieveByPatternFromChangesSource(String targetID, QueryDefinition queryDefinition, Date fromDate)
  {
    super(targetID);
    this._query = queryDefinition;
    this._fromDate = fromDate;
  }

  public DataAccessAdapterQueryRetrieveByPatternFromChangesSource(String targetID, QueryDefinition queryDefinition) {
    this(targetID, queryDefinition, null);
  }

  public String getOperationName() {
    return "DataAccess Query: Retrieve By Pattern From Changes Source Adapter operation";
  }

  public void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws AdapterAccessException, DataAccessException {
    BasicDataAdapter adapter = getAdapter(dataAccessManager).getBasicDataAdapter();
    ReplicationTopologyResultActionData result = getResult(adapter);
    replicationFuse(dataAccessManager, new Collection[] { ((TopologyIds)result.getTopologyForAdd()).getAllCIs(), ((TopologyIds)result.getTopologyForRemove()).getAllCIs(), ((TopologyIds)result.getTopologyForUpdate()).getAllCIs() });
    response.addResult("Retrieve Result", result);
  }

  private ReplicationTopologyResultActionData getResult(BasicDataAdapter adapter) throws DataAccessException
  {
    ReplicationTopologyResultActionData result;
    if (this._fromDate != null) {
      result = ((SourceChangesDataAdapter)adapter).getChangesTopology(this._query, this._fromDate);
    } else {
      TopologyIds emptyTopologyIds = TopologyFactory.createEmptyTopologyIds();
      TopologyIds topologyIdsToAdd = ((SourceChangesDataAdapter)adapter).getFullTopology(this._query);
      result = ReplicationActionDataFactory.createReplicationTopologyResultActionData(emptyTopologyIds, topologyIdsToAdd, emptyTopologyIds);
    }
    return result;
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    this._result = ((ReplicationTopologyResultActionData)response.getResult("Retrieve Result"));
  }

  public ReplicationTopologyResultActionData getResult() {
    return this._result;
  }

  protected StringBuilder getOutputInfo() {
    return new StringBuilder("Result: ").append(this._result);
  }

  protected StringBuilder getInputInfo() {
    return new StringBuilder("Target ID: ").append(getDestinationId()).append(", Pattern Name: ").append(this._query);
  }
}