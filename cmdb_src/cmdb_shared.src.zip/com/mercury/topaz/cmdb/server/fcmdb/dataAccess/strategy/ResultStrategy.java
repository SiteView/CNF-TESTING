package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy;

import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;

public abstract interface ResultStrategy
{
  public abstract CmdbObjectIds sortObjects(FTqlDataAdapter paramFTqlDataAdapter, ModelObjects paramModelObjects, CmdbSortCommand paramCmdbSortCommand, CalculationStrategy paramCalculationStrategy, String paramString)
    throws AdapterAccessException, DataAccessException;

  public abstract CmdbObjectIds sortObjects(FTqlDataAdapter paramFTqlDataAdapter, ElementCondition paramElementCondition, CmdbSortCommand paramCmdbSortCommand, CalculationStrategy paramCalculationStrategy, String paramString)
    throws AdapterAccessException, DataAccessException;

  public abstract CmdbLinks sortLinks(FTqlDataAdapter paramFTqlDataAdapter, ModelLinks paramModelLinks, CmdbSortCommand paramCmdbSortCommand, CalculationStrategy paramCalculationStrategy, String paramString)
    throws AdapterAccessException, DataAccessException;
}