package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.server.model.operation.query.ModelQueryGetFunctionsLayout;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrappers;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;

public class DataAccessAdapterQueryGetFunctionsLayout extends AbstractDataAccessLifeCycleAdapterQuery
  implements ModelQueryGetFunctionsLayout
{
  private static final String KEY_RESULT_OBJECT = "result_objects";
  private ModelObjects _groupByObjects;
  private ModelObjects _aggregatedObjects;
  private ModelLinks _modelLinks;
  private LayoutFunctionWrappers _layoutFunctionWrappers;
  private CmdbObjects _resultObjects;

  public DataAccessAdapterQueryGetFunctionsLayout(String destinationId, ModelObjects groupByObjects, ModelLinks modelLinks, ModelObjects aggregatedObjects, LayoutFunctionWrappers layoutFunctionWrappers)
  {
    super(destinationId);
    setGroupByObjects(groupByObjects);
    setAggregatedObjects(aggregatedObjects);
    setModelLinks(modelLinks);
    setLayoutFunctionHandlers(layoutFunctionWrappers);
  }

  protected StringBuilder getOutputInfo()
  {
    StringBuilder result = new StringBuilder();
    result.append("resultObjects: ").append(getResultObjects());
    return result;
  }

  protected StringBuilder getInputInfo() {
    StringBuilder result = new StringBuilder();
    result.append(" destinationId: ").append(getDestinationId()).append(" groupByObjects: ").append(getGroupByObjects()).append(" modelLinks: ").append(getModelLinks()).append(" aggregatedObjects: ").append(getAggregatedObjects()).append(" layoutFunctionWrappers: ").append(getLayoutFunctionHandlers());
    return result;
  }

  protected void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws AdapterAccessException, DataAccessException
  {
    CmdbObjects cmdbObjects = getFunctionsLayout(dataAccessManager);
    setResultObjects(cmdbObjects);
    response.addResult("result_objects", cmdbObjects);
  }

  private CmdbObjects getFunctionsLayout(DataAccessAdapterManager dataAccessManager) throws DataAccessException
  {
    BasicDataAdapterWrapper adapterWrapper = getAdapter(dataAccessManager);
    BasicDataAdapter adapter = adapterWrapper.getBasicDataAdapter();
    CalculationStrategy calculationStrategy = getCalculationStrategy(dataAccessManager, adapterWrapper.getAdapterId());
    return calculationStrategy.getFunctionsLayout((FTqlDataAdapter)adapter, getGroupByObjects(), getModelLinks(), getAggregatedObjects(), getLayoutFunctionHandlers(), getDestinationId());
  }

  public String getOperationName()
  {
    return "DataAccessAdapterQuery: Get Functions Layout";
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    CmdbObjects cmdbObjects = (CmdbObjects)response.getResult("result_objects");
    setResultObjects(cmdbObjects);
  }

  private ModelObjects getGroupByObjects()
  {
    return this._groupByObjects;
  }

  private void setGroupByObjects(ModelObjects groupByObjects) {
    if (groupByObjects == null)
      throw new IllegalArgumentException("groupByObjects was null");

    if (groupByObjects.size() == 0)
      throw new IllegalArgumentException("groupByObjects was empty");

    this._groupByObjects = groupByObjects;
  }

  private ModelObjects getAggregatedObjects() {
    return this._aggregatedObjects;
  }

  private void setAggregatedObjects(ModelObjects aggregatedObjects) {
    if (aggregatedObjects == null)
      throw new IllegalArgumentException("aggregatedObjects was null");

    this._aggregatedObjects = aggregatedObjects;
  }

  private ModelLinks getModelLinks() {
    return this._modelLinks;
  }

  private void setModelLinks(ModelLinks modelLinks) {
    if (modelLinks == null)
      throw new IllegalArgumentException("modelLinks was null");

    this._modelLinks = modelLinks;
  }

  private LayoutFunctionWrappers getLayoutFunctionHandlers() {
    return this._layoutFunctionWrappers;
  }

  private void setLayoutFunctionHandlers(LayoutFunctionWrappers wrappers) {
    if (wrappers == null)
      throw new IllegalArgumentException("wrappers was null");

    this._layoutFunctionWrappers = wrappers;
  }

  public CmdbObjects getResultObjects() {
    return this._resultObjects;
  }

  private void setResultObjects(CmdbObjects resultObjects) {
    if (resultObjects == null)
      throw new IllegalArgumentException("resultObjects was null");

    this._resultObjects = resultObjects;
  }
}