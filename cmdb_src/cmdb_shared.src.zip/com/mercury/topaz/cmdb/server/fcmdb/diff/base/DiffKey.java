package com.mercury.topaz.cmdb.server.fcmdb.diff.base;

import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.TqlNameConfig;
import java.io.Serializable;

public class DiffKey
  implements Serializable
{
  private String tqlName;
  private boolean exclusive;
  private String sourceDestId;
  private String targetDestId;

  public DiffKey(String tqlName, boolean exclusive, String sourceDestId, String targetDestId)
  {
    setTqlName(tqlName);
    setExclusive(exclusive);
    setSourceDestId(sourceDestId);
    setTargetDestId(targetDestId); }

  public DiffKey(TqlNameConfig tqlNameConfig, String sourceDestId, String targetDestId) {
    setTqlName(tqlNameConfig.getName());
    setExclusive(tqlNameConfig.isExclusive());
    setSourceDestId(sourceDestId);
    setTargetDestId(targetDestId);
  }

  public String getTqlName() {
    return this.tqlName;
  }

  public void setTqlName(String tqlName) {
    this.tqlName = tqlName;
  }

  public boolean isExclusive() {
    return this.exclusive;
  }

  public void setExclusive(boolean exclusive) {
    this.exclusive = exclusive;
  }

  public String getTargetDestId() {
    return this.targetDestId;
  }

  public void setTargetDestId(String targetDestId) {
    this.targetDestId = targetDestId;
  }

  public String getSourceDestId() {
    return this.sourceDestId;
  }

  public void setSourceDestId(String sourceDestId) {
    this.sourceDestId = sourceDestId;
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if ((o == null) || (super.getClass() != o.getClass())) return false;

    DiffKey diffKey = (DiffKey)o;

    if (this.sourceDestId != null) if (this.sourceDestId.equals(diffKey.sourceDestId)) break label62; 
    else if (diffKey.sourceDestId == null) break label62; 
    return false;
    if (this.targetDestId != null) label62: if (this.targetDestId.equals(diffKey.targetDestId)) break label95; 
    else if (diffKey.targetDestId == null) break label95; 
    return false;
    if (this.tqlName != null) label95: if (this.tqlName.equals(diffKey.tqlName)) break label128; 
    label128: return (diffKey.tqlName == null);
  }

  public int hashCode()
  {
    int result = (this.tqlName != null) ? this.tqlName.hashCode() : 0;
    result = 29 * result + ((this.sourceDestId != null) ? this.sourceDestId.hashCode() : 0);
    result = 29 * result + ((this.targetDestId != null) ? this.targetDestId.hashCode() : 0);
    return result;
  }
}