package com.mercury.topaz.cmdb.server.fcmdb.ftql;

import java.io.Serializable;

public abstract interface DataStorePermutationInfo extends Serializable
{
  public abstract String getEnd1DataStore();

  public abstract String getEnd2DataStore();
}