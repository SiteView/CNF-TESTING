package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.mappingEngine.MappingEngine;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessContainerQueryObtainMappingEngineByDestinationConfig extends AbstractDataAccessContainerQuery
{
  private static final String RETRIEVE_RESULT = "Retrieve Result";
  private String _mappingEngineClassName;
  private DestinationConfig _destinationConfig;
  private MappingEngine _mappingEngine;

  public DataAccessContainerQueryObtainMappingEngineByDestinationConfig(String mappingEngineClassName, DestinationConfig destinationConfig)
  {
    setMappingEngineClassName(mappingEngineClassName);
    setDestinationConfig(destinationConfig);
  }

  public void setDestinationConfig(DestinationConfig destinationConfig) {
    this._destinationConfig = destinationConfig;
  }

  public String getOperationName()
  {
    return "data access query: get mapping engine instance";
  }

  protected DestinationConfig getDestinationConfig() {
    return this._destinationConfig;
  }

  private String getMappingEngineClassName() {
    return this._mappingEngineClassName;
  }

  private void setMappingEngineClassName(String mappingEngineClassName) {
    if ((mappingEngineClassName == null) || (mappingEngineClassName.length() == 0))
      throw new IllegalArgumentException("mapping engine java class name is null or empty !!!");

    this._mappingEngineClassName = mappingEngineClassName;
  }

  public MappingEngine getMappingEngine()
  {
    return this._mappingEngine;
  }

  private void setMappingEngine(MappingEngine mappingEngine) {
    this._mappingEngine = mappingEngine;
  }

  public void dataAccessContainerExecute(DataAccessContainerManager dataAccessContainerManager, CmdbResponse response) throws AdapterAccessException {
    MappingEngine mappingEngine = dataAccessContainerManager.obtainMappingEngine(getMappingEngineClassName(), getDestinationConfig());
    response.addResult("Retrieve Result", mappingEngine);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setMappingEngine((MappingEngine)response.getResult("Retrieve Result"));
  }
}