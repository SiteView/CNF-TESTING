package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.impl;

import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessGeneralException;
import com.mercury.topaz.cmdb.shared.util.filesystem.traverse.FilesHandler;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class AdapterCodeBaseTraverse
  implements FilesHandler
{
  private List<URL> _urls;

  public AdapterCodeBaseTraverse()
  {
    this._urls = new ArrayList(); }

  public void handleFile(String fileName) {
    File file = new File(fileName);
    if (file.getName().endsWith(".jar"))
      try {
        this._urls.add(file.toURL());
      } catch (MalformedURLException e) {
        throw new AdapterAccessGeneralException("cannot load jar [" + fileName + "] due to error", e);
      }
  }

  public void handleEnterFolder(String folderName)
  {
    File folder = new File(folderName);
    if ("classes".equals(folder.getName()))
      try {
        this._urls.add(folder.toURL());
      } catch (MalformedURLException e) {
        throw new AdapterAccessGeneralException("cannot load classes due to error", e);
      }
  }

  public void handleExitFolder(String folderName)
  {
  }

  public URL[] getUrls()
  {
    return ((URL[])this._urls.toArray(new URL[0]));
  }
}