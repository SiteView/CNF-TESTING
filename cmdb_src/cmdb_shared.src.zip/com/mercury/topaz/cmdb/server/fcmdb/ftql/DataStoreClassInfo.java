package com.mercury.topaz.cmdb.server.fcmdb.ftql;

import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import java.io.Serializable;

public abstract interface DataStoreClassInfo extends Serializable
{
  public abstract String getDataStore();

  public abstract String getClassName();

  public abstract ElementIdsCondition getElementIdsCondition();
}