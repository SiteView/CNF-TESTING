package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ModifiableClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl.ClassDestinationsConfigFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.util.ConfigUtil;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.DestinationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.ModifiableFederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateFederationConfgOperation;

public class ConfigUpdateAddDestinationConfig extends AbstractConfigUpdateFederationConfgOperation
{
  private DestinationConfigDef destinationConfigDef;

  public ConfigUpdateAddDestinationConfig(DestinationConfigDef destinationConfigDef)
  {
    setDestinationConfigDef(destinationConfigDef);
  }

  public String getOperationName() {
    return "Config Update: Add Destination Config";
  }

  protected void updateConfig(ModifiableFederationConfigDef federationConfigDef, ConfigUpdateManager configUpdateManager)
  {
    federationConfigDef.addDestinationConfigDef(getDestinationConfigDef());
    ModifiableClassModelDestinationsConfig classesDestinationsConfig = ClassDestinationsConfigFactory.createModifiableClassesDestinationsConfig(getClassesDestinationsConfig());
    ConfigUtil.addDestinationToCmdbClassDestinationsConfig(classesDestinationsConfig, getDestinationConfigDef());
    ConfigUtil.updateClassModelDestinationsConfigCache(ClassDestinationsConfigFactory.createReadOnlyClassesDestinationsConfig(classesDestinationsConfig));
  }

  private DestinationConfigDef getDestinationConfigDef() {
    return this.destinationConfigDef;
  }

  private void setDestinationConfigDef(DestinationConfigDef destinationConfigDef) {
    this.destinationConfigDef = destinationConfigDef;
  }
}