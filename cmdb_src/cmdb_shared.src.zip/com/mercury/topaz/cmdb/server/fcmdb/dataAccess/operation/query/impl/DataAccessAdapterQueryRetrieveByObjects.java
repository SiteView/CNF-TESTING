package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.replication.SourceDataAdapter;
import com.hp.ucmdb.federationspi.data.replication.FCmdbDataContainer;
import com.hp.ucmdb.federationspi.data.replication.FCmdbDataIdsContainer;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.replication.FCmdbDatasContainerFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessAdapterQueryRetrieveByObjects extends AbstractDataAccessLifeCycleAdapterQuery
{
  private static final String RETRIEVE_RESULT = "Retrieve Result";
  private FCmdbDataContainer _result;
  private FCmdbDataIdsContainer _datasContainer;

  public DataAccessAdapterQueryRetrieveByObjects(String destinationId, FCmdbDataIdsContainer datasContainer)
  {
    super(destinationId);
    this._datasContainer = datasContainer;
  }

  public String getOperationName() {
    return "DataAccess Query: Retrieve By Objects";
  }

  public void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws AdapterAccessException, DataAccessException
  {
    FCmdbDataContainer result;
    if (this._datasContainer.isEmpty()) {
      result = FCmdbDatasContainerFactory.createDatasContainer();
    } else {
      SourceDataAdapter adapter = (SourceDataAdapter)getAdapter(dataAccessManager).getBasicDataAdapter();

      result = adapter.retrieveFullLayout(this._datasContainer);
    }

    response.addResult("Retrieve Result", result);
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
    this._result = ((FCmdbDataContainer)response.getResult("Retrieve Result"));
  }

  public FCmdbDataContainer getResultCmdbGraph() {
    return this._result;
  }

  public FCmdbDataIdsContainer getDataForRetrieve()
  {
    return this._datasContainer;
  }

  protected StringBuilder getOutputInfo() {
    return new StringBuilder("Graph: ").append(getResultCmdbGraph());
  }

  protected StringBuilder getInputInfo() {
    return new StringBuilder("Target ID: ").append(getDestinationId()).append(", Action Data Container: ").append(this._datasContainer);
  }
}