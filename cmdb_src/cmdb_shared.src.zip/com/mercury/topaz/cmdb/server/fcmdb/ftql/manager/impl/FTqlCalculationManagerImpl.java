package com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.impl;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadSingleWrite;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.rpm.LoadConfigurator;
import com.mercury.topaz.cmdb.server.model.datasource.TqlExtendedModelDataSourceQuery;
import com.mercury.topaz.cmdb.server.model.datasource.impl.TqlExtendedModelDataSourceQueryFactory;
import com.mercury.topaz.cmdb.server.tql.manager.TqlConditionStatisticsManager;
import com.mercury.topaz.cmdb.server.tql.manager.impl.TqlResultUtilsManagerImpl;

public class FTqlCalculationManagerImpl extends TqlResultUtilsManagerImpl
  implements FTqlCalculationManager, MultiReadSingleWrite, LoadConfigurator
{
  private TqlExtendedModelDataSourceQuery dataSourceQuery;
  private TqlConditionStatisticsManager statisticsManager;

  public FTqlCalculationManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
    this.dataSourceQuery = TqlExtendedModelDataSourceQueryFactory.createFederatedModelDataSourceQuery();
    this.statisticsManager = new FTqlConditionStatisticsManager();
  }

  public String getName() {
    return "FTql Calculation Task";
  }

  public TqlExtendedModelDataSourceQuery getDataSourceQuery() {
    return this.dataSourceQuery;
  }

  public TqlConditionStatisticsManager getConditionStatisticsManager() {
    return this.statisticsManager;
  }

  public int getPendingRequestsThreshold() {
    return getLocalSettings().getInt("tql.federated.max.pending.requests", 10);
  }

  public long getMaxPendingTime() {
    return getLocalSettings().getLong("tql.federated.max.pending.time", 600000L);
  }
}