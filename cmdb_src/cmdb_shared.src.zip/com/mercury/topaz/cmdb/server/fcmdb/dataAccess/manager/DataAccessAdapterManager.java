package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager;

import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public abstract interface DataAccessAdapterManager extends CmdbSubsystemManager
{
  public static final String NAME = "Data Access Adapter Task";

  public abstract int getReplicationAllowedNumberOfObjectsFromDataStore();

  public abstract int getFtqlAllowedNumberOfObjectsFromDataStore();
}