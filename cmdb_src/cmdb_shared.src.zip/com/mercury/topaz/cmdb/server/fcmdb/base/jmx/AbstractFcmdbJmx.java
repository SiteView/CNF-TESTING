package com.mercury.topaz.cmdb.server.fcmdb.base.jmx;

import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;

public class AbstractFcmdbJmx extends AbstractCmdbJmx
{
}