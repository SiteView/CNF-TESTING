package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.util.ConfigEncryptionUtil;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.exception.FConfigException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.query.impl.ConfigQueryGetAutoSynchronizedConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.net.URL;

public class ConfigUpdateReplaceEncryptionKeyFile extends AbstractConfigUpdateOperation
{
  private URL newKeyLocation;

  public ConfigUpdateReplaceEncryptionKeyFile()
  {
    this.newKeyLocation = null;
  }

  public ConfigUpdateReplaceEncryptionKeyFile(URL newKeyLocation)
  {
    this.newKeyLocation = newKeyLocation;
  }

  public void updateConfigExecute(ConfigUpdateManager configUpdateManager, CmdbResponse cmdbResponse)
  {
    try {
      if (this.newKeyLocation == null)
        ConfigEncryptionUtil.generateNewEncryptionKeyFile();
      else
        ConfigEncryptionUtil.replaceEncryptionKeyFile(this.newKeyLocation);

      saveFederationConfigToPersistence();
    }
    catch (Exception e) {
      throw new FConfigException("Replacing/Generating the keyfile failed", e);
    }
  }

  private void saveFederationConfigToPersistence()
  {
    ConfigQueryGetAutoSynchronizedConfig configQuery = new ConfigQueryGetAutoSynchronizedConfig();
    ServerApiFacade.executeOperation(configQuery);
    ServerApiFacade.executeOperation(new ConfigUpdateFederationConfigUpdate(configQuery.getFederationConfig()));
  }

  public String getOperationName()
  {
    return "Config Update: Replace encryption key file";
  }
}