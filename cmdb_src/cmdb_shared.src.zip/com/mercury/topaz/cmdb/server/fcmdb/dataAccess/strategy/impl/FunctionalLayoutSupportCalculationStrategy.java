package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.impl;

import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.util.CalculationUtils;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrappers;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;

public class FunctionalLayoutSupportCalculationStrategy extends PatternSupportCalculationStrategy
{
  public CmdbObjects getFunctionsLayout(FTqlDataAdapter adapter, ModelObjects groupByObjects, ModelLinks modelLinks, ModelObjects aggregatedObjects, LayoutFunctionWrappers wrappers, String dataStore)
    throws AdapterAccessException, DataAccessException
  {
    return CalculationUtils.getFunctionsLayoutByAdapter(adapter, groupByObjects, modelLinks, aggregatedObjects, wrappers);
  }
}