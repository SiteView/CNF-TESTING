package com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassAttributesDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ModifiableClassModelDestinationsConfig;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class ClassDestinationsConfigFactory
{
  public static final ClassModelDestinationsConfig EMTPY_CLASS_MODEL_DESTINATION_CONFIG = new ClassModelDestinationsConfigImpl();

  public static ClassDestinationsConfig cloneClassDestinationsConfig(ClassDestinationsConfig classDestinationsConfig)
  {
    Collection copiedDestinations = new ArrayList(classDestinationsConfig.getDestinations());
    return new ClassDestinationsConfigImpl(classDestinationsConfig.getClassName(), copiedDestinations);
  }

  public static ClassAttributesDestinationsConfig cloneClassAttributesDestinationsConfig(ClassAttributesDestinationsConfig classAttributesDestinationsConfig) {
    ClassAttributesDestinationsConfig newClassAttributesDestinationsConfig = new ClassAttributesDestinationsConfigImpl(classAttributesDestinationsConfig.getClassName());
    Collection attributes = classAttributesDestinationsConfig.getAttributes();
    for (Iterator i$ = attributes.iterator(); i$.hasNext(); ) { String attribute = (String)i$.next();
      Collection destinations = classAttributesDestinationsConfig.getDestinations(attribute);
      if (destinations != null)
        newClassAttributesDestinationsConfig.addAttributeDestinations(attribute, new ArrayList(destinations));
    }

    return newClassAttributesDestinationsConfig; }

  public static ClassDestinationsConfig createClassDestinationsConfig(String className) {
    return new ClassDestinationsConfigImpl(className); }

  public static ClassDestinationsConfig createClassDestinationsConfig(ClassDestinationsConfig classDestinationsConfig) {
    return new ClassDestinationsConfigImpl(classDestinationsConfig);
  }

  public static ClassModelDestinationsConfig createReadOnlyClassesDestinationsConfig(ClassModelDestinationsConfig classModelDestinationsConfig) {
    Collection classesDestinationConfig = new ArrayList();
    for (Iterator allClassDestinationsConfig = classModelDestinationsConfig.getAllClassDestinationsConfig(); allClassDestinationsConfig.hasNext(); )
      classesDestinationConfig.add(cloneClassDestinationsConfig((ClassDestinationsConfig)allClassDestinationsConfig.next()));

    Collection classesAttributesDestinationConfig = new ArrayList();
    for (Iterator allClassAttributesDestinationsConfig = classModelDestinationsConfig.getAllClassAttributesDestinationConfig(); allClassAttributesDestinationsConfig.hasNext(); )
      classesAttributesDestinationConfig.add(cloneClassAttributesDestinationsConfig((ClassAttributesDestinationsConfig)allClassAttributesDestinationsConfig.next()));

    return new ClassModelDestinationsConfigImpl(classesDestinationConfig, classesAttributesDestinationConfig);
  }

  public static ModifiableClassModelDestinationsConfig createModifiableClassesDestinationsConfig(ClassModelDestinationsConfig classModelDestinationsConfig) {
    return new ModifiableClassModelDestinationsConfigImpl(classModelDestinationsConfig); }

  public static ModifiableClassModelDestinationsConfig createModifiableClassesDestinationsConfig() {
    return new ModifiableClassModelDestinationsConfigImpl();
  }

  public static ClassAttributesDestinationsConfig createClassAttributesDestinationsConfig(String className) {
    return new ClassAttributesDestinationsConfigImpl(className);
  }

  public static ClassAttributesDestinationsConfig createClassAttributesDestinationsConfig(ClassAttributesDestinationsConfig classAttributesDestinationsConfig) {
    return new ClassAttributesDestinationsConfigImpl(classAttributesDestinationsConfig);
  }
}