package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.ResultStrategy;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;

public class DataAccessAdapterQuerySortObjects extends AbstractDataAccessLifeCycleAdapterQuery
{
  private static Log _log = LogFactory.getEasyLog(DataAccessAdapterQuerySortObjects.class);
  private static final String KEY_RESULT_OBJECT = "result_objects";
  private CmdbSortCommand _sortCommand;
  private ModelObjects _inputObjects;
  private ElementCondition _elementCondition;
  private CmdbObjectIds _resultObjectIDs;

  public DataAccessAdapterQuerySortObjects(String destinationId, ModelObjects modelObjects, CmdbSortCommand sortCommand)
  {
    super(destinationId);
    setInputObjects(modelObjects);
    setSortCommand(sortCommand);
  }

  public DataAccessAdapterQuerySortObjects(String destinationId, ElementCondition elementCondition, CmdbSortCommand sortCommand) {
    super(destinationId);
    setElementCondition(elementCondition);
    setSortCommand(sortCommand);
  }

  protected StringBuilder getOutputInfo()
  {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("result objects: ").append(getResultObjectIDs());
    return stringBuilder;
  }

  protected StringBuilder getInputInfo() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" destinoation id: ").append(getDestinationId());
    if (getInputObjects() != null) {
      stringBuilder.append(" input objects: ").append(getInputObjects());
    }
    else
      stringBuilder.append(" element Condition: ").append(getElementCondition());

    stringBuilder.append(" sort command: ").append(getSortCommand());
    return stringBuilder;
  }

  protected void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response)
    throws AdapterAccessException, DataAccessException
  {
    CmdbObjectIds sortedObjectIDs;
    if (getInputObjects() != null)
      sortedObjectIDs = sortObjects(dataAccessManager, getInputObjects(), getSortCommand());
    else
      sortedObjectIDs = sortObjects(dataAccessManager, getElementCondition(), getSortCommand());

    setResultObjectIDs(sortedObjectIDs);
    response.addResult("result_objects", sortedObjectIDs);
  }

  private CmdbObjectIds sortObjects(DataAccessAdapterManager dataAccessManager, ModelObjects modelObjects, CmdbSortCommand sortCommand) throws DataAccessException
  {
    BasicDataAdapterWrapper adapterWrapper = getAdapter(dataAccessManager);
    BasicDataAdapter adapter = adapterWrapper.getBasicDataAdapter();
    CalculationStrategy calculationStrategy = getCalculationStrategy(dataAccessManager, adapterWrapper.getAdapterId());
    ResultStrategy resultStrategy = getResultStrategy(dataAccessManager, adapterWrapper.getAdapterId());
    return resultStrategy.sortObjects((FTqlDataAdapter)adapter, modelObjects, sortCommand, calculationStrategy, getDestinationId());
  }

  private CmdbObjectIds sortObjects(DataAccessAdapterManager dataAccessManager, ElementCondition elementCondition, CmdbSortCommand sortCommand)
    throws DataAccessException
  {
    BasicDataAdapterWrapper adapterWrapper = getAdapter(dataAccessManager);
    BasicDataAdapter adapter = adapterWrapper.getBasicDataAdapter();
    CalculationStrategy calculationStrategy = getCalculationStrategy(dataAccessManager, adapterWrapper.getAdapterId());
    ResultStrategy resultStrategy = getResultStrategy(dataAccessManager, adapterWrapper.getAdapterId());
    CmdbObjectIds sortedObjectIDs = resultStrategy.sortObjects((FTqlDataAdapter)adapter, elementCondition, sortCommand, calculationStrategy, getDestinationId());
    return sortedObjectIDs;
  }

  public String getOperationName()
  {
    return "Data Access Adapter Query: Sort Objects";
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setResultObjectIDs((CmdbObjectIds)response.getResult("result_objects"));
  }

  private CmdbSortCommand getSortCommand()
  {
    return this._sortCommand;
  }

  private void setSortCommand(CmdbSortCommand sortCommand) {
    if (sortCommand == null)
      throw new IllegalArgumentException("sortCommand was null");

    this._sortCommand = sortCommand;
  }

  private ModelObjects getInputObjects() {
    return this._inputObjects;
  }

  private void setInputObjects(ModelObjects inputObjects) {
    if (inputObjects == null)
      throw new IllegalArgumentException("inputObjects was null");

    this._inputObjects = inputObjects;
  }

  public CmdbObjectIds getResultObjectIDs() {
    return this._resultObjectIDs;
  }

  private void setResultObjectIDs(CmdbObjectIds resultObjectIDs) {
    if (resultObjectIDs == null)
      throw new IllegalArgumentException("resultObjectIDs was null");

    this._resultObjectIDs = resultObjectIDs;
  }

  private ElementCondition getElementCondition() {
    return this._elementCondition;
  }

  private void setElementCondition(ElementCondition elementCondition) {
    if (elementCondition == null)
      throw new IllegalArgumentException("elementCondition was null");

    this._elementCondition = elementCondition;
  }
}