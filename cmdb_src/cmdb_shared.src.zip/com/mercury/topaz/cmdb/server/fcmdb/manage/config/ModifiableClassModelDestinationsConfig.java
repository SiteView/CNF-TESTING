package com.mercury.topaz.cmdb.server.fcmdb.manage.config;

import java.util.Collection;

public abstract interface ModifiableClassModelDestinationsConfig extends ClassModelDestinationsConfig
{
  public abstract void addDestinationForClass(String paramString1, String paramString2);

  public abstract void addDestinationForClassAndAttribute(String paramString1, String paramString2, String paramString3);

  public abstract boolean removeDestinationForClass(String paramString1, String paramString2);

  public abstract boolean removeDestinationForClassAndAttribute(String paramString1, String paramString2, String paramString3);

  public abstract void cleanAll();

  public abstract void removeDestinationForClassAndAttributes(String paramString1, String paramString2, Collection<String> paramCollection);

  public abstract void addDestinationForClassAndAttributes(String paramString1, String paramString2, Collection<String> paramCollection);
}