package com.mercury.topaz.cmdb.server.fcmdb.base.jmx.synchronizer;

import com.mercury.topaz.cmdb.server.fcmdb.base.jmx.AbstractFcmdbJmx;
import com.mercury.topaz.cmdb.shared.fcmdb.synchronizer.operation.command.impl.SynchronizerCommandRunDiffSynchronization;
import com.mercury.topaz.cmdb.shared.fcmdb.synchronizer.operation.command.impl.SynchronizerCommandRunFullSynchronization;
import com.mercury.topaz.cmdb.shared.fcmdb.synchronizer.operation.update.impl.SynchronizerUpdateInterruptSynch;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=FCmdb Synchronizer Services", description="FCmdb Synchronizer Services")
public class SynchJmxServices extends AbstractFcmdbJmx
{
  @ManagedOperation(description="Perform hard full synch")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer id"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="syncUnitId", description="Synch unit ID")})
  public String performFullSynch(Integer customerID, String syncUnitId)
  {
    try
    {
      invokeOperation(new SynchronizerCommandRunFullSynchronization(syncUnitId), customerID);
    } catch (Throwable e) {
      return createStringFromException(e, new String[0]);
    }
    return "The Full synch was properly performed ";
  }

  @ManagedOperation(description="Perform diff synch")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer id"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="syncUnitId", description="Synch unit ID")})
  public String performDiffSynch(Integer customerID, String syncUnitId)
  {
    try
    {
      invokeOperation(new SynchronizerCommandRunDiffSynchronization(syncUnitId), customerID);
    } catch (Throwable e) {
      return createStringFromException(e, new String[0]);
    }
    return "The Diff synch was properly performed ";
  }

  @ManagedOperation(description="interrupt synch unit")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer id"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="syncUnitId", description="Synch unit ID")})
  public String interruptSynch(Integer customerID, String syncUnitId)
  {
    SynchronizerUpdateInterruptSynch interruptSynch = new SynchronizerUpdateInterruptSynch(syncUnitId);
    try {
      invokeOperation(interruptSynch, customerID);
    } catch (Throwable e) {
      return createStringFromException(e, new String[0]);
    }

    if (interruptSynch.isInterrupted())
      return "synch unit (" + syncUnitId + ") was interrupted!";

    return "synch unit (" + syncUnitId + ") is not running and could not be interrupted!";
  }
}