package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.replication.SourceDataAdapter;
import com.hp.ucmdb.federationspi.data.query.topology.QueryDefinition;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyIds;
import com.hp.ucmdb.federationspi.data.replication.FCmdbResultContainer;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.Collection;

public class DataAccessAdapterQueryRetrieveByPattern extends AbstractDataAccessLifeCycleAdapterQuery
{
  private static final String RETRIEVE_RESULT = "Retrieve Result";
  private QueryDefinition _query;
  private FCmdbResultContainer _result;

  public DataAccessAdapterQueryRetrieveByPattern(String targetID, QueryDefinition query)
  {
    super(targetID);
    this._query = query;
  }

  public QueryDefinition getQuery()
  {
    return this._query;
  }

  public String getOperationName()
  {
    return "DataAccess Query: Retrieve By Pattern operation";
  }

  public void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws AdapterAccessException, DataAccessException {
    BasicDataAdapter adapter = getAdapter(dataAccessManager).getBasicDataAdapter();
    FCmdbResultContainer result = getTopology(adapter);

    replicationFuse(dataAccessManager, new Collection[] { result.getTopology().getAllCIs() });

    response.addResult("Retrieve Result", result);
  }

  protected FCmdbResultContainer getTopology(BasicDataAdapter adapter) throws DataAccessException {
    return ((SourceDataAdapter)adapter).getTopology(this._query);
  }

  public void updateQueryWithResponse(CmdbResponse cmdbResponse)
  {
    this._result = ((FCmdbResultContainer)cmdbResponse.getResult("Retrieve Result"));
  }

  public FCmdbResultContainer getResultContainer() {
    return this._result;
  }

  protected StringBuilder getOutputInfo() {
    return new StringBuilder("Result: ").append(this._result);
  }

  protected StringBuilder getInputInfo() {
    return new StringBuilder("Target ID: ").append(getDestinationId()).append(", Pattern Name: ").append(this._query);
  }
}