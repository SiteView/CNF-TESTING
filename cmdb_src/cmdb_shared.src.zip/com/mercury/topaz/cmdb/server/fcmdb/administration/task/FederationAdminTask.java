package com.mercury.topaz.cmdb.server.fcmdb.administration.task;

public class FederationAdminTask
{
  public static final String NAME = "Federation Admin Task";
}