package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ModifiableClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl.ClassDestinationsConfigFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.util.ConfigUtil;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.DestinationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.ModifiableFederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateFederationConfgOperation;

public class ConfigUpdateDestinationConfigRemove extends AbstractConfigUpdateFederationConfgOperation
{
  private String _destinationId;

  public ConfigUpdateDestinationConfigRemove(String destinationId)
  {
    setDestinationId(destinationId);
  }

  public String getDestinationId() {
    return this._destinationId;
  }

  private void setDestinationId(String destinationId) {
    if (destinationId == null)
      throw new IllegalArgumentException("The destination id is null");

    this._destinationId = destinationId;
  }

  protected void updateConfig(ModifiableFederationConfigDef federationConfigDef, ConfigUpdateManager configUpdateManager) {
    DestinationConfigDef destConfigDef = ConfigUtil.getDestinationConfigDefById(federationConfigDef, getDestinationId());
    federationConfigDef.removeDestinationConfigDef(getDestinationId());
    ModifiableClassModelDestinationsConfig classesDestinationsConfig = ClassDestinationsConfigFactory.createModifiableClassesDestinationsConfig(getClassesDestinationsConfig());
    ConfigUtil.removeDestinationFromClassModelDestinationsConfig(classesDestinationsConfig, destConfigDef);
    ConfigUtil.updateClassModelDestinationsConfigCache(ClassDestinationsConfigFactory.createReadOnlyClassesDestinationsConfig(classesDestinationsConfig));
    ConfigUtil.updateUcmdbSupportedClases(federationConfigDef, destConfigDef, null, classesDestinationsConfig);
  }

  public String getOperationName()
  {
    return "Config Update: Remove Destination Config Def";
  }
}