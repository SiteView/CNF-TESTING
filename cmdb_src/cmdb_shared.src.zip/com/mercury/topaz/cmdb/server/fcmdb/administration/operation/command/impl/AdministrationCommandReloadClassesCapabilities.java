package com.mercury.topaz.cmdb.server.fcmdb.administration.operation.command.impl;

import com.mercury.topaz.cmdb.server.fcmdb.administration.manager.FederationAdminManager;
import com.mercury.topaz.cmdb.server.fcmdb.administration.util.ConfigChangesUtil;
import com.mercury.topaz.cmdb.shared.fcmdb.administration.operation.command.impl.AbstractAdministrationCommand;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class AdministrationCommandReloadClassesCapabilities extends AbstractAdministrationCommand
{
  public String getOperationName()
  {
    return "Config Update Reload Config";
  }

  public void federationAdminExecute(FederationAdminManager federationAdminManager, CmdbResponse response) throws AdapterAccessException {
    ConfigChangesUtil.reloadClassesCapabilities(federationAdminManager);
  }
}