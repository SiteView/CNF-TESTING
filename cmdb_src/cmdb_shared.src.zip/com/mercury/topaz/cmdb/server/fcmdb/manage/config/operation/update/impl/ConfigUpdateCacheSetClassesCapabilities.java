package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigCacheManager;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ClassesCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateCacheOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class ConfigUpdateCacheSetClassesCapabilities extends AbstractConfigUpdateCacheOperation
{
  private ClassesCapabilities _classesCapabilities;

  public ConfigUpdateCacheSetClassesCapabilities(ClassesCapabilities classesCapabilities)
  {
    setClassesCapabilities(classesCapabilities);
  }

  private void setClassesCapabilities(ClassesCapabilities classesCapabilities)
  {
    if (classesCapabilities == null)
      throw new IllegalArgumentException("classesCapabilities is null");

    this._classesCapabilities = classesCapabilities;
  }

  public void updateConfigCacheExecute(ConfigCacheManager configCacheManager, CmdbResponse response) {
    configCacheManager.setClassesCapabilities(getClassesCapabilities());
  }

  private ClassesCapabilities getClassesCapabilities() {
    return this._classesCapabilities;
  }

  public String getOperationName() {
    return "Config Update Cache: Set Destinations Classes Config";
  }
}