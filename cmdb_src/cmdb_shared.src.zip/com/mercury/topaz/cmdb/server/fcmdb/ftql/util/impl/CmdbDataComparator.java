package com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl;

import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.ValuePropertyComparator;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.ValuePropertyComparatorFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommandAttributeOrder;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommandOrderDirection;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Comparator;

public class CmdbDataComparator
  implements Comparator<CmdbData>
{
  private CmdbSortCommand _sortCommand;
  private ValuePropertyComparator _valuePropertyComparator;

  public CmdbDataComparator(CmdbSortCommand sortCommand)
  {
    this._sortCommand = sortCommand;
    this._valuePropertyComparator = ValuePropertyComparatorFactory.create(); }

  public int compare(CmdbData cmdbData1, CmdbData cmdbData2) {
    if (cmdbData1 == cmdbData2)
      return 0;

    if (cmdbData1 == null)
      return -1;

    if (cmdbData2 == null)
      return 1;

    ReadOnlyIterator attributeOrderIterator = this._sortCommand.getAttributeOrderIterator();
    while (true) { CmdbSortCommandAttributeOrder sortCommand;
      CmdbProperty cmdbProperty1;
      CmdbProperty cmdbProperty2;
      while (true) { if (!(attributeOrderIterator.hasNext())) break label272;
        sortCommand = (CmdbSortCommandAttributeOrder)attributeOrderIterator.next();
        String curAttrName = sortCommand.getAttributeName();
        cmdbProperty1 = cmdbData1.getProperty(curAttrName);
        cmdbProperty2 = cmdbData2.getProperty(curAttrName);

        if ("root_class".equals(curAttrName)) {
          property1Type = CmdbSimpleTypes.CmdbString;
          property1Value = cmdbData1.getType();
          property2Value = cmdbData2.getType();
          break label222: }
        if ((!(isEmpty(cmdbProperty1))) || (!(isEmpty(cmdbProperty2)))) break;
      }
      if (isEmpty(cmdbProperty1))
        return ((CmdbSortCommandOrderDirection.ASC.equals(sortCommand.getOrderDirection())) ? -1 : 1);

      CmdbType property1Type = cmdbProperty1.getType();
      Object property1Value = cmdbProperty1.getValue();

      if (isEmpty(cmdbProperty2))
        return ((CmdbSortCommandOrderDirection.ASC.equals(sortCommand.getOrderDirection())) ? 1 : -1);

      Object property2Value = cmdbProperty2.getValue();

      label222: int comparisonResult = this._valuePropertyComparator.compare(property1Type, property1Value, property2Value);
      if (comparisonResult != 0) {
        if (sortCommand.getOrderDirection().equals(CmdbSortCommandOrderDirection.DESC))
          comparisonResult = -1 * comparisonResult;

        return comparisonResult;
      }
    }
    label272: return 0;
  }

  private boolean isEmpty(CmdbProperty property) {
    return ((null == property) || (property.isValueEmpty()));
  }
}