package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.FTqlCalculationOperation;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.fcmdb.operation.impl.AbstractFCmdbOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractFTqlCalculationOperation extends AbstractFCmdbOperation
  implements FTqlCalculationOperation
{
  protected void doExecute(SubsystemManager manager, CmdbResponse response)
    throws CmdbException
  {
    ftqlCalculationExecute((FTqlCalculationManager)manager, response);
  }

  public String getExecutionTaskQueueName() {
    return "FTql Calculation Task";
  }
}