package com.mercury.topaz.cmdb.server.fcmdb.ftql;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

public abstract interface ElementDataStoresInfo extends Serializable
{
  public abstract String getUcmdbClassName();

  public abstract Collection<DataStoreClassInfo> getSupportedDataStoresInfo();

  public abstract Set<String> getAllCoreDataStores();

  public abstract void addDataStoreClassInfo(DataStoreClassInfo paramDataStoreClassInfo);

  public abstract Map<String, Set<DataStoreAttributeInfo>> getExternalAttributesWithDataStores();

  public abstract Set<DataStoreAttributeInfo> getDataStoresForExternalAttribute(String paramString);

  public abstract void addExternalAttributesInfo(Map<String, Set<DataStoreAttributeInfo>> paramMap);

  public abstract Set<String> getAllDataStores();

  public abstract Set<String> getAllExternalAttributes();

  public abstract boolean hasExternalAttributes();

  public abstract void addExternalAttributeInfo(String paramString, DataStoreAttributeInfo[] paramArrayOfDataStoreAttributeInfo);
}