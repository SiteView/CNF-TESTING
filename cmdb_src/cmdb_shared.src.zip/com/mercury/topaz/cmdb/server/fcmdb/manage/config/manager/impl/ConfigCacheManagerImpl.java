package com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigCacheManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ClassesCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.impl.ClassesCapabilitiesFactory;
import com.mercury.topaz.cmdb.shared.util.timestamp.CmdbTimeStamp;
import java.util.HashMap;

public class ConfigCacheManagerImpl extends CmdbSubsystemManagerImpl
  implements ConfigCacheManager, SingleReadSingleWrite
{
  private static Log _logger = LogFactory.getEasyLog(ConfigCacheManagerImpl.class);
  private FederationConfig _federationConfig;
  private ClassesCapabilities _classesCapabilities;

  public ConfigCacheManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public void startUp() {
    this._classesCapabilities = ClassesCapabilitiesFactory.createClassesCapabilities(new HashMap());
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Federation Configuration Cache Manager is started up properly !!!");
  }

  public boolean isClassesCapabilitiesChanged(CmdbTimeStamp cmdbTimeStamp) {
    return (!(this._classesCapabilities.getClassesCapabilitiesTimeStamp().equals(cmdbTimeStamp)));
  }

  public ClassesCapabilities getClassesCapabilities() {
    return this._classesCapabilities;
  }

  public void shutdown() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Federation Configuration Cache Manager is shutdown properly !!!");
  }

  public void setFederationConfig(FederationConfig federationConfig) {
    this._federationConfig = federationConfig;
    if (_logger.isDebugEnabled())
      _logger.debug("loaded federation configuration: [" + federationConfig + "]");
  }

  public void setClassesCapabilities(ClassesCapabilities classesCapabilities)
  {
    this._classesCapabilities = classesCapabilities;
  }

  public FederationConfig getFederationConfig() {
    return this._federationConfig;
  }

  public String getName() {
    return "Federation Config Cache Task";
  }
}