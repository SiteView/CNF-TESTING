package com.mercury.topaz.cmdb.server.fcmdb.ftql;

import java.io.Serializable;

public abstract interface DataStoreAttributeInfo extends Serializable
{
  public abstract String getDataStore();

  public abstract String getClassName();

  public abstract String getAttributeName();
}