package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.util;

import com.hp.ucmdb.federationspi.adapter.environment.DataAdapterEnvironment;
import com.hp.ucmdb.federationspi.config.DestinationConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.load.impl.FederationConfigurationLoaderFactory;
import com.mercury.topaz.cmdb.server.fcmdb.spi.adapter.environment.DataAdapterEnvironmentFactory;
import com.mercury.topaz.cmdb.server.fcmdb.spi.config.DestinationConfigImpl;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.adapter.util.logging.DataAdapterLoggerFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AdapterConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DataAdapterEnvironmentUtil
{
  private static final String ADAPTER_CODE_BASE_FOLDER = FederationConfigurationLoaderFactory.getRootFederationConfigFolder() + File.separator + "CodeBase";

  public static DataAdapterEnvironment createDataAdapterEnvironment(DestinationConfig destinationConfig)
  {
    AdapterConfig adapterConfig = destinationConfig.getAdapterConfig();
    String adapterId = adapterConfig.getAdapterId();
    return DataAdapterEnvironmentFactory.createDataAdapterEnvironment(createAdapterURL(adapterId), DataAdapterLoggerFactory.getAdapterLogger(destinationConfig.getDestinationId()), convertDestinationConfigToSPI(destinationConfig)); }

  private static DestinationConfig convertDestinationConfigToSPI(DestinationConfig destinationConfig) {
    List queries = null;
    if (destinationConfig.getQueriesSize() > 0) {
      queries = new ArrayList();
      ReadOnlyIterator queriesIterator = destinationConfig.getQueries();
      while (queriesIterator.hasNext())
        queries.add((String)queriesIterator.next());
    }

    List classes = null;

    if (destinationConfig.getClassesSize() > 0) {
      classes = new ArrayList();
      ReadOnlyIterator classesIterator = destinationConfig.getClasses();
      while (classesIterator.hasNext())
        classes.add((String)classesIterator.next());

    }

    return new DestinationConfigImpl(destinationConfig.getDestinationId(), destinationConfig.getHostName(), destinationConfig.getPort(), destinationConfig.getUrl(), destinationConfig.getUserName(), destinationConfig.getPassword(), destinationConfig.getCustomerId(), queries, classes);
  }

  public static String createAdapterURL(String adapterId)
  {
    return ADAPTER_CODE_BASE_FOLDER + File.separator + adapterId;
  }
}