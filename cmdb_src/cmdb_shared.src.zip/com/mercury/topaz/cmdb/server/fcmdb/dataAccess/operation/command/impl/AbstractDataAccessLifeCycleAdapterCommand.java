package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.command.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.command.DataAccessCommand;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.impl.AbstractDataAccessLifeCycleAdapterOperation;

public abstract class AbstractDataAccessLifeCycleAdapterCommand extends AbstractDataAccessLifeCycleAdapterOperation
  implements DataAccessCommand
{
}