package com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassAttributesDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ModifiableClassModelDestinationsConfig;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ModifiableClassModelDestinationsConfigImpl
  implements ModifiableClassModelDestinationsConfig
{
  private Map<String, ClassDestinationsConfig> _classesMap;
  private Map<String, ClassAttributesDestinationsConfig> _classesAttributesMap;

  public ModifiableClassModelDestinationsConfigImpl()
  {
    this._classesMap = new HashMap();
    this._classesAttributesMap = new HashMap();
  }

  public ModifiableClassModelDestinationsConfigImpl(ClassModelDestinationsConfig classModelDestinationsConfig) {
    this._classesMap = new HashMap();
    this._classesAttributesMap = new HashMap();
    if (classModelDestinationsConfig != null) {
      addClassesDestinationsConfig(classModelDestinationsConfig.getAllClassDestinationsConfig());
      addClassesAttributesDestinationsConfig(classModelDestinationsConfig.getAllClassAttributesDestinationConfig());
    }
  }

  public Set<String> getAllExternalClasses()
  {
    return getClassesMap().keySet();
  }

  public Set<String> getAllExternalAttributes(String className) {
    ClassAttributesDestinationsConfig classAttributesDestinationsConfig = (ClassAttributesDestinationsConfig)this._classesAttributesMap.get(className);
    if (classAttributesDestinationsConfig == null)
      return Collections.EMPTY_SET;

    return new HashSet(classAttributesDestinationsConfig.getAttributes());
  }

  public Collection<String> getDestinationsForClass(String className) {
    ClassDestinationsConfig classDestinationsConfig = (ClassDestinationsConfig)getClassesMap().get(className);
    if (classDestinationsConfig != null)
      return classDestinationsConfig.getDestinations();

    return null;
  }

  public Collection<String> getDestinationsForClassAndAttribute(String className, String attribute) {
    ClassAttributesDestinationsConfig classAttributesDestinationsConfig = (ClassAttributesDestinationsConfig)this._classesAttributesMap.get(className);
    if (classAttributesDestinationsConfig != null)
      return classAttributesDestinationsConfig.getDestinations(attribute);

    return null;
  }

  public Iterator<ClassDestinationsConfig> getAllClassDestinationsConfig()
  {
    Collection destinationsConfigs = getClassesMap().values();
    return destinationsConfigs.iterator();
  }

  public Iterator<ClassAttributesDestinationsConfig> getAllClassAttributesDestinationConfig() {
    return this._classesAttributesMap.values().iterator();
  }

  public ClassAttributesDestinationsConfig getClassAttributeDestinationConfig(String className) {
    return ((ClassAttributesDestinationsConfig)this._classesAttributesMap.get(className));
  }

  public Map<String, ClassDestinationsConfig> getClassesMap() {
    return this._classesMap;
  }

  public boolean isEmpty() {
    return ((getClassesMap().isEmpty()) && (this._classesAttributesMap.isEmpty()));
  }

  private void addClassesAttributesDestinationsConfig(Iterator<ClassAttributesDestinationsConfig> allClassAttributesDestinationConfig) {
    while (allClassAttributesDestinationConfig.hasNext())
      addClassAttributesDestinationsConfig(ClassDestinationsConfigFactory.createClassAttributesDestinationsConfig((ClassAttributesDestinationsConfig)allClassAttributesDestinationConfig.next()));
  }

  private void addClassesDestinationsConfig(Iterator<ClassDestinationsConfig> allClassDestinationsConfig)
  {
    while (allClassDestinationsConfig.hasNext())
      addClassDestinationsConfig(ClassDestinationsConfigFactory.createClassDestinationsConfig((ClassDestinationsConfig)allClassDestinationsConfig.next()));
  }

  public void addClassDestinationsConfig(ClassDestinationsConfig classDestinationsConfig)
  {
    getClassesMap().put(classDestinationsConfig.getClassName(), classDestinationsConfig);
  }

  private void addClassAttributesDestinationsConfig(ClassAttributesDestinationsConfig classAttributesDestinationsConfig) {
    this._classesAttributesMap.put(classAttributesDestinationsConfig.getClassName(), classAttributesDestinationsConfig); }

  public void addDestinationForClass(String className, String destination) {
    ClassDestinationsConfig classDestinationsConfig = (ClassDestinationsConfig)getClassesMap().get(className);
    if (classDestinationsConfig == null) {
      classDestinationsConfig = ClassDestinationsConfigFactory.createClassDestinationsConfig(className);
      getClassesMap().put(className, classDestinationsConfig);
    }
    classDestinationsConfig.addDestination(destination);
  }

  public void addDestinationForClassAndAttribute(String className, String attribute, String destination) {
    ClassAttributesDestinationsConfig classAttributesDestinationsConfig = (ClassAttributesDestinationsConfig)this._classesAttributesMap.get(className);
    if (classAttributesDestinationsConfig == null) {
      classAttributesDestinationsConfig = ClassDestinationsConfigFactory.createClassAttributesDestinationsConfig(className);
      this._classesAttributesMap.put(className, classAttributesDestinationsConfig);
    }
    classAttributesDestinationsConfig.addAttributeDestination(attribute, destination);
  }

  public boolean removeDestinationForClass(String className, String destination)
  {
    ClassDestinationsConfig classDestinationsConfig = (ClassDestinationsConfig)getClassesMap().get(className);
    boolean wasRemoved = false;
    if (classDestinationsConfig != null) {
      wasRemoved = classDestinationsConfig.removeDestination(destination);
      if ((classDestinationsConfig.isEmpty()) || ((classDestinationsConfig.getDestinationsSize() == 1) && (classDestinationsConfig.containsDestination("MERCURY_CMDB"))))
        getClassesMap().remove(className);
    }

    return wasRemoved;
  }

  public boolean removeDestinationForClassAndAttribute(String className, String destination, String attribute) {
    ClassAttributesDestinationsConfig classAttributesDestinationsConfig = (ClassAttributesDestinationsConfig)this._classesAttributesMap.get(className);
    if (classAttributesDestinationsConfig == null)
      return false;

    boolean wasRemoved = classAttributesDestinationsConfig.removeDataStoreForAttributes(destination, new String[] { attribute });
    if (classAttributesDestinationsConfig.isEmpty())
      this._classesAttributesMap.remove(className);

    return wasRemoved;
  }

  public void cleanAll() {
    getClassesMap().clear();
  }

  public void removeDestinationForClassAndAttributes(String className, String destinationId, Collection<String> attributes) {
    ClassAttributesDestinationsConfig classAttributesDestinationsConfig = (ClassAttributesDestinationsConfig)this._classesAttributesMap.get(className);
    if (classAttributesDestinationsConfig != null) {
      classAttributesDestinationsConfig.removeDataStoreForAttributes(destinationId, attributes);
      if (classAttributesDestinationsConfig.isEmpty())
        this._classesAttributesMap.remove(className);
    }
  }

  public void addDestinationForClassAndAttributes(String className, String destId, Collection<String> attributes)
  {
    ClassAttributesDestinationsConfig classAttributesDestinationsConfig = (ClassAttributesDestinationsConfig)this._classesAttributesMap.get(className);
    if (classAttributesDestinationsConfig == null) {
      classAttributesDestinationsConfig = ClassDestinationsConfigFactory.createClassAttributesDestinationsConfig(className);
      this._classesAttributesMap.put(className, classAttributesDestinationsConfig);
    }

    classAttributesDestinationsConfig.addDestinationAttributes(destId, attributes);
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    ModifiableClassModelDestinationsConfigImpl that = (ModifiableClassModelDestinationsConfigImpl)o;

    if (this._classesAttributesMap != null) if (this._classesAttributesMap.equals(that._classesAttributesMap)) break label62; 
    else if (that._classesAttributesMap == null)
        break label62;
    return false;

    if (this._classesMap != null) label62: if (this._classesMap.equals(that._classesMap)) break label95;
    label95: return (that._classesMap == null);
  }

  public int hashCode()
  {
    int result = (this._classesMap != null) ? this._classesMap.hashCode() : 0;
    result = 29 * result + ((this._classesAttributesMap != null) ? this._classesAttributesMap.hashCode() : 0);
    return result;
  }
}