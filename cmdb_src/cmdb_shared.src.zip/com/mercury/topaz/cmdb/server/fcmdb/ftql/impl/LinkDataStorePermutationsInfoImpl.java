package com.mercury.topaz.cmdb.server.fcmdb.ftql.impl;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStorePermutationInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.LinkDataStorePermutationsInfo;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

class LinkDataStorePermutationsInfoImpl
  implements LinkDataStorePermutationsInfo
{
  List<DataStorePermutationInfo> _dataStorePermutationInfos;

  LinkDataStorePermutationsInfoImpl()
  {
    this._dataStorePermutationInfos = new ArrayList();
  }

  public void addDataStorePermutationInfo(DataStorePermutationInfo dataStorePermutationInfo) {
    this._dataStorePermutationInfos.add(dataStorePermutationInfo);
  }

  public void addDataStorePermutationInfo(String end1DataStore, String end2DataStore) {
    addDataStorePermutationInfo(PatternDataStoreInfoFactory.createDataStorePermutationInfo(end1DataStore, end2DataStore)); }

  public Collection<DataStorePermutationInfo> getDataStorePermutationsInfo() {
    return this._dataStorePermutationInfos;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    LinkDataStorePermutationsInfoImpl that = (LinkDataStorePermutationsInfoImpl)o;
    if (this._dataStorePermutationInfos.size() != that._dataStorePermutationInfos.size())
      return false;

    return this._dataStorePermutationInfos.containsAll(that._dataStorePermutationInfos);
  }

  public int hashCode()
  {
    return ((this._dataStorePermutationInfos != null) ? this._dataStorePermutationInfos.hashCode() : 0);
  }
}