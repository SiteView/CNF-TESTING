package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetObjectsLayout;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.types.ExternalCiIdImpl;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.graph.object.impl.ModelObjectsFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.EmptyCmdbObjects;
import com.mercury.topaz.cmdb.shared.model.operation.query.ModelQueryGetObjectsLayoutByIDs;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FTqlCalculationQueryGetObjectsLayoutByIds extends AbstractFTqlCalculationQuery
  implements ModelQueryGetObjectsLayoutByIDs
{
  private ElementSimpleLayout _objectLayout;
  private CmdbObjectIds _ids;
  private CmdbObjects _outgoingObjects;
  private static String RESULT_KEY = "result_key";

  public FTqlCalculationQueryGetObjectsLayoutByIds(CmdbObjectIds ids, ElementSimpleLayout objectLayout)
  {
    setIds(ids);
    setObjectLayout(objectLayout);
  }

  private ElementSimpleLayout getObjectLayout()
  {
    return this._objectLayout;
  }

  private void setObjectLayout(ElementSimpleLayout objectLayout) {
    this._objectLayout = objectLayout;
  }

  private CmdbObjectIds getIds() {
    return this._ids;
  }

  private void setIds(CmdbObjectIds ids) {
    this._ids = ids;
  }

  public String getOperationName() {
    return "FTqlCalculation Query: Get Objects Layout By Ids";
  }

  public void ftqlCalculationgExecuteQuery(FTqlCalculationManager fTqlCalculationManager, CmdbResponse cmdbResponse)
  {
    CmdbObjects resultObjects;
    if ((getIds() == null) || (getIds().size() == 0)) {
      resultObjects = EmptyCmdbObjects.getInstance();
    }
    else {
      Map modelObjectsByDataSourceMap = FtqlUtils.classifyByDataSource(getIds());
      resultObjects = CmdbObjectFactory.createObjects();
      for (Iterator i$ = modelObjectsByDataSourceMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        resultObjects.add(getObjectsLayout(fTqlCalculationManager, (String)entry.getKey(), (CmdbObjectIds)entry.getValue(), getObjectLayout()));
      }
    }
    setResultObjects(resultObjects);
    cmdbResponse.addResult(RESULT_KEY, resultObjects);
  }

  private CmdbObjects getObjectsLayout(FTqlCalculationManager fTqlCalculationManage, String dataStore, CmdbObjectIds objectIds, ElementSimpleLayout layout) throws AdapterAccessException {
    if (!(FtqlUtils.isExternalDataStore(dataStore))) {
      ModelQueryGetObjectsLayoutByIDs modelQueryGetObjectsLayout = ModelQueryFactory.getInternalModelQueryGetObjectsLayoutByIdOperation(layout, objectIds);
      fTqlCalculationManage.executeOperation(modelQueryGetObjectsLayout);
      return modelQueryGetObjectsLayout.getResultObjects();
    }
    ModelObjects modelObjects = ModelObjectsFactory.create();
    for (Iterator i$ = objectIds.iterator(); i$.hasNext(); ) { CmdbObjectID id = (CmdbObjectID)i$.next();
      modelObjects.add((ExternalCiIdImpl)id);
    }
    DataAccessAdapterQueryGetObjectsLayout getObjectsLayout = new DataAccessAdapterQueryGetObjectsLayout(dataStore, layout, modelObjects);
    fTqlCalculationManage.executeOperation(getObjectsLayout);
    return getObjectsLayout.getOutgoingObjects();
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
    setResultObjects((CmdbObjects)response.getResult(RESULT_KEY));
  }

  public CmdbObjects getResultObjects() {
    return this._outgoingObjects;
  }

  private void setResultObjects(CmdbObjects outgoingObjects)
  {
    this._outgoingObjects = outgoingObjects;
  }
}