package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetLinksLayout;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQuerySortLinks;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.util.CalculationUtils;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.model.operation.query.ModelQueryGetLinksLayout;
import com.mercury.topaz.cmdb.server.model.operation.query.ModelQuerySortLinks;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryFactory;
import com.mercury.topaz.cmdb.server.model.operation.query.util.ModelQueryUtil;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.ModelLinksFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FTqlCalculationQuerySortLinks extends AbstractFTqlCalculationQuery
  implements ModelQuerySortLinks
{
  private static final String KEY_RESULT_LINKS = "result_links";
  private CmdbSortCommand _sortCommand;
  private ModelLinks _inputLinks;
  private CmdbLinks _resultCmdbLinks;

  public FTqlCalculationQuerySortLinks(ModelLinks modelLinks, CmdbSortCommand sortCommand)
  {
    setInputLinks(modelLinks);
    setSortCommand(sortCommand);
  }

  public void ftqlCalculationgExecuteQuery(FTqlCalculationManager fTqlCalculationManager, CmdbResponse cmdbResponse)
  {
    validate(fTqlCalculationManager.getSynchronizedClassModel());

    CmdbLinks sortedCmdbLinks = sortLinks(fTqlCalculationManager, getInputLinks(), getSortCommand());
    setResultCmdbLinks(sortedCmdbLinks);
    cmdbResponse.addResult("result_links", sortedCmdbLinks);
  }

  public String getOperationName() {
    return "FTql Calculation Query: Sort Links";
  }

  private CmdbLinks sortLinks(FTqlCalculationManager fTqlCalculationManager, ModelLinks modelLinks, CmdbSortCommand sortCommand) throws AdapterAccessException {
    CmdbLinks sortedLinks;
    ModelLinks virtualLinks = FtqlUtils.getVirtualLinks(modelLinks);

    if (virtualLinks.size() < modelLinks.size()) {
      ModelLinks copiedModelLinks = ModelLinksFactory.createLinks();
      modelLinks.add(modelLinks);
      modelLinks.remove(virtualLinks);
      Map classifiedMap = FtqlUtils.classifyByDataSource(copiedModelLinks);
      if (classifiedMap.size() == 1) {
        String dataStore = (String)classifiedMap.keySet().iterator().next();
        if (!(FtqlUtils.isExternalDataStore(dataStore))) {
          ModelQuerySortLinks modelQuerySortLinks = ModelQueryFactory.getInternalModelQuerySortLinksOperation(getInputLinks(), getSortCommand());
          fTqlCalculationManager.executeOperation(modelQuerySortLinks);
          sortedLinks = modelQuerySortLinks.getResultCmdbLinks();
        }
        else {
          DataAccessAdapterQuerySortLinks sortLinks = new DataAccessAdapterQuerySortLinks(dataStore, getInputLinks(), getSortCommand());
          fTqlCalculationManager.executeOperation(sortLinks);
          sortedLinks = sortLinks.getResultCmdbLinks();
        }
      }
      else {
        sortedLinks = sortLinksInMemory(fTqlCalculationManager, sortCommand, classifiedMap);
      }
    } else {
      sortedLinks = CmdbLinkFactory.createLinks();
    }
    sortedLinks.add(virtualLinks.toCmdbLinks());
    return sortedLinks;
  }

  private CmdbLinks sortLinksInMemory(FTqlCalculationManager fTqlCalculationManager, CmdbSortCommand sortCommand, Map<String, ModelLinks> modelLinksByDataStore)
  {
    ElementSimpleLayout elementSimpleLayout = CalculationUtils.createElementSimpleLayoutFromSortCommand(sortCommand);
    CmdbLinks linksToSort = CmdbLinkFactory.createLinks();
    for (Iterator i$ = modelLinksByDataStore.entrySet().iterator(); i$.hasNext(); ) { CmdbLinks links;
      Map.Entry entry = (Map.Entry)i$.next();
      String dataStore = (String)entry.getKey();

      if (!(FtqlUtils.isExternalDataStore(dataStore))) {
        ModelQueryGetLinksLayout modelQueryGetLinksLayout = ModelQueryFactory.getInternalModelQueryGetLinksLayoutOperation(elementSimpleLayout, (ModelLinks)entry.getValue());
        fTqlCalculationManager.executeOperation(modelQueryGetLinksLayout);
        links = modelQueryGetLinksLayout.getResultLinks();
      }
      else {
        DataAccessAdapterQueryGetLinksLayout getLinksLayout = new DataAccessAdapterQueryGetLinksLayout(dataStore, (ModelLinks)entry.getValue(), elementSimpleLayout);
        fTqlCalculationManager.executeOperation(getLinksLayout);
        links = getLinksLayout.getResultLinks();
      }
      linksToSort.add(links);
    }
    return CalculationUtils.sortCmdbLinks(linksToSort, sortCommand);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    CmdbLinks sortedCmdbLinks = (CmdbLinks)response.getResult("result_links");
    setResultCmdbLinks(sortedCmdbLinks);
  }

  private void validate(CmdbClassModel classModel)
  {
    Set classNames = ModelQueryUtil.extractClassNames(getInputLinks());
    for (Iterator i$ = classNames.iterator(); i$.hasNext(); ) { Object className = i$.next();
      ModelQueryUtil.validateSortCommandByClassName(classModel, (String)className, getSortCommand());
    }
  }

  private CmdbSortCommand getSortCommand()
  {
    return this._sortCommand;
  }

  private void setSortCommand(CmdbSortCommand sortCommand) {
    if (sortCommand == null)
      throw new IllegalArgumentException("sortCommand was null");

    this._sortCommand = sortCommand;
  }

  private ModelLinks getInputLinks() {
    return this._inputLinks;
  }

  private void setInputLinks(ModelLinks inputLinks) {
    if (inputLinks == null)
      throw new IllegalArgumentException("inputLink was null");

    this._inputLinks = inputLinks;
  }

  public CmdbLinks getResultCmdbLinks() {
    return this._resultCmdbLinks;
  }

  private void setResultCmdbLinks(CmdbLinks resultCmdbLinks) {
    if (resultCmdbLinks == null)
      throw new IllegalArgumentException("resultCmdbLinks was null");

    this._resultCmdbLinks = resultCmdbLinks;
  }
}