package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.impl.AbstractDataAccessContainerOperation;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.update.DataAccessContainerUpdate;

public abstract class AbstractDataAccessContainerUpdate extends AbstractDataAccessContainerOperation
  implements DataAccessContainerUpdate
{
}