package com.mercury.topaz.cmdb.server.fcmdb.administration.operation.impl;

import com.mercury.topaz.cmdb.server.fcmdb.administration.manager.FederationAdminManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.fcmdb.administration.operation.FederationAdminOperation;
import com.mercury.topaz.cmdb.shared.fcmdb.operation.impl.AbstractFCmdbOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractFederationAdminOperation extends AbstractFCmdbOperation
  implements FederationAdminOperation
{
  protected void doExecute(SubsystemManager subsystemManager, CmdbResponse cmdbResponse)
    throws CmdbException
  {
    federationAdminExecute((FederationAdminManager)subsystemManager, cmdbResponse);
  }

  public String getExecutionTaskQueueName() {
    return "Federation Admin Task";
  }
}