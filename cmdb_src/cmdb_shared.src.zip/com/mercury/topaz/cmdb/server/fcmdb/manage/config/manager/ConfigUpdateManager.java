package com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager;

import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;

public abstract interface ConfigUpdateManager extends SubsystemManager
{
  public abstract void reloadFederationConfig();

  public abstract void redeployFederationConfig();

  public abstract void updatePersistentFederationConfig(FederationConfig paramFederationConfig);
}