package com.mercury.topaz.cmdb.server.fcmdb.manage.config;

import java.util.Collection;

public abstract interface ClassDestinationsConfig
{
  public abstract String getClassName();

  public abstract Collection<String> getDestinations();

  public abstract int getDestinationsSize();

  public abstract boolean containsDestination(String paramString);

  public abstract boolean isEmpty();

  public abstract void addDestination(String paramString);

  public abstract boolean removeDestination(String paramString);
}