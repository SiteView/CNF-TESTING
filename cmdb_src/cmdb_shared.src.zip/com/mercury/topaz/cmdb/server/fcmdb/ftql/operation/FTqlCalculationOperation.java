package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation;

import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.shared.fcmdb.base.FCmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.CmdbOperation;

public abstract interface FTqlCalculationOperation extends CmdbOperation
{
  public abstract void ftqlCalculationExecute(FTqlCalculationManager paramFTqlCalculationManager, CmdbResponse paramCmdbResponse)
    throws FCmdbException;
}