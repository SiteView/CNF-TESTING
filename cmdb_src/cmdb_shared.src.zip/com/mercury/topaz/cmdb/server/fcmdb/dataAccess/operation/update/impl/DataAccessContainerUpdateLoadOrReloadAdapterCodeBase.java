package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.base.ParameterizedErrorCode;
import com.mercury.topaz.cmdb.shared.base.ParameterizedErrorCode.ErrorCodeProperty;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AdapterConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.exception.FConifgValidationException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.query.impl.ConfigQueryGetAutoSynchronizedConfig;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Collection;

public class DataAccessContainerUpdateLoadOrReloadAdapterCodeBase extends AbstractDataAccessContainerUpdate
{
  protected static Log _log = LogFactory.getEasyLog(DataAccessContainerUpdateLoadOrReloadAdapterCodeBase.class);
  private String _adapterId;

  public DataAccessContainerUpdateLoadOrReloadAdapterCodeBase(String adapterId)
  {
    setAdapterId(adapterId);
  }

  public String getOperationName() {
    return "data access operation: load or reload adapter code base";
  }

  public void dataAccessContainerExecute(DataAccessContainerManager dataAccessContainerManager, CmdbResponse response) throws AdapterAccessException {
    removeAllDestinationForAdapter(dataAccessContainerManager);
  }

  protected Collection<DestinationConfig> removeAllDestinationForAdapter(DataAccessContainerManager dataAccessContainerManager) {
    ConfigQueryGetAutoSynchronizedConfig getAutoSynchronizedConfig = new ConfigQueryGetAutoSynchronizedConfig();
    ServerApiFacade.executeOperation(getAutoSynchronizedConfig);
    FederationConfig federationConfig = getAutoSynchronizedConfig.getFederationConfig();
    validate(federationConfig);
    Collection destinationsRemoved = removeAllAdaptersForAdapterId(dataAccessContainerManager, federationConfig.getDestinationsConfig());
    dataAccessContainerManager.removeAdapterStrategy(getAdapterId());
    return destinationsRemoved;
  }

  private void validate(FederationConfig federationConfig) {
    for (ReadOnlyIterator adapterConfigIterator = federationConfig.getAdaptersConfig(); adapterConfigIterator.hasNext(); ) {
      AdapterConfig adapterConfig = (AdapterConfig)adapterConfigIterator.next();
      if (adapterConfig.getAdapterId().equals(getAdapterId()))
        return;

    }

    ErrorCode errorCode = new ParameterizedErrorCode(ErrorCode.FCONFIG_VALIDATION_ERROR_NO_ADAPTER_FOUND, new ParameterizedErrorCode.ErrorCodeProperty[] { new ParameterizedErrorCode.ErrorCodeProperty("adapterName", getAdapterId()) });

    throw new FConifgValidationException("No adapter id [" + getAdapterId() + "] found!!", errorCode);
  }

  private Collection<DestinationConfig> removeAllAdaptersForAdapterId(DataAccessContainerManager dataAccessContainerManager, ReadOnlyIterator destinations) {
    Collection allAdaptersForAdapterId = new ArrayList();
    while (destinations.hasNext()) {
      DestinationConfig destConfig = (DestinationConfig)destinations.next();
      if (destConfig.getAdapterConfig().getAdapterId().equalsIgnoreCase(getAdapterId())) {
        allAdaptersForAdapterId.add(destConfig);
        try {
          dataAccessContainerManager.removeOrIgnoreDestination(destConfig.getDestinationId());
        } catch (Exception e) {
          _log.error("failed to remove adapter with destination id [" + destConfig.getDestinationId() + "]", e);
        }
      }
    }
    return allAdaptersForAdapterId;
  }

  private String getAdapterId() {
    return this._adapterId;
  }

  private void setAdapterId(String adapterId) {
    if ((adapterId == null) || (adapterId.length() == 0))
      throw new IllegalArgumentException("adapter id is null or empty !!!");

    this._adapterId = adapterId;
  }
}