package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.environment.DataAdapterEnvironment;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;

class BasicDataAdapterWrapperImpl
  implements BasicDataAdapterWrapper
{
  private BasicDataAdapter _basicDataAdapter;
  private ClassLoader _classLoader;
  private String _adapterId;
  private DataAdapterEnvironment _dataAdapterEnvironment;

  public BasicDataAdapterWrapperImpl(String adapterId, BasicDataAdapter basicDataAdapter, ClassLoader classLoader, DataAdapterEnvironment dataAdapterEnvironment)
  {
    setBasicDataAdapter(basicDataAdapter);
    setClassLoader(classLoader);
    setAdapterId(adapterId);
    setDataAdapterEnvironment(dataAdapterEnvironment);
  }

  private void setDataAdapterEnvironment(DataAdapterEnvironment dataAdapterEnvironment) {
    this._dataAdapterEnvironment = dataAdapterEnvironment;
  }

  public String getAdapterId() {
    return this._adapterId;
  }

  public DataAdapterEnvironment getDataAdapterEnvironment() {
    return this._dataAdapterEnvironment;
  }

  private void setAdapterId(String adapterId) {
    this._adapterId = adapterId;
  }

  public BasicDataAdapter getBasicDataAdapter() {
    return this._basicDataAdapter;
  }

  public ClassLoader getAdapterClassLoader() {
    return this._classLoader;
  }

  private void setBasicDataAdapter(BasicDataAdapter basicDataAdapter) {
    if (basicDataAdapter == null)
      throw new IllegalArgumentException("adapter is null !!!");

    this._basicDataAdapter = basicDataAdapter;
  }

  private void setClassLoader(ClassLoader classLoader)
  {
    if (classLoader == null)
      throw new IllegalArgumentException("class loader !!!");

    this._classLoader = classLoader;
  }
}