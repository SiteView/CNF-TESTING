package com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.fcmdb.base.log.FCmdbLogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ModifiableClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao.FederationConfigDAO;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao.impl.FederationConfigDAOFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl.ClassDestinationsConfigFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.load.FederationConfigurationLoader;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.load.impl.FederationConfigurationLoaderFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl.ConfigUpdateCacheSetFederationConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.util.ConfigUtil;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.FederationConfigDef;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.exception.FConfigException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.impl.ConfigFactory;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.impl.FederationConfigBuilder;

public class ConfigUpdateManagerImpl extends CmdbSubsystemManagerImpl
  implements ConfigUpdateManager, SingleReadSingleWrite
{
  private FederationConfigDAO _federationConfigDAO;

  public ConfigUpdateManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public void startUp() {
    FederationConfigDAO federationConfigDAO = FederationConfigDAOFactory.createFederationConfigDAO(this);
    federationConfigDAO.startUp();
    setFederationConfigDAO(federationConfigDAO);
    FederationConfig federationConfig = getFederationConfigFromDAO();
    if (federationConfig == null)
      federationConfig = deployFederationConfig();

    updateFederationConfigCache(federationConfig);
    reloadClassesDestinationsConfig(federationConfig);
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Federation Configuration Update Manager is started up successfully");
  }

  private ClassModelDestinationsConfig createClassesDestinationsConfig(FederationConfig federationConfig) {
    ModifiableClassModelDestinationsConfig modifiableClassesDestinationsConfig = ClassDestinationsConfigFactory.createModifiableClassesDestinationsConfig();
    if ((federationConfig != null) && (federationConfig.getDestinationsConfigSize() > 0))
      ConfigUtil.updateClassModelDestinationsConfig(modifiableClassesDestinationsConfig, null, federationConfig);

    return ClassDestinationsConfigFactory.createReadOnlyClassesDestinationsConfig(modifiableClassesDestinationsConfig);
  }

  public void shutdown()
  {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Federation Configuration Update Manager is shutdown");
  }

  private void updateFederationConfigCache(FederationConfig federationConfig)
  {
    ConfigUpdateCacheSetFederationConfig configSetFederationConfig = new ConfigUpdateCacheSetFederationConfig(federationConfig);
    executeOperation(configSetFederationConfig);
  }

  public void reloadFederationConfig()
  {
    FederationConfig federationConfig = getFederationConfigFromDAO();
    updateFederationConfigCache(federationConfig);
    reloadClassesDestinationsConfig(federationConfig);
    FCmdbLogFactory.getFcmdbLifecycleLog().info("federation configuration was reloaded from DAO");
  }

  public void updatePersistentFederationConfig(FederationConfig federationConfig)
  {
    getFederationConfigDAO().saveFederationConfig(federationConfig);
    updateFederationConfigCache(federationConfig);
  }

  public void redeployFederationConfig() {
    FederationConfig federationConfig = deployFederationConfig();
    updateFederationConfigCache(federationConfig);
  }

  private FederationConfig deployFederationConfig() {
    try {
      FCmdbLogFactory.getFcmdbLifecycleLog().info("start deploying federation configuration");
      FederationConfigurationLoader loader = FederationConfigurationLoaderFactory.createFederationConfigurationLoader();
      FederationConfigDef federationConfigDef = loader.loadFederationConfigDef();
      FederationConfig federationConfig = FederationConfigBuilder.buildFederationConfig(federationConfigDef);
      getFederationConfigDAO().saveFederationConfig(federationConfig);
      FCmdbLogFactory.getFcmdbLifecycleLog().info("finish deploying configuration definition.\nDeployed configuration [" + federationConfig + "]");
      return federationConfig;
    } catch (FConfigException e) {
      FCmdbLogFactory.getFcmdbLifecycleLog().info("failed to deploy configuration", e); }
    return ConfigFactory.createModifiableFederationConfig();
  }

  private FederationConfig getFederationConfigFromDAO()
  {
    return getFederationConfigDAO().getFederationConfig();
  }

  private FederationConfigDAO getFederationConfigDAO()
  {
    return this._federationConfigDAO;
  }

  private void setFederationConfigDAO(FederationConfigDAO federationConfigDAO) {
    if (federationConfigDAO == null)
      throw new IllegalArgumentException("federation config dao is null !!!");

    this._federationConfigDAO = federationConfigDAO;
  }

  public void reloadClassesDestinationsConfig(FederationConfig federationConfig) {
    ClassModelDestinationsConfig classModelDestinationsConfig = createClassesDestinationsConfig(federationConfig);
    ConfigUtil.updateClassModelDestinationsConfigCache(classModelDestinationsConfig);
    FCmdbLogFactory.getFcmdbLifecycleLog().info("Class Destinations was reloaded");
  }

  public String getName()
  {
    return "Federation Config Update Task";
  }
}