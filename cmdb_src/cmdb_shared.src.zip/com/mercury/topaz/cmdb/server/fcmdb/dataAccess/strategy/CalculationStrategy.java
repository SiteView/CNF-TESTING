package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy;

import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.VirtualLinkInfo;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyResult;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyQueryDefinition;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.tql.definition.layout.handler.function.LayoutFunctionWrappers;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;

public abstract interface CalculationStrategy
{
  public abstract ExternalTopologyResult calculateTopology(FTqlDataAdapter paramFTqlDataAdapter, TopologyQueryDefinition paramTopologyQueryDefinition, ReconciliationData paramReconciliationData, String paramString, VirtualLinkInfo paramVirtualLinkInfo)
    throws DataAccessException;

  public abstract CmdbObjects getFunctionsLayout(FTqlDataAdapter paramFTqlDataAdapter, ModelObjects paramModelObjects1, ModelLinks paramModelLinks, ModelObjects paramModelObjects2, LayoutFunctionWrappers paramLayoutFunctionWrappers, String paramString)
    throws AdapterAccessException, DataAccessException;

  public abstract CmdbObjects getObjectsLayout(FTqlDataAdapter paramFTqlDataAdapter, ModelObjects paramModelObjects, ElementSimpleLayout paramElementSimpleLayout, String paramString)
    throws AdapterAccessException;

  public abstract CmdbLinks getLinksLayout(FTqlDataAdapter paramFTqlDataAdapter, ModelLinks paramModelLinks, ElementSimpleLayout paramElementSimpleLayout, String paramString)
    throws AdapterAccessException;
}