package com.mercury.topaz.cmdb.server.fcmdb.manage.config.load.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.fcmdb.base.log.FCmdbLogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.load.FederationConfigurationLoader;
import java.io.File;

public class FederationConfigurationLoaderFactory
{
  public static FederationConfigurationLoader createFederationConfigurationLoader()
  {
    String fullFileName = getRootFederationConfigFolder() + File.separator + "config" + File.separator + "fconfig.xml";
    FCmdbLogFactory.getFcmdbLifecycleLog().info("Create xml load configuration  from file " + fullFileName);
    return new XmlFileFederationLoaderImpl(fullFileName); }

  public static String getRootFederationConfigFolder() {
    return System.getProperty("topaz.home") + File.separator + "fcmdb";
  }
}