package com.mercury.topaz.cmdb.server.fcmdb.administration.operation.command.impl;

import com.mercury.topaz.cmdb.server.fcmdb.administration.manager.FederationAdminManager;
import com.mercury.topaz.cmdb.server.fcmdb.administration.util.ConfigChangesUtil;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClassDefinition;
import com.mercury.topaz.cmdb.shared.fcmdb.administration.operation.command.impl.AbstractAdministrationCommand;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class AdministrationCommandReloadClassesCapabilitiesForClass extends AbstractAdministrationCommand
{
  private CmdbClassDefinition _classDefinition;

  public AdministrationCommandReloadClassesCapabilitiesForClass(CmdbClassDefinition classDefinition)
  {
    this._classDefinition = classDefinition;
  }

  public String getOperationName()
  {
    return "Config Update Reload Config For Class";
  }

  public void federationAdminExecute(FederationAdminManager federationAdminManager, CmdbResponse response) throws AdapterAccessException {
    ClassModelDestinationsConfig classModelDestinationsConfig = ConfigChangesUtil.getClassesDestinationConfig();
    if (FtqlUtils.isFederatedClass(this._classDefinition.getName(), classModelDestinationsConfig))
      ConfigChangesUtil.reloadClassesCapabilities(federationAdminManager, classModelDestinationsConfig);
  }
}