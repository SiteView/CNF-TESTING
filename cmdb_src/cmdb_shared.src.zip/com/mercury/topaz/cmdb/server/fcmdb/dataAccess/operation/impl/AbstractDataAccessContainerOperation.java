package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.DataAccessContainerOperation;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.fcmdb.operation.impl.AbstractFCmdbOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractDataAccessContainerOperation extends AbstractFCmdbOperation
  implements DataAccessContainerOperation
{
  public final String getExecutionTaskQueueName()
  {
    return "Data Access Container Task";
  }

  protected void doExecute(SubsystemManager manager, CmdbResponse response) throws CmdbException {
    dataAccessContainerExecute((DataAccessContainerManager)manager, response);
  }
}