package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.mappingEngine.MappingEngine;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.ResultStrategy;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.definition.AdapterConfigDef;

public abstract interface DataAccessContainerManager extends CmdbSubsystemManager
{
  public static final String NAME = "Data Access Container Task";

  public abstract BasicDataAdapterWrapper createAdapterWrapper(DestinationConfig paramDestinationConfig);

  public abstract BasicDataAdapterWrapper getStartedBasicDataAdapterWrapper(String paramString);

  public abstract BasicDataAdapterWrapper getStartedBasicDataAdapterWrapper(DestinationConfig paramDestinationConfig);

  public abstract BasicDataAdapterWrapper removeOrIgnoreDestination(String paramString)
    throws AdapterAccessException;

  public abstract void removeAdapterStrategy(String paramString);

  public abstract CalculationStrategy getCalculationStrategy(String paramString);

  public abstract ResultStrategy getResultStrategy(String paramString);

  public abstract MappingEngine obtainMappingEngine(String paramString1, String paramString2, String paramString3)
    throws AdapterAccessException;

  public abstract BasicDataAdapter getBasicDataAdapter(AdapterConfigDef paramAdapterConfigDef);

  public abstract MappingEngine obtainMappingEngine(String paramString, DestinationConfig paramDestinationConfig);
}