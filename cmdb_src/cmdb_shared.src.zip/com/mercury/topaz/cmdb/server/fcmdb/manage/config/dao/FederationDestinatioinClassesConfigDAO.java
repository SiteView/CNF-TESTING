package com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao;

import java.util.Collection;

public abstract interface FederationDestinatioinClassesConfigDAO
{
  public abstract Collection<String> getAllDestinatioinsForClass(String paramString);
}