package com.mercury.topaz.cmdb.server.fcmdb.administration.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.administration.operation.impl.AbstractFederationAdminOperation;
import com.mercury.topaz.cmdb.server.fcmdb.administration.operation.update.FederationAdminUpdate;

public abstract class AbstractFederationAdminUpdate extends AbstractFederationAdminOperation
  implements FederationAdminUpdate
{
}