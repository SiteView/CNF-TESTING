package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query.impl;

import com.hp.ucmdb.federationspi.data.query.topology.QueryDefinition;
import com.hp.ucmdb.federationspi.data.query.topology.QueryNode;
import com.hp.ucmdb.federationspi.data.query.topology.Topology;
import com.hp.ucmdb.federationspi.data.query.types.TopologyCI;
import com.hp.ucmdb.federationspi.data.replication.ReplicationLayoutResultActionData;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetSupportedClassConfigs;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryRetrieveByPatternFromChangesSource;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryRetrieveLayoutFromChangesSource;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.TopologiesMerger;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.load.impl.FederationConfigurationLoaderFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.query.impl.ConfigQueryGetDestinationConfig;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.topology.QueryDefinitionImpl;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter.ElementNumberConverter;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter.RandomElementNumberConverter;
import com.mercury.topaz.cmdb.server.model.operation.query.ModelQueryMergeObjectLayout;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.common.expression.ExpressionElement;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalOperator;
import com.mercury.topaz.cmdb.shared.manage.CmdbContextRepository;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.operation.query.impl.ModelQueryGetObjectsLayoutByIDsImpl;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.LinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ConditionOperator;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCardinality;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.PropertyCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.ConditionUtils;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.DefaultLinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.CmdbPatternIDFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetPattern;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.chunk.ChunkRequest;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultMapUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.pair.Pair;
import com.mercury.topaz.cmdb.shared.util.pair.impl.PairImpl;
import java.io.File;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class FtqlCalculationQueryMergeObjectLayoutById extends AbstractFTqlCalculationQuery
  implements ModelQueryMergeObjectLayout
{
  private String id;
  private Topology topology;
  private QueryDefinitionImpl query;
  private transient FTqlCalculationManager fTqlCalculationManager;
  private static String TOPOLOGY = "topology";
  private static String QUERY = "query";
  private static final String DEVICE_ID = "device_id";
  private static Log log = LogFactory.getEasyLog(FtqlCalculationQueryMergeObjectLayoutById.class);
  private static final String BAC_FOLDER_CLASS = "bac_folder";
  private static final String PATTERNS_FOLDER = "SM Query";
  private static final String BAC_CONTAINS_CLASS = "bac_contains";
  private static final String TQL_CLASS = "PatternImpl";
  private static final String PATTERN_NAME_ATTR = "pattern_name";
  private static final String ADAPTERS_CONFIG_FILE = FederationConfigurationLoaderFactory.getRootFederationConfigFolder() + "/CodeBase/ServiceDeskAdapter/webserviceAdapters.xml";

  public FtqlCalculationQueryMergeObjectLayoutById(String id)
  {
    this.id = id;
  }

  public Topology getTopology() {
    return this.topology;
  }

  public void setTopology(Topology topology) {
    this.topology = topology;
  }

  public QueryDefinitionImpl getQuery() {
    return this.query;
  }

  public void setQuery(QueryDefinitionImpl query) {
    this.query = query;
  }

  public String getOperationName() {
    return "FTql Calculation Query: Merge Object Layout by ID";
  }

  public void ftqlCalculationgExecuteQuery(FTqlCalculationManager fTqlCalculationManager, CmdbResponse cmdbResponse) {
    this.fTqlCalculationManager = fTqlCalculationManager;

    CmdbObjectID cmdbID = CmdbObjectID.Factory.restoreObjectID(this.id);
    CmdbObjectIds singleIdCollection = CmdbObjectIdsFactory.createSingleIdCollection(cmdbID);
    ModelQueryGetObjectsLayoutByIDsImpl getObjectOp = new ModelQueryGetObjectsLayoutByIDsImpl(singleIdCollection, PatternLayoutFactory.createElementSimpleLayout());

    invokeOperation(getObjectOp);

    if (!(getObjectOp.getResultObjects().contains(cmdbID)))
      throw new RuntimeException("Object with id: " + this.id + " does not exist in UCMDB");

    CmdbObject cmdbObject = (CmdbObject)getObjectOp.getResultObjects().get(cmdbID);

    CmdbClassModel classModel = classModel();
    Pair pair = findQuery(cmdbObject, classModel);
    Pattern pattern = (Pattern)pair.getFirst();
    PatternNode rootNode = (PatternNode)pair.getSecond();
    this.query = ((QueryDefinitionImpl)AdapterFPIConverter.convertPatternToQueryDefinition(pattern));
    String rootName = String.valueOf(rootNode.getElementNumber().getNumber());
    this.query.addRootName(rootName);

    Pattern patternWithID = addIdsToPattern(pattern, rootNode.getElementNumber(), singleIdCollection);
    QueryDefinition queryWithID = AdapterFPIConverter.convertPatternToQueryDefinition(patternWithID);
    this.topology = queryCmdb(queryWithID, patternWithID);
    if (this.topology.isEmpty()) {
      throw new RuntimeException("Object found id:" + this.id + ", type: " + cmdbObject.getType() + ", but tql: " + this.query.getName() + " returned no results");
    }

    Object deviceID = null;
    String deviceNodeName = null;
    for (Iterator i$ = queryWithID.getNodes().iterator(); i$.hasNext(); ) { QueryNode queryNode = (QueryNode)i$.next();
      if (classModel.isTypeOf("sm_device", queryNode.getType())) {
        ElementPropertiesCondition equalsCondition;
        Pattern targetPattern;
        if (!(queryNode.getProperties().contains("device_id")))
          log.error("Query layout does not have device_id. Query Name: " + this.query.getName() + " Node type: " + queryNode.getType());

        Collection smCis = this.topology.getCIsByName(queryNode.getName());
        if (!(smCis.isEmpty())) {
          TopologyCI smCi = (TopologyCI)smCis.iterator().next();
          CmdbProperty property = (CmdbProperty)smCi.getPropertyObject("device_id");
          if ((property != null) && (!(property.isValueEmpty()))) {
            deviceID = property.getValue();
            deviceNodeName = queryNode.getName();
            break;
          }
        }
      }
    }
    if (log.isDebugEnabled()) {
      log.debug("query: " + this.query.getName() + ", device ID: " + deviceID + ", device node: " + deviceNodeName);
    }

    if (deviceID != null)
    {
      equalsCondition = createEqualsCondition("device_id", deviceID);
      targetPattern = createPatternsWithPropertyCondition(pattern, equalsCondition, deviceNodeName);
      targetPattern = changeCardinality(targetPattern, deviceNodeName, rootNode);
      this.topology = targetAdapterTopology(targetPattern, rootName, cmdbObject.getType());
    }
    cmdbResponse.addResult(TOPOLOGY, this.topology);
    cmdbResponse.addResult(QUERY, this.query);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setTopology((Topology)response.getResult(TOPOLOGY));
    setQuery((QueryDefinitionImpl)response.getResult(QUERY));
  }

  private Topology targetAdapterTopology(Pattern pattern, String rootName, String type) {
    Map adapters = findTargetAdapter();
    if (log.isDebugEnabled())
      log.debug("Trying to fetch topology from the following list of adapters: " + adapters);

    for (Iterator i$ = adapters.keySet().iterator(); i$.hasNext(); ) { String targetID = (String)i$.next();

      pattern = removeUnsupportedClasses(pattern, targetID, type);
      QueryDefinition targetQuery = AdapterFPIConverter.convertPatternToQueryDefinition(pattern);

      DataAccessAdapterQueryRetrieveByPatternFromChangesSource targetTopologyOp = new DataAccessAdapterQueryRetrieveByPatternFromChangesSource(targetID, targetQuery);

      invokeOperation(targetTopologyOp);
      DataAccessAdapterQueryRetrieveLayoutFromChangesSource targetLayoutOp = new DataAccessAdapterQueryRetrieveLayoutFromChangesSource(targetID, targetQuery, targetTopologyOp.getResult());

      invokeOperation(targetLayoutOp);
      Topology ret = (Topology)targetLayoutOp.getResult().getTopologyForAdd();
      if (log.isDebugEnabled())
        log.debug("Result from target adapter: " + targetID + ", topology=" + ret);

      if (ret.getCIsByName(rootName).size() == 1) {
        TopologiesMerger merger = new TopologiesMerger();
        merger.first(ret).second(this.topology).query(this.query).rootName(rootName).id(this.id);
        if (!(((Boolean)adapters.get(targetID)).booleanValue()))
          merger.invert();

        return merger.merge();
      }
    }
    log.debug("None of the adapters returned topology");
    return this.topology;
  }

  private Map<String, Boolean> findTargetAdapter() {
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    try {
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document doc = documentBuilder.parse(new File(ADAPTERS_CONFIG_FILE));
      XPath xpath = XPathFactory.newInstance().newXPath();
      NodeList nodeList = (NodeList)xpath.evaluate("/adapters/adapter", doc, XPathConstants.NODESET);
      if (nodeList.getLength() == 0) throw new RuntimeException("No adapters elements were found in file");
      Map ret = new HashMap();
      for (int i = 0; i < nodeList.getLength(); ++i) {
        Element ele = (Element)nodeList.item(i);
        String ownerAttr = ele.getAttribute("owner");
        boolean owner = true;
        if ((ownerAttr != null) && (ownerAttr.equals("no")))
          owner = false;

        ret.put(ele.getAttribute("name"), Boolean.valueOf(owner));
      }
      return ret;
    } catch (Exception e) {
      log.error("Failed to read adapters configuration: " + ADAPTERS_CONFIG_FILE, e); }
    return Collections.emptyMap();
  }

  private CmdbClassModel classModel()
  {
    return this.fTqlCalculationManager.getSynchronizedClassModel();
  }

  private Topology queryCmdb(QueryDefinition query, Pattern queryPattern) {
    AdapterFPIConverter.ElementNumberConverter elementNumberConversionMap = new AdapterFPIConverter.RandomElementNumberConverter(query);
    PatternLayout layout = queryPattern.getLayout();
    TqlQueryGetAdHocMap tqlQueryGetAdHocMap = new TqlQueryGetAdHocMap(queryPattern, layout);
    TqlResultMap tqlResult = getTqlResultMap(tqlQueryGetAdHocMap);
    return AdapterFPIConverter.convertTqlResultMapToTopology(tqlResult, query, elementNumberConversionMap);
  }

  private Pair<Pattern, PatternNode> findQuery(CmdbObject cmdbObject, CmdbClassModel classModel)
  {
    Pair foundPattern = null;
    Collection tqlNames = allTqlNames();
    for (Iterator i$ = tqlNames.iterator(); i$.hasNext(); ) { String tqlName = (String)i$.next();
      CmdbPatternID patternID = CmdbPatternIDFactory.createObjectID(tqlName);
      TqlQueryGetPattern getPattern = new TqlQueryGetPattern(patternID);
      invokeOperation(getPattern);

      Pattern pattern = getPattern.getPattern();
      ReadOnlyIterator nodesIterator = pattern.getPatternGraph().getNodesIterator();

      while (nodesIterator.hasNext()) {
        PatternNode patternNode = (PatternNode)nodesIterator.next();
        String className = patternNode.getCondition().getClassCondition().getClassName();

        if ((classModel.isTypeOf(className, cmdbObject.getType())) && (checkRootClassCondition(patternNode, cmdbObject.getType()))) {
          if (foundPattern != null)
            throw new RuntimeException("found two patterns that match the CI " + cmdbObject + ". Patterns: " + ((Pattern)foundPattern.getFirst()).getName() + ", " + pattern.getName());

          foundPattern = new PairImpl(pattern, patternNode);
        }
      }
    }
    if (foundPattern == null)
      throw new RuntimeException("no suitable TQL found for: " + cmdbObject);

    return foundPattern;
  }

  private boolean checkRootClassCondition(PatternNode patternNode, String type)
  {
    if (patternNode.getCondition().hasPropertiesCondition()) {
      ReadOnlyIterator conditionIterator = patternNode.getCondition().getPropertiesCondition().getIterator();
      while (conditionIterator.hasNext()) {
        PropertyCondition property = (PropertyCondition)conditionIterator.next();
        if ((property.getPropertyName().equals("root_class")) && (property.getOperator().equals(ConditionOperator.IN))) {
          CmdbPropertyValues values = (CmdbPropertyValues)property.getPropertyValue();
          ReadOnlyIterator valuesIterator = values.valuesIterator();
          do if (!(valuesIterator.hasNext())) break label132;
          while (!(type.equalsIgnoreCase((String)valuesIterator.next())));
          return true;

          label132: return false;
        }
      }
    }
    return true;
  }

  private Collection<String> allTqlNames()
  {
    PatternElementNumber folderNum = PatternElementNumberFactory.createElementNumber(1);
    PatternElementNumber linkNum = PatternElementNumberFactory.createElementNumber(2);
    PatternElementNumber tqlNum = PatternElementNumberFactory.createElementNumber(3);

    ElementClassCondition folderClassCond = PatternConditionFactory.createElementClassCondition("bac_folder", true);
    ElementClassCondition linkClassCond = PatternConditionFactory.createElementClassCondition("bac_contains", true);
    ElementClassCondition tqlClassCond = PatternConditionFactory.createElementClassCondition("PatternImpl", true);

    PropertyCondition folderNameCond = PatternConditionFactory.createPropertyCondition("name", ConditionOperator.EQUEL, "SM Query", false);
    PropertyCondition folderContextCond = PatternConditionFactory.createPropertyCondition("context", ConditionOperator.EQUEL, "TQL", false);
    ModifiableElementPropertiesCondition folderPropsCond = PatternConditionFactory.createElementPropertiesCondition();
    folderPropsCond.addPropertyCondition(folderNameCond);
    folderPropsCond.addLogicalOperator(LogicalOperator.AND);
    folderPropsCond.addPropertyCondition(folderContextCond);

    ElementCondition linkCond = PatternConditionFactory.createElementCondition(linkClassCond);
    ElementCondition folderCond = PatternConditionFactory.createElementCondition(folderClassCond, folderPropsCond);
    ElementCondition tqlCond = PatternConditionFactory.createElementCondition(tqlClassCond);

    ModifiableNodeLinksCondition folderLinkCond = PatternConditionFactory.createNodeLinksCondition();
    LinkCardinality linkCardinality = PatternConditionFactory.createLinkCardinality(linkNum.getNumber(), 1, -1);
    folderLinkCond.addLinkCardinality(linkCardinality);

    PatternNode folderPatternNode = PatternGraphFactory.createPatternNode(folderNum, folderCond, false, folderLinkCond);
    PatternLink linkPatternLink = PatternGraphFactory.createPatternLink(linkNum, folderNum, tqlNum, linkCond, false);
    PatternNode tqlPatternNode = PatternGraphFactory.createPatternNode(tqlNum, tqlCond, true, folderLinkCond);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(folderPatternNode);
    patternGraph.addNode(tqlPatternNode);
    patternGraph.addLink(linkPatternLink);

    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("Find SM Web Service TQLs", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);
    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    elementSimpleLayout.addKey("pattern_name");
    patternLayout.setElementLayout(tqlNum, elementSimpleLayout);

    TqlQueryGetAdHocMap adHocMap = new TqlQueryGetAdHocMap(pattern, patternLayout);
    TqlResultMap tqlResultMap = getTqlResultMap(adHocMap);
    if (!(tqlResultMap.containsElementNumber(tqlNum))) return Collections.emptySet();
    CmdbObjects objects = tqlResultMap.getObjects(tqlNum);
    Set ret = new HashSet();
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { CmdbObject cmdbObject = (CmdbObject)i$.next();
      CmdbProperty property = cmdbObject.getProperty("pattern_name");
      ret.add(property.getType().stringValue(property.getValue()));
    }

    return ret;
  }

  private void invokeOperation(FrameworkOperation operation) {
    this.fTqlCalculationManager.executeOperation(operation);
  }

  private Pattern addIdsToPattern(Pattern pattern, PatternElementNumber rootNumber, CmdbObjectIds ids)
  {
    PatternGraph receivedPatternGraph = pattern.getPatternGraph();
    ModifiablePatternGraph newGraph = receivedPatternGraph.toModifiableGraph();
    ModifiablePatternNode node = newGraph.getModifiableNode(rootNumber);
    ElementCondition condition = node.getCondition();
    node.setCondition(PatternConditionFactory.createElementCondition(condition.getClassCondition(), condition.getPropertiesCondition(), ids));
    ModifiablePattern newPattern = PatternDefinitionFactory.createPattern(pattern.getName(), PatternGroupId.PATTERN_GROUP_ALL, newGraph);
    newPattern.setDefaultLayout(pattern.getLayout());
    return newPattern;
  }

  protected TqlResultMap getTqlResultMap(TqlQueryGetAdHocMap adHocMap) {
    TqlResultMap resultMap;
    invokeOperation(adHocMap);

    if (adHocMap.isDividedToChunks())
      resultMap = getResultMapInChunks(adHocMap.getChunkRequest());
    else
      resultMap = getResult(adHocMap);

    return resultMap;
  }

  protected TqlResultMap getResult(TqlQueryGetAdHocMap adHocMap) {
    return adHocMap.getResultMap();
  }

  protected TqlResultMap getResultMapInChunks(ChunkRequest chunkRequest) {
    LinksDictionary linkDictionary = DefaultLinksDictionary.getInstance();
    return TqlResultMapUtils.getResultInChunks(chunkRequest, linkDictionary, CmdbApiFactory.createCMDBAPI(), CmdbContextRepository.get(), true);
  }

  private Pattern createPatternsWithPropertyCondition(Pattern pattern, ElementPropertiesCondition propertiesCondition, String nodeName) {
    if ((pattern == null) || (nodeName == null))
      return pattern;

    PatternGraph receivedPatternGraph = pattern.getPatternGraph();
    ModifiablePatternGraph newGraph = receivedPatternGraph.toModifiableGraph();
    PatternElementNumber rootNumber = PatternElementNumberFactory.createElementNumber(Integer.valueOf(nodeName).intValue());
    ModifiablePatternNode node = newGraph.getModifiableNode(rootNumber);
    ElementCondition condition = node.getCondition();
    ElementPropertiesCondition newCondition = ConditionUtils.mergePropertiesCondition(condition.getPropertiesCondition(), LogicalOperator.AND, propertiesCondition);
    if (condition.hasIdsCondition())
      node.setCondition(PatternConditionFactory.createElementConditionWithIdsCondition(condition.getClassCondition(), newCondition, condition.getIdsCondition()));
    else
      node.setCondition(PatternConditionFactory.createElementCondition(condition.getClassCondition(), newCondition));

    ModifiablePattern newPattern = PatternDefinitionFactory.createPattern(pattern.getName(), PatternGroupId.PATTERN_GROUP_ALL, newGraph);
    newPattern.setDefaultLayout(pattern.getLayout());
    return newPattern;
  }

  private ElementPropertiesCondition createEqualsCondition(String attribute, Object value)
  {
    PropertyCondition dateCondition = PatternConditionFactory.createPropertyCondition(attribute, ConditionOperator.EQUEL, value, false);
    ModifiableElementPropertiesCondition datePropertiesCondition = PatternConditionFactory.createElementPropertiesCondition();
    datePropertiesCondition.addPropertyCondition(dateCondition);
    return datePropertiesCondition;
  }

  private Pattern changeCardinality(Pattern pattern, String deviceNode, PatternNode rootNode) {
    PatternGraph receivedPatternGraph = pattern.getPatternGraph();
    ModifiablePatternGraph newGraph = receivedPatternGraph.toModifiableGraph();
    ModifiablePatternNode node = newGraph.getModifiableNode(rootNode.getElementNumber());
    ModifiableNodeLinksCondition oldLinksCondition = node.getModifiableLinksCondition();
    if (oldLinksCondition == null) return null;
    ModifiableNodeLinksCondition newLinksCondition = PatternConditionFactory.createNodeLinksCondition();
    ReadOnlyIterator iterator = oldLinksCondition.getIterator();
    boolean first = true;
    while (true) { ExpressionElement curExpressionElement;
      while (true) { do { if (!(iterator.hasNext())) break label218;
          curExpressionElement = (ExpressionElement)iterator.next(); }
        while (curExpressionElement.isSubExpression()); if (!(curExpressionElement.isOperator()))
          break;
      }
      if (!(first))
        newLinksCondition.addLogicalOperator(LogicalOperator.AND);

      first = false;

      LinkCardinality linkCardinality = (LinkCardinality)curExpressionElement;
      PatternElementNumber end2Number = receivedPatternGraph.getLink(linkCardinality.getLinkElementId()).getEnd2Number();

      if (String.valueOf(end2Number.getNumber()).equals(deviceNode))
        newLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(linkCardinality.getLinkElementId().getNumber(), 1, linkCardinality.getTopLimit()));
      else
        newLinksCondition.addLinkCardinality(linkCardinality);
    }

    if (first) label218: return null;
    node.setLinksCondition(newLinksCondition);
    ModifiablePattern newPattern = PatternDefinitionFactory.createPattern(pattern.getName(), PatternGroupId.PATTERN_GROUP_ALL, newGraph);
    newPattern.setDefaultLayout(pattern.getLayout());
    return newPattern;
  }

  private Pattern removeUnsupportedClasses(Pattern pattern, String targetID, String rootType)
  {
    CmdbClassModel classModel = classModel();
    ConfigQueryGetDestinationConfig getConfig = new ConfigQueryGetDestinationConfig(targetID);
    invokeOperation(getConfig);
    if (getConfig.getDestinationConfig() == null) {
      throw new RuntimeException("Data source: " + targetID + " does not exist. Please check that the file: " + "<CMDB_DIR>/fcmdb/CodeBase/ServiceDeskAdapter/webserviceAdapters.xml contains the correct data source name");
    }

    DataAccessAdapterQueryGetSupportedClassConfigs getSupported = new DataAccessAdapterQueryGetSupportedClassConfigs(getConfig.getDestinationConfig());

    invokeOperation(getSupported);
    Set supportedClasses = getSupported.getSupportedClassesConfig().keySet();

    PatternGraph receivedPatternGraph = pattern.getPatternGraph();
    ModifiablePatternGraph newGraph = receivedPatternGraph.toModifiableGraph();
    ReadOnlyIterator elementNumbersIterator = receivedPatternGraph.getNodesIterator();
    while (elementNumbersIterator.hasNext()) {
      PatternNode node = (PatternNode)elementNumbersIterator.next();
      String nodeType = node.getCondition().getClassCondition().getClassName();

      if ((!(supportedClasses.contains(nodeType))) && (!(classModel.isTypeOf(nodeType, rootType))))
        newGraph.removeNode(node.getElementNumber());
    }

    ModifiablePattern newPattern = PatternDefinitionFactory.createPattern(pattern.getName(), PatternGroupId.PATTERN_GROUP_ALL, newGraph);
    newPattern.setDefaultLayout(pattern.getLayout());
    return newPattern;
  }
}