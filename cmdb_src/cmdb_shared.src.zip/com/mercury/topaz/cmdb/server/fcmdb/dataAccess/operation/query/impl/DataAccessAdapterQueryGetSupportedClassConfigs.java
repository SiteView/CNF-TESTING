package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.environment.DataAdapterEnvironment;
import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.util.DataAdapterEnvironmentUtil;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter;
import com.mercury.topaz.cmdb.server.fcmdb.util.FClassModelUtil;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.base.ParameterizedErrorCode;
import com.mercury.topaz.cmdb.shared.base.ParameterizedErrorCode.ErrorCodeProperty;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.util.tree.ClassTreeNode;
import com.mercury.topaz.cmdb.shared.classmodel.util.tree.CmdbClassTree;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessGeneralException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessNonLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AdapterCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AdapterConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AttributeOperatorsConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.ExternalAttribute;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.SupportFederatedQuery;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.SupportedClassConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.impl.AdapterCapabilitiesConfigFactory;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.HasExplicitTimeout;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DataAccessAdapterQueryGetSupportedClassConfigs extends AbstractDataAccessNonLifeCycleAdapterQuery
  implements HasExplicitTimeout
{
  private static Log _logger = LogFactory.getEasyLog(DataAccessAdapterQueryGetSupportedClassConfigs.class);
  public static final long DEFAULT_TIMEOUT = 20000L;
  private Map<String, SupportedClassConfig> _supportedClassesConfig;
  private long _timeOut;
  private static final String RETRIEVE_RESULT = "Retrieve Result";

  public DataAccessAdapterQueryGetSupportedClassConfigs(DestinationConfig destinationConfig)
  {
    setDestinationConfig(destinationConfig);
    this._timeOut = 20000L; }

  public DataAccessAdapterQueryGetSupportedClassConfigs(DestinationConfig destinationConfig, long timeOut) {
    setDestinationConfig(destinationConfig);
    this._timeOut = timeOut;
  }

  private Map<String, SupportedClassConfig> getSupportedClassesFromAdapterConfiguration(DataAccessAdapterManager dataAccessManager)
  {
    if (_logger.isDebugEnabled())
      _logger.debug("get supported classes from adapter config for destination" + getDestinationId());

    Map supportedClasses = null;
    AdapterConfig adapterConfig = getDestinationConfig().getAdapterConfig();
    AdapterCapabilities adapterCapabilities = adapterConfig.getAdapterCapabilities();
    if ((adapterCapabilities != null) && (adapterCapabilities.getSupportFederatedQuery() != null) && (adapterCapabilities.getSupportFederatedQuery().hasSupportedClassesDef())) {
      CmdbClassModel classModel = FClassModelUtil.getClassModel(dataAccessManager);
      ReadOnlyIterator supportedClassConfigIterator = adapterCapabilities.getSupportFederatedQuery().getSupportedClasses();
      List supportedClassConfigs = new ArrayList();
      while (supportedClassConfigIterator.hasNext())
        supportedClassConfigs.add(supportedClassConfigIterator.next());

      supportedClasses = getSupportedClasses(supportedClassConfigs, classModel);
    }
    else if (_logger.isDebugEnabled()) {
      _logger.debug("the adapter " + adapterConfig.getAdapterId() + " has no supported classes defined in config");
    }

    return supportedClasses;
  }

  private Map<String, SupportedClassConfig> getSupportedClasses(Collection<SupportedClassConfig> supportedClasses, CmdbClassModel classModel) {
    Map supportedClassesMap = new HashMap();
    for (Iterator i$ = supportedClasses.iterator(); i$.hasNext(); ) { SupportedClassConfig curSupportedClassConfig = (SupportedClassConfig)i$.next();
      String curClassName = validateClasses(curSupportedClassConfig, classModel);
      supportedClassesMap.put(curClassName, curSupportedClassConfig);
      if (curSupportedClassConfig.isDerived())
        addSupportedClassConfigForSubClasses(classModel, curClassName, curSupportedClassConfig, supportedClassesMap);

    }

    List existedClasses = new ArrayList(supportedClassesMap.keySet());
    CmdbClassTree classTree = classModel.getClassTree();
    for (Iterator i$ = existedClasses.iterator(); i$.hasNext(); ) { String className = (String)i$.next();
      CmdbClass curClass = classModel.getClass(className);
      if (curClass != null) {
        ReadOnlyIterator children = classTree.getTreeNodeByClassName(className).getChildrenIterator();
        while (children.hasNext()) {
          ClassTreeNode child = (ClassTreeNode)children.next();
          if (!(supportedClassesMap.containsKey(child.getCmdbClass().getName())))
            addSupportedClassConfigForSubClasses(classModel, className, (SupportedClassConfig)supportedClassesMap.get(className), supportedClassesMap);
        }
      }

    }

    if (_logger.isDebugEnabled())
      _logger.debug("supportedClassesMap are  [ " + supportedClassesMap + " ]");

    return supportedClassesMap;
  }

  private String validateClasses(SupportedClassConfig curSupportedClassConfig, CmdbClassModel classModel) {
    CmdbAttribute cmdbAttribute;
    ParameterizedErrorCode errorCode;
    String curClassName = curSupportedClassConfig.getClassName();
    CmdbClass curClass = classModel.getClass(curClassName);
    if (curClass == null) {
      ParameterizedErrorCode errorCode = new ParameterizedErrorCode(ErrorCode.DATA_STORE_CLASS_NOT_IN_CLASS_MODEL, new ParameterizedErrorCode.ErrorCodeProperty[] { new ParameterizedErrorCode.ErrorCodeProperty("class_name", curClassName) });
      throw new AdapterAccessGeneralException("the class [" + curClassName + "] is not defined in class model", errorCode);
    }

    if (curSupportedClassConfig.getSupportedAttributesSize() > 0) {
      ReadOnlyIterator supportedAttributes = curSupportedClassConfig.getSupportedAttributes();
      while (supportedAttributes.hasNext()) {
        ExternalAttribute curAttribute = (ExternalAttribute)supportedAttributes.next();
        cmdbAttribute = curClass.getAttributeByName(curAttribute.getName());
        if (cmdbAttribute == null) {
          errorCode = new ParameterizedErrorCode(ErrorCode.DATA_STORE_CLASS_ATTRIBUTE_NOT_IN_CLASS, new ParameterizedErrorCode.ErrorCodeProperty[] { new ParameterizedErrorCode.ErrorCodeProperty("attribute_name", curAttribute.getName()), new ParameterizedErrorCode.ErrorCodeProperty("class_name", curClassName) });

          throw new AdapterAccessGeneralException("the attribute [" + curAttribute.getName() + "] of class [" + curClassName + "] is not defined in class model", errorCode);
        }
      }
    }
    if (curSupportedClassConfig.getAttributeOperatorsSize() > 0) {
      ReadOnlyIterator attributesOperator = curSupportedClassConfig.getAttributeOperators();
      while (attributesOperator.hasNext()) {
        AttributeOperatorsConfig attributeOperatorsConfig = (AttributeOperatorsConfig)attributesOperator.next();
        cmdbAttribute = curClass.getAttributeByName(attributeOperatorsConfig.getAttributeName());
        if (cmdbAttribute == null) {
          errorCode = new ParameterizedErrorCode(ErrorCode.DATA_STORE_CLASS_ATTRIBUTE_NOT_IN_CLASS, new ParameterizedErrorCode.ErrorCodeProperty[] { new ParameterizedErrorCode.ErrorCodeProperty("attribute_name", attributeOperatorsConfig.getAttributeName()), new ParameterizedErrorCode.ErrorCodeProperty("class_name", curClassName) });

          throw new AdapterAccessGeneralException("the attribute [" + attributeOperatorsConfig.getAttributeName() + "] of class [" + curClassName + "] is not defined in class model", errorCode);
        }
      }

    }

    return curClassName;
  }

  private void addSupportedClassConfigForSubClasses(CmdbClassModel classModel, String curClassName, SupportedClassConfig curSupportedClassConfig, Map<String, SupportedClassConfig> supportedClassesMap) {
    CmdbClasses classes = classModel.getAllDescendentClasses(curClassName);
    ReadOnlyIterator classesIterator = classes.getIterator();
    List attributeOperatorsConfigs = null;
    if (curSupportedClassConfig.getAttributeOperatorsSize() > 0) {
      attributeOperatorsConfigs = new ArrayList(curSupportedClassConfig.getAttributeOperatorsSize());
      ReadOnlyIterator iterator = curSupportedClassConfig.getAttributeOperators();
      while (iterator.hasNext())
        attributeOperatorsConfigs.add(iterator.next());
    }

    List supportedAttributes = null;
    if (curSupportedClassConfig.getSupportedAttributesSize() > 0) {
      supportedAttributes = new ArrayList(curSupportedClassConfig.getSupportedAttributesSize());
      ReadOnlyIterator externalAttributeIterator = curSupportedClassConfig.getSupportedAttributes();
      while (externalAttributeIterator.hasNext())
        supportedAttributes.add(externalAttributeIterator.next());
    }

    while (classesIterator.hasNext()) {
      CmdbClass curClass = (CmdbClass)classesIterator.next();
      if (!(supportedClassesMap.containsKey(curClass.getName())))
      {
        SupportedClassConfig newSupportedClassConfig;
        if ((curSupportedClassConfig.isAllAttributesSupported()) || (attributeOperatorsConfigs == null) || (attributeOperatorsConfigs.isEmpty())) {
          newSupportedClassConfig = AdapterCapabilitiesConfigFactory.createSupportedClassConfig(curClass.getName(), false, curSupportedClassConfig.isAllAttributesSupported());
        }
        else
          newSupportedClassConfig = AdapterCapabilitiesConfigFactory.createSupportedClassConfig(curClass.getName(), false, attributeOperatorsConfigs, supportedAttributes);

        supportedClassesMap.put(curClass.getName(), newSupportedClassConfig);
      }
    }
  }

  private Map<String, SupportedClassConfig> getSupportedClassesByAdapterAccess(DataAccessAdapterManager dataAccessManager)
  {
    Collection supportedClasses;
    if (_logger.isDebugEnabled())
      _logger.debug("get supported classes by adapter access for destination" + getDestinationId());

    BasicDataAdapterWrapper dataAdapterWrapper = getAdapter(dataAccessManager);
    BasicDataAdapter dataAdapter = dataAdapterWrapper.getBasicDataAdapter();
    if (dataAdapter instanceof FTqlDataAdapter)
      try {
        DataAdapterEnvironment env = DataAdapterEnvironmentUtil.createDataAdapterEnvironment(getDestinationConfig());
        supportedClasses = ((FTqlDataAdapter)dataAdapter).getSupportedClasses(env);
        if (_logger.isDebugEnabled())
          _logger.debug("supportedClasses the adapter returned : " + supportedClasses);
      }
      catch (DataAccessException e) {
        throw new AdapterAccessGeneralException("failed to get supported classes for " + getDestinationConfig(), e);
      }


    throw new AdapterAccessGeneralException("failed to get supported classes for " + getDestinationConfig() + " the adapter doesn't support federation query");

    Collection convertedSupportedClasses = AdapterFPIConverter.convertSupportedClassConfigs(supportedClasses);
    return getSupportedClasses(convertedSupportedClasses, FClassModelUtil.getClassModel(dataAccessManager));
  }

  protected StringBuilder getOutputInfo()
  {
    return new StringBuilder("Supported Classes: ").append(getSupportedClassesConfig());
  }

  protected StringBuilder getInputInfo()
  {
    return new StringBuilder("Destination Configs: ").append(getDestinationConfig());
  }

  protected void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws AdapterAccessException
  {
    AdapterConfig adapterConfig = getDestinationConfig().getAdapterConfig();
    AdapterCapabilities adapterCapabilities = adapterConfig.getAdapterCapabilities();
    if ((adapterCapabilities != null) && (adapterCapabilities.getSupportFederatedQuery() == null))
      throw new AdapterAccessGeneralException("failed to get supported classes for " + getDestinationConfig() + " the adapter doesn't support federation query");

    Map supportedClasses = getSupportedClassesFromAdapterConfiguration(dataAccessManager);
    if ((supportedClasses == null) || (supportedClasses.isEmpty())) {
      supportedClasses = getSupportedClassesByAdapterAccess(dataAccessManager);
    }

    response.addResult("Retrieve Result", (Serializable)supportedClasses);
  }

  public String getOperationName()
  {
    return "Data Access Adapter Query: Get Supported Class Configs";
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
    this._supportedClassesConfig = ((Map)response.getResult("Retrieve Result"));
  }

  public Map<String, SupportedClassConfig> getSupportedClassesConfig() {
    return this._supportedClassesConfig;
  }

  public long getTimeout() {
    return this._timeOut;
  }
}