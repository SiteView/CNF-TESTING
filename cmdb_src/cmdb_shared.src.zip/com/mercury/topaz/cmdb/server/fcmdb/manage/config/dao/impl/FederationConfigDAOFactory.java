package com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao.FederationConfigDAO;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;

public class FederationConfigDAOFactory
{
  public static FederationConfigDAO createFederationConfigDAO(OperationExecutor operationExecutor)
  {
    return new FederationConfigDaoCMDBimpl(operationExecutor);
  }
}