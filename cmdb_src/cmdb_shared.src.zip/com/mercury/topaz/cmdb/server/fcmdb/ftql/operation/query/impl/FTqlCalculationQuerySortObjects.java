package com.mercury.topaz.cmdb.server.fcmdb.ftql.operation.query.impl;

import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyResult;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyQueryDefinition;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetObjectsLayout;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQueryGetTopologyByPattern;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessAdapterQuerySortObjects;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.util.CalculationUtils;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.manager.FTqlCalculationManager;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.CmdbDataComparator;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl.FtqlUtils;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter;
import com.mercury.topaz.cmdb.server.model.operation.query.ModelQueryGetObjectsLayout;
import com.mercury.topaz.cmdb.server.model.operation.query.ModelQuerySortObjects;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryFactory;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryGetObjectsByConditionNoObjects;
import com.mercury.topaz.cmdb.server.model.operation.query.util.ModelQueryUtil;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessCommunicationException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.operation.query.ModelQueryGetObjectsLayoutByIDs;
import com.mercury.topaz.cmdb.shared.model.operation.query.impl.ModelQueryGetObjectsLayoutByIDsImpl;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.sort.CmdbSortCommand;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FTqlCalculationQuerySortObjects extends AbstractFTqlCalculationQuery
  implements ModelQuerySortObjects
{
  private static Log _log = LogFactory.getEasyLog(FTqlCalculationQuerySortObjects.class);
  private static final String KEY_RESULT_OBJECT = "result_objects";
  private CmdbSortCommand _sortCommand;
  private ModelObjects _inputObjects;
  private ElementCondition _elementCondition;
  private CmdbObjectIds _resultObjectIDs;

  public FTqlCalculationQuerySortObjects(ModelObjects modelObjects, CmdbSortCommand sortCommand)
  {
    setInputObjects(modelObjects);
    setSortCommand(sortCommand);
  }

  public FTqlCalculationQuerySortObjects(ElementCondition elementCondition, CmdbSortCommand sortCommand) {
    setElementCondition(elementCondition);
    setSortCommand(sortCommand);
  }

  public void ftqlCalculationgExecuteQuery(FTqlCalculationManager fTqlCalculationManager, CmdbResponse cmdbResponse)
  {
    CmdbObjectIds sortedObjectIDs;
    validate(fTqlCalculationManager.getSynchronizedClassModel());

    if (getInputObjects() != null)
      sortedObjectIDs = sortObjects(fTqlCalculationManager, getInputObjects(), getSortCommand());
    else
      sortedObjectIDs = sortObjects(fTqlCalculationManager, getElementCondition(), getSortCommand());

    setResultObjectIDs(sortedObjectIDs);
    cmdbResponse.addResult("result_objects", sortedObjectIDs);
  }

  private void validate(CmdbClassModel classModel)
  {
    if (getElementCondition() != null) {
      String className = getElementCondition().getClassCondition().getClassName();
      ModelQueryUtil.validateSortCommandByClassName(classModel, className, getSortCommand());
    }
    else {
      Set classNames = ModelQueryUtil.extractClassNames(getInputObjects());
      for (Iterator i$ = classNames.iterator(); i$.hasNext(); ) { Object className = i$.next();
        ModelQueryUtil.validateSortCommandByClassName(classModel, (String)className, getSortCommand());
      }
    }
  }

  private CmdbObjectIds sortObjects(FTqlCalculationManager fTqlCalculationManager, ModelObjects modelObjects, CmdbSortCommand sortCommand)
  {
    CmdbObjectIds sortedObjectIDs;
    Map modelObjectsByDataSourceMap = FtqlUtils.classifyByDataSource(modelObjects);
    if (modelObjectsByDataSourceMap.size() == 1) {
      String dataStore = (String)modelObjectsByDataSourceMap.keySet().iterator().next();
      if (!(FtqlUtils.isExternalDataStore(dataStore))) {
        ModelQuerySortObjects modelQuerySortObjects = ModelQueryFactory.getInternalModelQuerySortObjectsOperation(modelObjects, sortCommand);
        fTqlCalculationManager.executeOperation(modelQuerySortObjects);
        sortedObjectIDs = modelQuerySortObjects.getResultObjectIDs();
      }
      else {
        DataAccessAdapterQuerySortObjects sortObjects = new DataAccessAdapterQuerySortObjects(dataStore, modelObjects, sortCommand);
        fTqlCalculationManager.executeOperation(sortObjects);
        sortedObjectIDs = sortObjects.getResultObjectIDs();
      }
    }
    else {
      sortedObjectIDs = sortObjectsInMemory(fTqlCalculationManager, sortCommand, modelObjectsByDataSourceMap);
    }
    return sortedObjectIDs;
  }

  private CmdbObjectIds sortObjects(FTqlCalculationManager fTqlCalculationManager, ElementCondition elementCondition, CmdbSortCommand sortCommand)
  {
    CmdbObjectIds sortedObjectIDs;
    ClassModelDestinationsConfig classDestinationsConfig = FtqlUtils.getClassesDestinationsConfig();
    Map classifiedMap = getObjectIdsByDataStore(elementCondition, classDestinationsConfig);
    if (classifiedMap.size() == 1) {
      String dataStore = (String)classifiedMap.keySet().iterator().next();
      if (!(FtqlUtils.isExternalDataStore(dataStore))) {
        ModelQuerySortObjects modelQuerySortObjects = ModelQueryFactory.getInternalModelQuerySortObjectsOperation(elementCondition, sortCommand);
        fTqlCalculationManager.executeOperation(modelQuerySortObjects);
        sortedObjectIDs = modelQuerySortObjects.getResultObjectIDs();
      }
      else {
        DataAccessAdapterQuerySortObjects sortObjects = new DataAccessAdapterQuerySortObjects(dataStore, elementCondition, sortCommand);
        fTqlCalculationManager.executeOperation(sortObjects);
        sortedObjectIDs = sortObjects.getResultObjectIDs();
      }
    } else {
      try {
        sortedObjectIDs = sortObjectsInMemory(fTqlCalculationManager, elementCondition, sortCommand, classifiedMap);
      } catch (AdapterAccessException e) {
        _log.error("failed to sort objects ", e);
        throw e;
      }
    }
    return sortedObjectIDs;
  }

  private Map<String, CmdbObjectIds> getObjectIdsByDataStore(ElementCondition elementCondition, ClassModelDestinationsConfig classModelDestinationsConfig) {
    Map classifiedMap;
    ElementIdsCondition idsCondition = elementCondition.getIdsCondition();

    if (null != idsCondition) {
      classifiedMap = FtqlUtils.classifyByDataSource(elementCondition.getIdsCondition().getIds());
    } else {
      classifiedMap = new HashMap();
      String className = elementCondition.getClassCondition().getClassName();
      Collection destinations = classModelDestinationsConfig.getDestinationsForClass(className);
      for (Iterator i$ = destinations.iterator(); i$.hasNext(); ) { String destination = (String)i$.next();
        classifiedMap.put(destination, null); }
    }
    return classifiedMap;
  }

  private CmdbObjectIds sortObjectsInMemory(FTqlCalculationManager fTqlCalculationManager, CmdbSortCommand sortCommand, Map<String, ModelObjects> modelObjectsByDataStoreMap) throws AdapterAccessCommunicationException {
    ElementSimpleLayout elementSimpleLayout = CalculationUtils.createElementSimpleLayoutFromSortCommand(sortCommand);
    CmdbObjects objectsToSort = CmdbObjectFactory.createObjects();
    for (Iterator i$ = modelObjectsByDataStoreMap.entrySet().iterator(); i$.hasNext(); ) { CmdbObjects objects;
      Map.Entry destination = (Map.Entry)i$.next();
      String dataStore = (String)destination.getKey();

      if (!(FtqlUtils.isExternalDataStore(dataStore))) {
        ModelQueryGetObjectsLayout modelQueryGetObjectsLayout = ModelQueryFactory.getInternalModelQueryGetObjectsLayoutOperation(elementSimpleLayout, (ModelObjects)destination.getValue());
        fTqlCalculationManager.executeOperation(modelQueryGetObjectsLayout);
        objects = modelQueryGetObjectsLayout.getOutgoingObjects();
      }
      else {
        DataAccessAdapterQueryGetObjectsLayout getObjectsLayout = new DataAccessAdapterQueryGetObjectsLayout((String)destination.getKey(), elementSimpleLayout, (ModelObjects)destination.getValue());
        fTqlCalculationManager.executeOperation(getObjectsLayout);
        objects = getObjectsLayout.getOutgoingObjects();
      }
      objectsToSort.add(objects);
    }
    CmdbObjects sortedObjects = objectsToSort.sort(new CmdbDataComparator(sortCommand));
    return CalculationUtils.transferCmdbObjectsToCmdbObjectIds(sortedObjects);
  }

  private CmdbObjectIds sortObjectsInMemory(FTqlCalculationManager fTqlCalculationManager, ElementCondition elementCondition, CmdbSortCommand sortCommand, Map<String, CmdbObjectIds> objectIdsByDataStoreMap) throws AdapterAccessException
  {
    ElementSimpleLayout elementSimpleLayout = CalculationUtils.createElementSimpleLayoutFromSortCommand(sortCommand);
    CmdbObjects objectsToSort = CmdbObjectFactory.createObjects();
    for (Iterator i$ = objectIdsByDataStoreMap.entrySet().iterator(); i$.hasNext(); ) { ElementCondition elementConditionWithId;
      Map.Entry destination = (Map.Entry)i$.next();
      String dataStore = (String)destination.getKey();
      CmdbObjects curDataStoreObjects = null;
      if (!(FtqlUtils.isExternalDataStore(dataStore))) {
        CmdbObjectIds idsCondition = (CmdbObjectIds)destination.getValue();
        elementConditionWithId = elementCondition;
        if (idsCondition != null)
          elementConditionWithId = PatternConditionFactory.createElementCondition(elementCondition.getClassCondition(), elementCondition.getPropertiesCondition(), idsCondition);

        ModelQueryGetObjectsByConditionNoObjects modelQueryGetObjectsByCondition = new ModelQueryGetObjectsByConditionNoObjects(elementConditionWithId);
        fTqlCalculationManager.executeOperation(modelQueryGetObjectsByCondition);
        CmdbObjectIds resultIds = modelQueryGetObjectsByCondition.getResultObjectIDs();
        if ((resultIds != null) && (!(resultIds.isEmpty()))) {
          ModelQueryGetObjectsLayoutByIDs modelQueryGetObjectsLayout = new ModelQueryGetObjectsLayoutByIDsImpl(resultIds, elementSimpleLayout);
          fTqlCalculationManager.executeOperation(modelQueryGetObjectsLayout);
          curDataStoreObjects = modelQueryGetObjectsLayout.getResultObjects();
        }
      }
      else {
        String nodeName = "oneNode";
        elementConditionWithId = PatternConditionFactory.createElementCondition(elementCondition.getClassCondition(), elementCondition.getPropertiesCondition(), (CmdbObjectIds)destination.getValue());
        TopologyQueryDefinition queryDefinition = AdapterFPIConverter.createQueryDefinitionByElementCondition(elementConditionWithId, nodeName);
        DataAccessAdapterQueryGetTopologyByPattern getTopologyByPattern = new DataAccessAdapterQueryGetTopologyByPattern((String)destination.getKey(), queryDefinition);
        fTqlCalculationManager.executeOperation(getTopologyByPattern);
        ExternalTopologyResult result = getTopologyByPattern.getTopologyResult();
        Collection topologyCIs = AdapterFPIConverter.extractCIsFromExternalTopologyResult(result, nodeName);
        ModelObjects resultObjects = AdapterFPIConverter.convertTopologyCisToModelObjects(topologyCIs);
        if ((resultObjects != null) && (resultObjects.size() > 0)) {
          DataAccessAdapterQueryGetObjectsLayout getObjectsLayout = new DataAccessAdapterQueryGetObjectsLayout((String)destination.getKey(), elementSimpleLayout, resultObjects);
          fTqlCalculationManager.executeOperation(getObjectsLayout);
          curDataStoreObjects = getObjectsLayout.getOutgoingObjects();
        }
      }
      if (curDataStoreObjects != null)
        objectsToSort.add(curDataStoreObjects);

    }

    CmdbObjects sortedObjects = objectsToSort.sort(new CmdbDataComparator(sortCommand));
    return CalculationUtils.transferCmdbObjectsToCmdbObjectIds(sortedObjects);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setResultObjectIDs((CmdbObjectIds)response.getResult("result_objects"));
  }

  public String getOperationName()
  {
    return "FTql Calculation Query: Sort Objects";
  }

  private CmdbSortCommand getSortCommand()
  {
    return this._sortCommand;
  }

  private void setSortCommand(CmdbSortCommand sortCommand) {
    if (sortCommand == null)
      throw new IllegalArgumentException("sortCommand was null");

    this._sortCommand = sortCommand;
  }

  private ModelObjects getInputObjects() {
    return this._inputObjects;
  }

  private void setInputObjects(ModelObjects inputObjects) {
    if (inputObjects == null)
      throw new IllegalArgumentException("inputObjects was null");

    this._inputObjects = inputObjects;
  }

  public CmdbObjectIds getResultObjectIDs() {
    return this._resultObjectIDs;
  }

  private void setResultObjectIDs(CmdbObjectIds resultObjectIDs) {
    if (resultObjectIDs == null)
      throw new IllegalArgumentException("resultObjectIDs was null");

    this._resultObjectIDs = resultObjectIDs;
  }

  private ElementCondition getElementCondition() {
    return this._elementCondition;
  }

  private void setElementCondition(ElementCondition elementCondition) {
    if (elementCondition == null)
      throw new IllegalArgumentException("elementCondition was null");

    this._elementCondition = elementCondition;
  }
}