package com.mercury.topaz.cmdb.server.fcmdb.diff.util;

import com.hp.ucmdb.federationspi.data.query.topology.TopologyIds;
import com.hp.ucmdb.federationspi.data.query.types.ExternalCiId;
import com.hp.ucmdb.federationspi.data.query.types.ExternalRelationId;
import com.hp.ucmdb.federationspi.data.replication.FCmdbGraphSignature;
import com.hp.ucmdb.federationspi.data.replication.FCmdbGraphSignatures;
import com.hp.ucmdb.federationspi.data.replication.FCmdbIdsActionData;
import com.hp.ucmdb.federationspi.data.replication.FCmdbResultContainer;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.replication.FCmdbActionDataFactory;
import com.mercury.topaz.cmdb.server.fcmdb.util.FCmdbDataUtil;
import com.mercury.topaz.cmdb.shared.fcmdb.base.FCmdbException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class DiffUtils
{
  public static FCmdbIdsActionData calculateDiff(FCmdbResultContainer lastState, FCmdbResultContainer newState, boolean exclusive)
    throws FCmdbException
  {
    FCmdbIdsActionData actionData;
    if ((newState != null) || (lastState != null))
      if (newState == null) {
        if (exclusive) {
          actionData = addAllGraphToRemove(lastState.getTopology());
        }
        else
          actionData = FCmdbActionDataFactory.createIdsActionData();

      }
      else if (lastState == null) {
        actionData = addAllGraphToAdd(newState.getTopology());
      }
      else {
        actionData = FCmdbActionDataFactory.createIdsActionData();
        addObjectsData(newState, lastState, actionData, exclusive);
        addLinksData(newState, lastState, actionData, exclusive);
      }

    else
      actionData = FCmdbActionDataFactory.createIdsActionData();

    return actionData;
  }

  private static FCmdbIdsActionData addAllGraphToRemove(TopologyIds graph)
  {
    FCmdbIdsActionData actionData = FCmdbActionDataFactory.createIdsActionData();

    actionData.getObjectsForRemove().addAll(graph.getAllCIs());

    Collection linksForRemove = graph.getAllRelations();
    Collection referencedObjects = createReferencedObjects(linksForRemove, graph.getAllCIs());
    actionData.getLinksForRemove().addAll(linksForRemove);
    actionData.getReferencedObjects().addAll(referencedObjects);

    return actionData;
  }

  private static Collection<ExternalCiId> createReferencedObjects(Collection<ExternalRelationId> dataContainerLinks, Collection<ExternalCiId> topologyObjects) {
    Map topologyObjectMap = FCmdbDataUtil.createDataMapById(topologyObjects);
    Set referencedObjectsSet = new HashSet();
    for (Iterator i$ = dataContainerLinks.iterator(); i$.hasNext(); ) { ExternalRelationId dataContainerLink = (ExternalRelationId)i$.next();
      if (!(dataContainerLink.isCmdbId())) {
        ExternalCiId end1Object = (ExternalCiId)topologyObjectMap.get(dataContainerLink.getEnd1Id());
        ExternalCiId end2Object = (ExternalCiId)topologyObjectMap.get(dataContainerLink.getEnd1Id());
        if ((end1Object == null) || (end2Object == null))
          throw new FCmdbException("link " + dataContainerLink + " has no cmdb id and one of the ends " + dataContainerLink.getEnd1Id() + "/" + dataContainerLink.getEnd2Id() + "in the result topology");

        referencedObjectsSet.add(end1Object);
        referencedObjectsSet.add(end2Object);
      }
    }
    return new ArrayList(referencedObjectsSet);
  }

  private static FCmdbIdsActionData addAllGraphToAdd(TopologyIds graph) {
    FCmdbIdsActionData actionData = FCmdbActionDataFactory.createIdsActionData();

    actionData.getObjectsForAdd().addAll(graph.getAllCIs());

    Collection relations = graph.getAllRelations();
    Collection referencedObjects = createReferencedObjects(relations, graph.getAllCIs());
    actionData.getLinksForAdd().addAll(relations);
    actionData.getReferencedObjects().addAll(referencedObjects);
    return actionData;
  }

  private static void addLinksData(FCmdbResultContainer newState, FCmdbResultContainer curState, FCmdbIdsActionData actionData, boolean exclusive) {
    Collection curLinks = curState.getTopology().getAllRelations();
    Collection newLinks = newState.getTopology().getAllRelations();

    Collection addLinks = new ArrayList();
    Collection removeLinks = new ArrayList();
    Collection updateLinks = new ArrayList();
    if (curLinks.isEmpty()) {
      addLinks.addAll(newLinks);
    }
    else if (newLinks.isEmpty()) {
      if (exclusive)
        removeLinks.addAll(curLinks);
    }
    else
    {
      FCmdbGraphSignatures curSignatures = curState.getSignature();
      FCmdbGraphSignatures newSignatures = newState.getSignature();
      Set curLinksSet = new HashSet(curLinks);
      for (Iterator i$ = newLinks.iterator(); i$.hasNext(); ) { ExternalRelationId newLink = (ExternalRelationId)i$.next();
        if (curLinksSet.contains(newLink)) {
          FCmdbGraphSignature newSignature = newSignatures.getSignature(newLink);
          if (newSignature == null)
            throw new FCmdbException("There is no signature in the new state topology for the link " + newLink);

          if (newSignature.isChanged(curSignatures.getSignature(newLink)))
            updateLinks.add(newLink);
        }
        else {
          addLinks.add(newLink);
        }
      }
      Set newLinksSet = new HashSet(newLinks);

      if (exclusive) {
        curLinksSet.removeAll(newLinksSet);
        for (Iterator i$ = curLinks.iterator(); i$.hasNext(); ) { ExternalRelationId curLink = (ExternalRelationId)i$.next();
          if (curLinksSet.contains(curLink))
            removeLinks.add(curLink);
        }
      }
    }

    updateDataContainerWithLinkActions(actionData, removeLinks, addLinks, updateLinks, curState.getTopology().getAllCIs());
  }

  private static void updateDataContainerWithLinkActions(FCmdbIdsActionData actionData, Collection<ExternalRelationId> removeLinks, Collection<ExternalRelationId> addLinks, Collection<ExternalRelationId> updateLinks, Collection<ExternalCiId> curStateObjects)
  {
    Collection referencedObjects;
    if (!(removeLinks.isEmpty())) {
      actionData.getLinksForRemove().addAll(removeLinks);
      referencedObjects = createReferencedObjects(removeLinks, curStateObjects);
      if ((referencedObjects != null) && (!(referencedObjects.isEmpty())))
        actionData.getReferencedObjects().addAll(referencedObjects);
    }

    if (!(addLinks.isEmpty())) {
      actionData.getLinksForAdd().addAll(addLinks);
      referencedObjects = createReferencedObjects(addLinks, curStateObjects);
      if ((referencedObjects != null) && (!(referencedObjects.isEmpty())))
        actionData.getReferencedObjects().addAll(referencedObjects);
    }

    if (!(updateLinks.isEmpty())) {
      actionData.getLinksForUpdate().addAll(updateLinks);
      referencedObjects = createReferencedObjects(updateLinks, curStateObjects);
      if ((referencedObjects != null) && (!(referencedObjects.isEmpty())))
        actionData.getReferencedObjects().addAll(referencedObjects);
    }
  }

  private static void addObjectsData(FCmdbResultContainer newState, FCmdbResultContainer lastState, FCmdbIdsActionData actionData, boolean exclusive)
  {
    Collection newObjects = newState.getTopology().getAllCIs();
    Collection lastObjects = lastState.getTopology().getAllCIs();

    Collection addObjects = new ArrayList();
    Collection removeObjects = new ArrayList();
    Collection updateObjects = new ArrayList();
    if (lastObjects.isEmpty()) {
      addObjects.addAll(newObjects);
    } else if (newObjects.isEmpty()) {
      if (exclusive)
        removeObjects.addAll(lastObjects);
    }
    else
    {
      FCmdbGraphSignatures newSignatures = newState.getSignature();
      FCmdbGraphSignatures lastSignatures = lastState.getSignature();
      Set lastObjectsSet = new HashSet(lastObjects);
      for (Iterator i$ = newObjects.iterator(); i$.hasNext(); ) { ExternalCiId newObject = (ExternalCiId)i$.next();
        if (lastObjectsSet.contains(newObject)) {
          FCmdbGraphSignature newSignature = newSignatures.getSignature(newObject);
          if (newSignature == null)
            throw new FCmdbException("There is no signature in the new state topology for the object " + newObject);

          if (newSignature.isChanged(lastSignatures.getSignature(newObject)))
            updateObjects.add(newObject);
        }
        else {
          addObjects.add(newObject);
        }
      }
      Set newObjectsSet = new HashSet(newObjects);

      if (exclusive) {
        lastObjectsSet.removeAll(newObjectsSet);
        for (Iterator i$ = lastObjects.iterator(); i$.hasNext(); ) { ExternalCiId lastObject = (ExternalCiId)i$.next();
          if (lastObjectsSet.contains(lastObject))
            removeObjects.add(lastObject);
        }
      }
    }

    if (!(removeObjects.isEmpty()))
      actionData.getObjectsForRemove().addAll(removeObjects);

    if (!(addObjects.isEmpty()))
      actionData.getObjectsForAdd().addAll(addObjects);

    if (!(updateObjects.isEmpty()))
      actionData.getObjectsForUpdate().addAll(updateObjects);
  }
}