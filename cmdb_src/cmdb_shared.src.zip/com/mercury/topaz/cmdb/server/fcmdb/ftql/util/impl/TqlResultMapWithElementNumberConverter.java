package com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl;

import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class TqlResultMapWithElementNumberConverter
{
  private TqlResultMap _resultMap;
  private Map<PatternElementNumber, String> _convertionMap;

  public TqlResultMapWithElementNumberConverter(TqlResultMap resultMap, Map<String, PatternElementNumber> convertionMap)
  {
    this._resultMap = resultMap;
    this._convertionMap = convertMap(convertionMap);
  }

  private Map<PatternElementNumber, String> convertMap(Map<String, PatternElementNumber> elementNumberConversionMap)
  {
    Map resultMap = new HashMap(elementNumberConversionMap.size());
    for (Iterator i$ = elementNumberConversionMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
      resultMap.put(curEntry.getValue(), curEntry.getKey());
    }
    return resultMap;
  }

  public TqlResultMap getResultMap() {
    return this._resultMap;
  }

  public Map<PatternElementNumber, String> getConvertionMap() {
    return this._convertionMap;
  }
}