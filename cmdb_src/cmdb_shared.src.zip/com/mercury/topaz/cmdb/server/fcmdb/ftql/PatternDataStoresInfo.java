package com.mercury.topaz.cmdb.server.fcmdb.ftql;

import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import java.io.Serializable;

public abstract interface PatternDataStoresInfo extends Serializable
{
  public abstract int getNumberOfElementDataStoresInfo();

  public abstract ElementDataStoresInfo getElementDataStoreInfo(PatternElementNumber paramPatternElementNumber);

  public abstract LinkDataStorePermutationsInfo getLinkDataStorePermutationsInfo(PatternElementNumber paramPatternElementNumber);

  public abstract int getNumberOfLinkDataStorePermutationsInfo();

  public abstract boolean isFederated();

  public abstract void addElementDataStoreInfo(PatternElementNumber paramPatternElementNumber, ElementDataStoresInfo paramElementDataStoresInfo);

  public abstract void setIsFederated(boolean paramBoolean);

  public abstract void addLinkDataStorePermutationsInfo(PatternElementNumber paramPatternElementNumber, LinkDataStorePermutationsInfo paramLinkDataStorePermutationsInfo);

  public abstract PatternDataStoresInfo clone();
}