package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.command;

import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.DataAccessOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.command.CmdbCommand;

public abstract interface DataAccessCommand
{
}