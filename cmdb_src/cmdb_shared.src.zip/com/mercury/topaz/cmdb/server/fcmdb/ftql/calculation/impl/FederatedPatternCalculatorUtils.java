package com.mercury.topaz.cmdb.server.fcmdb.ftql.calculation.impl;

import com.hp.ucmdb.federationspi.data.query.reconciliation.IdReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.IdReconciliationObject;
import com.hp.ucmdb.federationspi.data.query.reconciliation.PropertyReconciliationObject;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationObject;
import com.hp.ucmdb.federationspi.data.query.reconciliation.ReconciliationObjectFactory;
import com.hp.ucmdb.federationspi.data.query.reconciliation.TopologyReconciliationData;
import com.hp.ucmdb.federationspi.data.query.reconciliation.TopologyReconciliationObject;
import com.hp.ucmdb.federationspi.data.query.result.ExternalResultFactory;
import com.hp.ucmdb.federationspi.data.query.result.ExternalTopologyResult;
import com.hp.ucmdb.federationspi.data.query.topology.Topology;
import com.hp.ucmdb.federationspi.data.query.topology.TopologyQueryDefinition;
import com.hp.ucmdb.federationspi.data.query.types.ExternalCiId;
import com.hp.ucmdb.federationspi.data.query.types.ExternalRelationId;
import com.hp.ucmdb.federationspi.data.query.types.Property;
import com.hp.ucmdb.federationspi.data.query.types.ReconciliationId;
import com.hp.ucmdb.federationspi.data.query.types.ReconciliationIdFactory;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.result.ExternalTopologyPatternResultImpl;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter;
import com.mercury.topaz.cmdb.server.fcmdb.util.AdapterFPIConverter.ElementNumberConverterFromMap;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.tql.definition.impl.PatternGraphUtils;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalOperator;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.LinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternElement;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.NodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.ConditionUtils;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternLinkCompound;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternLinkJoinf;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.DefaultLinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumbers;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.result.TqlModifiableResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.impl.TqlResultFactory;
import com.mercury.topaz.cmdb.shared.tql.result.relative.PatternRelatives;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.CmdbLinkResultEntry;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.CmdbObjectResultEntry;
import com.mercury.topaz.cmdb.shared.tql.util.ClientSideRelatives;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultMapUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FederatedPatternCalculatorUtils
{
  private static FederatedPatternCalculatorUtils instance = new FederatedPatternCalculatorUtils();

  public Pattern internalIntegrateUserTqlIntoReconciliationData(TopologyReconciliationData topologyReconciliationData, DataForCalculation dataForCalculation)
  {
    if (topologyReconciliationData == null)
      PatternDefinitionFactory.createPattern("", "User mapping union FTQL", PatternGroupId.PATTERN_GROUP_ALL, dataForCalculation.getUserGraph());

    Pattern reconciliationPattern = dataForCalculation.getReconciliationPattern();
    ModifiablePatternGraph mergedPatternGraph = unifyUserAndReconciliationGraphs(dataForCalculation);
    mergeUserAndReconciliationLinkEndCondition(dataForCalculation, mergedPatternGraph);
    ModifiablePattern userAndMappingCombinedPattern = PatternDefinitionFactory.createPattern("", "User mapping union FTQL", PatternGroupId.PATTERN_GROUP_ALL, mergedPatternGraph);
    PatternLayout defaultLayout = reconciliationPattern.getLayout();
    userAndMappingCombinedPattern.setDefaultLayout(defaultLayout);
    return userAndMappingCombinedPattern;
  }

  private ModifiablePatternGraph unifyUserAndReconciliationGraphs(DataForCalculation dataForCalculation) {
    PatternGraph reconciliationGraph = dataForCalculation.getReconciliationPattern().getPatternGraph();
    PatternGraph userGraph = dataForCalculation.getUserGraph();
    PatternElementNumber linkEndNumber = dataForCalculation.getVirtualLinkEndNodeNumber();
    ModifiablePatternGraph mergedPatternGraph = reconciliationGraph.toModifiableGraph();
    if (dataForCalculation.getReconciliationElementNumbers().length == 1) {
      unifyUserAndReconciliationGraphsOneReconciliationNodes(dataForCalculation, userGraph, linkEndNumber, mergedPatternGraph);
    }
    else
      unifyUserAndReconciliationGraphsMultipleReconciliationNodes(dataForCalculation, userGraph, linkEndNumber, mergedPatternGraph);

    return mergedPatternGraph;
  }

  private void unifyUserAndReconciliationGraphsOneReconciliationNodes(DataForCalculation dataForCalculation, PatternGraph userGraph, PatternElementNumber linkEndNumber, ModifiablePatternGraph mergedPatternGraph) {
    PatternElementNumber reconciliationNumber = dataForCalculation.getReconciliationElementNumbers()[0];

    for (ReadOnlyIterator iter = userGraph.getNodesIterator(); iter.hasNext(); ) {
      PatternNode node = (PatternNode)iter.next();
      if (!(linkEndNumber.equals(node.getElementNumber())))
        mergedPatternGraph.addNode(node);
    }

    for (iter = userGraph.getLinksIterator(); iter.hasNext(); ) {
      PatternLink link = (PatternLink)iter.next();
      PatternElementNumber end1Number = link.getEnd1Number();
      PatternElementNumber end2Number = link.getEnd2Number();
      if (end1Number.equals(linkEndNumber)) {
        link = duplicateLink(link, link.getElementNumber(), reconciliationNumber, end2Number);
      }
      else if (end2Number.equals(linkEndNumber))
        link = duplicateLink(link, link.getElementNumber(), end1Number, reconciliationNumber);

      mergedPatternGraph.addLink(link);
    }
  }

  private PatternLink duplicateLink(PatternLink link, PatternElementNumber linkNumber, PatternElementNumber end1Number, PatternElementNumber end2Number) {
    PatternLink duplicatedLink = null;
    if (!(link.hasFunction())) {
      duplicatedLink = PatternGraphFactory.createPatternLink(linkNumber, end1Number, end2Number, link.getLinkCondition(), link.isVisible(), link.getName());
    }
    else if (link instanceof PatternLinkCompound) {
      duplicatedLink = PatternGraphFactory.createPatternLinkCompound(linkNumber, end1Number, end2Number, link.getLinkCondition(), link.isVisible(), link.getName(), ((PatternLinkCompound)link).getCompoundParameter());
    }
    else if (link instanceof PatternLinkJoinf) {
      duplicatedLink = PatternGraphFactory.createPatternLinkJoinf(linkNumber, end1Number, end2Number, link.getLinkCondition(), link.isVisible(), link.getName(), ((PatternLinkJoinf)link).getJoinfParameter());
    }

    return duplicatedLink;
  }

  private void unifyUserAndReconciliationGraphsMultipleReconciliationNodes(DataForCalculation dataForCalculation, PatternGraph userGraph, PatternElementNumber linkEndNumber, ModifiablePatternGraph mergedPatternGraph)
  {
    PatternElementNumber[] arr$ = dataForCalculation.getReconciliationElementNumbers(); int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { PatternElementNumber duplicateNumber;
      PatternElementNumber curReconciliationNumber = arr$[i$];

      Map originalToDuplicateNodeMap = new HashMap(userGraph.getNodeAmount());
      for (ReadOnlyIterator iter = userGraph.getNodesIterator(); iter.hasNext(); ) {
        PatternNode node = (PatternNode)iter.next();
        if (!(linkEndNumber.equals(node.getElementNumber()))) {
          duplicateNumber = dataForCalculation.getDuplicateUserGraphElementNumber(node.getElementNumber(), mergedPatternGraph);
          originalToDuplicateNodeMap.put(node.getElementNumber(), duplicateNumber);
          mergedPatternGraph.addNode(PatternGraphFactory.createPatternNode(duplicateNumber, node.getCondition(), node.isVisible(), node.getLinksCondition(), node.getName()));
        }
        else {
          originalToDuplicateNodeMap.put(node.getElementNumber(), curReconciliationNumber);
        }
      }
      for (iter = userGraph.getLinksIterator(); iter.hasNext(); ) {
        PatternLink link = (PatternLink)iter.next();
        duplicateNumber = dataForCalculation.getDuplicateUserGraphElementNumber(link.getElementNumber(), mergedPatternGraph);
        PatternElementNumber end1DuplicateNumber = (PatternElementNumber)originalToDuplicateNodeMap.get(link.getEnd1Number());
        PatternElementNumber end2DuplicateNumber = (PatternElementNumber)originalToDuplicateNodeMap.get(link.getEnd2Number());
        mergedPatternGraph.addLink(duplicateLink(link, duplicateNumber, end1DuplicateNumber, end2DuplicateNumber));
      }
    }
  }

  private void mergeUserAndReconciliationLinkEndCondition(DataForCalculation dataForCalculation, ModifiablePatternGraph mergedPatternGraph)
  {
    PatternGraph userGraph = dataForCalculation.getUserGraph();
    PatternElementNumber linkEndNumber = dataForCalculation.getVirtualLinkEndNodeNumber();
    PatternGraph reconciliationPatternGraph = dataForCalculation.getReconciliationPattern().getPatternGraph();
    ElementCondition userCondition = userGraph.getNode(linkEndNumber).getCondition();
    PatternElementNumber[] arr$ = dataForCalculation.getReconciliationElementNumbers(); int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { PatternElementNumber curElementNumber = arr$[i$];
      ElementCondition mappingCondition = reconciliationPatternGraph.getNode(curElementNumber).getCondition();

      ElementClassCondition mergedClassConsition = userCondition.getClassCondition();

      ElementPropertiesCondition userPropertiesCondition = userCondition.getPropertiesCondition();
      ElementPropertiesCondition mappingPropertiesCondition = mappingCondition.getPropertiesCondition();
      ElementPropertiesCondition mergedPropertiesCondition = ConditionUtils.mergePropertiesCondition(userPropertiesCondition, LogicalOperator.AND, mappingPropertiesCondition);

      ElementIdsCondition userIdsCondition = userCondition.getIdsCondition();
      ElementIdsCondition mappingIdsCondition = mappingCondition.getIdsCondition();
      ElementIdsCondition mergedIdsCondition = ConditionUtils.getObjectIdsConditionIntersection(userIdsCondition, mappingIdsCondition);
      CmdbObjectIds mergedIds = (mergedIdsCondition == null) ? null : mergedIdsCondition.getIds();

      ElementCondition mergedElementCondition = PatternConditionFactory.createElementCondition(mergedClassConsition, mergedPropertiesCondition, mergedIds);

      NodeLinksCondition userLinksCondition = userGraph.getNode(linkEndNumber).getLinksCondition();
      NodeLinksCondition mappingLinksCondition = reconciliationPatternGraph.getNode(curElementNumber).getLinksCondition();
      NodeLinksCondition mergedLinksCondition = PatternGraphUtils.mergeLinksCondition(userLinksCondition, LogicalOperator.AND, mappingLinksCondition);

      mergedPatternGraph.getModifiableNode(curElementNumber).setCondition(mergedElementCondition);
      if (mergedLinksCondition != null)
        mergedPatternGraph.getModifiableNode(curElementNumber).setLinksCondition(mergedLinksCondition.toModifiable());
    }
  }

  private void addObjectsWithReconcilition(ReconciliationData reconciliationData, TqlResultMap resultMap, DataForCalculation dataForCalculation, ExternalTopologyPatternResultImpl externalTopologyResult)
  {
    PatternElementNumber virtualLinkEndNodeNumber = dataForCalculation.getVirtualLinkEndNodeNumber();
    if (virtualLinkEndNodeNumber != null) {
      TqlResultMap reconciliationMap = subtractOriginalGraphFromTheResult(resultMap, dataForCalculation.getReconciliationPattern());
      if (reconciliationData instanceof TopologyReconciliationData) {
        addTopologyReconciliationObjects(reconciliationMap, externalTopologyResult, (TopologyReconciliationData)reconciliationData, dataForCalculation);
      }
      else if (reconciliationData instanceof IdReconciliationData) {
        addIdReconciliationObjects(reconciliationMap, externalTopologyResult, dataForCalculation);
      }
      else
        addPropertyReconciliationObject(reconciliationMap, externalTopologyResult, dataForCalculation, reconciliationData.getReconciliationClassName());
    }
  }

  public ExternalTopologyResult internalCreateExternalResult(PatternGraph userGraph, ReconciliationData reconciliationData, TqlResultMap resultMap, DataForCalculation dataForCalculation)
  {
    TopologyQueryDefinition topologyQueryDefinition = AdapterFPIConverter.convertPatternGraphToTopologyQueryDefinition(userGraph, "convertedGraph");
    ExternalTopologyPatternResultImpl externalTopologyResult = (ExternalTopologyPatternResultImpl)ExternalResultFactory.createExternalTopologyResult(topologyQueryDefinition);
    if ((resultMap != null) && (resultMap.objectsSize() > 0))
    {
      addObjectsWithReconcilition(reconciliationData, resultMap, dataForCalculation, externalTopologyResult);

      Topology topology = externalTopologyResult.getTopology();
      addObjectsToTopology(dataForCalculation, resultMap, topology);
      addLinksToTopology(dataForCalculation, resultMap, topology);
    }
    return externalTopologyResult;
  }

  private void addLinksToTopology(DataForCalculation dataForCalculation, TqlResultMap resultMap, Topology topology) {
    ReadOnlyIterator linksIterator = dataForCalculation.getUserGraph().getLinkNumbersIterator();
    while (linksIterator.hasNext()) {
      PatternElementNumber curLinkNumber = (PatternElementNumber)linksIterator.next();
      List duplicateNumbers = dataForCalculation.convertOriginalToDuplicateNumber(curLinkNumber);
      if (duplicateNumbers != null)
        for (Iterator i$ = duplicateNumbers.iterator(); i$.hasNext(); ) { PatternElementNumber duplicateNumber = (PatternElementNumber)i$.next();
          addLinkToCurrentNode(resultMap, duplicateNumber, curLinkNumber, dataForCalculation, topology);
        }

      else
        addLinkToCurrentNode(resultMap, curLinkNumber, curLinkNumber, dataForCalculation, topology);
    }
  }

  private void addObjectsToTopology(DataForCalculation dataForCalculation, TqlResultMap resultMap, Topology topology)
  {
    PatternElementNumber virtualLinkEndNodeNumber = dataForCalculation.getVirtualLinkEndNodeNumber();
    ReadOnlyIterator nodesIterator = dataForCalculation.getUserGraph().getNodeNumbersIterator();
    while (nodesIterator.hasNext()) {
      PatternElementNumber curElementNumber = (PatternElementNumber)nodesIterator.next();
      if (!(curElementNumber.equals(virtualLinkEndNodeNumber))) {
        List duplicateNumbers = dataForCalculation.convertOriginalToDuplicateNumber(curElementNumber);
        if (duplicateNumbers != null)
          for (Iterator i$ = duplicateNumbers.iterator(); i$.hasNext(); ) { PatternElementNumber curDuplicateNumber = (PatternElementNumber)i$.next();
            addObjectsForCurrentNode(resultMap, curDuplicateNumber, topology, curElementNumber);
          }

        else
          addObjectsForCurrentNode(resultMap, curElementNumber, topology, curElementNumber);
      }
    }
  }

  private void addObjectsForCurrentNode(TqlResultMap resultMap, PatternElementNumber curDuplicateNumber, Topology topology, PatternElementNumber curElementNumber)
  {
    if (resultMap.containsElementNumber(curDuplicateNumber)) {
      CmdbObjects restObjects = resultMap.getObjects(curDuplicateNumber);
      ReadOnlyIterator objectsIterator = restObjects.getObjectsIterator();
      while (objectsIterator.hasNext()) {
        CmdbObject curObject = (CmdbObject)objectsIterator.next();
        topology.addCI(String.valueOf(curElementNumber), AdapterFPIConverter.convertCmdbObjectToExternalID(curObject));
      }
    }
  }

  private void addPropertyReconciliationObject(TqlResultMap reconciliationMap, ExternalTopologyPatternResultImpl externalTopologyResult, DataForCalculation dataForCalculation, String reconciliatioinClassName) {
    PatternElementNumber reconciliationElementNumber = dataForCalculation.getReconciliationElementNumbers()[0];
    CmdbObjects cmdbObjects = reconciliationMap.getObjects(reconciliationElementNumber);
    for (Iterator i$ = cmdbObjects.iterator(); i$.hasNext(); ) { CmdbObject cmdbObject = (CmdbObject)i$.next();
      List properties = new ArrayList(cmdbObject.getPropertiesAmount());
      ReadOnlyIterator propertiesIterator = cmdbObject.getPropertiesIterator();
      while (propertiesIterator.hasNext())
        properties.add(AdapterFPIConverter.convertCmdbPropertyToProperty((CmdbProperty)propertiesIterator.next()));

      PropertyReconciliationObject reconciliationObject = ReconciliationObjectFactory.createPropertyReconciliationObject(reconciliatioinClassName, properties);
      externalTopologyResult.addCI(String.valueOf(dataForCalculation.getVirtualLinkEndNodeNumber().getNumber()), AdapterFPIConverter.convertCmdbObjectToExternalID(cmdbObject), new ReconciliationObject[] { reconciliationObject });
    }
  }

  private void addIdReconciliationObjects(TqlResultMap reconciliationMap, ExternalTopologyPatternResultImpl externalTopologyResult, DataForCalculation dataForCalculation)
  {
    PatternElementNumber reconciliationElementNumber = dataForCalculation.getReconciliationElementNumbers()[0];
    CmdbObjects cmdbObjects = reconciliationMap.getObjects(reconciliationElementNumber);
    for (Iterator i$ = cmdbObjects.iterator(); i$.hasNext(); ) { ReconciliationId reconciliationId;
      CmdbObject cmdbObject = (CmdbObject)i$.next();

      if (((CmdbObjectID)cmdbObject.getID()).isExternal())
      {
        Property[] properties = ((ExternalCiId)cmdbObject.getID()).getProperties();
        reconciliationId = ReconciliationIdFactory.createReconciliationCmdbId(properties[0].getPropertyValue().toString());
      }
      else {
        reconciliationId = ReconciliationIdFactory.createReconciliationCmdbId(((CmdbObjectID)cmdbObject.getID()).toString());
      }
      IdReconciliationObject idReconciliationObject = ReconciliationObjectFactory.createIdReconciliationObject(reconciliationId);

      externalTopologyResult.addCI(String.valueOf(dataForCalculation.getVirtualLinkEndNodeNumber().getNumber()), AdapterFPIConverter.convertCmdbObjectToExternalID(cmdbObject), new ReconciliationObject[] { idReconciliationObject });
    }
  }

  private void addLinkToCurrentNode(TqlResultMap resultMap, PatternElementNumber duplicateNumber, PatternElementNumber curLinkNumber, DataForCalculation dataForCalculation, Topology topology) {
    if (resultMap.containsElementNumber(duplicateNumber)) {
      CmdbLinks links = resultMap.getLinks(duplicateNumber);
      PatternGraph userGraph = dataForCalculation.getUserGraph();
      for (Iterator i$ = links.iterator(); i$.hasNext(); ) { CmdbLink curLink = (CmdbLink)i$.next();
        String curLinkName = String.valueOf(curLinkNumber);
        PatternLink curPatternLink = dataForCalculation.getUserGraph().getLink(curLinkNumber);
        PatternElementNumber end1Number = dataForCalculation.convertDuplicateToOriginalNumber(curPatternLink.getEnd1Number());
        if (end1Number == null)
          end1Number = curPatternLink.getEnd1Number();

        String end1Type = userGraph.getDefinitionElement(end1Number).getCondition().getClassCondition().getClassName();
        PatternElementNumber end2Number = dataForCalculation.convertDuplicateToOriginalNumber(curPatternLink.getEnd2Number());
        if (end2Number == null)
          end2Number = curPatternLink.getEnd2Number();

        String end2Type = userGraph.getDefinitionElement(end2Number).getCondition().getClassCondition().getClassName();
        ExternalCiId end1ID = AdapterFPIConverter.convertCmdbObjectIdAndTypeToExternalObjectId(curLink.getEnd1(), end1Type);
        ExternalCiId end2ID = AdapterFPIConverter.convertCmdbObjectIdAndTypeToExternalObjectId(curLink.getEnd2(), end2Type);
        ExternalRelationId relationId = AdapterFPIConverter.convertCmdbLinkToExternalID(curLink, end1ID, end2ID);
        topology.addRelation(curLinkName, relationId);
      }
    }
  }

  void addTopologyReconciliationObjects(TqlResultMap reconciliationMap, ExternalTopologyPatternResultImpl externalTopologyResult, TopologyReconciliationData reconciliationData, DataForCalculation dataForCalculation)
  {
    CmdbClassModel classModel = getClassModel();
    ClientSideRelatives clientSideRelatives = getClienSideRelatives(reconciliationMap, dataForCalculation, classModel);
    Map idRelativesMap = new HashMap();
    PatternElementNumbers requiredElementNumber = createRequiredElementNumbers(dataForCalculation.getReconciliationPattern());
    PatternElementNumber[] arr$ = dataForCalculation.getReconciliationElementNumbers(); int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { PatternElementNumber reconciliationElementNumber = arr$[i$];
      CmdbObjectIds ids = retriveCmdbObjectIds(reconciliationElementNumber, reconciliationMap);
      if ((ids != null) && (!(ids.isEmpty()))) {
        PatternRelatives patternRelatives = clientSideRelatives.generateRelatives(requiredElementNumber, reconciliationElementNumber, ids);
        ReadOnlyIterator relatives = patternRelatives.getRelativesIterator();
        while (relatives.hasNext()) {
          TqlResultMap relative = (TqlResultMap)relatives.next();
          if (relative.containsElementNumber(reconciliationElementNumber)) {
            CmdbObjects reconciliationObjects = relative.getObjects(reconciliationElementNumber);
            if ((reconciliationObjects != null) && (!(reconciliationObjects.isEmpty()))) {
              CmdbObject curReconciliationCmdbObject = (CmdbObject)reconciliationObjects.getObjectsIterator().next();
              String curCIType = curReconciliationCmdbObject.getType();
              ExternalCiId curId = AdapterFPIConverter.convertCmdbObjectIdAndTypeToExternalObjectId((CmdbObjectID)curReconciliationCmdbObject.getID(), curCIType);
              List curRelativesList = (List)idRelativesMap.get(curId);
              if (curRelativesList == null) {
                curRelativesList = new ArrayList();
                idRelativesMap.put(curId, curRelativesList);
              }
              curRelativesList.add(relative);
            }
          }
        }
      }
    }
    Map reconciliationTqlResultMap = unifyRelatives(idRelativesMap);
    String[] reconciliationElementNames = reconciliationData.getReconciliationNodeNames();
    for (Iterator i$ = reconciliationTqlResultMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
      Topology topology = AdapterFPIConverter.convertTqlResultMapToTopology((TqlResultMap)curEntry.getValue(), reconciliationData.getReconciliationQuery(), new AdapterFPIConverter.ElementNumberConverterFromMap(dataForCalculation.getNodeNameToElementNumberMap()));
      TopologyReconciliationObject topologyReconciliationObject = ReconciliationObjectFactory.createTopologyReconciliationObject(topology, reconciliationElementNames);
      externalTopologyResult.addCI(String.valueOf(dataForCalculation.getVirtualLinkEndNodeNumber().getNumber()), (ExternalCiId)curEntry.getKey(), new ReconciliationObject[] { topologyReconciliationObject });
    }
  }

  protected ClientSideRelatives getClienSideRelatives(TqlResultMap reconciliationMap, DataForCalculation dataForCalculation, CmdbClassModel classModel) {
    return new ClientSideRelatives(reconciliationMap, dataForCalculation.getReconciliationPattern(), classModel);
  }

  private CmdbObjectIds retriveCmdbObjectIds(PatternElementNumber elementNumber, TqlResultMap resultMap) {
    CmdbObjectIds cmdbObjectIds = CmdbObjectIdsFactory.create();
    if (resultMap.containsElementNumber(elementNumber)) {
      CmdbObjects objects = resultMap.getObjects(elementNumber);
      for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { CmdbObject cmdbObject = (CmdbObject)i$.next();
        cmdbObjectIds.add((CmdbObjectID)cmdbObject.getID());
      }
    }
    return cmdbObjectIds;
  }

  private Map<ExternalCiId, TqlResultMap> unifyRelatives(Map<ExternalCiId, List<TqlResultMap>> idRelativesMap) {
    Map resultMap = new HashMap();
    for (Iterator i$ = idRelativesMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
      List resultMapToUnify = (List)curEntry.getValue();
      if (resultMapToUnify.size() == 1) {
        resultMap.put(curEntry.getKey(), resultMapToUnify.get(0));
      }
      else {
        LinksDictionary linkDictionary = DefaultLinksDictionary.getInstance();
        TqlModifiableResultMap tqlResultMap = TqlResultFactory.createModifiableResultMap(linkDictionary);
        for (Iterator i$ = ((List)curEntry.getValue()).iterator(); i$.hasNext(); ) { TqlResultMap curTqlResultMap = (TqlResultMap)i$.next();
          addResultMap(tqlResultMap, curTqlResultMap);
        }
        resultMap.put(curEntry.getKey(), tqlResultMap);
      }
    }
    return resultMap;
  }

  private void addResultMap(TqlModifiableResultMap tqlResultMap, TqlResultMap tqlResultMapToAdd) {
    ReadOnlyIterator objectEntryIterator = tqlResultMapToAdd.getObjectResultEntryIterator();
    while (objectEntryIterator.hasNext()) {
      CmdbObjectResultEntry curObjectResultEntry = (CmdbObjectResultEntry)objectEntryIterator.next();
      tqlResultMap.addObjects(curObjectResultEntry.getElementNumber(), (CmdbObjects)curObjectResultEntry.getObjects());
    }
    ReadOnlyIterator linkEntryIterator = tqlResultMapToAdd.getLinkResultEntryIterator();
    while (linkEntryIterator.hasNext())
      tqlResultMap.addLinks((CmdbLinkResultEntry)linkEntryIterator.next());
  }

  private PatternElementNumbers createRequiredElementNumbers(Pattern reconciliationPattern)
  {
    PatternElementNumbers requiredElementNumber = PatternElementNumberFactory.createElementNumbersSetImpl();
    ReadOnlyIterator elementNumbers = reconciliationPattern.getPatternGraph().getElementNumbersIterator();
    while (elementNumbers.hasNext())
      requiredElementNumber.addElementId((PatternElementNumber)elementNumbers.next());

    return requiredElementNumber;
  }

  private TqlResultMap subtractOriginalGraphFromTheResult(TqlResultMap resultMap, Pattern reconciliationPattern) {
    PatternElementNumbers patternElementNumbers = createRequiredElementNumbers(reconciliationPattern);

    TqlModifiableResultMap subtructionResult = TqlResultMapUtils.getPartialResult(resultMap, patternElementNumbers);
    return subtructionResult;
  }

  protected CmdbClassModel getClassModel() {
    return ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
  }

  public static Pattern integrateUserTqlIntoReconciliationData(TopologyReconciliationData topologyReconciliationData, DataForCalculation dataForCalculation) {
    return instance.internalIntegrateUserTqlIntoReconciliationData(topologyReconciliationData, dataForCalculation);
  }

  public static ExternalTopologyResult createExternalResult(PatternGraph userGraph, ReconciliationData reconciliationData, TqlResultMap resultMap, DataForCalculation dataForCalculation)
  {
    return instance.internalCreateExternalResult(userGraph, reconciliationData, resultMap, dataForCalculation);
  }
}