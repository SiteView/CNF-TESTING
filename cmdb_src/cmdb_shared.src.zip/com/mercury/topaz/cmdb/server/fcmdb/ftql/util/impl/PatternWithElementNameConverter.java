package com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl;

import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import java.util.HashMap;
import java.util.Map;

public class PatternWithElementNameConverter
{
  private Pattern _pattern;
  private Map<String, PatternElementNumber> _convertionMap;

  public PatternWithElementNameConverter(Pattern pattern, Map<String, PatternElementNumber> targetTqlElementNumberConversionMap)
  {
    this._pattern = pattern;
    this._convertionMap = targetTqlElementNumberConversionMap;
  }

  public PatternWithElementNameConverter(Pattern pattern) {
    this._pattern = pattern;
    this._convertionMap = new HashMap();
  }

  public Pattern getPattern() {
    return this._pattern;
  }

  public PatternElementNumber getElementNumber(String name) {
    return ((PatternElementNumber)this._convertionMap.get(name));
  }

  public Map<String, PatternElementNumber> getConevertionMap() {
    return this._convertionMap;
  }
}