package com.mercury.topaz.cmdb.server.fcmdb.ftql.util.impl;

import com.hp.ucmdb.federationspi.data.query.types.ExternalId;
import com.hp.ucmdb.federationspi.mappingEngine.MappingEngine;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessContainerQueryObtainMappingEngine;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl.DataAccessContainerQueryObtainMappingEngineByDestinationConfig;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStoreAttributeInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.DataStoreClassInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.ElementDataStoresInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.LinkDataStorePermutationsInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.PatternDataStoresInfo;
import com.mercury.topaz.cmdb.server.fcmdb.ftql.impl.PatternDataStoreInfoFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassAttributesDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.spi.data.query.types.ExternalIdImpl;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.tql.calculator.CalculationState;
import com.mercury.topaz.cmdb.server.tql.calculator.incremental.datacollections.PatternGraphs;
import com.mercury.topaz.cmdb.server.tql.result.utils.impl.TqlResultServerUtils;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.common.expression.ExpressionElement;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AdapterConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.DestinationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLink;
import com.mercury.topaz.cmdb.shared.model.graph.link.ModelLinks;
import com.mercury.topaz.cmdb.shared.model.graph.link.impl.ModelLinksFactory;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObject;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.graph.object.impl.ModelObjectsFactory;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.link.id.impl.CmdbLinkIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.LinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternElement;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementIdsCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.PropertyCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.DefaultLinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.parameterized.NodeCondParams;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.parameterized.ParameterizedPatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.parameterized.PatternCondParams;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultMapChunk;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetServerTqlResultChunk;
import com.mercury.topaz.cmdb.shared.tql.result.TqlModifiableResult;
import com.mercury.topaz.cmdb.shared.tql.result.TqlModifiableResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResult;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.chunk.ChunkRequest;
import com.mercury.topaz.cmdb.shared.tql.result.impl.TqlResultFactory;
import com.mercury.topaz.cmdb.shared.tql.result.impl.model.ModelTqlResultFactory;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.ResultEntry;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultMapUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FtqlUtils
{
  public static final String MERCURY_CMDB = "MERCURY_CMDB";

  public static boolean isFederatedPatternGraph(PatternGraph patternGraph)
  {
    return isFederatedPatternGraph(patternGraph, getClassModel());
  }

  public static boolean isFederatedPatternGraph(PatternGraph patternGraph, CmdbClassModel classModel) {
    ClassModelDestinationsConfig classModelDestinationsConfig = classModel.getClassesDestinationsConfig();
    for (ReadOnlyIterator iter = patternGraph.getNodesIterator(); iter.hasNext(); ) {
      PatternNode patternNode = (PatternNode)iter.next();
      Map dataStoresWithIdsCondition = getDataSourcesByPatternElement(patternNode, classModel, false);
      if ((dataStoresWithIdsCondition.isEmpty()) || (containsExternalDataStores(dataStoresWithIdsCondition.keySet())))
        return true;

      String className = patternNode.getCondition().getClassCondition().getClassName();
      ElementDataStoresInfo elementDataStoresInfo = PatternDataStoreInfoFactory.createElementDataStoresInfo(className);
      addExternalAttributeDataStores(patternNode, null, elementDataStoresInfo, classModelDestinationsConfig);
      if (elementDataStoresInfo.hasExternalAttributes())
        return true;
    }

    return false;
  }

  public static PatternDataStoresInfo getPatternDataStoresInfo(PatternGraph patternGraph, PatternLayout patternLayout, CmdbClassModel classModel) {
    PatternDataStoresInfo patternDataStoresInfo = PatternDataStoreInfoFactory.createPatternDataStoresInfo();
    addDataStoreInformationForNodes(patternGraph, patternLayout, classModel, patternDataStoresInfo, true);
    addDataStoreInformationForLinks(patternGraph, classModel, patternDataStoresInfo, true);
    return patternDataStoresInfo;
  }

  private static void addDataStoreInformationForLinks(PatternGraph patternGraph, CmdbClassModel classModel, PatternDataStoresInfo patternDataStoresInfo, boolean removeNotBelongIds)
  {
    for (ReadOnlyIterator iter = patternGraph.getLinksIterator(); iter.hasNext(); ) {
      PatternLink patternLink = (PatternLink)iter.next();
      PatternElementNumber end1Number = patternLink.getEnd1Number();
      PatternElementNumber end2Number = patternLink.getEnd2Number();
      ElementDataStoresInfo end1ElementDataStoresInfo = patternDataStoresInfo.getElementDataStoreInfo(end1Number);
      ElementDataStoresInfo end2ElementDataStoresInfo = patternDataStoresInfo.getElementDataStoreInfo(end2Number);
      LinkDataStorePermutationsInfo linkDataStorePermutationsInfo = PatternDataStoreInfoFactory.createLinkDataStorePermutationsInfo();
      if ((!(end1ElementDataStoresInfo.getAllDataStores().isEmpty())) && (!(end2ElementDataStoresInfo.getAllDataStores().isEmpty()))) {
        String className = patternLink.getCondition().getClassCondition().getClassName();
        ElementIdsCondition idsCondition = patternLink.getLinkCondition().getIdsCondition();
        Map dataStoresWithIdsCondition = null;
        if ((idsCondition != null) && (idsCondition.getLinkIds() != null) && (!(idsCondition.getLinkIds().isEmpty()))) {
          dataStoresWithIdsCondition = getDataSourcesByIdCondition(idsCondition, className, classModel, removeNotBelongIds);
        }

        if (isInternalLink(end1ElementDataStoresInfo.getAllCoreDataStores(), end2ElementDataStoresInfo.getAllCoreDataStores(), dataStoresWithIdsCondition))
        {
          Set dataStores;
          if (end1ElementDataStoresInfo.getAllCoreDataStores().equals(end2ElementDataStoresInfo.getAllCoreDataStores()))
          {
            dataStores = end1ElementDataStoresInfo.getAllCoreDataStores();
          } else {
            dataStores = end1ElementDataStoresInfo.getAllCoreDataStores();
            dataStores.retainAll(end2ElementDataStoresInfo.getAllCoreDataStores());
          }
          if (dataStoresWithIdsCondition != null) {
            dataStores.retainAll(dataStoresWithIdsCondition.keySet());
          }

          addInternalLinkDataStoreInformation(dataStores, className, linkDataStorePermutationsInfo, patternDataStoresInfo, patternLink, dataStoresWithIdsCondition);
        } else {
          Collection end1Collection = end1ElementDataStoresInfo.getSupportedDataStoresInfo();
          Collection end2Collection = end2ElementDataStoresInfo.getSupportedDataStoresInfo();
          validate(end1Collection, end2Collection);
          ElementDataStoresInfo elementDataStoresInfo = null;
          for (Iterator i$ = end1Collection.iterator(); i$.hasNext(); ) { DataStoreClassInfo end1DataStoreClassInfo = (DataStoreClassInfo)i$.next();
            for (Iterator i$ = end2Collection.iterator(); i$.hasNext(); ) { DataStoreClassInfo end2DataStoreClassInfo = (DataStoreClassInfo)i$.next();
              if (end2DataStoreClassInfo.getDataStore().equals(end1DataStoreClassInfo.getDataStore())) {
                if (elementDataStoresInfo == null)
                  elementDataStoresInfo = PatternDataStoreInfoFactory.createElementDataStoresInfo(className);

                elementDataStoresInfo.addDataStoreClassInfo(PatternDataStoreInfoFactory.createDataStoreClassInfo(end2DataStoreClassInfo.getDataStore(), className));
              }
              linkDataStorePermutationsInfo.addDataStorePermutationInfo(end1DataStoreClassInfo.getDataStore(), end2DataStoreClassInfo.getDataStore());
            }
          }
          if (elementDataStoresInfo != null)
            patternDataStoresInfo.addElementDataStoreInfo(patternLink.getElementNumber(), elementDataStoresInfo);
        }
      }

      patternDataStoresInfo.addLinkDataStorePermutationsInfo(patternLink.getElementNumber(), linkDataStorePermutationsInfo);
    }
  }

  private static boolean isInternalLink(Set<String> end1DataStores, Set<String> end2DataStores, Map<String, ElementIdsCondition> dataStoresWithIdsCondition)
  {
    if (((dataStoresWithIdsCondition != null) && (!(dataStoresWithIdsCondition.isEmpty()))) || (end1DataStores.equals(end2DataStores)))
      return true;

    Set dataStoreIntersection = new HashSet(end1DataStores);
    dataStoreIntersection.retainAll(end2DataStores);
    if (dataStoreIntersection.isEmpty()) {
      return false;
    }

    return ((((end1DataStores.size() != 1) || (!(end1DataStores.contains("MERCURY_CMDB"))))) && (((end2DataStores.size() != 1) || (!(end2DataStores.contains("MERCURY_CMDB"))))));
  }

  private static void addInternalLinkDataStoreInformation(Collection<String> dataStores, String className, LinkDataStorePermutationsInfo linkDataStorePermutationsInfo, PatternDataStoresInfo patternDataStoresInfo, PatternLink patternLink, Map<String, ElementIdsCondition> dataStoresWithIdsCondition)
  {
    ElementDataStoresInfo elementDataStoresInfo = PatternDataStoreInfoFactory.createElementDataStoresInfo(className);
    for (Iterator i$ = dataStores.iterator(); i$.hasNext(); ) { String dataStore = (String)i$.next();
      if (dataStoresWithIdsCondition == null) {
        elementDataStoresInfo.addDataStoreClassInfo(PatternDataStoreInfoFactory.createDataStoreClassInfo(dataStore, className));
        linkDataStorePermutationsInfo.addDataStorePermutationInfo(dataStore, dataStore);
      } else if (dataStoresWithIdsCondition.containsKey(dataStore)) {
        elementDataStoresInfo.addDataStoreClassInfo(PatternDataStoreInfoFactory.createDataStoreClassInfo(dataStore, className, (ElementIdsCondition)dataStoresWithIdsCondition.get(dataStore)));
        linkDataStorePermutationsInfo.addDataStorePermutationInfo(dataStore, dataStore);
      }
    }
    if (elementDataStoresInfo.getAllCoreDataStores().isEmpty())
      throw new IllegalStateException("The virtual link  [" + className + "] has id condition or has no supported data stores");

    patternDataStoresInfo.addElementDataStoreInfo(patternLink.getElementNumber(), elementDataStoresInfo);
  }

  private static void addDataStoreInformationForNodes(PatternGraph patternGraph, PatternLayout patternLayout, CmdbClassModel classModel, PatternDataStoresInfo patternDataStoresInfo, boolean removeNotBelongIds) {
    for (ReadOnlyIterator iter = patternGraph.getNodesIterator(); iter.hasNext(); ) {
      PatternNode patternNode = (PatternNode)iter.next();
      Map dataStoresWithIdsCondition = getDataSourcesByPatternElement(patternNode, classModel, removeNotBelongIds);
      String className = patternNode.getCondition().getClassCondition().getClassName();
      ElementDataStoresInfo elementDataStoresInfo = PatternDataStoreInfoFactory.createElementDataStoresInfo(className);
      for (Iterator i$ = dataStoresWithIdsCondition.entrySet().iterator(); i$.hasNext(); ) { Map.Entry curEntry = (Map.Entry)i$.next();
        elementDataStoresInfo.addDataStoreClassInfo(PatternDataStoreInfoFactory.createDataStoreClassInfo((String)curEntry.getKey(), className, (ElementIdsCondition)curEntry.getValue()));
      }
      addExternalAttributeDataStores(patternNode, patternLayout, elementDataStoresInfo, classModel.getClassesDestinationsConfig());

      patternDataStoresInfo.addElementDataStoreInfo(patternNode.getElementNumber(), elementDataStoresInfo);
    }
  }

  private static void addExternalAttributeDataStores(PatternNode patternNode, PatternLayout patternLayout, ElementDataStoresInfo elementDataStoresInfo, ClassModelDestinationsConfig classModelDestinationsConfig) {
    addExternalAttributeDataStoresByCondition(patternNode, classModelDestinationsConfig, elementDataStoresInfo);
    if (patternLayout != null) {
      ElementLayout elementLayout = patternLayout.getElementLayout(patternNode.getElementNumber());
      if (elementLayout != null) {
        String className = patternNode.getCondition().getClassCondition().getClassName();
        addExternalAttributeDataStoresByLayout(className, elementLayout, elementDataStoresInfo, classModelDestinationsConfig);
      }
    }
  }

  public static void addExternalAttributeDataStoresByLayout(String className, ElementLayout elementLayout, ElementDataStoresInfo elementDataStoresInfo) {
    addExternalAttributeDataStoresByLayout(className, elementLayout, elementDataStoresInfo, getClassesDestinationsConfig());
  }

  public static void addExternalAttributeDataStoresByLayout(String className, ElementLayout elementLayout, ElementDataStoresInfo elementDataStoresInfo, ClassModelDestinationsConfig classModelDestinationsConfig) {
    if (elementLayout != null) {
      ElementSimpleLayout elementSimpleLayout = (ElementSimpleLayout)elementLayout;
      if (elementSimpleLayout.isAllLayer()) {
        ClassAttributesDestinationsConfig classAttributesDestinationsConfig = classModelDestinationsConfig.getClassAttributeDestinationConfig(className);
        if (classAttributesDestinationsConfig != null) {
          Collection attributes = classAttributesDestinationsConfig.getAttributes();
          for (Iterator i$ = attributes.iterator(); i$.hasNext(); ) { String attributeName = (String)i$.next();
            Collection destinations = classAttributesDestinationsConfig.getDestinations(attributeName);
            addDataStoresForAttribute(elementDataStoresInfo, className, attributeName, destinations);
          }
        }
      } else {
        ReadOnlyIterator keys = elementSimpleLayout.getKeysIterator();
        while (keys.hasNext()) {
          String attributeName = (String)keys.next();
          Collection destinations = classModelDestinationsConfig.getDestinationsForClassAndAttribute(className, attributeName);
          addDataStoresForAttribute(elementDataStoresInfo, className, attributeName, destinations);
        }
      }
    }
  }

  private static void addExternalAttributeDataStoresByCondition(PatternNode patternNode, ClassModelDestinationsConfig classModelDestinationsConfig, ElementDataStoresInfo elementDataStoresInfo)
  {
    ElementCondition condition = patternNode.getCondition();
    if ((condition.getPropertiesCondition() != null) && (condition.getPropertiesCondition().getNumberOfElements() > 0))
    {
      String className = condition.getClassCondition().getClassName();
      ReadOnlyIterator conditionIterator = condition.getPropertiesCondition().getIterator();
      while (conditionIterator.hasNext()) {
        ExpressionElement curExpressionElement = (ExpressionElement)conditionIterator.next();
        if (curExpressionElement.isVar()) {
          String propertyName = ((PropertyCondition)curExpressionElement).getPropertyName();
          Collection dataStores = classModelDestinationsConfig.getDestinationsForClassAndAttribute(className, propertyName);
          addDataStoresForAttribute(elementDataStoresInfo, className, propertyName, dataStores);
        }
      }
    }
  }

  private static void validate(Collection<DataStoreClassInfo> end1Collection, Collection<DataStoreClassInfo> end2Collection)
  {
    if ((end1Collection.size() > 1) && (end2Collection.size() > 1))
      throw new IllegalStateException("The one end of the virtual link should be only in one data store");

    if ((end1Collection.size() == 1) && (end2Collection.size() == 1)) {
      if ((((DataStoreClassInfo)end1Collection.iterator().next()).getDataStore().equals("MERCURY_CMDB")) || (((DataStoreClassInfo)end2Collection.iterator().next()).getDataStore().equals("MERCURY_CMDB"))) return;

      throw new IllegalStateException("The one of the ends of the virtual link should be in UCMDB");
    }
    if (end1Collection.size() == 1) {
      if (((DataStoreClassInfo)end1Collection.iterator().next()).getDataStore().equals("MERCURY_CMDB")) return;
      throw new IllegalStateException("The one of the ends of the virtual link should be in UCMDB");
    }
    if ((end2Collection.size() == 1) && 
      (!(((DataStoreClassInfo)end2Collection.iterator().next()).getDataStore().equals("MERCURY_CMDB"))))
      throw new IllegalStateException("The one of the ends of the virtual link should be in UCMDB");
  }

  public static int getFirstRelevantGraphIndex(PatternGraphs graphs, PatternElementNumber elementNumber)
  {
    for (int i = 0; i < graphs.size(); ++i) {
      PatternGraph graph = graphs.get(i);
      if (graph.hasDefinitionElement(elementNumber))
        return i;
    }

    return -1;
  }

  private static Map<String, ElementIdsCondition> getDataSourcesByPatternElement(PatternElement node, CmdbClassModel classModel, boolean removeNotBelongIds)
  {
    ElementCondition condition = node.getCondition();
    return getDataSourcesByCondition(condition, classModel, removeNotBelongIds);
  }

  private static void addDataStoresForAttribute(ElementDataStoresInfo elementDataStoresInfo, String className, String attributeName, Collection<String> dataStores)
  {
    if ((dataStores != null) && (!(dataStores.isEmpty())))
      for (Iterator i$ = dataStores.iterator(); i$.hasNext(); ) { String dataStore = (String)i$.next();
        elementDataStoresInfo.addExternalAttributeInfo(attributeName, new DataStoreAttributeInfo[] { PatternDataStoreInfoFactory.createDataStoreAttributeInfo(className, attributeName, dataStore) });
      }
  }

  private static Map<String, ElementIdsCondition> getDataSourcesByCondition(ElementCondition condition, CmdbClassModel classModel, boolean removeNotBelongIds)
  {
    ClassModelDestinationsConfig classModelDestinationsConfig = classModel.getClassesDestinationsConfig();
    String className = condition.getClassCondition().getClassName();
    ElementIdsCondition idsCondition = condition.getIdsCondition();
    Map idsConditionByDataStores = new HashMap();
    if ((idsCondition != null) && (idsCondition.getIds() != null) && (!(idsCondition.getIds().isEmpty()))) {
      idsConditionByDataStores = getDataSourcesByIdCondition(condition.getIdsCondition(), className, classModel, removeNotBelongIds);
      if (!(idsCondition.isNegate()))
        return idsConditionByDataStores;
    }

    Collection dataSources = getDataSourcesByClassName(className, classModelDestinationsConfig);
    Map result = new HashMap(dataSources.size());
    for (Iterator i$ = dataSources.iterator(); i$.hasNext(); ) { String dataStore = (String)i$.next();
      result.put(dataStore, idsConditionByDataStores.get(dataStore));
    }
    return result;
  }

  static Map<String, ElementIdsCondition> getDataSourcesByIdCondition(ElementIdsCondition idsCondition, String className, CmdbClassModel classModel, boolean removeNotBelongIds)
  {
    Map dataSources = new HashMap();
    if (idsCondition != null)
    {
      Map idsByDataSources;
      Iterator i$;
      Map.Entry curEntry;
      String dataSource;
      if (idsCondition.isIdsOfCmdbObjects())
      {
        idsByDataSources = new HashMap();
        CmdbObjectIds objectIds = idsCondition.getIds();
        for (i$ = objectIds.iterator(); i$.hasNext(); ) { CmdbObjectID id = (CmdbObjectID)i$.next();
          if ((!(removeNotBelongIds)) || (descendentOfClassCondition(id, className, classModel))) {
            dataSource = getDataSourceById(id);
            CmdbObjectIds curIds = (CmdbObjectIds)idsByDataSources.get(dataSource);
            if (curIds == null) {
              curIds = CmdbObjectIdsFactory.create();
              idsByDataSources.put(dataSource, curIds);
            }
            curIds.add(id);
          }
        }
        for (i$ = idsByDataSources.entrySet().iterator(); i$.hasNext(); ) { curEntry = (Map.Entry)i$.next();
          dataSources.put(curEntry.getKey(), PatternConditionFactory.createElementIdsCondition((CmdbObjectIds)curEntry.getValue(), idsCondition.isNegate()));
        }
      }
      else
      {
        idsByDataSources = new HashMap();
        CmdbLinkIds linkIds = idsCondition.getLinkIds();
        for (i$ = linkIds.iterator(); i$.hasNext(); ) { CmdbLinkID id = (CmdbLinkID)i$.next();
          dataSource = getDataSourceById(id);
          CmdbLinkIds curIds = (CmdbLinkIds)idsByDataSources.get(dataSource);
          if (curIds == null) {
            curIds = CmdbLinkIdsFactory.create();
            idsByDataSources.put(dataSource, curIds);
          }
          curIds.add(id);
        }
        for (i$ = idsByDataSources.entrySet().iterator(); i$.hasNext(); ) { curEntry = (Map.Entry)i$.next();
          dataSources.put(curEntry.getKey(), PatternConditionFactory.createElementIdsCondition((CmdbLinkIds)curEntry.getValue(), idsCondition.isNegate()));
        }
      }
    }
    return dataSources;
  }

  private static boolean descendentOfClassCondition(CmdbObjectID id, String className, CmdbClassModel classModel) {
    if (id.isExternal()) {
      String curClassName = ((ExternalIdImpl)id).getClassName();
      return classModel.isTypeOf(className, curClassName);
    }
    return true;
  }

  private static Map<String, Collection<CmdbDataID>> getDataSourcesByIdCondition(Collection<CmdbDataID> ids) {
    Map dataSources = new HashMap();
    if ((ids != null) && (!(ids.isEmpty())))
      for (Iterator i$ = ids.iterator(); i$.hasNext(); ) { CmdbDataID id = (CmdbDataID)i$.next();

        if (id.isExternal()) {
          dataSource = ((ExternalIdImpl)id).getDataStore();
          if ((dataSource != null) && (!(dataSource.equals("")))) break label116;
          throw new IllegalArgumentException("data store of id " + id + " is empty");
        }

        String dataSource = "MERCURY_CMDB";

        label116: Collection curIds = (Collection)dataSources.get(dataSource);
        if (curIds == null) {
          curIds = new ArrayList();
          dataSources.put(dataSource, curIds);
        }
        curIds.add(id);
      }

    return dataSources;
  }

  private static String getDataSourceById(CmdbDataID id)
  {
    if (id.isExternal()) {
      dataSource = ((ExternalIdImpl)id).getDataStore();
      if ((dataSource != null) && (!(dataSource.equals("")))) break label65;
      throw new IllegalArgumentException("data store of id " + id + " is empty");
    }

    String dataSource = "MERCURY_CMDB";

    label65: return dataSource;
  }

  public static Collection<String> getDataSourcesByClassName(String className, ClassModelDestinationsConfig classModelDestinationsConfig)
  {
    Collection dataSources = classModelDestinationsConfig.getDestinationsForClass(className);
    if ((dataSources == null) || (dataSources.isEmpty())) {
      dataSources = new ArrayList();
      dataSources.add("MERCURY_CMDB");
    }
    return dataSources;
  }

  public static Pattern integrateObjectIdsConditionInPattern(Pattern originalPattern, PatternElementNumber elementNumber, CmdbObjectIds objectIds)
  {
    NodeCondParams nodeCondParams = ParameterizedPatternConditionFactory.createNodeCondParams();
    nodeCondParams.addIdsParams(objectIds);

    PatternCondParams patternCondParams = ParameterizedPatternConditionFactory.createPatternCondParams();
    patternCondParams.addElementCondParam(elementNumber, nodeCondParams);

    return patternCondParams.integratePatternParams(originalPattern);
  }

  public static boolean isFederatedModelObjects(ModelObjects modelObjects) {
    for (ReadOnlyIterator modelObjectsIterator = modelObjects.getObjectsIterator(); modelObjectsIterator.hasNext(); )
    {
      ModelObject modelObject = (ModelObject)modelObjectsIterator.next();
      String dataStore = getDataStoreOfModelObject(modelObject);
      if (isExternalDataStore(dataStore))
        return true;
    }

    return false;
  }

  public static boolean isFederatedClass(String className)
  {
    ClassModelDestinationsConfig classModelDestinationsConfig = getClassesDestinationsConfig();
    return isFederatedClass(className, classModelDestinationsConfig);
  }

  public static boolean isFederatedClass(String className, ClassModelDestinationsConfig classModelDestinationsConfig) {
    Collection dataSources = getDataSourcesByClassName(className, classModelDestinationsConfig);
    return containsExternalDataStores(dataSources);
  }

  private static boolean containsExternalDataStores(Collection<String> dataSources) {
    return ((dataSources.size() > 1) || (!(dataSources.contains("MERCURY_CMDB"))));
  }

  public static boolean isFederatedModelLinks(ModelLinks modelLinks) {
    for (ReadOnlyIterator modelLinksIterator = modelLinks.getLinksIterator(); modelLinksIterator.hasNext(); )
    {
      String dataStore = getDataStoreOfModelLink((ModelLink)modelLinksIterator.next());
      if (isExternalDataStore(dataStore))
        return true;
    }

    return false;
  }

  public static boolean isExternalDataStore(String dataStore) {
    return (!("MERCURY_CMDB".equals(dataStore)));
  }

  public static boolean isFederatedElementCondition(ElementCondition elementCondition) {
    CmdbClassModel classModel = getClassModel();
    return isFederatedElementCondition(elementCondition, classModel);
  }

  static boolean isFederatedElementCondition(ElementCondition elementCondition, CmdbClassModel classModel) {
    ElementClassCondition classCondition = elementCondition.getClassCondition();
    ClassModelDestinationsConfig classModelDestinationsConfig = classModel.getClassesDestinationsConfig();
    if (isFederatedClass(classCondition.getClassName(), classModelDestinationsConfig))
      return true;

    Map dataSourcesMap = getDataSourcesByIdCondition(elementCondition.getIdsCondition(), classCondition.getClassName(), classModel, false);
    Collection dataSources = dataSourcesMap.keySet();
    return ((!(dataSources.isEmpty())) && (containsExternalDataStores(dataSources)));
  }

  public static boolean isFederatedIds(CmdbObjectIds ids) {
    if (ids == null)
      return false;

    ArrayList idsList = new ArrayList(ids.size());
    for (Iterator i$ = ids.iterator(); i$.hasNext(); ) { CmdbObjectID id = (CmdbObjectID)i$.next();
      idsList.add(id);
    }
    Map dataSourcesMap = getDataSourcesByIdCondition(idsList);
    Collection dataSources = dataSourcesMap.keySet();
    return containsExternalDataStores(dataSources);
  }

  public static Map<String, ModelLinks> classifyByDataSource(ModelLinks modelLinks)
  {
    Map map = new HashMap();
    for (ReadOnlyIterator iter = modelLinks.getLinksIterator(); iter.hasNext(); ) {
      ModelLink curModelLink = (ModelLink)iter.next();
      String dataSource = getDataStoreOfModelLink(curModelLink);
      ModelLinks curModelLinks = (ModelLinks)map.get(dataSource);
      if (curModelLinks == null) {
        curModelLinks = ModelLinksFactory.createLinks();
        map.put(dataSource, curModelLinks);
      }
      curModelLinks.add(curModelLink);
    }
    return map;
  }

  private static String getDataStoreOfModelLink(ModelLink curModelLink) {
    CmdbLinkID linkId = curModelLink.getID();
    return getDataStoreOfLinkID(linkId);
  }

  private static String getDataStoreOfLinkID(CmdbLinkID linkId)
  {
    String dataSource;
    if (linkId.isExternal())
      dataSource = ((ExternalIdImpl)linkId).getDataStore();
    else
      dataSource = "MERCURY_CMDB";

    return dataSource;
  }

  private static String getDataStoreOfModelObject(ModelObject modelObject) {
    CmdbObjectID objectID = modelObject.toCmdbObjectID();
    return getDataStoreOfObjectID(objectID);
  }

  private static String getDataStoreOfObjectID(CmdbObjectID objectID)
  {
    String dataSource;
    if (objectID.isExternal())
      dataSource = ((ExternalIdImpl)objectID).getDataStore();
    else
      dataSource = "MERCURY_CMDB";

    return dataSource;
  }

  public static Map<String, ModelObjects> classifyByDataSource(ModelObjects modelObjects)
  {
    Map map = new HashMap();
    for (ReadOnlyIterator iter = modelObjects.getObjectsIterator(); iter.hasNext(); ) {
      ModelObject curModelObject = (ModelObject)iter.next();
      String dataSource = getDataStoreOfModelObject(curModelObject);
      ModelObjects curModelObjects = (ModelObjects)map.get(dataSource);
      if (curModelObjects == null) {
        curModelObjects = ModelObjectsFactory.create();
        map.put(dataSource, curModelObjects);
      }
      curModelObjects.add(curModelObject);
    }
    return map;
  }

  public static ModelLinks getVirtualLinks(ModelLinks links) {
    if ((links == null) || (links.size() == 0))
      return links;

    ModelLinks virtualLinks = ModelLinksFactory.createLinks();
    ReadOnlyIterator curLinksIterator = links.getLinksIterator();
    while (curLinksIterator.hasNext()) {
      ModelLink curLink = (ModelLink)curLinksIterator.next();
      String end1DataStore = getDataStoreOfModelObject(curLink.getEnd1());
      String end2DataStore = getDataStoreOfModelObject(curLink.getEnd1());
      if (!(end1DataStore.equals(end2DataStore)))
        virtualLinks.add(curLink);
    }

    return virtualLinks;
  }

  public static ClassModelDestinationsConfig getClassesDestinationsConfig() {
    CmdbClassModel classModel = getClassModel();
    return classModel.getClassesDestinationsConfig();
  }

  public static CmdbClassModel getClassModel()
  {
    return ClassModelProvider.getInstance(ServerApiFacade.getLocalEnvironment()).getClassModel();
  }

  public static PatternGraph integrateCalculationStateAsIDsConditionInPattern(PatternGraph originalPatternGraph, CalculationState calculationState)
  {
    PatternCondParams patternCondParams = null;

    for (ReadOnlyIterator iter = originalPatternGraph.getNodesIterator(); iter.hasNext(); ) {
      PatternNode patternNode = (PatternNode)iter.next();
      if (calculationState.hasPreconditionObjects(patternNode.getElementNumber())) {
        ModelObjects preliminaryObjects = calculationState.getPreconditionObjects(patternNode.getElementNumber());
        patternCondParams = addPreliminaryObjects(preliminaryObjects, patternCondParams, patternNode);
      }
    }
    return ((patternCondParams == null) ? originalPatternGraph : patternCondParams.integratePatternParams(PatternDefinitionFactory.createPattern("ftql_calc_graph", PatternGroupId.PATTERN_GROUP_ALL, originalPatternGraph)).getPatternGraph());
  }

  private static PatternCondParams addPreliminaryObjects(ModelObjects preliminaryObjects, PatternCondParams patternCondParams, PatternNode patternNode)
  {
    if (preliminaryObjects.size() > 0) {
      if (patternCondParams == null)
        patternCondParams = ParameterizedPatternConditionFactory.createPatternCondParams();

      CmdbObjectIds preliminaryObjectIds = TqlResultServerUtils.extractObjectIds(preliminaryObjects);

      if (patternNode.getCondition().getIdsCondition() != null) {
        preliminaryObjectIds = TqlResultMapUtils.intersectObjectIds(preliminaryObjectIds, patternNode.getCondition().getIdsCondition().getIds());
      }

      NodeCondParams nodeCondParams = ParameterizedPatternConditionFactory.createNodeCondParams();
      nodeCondParams.addIdsParams(preliminaryObjectIds);

      patternCondParams.addElementCondParam(patternNode.getElementNumber(), nodeCondParams);
    }
    return patternCondParams;
  }

  public static TqlResult getResultInChunks(ChunkRequest chunkRequest)
  {
    LinksDictionary linkDictionary = DefaultLinksDictionary.getInstance();
    TqlModifiableResult totalResult = ModelTqlResultFactory.createModifiableResult(linkDictionary);
    int chunksCount = 0;
    while (chunkRequest.hasNext()) {
      if (chunksCount != 0)
        chunkRequest = chunkRequest.next();

      TqlQueryGetServerTqlResultChunk getChunk = new TqlQueryGetServerTqlResultChunk(chunkRequest);
      ServerApiFacade.executeOperation(getChunk);
      TqlResult chunkResult = getChunk.getServerTqlResult();
      addToResult(totalResult, chunkResult);
      ++chunksCount;
    }
    return totalResult;
  }

  public static TqlResultMap getResultMapInChunks(ChunkRequest chunkRequest, LinksDictionary linksDictionary)
  {
    TqlModifiableResultMap totalResult = TqlResultFactory.createModifiableResultMap(linksDictionary);
    int chunksCount = 0;
    while (chunkRequest.hasNext()) {
      if (chunksCount != 0)
        chunkRequest = chunkRequest.next();

      TqlQueryGetResultMapChunk getChunk = new TqlQueryGetResultMapChunk(chunkRequest);
      ServerApiFacade.executeOperation(getChunk);
      TqlResultMap chunkResult = getChunk.getResultMap();
      TqlResultMapUtils.addToResult(totalResult, chunkResult);
      ++chunksCount;
    }
    return totalResult;
  }

  private static void addToResult(TqlModifiableResult modifiableResult, TqlResult result) {
    ResultEntry resultEntry;
    PatternElementNumber elementNumber;
    for (ReadOnlyIterator iter = result.getObjectResultEntryIterator(); iter.hasNext(); ) {
      resultEntry = (ResultEntry)iter.next();
      elementNumber = resultEntry.getElementNumber();
      ModelObjects objects = result.getObjects(elementNumber);
      modifiableResult.addObjects(elementNumber, objects);
    }
    for (iter = result.getLinkResultEntryIterator(); iter.hasNext(); ) {
      resultEntry = (ResultEntry)iter.next();
      elementNumber = resultEntry.getElementNumber();
      ModelLinks links = result.getLinks(elementNumber);
      modifiableResult.addLinks(elementNumber, links);
    }
  }

  public static Map<String, CmdbObjectIds> classifyByDataSource(CmdbObjectIds objectIds)
  {
    Map map = new HashMap();
    for (ReadOnlyIterator iter = objectIds.getIdsIterator(); iter.hasNext(); ) {
      CmdbObjectID objectID = (CmdbObjectID)iter.next();
      String dataSource = "MERCURY_CMDB";
      if (objectID.isExternal()) {
        dataSource = ((ExternalId)objectID).getDataStore();
      }

      CmdbObjectIds ids = (CmdbObjectIds)map.get(dataSource);
      if (ids == null) {
        ids = CmdbObjectIdsFactory.create();
        map.put(dataSource, ids);
      }
      ids.add(objectID);
    }
    return map;
  }

  public static Map<String, CmdbLinkIds> classifyByDataSource(CmdbLinkIds linkIds)
  {
    Map map = new HashMap();
    for (ReadOnlyIterator iter = linkIds.getIdsIterator(); iter.hasNext(); ) {
      CmdbLinkID linkID = (CmdbLinkID)iter.next();
      String dataSource = "MERCURY_CMDB";
      if (linkID.isExternal())
      {
        dataSource = ((ExternalId)linkID).getDataStore();
      }
      CmdbLinkIds ids = (CmdbLinkIds)map.get(dataSource);
      if (ids == null) {
        ids = CmdbLinkIdsFactory.create();
        map.put(dataSource, ids);
      }
      ids.add(linkID);
    }
    return map;
  }

  public static boolean containsExtendedAttribute(PatternGraph graphWithPotentiallyExtendedAttributes, ClassModelDestinationsConfig classModelDestinationsConfig) {
    ReadOnlyIterator graphNodes = graphWithPotentiallyExtendedAttributes.getNodesIterator();
    while (graphNodes.hasNext()) {
      PatternNode patternNode = (PatternNode)graphNodes.next();
      ElementCondition condition = patternNode.getCondition();
      if (condition.hasPropertiesCondition()) {
        String className = condition.getClassCondition().getClassName();
        ReadOnlyIterator conditionIterator = condition.getPropertiesCondition().getIterator();
        while (conditionIterator.hasNext()) {
          ExpressionElement curExpressionElement = (ExpressionElement)conditionIterator.next();
          if (curExpressionElement.isVar()) {
            String propertyName = ((PropertyCondition)curExpressionElement).getPropertyName();
            Collection dataStores = classModelDestinationsConfig.getDestinationsForClassAndAttribute(className, propertyName);
            if ((dataStores != null) && (!(dataStores.isEmpty())))
              return true;
          }
        }
      }
    }

    return false;
  }

  public static String getMappingEngineClassNameByDestinationId(FederationConfig federationConfig, String dataSource)
  {
    ReadOnlyIterator it = federationConfig.getDestinationsConfig();
    while (it.hasNext()) {
      DestinationConfig destinationConfig = (DestinationConfig)it.next();

      if (destinationConfig.getDestinationId().equals(dataSource))
        return getMappingEngineClassNameByDestinationConfig(destinationConfig);
    }

    return null;
  }

  public static String getMappingEngineClassNameByDestinationConfig(DestinationConfig destinationConfig) {
    AdapterConfig adapterConfig = destinationConfig.getAdapterConfig();

    return adapterConfig.getDefaultMappingEngine();
  }

  public static MappingEngine getMappingEngine(String mappingEngineClassName, String srcDataStore, String trgDataStore) {
    DataAccessContainerQueryObtainMappingEngine dataAccessContainerQueryObtainMappingEngine = new DataAccessContainerQueryObtainMappingEngine(mappingEngineClassName, srcDataStore, trgDataStore);
    ServerApiFacade.executeOperation(dataAccessContainerQueryObtainMappingEngine);
    MappingEngine mappingEngine = dataAccessContainerQueryObtainMappingEngine.getMappingEngine();
    if (mappingEngine == null)
      throw new IllegalStateException("The problem with mapping defintion for mappingEngineClassName " + mappingEngineClassName);

    return mappingEngine;
  }

  public static MappingEngine getMappingEngine(String mappingEngineClassName, DestinationConfig destinationConfig) {
    DataAccessContainerQueryObtainMappingEngineByDestinationConfig dataAccessContainerQueryObtainMappingEngine = new DataAccessContainerQueryObtainMappingEngineByDestinationConfig(mappingEngineClassName, destinationConfig);
    ServerApiFacade.executeOperation(dataAccessContainerQueryObtainMappingEngine);
    MappingEngine mappingEngine = dataAccessContainerQueryObtainMappingEngine.getMappingEngine();
    if (mappingEngine == null)
      throw new IllegalStateException("The problem with mapping defintion for mappingEngineClassName " + mappingEngineClassName);

    return mappingEngine;
  }
}