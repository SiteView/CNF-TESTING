package com.mercury.topaz.cmdb.server.fcmdb.ftql.calculation;

import com.mercury.topaz.cmdb.shared.fcmdb.ftql.util.ValidLinkIdentifier;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResult;

public abstract interface FederatedPatternCalculator
{
  public abstract TqlResult calculate(PatternGraph paramPatternGraph, ValidLinkIdentifier paramValidLinkIdentifier, ModelObjects paramModelObjects, PatternLink paramPatternLink, String paramString1, String paramString2, boolean paramBoolean);

  public abstract TqlResult calculate(PatternGraph paramPatternGraph, String paramString);
}