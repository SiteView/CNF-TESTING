package com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassAttributesDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ClassModelDestinationsConfigDelegator;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public class ClassModelDestinationsConfigDelegatorImpl
  implements ClassModelDestinationsConfigDelegator
{
  private ClassModelDestinationsConfig _classModelDestinationsConfig;
  private static Log _log = LogFactory.getEasyLog(ClassModelDestinationsConfigDelegatorImpl.class);

  public ClassModelDestinationsConfigDelegatorImpl(ClassModelDestinationsConfig classModelDestinationsConfig)
  {
    setClassesDestinationsConfig(classModelDestinationsConfig);
  }

  public void setClassesDestinationsConfig(ClassModelDestinationsConfig classModelDestinationsConfig) {
    if (classModelDestinationsConfig == null)
      throw new IllegalArgumentException("classModelDestinationsConfig is null");

    if ((this._classModelDestinationsConfig != null) && (!(this._classModelDestinationsConfig.isEmpty())) && (classModelDestinationsConfig.isEmpty()))
    {
      _log.error("For debug purpose: cleaning all external classes and attributes ", new Exception());
    }
    this._classModelDestinationsConfig = classModelDestinationsConfig;
  }

  public ClassModelDestinationsConfig getClassesDestinationsConfig() {
    return this._classModelDestinationsConfig;
  }

  public Set<String> getAllExternalClasses() {
    return getClassesDestinationsConfig().getAllExternalClasses();
  }

  public Set<String> getAllExternalAttributes(String className) {
    return getClassesDestinationsConfig().getAllExternalAttributes(className);
  }

  public boolean isEmpty() {
    return this._classModelDestinationsConfig.isEmpty();
  }

  public Collection<String> getDestinationsForClass(String className) {
    return getClassesDestinationsConfig().getDestinationsForClass(className);
  }

  public Collection<String> getDestinationsForClassAndAttribute(String className, String attribute) {
    return getClassesDestinationsConfig().getDestinationsForClassAndAttribute(className, attribute);
  }

  public Iterator<ClassDestinationsConfig> getAllClassDestinationsConfig() {
    return getClassesDestinationsConfig().getAllClassDestinationsConfig();
  }

  public Iterator<ClassAttributesDestinationsConfig> getAllClassAttributesDestinationConfig() {
    return getClassesDestinationsConfig().getAllClassAttributesDestinationConfig();
  }

  public ClassAttributesDestinationsConfig getClassAttributeDestinationConfig(String className) {
    return getClassesDestinationsConfig().getClassAttributeDestinationConfig(className);
  }

  public boolean equals(Object o)
  {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    ClassModelDestinationsConfigDelegatorImpl that = (ClassModelDestinationsConfigDelegatorImpl)o;

    if (this._classModelDestinationsConfig != null) if (this._classModelDestinationsConfig.equals(that._classModelDestinationsConfig)) break label62;
    label62: return (that._classModelDestinationsConfig == null);
  }

  public int hashCode()
  {
    return ((this._classModelDestinationsConfig != null) ? this._classModelDestinationsConfig.hashCode() : 0);
  }
}