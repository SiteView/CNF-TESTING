package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.graph.object.ModelObjects;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.impl.EmptyCmdbObjects;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;

public class DataAccessAdapterQueryGetObjectsLayout extends AbstractDataAccessLifeCycleAdapterQuery
{
  private ElementSimpleLayout _objectLayout;
  private ModelObjects _objects;
  private CmdbObjects _outgoingObjects;
  private static final String RESULT_KEY = "result_key";

  public DataAccessAdapterQueryGetObjectsLayout(String destinationId, ElementSimpleLayout objectLayout, ModelObjects objects)
  {
    super(destinationId);
    setObjectLayout(objectLayout);
    setObjects(objects);
  }

  protected StringBuilder getOutputInfo() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("result objects: ").append(getOutgoingObjects());
    return stringBuilder;
  }

  protected StringBuilder getInputInfo() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" destination Id: ").append(getDestinationId()).append(" objects: ").append(getObjects()).append(" layout: ").append(getObjectLayout());
    return stringBuilder;
  }

  protected void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response)
    throws AdapterAccessException
  {
    CmdbObjects resultObjects;
    if ((getObjects() == null) || (getObjects().size() == 0)) {
      resultObjects = EmptyCmdbObjects.getInstance();
    }
    else
      resultObjects = getObjectsLayout(dataAccessManager, getObjects(), getObjectLayout());

    setOutgoingObjects(resultObjects);
    response.addResult("result_key", resultObjects);
  }

  private CmdbObjects getObjectsLayout(DataAccessAdapterManager dataAccessManager, ModelObjects objects, ElementSimpleLayout layout) throws AdapterAccessException {
    BasicDataAdapterWrapper adapterWrapper = getAdapter(dataAccessManager);
    BasicDataAdapter adapter = adapterWrapper.getBasicDataAdapter();
    CalculationStrategy calculationStrategy = getCalculationStrategy(dataAccessManager, adapterWrapper.getAdapterId());
    return calculationStrategy.getObjectsLayout((FTqlDataAdapter)adapter, objects, layout, getDestinationId());
  }

  public String getOperationName()
  {
    return "Data Access Adapter: Get Objects Layout";
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
    setOutgoingObjects((CmdbObjects)response.getResult("result_key"));
  }

  private ElementSimpleLayout getObjectLayout() {
    return this._objectLayout;
  }

  private void setObjectLayout(ElementSimpleLayout objectLayout) {
    this._objectLayout = objectLayout;
  }

  public CmdbObjects getOutgoingObjects()
  {
    return this._outgoingObjects;
  }

  private void setOutgoingObjects(CmdbObjects outgoingObjects) {
    this._outgoingObjects = outgoingObjects;
  }

  private ModelObjects getObjects() {
    return this._objects;
  }

  private void setObjects(ModelObjects objects) {
    this._objects = objects;
  }
}