package com.mercury.topaz.cmdb.server.fcmdb.manage.config.dao;

import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;

public abstract interface FederationConfigReadOnlyDAO
{
  public abstract void startUp();

  public abstract void shutdown();

  public abstract FederationConfig getFederationConfig();
}