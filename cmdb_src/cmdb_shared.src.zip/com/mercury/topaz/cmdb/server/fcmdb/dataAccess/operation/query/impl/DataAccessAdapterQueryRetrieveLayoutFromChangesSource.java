package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.query.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.replication.SourceChangesDataAdapter;
import com.hp.ucmdb.federationspi.data.query.topology.QueryDefinition;
import com.hp.ucmdb.federationspi.data.replication.ReplicationLayoutResultActionData;
import com.hp.ucmdb.federationspi.data.replication.ReplicationTopologyResultActionData;
import com.hp.ucmdb.federationspi.exception.DataAccessException;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessAdapterManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.operation.query.impl.AbstractDataAccessLifeCycleAdapterQuery;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessAdapterQueryRetrieveLayoutFromChangesSource extends AbstractDataAccessLifeCycleAdapterQuery
{
  private static final String RETRIEVE_RESULT = "Retrieve Result";
  private final QueryDefinition _query;
  private final ReplicationTopologyResultActionData _actionData;
  private ReplicationLayoutResultActionData _result;

  public DataAccessAdapterQueryRetrieveLayoutFromChangesSource(String dataStore, QueryDefinition queryDefinition, ReplicationTopologyResultActionData actionData)
  {
    super(dataStore);
    this._query = queryDefinition;
    this._actionData = actionData;
  }

  public String getOperationName() {
    return "DataAccess Query: Retrieve Layout From Changes Source Adapter operation";
  }

  public void doDataAccessQueryExecute(DataAccessAdapterManager dataAccessManager, CmdbResponse response) throws AdapterAccessException, DataAccessException {
    BasicDataAdapter adapter = getAdapter(dataAccessManager).getBasicDataAdapter();
    this._result = ((SourceChangesDataAdapter)adapter).getLayout(getQuery(), getActionData());
    response.addResult("Retrieve Result", this._result);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    this._result = ((ReplicationLayoutResultActionData)response.getResult("Retrieve Result"));
  }

  public ReplicationLayoutResultActionData getResult() {
    return this._result;
  }

  public QueryDefinition getQuery() {
    return this._query;
  }

  public ReplicationTopologyResultActionData getActionData() {
    return this._actionData;
  }

  protected StringBuilder getOutputInfo()
  {
    return new StringBuilder("Result: ").append(this._result);
  }

  protected StringBuilder getInputInfo() {
    return new StringBuilder("Target ID: ").append(getDestinationId()).append(", Pattern Name: ").append(this._query);
  }
}