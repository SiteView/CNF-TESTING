package com.mercury.topaz.cmdb.server.fcmdb.administration.operation.update;

import com.mercury.topaz.cmdb.shared.fcmdb.administration.operation.FederationAdminOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;

public abstract interface FederationAdminUpdate
{
}