package com.mercury.topaz.cmdb.server.fcmdb.manage.config.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.manage.config.ModifiableClassModelDestinationsConfig;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.impl.ClassDestinationsConfigFactory;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager.ConfigUpdateManager;
import com.mercury.topaz.cmdb.server.fcmdb.manage.config.util.ConfigUtil;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.FederationConfig;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.operation.update.impl.AbstractConfigUpdateOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class ConfigUpdateReread extends AbstractConfigUpdateOperation
{
  private static final String RETRIEVE_RESULT = "Retrieve Result";
  private FederationConfig _federationConfig;

  public String getOperationName()
  {
    return "Config Update: Reread";
  }

  public void updateConfigExecute(ConfigUpdateManager configUpdateManager, CmdbResponse cmdbResponse) throws CmdbException {
    FederationConfig prevFederationConfig = getCashedFederationConfig(configUpdateManager);
    configUpdateManager.redeployFederationConfig();
    ModifiableClassModelDestinationsConfig classesDestinationsConfig = ClassDestinationsConfigFactory.createModifiableClassesDestinationsConfig(getClassesDestinationsConfig());
    boolean wasChanged = ConfigUtil.updateClassModelDestinationsConfig(classesDestinationsConfig, prevFederationConfig, getCashedFederationConfig(configUpdateManager));
    if (wasChanged)
      ConfigUtil.updateClassModelDestinationsConfigCache(ClassDestinationsConfigFactory.createReadOnlyClassesDestinationsConfig(classesDestinationsConfig));

    cmdbResponse.addResult("Retrieve Result", getCashedFederationConfig(configUpdateManager));
    updateWithResponse(cmdbResponse);
  }

  public void updateWithResponse(CmdbResponse response) {
    this._federationConfig = ((FederationConfig)response.getResult("Retrieve Result"));
  }

  public FederationConfig getFederationConfig() {
    return this._federationConfig;
  }
}