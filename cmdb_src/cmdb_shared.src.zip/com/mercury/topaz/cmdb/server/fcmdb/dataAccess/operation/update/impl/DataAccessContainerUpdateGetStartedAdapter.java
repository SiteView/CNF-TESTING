package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.operation.update.impl;

import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.BasicDataAdapterWrapper;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.manager.DataAccessContainerManager;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DataAccessContainerUpdateGetStartedAdapter extends AbstractDataAccessContainerUpdate
{
  private BasicDataAdapterWrapper _startedAdapter;
  private String _destinationId;

  public DataAccessContainerUpdateGetStartedAdapter(String destinationId)
  {
    setDestinationId(destinationId); }

  public String getOperationName() {
    return "DataAccessContainerUpdate: Get Started Adapter";
  }

  public void dataAccessContainerExecute(DataAccessContainerManager dataAccessContainerManager, CmdbResponse response) throws AdapterAccessException {
    setStartedAdapter(dataAccessContainerManager.getStartedBasicDataAdapterWrapper(getDestinationId()));
  }

  public String getDestinationId()
  {
    return this._destinationId;
  }

  public void setDestinationId(String destinationId) {
    this._destinationId = destinationId;
  }

  public BasicDataAdapterWrapper getStartedAdapter() {
    return this._startedAdapter;
  }

  private void setStartedAdapter(BasicDataAdapterWrapper startedAdapter) {
    this._startedAdapter = startedAdapter;
  }
}