package com.mercury.topaz.cmdb.server.fcmdb.manage.config.manager;

import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;

public abstract interface ConfigManager extends SubsystemManager
{
}