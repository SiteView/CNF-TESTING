package com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.impl;

import com.hp.ucmdb.federationspi.adapter.BasicDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.FTqlDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.layout.FunctionalLayoutDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.result.SortResultDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.topology.OneNodeDataAdapter;
import com.hp.ucmdb.federationspi.adapter.ftql.topology.PatternDataAdapter;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.CalculationStrategy;
import com.mercury.topaz.cmdb.server.fcmdb.dataAccess.strategy.ResultStrategy;
import com.mercury.topaz.cmdb.shared.fcmdb.dataAccess.exception.AdapterAccessGeneralException;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.AdapterCapabilities;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.PatternTopology;
import com.mercury.topaz.cmdb.shared.fcmdb.manage.config.SupportFederatedQuery;
import java.util.HashMap;
import java.util.Map;

public class AdapterStrategyContext
{
  private OneNodeSupportCalculationStrategy _oneNodeSupportCalculationStrategy;
  private PatternSupportCalculationStrategy _patternSupportCalculationStrategy;
  private FunctionalLayoutSupportCalculationStrategy _functionalLayoutSupportCalculationStrategy;
  private SortInMemoryCalculationStrategy _sortInMemoryCalculationStrategy;
  private SortSupportCalculationStrategy _sortSupportCalculationStrategy;
  private Map<String, CalculationStrategy> _adapterCalculationStrategyMap;
  private Map<String, ResultStrategy> _adapterResultStrategyMap;

  public AdapterStrategyContext()
  {
    this._adapterCalculationStrategyMap = new HashMap();
    this._adapterResultStrategyMap = new HashMap();
    initStrategies();
  }

  private void initStrategies() {
    this._oneNodeSupportCalculationStrategy = new OneNodeSupportCalculationStrategy();
    this._patternSupportCalculationStrategy = new PatternSupportCalculationStrategy();
    this._functionalLayoutSupportCalculationStrategy = new FunctionalLayoutSupportCalculationStrategy();
    this._sortInMemoryCalculationStrategy = new SortInMemoryCalculationStrategy();
    this._sortSupportCalculationStrategy = new SortSupportCalculationStrategy();
  }

  public void addAdapterCapabilities(String adapterId, AdapterCapabilities adapterCapabilities, BasicDataAdapter dataAdapter) {
    if (isAdapterExist(adapterId))
      throw new AdapterAccessGeneralException("The adapter already exists");

    this._adapterCalculationStrategyMap.put(adapterId, getCalculationStrategyForAdapter(adapterCapabilities, dataAdapter));
    this._adapterResultStrategyMap.put(adapterId, getResultStrategyForAdapter(adapterCapabilities, dataAdapter));
  }

  private ResultStrategy getResultStrategyForAdapter(AdapterCapabilities adapterCapabilities, BasicDataAdapter dataAdapter) {
    return getResultStrategyByCapabilities(adapterCapabilities, dataAdapter);
  }

  private ResultStrategy getResultStrategyByCapabilities(AdapterCapabilities adapterCapabilities, BasicDataAdapter dataAdapter)
  {
    if (adapterCapabilities.getSupportFederatedQuery() != null) {
      if (!(dataAdapter instanceof FTqlDataAdapter))
        throw new IllegalStateException("The adapter capabilities of dataAdapter " + dataAdapter.getClass() + "are not compatible for implementation. The adapter doesn't implement FTqlDataAdapter");

      if (adapterCapabilities.getSupportFederatedQuery().isSortResultIsSupported()) {
        if (!(dataAdapter instanceof SortResultDataAdapter))
          throw new IllegalStateException("The adapter capabilities of dataAdapter " + dataAdapter.getClass() + "are not compatible for implementation. The adapter doesn't implement SortResultDataAdapter");

        return this._sortSupportCalculationStrategy;
      }

      return this._sortInMemoryCalculationStrategy;
    }

    return null;
  }

  private CalculationStrategy getCalculationStrategyForAdapter(AdapterCapabilities adapterCapabilities, BasicDataAdapter dataAdapter) {
    if (adapterCapabilities == null)
      throw new AdapterAccessGeneralException("Adapter capabilities is null cannot set Calculation");

    return getCalculationStrategyByCapabilities(adapterCapabilities, dataAdapter);
  }

  private CalculationStrategy getCalculationStrategyByCapabilities(AdapterCapabilities adapterCapabilities, BasicDataAdapter dataAdapter)
  {
    if (adapterCapabilities == null)
      throw new AdapterAccessGeneralException("Adapter capabilities is null cannot set Strategies");

    if (adapterCapabilities.getSupportFederatedQuery() != null) {
      if (!(dataAdapter instanceof FTqlDataAdapter))
        throw new IllegalStateException("The adapter capabilities of dataAdapter " + dataAdapter.getClass() + "are not compatible for implementation. The adapter doesn't implement FTqlDataAdapter");

      if (adapterCapabilities.getSupportFederatedQuery().getPatternTopology() != null) {
        if (!(dataAdapter instanceof PatternDataAdapter))
          throw new IllegalStateException("The adapter capabilities of dataAdapter " + dataAdapter.getClass() + "are not compatible for implementation. The adapter doesn't implement PatternTopologyDataAdapter");

        if (adapterCapabilities.getSupportFederatedQuery().getPatternTopology().isFunctionLayoutSupported()) {
          if (!(dataAdapter instanceof FunctionalLayoutDataAdapter))
            throw new IllegalStateException("The adapter capabilities of dataAdapter " + dataAdapter.getClass() + "are not compatible for implementation. The adapter doesn't implement FunctionalLayoutSupportCalculationStrategy");

          return this._functionalLayoutSupportCalculationStrategy;
        }

        return this._patternSupportCalculationStrategy;
      }

      if (adapterCapabilities.getSupportFederatedQuery().isOneNodeTopologyIsSupported()) {
        if (!(dataAdapter instanceof OneNodeDataAdapter))
          throw new IllegalStateException("The adapter capabilities of dataAdapter " + dataAdapter.getClass() + "are not compatible for implementation. The adapter doesn't implement OneNodeTopologyDataAdapter");

        return this._oneNodeSupportCalculationStrategy;
      }

      throw new IllegalStateException("The adaper capabilities definition is wrong: no OneNode Or Pattern Topology capability");
    }

    return null;
  }

  public CalculationStrategy getCalculationStrategy(String adapterId) {
    CalculationStrategy calculationStrategy = (CalculationStrategy)this._adapterCalculationStrategyMap.get(adapterId);
    if (calculationStrategy == null)
      throw new AdapterAccessGeneralException("the adapter " + adapterId + " has no calculation strategy");

    return calculationStrategy;
  }

  public ResultStrategy getResultStrategy(String adapterId)
  {
    ResultStrategy resultStrategy = (ResultStrategy)this._adapterResultStrategyMap.get(adapterId);
    if (resultStrategy == null)
      throw new AdapterAccessGeneralException("the adapter " + adapterId + " has no result strategy");

    return resultStrategy;
  }

  public boolean isAdapterExist(String adapterId) {
    return this._adapterCalculationStrategyMap.containsKey(adapterId);
  }

  public void removeAdapter(String adapterId) {
    this._adapterCalculationStrategyMap.remove(adapterId);
    this._adapterResultStrategyMap.remove(adapterId);
  }
}