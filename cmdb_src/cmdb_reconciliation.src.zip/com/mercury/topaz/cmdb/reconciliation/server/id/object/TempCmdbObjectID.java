package com.mercury.topaz.cmdb.reconciliation.server.id.object;

import com.mercury.topaz.cmdb.reconciliation.server.id.data.TempCmdbDataID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;

public abstract interface TempCmdbObjectID
{
}