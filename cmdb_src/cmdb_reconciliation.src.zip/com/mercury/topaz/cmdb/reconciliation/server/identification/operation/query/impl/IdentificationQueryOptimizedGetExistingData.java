package com.mercury.topaz.cmdb.reconciliation.server.identification.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl.ReconciliationConfigCacheQueryGetIdentificationLayoutPatternsByLinkType;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl.ReconciliationConfigCacheQueryGetIdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl.ReconciliationConfigCacheQueryGetOwnerByType;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl.DataContainerFactory;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.id.object.TempCmdbObjectID;
import com.mercury.topaz.cmdb.reconciliation.server.identification.manager.IdentificationManager;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl.IDIdentificationRule;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementTypeLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class IdentificationQueryOptimizedGetExistingData extends IdentificationQueryGetExistingData
{
  private boolean _shouldAddLinkEnds;

  public IdentificationQueryOptimizedGetExistingData(DataContainer dataContainer, String dataSource, InputIdToCmdbDatasMapping idToExistingData, boolean shouldAddLinkEnds)
  {
    super(dataContainer, dataSource, idToExistingData);
    this._shouldAddLinkEnds = shouldAddLinkEnds;
  }

  public void identificationQueryExecute(IdentificationManager identificationManager, CmdbResponse response)
  {
    CmdbClassModel classModel = identificationManager.getSynchronizedClassModel();

    DataContainer newDataContainer = createNewDataContainer(classModel);

    runIdentification(response, classModel, newDataContainer);
  }

  private DataContainer createNewDataContainer(CmdbClassModel classModel) {
    Map.Entry entry;
    String type;
    CmdbLinks cmdbLinks;
    CmdbObjects cmdbObjects;
    DataContainer oldDataContainer = getDataContainer();
    DataContainer newDataContainer = DataContainerFactory.createDataContainer();

    if (this._shouldAddLinkEnds) {
      for (iteratorByType = oldDataContainer.getLinksForUpdateIteratorByType(); iteratorByType.hasNext(); ) {
        entry = (Map.Entry)iteratorByType.next();
        type = (String)entry.getKey();
        cmdbLinks = (CmdbLinks)entry.getValue();
        addLinksEnds(classModel, type, cmdbLinks);
      }

    }

    for (Iterator iteratorByType = oldDataContainer.getObjectsForUpdateIteratorByType(); iteratorByType.hasNext(); ) {
      entry = (Map.Entry)iteratorByType.next();
      type = (String)entry.getKey();
      cmdbObjects = (CmdbObjects)entry.getValue();
      addObjectTypeToNewDataContainer(newDataContainer, type, cmdbObjects);
    }

    for (iteratorByType = oldDataContainer.getReferencedObjectsIteratorByType(); iteratorByType.hasNext(); ) {
      entry = (Map.Entry)iteratorByType.next();
      type = (String)entry.getKey();
      cmdbObjects = (CmdbObjects)entry.getValue();
      addObjectTypeToNewDataContainer(newDataContainer, type, cmdbObjects);
    }

    for (iteratorByType = oldDataContainer.getLinksForUpdateIteratorByType(); iteratorByType.hasNext(); ) {
      entry = (Map.Entry)iteratorByType.next();
      type = (String)entry.getKey();
      cmdbLinks = (CmdbLinks)entry.getValue();
      addLinkTypeToNewDataContainer(newDataContainer, type, cmdbLinks);
    }

    for (iteratorByType = oldDataContainer.getReferencedLinksIteratorByType(); iteratorByType.hasNext(); ) {
      entry = (Map.Entry)iteratorByType.next();
      type = (String)entry.getKey();
      cmdbLinks = (CmdbLinks)entry.getValue();
      addLinkTypeToNewDataContainer(newDataContainer, type, cmdbLinks);
    }

    addContainerObjects(newDataContainer);

    return newDataContainer;
  }

  private void addObjectTypeToNewDataContainer(DataContainer newDataContainer, String type, CmdbObjects cmdbObjects) {
    Iterator i$;
    CmdbObject object;
    if (shouldIdentify(type))
      for (i$ = cmdbObjects.iterator(); i$.hasNext(); ) { object = (CmdbObject)i$.next();
        newDataContainer.addObjectForUpdate(object);
      }
    else
      for (i$ = cmdbObjects.iterator(); i$.hasNext(); ) { object = (CmdbObject)i$.next();
        newDataContainer.addReferencedObject(object);
      }
  }

  private void addLinkTypeToNewDataContainer(DataContainer newDataContainer, String type, CmdbLinks cmdbLinks)
  {
    Iterator i$;
    CmdbLink link;
    if (shouldIdentify(type))
      for (i$ = cmdbLinks.iterator(); i$.hasNext(); ) { link = (CmdbLink)i$.next();
        newDataContainer.addLinkForUpdate(link);
      }
    else
      for (i$ = cmdbLinks.iterator(); i$.hasNext(); ) { link = (CmdbLink)i$.next();
        newDataContainer.addReferencedLink(link);
      }
  }

  private void addLinksEnds(CmdbClassModel classModel, String type, CmdbLinks cmdbLinks)
  {
    ReconciliationConfigCacheQueryGetIdentificationLayoutPatternsByLinkType getPatterns = new ReconciliationConfigCacheQueryGetIdentificationLayoutPatternsByLinkType(type);
    ServerApiFacade.executeOperation(getPatterns);

    Collection patterns = getPatterns.getLayoutPatterns();
    if (!(patterns.isEmpty()))
    {
      Map layoutMap = new HashMap();
      for (Iterator i$ = patterns.iterator(); i$.hasNext(); ) { Pattern pattern = (Pattern)i$.next();
        PatternLayout patternlayout = pattern.getLayout();
        ReadOnlyIterator it = pattern.getPatternGraph().getNodeNumbersIterator();
        while (it.hasNext()) {
          PatternElementNumber number = (PatternElementNumber)it.next();
          String nodeType = pattern.getPatternGraph().getNode(number).getCondition().getClassCondition().getClassName();
          addLayoutToMap(classModel, layoutMap, patternlayout.getElementLayout(number), nodeType);
        }

      }

      ElementTypeLayout layout = PatternLayoutFactory.createTypeLayout();
      for (Iterator i$ = layoutMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry currentLayoutEntry = (Map.Entry)i$.next();
        layout.addSimpleLayout((String)currentLayoutEntry.getKey(), (ElementSimpleLayout)currentLayoutEntry.getValue());
      }

      CmdbObjectIds idsForLayout = CmdbObjectIdsFactory.create();
      for (Iterator i$ = cmdbLinks.iterator(); i$.hasNext(); ) { CmdbLink currentLink = (CmdbLink)i$.next();
        addEndIDIfNeeded(classModel, idsForLayout, currentLink.getEnd1(), layout);
        addEndIDIfNeeded(classModel, idsForLayout, currentLink.getEnd2(), layout);
      }

      if (!(idsForLayout.isEmpty()))
      {
        CmdbObjects foundObjects = getObjectsByIDs(idsForLayout, layout);
        for (Iterator i$ = foundObjects.iterator(); i$.hasNext(); ) { CmdbObject objectFromCmdb = (CmdbObject)i$.next();
          CmdbObject objectFromDataContainer = getDataContainer().getCmdbObject((CmdbObjectID)objectFromCmdb.getID());
          CmdbObject objectWithAllNeededProperties = mergeObjects(objectFromDataContainer, objectFromCmdb);
          getDataContainer().addObjectForUpdate(objectWithAllNeededProperties);
        }
      }
    }
  }

  private void addLayoutToMap(CmdbClassModel classModel, Map<String, ElementSimpleLayout> layoutMap, ElementLayout layout, String nodeType)
  {
    if (layout instanceof ElementTypeLayout) {
      ReadOnlyIterator types = ((ElementTypeLayout)layout).getTypes();
      while (types.hasNext()) {
        String type = (String)types.next();
        addSimpleLayoutToMap(layoutMap, ((ElementTypeLayout)layout).getTypeLayout(type, classModel), type);
      }
    }
    else if (layout instanceof ElementSimpleLayout) {
      addSimpleLayoutToMap(layoutMap, layout, nodeType);
    }
  }

  private void addSimpleLayoutToMap(Map<String, ElementSimpleLayout> layoutMap, ElementLayout layout, String type) {
    ElementSimpleLayout prevLayout = (ElementSimpleLayout)layoutMap.get(type);
    if (prevLayout == null) {
      prevLayout = PatternLayoutFactory.createElementSimpleLayout();
      layoutMap.put(type, prevLayout);
    }
    prevLayout.addLayout(layout);
  }

  private CmdbObject mergeObjects(CmdbObject strongObject, CmdbObject weakObject) {
    CmdbProperty property;
    if (strongObject == null)
      return weakObject;

    if (weakObject == null)
      return strongObject;

    CmdbProperties properties = CmdbPropertyFactory.createProperties(strongObject.getPropertiesAmount() + weakObject.getPropertiesAmount());
    for (Iterator i$ = weakObject.getUnmodifiableProperties().iterator(); i$.hasNext(); ) { property = (CmdbProperty)i$.next();
      properties.add(property);
    }
    for (i$ = strongObject.getUnmodifiableProperties().iterator(); i$.hasNext(); ) { property = (CmdbProperty)i$.next();
      properties.add(property);
    }
    return CmdbObjectFactory.createObject((CmdbObjectID)strongObject.getID(), strongObject.getType(), properties);
  }

  private CmdbObjects getObjectsByIDs(CmdbObjectIds idsForLayout, ElementTypeLayout layout) {
    PatternElementNumber number = PatternElementNumberFactory.createElementNumber(1000);
    ElementClassCondition classCondition = PatternConditionFactory.createElementClassCondition("object", true);
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(classCondition, null, idsForLayout);
    PatternNode patternNode = PatternGraphFactory.createPatternNode(number, elementCondition, true, null);
    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(patternNode);
    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("linkEndsPattern", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);
    PatternLayout nodeLayout = PatternLayoutFactory.createLayout();
    nodeLayout.setElementLayout(number, layout);
    TqlQueryGetAdHocMap runTql = new TqlQueryGetAdHocMap(pattern, nodeLayout);
    ServerApiFacade.executeOperation(runTql);
    TqlResultMap tqlResultMap = (runTql.isDividedToChunks()) ? DataInUtil.getResultInChunks(runTql.getChunkRequest()) : runTql.getResultMap();
    if (tqlResultMap.containsElementNumber(number))
      return tqlResultMap.getObjects(number);

    return CmdbObjectFactory.createObjects();
  }

  private void addEndIDIfNeeded(CmdbClassModel classModel, CmdbObjectIds idsForLayout, CmdbObjectID idToCheck, ElementTypeLayout layout) {
    if (getDataContainer().containsObjectForUpdate(idToCheck))
      return;

    if (getDataContainer().containsReferencedObject(idToCheck))
      if (!(idToCheck instanceof TempCmdbObjectID)) {
        CmdbObject referencedObject = getDataContainer().getReferencedObject(idToCheck);
        ElementLayout layoutForRef = layout.getTypeLayout(referencedObject.getType(), classModel);

        ReadOnlyIterator keysIt = layoutForRef.getKeysIterator();
        do if (!(keysIt.hasNext())) break label112;
        while (referencedObject.getProperty((String)keysIt.next()) != null);
        idsForLayout.add(idToCheck);

        label112: getDataContainer().addObjectForUpdate(referencedObject);
      }

    else
      idsForLayout.add(idToCheck);
  }

  private boolean shouldIdentify(String type)
  {
    Collection rules = getRule(type);
    return (((!(rules.isEmpty())) && (!(isIdIdentificationRule(rules)))) || (hasOwnerConfiguration(type)));
  }

  private boolean isIdIdentificationRule(Collection<IdentificationRule> rule) {
    return ((rule.size() == 1) && (rule.iterator().next() instanceof IDIdentificationRule));
  }

  private boolean hasOwnerConfiguration(String type) {
    ReconciliationConfigCacheQueryGetOwnerByType getOwner = new ReconciliationConfigCacheQueryGetOwnerByType(type);
    ServerApiFacade.executeOperation(getOwner);
    return (!(((Collection)getOwner.getOwnerByTypeMap().get(type)).isEmpty()));
  }

  private Collection<IdentificationRule> getRule(String type) {
    ReconciliationConfigCacheQueryGetIdentificationRule getRule = new ReconciliationConfigCacheQueryGetIdentificationRule(type);
    ServerApiFacade.executeOperation(getRule);
    return getRule.getIdentificationRule();
  }

  public String getOperationName() {
    return "Identification Query - Optimized Get Existing Data";
  }

  private void addContainerObjects(DataContainer dataContainer) {
    Map toStringIdToObjectReferenceMap = new HashMap(dataContainer.getReferencedObjectsSize());
    Iterator objectsIt = dataContainer.getReferencedObjectsIterator();
    while (objectsIt.hasNext()) {
      CmdbObject object = (CmdbObject)objectsIt.next();
      toStringIdToObjectReferenceMap.put(((CmdbObjectID)object.getID()).toString(), object);
    }

    findContainedObjectsThatAreNotForUpdate(dataContainer, dataContainer.getObjectsForUpdateIterator(), null, toStringIdToObjectReferenceMap);
  }

  private void findContainedObjectsThatAreNotForUpdate(DataContainer dataContainer, Iterator<CmdbObject> objectsIt, CmdbObjects objectsToMove, Map<String, CmdbObject> toStringIdToObjectIdMap)
  {
    if (objectsToMove == null) {
      objectsToMove = CmdbObjectFactory.createObjects();
    }
    else if (objectsToMove.isEmpty()) {
      return;
    }

    objectsToMove.clear();
    while (objectsIt.hasNext()) {
      CmdbObject object = (CmdbObject)objectsIt.next();
      CmdbProperty cmdbProperty = object.getProperty("root_container");
      if ((cmdbProperty != null) && (!(cmdbProperty.isValueEmpty()))) {
        String rootContainerAsString = (String)cmdbProperty.getValue();
        if (toStringIdToObjectIdMap.containsKey(rootContainerAsString))
          objectsToMove.add((CmdbData)toStringIdToObjectIdMap.get(rootContainerAsString));

      }

    }

    for (Iterator i$ = objectsToMove.iterator(); i$.hasNext(); ) { CmdbObject objFromRef = (CmdbObject)i$.next();
      if (objFromRef != null)
        dataContainer.addObjectForUpdate(objFromRef);
    }

    findContainedObjectsThatAreNotForUpdate(dataContainer, objectsToMove.iterator(), objectsToMove, toStringIdToObjectIdMap);
  }
}