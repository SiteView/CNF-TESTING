package com.mercury.topaz.cmdb.reconciliation.server.id.link.impl;

import com.mercury.topaz.cmdb.reconciliation.server.id.link.TempCmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.id.impl.CmdbRandomID;

public class TempLinkIDFactory
{
  public static TempCmdbLinkID createTempLinkID(String id)
  {
    return new TempCmdbLinkIDImpl(id); }

  public static TempCmdbLinkID createTempLinkID() {
    return new TempCmdbLinkIDImpl(CmdbRandomID.getRandomString());
  }
}