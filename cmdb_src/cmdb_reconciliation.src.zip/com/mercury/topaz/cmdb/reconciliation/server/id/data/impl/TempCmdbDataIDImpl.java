package com.mercury.topaz.cmdb.reconciliation.server.id.data.impl;

import com.mercury.topaz.cmdb.reconciliation.server.id.data.TempCmdbDataID;

public abstract class TempCmdbDataIDImpl
  implements TempCmdbDataID
{
  private String _id;

  protected TempCmdbDataIDImpl(String id)
  {
    setId(id);
  }

  protected String getId() {
    return this._id;
  }

  private void setId(String id) {
    if (id == null)
      throw new IllegalArgumentException("id is null");

    this._id = id;
  }

  public String toString() {
    return getId();
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    TempCmdbDataIDImpl that = (TempCmdbDataIDImpl)o;

    if (this._id != null) if (this._id.equals(that._id)) break label62;
    label62: return (that._id == null);
  }

  public int hashCode()
  {
    return ((this._id != null) ? this._id.hashCode() : 0);
  }

  public boolean isExternal() {
    throw new UnsupportedOperationException();
  }
}