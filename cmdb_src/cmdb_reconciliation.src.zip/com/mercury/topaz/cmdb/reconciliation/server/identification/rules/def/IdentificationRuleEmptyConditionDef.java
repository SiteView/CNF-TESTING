package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

public class IdentificationRuleEmptyConditionDef extends AbstractIdentificationRuleConditionDef
{
  private static final IdentificationRuleEmptyConditionDef _instance = new IdentificationRuleEmptyConditionDef();

  public static IdentificationRuleEmptyConditionDef instance()
  {
    return _instance;
  }

  public void accept(IdentificationRuleConditionDefVisitor visitor)
  {
    visitor.visit(this);
  }
}