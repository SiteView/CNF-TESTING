package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

class GeneralUtils
{
  public static <Type> boolean equals(Type o1, Type o2)
  {
    return ((o1 == o2) || ((o1 != null) && (o1.equals(o2))));
  }

  public static <Type> Collection<Collection<Type>> getAllPermutations(Collection<? extends Collection<Type>> input) {
    int numberOfPermutations = getNumberOfPermutations(input);
    if (numberOfPermutations < 1) {
      return Collections.emptyList();
    }

    Collection ans = new ArrayList(numberOfPermutations);

    for (int i = 0; i < numberOfPermutations; ++i) {
      ans.add(new ArrayList(input.size()));
    }

    Iterator inputIter = input.iterator();

    Collection firstList = (Collection)inputIter.next();
    Iterator ansIter = ans.iterator();
    for (Iterator i$ = firstList.iterator(); i$.hasNext(); ) { Object type = i$.next();
      ((Collection)ansIter.next()).add(type);
    }
    int ansSize = firstList.size();

    while (inputIter.hasNext()) {
      Collection currentInputColl = (Collection)inputIter.next();
      int ansPrevSize = ansSize;
      ansSize = multiplyContent(ans, ansSize, currentInputColl.size());

      Iterator ansIter = ans.iterator();
      for (Iterator i$ = currentInputColl.iterator(); i$.hasNext(); ) { Object currentType = i$.next();
        for (int k = 0; k < ansPrevSize; ++k)
          ((Collection)ansIter.next()).add(currentType);
      }

    }

    return ans;
  }

  private static <Type> int multiplyContent(Collection<Collection<Type>> collections, int collectionSize, int numberOfTimes) {
    if (numberOfTimes < 1) {
      collections.clear();
      return 0;
    }

    ArrayList originalCollection = new ArrayList(collectionSize);

    Iterator collectionIterator = collections.iterator();
    for (int i = 0; i < collectionSize; ++i) {
      originalCollection.add(collectionIterator.next());
    }

    collectionIterator = collections.iterator();

    for (i = 0; i < collectionSize; ++i)
      collectionIterator.next();

    for (i = 1; i < numberOfTimes; ++i)
      for (Iterator i$ = originalCollection.iterator(); i$.hasNext(); ) { Collection collection = (Collection)i$.next();
        ((Collection)collectionIterator.next()).addAll(collection);
      }

    return (collectionSize * numberOfTimes);
  }

  public static <Type> int getNumberOfPermutations(Collection<? extends Collection<Type>> input) {
    if (input.isEmpty()) {
      return 0;
    }

    int numberOfPermutations = 1;
    for (Iterator i$ = input.iterator(); i$.hasNext(); ) { Collection col = (Collection)i$.next();
      numberOfPermutations *= col.size();
    }
    return numberOfPermutations;
  }
}