package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelExternalUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.OptimisticModelUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModelUpdateBulkInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModifiableModelUpdateBulkInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.impl.CmdbModelUpdateBulkInfoFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsIfExist;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public abstract class AbstractDataInOptimisticUpdateOperation extends AbstractDataInUpdateDataOperation
{
  private ModelUpdateBulksOptimistic _updateBulk;

  protected AbstractDataInOptimisticUpdateOperation(DataContainer dataContainer, Changer changer)
  {
    super(dataContainer, changer);
  }

  protected void addToModelUpdateOperations(List<? extends ModelUpdate> modelUpdateOperations) {
    if ((!(modelUpdateOperations.isEmpty())) && (getUpdateBulk() == null)) {
      setUpdateBulk(new ModelUpdateBulksOptimistic(getChanger()));
    }

    for (Iterator i$ = modelUpdateOperations.iterator(); i$.hasNext(); ) { OptimisticModelUpdate modelUpdateOperation = (OptimisticModelUpdate)i$.next();
      getUpdateBulk().addOptimisticModelUpdateOperation(modelUpdateOperation);
    }
  }

  protected ModelExternalUpdate getModelUpdateOperation() {
    return getUpdateBulk();
  }

  protected CmdbModelUpdateBulkInfo sendToModelUpdate(DataInManager dataInManager) {
    if (getUpdateBulk() != null)
    {
      dataInManager.executeOperation(getUpdateBulk());
      return getUpdateBulk().getModelUpdateBulkInfo();
    }
    return CmdbModelUpdateBulkInfoFactory.create().getCmdbModelUpdateBulkInfo();
  }

  protected List<? extends ModelUpdate> createModelUpdateOperations(CmdbObjectIds idsToRemove)
  {
    return Arrays.asList(new OptimisticModelUpdate[] { new ModelUpdateRemoveObjectsIfExist(idsToRemove, getChanger()) });
  }

  private ModelUpdateBulksOptimistic getUpdateBulk() {
    return this._updateBulk;
  }

  private void setUpdateBulk(ModelUpdateBulksOptimistic updateBulk) {
    this._updateBulk = updateBulk;
  }
}