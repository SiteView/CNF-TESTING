package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl;

import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;

public abstract class IDIdentificationRule
  implements IdentificationRule
{
  public Pattern getLayoutPattern(String type, PatternElementNumber nodeElementNumber)
  {
    return null;
  }
}