package com.mercury.topaz.cmdb.reconciliation.server.datain.util;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import java.util.Collection;

abstract class TempMergeInput<Type extends CmdbData>
{
  private final Type _remainingObject;
  private final Collection<Type> _datasFromCmdb;

  public TempMergeInput(Type remainingObject, Collection<Type> datasFromCmdb)
  {
    this._remainingObject = remainingObject;
    this._datasFromCmdb = datasFromCmdb;
  }

  public Type getRemainingObject() {
    return this._remainingObject;
  }

  public Collection<Type> getDatasFromCmdb() {
    return this._datasFromCmdb;
  }
}