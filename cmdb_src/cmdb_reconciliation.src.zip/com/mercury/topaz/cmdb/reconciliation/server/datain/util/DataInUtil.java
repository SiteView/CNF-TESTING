package com.mercury.topaz.cmdb.reconciliation.server.datain.util;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.exception.DataInException;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInErrorInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInMergePropertiesInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInMergeTopologyInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInResolvedInfo;
import com.mercury.topaz.cmdb.reconciliation.server.id.link.TempCmdbLinkID;
import com.mercury.topaz.cmdb.reconciliation.server.id.object.TempCmdbObjectID;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.impl.MergeInputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.command.impl.MergeCIsPropertiesOperation;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.command.impl.MergeRelationshipsPropertiesOperation;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl.MergeTopologyOutput;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl.MergeTopologyQueryOperation;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl.PatternCreator;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ModelUtil;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ReconciliationLogs;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkIds;
import com.mercury.topaz.cmdb.shared.model.link.id.impl.CmdbLinkIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModelUpdateBulkInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModifiableModelUpdateBulkInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbUpdatedLinksInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbUpdatedModelDataInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbUpdatedObjectsInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.impl.CmdbModelUpdateBulkInfoFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.DefaultLinksDictionary;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocCmdbMap;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultMapChunk;
import com.mercury.topaz.cmdb.shared.tql.result.TqlModifiableResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.chunk.ChunkRequest;
import com.mercury.topaz.cmdb.shared.tql.result.impl.TqlResultFactory;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultMapUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DataInUtil
{
  public static Map<CmdbObject, CmdbObject> mergeCIProperties(Collection<TempMergePropertiesInput<CmdbObject>> tempInput, Set<String> isOwnerByType, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs, List<DataInInfo> info)
  {
    if (tempInput.isEmpty())
      return Collections.emptyMap();

    Set updatedByOwnerObjects = getIsUpdatedByOwnerForObjects(tempInput, isOwnerByType);

    Collection input = createMergeInput(tempInput, isOwnerByType, updatedByOwnerObjects, inputIDAsStringToReconciledIDs);

    MergeCIsPropertiesOperation merge = new MergeCIsPropertiesOperation(input);
    try {
      ServerApiFacade.executeOperation(merge);
    }
    catch (Exception e) {
      String errorMsg = "Error occured while trying to Merge CI properties. Input: " + input;
      info.add(new DataInErrorInfo(errorMsg));
      throw new DataInException(errorMsg, e);
    }
    Map result = merge.getResult();

    for (Iterator i$ = input.iterator(); i$.hasNext(); ) { MergeInput anInput = (MergeInput)i$.next();
      CmdbObject resultData = (CmdbObject)result.get(anInput.getUpdatingData());
      DataInMergePropertiesInfo mergeInfo = new DataInMergePropertiesInfo(anInput.getUpdatingData(), anInput.getDatasToMerge(), resultData);
      info.add(mergeInfo);
    }
    return result;
  }

  public static Map<CmdbLink, CmdbLink> mergeRelationsProperties(Collection<TempMergePropertiesInput<CmdbLink>> tempInput, Set<String> isOwnerByType, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs, List<DataInInfo> info) {
    Set updatedByOwnerLinks = getIsUpdatedByOwnerForLinks(tempInput, isOwnerByType);

    Collection input = createMergeInput(tempInput, isOwnerByType, updatedByOwnerLinks, inputIDAsStringToReconciledIDs);

    MergeRelationshipsPropertiesOperation merge = new MergeRelationshipsPropertiesOperation(input);
    try {
      ServerApiFacade.executeOperation(merge);
    }
    catch (Exception e) {
      String errorMsg = "Error occured while trying to Merge Relation properties. Input: " + input;
      info.add(new DataInErrorInfo(errorMsg));
      throw new DataInException(errorMsg, e);
    }
    Map result = merge.getResult();

    for (Iterator i$ = input.iterator(); i$.hasNext(); ) { MergeInput anInput = (MergeInput)i$.next();
      CmdbLink resultData = (CmdbLink)result.get(anInput.getUpdatingData());
      DataInMergePropertiesInfo mergeInfo = new DataInMergePropertiesInfo(anInput.getUpdatingData(), anInput.getDatasToMerge(), resultData);
      info.add(mergeInfo);
    }
    return result;
  }

  private static <Type extends CmdbData> Collection<MergeInput<Type>> createMergeInput(Collection<TempMergePropertiesInput<Type>> tempInput, Set<String> isOwnerByType, Set<? extends CmdbDataID> updatedByOwnerObjects, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs) {
    Collection input = new ArrayList(tempInput.size());
    Map tempInputIDAsStringToReconciledIDs = new HashMap();
    for (Iterator i$ = tempInput.iterator(); i$.hasNext(); ) { TempMergePropertiesInput mergePropertiesInput = (TempMergePropertiesInput)i$.next();
      inputIDAsStringToReconciledIDs.remove(mergePropertiesInput.getRemainingObject().getDataID().toString());
      updateExistingDataMap(tempInputIDAsStringToReconciledIDs, mergePropertiesInput);

      Collection objectsFromCmdb = mergePropertiesInput.getDatasFromCmdb();
      Collection objectsFromBulk = mergePropertiesInput.getDatasFromBulk();
      CmdbData remainingObject = mergePropertiesInput.getRemainingObject();

      Collection mergePropertiesInputObjects = new ArrayList(objectsFromCmdb.size() + objectsFromBulk.size());
      mergePropertiesInputObjects.addAll(objectsFromCmdb);

      if ((isOwnerByType.contains(remainingObject.getType())) || (!(containsObjectUpdatedByOwner(objectsFromCmdb, updatedByOwnerObjects)))) {
        mergePropertiesInputObjects.addAll(objectsFromBulk);
        MergeInput mergeInput = MergeInputFactory.createMergeInput(mergePropertiesInputObjects, remainingObject);
        if (!(input.contains(mergeInput))) {
          input.add(mergeInput);
        }

      }
      else if (ReconciliationLogs.getReconciliationLog().isDebugEnabled()) {
        StringBuilder msg = new StringBuilder("Data wasn't updated in cmdb because the changer isn't the owner and the data in cmdb was already updated by the owner: ");
        msg.append("\n\t\tData In Bulk: ").append(objectsFromBulk);
        msg.append("\n\t\tData In Cmdb: ").append(objectsFromCmdb);
        ReconciliationLogs.getReconciliationLog().debug(msg);
      }
    }

    inputIDAsStringToReconciledIDs.putAll(tempInputIDAsStringToReconciledIDs);
    return input;
  }

  private static <Type extends CmdbData> boolean containsObjectUpdatedByOwner(Collection<Type> objectsFromCmdb, Set<? extends CmdbDataID> updatedByOwnerObjects) {
    for (Iterator i$ = objectsFromCmdb.iterator(); i$.hasNext(); ) { CmdbData currObjectFromCmdb = (CmdbData)i$.next();

      if (updatedByOwnerObjects.contains(currObjectFromCmdb.getDataID()))
        return true;
    }

    return false;
  }

  private static void fillCollectionOfLinkIdsToCheck(Collection<TempMergePropertiesInput<CmdbLink>> tempInput, CmdbLinkIds idsToCheck, Set<String> isOwnerByType) {
    for (Iterator i$ = tempInput.iterator(); i$.hasNext(); ) { TempMergePropertiesInput mergePropertiesInput = (TempMergePropertiesInput)i$.next();
      Collection datasFromCmdb = mergePropertiesInput.getDatasFromCmdb();
      for (Iterator i$ = datasFromCmdb.iterator(); i$.hasNext(); ) { CmdbData dataFromCmdb = (CmdbLink)i$.next();
        if (!(isOwnerByType.contains(dataFromCmdb.getType())))
          idsToCheck.add((CmdbLinkID)dataFromCmdb.getDataID());
      }
    }
  }

  private static void fillCollectionOfObjectIdsToCheck(Collection<TempMergePropertiesInput<CmdbObject>> tempInput, CmdbObjectIds idsToCheck, Set<String> isOwnerByType)
  {
    for (Iterator i$ = tempInput.iterator(); i$.hasNext(); ) { TempMergePropertiesInput mergePropertiesInput = (TempMergePropertiesInput)i$.next();
      Collection datasFromCmdb = mergePropertiesInput.getDatasFromCmdb();
      for (Iterator i$ = datasFromCmdb.iterator(); i$.hasNext(); ) { CmdbData dataFromCmdb = (CmdbObject)i$.next();
        if (!(isOwnerByType.contains(dataFromCmdb.getType())))
          idsToCheck.add((CmdbObjectID)dataFromCmdb.getDataID());
      }
    }
  }

  public static Map<CmdbObjectID, MergeTopologyOutput> mergeTopology(List<MergeInput<CmdbObject>> input, List<DataInInfo> info, Map<CmdbDataID, CmdbDataID> idChangesMap, PatternCreator patternCreator, boolean shouldRemoveMainNode)
  {
    return mergeTopology(input, info, idChangesMap, new MergeTopologyAdvancedType(patternCreator, shouldRemoveMainNode));
  }

  public static Map<CmdbObjectID, MergeTopologyOutput> mergeTopology(List<MergeInput<CmdbObject>> input, List<DataInInfo> info, Map<CmdbDataID, CmdbDataID> idChangesMap) {
    return mergeTopology(input, info, idChangesMap, new MergeFullTopologyType(null));
  }

  private static Map<CmdbObjectID, MergeTopologyOutput> mergeTopology(List<MergeInput<CmdbObject>> input, List<DataInInfo> info, Map<CmdbDataID, CmdbDataID> idChangesMap, MergeTopologyType mergeTopologyType) {
    if (input.isEmpty())
      return Collections.emptyMap();

    MergeTopologyQueryOperation merge = mergeTopologyType.createOperation(input);
    try {
      ServerApiFacade.executeOperation(merge);
    } catch (Exception e) {
      String errorMsg = "Error occured while trying to Merge Topology. Input: " + input;
      info.add(new DataInErrorInfo(errorMsg));
      throw new DataInException(errorMsg, e);
    }
    Map mergeTopologyOutputs = merge.getOutput();

    for (Iterator i$ = input.iterator(); i$.hasNext(); ) { MergeInput anInput = (MergeInput)i$.next();
      MergeTopologyOutput mergeTopologyOutput = (MergeTopologyOutput)mergeTopologyOutputs.get(((CmdbObject)anInput.getUpdatingData()).getID());
      DataInMergeTopologyInfo mergeInfo = new DataInMergeTopologyInfo((CmdbObject)anInput.getUpdatingData(), anInput.getDatasToMerge(), mergeTopologyOutput.getObjectsToRemove(), mergeTopologyOutput.getObjectsToAdd(), mergeTopologyOutput.getLinksToRemove(), mergeTopologyOutput.getLinksToAdd());
      info.add(mergeInfo);
    }

    if (null != idChangesMap) {
      idChangesMap.putAll(merge.getOldToNewObjectMap());
    }

    return mergeTopologyOutputs;
  }

  public static CmdbDatas<? extends CmdbDataID, ? extends CmdbData> resolveCmdbData(DataFactory dataFactory, CmdbData dataToResolve, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs, Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDs, List<DataInInfo> info) {
    try {
      if (dataToResolve.getDataID().isObjectID())
        return resolveCmdbData(dataFactory, (CmdbObject)dataToResolve, inputIDAsStringToReconciledIDs, inputIDToReconciledIDs, info);

      return resolveCmdbData(dataFactory, (CmdbLink)dataToResolve, inputIDAsStringToReconciledIDs, inputIDToReconciledIDs, info);
    }
    catch (Exception e) {
      String errorMsg = "Error occured while trying to resolve Data: " + dataToResolve;
      info.add(new DataInErrorInfo(errorMsg));
      throw new DataInException(errorMsg, e);
    }
  }

  private static boolean shouldResolve(CmdbDataID id, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs) {
    String idToResolve = id.toString();
    return ((!(inputIDAsStringToReconciledIDs.containsKey(idToResolve))) || ((inputIDAsStringToReconciledIDs.get(idToResolve) != null) && (!(((CmdbDataIDs)inputIDAsStringToReconciledIDs.get(idToResolve)).isEmpty()))));
  }

  public static CmdbObjects resolveCmdbData(DataFactory dataFactory, CmdbObject dataToResolve, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs, Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDs, List<DataInInfo> info)
  {
    CmdbObjects updatedObjects = CmdbObjectFactory.createObjects();

    if (!(shouldResolve((CmdbDataID)dataToResolve.getID(), inputIDAsStringToReconciledIDs))) {
      return updatedObjects;
    }

    CmdbClassModel cmdbClassModel = dataFactory.getClassModel();
    boolean isDataToResolveHasTempId = dataToResolve.getID() instanceof TempCmdbObjectID;
    if (ModelUtil.isContainedInObject(dataToResolve, cmdbClassModel)) {
      Collection containedInProps = ModelUtil.getContainedByProperties(dataToResolve, cmdbClassModel);
      if (containedInProps.size() != 1)
        throw new DataInException("DataInUtil does not support a more then 1 containers! found: " + containedInProps);

      CmdbProperty containedInProp = (CmdbProperty)containedInProps.iterator().next();
      String value = (String)containedInProp.getValue();
      if (inputIDAsStringToReconciledIDs.containsKey(value)) {
        CmdbDataIDs updatedObjectIds = CmdbDataIdsFactory.create();

        CmdbDataIDs updatedContainerIDs = (CmdbDataIDs)inputIDAsStringToReconciledIDs.get(value);
        ReadOnlyIterator it = updatedContainerIDs.getIdsIterator();
        while (it.hasNext()) {
          CmdbObjectID updatedContainerID = (CmdbObjectID)it.next();
          CmdbProperty updatedContainedInProp = CmdbPropertyFactory.createProperty(containedInProp.getKey(), updatedContainerID.toString());
          CmdbProperties updatedProps = ModelUtil.copyProperties(dataToResolve);
          updatedProps.remove(containedInProp.getKey());
          updatedProps.add(updatedContainedInProp);
          CmdbObject updatedObject = dataFactory.createObject(dataToResolve.getType(), updatedProps);
          updatedObjects.add(updatedObject);
          addResolvedDataInfo(dataToResolve, updatedObject, info);
          updatedObjectIds.add((CmdbDataID)updatedObject.getID());
        }
        inputIDAsStringToReconciledIDs.put(((CmdbObjectID)dataToResolve.getID()).toString(), updatedObjectIds);
        if ((inputIDToReconciledIDs != null) && (((updatedObjectIds.size() != 1) || (!(((CmdbDataID)updatedObjectIds.getIdsIterator().next()).equals(dataToResolve.getDataID()))))))
          inputIDToReconciledIDs.put(dataToResolve.getID(), updatedObjectIds);
      }
    }

    if (updatedObjects.isEmpty())
      if (isDataToResolveHasTempId) {
        CmdbObject updatedObject = dataFactory.createObject(dataToResolve.getType(), dataToResolve.getUnmodifiableProperties());
        updatedObjects.add(updatedObject);
        addResolvedDataInfo(dataToResolve, updatedObject, info);
        CmdbDataIDs updatedObjectIds = CmdbDataIdsFactory.create();
        updatedObjectIds.add((CmdbDataID)updatedObject.getID());
        inputIDAsStringToReconciledIDs.put(((CmdbObjectID)dataToResolve.getID()).toString(), updatedObjectIds);
        if ((inputIDToReconciledIDs != null) && (!(((CmdbObjectID)dataToResolve.getID()).equals(updatedObject.getID()))))
          inputIDToReconciledIDs.put(dataToResolve.getID(), updatedObjectIds);
      }
      else
      {
        updatedObjects.add(dataToResolve);
      }

    return updatedObjects;
  }

  public static CmdbLinks resolveCmdbData(DataFactory dataFactory, CmdbLink dataToResolve, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs, Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDs, List<DataInInfo> info) {
    CmdbLinks updatedLinks = CmdbLinkFactory.createLinks();
    CmdbObjectID end1ID = dataToResolve.getEnd1();
    CmdbObjectID end2ID = dataToResolve.getEnd2();

    if ((!(shouldResolve((CmdbDataID)dataToResolve.getID(), inputIDAsStringToReconciledIDs))) || (!(shouldResolve(end1ID, inputIDAsStringToReconciledIDs))) || (!(shouldResolve(end2ID, inputIDAsStringToReconciledIDs)))) {
      return updatedLinks;
    }

    String end1AsString = end1ID.toString();
    String end2AsString = end2ID.toString();
    if ((inputIDAsStringToReconciledIDs.containsKey(end1AsString)) || (inputIDAsStringToReconciledIDs.containsKey(end2AsString))) {
      List end1IDs;
      List end2IDs;
      CmdbObjectID end1CurrentID;
      CmdbDataIDs updatedLinkIds = CmdbDataIdsFactory.create();

      if (inputIDAsStringToReconciledIDs.containsKey(end1AsString)) {
        end1IDs = getIDsListFromIDsCollection((CmdbIDsCollection)inputIDAsStringToReconciledIDs.get(end1AsString));
      }
      else {
        end1IDs = new ArrayList(1);
        end1IDs.add(end1ID);
      }
      if (inputIDAsStringToReconciledIDs.containsKey(end2AsString)) {
        end2IDs = getIDsListFromIDsCollection((CmdbIDsCollection)inputIDAsStringToReconciledIDs.get(end2AsString));
      }
      else {
        end2IDs = new ArrayList(1);
        end2IDs.add(end2ID);
      }

      if (end1IDs.size() != end2IDs.size())
        for (Iterator i$ = end1IDs.iterator(); i$.hasNext(); ) { end1CurrentID = (CmdbObjectID)i$.next();
          for (Iterator i$ = end2IDs.iterator(); i$.hasNext(); ) { CmdbObjectID end2CurrentID = (CmdbObjectID)i$.next();
            CmdbLink updatedLink = dataFactory.createLink(dataToResolve.getType(), end1CurrentID, end2CurrentID, dataToResolve.getUnmodifiableProperties());
            updatedLinks.add(updatedLink);
            addResolvedDataInfo(dataToResolve, updatedLink, info);
            updatedLinkIds.add((CmdbDataID)updatedLink.getID());
          }
        }

      else
        for (int i = 0; i < end1IDs.size(); ++i) {
          end1CurrentID = (CmdbObjectID)end1IDs.get(i);
          CmdbObjectID end2CurrentID = (CmdbObjectID)end2IDs.get(i);
          CmdbLink updatedLink = dataFactory.createLink(dataToResolve.getType(), end1CurrentID, end2CurrentID, dataToResolve.getUnmodifiableProperties());
          updatedLinks.add(updatedLink);
          addResolvedDataInfo(dataToResolve, updatedLink, info);
          updatedLinkIds.add((CmdbDataID)updatedLink.getID());
        }


      if ((updatedLinkIds.size() != 1) || (!(((CmdbDataID)updatedLinkIds.getIdsIterator().next()).equals(dataToResolve.getDataID()))))
        inputIDAsStringToReconciledIDs.put(((CmdbLinkID)dataToResolve.getID()).toString(), updatedLinkIds);

      if (inputIDToReconciledIDs != null) {
        inputIDToReconciledIDs.put(dataToResolve.getID(), updatedLinkIds);
      }

    }
    else if (dataToResolve.getID() instanceof TempCmdbLinkID) {
      CmdbLink updatedLink = dataFactory.createLink(dataToResolve.getType(), end1ID, end2ID, dataToResolve.getUnmodifiableProperties());
      updatedLinks.add(updatedLink);
      addResolvedDataInfo(dataToResolve, updatedLink, info);
      CmdbDataIDs updatedLinkIds = CmdbDataIdsFactory.create();
      updatedLinkIds.add((CmdbDataID)updatedLink.getID());
      inputIDAsStringToReconciledIDs.put(((CmdbLinkID)dataToResolve.getID()).toString(), updatedLinkIds);
      if ((inputIDToReconciledIDs != null) && (!(((CmdbLinkID)dataToResolve.getID()).equals(updatedLink.getID()))))
        inputIDToReconciledIDs.put(dataToResolve.getID(), updatedLinkIds);
    }
    else
    {
      updatedLinks.add(dataToResolve);
    }

    return updatedLinks;
  }

  private static List<CmdbObjectID> getIDsListFromIDsCollection(CmdbIDsCollection iDsCollection) {
    List ids = new ArrayList();
    ReadOnlyIterator idsIt = iDsCollection.getIdsIterator();
    while (idsIt.hasNext())
      ids.add((CmdbObjectID)idsIt.next());

    return ids;
  }

  private static void addResolvedDataInfo(CmdbData inputData, CmdbData resolvedData, List<DataInInfo> info) {
    if (info != null)
      info.add(new DataInResolvedInfo(inputData, resolvedData));
  }

  private static Set<CmdbObjectID> getIsUpdatedByOwnerForObjects(Collection<TempMergePropertiesInput<CmdbObject>> tempInput, Set<String> isOwnerByType)
  {
    CmdbObjectIds idsToCheck = CmdbObjectIdsFactory.create();
    fillCollectionOfObjectIdsToCheck(tempInput, idsToCheck, isOwnerByType);

    if (idsToCheck.isEmpty()) {
      return Collections.emptySet();
    }

    CmdbDatas datas = getPropertyForAllObjects(idsToCheck, "root_isupdatedbyowner");
    return createSetOfUpdatedByOwner(datas);
  }

  private static Set<CmdbLinkID> getIsUpdatedByOwnerForLinks(Collection<TempMergePropertiesInput<CmdbLink>> tempInput, Set<String> isOwnerByType) {
    CmdbLinkIds idsToCheck = CmdbLinkIdsFactory.create();
    fillCollectionOfLinkIdsToCheck(tempInput, idsToCheck, isOwnerByType);

    if (idsToCheck.isEmpty()) {
      return Collections.emptySet();
    }

    CmdbDatas datas = getPropertyForAllLinks(idsToCheck, "root_isupdatedbyowner");
    return createSetOfUpdatedByOwner(datas);
  }

  private static <IDType> Set<IDType> createSetOfUpdatedByOwner(CmdbDatas<? extends CmdbDataID, ? extends CmdbData> datas) {
    Set updatedByOwnerSet = new HashSet(datas.size());
    for (Iterator i$ = datas.iterator(); i$.hasNext(); ) { CmdbData data = (CmdbData)i$.next();
      CmdbProperty isUpdatedByOwnerProperty = data.getProperty("root_isupdatedbyowner");
      if ((!(isUpdatedByOwnerProperty.isValueEmpty())) && (((Boolean)isUpdatedByOwnerProperty.getValue()).booleanValue()))
      {
        updatedByOwnerSet.add(data.getDataID());
      }
    }
    return updatedByOwnerSet;
  }

  public static TqlResultMap getResultInChunks(ChunkRequest chunkRequest) {
    TqlModifiableResultMap totalResult = TqlResultFactory.createModifiableResultMap(DefaultLinksDictionary.getInstance());
    int chunksCount = 0;
    while (chunkRequest.hasNext()) {
      if (chunksCount != 0)
        chunkRequest = chunkRequest.next();

      TqlQueryGetResultMapChunk getChunk = new TqlQueryGetResultMapChunk(chunkRequest);
      ServerApiFacade.executeOperation(getChunk);
      TqlResultMap chunkResult = getChunk.getResultMap();
      TqlResultMapUtils.addToResult(totalResult, chunkResult);
      ++chunksCount;
    }
    return totalResult;
  }

  private static CmdbDatas<? extends CmdbDataID, ? extends CmdbData> getPropertyForAllObjects(CmdbObjectIds ids, String attributeName) {
    PatternElementNumber elementNumber = PatternElementNumberFactory.createElementNumber(0);
    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();

    ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition("root", true);
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, null, ids);
    patternGraph.addNode(PatternGraphFactory.createPatternNode(elementNumber, elementCondition, true, null));

    Pattern pattern = PatternDefinitionFactory.createPattern("Merge Properties: get objects is updated by owner properties.", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    elementSimpleLayout.addKey(attributeName);
    PatternLayout layout = PatternLayoutFactory.createLayout();
    layout.setElementLayout(elementNumber, elementSimpleLayout);

    TqlQueryGetAdHocCmdbMap queryGetAdHocMap = new TqlQueryGetAdHocCmdbMap(pattern, layout);
    ServerApiFacade.executeOperation(queryGetAdHocMap);
    TqlResultMap tqlResultMap = (queryGetAdHocMap.isDividedToChunks()) ? getResultInChunks(queryGetAdHocMap.getChunkRequest()) : queryGetAdHocMap.getResultMap();
    return ((tqlResultMap.containsElementNumber(elementNumber)) ? tqlResultMap.getObjects(elementNumber) : CmdbObjectFactory.createEmptyObjects());
  }

  private static CmdbDatas<? extends CmdbDataID, ? extends CmdbData> getPropertyForAllLinks(CmdbLinkIds ids, String attributeName) {
    PatternElementNumber end1ElementNumber = PatternElementNumberFactory.createElementNumber(0);
    PatternElementNumber end2ElementNumber = PatternElementNumberFactory.createElementNumber(1);

    PatternElementNumber linkElementNumber = PatternElementNumberFactory.createElementNumber(2);
    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();

    ElementCondition endsElementCondition = PatternConditionFactory.createElementCondition("object", true);
    ModifiableNodeLinksCondition modifiableNodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
    modifiableNodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(linkElementNumber.getNumber(), 1, -1));
    patternGraph.addNode(PatternGraphFactory.createPatternNode(end1ElementNumber, endsElementCondition, false, modifiableNodeLinksCondition));
    patternGraph.addNode(PatternGraphFactory.createPatternNode(end2ElementNumber, endsElementCondition, false, modifiableNodeLinksCondition));

    ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition("root", true);
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, null, ids, false);
    patternGraph.addLink(PatternGraphFactory.createPatternLink(linkElementNumber, end1ElementNumber, end2ElementNumber, elementCondition, true));

    Pattern pattern = PatternDefinitionFactory.createPattern("Merge Properties: get links is updated by owner properties.", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    elementSimpleLayout.addKey(attributeName);
    PatternLayout layout = PatternLayoutFactory.createLayout();
    layout.setElementLayout(linkElementNumber, elementSimpleLayout);

    TqlQueryGetAdHocCmdbMap queryGetAdHocMap = new TqlQueryGetAdHocCmdbMap(pattern, layout);
    ServerApiFacade.executeOperation(queryGetAdHocMap);
    TqlResultMap tqlResultMap = (queryGetAdHocMap.isDividedToChunks()) ? getResultInChunks(queryGetAdHocMap.getChunkRequest()) : queryGetAdHocMap.getResultMap();
    return ((tqlResultMap.containsElementNumber(linkElementNumber)) ? tqlResultMap.getObjects(linkElementNumber) : CmdbObjectFactory.createEmptyObjects());
  }

  public static <Type extends CmdbData> void updateExistingDataMap(Map<String, CmdbDataIDs> tempInputIDAsStringToReconciledIDs, TempMergePropertiesInput<Type> mergeInput) {
    CmdbDataID updatingDataId = mergeInput.getRemainingObject().getDataID();
    Collection datasToMerge = mergeInput.getDatasFromBulk();
    for (Iterator i$ = datasToMerge.iterator(); i$.hasNext(); ) { CmdbData object = (CmdbData)i$.next();
      CmdbDataID objectId = object.getDataID();
      if (!(updatingDataId.equals(objectId))) {
        CmdbDataIDs objectIds = (CmdbDataIDs)tempInputIDAsStringToReconciledIDs.get(objectId.toString());
        if (objectIds == null)
          objectIds = CmdbDataIdsFactory.createList();

        if (!(objectIds.contains(updatingDataId)))
          objectIds.add(updatingDataId);

        tempInputIDAsStringToReconciledIDs.put(objectId.toString(), objectIds);
      }
    }
  }

  public static CmdbObject getDataFromCollectionById(Collection<CmdbObject> col, CmdbObjectID requestedDataId) {
    for (Iterator i$ = col.iterator(); i$.hasNext(); ) { CmdbObject data = (CmdbObject)i$.next();
      if (((CmdbObjectID)data.getID()).equals(requestedDataId))
        return data;
    }

    return null;
  }

  public static <Type extends CmdbData, TypeID extends CmdbDataID> Type removeObjectById(Collection<Type> collectionToRemoveFrom, TypeID idToRemove) {
    Iterator iter = collectionToRemoveFrom.iterator();
    while (iter.hasNext()) {
      CmdbData currType = (CmdbData)iter.next();
      if (currType.getDataID().equals(idToRemove)) {
        iter.remove();
        return currType;
      }
    }
    throw new DataInException("could not remove id <" + idToRemove + "> from collection. collection:" + collectionToRemoveFrom);
  }

  public static CmdbModelUpdateBulkInfo filterBulkStatistics(DataContainer dataContainer, CmdbModelUpdateBulkInfo bulkInfo, Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap)
  {
    CmdbModifiableModelUpdateBulkInfo newBulkInfo = CmdbModelUpdateBulkInfoFactory.create();
    Map reconciledToInputMap = reverseInputToReconciledMap(inputIDToReconciledIDsMap);

    addObjectsStatistics(dataContainer, bulkInfo, newBulkInfo, reconciledToInputMap);

    addLinksStatistics(dataContainer, bulkInfo, newBulkInfo, reconciledToInputMap);

    return newBulkInfo.getCmdbModelUpdateBulkInfo();
  }

  private static void addObjectsStatistics(DataContainer dataContainer, CmdbModelUpdateBulkInfo bulkInfo, CmdbModifiableModelUpdateBulkInfo newBulkInfo, Map<CmdbDataID, CmdbDataID> reconciledToInputMap) {
    Map statisticsMap = new HashMap(dataContainer.getObjectsForUpdateSize());
    ReadOnlyIterator objectsInfo = bulkInfo.getObjectsInfo();
    while (objectsInfo.hasNext()) {
      CmdbUpdatedObjectsInfo currentInfo = (CmdbUpdatedObjectsInfo)objectsInfo.next();
      for (Iterator i$ = currentInfo.inputIDsIterator().iterator(); i$.hasNext(); ) { CmdbDataID cmdbDataID = (CmdbDataID)i$.next();
        CmdbObjectID currentID = (CmdbObjectID)cmdbDataID;
        CmdbObject objectFromDataContainer = null;
        if (dataContainer.containsObjectForUpdate(currentID))
          objectFromDataContainer = dataContainer.getObjectForUpdate(currentID);
        else if (reconciledToInputMap.containsKey(currentID))
          objectFromDataContainer = dataContainer.getObjectForUpdate((CmdbObjectID)reconciledToInputMap.get(currentID));

        addDataStatistics(statisticsMap, currentInfo, currentID, objectFromDataContainer);
      }
    }
    addObjectsStatisticsMapToBulkInfo(statisticsMap, newBulkInfo);
  }

  private static void addLinksStatistics(DataContainer dataContainer, CmdbModelUpdateBulkInfo bulkInfo, CmdbModifiableModelUpdateBulkInfo newBulkInfo, Map<CmdbDataID, CmdbDataID> reconciledToInputMap) {
    Map statisticsMap = new HashMap(dataContainer.getLinksForUpdateSize());
    ReadOnlyIterator linksInfo = bulkInfo.getLinksInfo();
    while (linksInfo.hasNext()) {
      CmdbUpdatedLinksInfo currentInfo = (CmdbUpdatedLinksInfo)linksInfo.next();
      for (Iterator i$ = currentInfo.inputIDsIterator().iterator(); i$.hasNext(); ) { CmdbDataID cmdbDataID = (CmdbDataID)i$.next();
        CmdbLinkID currentID = (CmdbLinkID)cmdbDataID;
        CmdbLink linkFromDataContainer = null;
        if (dataContainer.containsLinkForUpdate(currentID))
          linkFromDataContainer = dataContainer.getLinkForUpdate(currentID);
        else if (reconciledToInputMap.containsKey(currentID))
          linkFromDataContainer = dataContainer.getLinkForUpdate((CmdbLinkID)reconciledToInputMap.get(currentID));

        addDataStatistics(statisticsMap, currentInfo, currentID, linkFromDataContainer);
      }
    }
    addLinksStatisticsMapToBulkInfo(statisticsMap, newBulkInfo);
  }

  private static void addDataStatistics(Map<CmdbDataID, StatisticsHolder> statisticsMap, CmdbUpdatedModelDataInfo currentInfo, CmdbDataID currentID, CmdbData dataFromDataContainer) {
    if (dataFromDataContainer != null)
    {
      Integer currentCount;
      if ((statisticsMap.containsKey(currentID)) && (!(currentInfo.getClassName().equals(dataFromDataContainer.getType()))))
      {
        return;
      }
      StatisticsHolder statisticsHolder = new StatisticsHolder(currentInfo.getClassName());
      statisticsMap.put(currentID, statisticsHolder);
      statisticsHolder.increaseInputCount(1);
      if (currentInfo.containsAddedCount(currentID)) {
        currentCount = Integer.valueOf(currentInfo.getAddedCount(currentID));
        if ((currentCount != null) && (currentCount.intValue() > 0)) {
          statisticsHolder.increaseAddedCount(currentCount.intValue());
          return;
        }
      }
      if (currentInfo.containsUpdatedCount(currentID)) {
        currentCount = Integer.valueOf(currentInfo.getUpdatedCount(currentID));
        if ((currentCount != null) && (currentCount.intValue() > 0)) {
          statisticsHolder.increaseUpdatedCount(currentCount.intValue());
          return;
        }
      }
      if (currentInfo.containsRemovedCount(currentID)) {
        currentCount = Integer.valueOf(currentInfo.getRemovedCount(currentID));
        if ((currentCount != null) && (currentCount.intValue() > 0)) {
          statisticsHolder.increaseRemovedCount(currentCount.intValue());
          return;
        }
      }
      if (currentInfo.containsInvalidCount(currentID)) {
        currentCount = Integer.valueOf(currentInfo.getInvalidCount(currentID));
        if ((currentCount != null) && (currentCount.intValue() > 0)) {
          statisticsHolder.increaseInvalidCount(currentCount.intValue());

          return;
        }
      }
    }
  }

  private static void addObjectsStatisticsMapToBulkInfo(Map<CmdbDataID, StatisticsHolder> statisticsMap, CmdbModifiableModelUpdateBulkInfo newBulkInfo) {
    for (Iterator i$ = statisticsMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry currentEntry = (Map.Entry)i$.next();
      CmdbObjectID id = (CmdbObjectID)currentEntry.getKey();
      if (((StatisticsHolder)currentEntry.getValue())._inputCount > 0)
        newBulkInfo.increaseInputObjectsCount(((StatisticsHolder)currentEntry.getValue())._className, id, ((StatisticsHolder)currentEntry.getValue())._inputCount);

      if (((StatisticsHolder)currentEntry.getValue())._addedCount > 0)
        newBulkInfo.increaseAddedObjectsCount(((StatisticsHolder)currentEntry.getValue())._className, id, ((StatisticsHolder)currentEntry.getValue())._addedCount);

      if (((StatisticsHolder)currentEntry.getValue())._updatedCount > 0)
        newBulkInfo.increaseUpdatedObjectsCount(((StatisticsHolder)currentEntry.getValue())._className, id, ((StatisticsHolder)currentEntry.getValue())._updatedCount);

      if (((StatisticsHolder)currentEntry.getValue())._removedCount > 0)
        newBulkInfo.increaseRemovedObjectsCount(((StatisticsHolder)currentEntry.getValue())._className, id, ((StatisticsHolder)currentEntry.getValue())._removedCount);

      if (((StatisticsHolder)currentEntry.getValue())._invalidCount > 0)
        newBulkInfo.increaseInvalidObjectsCount(((StatisticsHolder)currentEntry.getValue())._className, id, ((StatisticsHolder)currentEntry.getValue())._invalidCount);
    }
  }

  private static void addLinksStatisticsMapToBulkInfo(Map<CmdbDataID, StatisticsHolder> statisticsMap, CmdbModifiableModelUpdateBulkInfo newBulkInfo)
  {
    for (Iterator i$ = statisticsMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry currentEntry = (Map.Entry)i$.next();
      CmdbLinkID id = (CmdbLinkID)currentEntry.getKey();
      if (((StatisticsHolder)currentEntry.getValue())._inputCount > 0)
        newBulkInfo.increaseInputLinksCount(((StatisticsHolder)currentEntry.getValue())._className, id, ((StatisticsHolder)currentEntry.getValue())._inputCount);

      if (((StatisticsHolder)currentEntry.getValue())._addedCount > 0)
        newBulkInfo.increaseAddedLinksCount(((StatisticsHolder)currentEntry.getValue())._className, id, ((StatisticsHolder)currentEntry.getValue())._addedCount);

      if (((StatisticsHolder)currentEntry.getValue())._updatedCount > 0)
        newBulkInfo.increaseUpdatedLinksCount(((StatisticsHolder)currentEntry.getValue())._className, id, ((StatisticsHolder)currentEntry.getValue())._updatedCount);

      if (((StatisticsHolder)currentEntry.getValue())._removedCount > 0)
        newBulkInfo.increaseRemovedLinksCount(((StatisticsHolder)currentEntry.getValue())._className, id, ((StatisticsHolder)currentEntry.getValue())._removedCount);

      if (((StatisticsHolder)currentEntry.getValue())._invalidCount > 0)
        newBulkInfo.increaseInvalidLinksCount(((StatisticsHolder)currentEntry.getValue())._className, id, ((StatisticsHolder)currentEntry.getValue())._invalidCount);
    }
  }

  private static Map<CmdbDataID, CmdbDataID> reverseInputToReconciledMap(Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap)
  {
    Map reconciledToInputMap = new HashMap(inputIDToReconciledIDsMap.size());
    for (Iterator i$ = inputIDToReconciledIDsMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry currentEntry = (Map.Entry)i$.next();
      for (Iterator i$ = ((CmdbDataIDs)currentEntry.getValue()).iterator(); i$.hasNext(); ) { CmdbDataID currentReconciledID = (CmdbDataID)i$.next();
        reconciledToInputMap.put(currentReconciledID, currentEntry.getKey());
      }
    }
    return reconciledToInputMap;
  }

  private static class MergeTopologyAdvancedType
  implements DataInUtil.MergeTopologyType
  {
    private final PatternCreator _patternCreator;
    private final boolean _shouldRemoveMainNode;

    public MergeTopologyAdvancedType(PatternCreator patternCreator, boolean shouldRemoveMainNode)
    {
      this._patternCreator = patternCreator;
      this._shouldRemoveMainNode = shouldRemoveMainNode;
    }

    public MergeTopologyQueryOperation createOperation(List<MergeInput<CmdbObject>> input) {
      return new MergeTopologyQueryOperation(input, this._patternCreator, this._shouldRemoveMainNode);
    }
  }

  private static class MergeFullTopologyType
  implements DataInUtil.MergeTopologyType
  {
    public MergeTopologyQueryOperation createOperation(List<MergeInput<CmdbObject>> input)
    {
      return new MergeTopologyQueryOperation(input);
    }
  }

  private static abstract interface MergeTopologyType
  {
    public abstract MergeTopologyQueryOperation createOperation(List<MergeInput<CmdbObject>> paramList);
  }

  private static class StatisticsHolder
  {
    String _className;
    int _inputCount;
    int _addedCount;
    int _updatedCount;
    int _removedCount;
    int _invalidCount;

    public StatisticsHolder(String className)
    {
      this._className = className;
      this._inputCount = 0;
      this._addedCount = 0;
      this._updatedCount = 0;
      this._removedCount = 0;
      this._invalidCount = 0;
    }

    void increaseInputCount(int count) {
      this._inputCount += count; }

    void increaseAddedCount(int count) {
      this._addedCount += count; }

    void increaseUpdatedCount(int count) {
      this._updatedCount += count; }

    void increaseRemovedCount(int count) {
      this._removedCount += count; }

    void increaseInvalidCount(int count) {
      this._invalidCount += count;
    }
  }
}