package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import java.io.Serializable;

public class AttributeCondition
  implements Serializable
{
  protected String _attributeName;
  protected String _fixedValue;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public String getAttributeName()
  {
    return this._attributeName;
  }

  public void setAttributeName(String attributeName) {
    this._attributeName = attributeName;
  }

  public String getFixedValue() {
    return this._fixedValue;
  }

  public void setFixedValue(String fixedValue) {
    this._fixedValue = fixedValue;
  }
}