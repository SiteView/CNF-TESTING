package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;

class PatternElementNumberCreator
{
  private static int n = 0;

  static PatternElementNumber create()
  {
    return PatternElementNumberFactory.createElementNumber(n++);
  }
}