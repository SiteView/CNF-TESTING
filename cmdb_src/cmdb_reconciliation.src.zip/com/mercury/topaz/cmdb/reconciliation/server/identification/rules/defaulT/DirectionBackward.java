package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;

class DirectionBackward
  implements Direction
{
  public CmdbObjectID getSource(CmdbLink link)
  {
    return link.getEnd1();
  }

  public CmdbObjectID getTarget(CmdbLink link) {
    return link.getEnd2();
  }

  public PatternLink createPatternLink(PatternElementNumber linkNumber, PatternElementNumber srcElementNumber, PatternElementNumber trgElementNumber, ElementCondition condition, boolean isVisible) {
    return PatternGraphFactory.createPatternLink(linkNumber, srcElementNumber, trgElementNumber, condition, isVisible);
  }

  public CmdbLinks getLinksFromDataContainerBySource(DataContainer dataContainer, CmdbObjectID id) {
    return dataContainer.getCmdbLinksByEnd1(id);
  }
}