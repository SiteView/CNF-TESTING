package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import org.jibx.runtime.IAbstractMarshaller;
import org.jibx.runtime.IMarshaller;
import org.jibx.runtime.IUnmarshaller;

public class JiBX_bindingAbstractIdentificationRuleConfig_access
  implements IUnmarshaller, IMarshaller, IAbstractMarshaller
{
}