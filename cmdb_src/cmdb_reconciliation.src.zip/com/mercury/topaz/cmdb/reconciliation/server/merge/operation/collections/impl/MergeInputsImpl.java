package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.impl;

import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInputs;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class MergeInputsImpl<ID extends CmdbDataID, Type extends CmdbData>
  implements MergeInputs<ID, Type>
{
  private final Map<CmdbDataID, MergeInput<Type>> _mergeInputs;

  public MergeInputsImpl(int initialCapacity)
  {
    this._mergeInputs = new HashMap(initialCapacity);
  }

  public MergeInput<Type> getMergeInputByUpdatingDataId(ID updatingDataId) {
    return ((MergeInput)this._mergeInputs.get(updatingDataId));
  }

  public MergeInput<Type> add(Type updatingData, CmdbDatas<ID, Type> datas) {
    return add(updatingData, datas, datas.size());
  }

  public MergeInput<Type> add(Type updatingData, Collection<Type> datas) {
    return add(updatingData, datas, datas.size());
  }

  private MergeInput<Type> add(Type updatingData, Iterable<Type> datas, int size) {
    MergeInput mergeInput = getMergeInput(updatingData, size);
    for (Iterator i$ = datas.iterator(); i$.hasNext(); ) { CmdbData data = (CmdbData)i$.next();
      addToMergeInput(data, mergeInput);
    }
    return mergeInput;
  }

  public MergeInput<Type> add(Type updatingData, Type object) {
    MergeInput mergeInput = getMergeInput(updatingData, 1);
    addToMergeInput(object, mergeInput);
    return mergeInput;
  }

  public boolean isEmpty() {
    return this._mergeInputs.isEmpty();
  }

  public int size() {
    return this._mergeInputs.size();
  }

  public Collection<MergeInput<Type>> getAllMergeInputs() {
    return this._mergeInputs.values();
  }

  private MergeInput<Type> getMergeInput(Type updatingData, int initialCapacity) {
    MergeInput mergeInput = (MergeInput)this._mergeInputs.get(updatingData.getDataID());
    if (null == mergeInput) {
      mergeInput = MergeInputFactory.createMergeInput(initialCapacity, updatingData);
      this._mergeInputs.put(updatingData.getDataID(), mergeInput);
    }
    return mergeInput;
  }

  private void addToMergeInput(Type object, MergeInput<Type> mergeInput) {
    for (Iterator i$ = mergeInput.getDatasToMerge().iterator(); i$.hasNext(); ) { CmdbData data = (CmdbData)i$.next();
      if (data.equals(object))
        return;
    }

    mergeInput.add(object);
  }

  public Iterator<MergeInput<Type>> iterator() {
    return this._mergeInputs.values().iterator();
  }
}