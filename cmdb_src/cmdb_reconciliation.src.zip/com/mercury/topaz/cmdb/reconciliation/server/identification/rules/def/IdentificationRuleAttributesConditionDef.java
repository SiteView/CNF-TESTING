package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class IdentificationRuleAttributesConditionDef extends AbstractIdentificationRuleConditionDef
  implements Iterable<IdentificationRuleAttributeConditionDef>
{
  private final Collection<IdentificationRuleAttributeConditionDef> _identificationRuleAttributeConditionDefs;

  public IdentificationRuleAttributesConditionDef(Collection<IdentificationRuleAttributeConditionDef> identificationRuleAttributeConditionDefs)
  {
    this._identificationRuleAttributeConditionDefs = identificationRuleAttributeConditionDefs;
  }

  public IdentificationRuleAttributesConditionDef() {
    this._identificationRuleAttributeConditionDefs = new LinkedList();
  }

  public void accept(IdentificationRuleConditionDefVisitor visitor) {
    visitor.visit(this);
  }

  public Collection<IdentificationRuleAttributeConditionDef> getReconciliationRuleAttributeConditionDefs() {
    return this._identificationRuleAttributeConditionDefs;
  }

  public Iterator<IdentificationRuleAttributeConditionDef> iterator() {
    return this._identificationRuleAttributeConditionDefs.iterator();
  }

  public void addAttributeCondition(IdentificationRuleAttributeConditionDef attributeConditionDef) {
    getReconciliationRuleAttributeConditionDefs().add(attributeConditionDef);
  }
}