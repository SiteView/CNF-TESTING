package com.mercury.topaz.cmdb.reconciliation.server.change;

import com.mercury.topaz.cmdb.shared.change.CmdbChange;

public abstract interface CmdbIDChange extends CmdbChange
{
}