package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;

public class DataInAddOrUpdateData extends AbstractDataInOptimisticUpdateOperation
{
  private boolean _ignoreInvalidLinks;

  public DataInAddOrUpdateData(DataContainer dataContainer, Changer changer)
  {
    super(dataContainer, changer);
  }

  public DataInAddOrUpdateData(DataContainer dataContainer, Changer changer, boolean ignoreInvalidLinks) {
    super(dataContainer, changer);
    setIgnoreInvalidLinks(ignoreInvalidLinks);
  }

  public String getOperationName() {
    return "Data In - Add Or Update Data";
  }

  protected DataInRuleOutput runDataInRule(DataInRule dataInRule, ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return dataInRule.onAddOrUpdateData(environment, dataInRuleInput, isIgnoreInvalidLinks());
  }

  private boolean isIgnoreInvalidLinks() {
    return this._ignoreInvalidLinks;
  }

  private void setIgnoreInvalidLinks(boolean ignoreInvalidLinks) {
    this._ignoreInvalidLinks = ignoreInvalidLinks;
  }

  protected boolean shouldAddLinkEnds() {
    return true;
  }
}