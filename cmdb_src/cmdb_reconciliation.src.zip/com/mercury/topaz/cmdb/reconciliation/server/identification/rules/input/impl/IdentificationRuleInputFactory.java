package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;

public class IdentificationRuleInputFactory
{
  public static IdentificationRuleInput create(ReconciliationEnvironment env, DataContainer data, String typeToReconcile, InputIdToCmdbDatasMapping alreayReconciledData, IdentificationScope identificationScope)
  {
    return new IdentificationRuleInputImpl(env, data, typeToReconcile, alreayReconciledData, identificationScope);
  }
}