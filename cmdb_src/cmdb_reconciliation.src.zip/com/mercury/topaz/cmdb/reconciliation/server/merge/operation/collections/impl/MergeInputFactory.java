package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.impl;

import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInputs;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.util.Collection;

public class MergeInputFactory
{
  public static <Type extends CmdbData> MergeInput<Type> createMergeInput(int initialCapacity, Type updatingData)
  {
    return new MergeInputImpl(initialCapacity, updatingData);
  }

  public static <Type extends CmdbData> MergeInput<Type> createMergeInput(Collection<Type> datasToMerge, Type updatingData) {
    return new MergeInputImpl(datasToMerge, updatingData);
  }

  public static <ID extends CmdbDataID, Type extends CmdbData> MergeInputs<ID, Type> createMergeInputs(int initialCapacity) {
    return new MergeInputsImpl(initialCapacity);
  }
}