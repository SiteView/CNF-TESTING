package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import org.jibx.runtime.IBindingFactory;

public class JiBX_bindingFactory
  implements IBindingFactory
{
  private static IBindingFactory m_inst;
}