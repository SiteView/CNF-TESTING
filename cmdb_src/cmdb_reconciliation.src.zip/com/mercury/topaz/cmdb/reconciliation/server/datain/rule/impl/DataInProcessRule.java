package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.exception.DataInException;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.impl.DataInRuleOutputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.TempMergePropertiesInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.TempMergeTopologyInput;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.impl.MergeInputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl.MergeTopologyOutput;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddLinksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddOrIgnoreLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddUpdateOrIgnoreLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddObjectsStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddOrIgnoreObjects;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddOrUpdateObjects;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsStrict;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DataInProcessRule extends DataInDefaultRule
{
  private static final Map<List<Integer>, DataInDefaultRule.Command<CmdbObjectID, CmdbObject>> _commandsMap;
  public static final String ATTRIBUTE_CMDLINE_FIXED_VALUE = "";

  public DataInProcessRule(DataInRuleDefinition ruleDefinition)
  {
    super(ruleDefinition);
  }

  public DataInRuleOutput onAddOrUpdateData(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, boolean ignoreInvalidLinks) {
    return onAdd(environment, dataInRuleInput, AddType.addOrUpdate);
  }

  public DataInRuleOutput onAddOrIgnoreData(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onAdd(environment, dataInRuleInput, AddType.addOrIgnore);
  }

  public DataInRuleOutput onAddDataStrict(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onAdd(environment, dataInRuleInput, AddType.addStrict);
  }

  private DataInRuleOutput onAdd(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, AddType addType) {
    CmdbObjectIds updatedIdsToRemove;
    DataContainer dataContainer = dataInRuleInput.getDataContainer();

    CmdbObjects objectsForUpdate = dataContainer.getObjectsForUpdate(dataInRuleInput.getType());
    Map idChangesMap = new HashMap(objectsForUpdate.size());

    CmdbDataIDs idsForTouch = CmdbDataIdsFactory.createList();
    CmdbObjects objectsToAdd = CmdbObjectFactory.createObjects();
    CmdbObjects objectsToAddOrIgnore = CmdbObjectFactory.createObjects();
    CmdbObjectIds objectsToRemove = CmdbObjectIdsFactory.create();
    CmdbLinks linksToAdd = CmdbLinkFactory.createLinks();
    CmdbLinks linksToRemove = CmdbLinkFactory.createLinks();

    if (dataContainer.sizeOfDataForUpdate() > 0) {
      Set idsHandled = new HashSet(objectsForUpdate.size());
      InputIdToCmdbDatasMapping existingMap = dataInRuleInput.getExistingDataMap();
      Collection mergeTopologyInputs = new ArrayList(objectsForUpdate.size());
      Collection mergePropertiesInputs = new ArrayList(objectsForUpdate.size());
      for (Iterator i$ = objectsForUpdate.iterator(); i$.hasNext(); ) { CmdbObject objectWithPossiblyTempID = (CmdbObject)i$.next();
        if (!(idsHandled.contains(objectWithPossiblyTempID.getID()))) {
          chooseObjectToKeepAndCreateMergeInput(objectWithPossiblyTempID, existingMap, idChangesMap, environment, dataInRuleInput, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, idsForTouch, addType, idsHandled);
        }

      }

      Map mergePropertiesResultMap = DataInUtil.mergeCIProperties(mergePropertiesInputs, dataInRuleInput.getOwnerByType(), dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());
      for (Iterator i$ = mergePropertiesResultMap.values().iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
        if (null != object)
          objectsToAdd.add(object);
      }

      for (i$ = mergePropertiesInputs.iterator(); i$.hasNext(); ) { TempMergePropertiesInput tempMergePropertiesInput = (TempMergePropertiesInput)i$.next();
        for (Iterator i$ = tempMergePropertiesInput.getDatasFromCmdb().iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
          if (!(objectsToAdd.contains(object)))
            objectsToRemove.add((CmdbObjectID)object.getID());

        }

      }

      List newMergeTopologyInputs = fixRemainingObjectInMergeTopologyInput(idChangesMap, mergeTopologyInputs, mergePropertiesResultMap);
      Map mergeTopologyOutput = mergeTopology(dataInRuleInput, idChangesMap, newMergeTopologyInputs);
      processMergeTopologyResult(objectsToAdd, objectsToAddOrIgnore, objectsToRemove, linksToAdd, linksToRemove, mergeTopologyOutput);
    }

    Map idChangesMapFromPreviousRules = dataInRuleInput.getIdChanges();
    if ((idChangesMapFromPreviousRules == null) || (idChangesMapFromPreviousRules.isEmpty())) {
      updatedIdsToRemove = objectsToRemove;
    }
    else {
      updatedIdsToRemove = CmdbObjectIdsFactory.createIdsList(2 * objectsToRemove.size());
      for (Iterator i$ = objectsToRemove.iterator(); i$.hasNext(); ) { CmdbObjectID idToRemove = (CmdbObjectID)i$.next();
        updatedIdsToRemove.add(idToRemove);
        CmdbObjectID changedID = (CmdbObjectID)idChangesMapFromPreviousRules.get(idToRemove);
        if (changedID != null)
          updatedIdsToRemove.add(changedID);
      }

    }

    Changer changer = dataInRuleInput.getChanger();
    List modelUpdates = addType.createModelUpdateOperations(objectsToAdd, updatedIdsToRemove, linksToAdd, linksToRemove, changer);
    if (!(objectsToAddOrIgnore.isEmpty()))
      modelUpdates.add(new ModelUpdateAddOrIgnoreObjects(objectsToAddOrIgnore, changer));

    return DataInRuleOutputFactory.createDataInRuleOutput(idChangesMap, modelUpdates, idsForTouch);
  }

  private List<MergeInput<CmdbObject>> fixRemainingObjectInMergeTopologyInput(Map<CmdbDataID, CmdbDataID> idChangesMap, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, Map<CmdbObject, CmdbObject> mergePropertiesResultMap) {
    List newMergeTopologyInputs = new ArrayList(mergeTopologyInputs.size());
    for (Iterator i$ = mergeTopologyInputs.iterator(); i$.hasNext(); ) { TempMergeTopologyInput tempMergeTopologyInput = (TempMergeTopologyInput)i$.next();
      if (mergePropertiesResultMap.containsKey(tempMergeTopologyInput.getRemainingObject()))
      {
        CmdbObject newRemainingData = (CmdbObject)mergePropertiesResultMap.get(tempMergeTopologyInput.getRemainingObject());
        newMergeTopologyInputs.add(MergeInputFactory.createMergeInput(tempMergeTopologyInput.getDatasFromCmdb(), newRemainingData));
      } else {
        MergeInput newMergeInput = MergeInputFactory.createMergeInput(tempMergeTopologyInput.getDatasFromCmdb(), tempMergeTopologyInput.getRemainingObject());
        newMergeTopologyInputs.add(newMergeInput);
      }
      for (Iterator i$ = tempMergeTopologyInput.getDatasFromCmdb().iterator(); i$.hasNext(); ) { CmdbObject currObject = (CmdbObject)i$.next();
        idChangesMap.put(currObject.getDataID(), ((CmdbObject)tempMergeTopologyInput.getRemainingObject()).getDataID());
      }
    }
    return newMergeTopologyInputs;
  }

  protected Map<CmdbObjectID, MergeTopologyOutput> mergeTopology(DataInRuleInput dataInRuleInput, Map<CmdbDataID, CmdbDataID> idChangesMap, List<MergeInput<CmdbObject>> newMergeTopologyInputs) {
    return DataInUtil.mergeTopology(newMergeTopologyInputs, dataInRuleInput.getDataInInfoList(), idChangesMap);
  }

  protected void processMergeTopologyResult(CmdbObjects objectsToAdd, CmdbObjects objectsToAddOrIgnore, CmdbObjectIds objectsToRemove, CmdbLinks linksToAdd, CmdbLinks linksToRemove, Map<CmdbObjectID, MergeTopologyOutput> mergeTopologyOutput)
  {
    for (Iterator i$ = mergeTopologyOutput.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      MergeTopologyOutput output = (MergeTopologyOutput)entry.getValue();
      for (Iterator i$ = output.getObjectsToAdd().iterator(); i$.hasNext(); ) { CmdbObject objectToAdd = (CmdbObject)i$.next();
        if (((CmdbObjectID)objectToAdd.getID()).equals(entry.getKey())) {
          objectsToAdd.add(objectToAdd);
        }
        else
          objectsToAddOrIgnore.add(objectToAdd);
      }

      for (i$ = output.getObjectsToRemove().iterator(); i$.hasNext(); ) { CmdbObject objectToRemove = (CmdbObject)i$.next();
        objectsToRemove.add((CmdbObjectID)objectToRemove.getID());
      }
      for (i$ = output.getLinksToAdd().iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
        linksToAdd.add(link);
      }
    }
  }

  private void chooseObjectToKeepAndCreateMergeInput(CmdbObject object, InputIdToCmdbDatasMapping existingMap, Map<CmdbDataID, CmdbDataID> idChangesMap, ReconciliationEnvironment env, DataInRuleInput input, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, CmdbDataIDs idsForTouch, AddType typeOfAdd, Set<CmdbObjectID> idsHandled)
  {
    Collection existingInBulk = existingMap.getInBulk((CmdbDataID)object.getID());

    Collection existingInCMDB = existingMap.get((CmdbDataID)object.getID());

    Collection inCompleteObjectsFromBulk = new ArrayList(existingInBulk.size());
    Collection completeObjectsFromBulk = new ArrayList(existingInBulk.size());
    Collection inCompleteObjectsFromCMDB = new ArrayList(existingInCMDB.size());
    Collection completeObjectsFromCMDB = new ArrayList(existingInCMDB.size());

    for (Iterator i$ = existingInBulk.iterator(); i$.hasNext(); ) { CmdbObject existingInBulkObject = (CmdbObject)i$.next();
      idsHandled.add(existingInBulkObject.getID());
    }

    fillCompleteAndIncompleteCollections(Resolve.resolve, env.getDataFactory(), completeObjectsFromBulk, inCompleteObjectsFromBulk, Arrays.asList(new CmdbObject[] { object }));
    fillCompleteAndIncompleteCollections(Resolve.resolve, env.getDataFactory(), completeObjectsFromBulk, inCompleteObjectsFromBulk, existingInBulk);
    fillCompleteAndIncompleteCollections(Resolve.dontResolve, null, completeObjectsFromCMDB, inCompleteObjectsFromCMDB, existingInCMDB);

    typeOfAdd.handle(object, idChangesMap, env, input, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, idsForTouch, inCompleteObjectsFromBulk, completeObjectsFromBulk, inCompleteObjectsFromCMDB, completeObjectsFromCMDB);
  }

  private static void fillCompleteAndIncompleteCollections(Resolve resolve, DataFactory dataFactory, Collection<CmdbObject> completeObjects, Collection<CmdbObject> inCompleteObjects, Collection<CmdbObject> allObjects) {
    for (Iterator i$ = allObjects.iterator(); i$.hasNext(); ) { CmdbObject currentObject = (CmdbObject)i$.next();
      if (isComplete(currentObject))
        completeObjects.add(resolve.resolve(dataFactory, currentObject));
      else
        inCompleteObjects.add(currentObject);
    }
  }

  public static boolean isComplete(CmdbObject object)
  {
    String commandLineAttributeName = "process_cmdline";
    CmdbProperty cmdLineProperty = object.getProperty("process_cmdline");
    if (null == cmdLineProperty) {
      throw new DataInException("Received [" + object.getType() + "] without required attribute [" + "process_cmdline" + "]!\nthe object: " + object);
    }

    return ((!(cmdLineProperty.isValueEmpty())) && (!(cmdLineProperty.getValue().equals(""))));
  }

  private static void handleIt(CmdbObject currentObject, ReconciliationEnvironment env, DataInRuleInput input, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, Collection<CmdbObject> inCompleteHostsFromBulk, Collection<CmdbObject> inCompleteHostsFromCMDB, Collection<CmdbObject> completeHostsFromBulk, Collection<CmdbObject> completeHostsFromCMDB)
  {
    CmdbObject remainingObject = chooseObjectToKeepAndResolveIt(completeHostsFromCMDB, inCompleteHostsFromCMDB, completeHostsFromBulk, inCompleteHostsFromBulk, env.getDataFactory(), input.getInputIDAsStringToReconciledIDsMap(), input.getInputIDToReconciledIDsMap(), input.getDataInInfoList());

    addToInputToReconciledIdMapIfNeeded(currentObject, input, remainingObject);

    List listOfSizes = Arrays.asList(new Integer[] { Integer.valueOf(getSize(inCompleteHostsFromBulk)), Integer.valueOf(getSize(completeHostsFromBulk)), Integer.valueOf(getSize(inCompleteHostsFromCMDB)), Integer.valueOf(getSize(completeHostsFromCMDB)) });

    DataInDefaultRule.Command command = (DataInDefaultRule.Command)_commandsMap.get(listOfSizes);
    if (null == command) {
      throw new DataInException("Process Data In Rule: no command found for combination of " + listOfSizes + "\n trigger object: " + currentObject + createString("incomplete in bulk", inCompleteHostsFromBulk) + createString("complete in bulk", completeHostsFromBulk) + createString("incomplete in cmdb", inCompleteHostsFromCMDB) + createString("complete in cmdb", completeHostsFromCMDB));
    }

    List existingInBulk = new ArrayList(inCompleteHostsFromBulk.size() + completeHostsFromBulk.size());
    List existingInCMDB = new ArrayList(inCompleteHostsFromCMDB.size() + completeHostsFromCMDB.size());
    existingInBulk.addAll(inCompleteHostsFromBulk);
    existingInBulk.addAll(completeHostsFromBulk);
    existingInCMDB.addAll(inCompleteHostsFromCMDB);
    existingInCMDB.addAll(completeHostsFromCMDB);
    command.handle(remainingObject, existingInBulk, existingInCMDB, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, env.getCmdbClassModel());
  }

  private static String createString(String type, Collection<CmdbObject> objects) {
    return "\n" + type + "(" + objects.size() + "): " + createObjectInALineString(objects).replaceAll("\n", "\n\t");
  }

  private static String createObjectInALineString(Iterable<?> objects) {
    StringBuilder sb = new StringBuilder();
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { Object object = i$.next();
      sb.append("\n").append(object.toString().replaceAll("\n", "\t"));
    }
    return sb.toString();
  }

  private static int getSize(Collection<CmdbObject> collection) {
    int actualSize = collection.size();
    return ((actualSize > 1) ? 2 : actualSize);
  }

  private static void addToInputToReconciledIdMapIfNeeded(CmdbObject currentObject, DataInRuleInput input, CmdbObject remainingObject) {
    if (!(((CmdbObjectID)currentObject.getID()).equals(remainingObject.getID()))) {
      CmdbObjectID oldID = (CmdbObjectID)currentObject.getID();
      addToInputToReconciledIdMap(remainingObject, oldID, input.getInputIDToReconciledIDsMap());
      addToInputToReconciledIdMap(remainingObject, oldID.toString(), input.getInputIDAsStringToReconciledIDsMap());
    }
  }

  private static <KeyType> void addToInputToReconciledIdMap(CmdbObject remainingObject, KeyType key, Map<KeyType, CmdbDataIDs> inputIDToReconciledIDsMap) {
    CmdbDataIDs reconciledIDs = (CmdbDataIDs)inputIDToReconciledIDsMap.get(key);
    if (null == reconciledIDs) {
      reconciledIDs = CmdbDataIdsFactory.create();
      inputIDToReconciledIDsMap.put(key, reconciledIDs);
    }
    reconciledIDs.add((CmdbDataID)remainingObject.getID());
  }

  private static CmdbObject chooseObjectToKeepAndResolveIt(Collection<CmdbObject> completeObjectsFromCMDB, Collection<CmdbObject> inCompleteObjectsFromCMDB, Collection<CmdbObject> completeObjectsFromBulk, Collection<CmdbObject> inCompleteObjectsFromBulk, DataFactory dataFactory, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDsMap, Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap, List<DataInInfo> dataInInfoList) {
    if (!(completeObjectsFromCMDB.isEmpty())) {
      return ((CmdbObject)completeObjectsFromCMDB.iterator().next());
    }

    if (!(completeObjectsFromBulk.isEmpty())) {
      resolvedObjects = DataInUtil.resolveCmdbData(dataFactory, (CmdbObject)completeObjectsFromBulk.iterator().next(), inputIDAsStringToReconciledIDsMap, inputIDToReconciledIDsMap, dataInInfoList);
      if ((!($assertionsDisabled)) && (resolvedObjects.size() != 1)) throw new AssertionError();
      return ((CmdbObject)resolvedObjects.iterator().next());
    }

    if (!(inCompleteObjectsFromCMDB.isEmpty())) {
      return ((CmdbObject)inCompleteObjectsFromCMDB.iterator().next());
    }

    CmdbObjects resolvedObjects = DataInUtil.resolveCmdbData(dataFactory, (CmdbObject)inCompleteObjectsFromBulk.iterator().next(), inputIDAsStringToReconciledIDsMap, inputIDToReconciledIDsMap, dataInInfoList);
    if ((!($assertionsDisabled)) && (resolvedObjects.size() != 1)) throw new AssertionError();
    return ((CmdbObject)resolvedObjects.iterator().next());
  }

  static
  {
    _commandsMap = new HashMap(30);

    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.AddCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(1) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.AddCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(1) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(1) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(2) }), AddIgnoreIncompleteInBulkRemoveIncompleteInCmdb.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(2) }), AddIgnoreIncompleteInBulkRemoveIncompleteInCmdb.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(2) }), AddIgnoreIncompleteInBulkRemoveIncompleteInCmdb.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(2) }), AddIgnoreIncompleteInBulkRemoveIncompleteInCmdb.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(2) }), AddIgnoreIncompleteInBulkRemoveIncompleteInCmdb.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(2) }), AddIgnoreIncompleteInBulkRemoveIncompleteInCmdb.getInstance());
  }

  private static class AddIgnoreIncompleteInBulkRemoveIncompleteInCmdb
  implements DataInDefaultRule.Command<CmdbObjectID, CmdbObject> {
    private static final AddIgnoreIncompleteInBulkRemoveIncompleteInCmdb _instance = new AddIgnoreIncompleteInBulkRemoveIncompleteInCmdb();

    public static AddIgnoreIncompleteInBulkRemoveIncompleteInCmdb getInstance() {
      return _instance;
    }

    public void handle(CmdbObject remainingObject, Collection<CmdbObject> datasFromBulk, Collection<CmdbObject> datasFromCMDB, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbDatas<CmdbObjectID, CmdbObject> datasToAdd, CmdbObjectIds objectsToRemove, CmdbClassModel classModel) {
      CmdbObject object;
      for (Iterator i$ = datasFromBulk.iterator(); i$.hasNext(); ) { object = (CmdbObject)i$.next();
        if (DataInProcessRule.isComplete(object))
          datasToAdd.add(object);
      }

      for (i$ = datasFromCMDB.iterator(); i$.hasNext(); ) { object = (CmdbObject)i$.next();
        if (!(DataInProcessRule.isComplete(object)))
          objectsToRemove.add((CmdbObjectID)object.getID());
      }
    }
  }

  private static abstract enum AddType
  {
    addStrict, addOrIgnore, addOrUpdate;

    public static final AddType[] values()
    {
      return ((AddType[])$VALUES.clone());
    }

    public abstract ModelUpdate createModelUpdateOperation(CmdbObjects paramCmdbObjects, Changer paramChanger);

    public abstract List<ModelUpdate> createModelUpdateOperations(CmdbObjects paramCmdbObjects, CmdbObjectIds paramCmdbObjectIds, CmdbLinks paramCmdbLinks1, CmdbLinks paramCmdbLinks2, Changer paramChanger);

    public abstract void handle(CmdbObject paramCmdbObject, Map<CmdbDataID, CmdbDataID> paramMap, ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput, Collection<TempMergePropertiesInput<CmdbObject>> paramCollection, Collection<TempMergeTopologyInput<CmdbObject>> paramCollection1, CmdbObjects paramCmdbObjects, CmdbObjectIds paramCmdbObjectIds, CmdbDataIDs paramCmdbDataIDs, Collection<CmdbObject> paramCollection2, Collection<CmdbObject> paramCollection3, Collection<CmdbObject> paramCollection4, Collection<CmdbObject> paramCollection5);
  }

  private static abstract enum Resolve
  {
    resolve, dontResolve;

    public static final Resolve[] values()
    {
      return ((Resolve[])$VALUES.clone());
    }

    public abstract CmdbObject resolve(DataFactory paramDataFactory, CmdbObject paramCmdbObject);
  }
}