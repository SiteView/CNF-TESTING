package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import java.util.Collection;
import java.util.Iterator;

public class DataInMergePropertiesInfo<Type extends CmdbData>
  implements DataInInfo
{
  private CmdbData _result;
  private CmdbData _inputData;
  private Collection<Type> _datasToMerge;

  public DataInMergePropertiesInfo(CmdbData inputData, Collection<Type> datasToMerge, CmdbData result)
  {
    this._inputData = inputData;
    this._datasToMerge = datasToMerge;
    this._result = result;
  }

  public String getShortMessage() {
    StringBuilder info = new StringBuilder("Merged Properties: [input:");
    info.append(this._inputData);
    info.append("]\n\t[datas to merge:");
    appendDatasToMerge(info, 2);
    info.append("]\n\t[result:").append(this._result).append("]");
    return info.toString();
  }

  private StringBuilder appendDatasToMerge(StringBuilder sb, int numberOfTabs) {
    for (Iterator i$ = this._datasToMerge.iterator(); i$.hasNext(); ) { CmdbData obj = (CmdbData)i$.next();
      sb.append("\n");
      addTabs(sb, numberOfTabs);
      sb.append(obj);
    }
    return sb;
  }

  private static void addTabs(StringBuilder sb, int numberOfTabs) {
    for (int i = 0; i < numberOfTabs; ++i)
      sb.append("\t");
  }
}