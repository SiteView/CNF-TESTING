package com.mercury.topaz.cmdb.reconciliation.server.datain.rule;

import java.io.Serializable;
import java.util.Map;

public abstract interface DataInRuleDefinition extends Serializable
{
  public abstract Map<String, String> getConfigurationParams();

  public abstract String getConfigurationParam(String paramString);

  public abstract boolean containsParam(String paramString);
}