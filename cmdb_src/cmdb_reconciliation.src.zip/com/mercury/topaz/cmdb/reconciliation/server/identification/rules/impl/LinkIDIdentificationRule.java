package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.id.link.TempCmdbLinkID;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.model.operation.query.topology.separation.ModelTopologyQueryCheckLinksExistence;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class LinkIDIdentificationRule extends IDIdentificationRule
{
  private static final LinkIDIdentificationRule _instance = new LinkIDIdentificationRule();

  public static LinkIDIdentificationRule getInstance()
  {
    return _instance;
  }

  public void identify(IdentificationRuleInput input) {
    Collection emptyCollection = Collections.emptyList();

    InputIdToCmdbDatasMapping idToCmdbDatasMapping = input.getAlreadyReconciledData();
    Map linkToFindToInputLink = new HashMap();

    CmdbLinks linksToFind = CmdbLinkFactory.createLinksListImpl();
    CmdbLinks linksToIdentify = input.getDataContainer().getLinksForUpdate(input.getTypeToIdentify());
    for (Iterator i$ = linksToIdentify.iterator(); i$.hasNext(); ) { CmdbLink currentLink = (CmdbLink)i$.next();
      if (!(currentLink.getID() instanceof TempCmdbLinkID)) {
        linkToFindToInputLink.put(currentLink, currentLink);
        linksToFind.add(currentLink);
      } else {
        DataFactory dataFactory = input.getReconciliationRuleEnvironment().getDataFactory();

        Collection end1Objects = idToCmdbDatasMapping.get(currentLink.getEnd1());
        if ((end1Objects != null) && (!(end1Objects.isEmpty())))
          for (Iterator i$ = end1Objects.iterator(); i$.hasNext(); ) { CmdbObject end1Object = (CmdbObject)i$.next();

            Collection end2Objects = idToCmdbDatasMapping.get(currentLink.getEnd2());
            if ((end2Objects != null) && (!(end2Objects.isEmpty())))
              for (Iterator i$ = end2Objects.iterator(); i$.hasNext(); ) { CmdbObject end2Object = (CmdbObject)i$.next();
                CmdbLink realLinkToFind = dataFactory.createLink(currentLink.getType(), (CmdbObjectID)end1Object.getID(), (CmdbObjectID)end2Object.getID(), currentLink.getUnmodifiableProperties());
                linkToFindToInputLink.put(realLinkToFind, currentLink);
                linksToFind.add(realLinkToFind);
              }
            else
              idToCmdbDatasMapping.add((CmdbDataID)currentLink.getID(), emptyCollection);
          }

        else
          idToCmdbDatasMapping.add((CmdbDataID)currentLink.getID(), emptyCollection);
      }
    }

    ModelTopologyQueryCheckLinksExistence getData = new ModelTopologyQueryCheckLinksExistence(linksToFind);
    ServerApiFacade.executeOperation(getData);

    CmdbLinks existingLinks = getData.getExistingLinks();
    for (Iterator i$ = existingLinks.iterator(); i$.hasNext(); ) { CmdbLink existLink = (CmdbLink)i$.next();
      CmdbLink inputLink = (CmdbLink)linkToFindToInputLink.get(existLink);

      addExistingLinkToMap(idToCmdbDatasMapping, existLink, (CmdbLinkID)inputLink.getID());
    }

    CmdbLinks notExistingLinks = getData.getNonExistingLinks();
    for (Iterator i$ = notExistingLinks.iterator(); i$.hasNext(); ) { CmdbLink notExistLink = (CmdbLink)i$.next();
      CmdbLink inputLink = (CmdbLink)linkToFindToInputLink.get(notExistLink);
      if (!(idToCmdbDatasMapping.containsKey((CmdbDataID)inputLink.getID())))
        idToCmdbDatasMapping.add((CmdbDataID)notExistLink.getID(), emptyCollection);
    }

    identifyInBulk(linksToIdentify, idToCmdbDatasMapping);
  }

  private void addExistingLinkToMap(InputIdToCmdbDatasMapping identificationDatas, CmdbLink existLink, CmdbLinkID inputId)
  {
    Collection existingLinks = identificationDatas.get(inputId);
    if (existingLinks == null) {
      existingLinks = new ArrayList(1);
      identificationDatas.add(inputId, existingLinks);
    }
    for (Iterator i$ = existingLinks.iterator(); i$.hasNext(); ) { CmdbLink currentExistsLink = (CmdbLink)i$.next();
      if (((CmdbLinkID)currentExistsLink.getID()).equals(existLink.getID()))
        return;
    }

    existingLinks.add(existLink);
  }

  private void identifyInBulk(CmdbLinks linksToIdentify, InputIdToCmdbDatasMapping alreadyReconciledData) {
    Collection emptyCollection = Collections.emptyList();
    for (Iterator i$ = linksToIdentify.iterator(); i$.hasNext(); ) { CmdbLink linkToIdentify = (CmdbLink)i$.next();
      alreadyReconciledData.addInBulk((CmdbDataID)linkToIdentify.getID(), emptyCollection);
    }
  }
}