package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.id.object.TempCmdbObjectID;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ModelUtil;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.operation.query.impl.ClassModelQueryGetWholeClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementTypeLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocCmdbMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class HostIdentificationRule
  implements IdentificationRule
{
  private static int number;
  private static final PatternElementNumber hostElementNumber;
  private static final PatternElementNumber ipElementNumber;
  private static final PatternElementNumber linkElementNumber;
  private static ResultFilter[] _filters;

  public void identify(IdentificationRuleInput input)
  {
    if ((!($assertionsDisabled)) && (!("host".equals(input.getTypeToIdentify())))) throw new AssertionError();
    ReconciliationEnvironment env = input.getReconciliationRuleEnvironment();
    DataContainer data = input.getDataContainer();
    InputIdToCmdbDatasMapping alreayReconciledData = input.getAlreadyReconciledData();
    Map inputHostIdToRealId = new HashMap();
    Map hostIsCompleteMap = new HashMap(data.getObjectsForUpdate("host").size());
    Map reversedMap = new HashMap();
    initializeMaps(env, data, inputHostIdToRealId, hostIsCompleteMap);

    if (input.getIdentifierScope().isContainCMDB())
    {
      reconcileByIpId(data, env, alreayReconciledData, reversedMap);

      reconcileByHostId(data.getObjectsForUpdate("host"), env, alreayReconciledData, hostIsCompleteMap);
    }

    if (input.getIdentifierScope().isContainBulk())
    {
      reconcileByIpInBulk(data, env, alreayReconciledData);
    }
    filterResult(data, alreayReconciledData, reversedMap, inputHostIdToRealId, hostIsCompleteMap);
  }

  private void initializeMaps(ReconciliationEnvironment env, DataContainer data, Map<CmdbObjectID, CmdbObjectID> inputHostIdToRealId, Map<CmdbObjectID, Boolean> hostIsCompleteMap) {
    for (Iterator i$ = data.getObjectsForUpdate("host").iterator(); i$.hasNext(); ) { CmdbObject host = (CmdbObject)i$.next();
      CmdbObjectID objectRealID = (CmdbObjectID)host.getID();

      if ((host.getID() instanceof TempCmdbObjectID) && 
        (ModelUtil.hasAllKeyProperties(host, env.getCmdbClassModel()))) {
        objectRealID = env.getDataFactory().createObjectID(host.getType(), host.getUnmodifiableProperties());
        inputHostIdToRealId.put(host.getID(), objectRealID);
      }

      hostIsCompleteMap.put(objectRealID, Boolean.valueOf(isCompleteHost(host)));
    }
  }

  private void reconcileByIpId(DataContainer data, ReconciliationEnvironment env, InputIdToCmdbDatasMapping inputIdToCmdbDatasMapping, Map<CmdbObjectID, List<CmdbObject>> reversedMap)
  {
    Map ipIDsMap = new HashMap();
    Pattern pattern = createReconciliationByIpIdPattern(data, env, ipIDsMap);
    Map ipToRealHostMap = new HashMap();

    if (pattern != null) {
      TqlQueryGetAdHocCmdbMap op = new TqlQueryGetAdHocCmdbMap(pattern, getHostLayout());
      ServerApiFacade.executeOperation(op);
      TqlResultMap tqlResultMap = (op.isDividedToChunks()) ? DataInUtil.getResultInChunks(op.getChunkRequest()) : op.getResultMap();

      CmdbLinks linksFromCmdb = (tqlResultMap.containsElementNumber(linkElementNumber)) ? tqlResultMap.getLinks(linkElementNumber) : CmdbLinkFactory.createEmptyLinks();
      CmdbObjects hostsFromCmdb = (tqlResultMap.containsElementNumber(hostElementNumber)) ? tqlResultMap.getObjects(hostElementNumber) : CmdbObjectFactory.createEmptyObjects();
      for (Iterator i$ = linksFromCmdb.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
        CmdbObject realHost = (CmdbObject)hostsFromCmdb.get(link.getEnd1());
        CmdbObjects realHosts = (CmdbObjects)ipToRealHostMap.get(link.getEnd2());
        if (null == realHosts) {
          realHosts = CmdbObjectFactory.createObjects();
          ipToRealHostMap.put(link.getEnd2(), realHosts);
        }
        realHosts.add(realHost);

        reversedMap.put(realHost.getID(), new ArrayList(1));
      }

    }

    for (Iterator i$ = data.getObjectsForUpdate("host").iterator(); i$.hasNext(); ) { Collection realHosts;
      CmdbObject host = (CmdbObject)i$.next();
      Collection existingHosts = inputIdToCmdbDatasMapping.get((CmdbDataID)host.getID());

      if (existingHosts != null) {
        realHosts = existingHosts;
      } else {
        realHosts = new ArrayList(1);
        inputIdToCmdbDatasMapping.add((CmdbDataID)host.getID(), realHosts);
      }

      CmdbLinks cmdbLinks = data.getCmdbLinksByEnd1((CmdbObjectID)host.getID());
      for (Iterator i$ = cmdbLinks.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
        CmdbObjectID ipId = link.getEnd2();
        CmdbObject ip = data.getCmdbObject(ipId);
        if ((ip != null) && (env.getCmdbClassModel().isTypeOf("ip", ip.getType()))) {
          CmdbObjects hostRealIds = (CmdbObjects)ipToRealHostMap.get(ipIDsMap.get(ipId));
          if (hostRealIds != null)
            for (Iterator i$ = hostRealIds.iterator(); i$.hasNext(); ) { CmdbObject realHost = (CmdbObject)i$.next();
              addToListIfNotExist(realHosts, realHost);
              addToReversedMap(reversedMap, host, realHost);
            }
        }
      }
    }
  }

  private void addToReversedMap(Map<CmdbObjectID, List<CmdbObject>> reversedMap, CmdbObject inputHost, CmdbObject hostFromCmdb)
  {
    ((List)reversedMap.get(hostFromCmdb.getID())).add(inputHost);
  }

  private void addToListIfNotExist(Collection<CmdbObject> listOfObjects, CmdbObject newObject) {
    for (Iterator i$ = listOfObjects.iterator(); i$.hasNext(); ) { CmdbObject objectFromList = (CmdbObject)i$.next();
      if (((CmdbObjectID)newObject.getID()).equals(objectFromList.getID()))
        return;
    }

    listOfObjects.add(newObject);
  }

  private static boolean isCompleteHost(CmdbObject object) {
    CmdbProperty property = object.getProperty("host_iscomplete");
    return ((property != null) && (!(property.isValueEmpty())) && (((Boolean)property.getValue()).booleanValue()));
  }

  private static boolean isCompleteHost(CmdbObject object, Map<CmdbObjectID, Boolean> hostIsCompleteMap) {
    if (hostIsCompleteMap.containsKey(object.getID()))
      return ((Boolean)hostIsCompleteMap.get(object.getID())).booleanValue();

    CmdbProperty property = object.getProperty("host_iscomplete");
    return ((property != null) && (!(property.isValueEmpty())) && (((Boolean)property.getValue()).booleanValue()));
  }

  private CmdbObjects reconcileByHostId(CmdbObjects hostsToReconcile, ReconciliationEnvironment env, InputIdToCmdbDatasMapping reconciliationMap, Map<CmdbObjectID, Boolean> hostIsCompleteMap) {
    ElementClassCondition hostClassCondition = PatternConditionFactory.createElementClassCondition("host", true);
    CmdbObjectIds hostsIds = CmdbObjectIdsFactory.create();
    Map inputHostIdToRealId = new HashMap();
    for (Iterator i$ = hostsToReconcile.iterator(); i$.hasNext(); ) { CmdbObject hostWithPossiblyTempID = (CmdbObject)i$.next();
      CmdbObjectID hostTempID = (CmdbObjectID)hostWithPossiblyTempID.getID();
      CmdbObjectID objectRealID = null;
      if (hostTempID instanceof TempCmdbObjectID)
        if (ModelUtil.hasAllKeyProperties(hostWithPossiblyTempID, env.getCmdbClassModel())) {
          objectRealID = env.getDataFactory().createObjectID(hostWithPossiblyTempID.getType(), hostWithPossiblyTempID.getUnmodifiableProperties());
          inputHostIdToRealId.put(hostWithPossiblyTempID.getID(), objectRealID);
        }
      else
        objectRealID = hostTempID;

      if (objectRealID != null)
        hostsIds.add(objectRealID);
    }

    ElementCondition hostElementCondition = PatternConditionFactory.createElementCondition(hostClassCondition, null, hostsIds);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    PatternNode hostPatternNode = PatternGraphFactory.createPatternNode(hostElementNumber, hostElementCondition, true, null);
    patternGraph.addNode(hostPatternNode);
    ModifiablePattern modifiablePattern = PatternDefinitionFactory.createPattern("hostIdentificationByID", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    TqlQueryGetAdHocCmdbMap op = new TqlQueryGetAdHocCmdbMap(modifiablePattern, getHostLayout());
    ServerApiFacade.executeOperation(op);
    TqlResultMap tqlResultMap = (op.isDividedToChunks()) ? DataInUtil.getResultInChunks(op.getChunkRequest()) : op.getResultMap();

    if (tqlResultMap.containsElementNumber(hostElementNumber)) {
      CmdbObjects stillNotReconciledHosts = CmdbObjectFactory.createObjects();
      CmdbObjects hostsFromCmdb = tqlResultMap.getObjects(hostElementNumber);
      for (Iterator i$ = hostsToReconcile.iterator(); i$.hasNext(); ) { CmdbObject host = (CmdbObject)i$.next();
        CmdbObjectID hostInputID = (CmdbObjectID)host.getID();
        CmdbObjectID hostRealID = hostInputID;
        if (inputHostIdToRealId.containsKey(hostInputID))
          hostRealID = (CmdbObjectID)inputHostIdToRealId.get(hostInputID);

        if ((hostRealID != null) && (!(hostsFromCmdb.contains(hostRealID)))) {
          stillNotReconciledHosts.add(host);
        }
        else {
          Collection objects = reconciliationMap.get(hostInputID);
          if ((!($assertionsDisabled)) && (null == objects)) throw new AssertionError("<" + hostInputID + "> should have been in the reconciliationMap as empty collection!");
          CmdbObject hostFound = (CmdbObject)hostsFromCmdb.get(hostRealID);
          if (!(isIDInHostCollection(objects, (CmdbObjectID)hostFound.getID()))) {
            objects.add(hostFound);
          }

          hostIsCompleteMap.put(hostInputID, Boolean.valueOf(isCompleteHost(hostFound)));
        }
      }
      return stillNotReconciledHosts;
    }
    return hostsToReconcile;
  }

  private boolean isIDInHostCollection(Collection<CmdbObject> objects, CmdbObjectID id) {
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
      if (((CmdbObjectID)object.getID()).equals(id))
        return true;
    }

    return false; }

  private PatternLayout getHostLayout() {
    PatternLayout layout = PatternLayoutFactory.createLayout();
    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    elementSimpleLayout.addKey("host_iscomplete");
    layout.setElementLayout(hostElementNumber, elementSimpleLayout);
    return layout;
  }

  private Pattern createReconciliationByIpIdPattern(DataContainer data, ReconciliationEnvironment env, Map<CmdbObjectID, CmdbObjectID> ipIDsMap) {
    Iterator ipIterator = data.getCmdbObjectsIteratorByType("ip");
    if (!(ipIterator.hasNext()))
      return null;

    ElementClassCondition hostClassCondition = PatternConditionFactory.createElementClassCondition("host", true);
    ElementClassCondition ipClassCondition = PatternConditionFactory.createElementClassCondition("ip", true);
    ElementClassCondition linkClassCondition = PatternConditionFactory.createElementClassCondition("contained", true);
    CmdbObjectIds ipIds = CmdbObjectIdsFactory.createIdsList();
    while (ipIterator.hasNext()) {
      CmdbObject currentIP = (CmdbObject)ipIterator.next();
      CmdbObjectID cmdbObjectID = (CmdbObjectID)currentIP.getID();
      if (cmdbObjectID instanceof TempCmdbObjectID)
        cmdbObjectID = env.getDataFactory().createObjectID(currentIP.getType(), currentIP.getUnmodifiableProperties());

      ipIDsMap.put(currentIP.getID(), cmdbObjectID);
      ipIds.add(cmdbObjectID);
    }
    ElementCondition hostElementCondition = PatternConditionFactory.createElementCondition(hostClassCondition);
    ElementCondition ipElementCondition = PatternConditionFactory.createElementCondition(ipClassCondition, null, ipIds);
    ElementCondition linkElementCondition = PatternConditionFactory.createElementCondition(linkClassCondition);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    ModifiableNodeLinksCondition nodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
    nodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(linkElementNumber.getNumber(), 1, -1));
    PatternNode hostPatternNode = PatternGraphFactory.createPatternNode(hostElementNumber, hostElementCondition, true, nodeLinksCondition);
    PatternNode ipPatternNode = PatternGraphFactory.createPatternNode(ipElementNumber, ipElementCondition, true, nodeLinksCondition);
    PatternLink link = PatternGraphFactory.createPatternLink(linkElementNumber, hostElementNumber, ipElementNumber, linkElementCondition, true);
    patternGraph.addNode(hostPatternNode);
    patternGraph.addNode(ipPatternNode);
    patternGraph.addLink(link);
    return PatternDefinitionFactory.createPattern("hostReconciliationPattern", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);
  }

  private void reconcileByIpInBulk(DataContainer data, ReconciliationEnvironment env, InputIdToCmdbDatasMapping inputIdToCmdbDatasMapping)
  {
    CmdbObject currentHost;
    Iterator i$;
    Map ipToHostsMap = new HashMap();
    Iterator hostsIterator = data.getCmdbObjectsIteratorByType("host");
    while (hostsIterator.hasNext()) {
      currentHost = (CmdbObject)hostsIterator.next();
      inputIdToCmdbDatasMapping.addInBulk((CmdbDataID)currentHost.getID(), new ArrayList(0));
      for (i$ = data.getCmdbLinksByEnd1((CmdbObjectID)currentHost.getID()).iterator(); i$.hasNext(); ) { CmdbLink currentLink = (CmdbLink)i$.next();
        if (env.getCmdbClassModel().isTypeOf("contained", currentLink.getType())) {
          CmdbObjectID end2ID = currentLink.getEnd2();
          CmdbObject end2Object = data.getCmdbObject(end2ID);
          if ((null != end2Object) && (env.getCmdbClassModel().isTypeOf("ip", end2Object.getType())))
            if (ipToHostsMap.containsKey(end2ID)) {
              ((CmdbObjects)ipToHostsMap.get(end2ID)).add(currentHost);
            } else {
              CmdbObjects hosts = CmdbObjectFactory.createObjects();
              hosts.add(currentHost);
              ipToHostsMap.put(end2ID, hosts);
            }
        }

      }

    }

    hostsIterator = data.getCmdbObjectsIteratorByType("host");
    while (hostsIterator.hasNext()) {
      currentHost = (CmdbObject)hostsIterator.next();

      for (i$ = data.getCmdbLinksByEnd1((CmdbObjectID)currentHost.getID()).iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
        CmdbObjects connectedHosts = (CmdbObjects)ipToHostsMap.get(link.getEnd2());
        if (null != connectedHosts)
          for (Iterator i$ = connectedHosts.iterator(); i$.hasNext(); ) { CmdbObject connectedHost = (CmdbObject)i$.next();
            if (!(((CmdbObjectID)connectedHost.getID()).equals(currentHost.getID())))
            {
              inputIdToCmdbDatasMapping.getInBulk((CmdbDataID)currentHost.getID()).add(connectedHost);
            }
          }
      }
    }
  }

  public Pattern getLayoutPattern(String type, PatternElementNumber nodeElementNumber)
  {
    ElementClassCondition hostClassCondition = PatternConditionFactory.createElementClassCondition("host", true);
    ElementClassCondition ipClassCondition = PatternConditionFactory.createElementClassCondition("ip", true);
    ElementClassCondition linkClassCondition = PatternConditionFactory.createElementClassCondition("contained", true);
    ElementCondition hostElementCondition = PatternConditionFactory.createElementCondition(hostClassCondition);
    ElementCondition ipElementCondition = PatternConditionFactory.createElementCondition(ipClassCondition);
    ElementCondition linkElementCondition = PatternConditionFactory.createElementCondition(linkClassCondition);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    ModifiableNodeLinksCondition nodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
    nodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(linkElementNumber.getNumber(), 1, -1));
    PatternNode hostPatternNode = PatternGraphFactory.createPatternNode(nodeElementNumber, hostElementCondition, true, nodeLinksCondition);
    PatternNode ipPatternNode = PatternGraphFactory.createPatternNode(ipElementNumber, ipElementCondition, true, nodeLinksCondition);
    PatternLink link = PatternGraphFactory.createPatternLink(linkElementNumber, nodeElementNumber, ipElementNumber, linkElementCondition, true);
    patternGraph.addNode(hostPatternNode);
    patternGraph.addNode(ipPatternNode);
    patternGraph.addLink(link);

    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("hostLayoutPattern", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

    PatternLayout hostLayout = PatternLayoutFactory.createLayout();
    hostLayout.setElementLayout(nodeElementNumber, getHostTypedLayout());
    pattern.setDefaultLayout(hostLayout);
    return pattern;
  }

  private ElementTypeLayout getHostTypedLayout() {
    ElementTypeLayout hostLayout = PatternLayoutFactory.createTypeLayout();
    ClassModelQueryGetWholeClassModel getClassModel = new ClassModelQueryGetWholeClassModel();
    ServerApiFacade.executeOperation(getClassModel);
    CmdbClassModel classModel = getClassModel.getClassModel();
    Set basicIdAttrs = new HashSet(3);

    CmdbClass hostClass = classModel.getClass("host");
    fillIDAttributesNames(hostClass, basicIdAttrs);

    addLayoutToTypedLayout(hostLayout, "host", basicIdAttrs);

    CmdbClasses descClasses = classModel.getAllDescendentClasses("host");
    ReadOnlyIterator descClassesIt = descClasses.getIterator();
    while (descClassesIt.hasNext()) {
      CmdbClass currentClass = (CmdbClass)descClassesIt.next();
      Collection idAttrs = getIDAttributesNames(currentClass);
      if (!(basicIdAttrs.containsAll(idAttrs)))
        addLayoutToTypedLayout(hostLayout, currentClass.getName(), idAttrs);
    }

    return hostLayout;
  }

  private void addLayoutToTypedLayout(ElementTypeLayout typedLayout, String type, Collection<String> attrs) {
    ElementSimpleLayout simpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    for (Iterator i$ = attrs.iterator(); i$.hasNext(); ) { String attr = (String)i$.next();
      simpleLayout.addKey(attr);
    }
    simpleLayout.addKey("host_iscomplete");
    typedLayout.addSimpleLayout(type, simpleLayout);
  }

  private Collection<String> getIDAttributesNames(CmdbClass cmdbClass) {
    Collection names = new ArrayList(3);
    fillIDAttributesNames(cmdbClass, names);
    return names;
  }

  private void fillIDAttributesNames(CmdbClass cmdbClass, Collection coll) {
    CmdbAttributes idAttrs = cmdbClass.getAttributesByQualifier(CmdbAttributeQualifierDefs.ID_ATTRIBUTE);
    ReadOnlyIterator attrsIt = idAttrs.getIterator();
    while (attrsIt.hasNext())
      coll.add(((CmdbAttributeDefinition)attrsIt.next()).getName());
  }

  private void filterResult(DataContainer dataContainer, InputIdToCmdbDatasMapping inputIdToCmdbDatasMapping, Map<CmdbObjectID, List<CmdbObject>> reversedMap, Map<CmdbObjectID, CmdbObjectID> inputHostIdToRealId, Map<CmdbObjectID, Boolean> hostIsCompleteMap)
  {
    Iterator hostsIterator = dataContainer.getCmdbObjectsIteratorByType("host");
    while (hostsIterator.hasNext()) {
      CmdbObject inputHost = (CmdbObject)hostsIterator.next();
      CmdbObjectID hostRealID = (CmdbObjectID)inputHost.getID();
      if (inputHostIdToRealId.containsKey(inputHost.getID()))
        hostRealID = (CmdbObjectID)inputHostIdToRealId.get(inputHost.getID());

      boolean isInputHostComplete = ((Boolean)hostIsCompleteMap.get(hostRealID)).booleanValue();
      ResultFilter[] arr$ = _filters; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { ResultFilter _filter = arr$[i$];
        _filter.filter(inputIdToCmdbDatasMapping, reversedMap, inputHost, hostRealID, isInputHostComplete, hostIsCompleteMap);
      }
    }
  }

  private static boolean isCsgInvolved(Collection<CmdbObject> hosts) {
    if ((hosts == null) || (hosts.isEmpty()))
      return false;

    for (Iterator i$ = hosts.iterator(); i$.hasNext(); ) { CmdbObject currentMappedHost = (CmdbObject)i$.next();
      if (currentMappedHost.getType().equals("clusteredservice"))
        return true;
    }

    return false;
  }

  private static void cleanCompleteHostsThatAreNotCsgFromList(List<CmdbObject> mappedHosts, Map<CmdbObjectID, Boolean> hostIsCompleteMap)
  {
    if ((mappedHosts != null) && (!(mappedHosts.isEmpty())))
    {
      List validHosts = new ArrayList(mappedHosts.size());
      for (Iterator i$ = mappedHosts.iterator(); i$.hasNext(); ) { CmdbObject host = (CmdbObject)i$.next();
        if ((host.getType().equals("clusteredservice")) || (!(isCompleteHost(host, hostIsCompleteMap))))
          validHosts.add(host);

      }

      if (validHosts.size() != mappedHosts.size())
      {
        mappedHosts.clear();
        mappedHosts.addAll(validHosts);
      }
    }
  }

  private static void cleanCompleteHostsThatDoesntMatchTheInputIDFromList(List<CmdbObject> mappedHosts, CmdbObjectID inputHostID, Map<CmdbObjectID, Boolean> hostIsCompleteMap)
  {
    if ((mappedHosts != null) && (!(mappedHosts.isEmpty())))
    {
      List validHosts = new ArrayList(mappedHosts.size());
      for (Iterator i$ = mappedHosts.iterator(); i$.hasNext(); ) { CmdbObject host = (CmdbObject)i$.next();
        if ((!(isCompleteHost(host, hostIsCompleteMap))) || (((CmdbObjectID)host.getID()).equals(inputHostID)))
          validHosts.add(host);

      }

      if (validHosts.size() != mappedHosts.size())
      {
        mappedHosts.clear();
        mappedHosts.addAll(validHosts);
      }
    }
  }

  static
  {
    number = 106000;
    hostElementNumber = PatternElementNumberFactory.createElementNumber(number++);
    ipElementNumber = PatternElementNumberFactory.createElementNumber(number++);
    linkElementNumber = PatternElementNumberFactory.createElementNumber(number++);
    _filters = { CompleteToCompleteFilter.getInstance(), CsgFilter.getInstance() };
  }

  private static class CompleteToCompleteFilter
  implements HostIdentificationRule.ResultFilter
  {
    static CompleteToCompleteFilter _instance = new CompleteToCompleteFilter();

    public static CompleteToCompleteFilter getInstance() {
      return _instance;
    }

    public void filter(InputIdToCmdbDatasMapping inputIdToCmdbDatasMapping, Map<CmdbObjectID, List<CmdbObject>> reversedMap, CmdbObject inputHost, CmdbObjectID hostID, boolean isInputHostComplete, Map<CmdbObjectID, Boolean> hostIsCompleteMap) {
      if (isInputHostComplete) {
        List mappedInCmdb = (List)inputIdToCmdbDatasMapping.get((CmdbDataID)inputHost.getID());
        List mappedInBulk = (List)inputIdToCmdbDatasMapping.getInBulk((CmdbDataID)inputHost.getID());

        HostIdentificationRule.access$200(mappedInBulk, hostID, hostIsCompleteMap);
        HostIdentificationRule.access$200(mappedInCmdb, hostID, hostIsCompleteMap);
      }
    }
  }

  private static class CsgFilter
  implements HostIdentificationRule.ResultFilter
  {
    static CsgFilter _instance = new CsgFilter();

    public static CsgFilter getInstance()
    {
      return _instance;
    }

    public void filter(InputIdToCmdbDatasMapping inputIdToCmdbDatasMapping, Map<CmdbObjectID, List<CmdbObject>> reversedMap, CmdbObject inputHost, CmdbObjectID hostID, boolean isInputHostComplete, Map<CmdbObjectID, Boolean> hostIsCompleteMap) {
      List mappedInCmdb = (List)inputIdToCmdbDatasMapping.get((CmdbDataID)inputHost.getID());
      List mappedInBulk = (List)inputIdToCmdbDatasMapping.getInBulk((CmdbDataID)inputHost.getID());

      if ((isInputHostComplete) && (!(inputHost.getType().equals("clusteredservice"))))
      {
        List validHosts;
        Iterator i$;
        CmdbObject currentMappedHost;
        if ((mappedInCmdb != null) && (!(mappedInCmdb.isEmpty()))) {
          validHosts = new ArrayList(mappedInCmdb.size());
          for (i$ = mappedInCmdb.iterator(); i$.hasNext(); ) { currentMappedHost = (CmdbObject)i$.next();

            if ((((CmdbObjectID)currentMappedHost.getID()).equals(inputHost.getID())) || (!(HostIdentificationRule.access$000((Collection)reversedMap.get(currentMappedHost.getID())))))
              validHosts.add(currentMappedHost);
          }

          if (validHosts.size() != mappedInCmdb.size()) {
            mappedInCmdb.clear();
            mappedInCmdb.addAll(validHosts);
          }
        }

        if ((mappedInBulk != null) && (!(mappedInBulk.isEmpty()))) {
          validHosts = new ArrayList(mappedInBulk.size());
          for (i$ = mappedInBulk.iterator(); i$.hasNext(); ) { currentMappedHost = (CmdbObject)i$.next();

            if ((((CmdbObjectID)currentMappedHost.getID()).equals(inputHost.getID())) || (!(HostIdentificationRule.access$000(inputIdToCmdbDatasMapping.getInBulk((CmdbDataID)currentMappedHost.getID())))))
              validHosts.add(currentMappedHost);
          }

          if (validHosts.size() != mappedInBulk.size()) {
            mappedInBulk.clear();
            mappedInBulk.addAll(validHosts);
          }
        }
      }
      else
      {
        boolean isCsgInvolved = (HostIdentificationRule.access$000(mappedInCmdb)) || (HostIdentificationRule.access$000(mappedInBulk));
        if (isCsgInvolved) {
          HostIdentificationRule.access$100(mappedInBulk, hostIsCompleteMap);
          HostIdentificationRule.access$100(mappedInCmdb, hostIsCompleteMap);
        }
      }
    }
  }

  private static abstract interface ResultFilter
  {
    public abstract void filter(InputIdToCmdbDatasMapping paramInputIdToCmdbDatasMapping, Map<CmdbObjectID, List<CmdbObject>> paramMap, CmdbObject paramCmdbObject, CmdbObjectID paramCmdbObjectID, boolean paramBoolean, Map<CmdbObjectID, Boolean> paramMap1);
  }
}