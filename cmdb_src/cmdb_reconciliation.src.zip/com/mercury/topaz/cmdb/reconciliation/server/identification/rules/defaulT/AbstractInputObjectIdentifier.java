package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import java.util.HashSet;
import java.util.Set;

abstract class AbstractInputObjectIdentifier
  implements InputObjectIdentifier
{
  public abstract int hashCode();

  public abstract boolean equals(Object paramObject);

  public void add(CmdbProperty property)
  {
  }

  public void addFixedValue(FixedValueAttribute fixedValueAttribute)
  {
  }

  public void setId(CmdbDataID id)
  {
  }

  public <TypeID extends CmdbDataID> Set<TypeID> createInitialSet()
  {
    return new HashSet(2);
  }

  public <TypeID extends CmdbDataID> boolean addToSet(Set<TypeID> set, TypeID obj) {
    return set.add(obj);
  }

  public AbstractInputObjectIdentifier clone() {
    try {
      return ((AbstractInputObjectIdentifier)super.clone());
    } catch (CloneNotSupportedException e) {
      throw new Error("Object.clone() threw CloneNotSupportedException", e);
    }
  }

  public CmdbDataID getId() {
    return null;
  }

  public boolean equals(CmdbData<?> d1, CmdbData<?> d2) {
    return true;
  }
}