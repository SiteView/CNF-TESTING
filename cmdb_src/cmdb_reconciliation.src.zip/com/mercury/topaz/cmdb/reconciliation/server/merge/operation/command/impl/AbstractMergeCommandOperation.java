package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.command.impl;

import com.mercury.topaz.cmdb.reconciliation.server.merge.manager.MergeManager;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.impl.AbstractMergeOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

abstract class AbstractMergeCommandOperation extends AbstractMergeOperation
{
  protected final void mergeExecute(MergeManager manager, CmdbResponse response)
    throws CmdbException
  {
    mergeCommandExecute(manager, response);
  }

  protected abstract void mergeCommandExecute(MergeManager paramMergeManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}