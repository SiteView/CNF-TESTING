package com.mercury.topaz.cmdb.reconciliation.server.datain.rule;

import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInPreAnalyzeRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInPreAnalyzeRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import java.io.Serializable;

public abstract interface DataInPreAnalyzeRule extends Serializable
{
  public abstract DataInPreAnalyzeRuleOutput preAnalyze(ReconciliationEnvironment paramReconciliationEnvironment, DataInPreAnalyzeRuleInput paramDataInPreAnalyzeRuleInput);
}