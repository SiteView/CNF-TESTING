package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;

public class DataInCustomInfo
  implements DataInInfo
{
  private String _shortMessage;

  public DataInCustomInfo(String shortMessage)
  {
    this._shortMessage = shortMessage;
  }

  public String getShortMessage() {
    return this._shortMessage;
  }
}