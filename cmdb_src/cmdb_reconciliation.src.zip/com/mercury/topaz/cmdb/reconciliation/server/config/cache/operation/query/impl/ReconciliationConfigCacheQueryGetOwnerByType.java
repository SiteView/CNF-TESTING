package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ReconciliationConfigCacheQueryGetOwnerByType extends AbstractReconciliationConfigCacheQueryOperation
{
  private static final String NAME = "Reconciliation Config Cache Query - Get Owner By Type";
  private Collection<String> _typesCollection;
  private Map<String, Collection<String>> _ownerByTypeMap;
  public static final String OWNER_BY_TYPE = "ownerByType";

  public ReconciliationConfigCacheQueryGetOwnerByType(Collection<String> typesCollection)
  {
    setTypesCollection(typesCollection);
  }

  public ReconciliationConfigCacheQueryGetOwnerByType(String type) {
    Collection types = new ArrayList(1);
    types.add(type);
    setTypesCollection(types);
  }

  public String getOperationName() {
    return "Reconciliation Config Cache Query - Get Owner By Type";
  }

  public void configCacheQueryExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response) throws CmdbException
  {
    CmdbClassModel classModel = configCacheManager.getSynchronizedClassModel();
    Map ownerByTypeMap = new HashMap(getTypesCollection().size());
    for (Iterator i$ = getTypesCollection().iterator(); i$.hasNext(); ) { String currentType = (String)i$.next();
      ownerByTypeMap.put(currentType, configCacheManager.getOwnersByType(currentType, classModel));
    }
    setOwnerByTypeMap(ownerByTypeMap);
    response.addResult("ownerByType", (Serializable)ownerByTypeMap);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setOwnerByTypeMap((Map)response.getResult("ownerByType"));
  }

  private Collection<String> getTypesCollection() {
    return this._typesCollection;
  }

  private void setTypesCollection(Collection<String> typesCollection) {
    this._typesCollection = typesCollection;
  }

  public Map<String, Collection<String>> getOwnerByTypeMap() {
    return this._ownerByTypeMap;
  }

  private void setOwnerByTypeMap(Map<String, Collection<String>> ownerByTypeMap) {
    this._ownerByTypeMap = ownerByTypeMap;
  }
}