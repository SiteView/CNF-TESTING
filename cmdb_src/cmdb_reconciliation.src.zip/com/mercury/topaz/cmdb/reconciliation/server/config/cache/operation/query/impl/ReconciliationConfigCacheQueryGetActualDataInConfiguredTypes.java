package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.io.Serializable;
import java.util.Collection;
import java.util.Map;

public class ReconciliationConfigCacheQueryGetActualDataInConfiguredTypes extends AbstractReconciliationConfigCacheQueryOperation
{
  public static final String ACTUAL_TYPES_MAP = "typesMap";
  private final Collection<String> _types;
  private Map<String, String> _typesMap;

  public ReconciliationConfigCacheQueryGetActualDataInConfiguredTypes(Collection<String> types)
  {
    this._types = types;
  }

  public String getOperationName() {
    return "Reconciliation Config Cache Query - Get actual data in configured types " + getTypes();
  }

  public void configCacheQueryExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response) throws CmdbException {
    setTypesMap(configCacheManager.getActualDataInRuleConfiguredTypes(getTypes()));
    response.addResult("typesMap", (Serializable)getTypesMap());
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
    setTypesMap((Map)response.getResult("typesMap"));
  }

  private Collection<String> getTypes() {
    return this._types;
  }

  public Map<String, String> getTypesMap() {
    return this._typesMap;
  }

  private void setTypesMap(Map<String, String> typesMap) {
    this._typesMap = typesMap;
  }
}