package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.merge.manager.MergeManager;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.impl.AbstractMergeOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

abstract class AbstractMergeQueryOperation extends AbstractMergeOperation
{
  protected final void mergeExecute(MergeManager manager, CmdbResponse response)
    throws CmdbException
  {
    mergeQueryExecute(manager, response);
  }

  protected abstract void mergeQueryExecute(MergeManager paramMergeManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}