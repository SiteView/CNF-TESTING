package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.OwnerConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.OwnersConfigDef;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class OwnersConfigDefImpl
  implements OwnersConfigDef, IUnmarshallable, IMarshallable
{
  private Collection<OwnerConfigDef> _ownersCollection;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public OwnersConfigDefImpl()
  {
    setOwnersCollection(new ArrayList());
  }

  public Collection<OwnerConfigDef> getOwnersCollection() {
    return this._ownersCollection;
  }

  public void setOwnersCollection(Collection<OwnerConfigDef> ownersCollection) {
    this._ownersCollection = ownersCollection;
  }

  public Iterator<OwnerConfigDef> getOwnerIterator() {
    return getOwnersCollection().iterator();
  }

  public void addOwner(Object object) {
    getOwnersCollection().add((OwnerConfigDef)object);
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    OwnersConfigDefImpl that = (OwnersConfigDefImpl)o;

    if (this._ownersCollection != null) if (this._ownersCollection.equals(that._ownersCollection))
        break label62;
    label62: return (that._ownersCollection == null);
  }

  public int hashCode()
  {
    return ((this._ownersCollection != null) ? this._ownersCollection.hashCode() : 0);
  }
}