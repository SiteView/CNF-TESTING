package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class OldToNewIdMapping
  implements Iterable<Map.Entry<CmdbObjectID, CmdbObjectID>>
{
  private final Map<CmdbObjectID, CmdbObjectID> _idMapping;
  private final Map<CmdbObjectID, CmdbObjectID> _newToOldIdMapping;
  private final Map<String, String> _idMappingByString;

  public OldToNewIdMapping()
  {
    this._idMapping = new HashMap();
    this._newToOldIdMapping = new HashMap();
    this._idMappingByString = new HashMap();
  }

  public final CmdbObjectID get(CmdbObjectID id) {
    return get(id, id);
  }

  public final CmdbObjectID getOldId(CmdbObjectID newId) {
    return getOldId(newId, newId);
  }

  public final String get(String id) {
    return get(id, id);
  }

  public final CmdbObjectID get(CmdbObjectID id, CmdbObjectID defaultValue) {
    CmdbObjectID value = (CmdbObjectID)this._idMapping.get(id);
    return ((CmdbObjectID)returnValueWithDefault(value, defaultValue));
  }

  public final CmdbObjectID getOldId(CmdbObjectID id, CmdbObjectID defaultValue) {
    CmdbObjectID value = (CmdbObjectID)this._newToOldIdMapping.get(id);
    return ((CmdbObjectID)returnValueWithDefault(value, defaultValue));
  }

  public final String get(String id, String defaultValue) {
    String value = (String)this._idMappingByString.get(id);
    return ((String)returnValueWithDefault(value, defaultValue));
  }

  private <Type> Type returnValueWithDefault(Type value, Type defaultValue) {
    return ((null == value) ? defaultValue : value);
  }

  public final void put(CmdbObjectID source, CmdbObjectID target) {
    this._idMapping.put(source, target);
    this._newToOldIdMapping.put(target, source);
    this._idMappingByString.put(source.toString(), target.toString());
  }

  public Iterator<Map.Entry<CmdbObjectID, CmdbObjectID>> iterator() {
    return this._idMapping.entrySet().iterator();
  }

  String toString(DataContainer originalDataContainer, DataContainer manipulatedDataContainer) {
    StringBuilder sb = new StringBuilder();

    for (Iterator i$ = iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      CmdbObjectID originalId = (CmdbObjectID)entry.getKey();
      CmdbObjectID newId = (CmdbObjectID)entry.getValue();

      CmdbObject originalObject = originalDataContainer.getCmdbObject(originalId);
      CmdbObject newObject = manipulatedDataContainer.getCmdbObject(newId);
      sb.append("\nOld Object: ").append(originalObject.toString().replaceAll("\n", "\t"));
      sb.append("\nNew Object: ").append(newObject.toString().replaceAll("\n", "\t"));
    }

    return sb.toString();
  }

  public boolean isEmpty() {
    return this._idMapping.isEmpty();
  }
}