package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

public class IdentificationRuleWrapperDef
{
  private IdentificationRuleDef _rule;

  public IdentificationRuleWrapperDef(IdentificationRuleDef rule)
  {
    this._rule = rule;
  }

  public IdentificationRuleDef getRule()
  {
    return this._rule;
  }

  public void setRule(IdentificationRuleDef rule) {
    this._rule = rule;
  }
}