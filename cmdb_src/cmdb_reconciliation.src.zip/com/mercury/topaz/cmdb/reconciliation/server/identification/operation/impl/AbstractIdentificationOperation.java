package com.mercury.topaz.cmdb.reconciliation.server.identification.operation.impl;

import com.mercury.topaz.cmdb.reconciliation.server.identification.manager.IdentificationManager;
import com.mercury.topaz.cmdb.reconciliation.server.identification.operation.IdentificationOperation;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCmdbOperation;

public abstract class AbstractIdentificationOperation extends AbstractCmdbOperation
  implements IdentificationOperation
{
  public String getExecutionTaskQueueName()
  {
    return "Reconciliation Identification Task";
  }

  protected void doExecute(SubsystemManager manager, CmdbResponse response) throws CmdbException {
    identificationExecute((IdentificationManager)manager, response);
  }

  public String getServiceName() {
    return "CMDB_RECONCILE";
  }
}