package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.exception.DataInException;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInAnomalyInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.impl.DataInRuleOutputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.TempMergePropertiesInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.TempMergeTopologyInput;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.OptimisticModelUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddLinksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddOrIgnoreLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddOrUpdateLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddUpdateOrIgnoreLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.update.ModelUpdateLinksIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.update.ModelUpdateLinksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddObjectsStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddOrIgnoreObjects;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddOrUpdateObjects;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.update.ModelUpdateObjectsIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.update.ModelUpdateObjectsStrict;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DataInDefaultRule extends AbstractDataInRule
{
  private static final DataInRule _defaultRuleInstance;
  private static final Map<List<Integer>, Command<? extends CmdbDataID, ? extends CmdbData>> _commandsMap;

  public DataInDefaultRule(DataInRuleDefinition ruleDefinition)
  {
    super(ruleDefinition);
  }

  public static DataInRule getDefaultRuleInstance()
  {
    return _defaultRuleInstance; }

  public DataInRuleOutput onAddOrUpdateData(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, boolean ignoreInvalidLinks) {
    return onAdd(environment, dataInRuleInput, ignoreInvalidLinks, AddType.addOrUpdate);
  }

  public DataInRuleOutput onAddOrIgnoreData(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onAdd(environment, dataInRuleInput, false, AddType.addOrIgnore);
  }

  public DataInRuleOutput onAddDataStrict(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onAdd(environment, dataInRuleInput, false, AddType.addStrict);
  }

  public DataInRuleOutput onAdd(ReconciliationEnvironment ruleEnvironment, DataInRuleInput dataInRuleInput, boolean ignoreInvalidLinks, AddType addType)
  {
    List modelUpdateOperations = new ArrayList();
    boolean isObject = isObject(dataInRuleInput);
    UpdateDataHelper updateDataHelper = createUpdateDataHelper(isObject);
    CmdbDatas datasForAdd = updateDataHelper.createDatasCollection();
    CmdbDataIDs idsForTouch = CmdbDataIdsFactory.create();

    Iterator it = dataInRuleInput.getDataContainer().getDatasForUpdateIteratorByType(dataInRuleInput.getType());
    while (it.hasNext()) {
      CmdbData currentData = (CmdbData)it.next();
      boolean existingInCmdb = dataInRuleInput.getExistingDataMap().containsKeyWithNotEmptyValue(currentData.getDataID());

      if (existingInCmdb) {
        onAddForExistingInCmdb(ruleEnvironment, dataInRuleInput, currentData, isObject, datasForAdd, idsForTouch, updateDataHelper, addType);
      }
      else
        onAddForNotExistingInCmdb(ruleEnvironment, dataInRuleInput, currentData, datasForAdd, updateDataHelper);

    }

    updateDataHelper.mergeProperties(dataInRuleInput.getOwnerByType(), dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getDataInInfoList(), datasForAdd);

    if (!(datasForAdd.isEmpty()))
      addType.addModelUpdateOperation(datasForAdd, updateDataHelper, modelUpdateOperations, dataInRuleInput.getChanger(), ignoreInvalidLinks);

    return DataInRuleOutputFactory.createDataInRuleOutput(modelUpdateOperations, idsForTouch);
  }

  private void onAddForExistingInCmdb(ReconciliationEnvironment ruleEnvironment, DataInRuleInput dataInRuleInput, CmdbData currentData, boolean isObject, CmdbDatas<? extends CmdbDataID, ? extends CmdbData> datasForAdd, CmdbDataIDs idsForTouch, UpdateDataHelper updateDataHelper, AddType addType)
  {
    Collection dataFromCmdb = dataInRuleInput.getExistingDataMap().get(currentData.getDataID());
    Collection existingInBulk = dataInRuleInput.getExistingDataMap().getInBulk(currentData.getDataID());

    if (!(shouldContinueOnExistingDatas(currentData, dataFromCmdb, dataInRuleInput.getDataInAnomalyInfoList(), dataInRuleInput.getInputIDAsStringToReconciledIDsMap()))) {
      return;
    }

    boolean existsInBulk = (addType.shouldCheckIfExist()) && (dataInRuleInput.getExistingDataMap().containsKeyWithNotEmptyValueInBulk(currentData.getDataID()));
    boolean existsInCmdb = (addType.shouldCheckIfExist()) && (dataInRuleInput.getExistingDataMap().containsKeyWithNotEmptyValue(currentData.getDataID()));

    List listOfSizes = Arrays.asList(new Integer[] { Integer.valueOf(getIntValue(isObject)), Integer.valueOf(getIntValue(existsInBulk)), Integer.valueOf(getIntValue(existsInCmdb)) });

    Command command = (Command)_commandsMap.get(listOfSizes);
    if (null == command) {
      throw new DataInException("no command found for combination of " + listOfSizes);
    }

    if (existingInBulk == null)
      existingInBulk = new ArrayList(1);

    Collection newExistingInBulk = updateDataHelper.addToDataCollection(currentData, existingInBulk);

    Collection remainingDatas = chooseRemainingData(currentData, dataFromCmdb, dataInRuleInput.getInputIDToReconciledIDsMap());
    for (Iterator i$ = remainingDatas.iterator(); i$.hasNext(); ) { CmdbData remainingData = (CmdbData)i$.next();
      Collection newDataFromCmdb = ((dataFromCmdb == null) || (dataFromCmdb.isEmpty())) ? dataFromCmdb : Arrays.asList(new CmdbData[] { remainingData });
      updateDataHelper.handleCommand(addType, command, idsForTouch, remainingData, newExistingInBulk, newDataFromCmdb, ruleEnvironment, dataInRuleInput, datasForAdd);
    }
  }

  private void onAddForNotExistingInCmdb(ReconciliationEnvironment ruleEnvironment, DataInRuleInput dataInRuleInput, CmdbData currentData, CmdbDatas<? extends CmdbDataID, ? extends CmdbData> datasForAdd, UpdateDataHelper updateDataHelper)
  {
    CmdbDatas resolvedDatas = DataInUtil.resolveCmdbData(ruleEnvironment.getDataFactory(), currentData, dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getInputIDToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());

    if (!(shouldContinueOnExistingDatas(currentData, resolvedDatas, dataInRuleInput.getDataInAnomalyInfoList(), dataInRuleInput.getInputIDAsStringToReconciledIDsMap()))) {
      return;
    }

    ReadOnlyIterator resolvedIt = resolvedDatas.getDatasIterator();
    while (resolvedIt.hasNext()) {
      CmdbData currentResolvedData = (CmdbData)resolvedIt.next();
      updateDataHelper.addToDataCollection(currentResolvedData, datasForAdd);
    }
  }

  private Collection<? extends CmdbData> chooseRemainingData(CmdbData currentResolvedData, Collection<? extends CmdbData> dataFromCmdb, Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap) {
    if ((dataFromCmdb != null) && (!(dataFromCmdb.isEmpty())))
    {
      CmdbDataIDs ids = CmdbDataIdsFactory.createList();
      for (Iterator i$ = dataFromCmdb.iterator(); i$.hasNext(); ) { CmdbData data = (CmdbData)i$.next();
        if (!(currentResolvedData.getDataID().equals(data.getID())))
          ids.add(data.getDataID());

        if (!(ids.isEmpty()))
          inputIDToReconciledIDsMap.put(currentResolvedData.getDataID(), ids);
      }

      return dataFromCmdb;
    }
    return Arrays.asList(new CmdbData[] { currentResolvedData });
  }

  int getIntValue(boolean boolValue) {
    return ((boolValue) ? 1 : 0);
  }

  int getIntValue(boolean boolValue, boolean checkedForExistence) {
    return ((checkedForExistence) ? 0 : (boolValue) ? 1 : -1);
  }

  private boolean shouldContinueOnExistingDatas(CmdbData inputData, Collection<? extends CmdbData> existingDatas, List<DataInAnomalyInfo> dataInAnomalyInfoList, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs) {
    if (existingDatas.size() > 1) {
      String moreThanOneMatchAction = getRuleDefinition().getConfigurationParam("more-than-one-match");
      if (moreThanOneMatchAction == null)
        moreThanOneMatchAction = "IGNORE";

      DataInAnomalyInfo info = new DataInAnomalyInfo(inputData, moreThanOneMatchAction, existingDatas, null, null);
      dataInAnomalyInfoList.add(info);
      if (moreThanOneMatchAction.equals("ERROR"))
        throw new DataInException("The data: " + inputData + " has more than one match. existing datas: " + existingDatas);

      if (moreThanOneMatchAction.equals("IGNORE")) {
        inputIDAsStringToReconciledIDs.put(inputData.getDataID().toString(), null);
        return false;
      }
    }
    return true;
  }

  private boolean shouldContinueOnExistingDatas(CmdbData inputData, CmdbDatas existingDatas, List<DataInAnomalyInfo> dataInAnomalynfoList, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs) {
    Collection existingDatasColl = new ArrayList(existingDatas.size());
    ReadOnlyIterator it = existingDatas.getDatasIterator();
    while (it.hasNext())
      existingDatasColl.add((CmdbData)it.next());

    return shouldContinueOnExistingDatas(inputData, existingDatasColl, dataInAnomalynfoList, inputIDAsStringToReconciledIDs);
  }

  private void addExistingDatasToCollAndToInputToReconciledlMap(CmdbData inputData, DataInRuleInput dataInRuleInput, CmdbDatas exisitingDataColl) {
    List existingDatas = (List)dataInRuleInput.getExistingDataMap().get(inputData.getDataID());
    if (!(shouldContinueOnExistingDatas(inputData, existingDatas, dataInRuleInput.getDataInAnomalyInfoList(), dataInRuleInput.getInputIDAsStringToReconciledIDsMap())))
      return;

    CmdbDataIDs existingIDs = CmdbDataIdsFactory.create();
    boolean isSameID = true;
    for (Iterator i$ = existingDatas.iterator(); i$.hasNext(); ) { CmdbData existingData = (CmdbData)i$.next();
      exisitingDataColl.add(existingData);
      existingIDs.add(existingData.getDataID());
      if (!(existingData.getDataID().equals(inputData.getDataID())))
        isSameID = false;
    }

    if ((!(existingIDs.isEmpty())) && (!(isSameID))) {
      dataInRuleInput.getInputIDAsStringToReconciledIDsMap().put(inputData.getDataID().toString(), existingIDs);
      dataInRuleInput.getInputIDToReconciledIDsMap().put(inputData.getDataID(), existingIDs);
    }
  }

  private DataInRuleOutput onRemove(ReconciliationEnvironment ruleEnvironment, DataInRuleInput dataInRuleInput, RemoveType removeType)
  {
    List modelUpdateOperations = new ArrayList();
    boolean isObject = isObject(dataInRuleInput);
    UpdateDataHelper updateDataHelper = createUpdateDataHelper(isObject);
    CmdbDatas datasForRemove = updateDataHelper.createDatasCollection();
    Iterator it = dataInRuleInput.getDataContainer().getDatasForUpdateIteratorByType(dataInRuleInput.getType());

    while (it.hasNext()) {
      CmdbData currentData = (CmdbData)it.next();
      boolean checkedForExistenceInCmdb = dataInRuleInput.getExistingDataMap().containsKey(currentData.getDataID());
      if (checkedForExistenceInCmdb) {
        boolean dataExists = dataInRuleInput.getExistingDataMap().containsKeyWithNotEmptyValue(currentData.getDataID());
        if (dataExists) {
          addExistingDatasToCollAndToInputToReconciledlMap(currentData, dataInRuleInput, datasForRemove);
        }
        else
          removeType.onRemoveNotExistingData(currentData);
      }
      else
      {
        CmdbDatas resolvedDatas = DataInUtil.resolveCmdbData(ruleEnvironment.getDataFactory(), currentData, dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getInputIDToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());
        ReadOnlyIterator resolvedIt = resolvedDatas.getDatasIterator();
        while (resolvedIt.hasNext())
          datasForRemove.add((CmdbData)resolvedIt.next());

      }

    }

    removeType.addModelUpdateOperation(datasForRemove, updateDataHelper, modelUpdateOperations, dataInRuleInput.getChanger());
    return DataInRuleOutputFactory.createDataInRuleOutput(modelUpdateOperations); }

  public DataInRuleOutput onRemoveDataIfExist(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onRemove(environment, dataInRuleInput, RemoveType.removeIfExist);
  }

  public DataInRuleOutput onRemoveDataStrict(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onRemove(environment, dataInRuleInput, RemoveType.removeStrict);
  }

  private void addDataForUpdateToMergeInput(CmdbData inputData, DataInRuleInput dataInRuleInput, UpdateDataHelper updateDataHelper) {
    Collection existingDatas = dataInRuleInput.getExistingDataMap().get(inputData.getDataID());
    Collection newExistingInBulk = updateDataHelper.addToDataCollection(inputData, dataInRuleInput.getExistingDataMap().getInBulk(inputData.getDataID()));

    if (!(shouldContinueOnExistingDatas(inputData, existingDatas, dataInRuleInput.getDataInAnomalyInfoList(), dataInRuleInput.getInputIDAsStringToReconciledIDsMap()))) {
      return;
    }

    Collection remainingDatas = chooseRemainingData(inputData, existingDatas, dataInRuleInput.getInputIDToReconciledIDsMap());
    for (Iterator i$ = remainingDatas.iterator(); i$.hasNext(); ) { CmdbData remainingData = (CmdbData)i$.next();
      Collection newExistingData = ((existingDatas == null) || (existingDatas.isEmpty())) ? existingDatas : Arrays.asList(new CmdbData[] { remainingData });
      updateDataHelper.addToMergeInput(remainingData, newExistingData, newExistingInBulk);
    }
  }

  public DataInRuleOutput onUpdate(ReconciliationEnvironment ruleEnvironment, DataInRuleInput dataInRuleInput, UpdateType updateType)
  {
    List modelUpdateOperations = new ArrayList();
    boolean isObject = isObject(dataInRuleInput);
    UpdateDataHelper updateDataHelper = createUpdateDataHelper(isObject);
    CmdbDatas datasForUpdate = updateDataHelper.createDatasCollection();
    Iterator it = dataInRuleInput.getDataContainer().getDatasForUpdateIteratorByType(dataInRuleInput.getType());
    while (it.hasNext()) {
      CmdbData currentData = (CmdbData)it.next();
      boolean checkedForExistenceInCmdb = dataInRuleInput.getExistingDataMap().containsKey(currentData.getDataID());
      if (checkedForExistenceInCmdb) {
        boolean dataExists = dataInRuleInput.getExistingDataMap().containsKeyWithNotEmptyValue(currentData.getDataID());
        if (dataExists)
        {
          addDataForUpdateToMergeInput(currentData, dataInRuleInput, updateDataHelper);
        }
        else
          updateType.onUpdateNotExistingData(currentData);
      }
      else
      {
        CmdbDatas resolvedDatas = DataInUtil.resolveCmdbData(ruleEnvironment.getDataFactory(), currentData, dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getInputIDToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());
        ReadOnlyIterator resolvedIt = resolvedDatas.getDatasIterator();
        while (resolvedIt.hasNext())
          datasForUpdate.add((CmdbData)resolvedIt.next());

      }

    }

    updateDataHelper.mergeProperties(dataInRuleInput.getOwnerByType(), dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getDataInInfoList(), datasForUpdate);

    updateType.addModelUpdateOperation(datasForUpdate, updateDataHelper, modelUpdateOperations, dataInRuleInput.getChanger());
    return DataInRuleOutputFactory.createDataInRuleOutput(modelUpdateOperations);
  }

  public DataInRuleOutput onUpdateDataIfExist(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onUpdate(environment, dataInRuleInput, UpdateType.updateIfExist);
  }

  public DataInRuleOutput onUpdateDataStrict(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onUpdate(environment, dataInRuleInput, UpdateType.updateStrict);
  }

  private boolean isObject(DataInRuleInput dataInRuleInput)
  {
    Iterator it = dataInRuleInput.getDataContainer().getDatasForUpdateIteratorByType(dataInRuleInput.getType());
    if (it.hasNext()) {
      return ((CmdbData)it.next()).getDataID().isObjectID();
    }

    throw new DataInException("no data from type " + dataInRuleInput.getType() + " in the data container");
  }

  private UpdateDataHelper createUpdateDataHelper(boolean isObject)
  {
    if (isObject) {
      return new UpdateObjectHelper();
    }

    return new UpdateLinkHelper();
  }

  protected static void addIgnoredDataToInputToReconciledMap(Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap, CmdbDataID inputID, Collection<? extends CmdbData> existingData)
  {
    if ((!(inputIDToReconciledIDsMap.containsKey(inputID))) && (existingData.size() > 0)) {
      CmdbDataIDs ids = CmdbDataIdsFactory.create();
      for (Iterator i$ = existingData.iterator(); i$.hasNext(); ) { CmdbData currentData = (CmdbData)i$.next();
        if (!(inputID.equals(currentData.getID())))
          ids.add((CmdbDataID)currentData.getID());
      }

      if (ids.size() > 0)
        inputIDToReconciledIDsMap.put(inputID, ids);
    }
  }

  static
  {
    Map params = new HashMap();
    params.put("more-than-one-match", "IGNORE");
    _defaultRuleInstance = new DataInDefaultRule(DataInRuleDefinitionFactory.createDataInRuleDefinition(params));

    _commandsMap = new HashMap();

    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0) }), AddCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0) }), AddCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1) }), MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1) }), MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0) }), MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0) }), MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(1) }), MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1) }), MergePropertiesCommand.getInstance());
  }

  protected static class AddCommand<ID extends CmdbDataID, Type extends CmdbData>
  implements DataInDefaultRule.Command<ID, Type>
  {
    private static final AddCommand _instance = new AddCommand();

    public static <ID extends CmdbDataID, Type extends CmdbData> AddCommand<ID, Type> getInstance() {
      return _instance;
    }

    public void handle(Type remainingObject, Collection<Type> datasFromBulk, Collection<Type> datasFromCMDB, Collection<TempMergePropertiesInput<Type>> mergePropertiesInputs, Collection<TempMergeTopologyInput<Type>> mergeTopologyInputs, CmdbDatas<ID, Type> datasToAdd, CmdbObjectIds objectsToRemove, CmdbClassModel classModel)
    {
      datasToAdd.add(remainingObject);
    }
  }

  protected static class MergeTopologyCommand
  implements DataInDefaultRule.Command<CmdbObjectID, CmdbObject>
  {
    private static final MergeTopologyCommand _instance;

    public static MergeTopologyCommand getInstance()
    {
      return _instance;
    }

    public void handle(CmdbObject remainingObject, Collection<CmdbObject> datasFromBulk, Collection<CmdbObject> datasFromCMDB, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbDatas<CmdbObjectID, CmdbObject> datasToAdd, CmdbObjectIds objectsToRemove, CmdbClassModel classModel)
    {
      if ((!($assertionsDisabled)) && (datasFromBulk.isEmpty())) throw new AssertionError();
      if ((!($assertionsDisabled)) && (datasFromCMDB.isEmpty())) throw new AssertionError();

      mergeTopologyInputs.add(new TempMergeTopologyInput(remainingObject, datasFromCMDB));
    }

    static
    {
      _instance = new MergeTopologyCommand();
    }
  }

  protected static class MergePropertiesCommand<ID extends CmdbDataID, Type extends CmdbData>
  implements DataInDefaultRule.Command<ID, Type>
  {
    private static final MergePropertiesCommand _instance;

    public static <ID extends CmdbDataID, Type extends CmdbData> MergePropertiesCommand<ID, Type> getInstance()
    {
      return _instance;
    }

    public void handle(Type remainingObject, Collection<Type> datasFromBulk, Collection<Type> datasFromCMDB, Collection<TempMergePropertiesInput<Type>> mergePropertiesInputs, Collection<TempMergeTopologyInput<Type>> mergeTopologyInputs, CmdbDatas<ID, Type> datasToAdd, CmdbObjectIds objectsToRemove, CmdbClassModel classModel)
    {
      if ((!($assertionsDisabled)) && (datasFromBulk.size() + datasFromCMDB.size() <= 1)) throw new AssertionError();

      mergePropertiesInputs.add(new TempMergePropertiesInput(remainingObject, datasFromCMDB, datasFromBulk));
    }

    static
    {
      _instance = new MergePropertiesCommand();
    }
  }

  protected static class MergePropertiesIgnoreCmdbAndTopologyCommand
  implements DataInDefaultRule.Command<CmdbObjectID, CmdbObject>
  {
    private static final MergePropertiesIgnoreCmdbAndTopologyCommand _instance;

    public static MergePropertiesIgnoreCmdbAndTopologyCommand getInstance()
    {
      return _instance;
    }

    public void handle(CmdbObject remainingObject, Collection<CmdbObject> datasFromBulk, Collection<CmdbObject> datasFromCMDB, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbDatas<CmdbObjectID, CmdbObject> datasToAdd, CmdbObjectIds objectsToRemove, CmdbClassModel classModel)
    {
      if ((!($assertionsDisabled)) && (datasFromBulk.isEmpty())) throw new AssertionError();
      if ((!($assertionsDisabled)) && (datasFromCMDB.isEmpty())) throw new AssertionError();

      mergePropertiesInputs.add(new TempMergePropertiesInput(remainingObject, Collections.emptyList(), datasFromBulk));
      mergeTopologyInputs.add(new TempMergeTopologyInput(remainingObject, datasFromCMDB));
    }

    static
    {
      _instance = new MergePropertiesIgnoreCmdbAndTopologyCommand();
    }
  }

  protected static class MergePropertiesAndTopologyCommand
  implements DataInDefaultRule.Command<CmdbObjectID, CmdbObject>
  {
    private static final MergePropertiesAndTopologyCommand _instance;

    public static MergePropertiesAndTopologyCommand getInstance()
    {
      return _instance;
    }

    public void handle(CmdbObject remainingObject, Collection<CmdbObject> datasFromBulk, Collection<CmdbObject> datasFromCMDB, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbDatas<CmdbObjectID, CmdbObject> datasToAdd, CmdbObjectIds objectsToRemove, CmdbClassModel classModel)
    {
      if ((!($assertionsDisabled)) && (datasFromBulk.isEmpty())) throw new AssertionError();
      if ((!($assertionsDisabled)) && (datasFromCMDB.isEmpty())) throw new AssertionError();

      mergePropertiesInputs.add(new TempMergePropertiesInput(remainingObject, datasFromBulk, datasFromCMDB));
      mergeTopologyInputs.add(new TempMergeTopologyInput(remainingObject, datasFromCMDB));
    }

    static
    {
      _instance = new MergePropertiesAndTopologyCommand();
    }
  }

  protected static abstract interface Command<ID extends CmdbDataID, Type extends CmdbData>
  {
    public abstract void handle(Type paramType, Collection<Type> paramCollection1, Collection<Type> paramCollection2, Collection<TempMergePropertiesInput<Type>> paramCollection, Collection<TempMergeTopologyInput<Type>> paramCollection3, CmdbDatas<ID, Type> paramCmdbDatas, CmdbObjectIds paramCmdbObjectIds, CmdbClassModel paramCmdbClassModel);
  }

  private static abstract enum UpdateType
  {
    updateIfExist, updateStrict;

    public static final UpdateType[] values()
    {
      return ((UpdateType[])$VALUES.clone());
    }

    abstract void addModelUpdateOperation(CmdbDatas paramCmdbDatas, DataInDefaultRule.UpdateDataHelper paramUpdateDataHelper, List<ModelUpdate> paramList, Changer paramChanger);

    abstract void onUpdateNotExistingData(CmdbData paramCmdbData);
  }

  private static abstract enum RemoveType
  {
    removeIfExist, removeStrict;

    public static final RemoveType[] values()
    {
      return ((RemoveType[])$VALUES.clone());
    }

    abstract void addModelUpdateOperation(CmdbDatas paramCmdbDatas, DataInDefaultRule.UpdateDataHelper paramUpdateDataHelper, List<ModelUpdate> paramList, Changer paramChanger);

    abstract void onRemoveNotExistingData(CmdbData paramCmdbData);
  }

  private static abstract enum AddType
  {
    addStrict, addOrIgnore, addOrUpdate;

    public static final AddType[] values()
    {
      return ((AddType[])$VALUES.clone());
    }

    abstract <ID extends CmdbDataID, Type extends CmdbData> void handleCommand(DataInDefaultRule.Command<ID, Type> paramCommand, DataInDefaultRule.UpdateDataHelper paramUpdateDataHelper, CmdbDataIDs paramCmdbDataIDs, Type paramType, Collection<Type> paramCollection1, Collection<Type> paramCollection2, ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput, Collection<TempMergePropertiesInput<Type>> paramCollection, CmdbDatas<ID, Type> paramCmdbDatas, CmdbObjectIds paramCmdbObjectIds);

    abstract boolean shouldCheckIfExist();

    abstract void addModelUpdateOperation(CmdbDatas paramCmdbDatas, DataInDefaultRule.UpdateDataHelper paramUpdateDataHelper, List<ModelUpdate> paramList, Changer paramChanger, boolean paramBoolean);
  }

  private static class UpdateLinkHelper
  implements DataInDefaultRule.UpdateDataHelper
  {
    final Collection<TempMergePropertiesInput<CmdbLink>> _mergeInputs;

    public UpdateLinkHelper()
    {
      this._mergeInputs = new LinkedList();
    }

    public CmdbLinks createDatasCollection() {
      return CmdbLinkFactory.createLinks();
    }

    public void addToMergeInput(CmdbData dataToUpdate, Collection<? extends CmdbData> existingDatas, Collection<? extends CmdbData> existingInBulk)
    {
      this._mergeInputs.add(new TempMergePropertiesInput((CmdbLink)dataToUpdate, existingDatas, existingInBulk));
    }

    public void mergeProperties(Set<String> isOwnerByType, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDsMap, List<DataInInfo> info, CmdbDatas datas) {
      if ((this._mergeInputs != null) && (!(this._mergeInputs.isEmpty()))) {
        Map mergedDataMap = DataInUtil.mergeRelationsProperties(this._mergeInputs, isOwnerByType, inputIDAsStringToReconciledIDsMap, info);
        for (Iterator i$ = mergedDataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
          CmdbLink currentResult = (CmdbLink)entry.getValue();
          datas.add(currentResult);
        }
      }
    }

    public Collection<? extends CmdbData> addToDataCollection(CmdbData currentData, Collection<? extends CmdbData> coll)
    {
      Collection newDataCollection = new ArrayList(coll);
      newDataCollection.add((CmdbLink)currentData);
      return newDataCollection;
    }

    public void addToDataCollection(CmdbData currentData, CmdbDatas coll) {
      coll.add(currentData);
    }

    public void handleCommand(DataInDefaultRule.AddType addType, DataInDefaultRule.Command command, CmdbDataIDs idsForTouch, CmdbData currentResolvedData, Collection<? extends CmdbData> inBulk, Collection<? extends CmdbData> cmdbDatas, ReconciliationEnvironment ruleEnvironment, DataInRuleInput dataInRuleInput, CmdbDatas<? extends CmdbDataID, ? extends CmdbData> datasForAdd)
    {
      addType.handleCommand(command, this, idsForTouch, (CmdbLink)currentResolvedData, inBulk, cmdbDatas, ruleEnvironment, dataInRuleInput, this._mergeInputs, (CmdbLinks)datasForAdd, null);
    }

    public void addAddOrUpdateOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer, boolean ignoreInvalidLinks) {
      if (!(datas.isEmpty()))
      {
        OptimisticModelUpdate add;
        if (ignoreInvalidLinks) {
          add = new ModelUpdateAddUpdateOrIgnoreLinks((CmdbLinks)datas, changer);
        }
        else
          add = new ModelUpdateAddOrUpdateLinks((CmdbLinks)datas, changer);

        modelUpdateOperations.add(add);
      }
    }

    public void addAddOrIgnoreOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer) {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateAddOrIgnoreLinks((CmdbLinks)datas, changer));
    }

    public void addAddStrictOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateAddLinksStrict((CmdbLinks)datas, changer));
    }

    public void addUpdateIfExistsOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateLinksIfExist((CmdbLinks)datas, changer));
    }

    public void addUpdateStrictOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateLinksStrict((CmdbLinks)datas, changer));
    }

    public void addRemoveIfExistsOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateRemoveLinksIfExist((CmdbLinks)datas, changer));
    }

    public void addRemoveStrictOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateRemoveLinksStrict((CmdbLinks)datas, changer));
    }
  }

  private static class UpdateObjectHelper
  implements DataInDefaultRule.UpdateDataHelper
  {
    Collection<TempMergePropertiesInput<CmdbObject>> _mergeInputs;

    public UpdateObjectHelper()
    {
      this._mergeInputs = new LinkedList();
    }

    public CmdbObjects createDatasCollection() {
      return CmdbObjectFactory.createObjects();
    }

    public void addToMergeInput(CmdbData dataToUpdate, Collection<? extends CmdbData> existingDatas, Collection<? extends CmdbData> existingInBulk)
    {
      this._mergeInputs.add(new TempMergePropertiesInput((CmdbObject)dataToUpdate, existingDatas, existingInBulk));
    }

    public void mergeProperties(Set<String> isOwnerByType, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDsMap, List<DataInInfo> info, CmdbDatas datas) {
      if ((this._mergeInputs != null) && (!(this._mergeInputs.isEmpty())))
      {
        Map mergedDataMap = DataInUtil.mergeCIProperties(this._mergeInputs, isOwnerByType, inputIDAsStringToReconciledIDsMap, info);
        for (Iterator i$ = mergedDataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
          CmdbObject currentResult = (CmdbObject)entry.getValue();
          datas.add(currentResult);
        }
      }
    }

    public Collection<? extends CmdbData> addToDataCollection(CmdbData currentData, Collection<? extends CmdbData> coll)
    {
      Collection newDataCollection = new ArrayList(coll);
      newDataCollection.add((CmdbObject)currentData);
      return newDataCollection;
    }

    public void addToDataCollection(CmdbData currentData, CmdbDatas coll) {
      coll.add(currentData);
    }

    public void handleCommand(DataInDefaultRule.AddType addType, DataInDefaultRule.Command command, CmdbDataIDs idsForTouch, CmdbData currentResolvedData, Collection<? extends CmdbData> inBulk, Collection<? extends CmdbData> cmdbDatas, ReconciliationEnvironment ruleEnvironment, DataInRuleInput dataInRuleInput, CmdbDatas<? extends CmdbDataID, ? extends CmdbData> datasForAdd)
    {
      addType.handleCommand(command, this, idsForTouch, (CmdbObject)currentResolvedData, inBulk, cmdbDatas, ruleEnvironment, dataInRuleInput, this._mergeInputs, (CmdbObjects)datasForAdd, null);
    }

    public void addAddOrUpdateOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer, boolean ignoreInvalidLinks) {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateAddOrUpdateObjects((CmdbObjects)datas, changer));
    }

    public void addAddOrIgnoreOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateAddOrIgnoreObjects((CmdbObjects)datas, changer));
    }

    public void addAddStrictOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateAddObjectsStrict((CmdbObjects)datas, changer));
    }

    public void addUpdateIfExistsOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateObjectsIfExist((CmdbObjects)datas, changer));
    }

    public void addUpdateStrictOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateObjectsStrict((CmdbObjects)datas, changer));
    }

    public void addRemoveIfExistsOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateRemoveObjectsIfExist(((CmdbObjects)datas).asIds(), changer));
    }

    public void addRemoveStrictOperation(List<ModelUpdate> modelUpdateOperations, CmdbDatas datas, Changer changer)
    {
      if (!(datas.isEmpty()))
        modelUpdateOperations.add(new ModelUpdateRemoveObjectsStrict(((CmdbObjects)datas).asIds(), changer));
    }
  }

  private static abstract interface UpdateDataHelper
  {
    public abstract CmdbDatas<? extends CmdbDataID, ? extends CmdbData> createDatasCollection();

    public abstract void addToMergeInput(CmdbData paramCmdbData, Collection<? extends CmdbData> paramCollection1, Collection<? extends CmdbData> paramCollection2);

    public abstract void mergeProperties(Set<String> paramSet, Map<String, CmdbDataIDs> paramMap, List<DataInInfo> paramList, CmdbDatas paramCmdbDatas);

    public abstract void addAddOrUpdateOperation(List<ModelUpdate> paramList, CmdbDatas paramCmdbDatas, Changer paramChanger, boolean paramBoolean);

    public abstract void addAddOrIgnoreOperation(List<ModelUpdate> paramList, CmdbDatas paramCmdbDatas, Changer paramChanger);

    public abstract void addAddStrictOperation(List<ModelUpdate> paramList, CmdbDatas paramCmdbDatas, Changer paramChanger);

    public abstract void addUpdateIfExistsOperation(List<ModelUpdate> paramList, CmdbDatas paramCmdbDatas, Changer paramChanger);

    public abstract void addUpdateStrictOperation(List<ModelUpdate> paramList, CmdbDatas paramCmdbDatas, Changer paramChanger);

    public abstract void addRemoveIfExistsOperation(List<ModelUpdate> paramList, CmdbDatas paramCmdbDatas, Changer paramChanger);

    public abstract void addRemoveStrictOperation(List<ModelUpdate> paramList, CmdbDatas paramCmdbDatas, Changer paramChanger);

    public abstract Collection<? extends CmdbData> addToDataCollection(CmdbData paramCmdbData, Collection<? extends CmdbData> paramCollection);

    public abstract void addToDataCollection(CmdbData paramCmdbData, CmdbDatas<? extends CmdbDataID, ? extends CmdbData> paramCmdbDatas);

    public abstract void handleCommand(DataInDefaultRule.AddType paramAddType, DataInDefaultRule.Command paramCommand, CmdbDataIDs paramCmdbDataIDs, CmdbData paramCmdbData, Collection<? extends CmdbData> paramCollection1, Collection<? extends CmdbData> paramCollection2, ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput, CmdbDatas<? extends CmdbDataID, ? extends CmdbData> paramCmdbDatas);
  }
}