package com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.admin.manager.ReconciliationConfigAdminManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.update.impl.ReconciliationConfigCacheRemoveConfig;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsIfExist;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class ReconciliationConfigAdminRemoveConfig extends AbstractReconciliationConfigUpdateAdminOperation
{
  private Collection<String> _configNames;

  public ReconciliationConfigAdminRemoveConfig(String configName, Changer changer)
  {
    super(changer);
    Collection configNames = new ArrayList(1);
    configNames.add(configName);
    setConfigNames(configNames);
  }

  public ReconciliationConfigAdminRemoveConfig(Collection<String> configNames, Changer changer) {
    super(changer);
    setConfigNames(configNames);
  }

  public String getOperationName() {
    return "Reconciliation Config Update - Remove Config";
  }

  public void configUpdateExecute(ReconciliationConfigAdminManager configAdminManager, CmdbResponse response) throws CmdbException {
    DataFactory dataFactory = DataFactoryCreator.create(configAdminManager.getSynchronizedClassModel());
    CmdbObjectIds idsToRemove = CmdbObjectIdsFactory.create();
    for (Iterator i$ = getConfigNames().iterator(); i$.hasNext(); ) { String configName = (String)i$.next();
      CmdbProperties props = CmdbPropertyFactory.createProperties();
      props.add(CmdbPropertyFactory.createProperty("data_name", configName));
      CmdbObjectID configID = dataFactory.createObjectID("reconciliation_configuration", props);
      idsToRemove.add(configID);
    }
    if (idsToRemove.size() > 0) {
      updatePersistency(configAdminManager, idsToRemove);
      updateCache(configAdminManager);
    }
  }

  private void updatePersistency(OperationExecutor executor, CmdbObjectIds configIDs) {
    ModelUpdateRemoveObjectsIfExist remove = new ModelUpdateRemoveObjectsIfExist(configIDs, getChanger());
    executor.executeOperation(remove);
  }

  private void updateCache(ReconciliationConfigAdminManager configAdminManager) {
    ReconciliationConfigCacheRemoveConfig removeFromCache = new ReconciliationConfigCacheRemoveConfig(getConfigNames());
    configAdminManager.executeOperation(removeFromCache);
  }

  public Collection<String> getConfigNames() {
    return this._configNames;
  }

  public void setConfigNames(Collection<String> configNames) {
    this._configNames = configNames;
  }
}