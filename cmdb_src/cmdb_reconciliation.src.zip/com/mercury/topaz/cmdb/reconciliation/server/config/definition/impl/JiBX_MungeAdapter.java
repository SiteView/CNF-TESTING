package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

public abstract class JiBX_MungeAdapter
{
}