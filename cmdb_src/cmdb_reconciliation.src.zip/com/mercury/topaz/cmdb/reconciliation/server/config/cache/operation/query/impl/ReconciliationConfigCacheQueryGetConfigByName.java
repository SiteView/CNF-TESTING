package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ReconciliationConfigDef;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class ReconciliationConfigCacheQueryGetConfigByName extends AbstractReconciliationConfigCacheQueryOperation
{
  public static final String CONFIG_DEF = "configDef";
  private String _configName;
  private ReconciliationConfigDef _configDef;

  public ReconciliationConfigCacheQueryGetConfigByName(String configName)
  {
    setConfigName(configName);
  }

  public String getOperationName() {
    return "Reconciliation Config Cache Query - Get Config By Name";
  }

  public void configCacheQueryExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response) throws CmdbException {
    setConfigDef(configCacheManager.getConfigDef(getConfigName()));
    response.addResult("configDef", getConfigDef());
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setConfigDef((ReconciliationConfigDef)response.getResult("configDef"));
  }

  private String getConfigName() {
    return this._configName;
  }

  private void setConfigName(String configName) {
    this._configName = configName;
  }

  public ReconciliationConfigDef getConfigDef() {
    return this._configDef;
  }

  private void setConfigDef(ReconciliationConfigDef configDef) {
    this._configDef = configDef;
  }
}