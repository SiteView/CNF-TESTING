package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import java.io.Serializable;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class CiIdCondition
  implements Serializable, IUnmarshallable, IMarshallable
{
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";
}