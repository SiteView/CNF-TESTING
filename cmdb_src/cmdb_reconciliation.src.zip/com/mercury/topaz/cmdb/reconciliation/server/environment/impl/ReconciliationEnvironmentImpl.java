package com.mercury.topaz.cmdb.reconciliation.server.environment.impl;

import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;

class ReconciliationEnvironmentImpl
  implements ReconciliationEnvironment
{
  private CmdbClassModel _cmdbClassModel;
  private DataFactory _dataFactory;

  public ReconciliationEnvironmentImpl(DataFactory dataFactory, CmdbClassModel cmdbClassModel)
  {
    setDataFactory(dataFactory);
    setCmdbClassModel(cmdbClassModel);
  }

  public DataFactory getDataFactory() {
    return this._dataFactory;
  }

  private void setDataFactory(DataFactory dataFactory) {
    this._dataFactory = dataFactory;
  }

  public CmdbClassModel getCmdbClassModel() {
    return this._cmdbClassModel;
  }

  private void setCmdbClassModel(CmdbClassModel cmdbClassModel) {
    this._cmdbClassModel = cmdbClassModel;
  }
}