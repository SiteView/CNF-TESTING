package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class IdentificationConfiguration
  implements Serializable, IUnmarshallable, IMarshallable
{
  protected final Collection<IdentificationRuleConfig> identificationRuleConfig;
  protected final Collection<IdentificationRuleProprietaryConfig> identificationRuleProprietaryConfig;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public IdentificationConfiguration()
  {
    this.identificationRuleConfig = new ArrayList(1);
    this.identificationRuleProprietaryConfig = new ArrayList(1);
  }

  public IdentificationConfiguration(int identificationRuleConfigSize, int identificationRuleProprietaryConfigSize) {
    this.identificationRuleConfig = new ArrayList(identificationRuleConfigSize);
    this.identificationRuleProprietaryConfig = new ArrayList(identificationRuleProprietaryConfigSize);
  }

  public IdentificationConfiguration(Collection<IdentificationRuleConfig> identificationRuleConfig, Collection<IdentificationRuleProprietaryConfig> identificationRuleProprietaryConfig) {
    this.identificationRuleConfig = identificationRuleConfig;
    this.identificationRuleProprietaryConfig = identificationRuleProprietaryConfig;
  }

  public Collection<IdentificationRuleConfig> getIdentificationRuleConfig() {
    return this.identificationRuleConfig;
  }

  private void addIdentificationRuleConfig(Object identificationRuleConfig)
  {
    this.identificationRuleConfig.add((IdentificationRuleConfig)identificationRuleConfig);
  }

  public Collection<IdentificationRuleProprietaryConfig> getIdentificationRuleProprietaryConfig() {
    return this.identificationRuleProprietaryConfig;
  }

  private void addIdentificationRuleProprietaryConfig(Object identificationRuleProprietaryConfig)
  {
    this.identificationRuleProprietaryConfig.add((IdentificationRuleProprietaryConfig)identificationRuleProprietaryConfig);
  }

  public Iterator<IdentificationRuleConfig> getIdentificationRuleConfigIterator() {
    return this.identificationRuleConfig.iterator();
  }

  public Iterator<IdentificationRuleProprietaryConfig> getIdentificationRuleProprietaryConfigIterator() {
    return this.identificationRuleProprietaryConfig.iterator();
  }
}