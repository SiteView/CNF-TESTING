package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.query;

import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.DataInOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;

public abstract interface DataInQueryOperation
{
  public abstract void dataInQueryExecute(DataInManager paramDataInManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}