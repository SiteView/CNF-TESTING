package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;

public class DataInResolvedInfo
  implements DataInInfo
{
  private CmdbData _inputData;
  private CmdbData _resolvedData;

  public DataInResolvedInfo(CmdbData inputData, CmdbData resolvedData)
  {
    this._inputData = inputData;
    this._resolvedData = resolvedData;
  }

  public String getShortMessage() {
    StringBuilder info = new StringBuilder("Data Resolved: \t[input:");
    info.append(this._inputData).append("]\n\t\t[resolved:").append(this._resolvedData).append("]");
    return info.toString();
  }
}