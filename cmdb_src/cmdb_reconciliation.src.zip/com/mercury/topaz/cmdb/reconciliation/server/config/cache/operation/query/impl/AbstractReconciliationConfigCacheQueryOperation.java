package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.impl.AbstractReconciliationConfigCacheOperation;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.ReconciliationConfigCacheQueryOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractReconciliationConfigCacheQueryOperation extends AbstractReconciliationConfigCacheOperation
  implements ReconciliationConfigCacheQueryOperation
{
  public void configCacheExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response)
    throws CmdbException
  {
    configCacheQueryExecute(configCacheManager, response);
  }
}