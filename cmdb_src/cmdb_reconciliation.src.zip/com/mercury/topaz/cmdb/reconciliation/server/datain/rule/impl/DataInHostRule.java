package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.exception.DataInException;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.impl.DataInRuleOutputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.TempMergePropertiesInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.TempMergeTopologyInput;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.impl.MergeInputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl.MergeTopologyOutput;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddLinksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddOrIgnoreLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddUpdateOrIgnoreLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddObjectsStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddOrIgnoreObjects;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddOrUpdateObjects;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsStrict;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DataInHostRule extends DataInDefaultRule
{
  private static final Map<List<Integer>, DataInDefaultRule.Command<CmdbObjectID, CmdbObject>> _commandsMap;

  public DataInHostRule(DataInRuleDefinition ruleDefinition)
  {
    super(ruleDefinition);
  }

  public DataInRuleOutput onAddOrUpdateData(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, boolean ignoreInvalidLinks)
  {
    return onAdd(environment, dataInRuleInput, AddType.addOrUpdate);
  }

  public DataInRuleOutput onAddOrIgnoreData(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onAdd(environment, dataInRuleInput, AddType.addOrIgnore);
  }

  public DataInRuleOutput onAddDataStrict(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onAdd(environment, dataInRuleInput, AddType.addStrict);
  }

  private DataInRuleOutput onAdd(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, AddType typeOfAdd) {
    if ((!($assertionsDisabled)) && (!(environment.getCmdbClassModel().isTypeOf("host", dataInRuleInput.getType())))) throw new AssertionError();

    DataContainer dataContainer = dataInRuleInput.getDataContainer();

    Map idChangesMap = new HashMap();

    CmdbDataIDs idsForTouch = CmdbDataIdsFactory.createList();
    CmdbObjects objectsToAdd = CmdbObjectFactory.createObjects();
    CmdbObjects objectsToAddOrIgnore = CmdbObjectFactory.createObjects();
    CmdbObjectIds objectsToRemove = CmdbObjectIdsFactory.create();
    CmdbLinks linksToAdd = CmdbLinkFactory.createLinks();
    CmdbLinks linksToRemove = CmdbLinkFactory.createLinks();

    if (dataContainer.sizeOfDataForUpdate() > 0) {
      InputIdToCmdbDatasMapping existingMap = dataInRuleInput.getExistingDataMap();
      CmdbObjects objectsForUpdate = dataContainer.getObjectsForUpdate(dataInRuleInput.getType());
      Collection mergeTopologyInputs = new ArrayList(objectsForUpdate.size());
      Collection mergePropertiesInputs = new ArrayList(objectsForUpdate.size());
      for (Iterator i$ = objectsForUpdate.iterator(); i$.hasNext(); ) { CmdbObject objectWithPossiblyTempID = (CmdbObject)i$.next();
        chooseObjectToKeepAndCreateMergeInput(objectWithPossiblyTempID, existingMap, idChangesMap, environment, dataInRuleInput, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, idsForTouch, typeOfAdd);
      }

      Map mergePropertiesResultMap = DataInUtil.mergeCIProperties(mergePropertiesInputs, dataInRuleInput.getOwnerByType(), dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());
      for (Iterator i$ = mergePropertiesResultMap.values().iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
        if (null != object) {
          objectsToAdd.add(object);
        }

      }

      List newMergeTopologyInputs = fixRemainingObjectInMergeTopologyInput(idChangesMap, mergeTopologyInputs, mergePropertiesResultMap);
      Map mergeTopologyOutput = mergeTopology(dataInRuleInput, idChangesMap, newMergeTopologyInputs);
      processMergeTopologyResult(objectsToAdd, objectsToAddOrIgnore, objectsToRemove, linksToAdd, linksToRemove, mergeTopologyOutput);
    }

    customise(objectsToAdd, objectsToAddOrIgnore, objectsToRemove, linksToAdd, linksToRemove, dataInRuleInput, environment);

    Changer changer = dataInRuleInput.getChanger();
    List modelUpdates = typeOfAdd.createModelUpdateOperations(objectsToAdd, objectsToRemove, linksToAdd, linksToRemove, changer);
    if (!(objectsToAddOrIgnore.isEmpty()))
      modelUpdates.add(new ModelUpdateAddOrIgnoreObjects(objectsToAddOrIgnore, changer));

    return DataInRuleOutputFactory.createDataInRuleOutput(idChangesMap, modelUpdates, idsForTouch);
  }

  protected void customise(CmdbObjects objectsToAdd, CmdbObjects objectsToAddRoIgnore, CmdbObjectIds objectsToRemove, CmdbLinks linksToAdd, CmdbLinks linksToRemove, DataInRuleInput ruleInput, ReconciliationEnvironment environment) {
  }

  protected Map<CmdbObjectID, MergeTopologyOutput> mergeTopology(DataInRuleInput dataInRuleInput, Map<CmdbDataID, CmdbDataID> idChangesMap, List<MergeInput<CmdbObject>> newMergeTopologyInputs) {
    return DataInUtil.mergeTopology(newMergeTopologyInputs, dataInRuleInput.getDataInInfoList(), idChangesMap);
  }

  private List<MergeInput<CmdbObject>> fixRemainingObjectInMergeTopologyInput(Map<CmdbDataID, CmdbDataID> idChangesMap, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, Map<CmdbObject, CmdbObject> mergePropertiesResultMap) {
    List newMergeTopologyInputs = new ArrayList(mergeTopologyInputs.size());
    for (Iterator i$ = mergeTopologyInputs.iterator(); i$.hasNext(); ) { TempMergeTopologyInput tempMergeTopologyInput = (TempMergeTopologyInput)i$.next();
      if (mergePropertiesResultMap.containsKey(tempMergeTopologyInput.getRemainingObject()))
      {
        CmdbObject newRemainingData = (CmdbObject)mergePropertiesResultMap.get(tempMergeTopologyInput.getRemainingObject());
        newMergeTopologyInputs.add(MergeInputFactory.createMergeInput(tempMergeTopologyInput.getDatasFromCmdb(), newRemainingData));
      } else {
        MergeInput newMergeInput = MergeInputFactory.createMergeInput(tempMergeTopologyInput.getDatasFromCmdb(), tempMergeTopologyInput.getRemainingObject());
        newMergeTopologyInputs.add(newMergeInput);
      }
      for (Iterator i$ = tempMergeTopologyInput.getDatasFromCmdb().iterator(); i$.hasNext(); ) { CmdbObject currObject = (CmdbObject)i$.next();
        idChangesMap.put(currObject.getDataID(), ((CmdbObject)tempMergeTopologyInput.getRemainingObject()).getDataID());
      }
    }
    return newMergeTopologyInputs;
  }

  protected void processMergeTopologyResult(CmdbObjects objectsToAdd, CmdbObjects objectsToAddOrIgnore, CmdbObjectIds objectsToRemove, CmdbLinks linksToAdd, CmdbLinks linksToRemove, Map<CmdbObjectID, MergeTopologyOutput> mergeTopologyOutput)
  {
    for (Iterator i$ = mergeTopologyOutput.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      MergeTopologyOutput output = (MergeTopologyOutput)entry.getValue();
      for (Iterator i$ = output.getObjectsToAdd().iterator(); i$.hasNext(); ) { CmdbObject objectToAdd = (CmdbObject)i$.next();
        if (((CmdbObjectID)objectToAdd.getID()).equals(entry.getKey())) {
          objectsToAdd.add(objectToAdd);
        }
        else
          objectsToAddOrIgnore.add(objectToAdd);
      }

      for (i$ = output.getObjectsToRemove().iterator(); i$.hasNext(); ) { CmdbObject objectToRemove = (CmdbObject)i$.next();
        objectsToRemove.add((CmdbObjectID)objectToRemove.getID());
      }
      for (i$ = output.getLinksToAdd().iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
        linksToAdd.add(link);
      }
    }
  }

  private void chooseObjectToKeepAndCreateMergeInput(CmdbObject object, InputIdToCmdbDatasMapping existingMap, Map<CmdbDataID, CmdbDataID> idChangesMap, ReconciliationEnvironment env, DataInRuleInput input, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, CmdbDataIDs idsForTouch, AddType typeOfAdd)
  {
    Collection existingInBulk = existingMap.getInBulk((CmdbDataID)object.getID());

    Collection existingInCMDB = existingMap.get((CmdbDataID)object.getID());

    Collection inCompleteHostsFromBulk = new ArrayList(existingInBulk.size());
    Collection completeHostsFromBulk = new ArrayList(existingInBulk.size());
    Collection inCompleteHostsFromCMDB = new ArrayList(existingInCMDB.size());
    Collection completeHostsFromCMDB = new ArrayList(existingInCMDB.size());

    fillCompleteAndIncompleteCollections(Resolve.resolve, env.getDataFactory(), completeHostsFromBulk, inCompleteHostsFromBulk, Arrays.asList(new CmdbObject[] { object }));
    fillCompleteAndIncompleteCollections(Resolve.resolve, env.getDataFactory(), completeHostsFromBulk, inCompleteHostsFromBulk, existingInBulk);
    fillCompleteAndIncompleteCollections(Resolve.dontResolve, null, completeHostsFromCMDB, inCompleteHostsFromCMDB, existingInCMDB);

    typeOfAdd.handle(object, idChangesMap, env, input, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, idsForTouch, inCompleteHostsFromBulk, completeHostsFromBulk, inCompleteHostsFromCMDB, completeHostsFromCMDB);
  }

  private static void fillCompleteAndIncompleteCollections(Resolve resolve, DataFactory dataFactory, Collection<CmdbObject> completeHosts, Collection<CmdbObject> inCompleteHosts, Collection<CmdbObject> allHosts) {
    for (Iterator i$ = allHosts.iterator(); i$.hasNext(); ) { CmdbObject currentHost = (CmdbObject)i$.next();
      if (isCompleteHost(currentHost))
        completeHosts.add(resolve.resolve(dataFactory, currentHost));
      else
        inCompleteHosts.add(currentHost);
    }
  }

  public static boolean isCompleteHost(CmdbObject object)
  {
    CmdbProperty isCompleteHostProperty = object.getProperty("host_iscomplete");
    return ((null != isCompleteHostProperty) && (!(isCompleteHostProperty.isValueEmpty())) && (((Boolean)isCompleteHostProperty.getValue()).booleanValue()));
  }

  static
  {
    _commandsMap = new HashMap();

    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.AddCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.AddCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergeTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(0) }), DataInDefaultRule.MergeTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(1) }), HostMergePropertiesIgnoreCmdbAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1) }), HostMergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1) }), HostMergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesIgnoreCmdbAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesIgnoreCmdbAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1) }), HostMergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1) }), DataInDefaultRule.MergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0) }), HostMergePropertiesCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesIgnoreCmdbAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(0) }), DataInDefaultRule.MergePropertiesIgnoreCmdbAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1) }), HostMergePropertiesIgnoreCmdbAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(1) }), HostMergePropertiesIgnoreCmdbAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1) }), HostMergePropertiesIgnoreCmdbAndTopologyCommand.getInstance());
    _commandsMap.put(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(1) }), HostMergePropertiesIgnoreCmdbAndTopologyCommand.getInstance());
  }

  private static class HostMergePropertiesIgnoreCmdbAndTopologyCommand extends DataInDefaultRule.MergePropertiesIgnoreCmdbAndTopologyCommand
  {
    private static final HostMergePropertiesIgnoreCmdbAndTopologyCommand _instance = new HostMergePropertiesIgnoreCmdbAndTopologyCommand();

    public static DataInDefaultRule.MergePropertiesIgnoreCmdbAndTopologyCommand getInstance() {
      return _instance;
    }

    public void handle(CmdbObject remainingObject, Collection<CmdbObject> datasFromBulk, Collection<CmdbObject> datasFromCMDB, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbDatas<CmdbObjectID, CmdbObject> datasToAdd, CmdbObjectIds objectsToRemove, CmdbClassModel classModel)
    {
      for (Iterator i$ = datasFromCMDB.iterator(); i$.hasNext(); ) { CmdbObject dataFromCmdb = (CmdbObject)i$.next();
        if (remainingObject.getDataID().equals(dataFromCmdb.getDataID())) {
          if ((remainingObject.getType().equals(dataFromCmdb.getType())) || 
            (classModel.isDescendant(remainingObject.getType(), dataFromCmdb.getType())) || (classModel.isDescendant(dataFromCmdb.getType(), remainingObject.getType())))
            break;
          objectsToRemove.add((CmdbObjectID)dataFromCmdb.getID());

          if (datasFromBulk.size() > 1)
            mergePropertiesInputs.add(new TempMergePropertiesInput(remainingObject, Collections.emptyList(), datasFromBulk));

          if (datasFromCMDB.size() > 1) {
            Collection newDatasFromCmdb = new ArrayList(datasFromCMDB.size() - 1);
            for (Iterator i$ = datasFromCMDB.iterator(); i$.hasNext(); ) { CmdbObject otherDataFromCmdb = (CmdbObject)i$.next();
              if (!(((CmdbObjectID)otherDataFromCmdb.getID()).equals(remainingObject.getID())))
                newDatasFromCmdb.add(otherDataFromCmdb);
            }

            mergeTopologyInputs.add(new TempMergeTopologyInput(remainingObject, newDatasFromCmdb));
          }
          else {
            datasToAdd.add(remainingObject);
          }
          return;
        }

      }

      super.handle(remainingObject, datasFromBulk, datasFromCMDB, mergePropertiesInputs, mergeTopologyInputs, datasToAdd, objectsToRemove, classModel);
    }
  }

  private static class HostMergePropertiesCommand extends DataInDefaultRule.MergePropertiesCommand<CmdbObjectID, CmdbObject>
  {
    private static final HostMergePropertiesCommand _instance = new HostMergePropertiesCommand();

    public static HostMergePropertiesCommand getInstance()
    {
      return _instance;
    }

    public void handle(CmdbObject remainingObject, Collection<CmdbObject> datasFromBulk, Collection<CmdbObject> datasFromCMDB, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbDatas<CmdbObjectID, CmdbObject> datasToAdd, CmdbObjectIds objectsToRemove, CmdbClassModel classModel)
    {
      for (Iterator i$ = datasFromCMDB.iterator(); i$.hasNext(); ) { CmdbObject dataFromCmdb = (CmdbObject)i$.next();
        if (remainingObject.getDataID().equals(dataFromCmdb.getDataID())) {
          if (remainingObject.getType().equals(dataFromCmdb.getType())) break;
          if (classModel.isDescendant(dataFromCmdb.getType(), remainingObject.getType()))
          {
            if (datasFromBulk.size() > 1)
              mergePropertiesInputs.add(new TempMergePropertiesInput(remainingObject, Collections.emptyList(), datasFromBulk));

            mergeTopologyInputs.add(new TempMergeTopologyInput(remainingObject, datasFromCMDB));
            return;
          }

          if (classModel.isDescendant(remainingObject.getType(), dataFromCmdb.getType()))
            break;
          objectsToRemove.add((CmdbObjectID)dataFromCmdb.getID());

          if (datasFromBulk.size() > 1) {
            mergePropertiesInputs.add(new TempMergePropertiesInput(remainingObject, Collections.emptyList(), datasFromBulk));
          }
          else
            datasToAdd.add(remainingObject);

          return;
        }

      }

      super.handle(remainingObject, datasFromBulk, datasFromCMDB, mergePropertiesInputs, mergeTopologyInputs, datasToAdd, objectsToRemove, classModel);
    }
  }

  private static abstract enum Resolve
  {
    resolve, dontResolve;

    public static final Resolve[] values()
    {
      return ((Resolve[])$VALUES.clone());
    }

    public abstract CmdbObject resolve(DataFactory paramDataFactory, CmdbObject paramCmdbObject);
  }

  private static abstract enum AddType
  {
    public static final AddType[] values()
    {
      return ((AddType[])$VALUES.clone());
    }

    public abstract List<ModelUpdate> createModelUpdateOperations(CmdbObjects paramCmdbObjects, CmdbObjectIds paramCmdbObjectIds, CmdbLinks paramCmdbLinks1, CmdbLinks paramCmdbLinks2, Changer paramChanger);

    public abstract void handle(CmdbObject paramCmdbObject, Map<CmdbDataID, CmdbDataID> paramMap, ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput, Collection<TempMergePropertiesInput<CmdbObject>> paramCollection, Collection<TempMergeTopologyInput<CmdbObject>> paramCollection1, CmdbObjects paramCmdbObjects, CmdbObjectIds paramCmdbObjectIds, CmdbDataIDs paramCmdbDataIDs, Collection<CmdbObject> paramCollection2, Collection<CmdbObject> paramCollection3, Collection<CmdbObject> paramCollection4, Collection<CmdbObject> paramCollection5);

    private static void handleIt(CmdbObject object, ReconciliationEnvironment env, DataInRuleInput input, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, Collection<CmdbObject> inCompleteHostsFromBulk, Collection<CmdbObject> completeHostsFromBulk, Collection<CmdbObject> inCompleteHostsFromCMDB, Collection<CmdbObject> completeHostsFromCMDB)
    {
      CmdbObject completeHost;
      HashSet allCompleteHosts = new HashSet(completeHostsFromBulk.size() + completeHostsFromCMDB.size());
      for (Iterator i$ = completeHostsFromBulk.iterator(); i$.hasNext(); ) { completeHost = (CmdbObject)i$.next();
        allCompleteHosts.add(completeHost.getID());
      }
      for (i$ = completeHostsFromCMDB.iterator(); i$.hasNext(); ) { completeHost = (CmdbObject)i$.next();
        allCompleteHosts.add(completeHost.getID());
      }

      if (!(allCompleteHosts.isEmpty())) {
        for (i$ = allCompleteHosts.iterator(); i$.hasNext(); ) { CmdbObjectID completeHostId = (CmdbObjectID)i$.next();
          CmdbObject completeHostFromBulk = DataInUtil.getDataFromCollectionById(completeHostsFromBulk, completeHostId);
          List newCompleteHostsFromBulk = (null == completeHostFromBulk) ? Collections.emptyList() : Arrays.asList(new CmdbObject[] { completeHostFromBulk });
          CmdbObject completeHostFromCMDB = DataInUtil.getDataFromCollectionById(completeHostsFromCMDB, completeHostId);
          List newCompleteHostsFromCMDB = (null == completeHostFromCMDB) ? Collections.emptyList() : Arrays.asList(new CmdbObject[] { completeHostFromCMDB });

          handleIt(object, env, input, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, inCompleteHostsFromBulk, inCompleteHostsFromCMDB, newCompleteHostsFromBulk, newCompleteHostsFromCMDB);
        }
      } else {
        List newCompleteHostsFromBulk = Collections.emptyList();
        List newCompleteHostsFromCMDB = Collections.emptyList();
        handleIt(object, env, input, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, inCompleteHostsFromBulk, inCompleteHostsFromCMDB, newCompleteHostsFromBulk, newCompleteHostsFromCMDB);
      }
    }

    private static void handleIt(CmdbObject currentObject, ReconciliationEnvironment env, DataInRuleInput input, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, Collection<CmdbObject> inCompleteHostsFromBulk, Collection<CmdbObject> inCompleteHostsFromCMDB, List<CmdbObject> completeHostsFromBulk, List<CmdbObject> completeHostsFromCMDB) {
      CmdbObject remainingObject = chooseHostToKeepAndResolveIt(env, completeHostsFromCMDB, inCompleteHostsFromCMDB, completeHostsFromBulk, inCompleteHostsFromBulk, env.getDataFactory(), input.getInputIDAsStringToReconciledIDsMap(), input.getInputIDToReconciledIDsMap(), input.getDataInInfoList());

      addToInputToReconciledIdMapIfNeeded(currentObject, input, remainingObject);

      List listOfSizes = Arrays.asList(new Integer[] { Integer.valueOf(getSize(inCompleteHostsFromBulk)), Integer.valueOf(getSize(completeHostsFromBulk)), Integer.valueOf(getSize(inCompleteHostsFromCMDB)), Integer.valueOf(getSize(completeHostsFromCMDB)) });

      DataInDefaultRule.Command command = (DataInDefaultRule.Command)DataInHostRule.access$200().get(listOfSizes);
      if (null == command) {
        throw new DataInException("Host Data In Rule: no command found for combination of " + listOfSizes + "\n trigger object: " + currentObject + createString("incomplete in bulk", inCompleteHostsFromBulk) + createString("complete in bulk", completeHostsFromBulk) + createString("incomplete in cmdb", inCompleteHostsFromCMDB) + createString("complete in cmdb", completeHostsFromCMDB));
      }

      List existingInBulk = new ArrayList(inCompleteHostsFromBulk.size() + completeHostsFromBulk.size());
      List existingInCMDB = new ArrayList(inCompleteHostsFromCMDB.size() + completeHostsFromCMDB.size());
      existingInBulk.addAll(inCompleteHostsFromBulk);
      existingInBulk.addAll(completeHostsFromBulk);
      existingInCMDB.addAll(inCompleteHostsFromCMDB);
      existingInCMDB.addAll(completeHostsFromCMDB);
      command.handle(remainingObject, existingInBulk, existingInCMDB, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, env.getCmdbClassModel());
    }

    private static String createString(String type, Collection<CmdbObject> objects) {
      return "\n" + type + "(" + objects.size() + "): " + createObjectInALineString(objects).replaceAll("\n", "\n\t");
    }

    private static String createObjectInALineString(Iterable<?> objects) {
      StringBuilder sb = new StringBuilder();
      for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { Object object = i$.next();
        sb.append("\n").append(object.toString().replaceAll("\n", "\t"));
      }
      return sb.toString();
    }

    private static void addToInputToReconciledIdMapIfNeeded(CmdbObject currentObject, DataInRuleInput input, CmdbObject remainingObject) {
      if (!(((CmdbObjectID)currentObject.getID()).equals(remainingObject.getID()))) {
        CmdbObjectID oldID = (CmdbObjectID)currentObject.getID();
        addToInputToReconciledIdMap(remainingObject, oldID, input.getInputIDToReconciledIDsMap());
        addToInputToReconciledIdMap(remainingObject, oldID.toString(), input.getInputIDAsStringToReconciledIDsMap());
      }
    }

    private static <KeyType> void addToInputToReconciledIdMap(CmdbObject remainingObject, KeyType key, Map<KeyType, CmdbDataIDs> inputIDToReconciledIDsMap) {
      CmdbDataIDs reconciledIDs = (CmdbDataIDs)inputIDToReconciledIDsMap.get(key);
      if (null == reconciledIDs) {
        reconciledIDs = CmdbDataIdsFactory.create();
        inputIDToReconciledIDsMap.put(key, reconciledIDs);
      }
      reconciledIDs.add((CmdbDataID)remainingObject.getID());
    }

    private static int getSize(Collection<CmdbObject> collection) {
      int actualSize = collection.size();
      return ((actualSize > 1) ? 2 : actualSize);
    }

    private static CmdbObject chooseHostToKeepAndResolveIt(ReconciliationEnvironment environment, Collection<CmdbObject> completeHostsFromCMDB, Collection<CmdbObject> inCompleteHostsFromCMDB, Collection<CmdbObject> completeHostsFromBulk, Collection<CmdbObject> inCompleteHostsFromBulk, DataFactory dataFactory, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDsMap, Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap, List<DataInInfo> dataInInfoList)
    {
      CmdbObject chosenObject = null;
      if (!(completeHostsFromBulk.isEmpty())) {
        resolvedObjects = DataInUtil.resolveCmdbData(dataFactory, (CmdbObject)completeHostsFromBulk.iterator().next(), inputIDAsStringToReconciledIDsMap, inputIDToReconciledIDsMap, dataInInfoList);
        if ((!($assertionsDisabled)) && (resolvedObjects.size() != 1)) throw new AssertionError();
        chosenObject = (CmdbObject)resolvedObjects.iterator().next();
      }

      if (!(completeHostsFromCMDB.isEmpty()))
      {
        CmdbObject hostFromCmdb = (CmdbObject)completeHostsFromCMDB.iterator().next();
        if ((chosenObject == null) || (environment.getCmdbClassModel().isDescendant(chosenObject.getType(), hostFromCmdb.getType())))
          chosenObject = hostFromCmdb;

      }

      if (chosenObject != null) {
        return chosenObject;
      }

      if (!(inCompleteHostsFromCMDB.isEmpty())) {
        return ((CmdbObject)inCompleteHostsFromCMDB.iterator().next());
      }

      CmdbObjects resolvedObjects = DataInUtil.resolveCmdbData(dataFactory, (CmdbObject)inCompleteHostsFromBulk.iterator().next(), inputIDAsStringToReconciledIDsMap, inputIDToReconciledIDsMap, dataInInfoList);
      if ((!($assertionsDisabled)) && (resolvedObjects.size() != 1)) throw new AssertionError();
      return ((CmdbObject)resolvedObjects.iterator().next());
    }

    static
    {
      addStrict = new AddType("addStrict", 0) {
        public List<ModelUpdate> createModelUpdateOperations(CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, CmdbLinks linksToAdd, CmdbLinks linksToRemove, Changer changer) {
          List modelUpdates = new ArrayList(4);
          if (!(linksToRemove.isEmpty()))
            modelUpdates.add(new ModelUpdateRemoveLinksStrict(linksToRemove, changer));

          if (!(objectsToRemove.isEmpty()))
            modelUpdates.add(new ModelUpdateRemoveObjectsStrict(objectsToRemove, changer));

          if (!(objectsToAdd.isEmpty()))
            modelUpdates.add(new ModelUpdateAddObjectsStrict(objectsToAdd, changer));

          if (!(linksToAdd.isEmpty()))
            modelUpdates.add(new ModelUpdateAddLinksStrict(linksToAdd, changer));

          return modelUpdates; }

        public void handle(CmdbObject object, Map<CmdbDataID, CmdbDataID> idChangesMap, ReconciliationEnvironment env, DataInRuleInput input, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, CmdbDataIDs idsForTouch, Collection<CmdbObject> inCompleteHostsFromBulk, Collection<CmdbObject> completeHostsFromBulk, Collection<CmdbObject> inCompleteHostsFromCMDB, Collection<CmdbObject> completeHostsFromCMDB) {
          if ((completeHostsFromCMDB.size() + inCompleteHostsFromCMDB.size() < 1) || ((!(completeHostsFromBulk.isEmpty())) && (completeHostsFromCMDB.isEmpty())))
          {
            DataInHostRule.AddType.access$100(object, env, input, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, inCompleteHostsFromBulk, completeHostsFromBulk, inCompleteHostsFromCMDB, completeHostsFromCMDB);
          }
          else throw new DataInException("trying to add(strict) host when the host exists.\ncompleteHostsFromCMDB=" + completeHostsFromCMDB + "\ninCompleteHostsFromCMDB=" + inCompleteHostsFromCMDB + "\ncompleteHostsFromBulk=" + completeHostsFromBulk + "\ninCompleteHostsFromBulk" + inCompleteHostsFromBulk);

        }

      };
      addOrIgnore = new AddType("addOrIgnore", 1) {
        public List<ModelUpdate> createModelUpdateOperations(CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, CmdbLinks linksToAdd, CmdbLinks linksToRemove, Changer changer) {
          List modelUpdates = new ArrayList(4);
          if (!(linksToRemove.isEmpty()))
            modelUpdates.add(new ModelUpdateRemoveLinksIfExist(linksToRemove, changer));

          if (!(objectsToRemove.isEmpty()))
            modelUpdates.add(new ModelUpdateRemoveObjectsIfExist(objectsToRemove, changer));

          if (!(objectsToAdd.isEmpty()))
            modelUpdates.add(new ModelUpdateAddOrIgnoreObjects(objectsToAdd, changer));

          if (!(linksToAdd.isEmpty()))
            modelUpdates.add(new ModelUpdateAddOrIgnoreLinks(linksToAdd, changer));

          return modelUpdates; }

        public void handle(CmdbObject object, Map<CmdbDataID, CmdbDataID> idChangesMap, ReconciliationEnvironment env, DataInRuleInput input, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, CmdbDataIDs idsForTouch, Collection<CmdbObject> inCompleteHostsFromBulk, Collection<CmdbObject> completeHostsFromBulk, Collection<CmdbObject> inCompleteHostsFromCMDB, Collection<CmdbObject> completeHostsFromCMDB) {
          if ((completeHostsFromCMDB.size() + inCompleteHostsFromCMDB.size() < 1) || ((!(completeHostsFromBulk.isEmpty())) && (completeHostsFromCMDB.isEmpty())))
          {
            DataInHostRule.AddType.access$100(object, env, input, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, inCompleteHostsFromBulk, completeHostsFromBulk, inCompleteHostsFromCMDB, completeHostsFromCMDB);
          } else {
            CmdbObject currObject;
            for (Iterator i$ = completeHostsFromCMDB.iterator(); i$.hasNext(); ) { currObject = (CmdbObject)i$.next();
              idsForTouch.add((CmdbDataID)currObject.getID());
            }
            for (i$ = inCompleteHostsFromCMDB.iterator(); i$.hasNext(); ) { currObject = (CmdbObject)i$.next();
              idsForTouch.add((CmdbDataID)currObject.getID());
            }
            Collection existing = new ArrayList(completeHostsFromCMDB.size() + inCompleteHostsFromCMDB.size());
            existing.addAll(completeHostsFromCMDB);
            existing.addAll(inCompleteHostsFromCMDB);
            DataInDefaultRule.addIgnoredDataToInputToReconciledMap(input.getInputIDToReconciledIDsMap(), (CmdbDataID)object.getID(), existing);
          }
        }

      };
      addOrUpdate = new AddType("addOrUpdate", 2) {
        public List<ModelUpdate> createModelUpdateOperations(CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, CmdbLinks linksToAdd, CmdbLinks linksToRemove, Changer changer) {
          List modelUpdates = new ArrayList(4);
          if (!(linksToRemove.isEmpty()))
            modelUpdates.add(new ModelUpdateRemoveLinksIfExist(linksToRemove, changer));

          if (!(objectsToRemove.isEmpty()))
            modelUpdates.add(new ModelUpdateRemoveObjectsIfExist(objectsToRemove, changer));

          if (!(objectsToAdd.isEmpty()))
            modelUpdates.add(new ModelUpdateAddOrUpdateObjects(objectsToAdd, changer));

          if (!(linksToAdd.isEmpty()))
            modelUpdates.add(new ModelUpdateAddUpdateOrIgnoreLinks(linksToAdd, changer));

          return modelUpdates; }

        public void handle(CmdbObject object, Map<CmdbDataID, CmdbDataID> idChangesMap, ReconciliationEnvironment env, DataInRuleInput input, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<TempMergeTopologyInput<CmdbObject>> mergeTopologyInputs, CmdbObjects objectsToAdd, CmdbObjectIds objectsToRemove, CmdbDataIDs idsForTouch, Collection<CmdbObject> inCompleteHostsFromBulk, Collection<CmdbObject> completeHostsFromBulk, Collection<CmdbObject> inCompleteHostsFromCMDB, Collection<CmdbObject> completeHostsFromCMDB) {
          DataInHostRule.AddType.access$100(object, env, input, mergePropertiesInputs, mergeTopologyInputs, objectsToAdd, objectsToRemove, inCompleteHostsFromBulk, completeHostsFromBulk, inCompleteHostsFromCMDB, completeHostsFromCMDB);
        }
      };
      $VALUES = { addStrict, addOrIgnore, addOrUpdate };
    }
  }
}