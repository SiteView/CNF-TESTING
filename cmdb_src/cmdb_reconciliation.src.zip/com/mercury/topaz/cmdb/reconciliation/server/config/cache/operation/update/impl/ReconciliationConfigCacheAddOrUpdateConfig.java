package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ReconciliationConfigDef;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.Collection;
import java.util.Iterator;

public class ReconciliationConfigCacheAddOrUpdateConfig extends AbstractReconciliationConfigCacheUpdateOperation
{
  private Collection<ReconciliationConfigDef> _configDefs;

  public ReconciliationConfigCacheAddOrUpdateConfig(Collection<ReconciliationConfigDef> configDefs)
  {
    setConfigDefs(configDefs);
  }

  public String getOperationName() {
    return "Reconciliation Config Cache - Add Or Update Config";
  }

  public void configCacheUpdateExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response) throws CmdbException {
    for (Iterator i$ = getConfigDefs().iterator(); i$.hasNext(); ) { ReconciliationConfigDef configDef = (ReconciliationConfigDef)i$.next();
      configCacheManager.addOrUpdateConfigDef(configDef);
    }
  }

  private Collection<ReconciliationConfigDef> getConfigDefs() {
    return this._configDefs;
  }

  private void setConfigDefs(Collection<ReconciliationConfigDef> configDefs) {
    this._configDefs = configDefs;
  }
}