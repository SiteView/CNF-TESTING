package com.mercury.topaz.cmdb.reconciliation.server.datain.manager;

import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public abstract interface DataInManager extends CmdbSubsystemManager
{
}