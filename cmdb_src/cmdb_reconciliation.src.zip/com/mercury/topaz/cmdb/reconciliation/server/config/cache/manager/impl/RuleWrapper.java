package com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.impl;

class RuleWrapper<RuleType>
{
  private final RuleType _rule;
  private final String _actualType;

  RuleWrapper(RuleType rule, String actualType)
  {
    this._rule = rule;
    this._actualType = actualType;
  }

  public RuleType getRule() {
    return this._rule;
  }

  public String getActualType() {
    return this._actualType;
  }
}