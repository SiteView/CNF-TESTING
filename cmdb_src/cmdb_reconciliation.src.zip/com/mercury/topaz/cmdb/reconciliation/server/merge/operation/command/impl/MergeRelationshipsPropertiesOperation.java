package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.command.impl;

import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class MergeRelationshipsPropertiesOperation extends AbstractMergeDataPropertiesOperation<CmdbLinkID, CmdbLink>
{
  public MergeRelationshipsPropertiesOperation(Collection<MergeInput<CmdbLink>> input)
  {
    super(input);
    validateInput(input);
  }

  protected MergeRelationshipsPropertiesOperation(List<MergeInput<CmdbLink>> input, CmdbClassModel classModel)
  {
    this(input);
    setClassModel(classModel);
  }

  private void validateInput(Collection<MergeInput<CmdbLink>> input) {
    for (Iterator i$ = input.iterator(); i$.hasNext(); ) { MergeInput mergeInput = (MergeInput)i$.next();
      CmdbLink cmdbLink = (CmdbLink)mergeInput.iterator().next();
      CmdbObjectID end1 = cmdbLink.getEnd1();
      CmdbObjectID end2 = cmdbLink.getEnd2();
      for (Iterator i$ = mergeInput.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
        if ((!(link.getEnd1().equals(end1))) || (!(link.getEnd2().equals(end2))))
          throw new IllegalArgumentException("more then one link with different end!");
      }
    }
  }

  protected CmdbLink merge(MergeInput<CmdbLink> datas, String mergedType, CmdbDataID mergedID, CmdbProperties mergedProperties)
    throws CmdbException
  {
    CmdbLinkID cmdbLinkID = (CmdbLinkID)mergedID;
    CmdbObjectID end1 = mergeEnd1(datas);
    CmdbObjectID end2 = mergeEnd2(datas);
    return CmdbLinkFactory.createLink(cmdbLinkID, end1, end2, mergedType, mergedProperties);
  }

  private CmdbObjectID mergeEnd1(MergeInput<CmdbLink> datas) {
    return ((CmdbLink)datas.iterator().next()).getEnd1();
  }

  private CmdbObjectID mergeEnd2(MergeInput<CmdbLink> datas) {
    return ((CmdbLink)datas.iterator().next()).getEnd2();
  }

  public String getOperationName() {
    return "Merge Relationships Properties";
  }
}