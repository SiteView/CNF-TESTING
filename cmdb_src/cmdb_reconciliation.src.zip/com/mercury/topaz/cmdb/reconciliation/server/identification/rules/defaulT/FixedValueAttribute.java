package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;

class FixedValueAttribute
{
  private final String _attributeName;
  private final Object _value;
  private CmdbProperty _property;

  FixedValueAttribute(String attributeName, Object value)
  {
    this._attributeName = attributeName;
    this._value = value;
  }

  public String getAttributeName() {
    return this._attributeName;
  }

  public Object getValue() {
    return this._value;
  }

  public CmdbProperty getProperty() {
    return this._property;
  }

  public void setProperty(CmdbProperty property) {
    this._property = property;
  }
}