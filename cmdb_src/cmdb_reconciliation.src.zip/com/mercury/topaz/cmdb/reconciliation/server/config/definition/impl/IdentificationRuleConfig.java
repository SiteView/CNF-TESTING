package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class IdentificationRuleConfig extends AbstractIdentificationRuleConfig
  implements IUnmarshallable, IMarshallable
{
  protected And and;
  protected Or or;
  protected AttributeCondition attributeCondition;
  protected ConnectedCiCondition connectedCiCondition;
  protected String className;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public And getAnd()
  {
    return this.and;
  }

  public void setAnd(And and) {
    this.and = and;
  }

  public Or getOr() {
    return this.or;
  }

  public void setOr(Or or) {
    this.or = or;
  }

  public AttributeCondition getAttributeCondition() {
    return this.attributeCondition;
  }

  public void setAttributeCondition(AttributeCondition attributeCondition) {
    this.attributeCondition = attributeCondition;
  }

  public ConnectedCiCondition getConnectedCiCondition() {
    return this.connectedCiCondition;
  }

  public void setConnectedCiCondition(ConnectedCiCondition connectedCiCondition) {
    this.connectedCiCondition = connectedCiCondition;
  }

  public String getClassName() {
    return this.className;
  }

  public void setClassName(String className) {
    this.className = className;
  }
}