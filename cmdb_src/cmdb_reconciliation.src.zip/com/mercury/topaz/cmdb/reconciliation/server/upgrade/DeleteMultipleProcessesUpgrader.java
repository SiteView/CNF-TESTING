package com.mercury.topaz.cmdb.reconciliation.server.upgrade;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.exception.ReconciliationException;
import com.mercury.topaz.cmdb.server.upgrade.impl.AbstractSubsystemManagerUpgrader;
import com.mercury.topaz.cmdb.shared.enrichment.admin.operation.update.impl.EnrichmentUpdateRemoveEnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.command.impl.EnrichmentCommandAdHocCalculator;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.CmdbPatternIDFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdatePatternRemove;

public class DeleteMultipleProcessesUpgrader extends AbstractSubsystemManagerUpgrader
{
  public DeleteMultipleProcessesUpgrader(String fromVersion, String toVersion)
  {
    super(fromVersion, toVersion);
  }

  protected String getUpgraderName() {
    return getClass().getSimpleName();
  }

  protected String getSubsystemName() {
    return "PackageManager";
  }

  public void preStartup()
  {
  }

  public void postStartup() {
    String name = "ReconciliationUpgradeRemoveMultipleProcesses";
    String logPrefix = "Upgrader <" + getUpgraderName() + ">: ";

    getLog().info(logPrefix + "Started!!");
    try
    {
      executeOperation(new EnrichmentCommandAdHocCalculator("ReconciliationUpgradeRemoveMultipleProcesses"));
    } catch (Throwable e) {
      String msg = logPrefix + "Failed to run the enrichment <" + "ReconciliationUpgradeRemoveMultipleProcesses" + "> as part of the reconciliation upgrade.";
      getLog().error(msg, e);
      throw new ReconciliationException(msg, e);
    }

    try
    {
      executeOperation(new EnrichmentUpdateRemoveEnrichmentDefinition("ReconciliationUpgradeRemoveMultipleProcesses"));

      executeOperation(new TqlUpdatePatternRemove(CmdbPatternIDFactory.createObjectID("ReconciliationUpgradeRemoveMultipleProcesses")));
    } catch (Throwable e) {
      getLog().error(logPrefix + "Failed to remove (clean) the pattern relevant to reconciliation upgrade!!", e);
    }

    getLog().info(logPrefix + "Finished!!");
  }
}