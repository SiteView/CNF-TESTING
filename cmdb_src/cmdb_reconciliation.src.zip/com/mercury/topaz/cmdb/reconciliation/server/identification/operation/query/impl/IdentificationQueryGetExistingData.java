package com.mercury.topaz.cmdb.reconciliation.server.identification.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl.ReconciliationConfigCacheQueryGetActualIdentificationConfiguredTypes;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl.ReconciliationConfigCacheQueryGetIdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.IndependentDataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl.DataContainerUtil;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.environment.impl.ReconciliationEnvironmentFactory;
import com.mercury.topaz.cmdb.reconciliation.server.identification.manager.IdentificationManager;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl.InputIdToCmdbDatasMappingFactory;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.impl.IdentificationRuleInputFactory;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class IdentificationQueryGetExistingData extends AbstractIdentificationQueryOperation
{
  public static final String ID_TO_EXISTING_DATA = "idToExistingData";
  private static final String NAME = "Identification Query - Get Existing Data";
  private InputIdToCmdbDatasMapping _idToExistingData;
  private String _dataSource;
  private DataContainer _dataContainer;

  public IdentificationQueryGetExistingData(DataContainer dataContainer, String dataSource, InputIdToCmdbDatasMapping alreadyExistingData)
  {
    setDataContainer(dataContainer);
    setDataSource(dataSource);
    setIdToExistingData(alreadyExistingData);
  }

  public IdentificationQueryGetExistingData(DataContainer dataContainer, String dataSource) {
    setDataContainer(dataContainer);
    setDataSource(dataSource);
    setIdToExistingData(InputIdToCmdbDatasMappingFactory.create(dataContainer.sizeOfDataForUpdate()));
  }

  public String getOperationName() {
    return "Identification Query - Get Existing Data";
  }

  public void identificationQueryExecute(IdentificationManager identificationManager, CmdbResponse response) {
    CmdbClassModel classModel = identificationManager.getSynchronizedClassModel();
    runIdentification(response, classModel, getDataContainer());
  }

  protected void runIdentification(CmdbResponse response, CmdbClassModel classModel, DataContainer dataContainer)
  {
    ReconciliationEnvironment env = ReconciliationEnvironmentFactory.createReconciliationRuleEnvironment(DataFactoryCreator.create(classModel), classModel);

    List containers = DataContainerUtil.splitDataContainerAndOrderTypes(getTypeToRelevantSuperTypeMap(dataContainer), classModel, dataContainer);
    for (Iterator i$ = containers.iterator(); i$.hasNext(); ) { IndependentDataContainer currDataContainer = (IndependentDataContainer)i$.next();
      Iterator objectsIterator = currDataContainer.getObjectsForUpdateIteratorByType();
      identify(env, currDataContainer, objectsIterator);

      Iterator linksIterator = currDataContainer.getLinksForUpdateIteratorByType();
      identify(env, currDataContainer, linksIterator);
    }

    response.addResult("idToExistingData", getIdToExistingData());
  }

  private Map<String, String> getTypeToRelevantSuperTypeMap(DataContainer dataContainer) {
    ReconciliationConfigCacheQueryGetActualIdentificationConfiguredTypes getActualConfiguredTypes = new ReconciliationConfigCacheQueryGetActualIdentificationConfiguredTypes(dataContainer.getAllTypes());
    ServerApiFacade.executeOperation(getActualConfiguredTypes);
    return getActualConfiguredTypes.getTypesMap();
  }

  private void identify(ReconciliationEnvironment env, IndependentDataContainer dataContainer, Iterator<? extends Map.Entry<String, ? extends CmdbDatas<? extends CmdbDataID, ? extends CmdbData>>> it) {
    while (it.hasNext()) {
      Map.Entry entry = (Map.Entry)it.next();
      String type = (String)entry.getKey();
      Collection rules = getRule(type);
      for (Iterator i$ = rules.iterator(); i$.hasNext(); ) { IdentificationRule rule = (IdentificationRule)i$.next();
        IdentificationRuleInput ruleInput = IdentificationRuleInputFactory.create(env, dataContainer, type, getIdToExistingData(), IdentificationScope.ALL);
        rule.identify(ruleInput);
      }
    }
  }

  private Collection<IdentificationRule> getRule(String type) {
    ReconciliationConfigCacheQueryGetIdentificationRule getRule = new ReconciliationConfigCacheQueryGetIdentificationRule(type);
    ServerApiFacade.executeOperation(getRule);
    return getRule.getIdentificationRule();
  }

  public InputIdToCmdbDatasMapping getIdToExistingData() {
    return this._idToExistingData;
  }

  private void setIdToExistingData(InputIdToCmdbDatasMapping idToExistingData) {
    this._idToExistingData = idToExistingData;
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
    setIdToExistingData((InputIdToCmdbDatasMapping)response.getResult("idToExistingData"));
  }

  protected DataContainer getDataContainer() {
    return this._dataContainer;
  }

  private void setDataContainer(DataContainer dataContainer) {
    if (dataContainer == null)
      throw new IllegalArgumentException("dataContainer is null");

    this._dataContainer = dataContainer;
  }

  protected String getDataSource() {
    return this._dataSource;
  }

  private void setDataSource(String dataSource) {
    this._dataSource = dataSource;
  }
}