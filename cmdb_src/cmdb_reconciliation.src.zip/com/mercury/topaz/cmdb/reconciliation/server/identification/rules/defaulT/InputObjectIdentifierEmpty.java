package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

class InputObjectIdentifierEmpty extends AbstractInputObjectIdentifier
{
  private static final InputObjectIdentifierEmpty _instance = new InputObjectIdentifierEmpty();

  static InputObjectIdentifierEmpty instance()
  {
    return _instance;
  }

  public int hashCode()
  {
    return 0;
  }

  public boolean equals(Object obj)
  {
    return obj instanceof InputObjectIdentifierEmpty;
  }

  public InputObjectIdentifierEmpty clone()
  {
    return this;
  }
}