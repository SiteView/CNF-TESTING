package com.mercury.topaz.cmdb.reconciliation.server.change.listener;

import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;

public abstract interface CmdbIDChangeListenerFineGrained extends CmdbChangeListenerFineGrained
{
  public abstract void onCmdbObjectIDChange(CmdbObjectID paramCmdbObjectID1, CmdbObjectID paramCmdbObjectID2);

  public abstract void onCmdbLinkIDChange(CmdbLinkID paramCmdbLinkID1, CmdbLinkID paramCmdbLinkID2);
}