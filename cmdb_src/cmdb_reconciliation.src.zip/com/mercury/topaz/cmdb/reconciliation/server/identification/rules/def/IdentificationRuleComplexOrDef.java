package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

import java.util.Collection;

public class IdentificationRuleComplexOrDef extends AbstractIdentificationRuleComplexDef
{
  public IdentificationRuleComplexOrDef(Collection<IdentificationRuleDef> childs)
  {
    super(childs);
  }

  public void accept(IdentificationRuleDefVisitor visitor) {
    visitor.visit(this);
  }
}