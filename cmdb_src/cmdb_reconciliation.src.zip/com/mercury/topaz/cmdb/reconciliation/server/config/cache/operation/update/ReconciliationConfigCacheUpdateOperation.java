package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.update;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.ReconciliationConfigCacheOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;

public abstract interface ReconciliationConfigCacheUpdateOperation
{
  public abstract void configCacheUpdateExecute(ReconciliationConfigCacheManager paramReconciliationConfigCacheManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}