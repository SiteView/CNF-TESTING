package com.mercury.topaz.cmdb.reconciliation.server.exception;

import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;

public class ReconciliationException extends CmdbException
{
  public ReconciliationException(String message)
  {
    super(message);
  }

  public ReconciliationException(String message, ErrorCode errorCode) {
    super(message, errorCode);
  }

  public ReconciliationException(String message, Throwable cause) {
    super(message, cause);
  }

  public ReconciliationException(String message, Throwable cause, ErrorCode errorCode) {
    super(message, cause, errorCode);
  }

  public ReconciliationException(Throwable cause) {
    super(cause);
  }

  public ReconciliationException(Throwable cause, ErrorCode errorCode) {
    super(cause, errorCode);
  }
}