package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.IndependentDataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl.DataContainerFactory;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl.DataContainerUtil;
import com.mercury.topaz.cmdb.reconciliation.server.id.data.TempCmdbDataID;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItem;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItems;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbModifiableAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.impl.CmdbAttributeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class PreReconciliationDataManipulation
{
  private static Log _reconciliationDataManipulatorLog = ReconciliationLogs.getReconciliationDataManipulatorLog();

  public static DataContainer manipulate(DataContainer originalDataContainer, DataFactory dataFactory, OldToNewIdMapping idMapping)
  {
    CmdbClassModel classModel = dataFactory.getClassModel();
    DataContainer ans = DataContainerFactory.createDataContainer();

    List splittedDataContainers = DataContainerUtil.split(classModel, originalDataContainer);

    for (Iterator i$ = splittedDataContainers.iterator(); i$.hasNext(); ) { DataContainer dataContainer = (IndependentDataContainer)i$.next();
      handleForTypeOfData(dataContainer, dataFactory, classModel, ans, idMapping, new TypeObjectsForUpdate());
      handleForTypeOfData(dataContainer, dataFactory, classModel, ans, idMapping, new TypeObjectsForReference());
      handleForTypeOfData(dataContainer, dataFactory, classModel, ans, idMapping, new TypeLinksForUpdate());
      handleForTypeOfData(dataContainer, dataFactory, classModel, ans, idMapping, new TypeLinksForReference());
    }

    if ((_reconciliationDataManipulatorLog.isInfoEnabled()) && (!(idMapping.isEmpty()))) {
      String idsMappingString = "idMappings (only objects that changed their id will appear):" + idMapping.toString(originalDataContainer, ans).replaceAll("\n", "\n\t");
      if (_reconciliationDataManipulatorLog.isDebugEnabled())
        _reconciliationDataManipulatorLog.debug("\nOriginal DataContainer:\n" + originalDataContainer.toString().replaceAll("\n", "\n\t") + "\n" + idsMappingString);
      else
        _reconciliationDataManipulatorLog.info(idsMappingString);

    }

    return ans;
  }

  private static <IDType extends CmdbDataID, Type extends CmdbData<IDType>> void handleForTypeOfData(DataContainer originalDataContainer, DataFactory dataFactory, CmdbClassModel classModel, DataContainer ans, OldToNewIdMapping idMapping, TypeOfData<IDType, Type> typeOfData) {
    Iterator iter = typeOfData.get(originalDataContainer);
    while (iter.hasNext()) {
      Map.Entry entry = (Map.Entry)iter.next();
      CmdbClass aClass = classModel.getClass((String)entry.getKey());
      CmdbDatas objectsForType = (CmdbDatas)entry.getValue();
      CmdbAttributes valueReplacementAttributes = aClass.getAttributesByQualifier(CmdbAttributeQualifierDefs.REPLACE_VALUE_WITH_VALUE_FROM_SYSTEM_PROPERTY);
      CmdbAttributes rootContainerAttributes = aClass.getAttributesByQualifier(CmdbAttributeQualifierDefs.CONTAINED_BY);

      boolean isRootContainerAttribute = aClass.getIDAttributesSortedByName().hasAttribute("root_container");

      if ((isEmpty(valueReplacementAttributes)) && (isEmpty(rootContainerAttributes)) && (!(isRootContainerAttribute)) && (aClass.isTypeOfObject())) {
        typeOfData.addAll(ans, objectsForType);
      } else {
        CmdbAttributes containerAttributes = createContainerAttributes(rootContainerAttributes, (isRootContainerAttribute) ? aClass.getAttributeByName("root_container") : null);
        Map idCmdbPropertiesMap = createNewProperties(aClass, objectsForType, valueReplacementAttributes, containerAttributes, idMapping);
        for (Iterator i$ = objectsForType.iterator(); i$.hasNext(); ) { CmdbData newData;
          CmdbData data = (CmdbData)i$.next();
          CmdbDataID id = (CmdbDataID)data.getID();
          String type = data.getType();
          CmdbProperties newProperties = (CmdbProperties)idCmdbPropertiesMap.get(id);

          if ((id instanceof TempCmdbDataID) || (!(ModelUtil.hasAllKeyProperties(newProperties, aClass))))
            newData = typeOfData.createData(data, id, type, newProperties, idMapping);
          else
            newData = typeOfData.createData(data, type, newProperties, dataFactory, idMapping);

          typeOfData.add(ans, newData);
        }
      }
    }
  }

  private static CmdbAttributes createContainerAttributes(CmdbAttributes containerAttributes, CmdbAttribute rootContainerAttribute) {
    CmdbModifiableAttributes attributes = CmdbAttributeFactory.createAttributes(containerAttributes);
    if (rootContainerAttribute != null)
      attributes.add(rootContainerAttribute);

    return attributes;
  }

  private static boolean isEmpty(CmdbAttributes valueReplacementAttributes) {
    return ((null == valueReplacementAttributes) || (valueReplacementAttributes.isEmpty()));
  }

  private static <IDType extends CmdbDataID, Type extends CmdbData<IDType>> Map<IDType, CmdbProperties> createNewProperties(CmdbClass aClass, CmdbDatas<IDType, Type> objectsForType, CmdbAttributes valueReplacementAttributes, CmdbAttributes containerAttributes, OldToNewIdMapping idMapping) {
    Map idToPropertiesMap = createIdToPropertyMap(objectsForType);

    handleValueReplacementAttributes(aClass, objectsForType, valueReplacementAttributes, idToPropertiesMap);
    handleContainerAttributes(objectsForType, containerAttributes, idToPropertiesMap, idMapping);
    return idToPropertiesMap;
  }

  private static <IDType extends CmdbDataID, Type extends CmdbData<IDType>> void handleValueReplacementAttributes(CmdbClass aClass, CmdbDatas<IDType, Type> objectsForType, CmdbAttributes valueReplacementAttributes, Map<IDType, CmdbProperties> idToPropertiesMap) {
    for (Iterator i$ = valueReplacementAttributes.iterator(); i$.hasNext(); ) { CmdbAttributeDefinition attributeDef = (CmdbAttributeDefinition)i$.next();
      CmdbAttribute attribute = aClass.getAttributeByName(attributeDef.getName());
      CmdbType attributeType = attribute.getResolvedType();
      CmdbAttributeQualifier theQualifier = attributeDef.getQualifierByName(CmdbAttributeQualifierDefs.REPLACE_VALUE_WITH_VALUE_FROM_SYSTEM_PROPERTY.getName());
      DataItems dataItems = theQualifier.getDataItems();
      Object constantToReplace = getConstantToReplace(aClass, attributeDef, attributeType, dataItems);
      Object systemPropertyValue = getSystemPropertyValue(attributeType, dataItems);

      for (Iterator i$ = objectsForType.iterator(); i$.hasNext(); ) { CmdbData object = (CmdbData)i$.next();
        CmdbProperties newProperties = (CmdbProperties)idToPropertiesMap.get(object.getID());

        CmdbProperty propertyToHandle = object.getProperty(attributeDef.getName());
        if (propertyToHandle != null) {
          ReplaceConstantTypeVisitor replaceConstantTypeVisitor = new ReplaceConstantTypeVisitor(propertyToHandle, constantToReplace, systemPropertyValue);
          attributeType.accept(replaceConstantTypeVisitor);
          CmdbProperty newCmdbProperty = replaceConstantTypeVisitor.getNewCmdbProperty();
          if (null != newCmdbProperty)
            newProperties.add(newCmdbProperty);
        }
      }

    }

    if (!(valueReplacementAttributes.isEmpty())) {
      CmdbAttributes calculatedAttributes = aClass.getAttributesByQualifier(CmdbAttributeQualifierDefs.CALCULATED_ATTRIBUTE);
      for (Iterator i$ = idToPropertiesMap.values().iterator(); i$.hasNext(); ) { CmdbProperties properties = (CmdbProperties)i$.next();
        for (Iterator i$ = calculatedAttributes.iterator(); i$.hasNext(); ) { CmdbAttributeDefinition attribute = (CmdbAttributeDefinition)i$.next();
          String attributeName = attribute.getName();
          if (properties.contains(attributeName))
            properties.remove(attributeName);
        }
      }
    }
  }

  private static <IDType extends CmdbDataID, Type extends CmdbData<IDType>> void handleContainerAttributes(CmdbDatas<IDType, Type> objectsForType, CmdbAttributes containerAttributes, Map<IDType, CmdbProperties> idToPropertiesMap, OldToNewIdMapping idMapping)
  {
    for (Iterator i$ = containerAttributes.iterator(); i$.hasNext(); ) { CmdbAttributeDefinition attributeDef = (CmdbAttributeDefinition)i$.next();
      for (Iterator i$ = objectsForType.iterator(); i$.hasNext(); ) { CmdbData object = (CmdbData)i$.next();
        CmdbProperties newProperties = (CmdbProperties)idToPropertiesMap.get(object.getID());

        String attributeName = attributeDef.getName();
        CmdbProperty propertyToHandle = object.getProperty(attributeName);
        if (propertyToHandle != null) {
          String containerId = (String)propertyToHandle.getValue();
          String newContainerId = idMapping.get(containerId);
          newProperties.add(CmdbPropertyFactory.createProperty(attributeName, newContainerId));
        }
      }
    }
  }

  private static Object getConstantToReplace(CmdbClass aClass, CmdbAttributeDefinition attributeDef, CmdbType attributeType, DataItems dataItems) {
    DataItem constantToReplaceDataItem = dataItems.getDataItemByName("CONSTANT_TO_REPLACE");
    Object constantToReplace = constantToReplaceDataItem.getValue();
    if (!(constantToReplaceDataItem.getType().equals(attributeType)))
      throw new RuntimeException("Constant Data item type [" + constantToReplaceDataItem.getType() + "] does not fit to the attribute type [" + attributeType + "] in class named: " + aClass.getName() + "attribute named: [" + attributeDef.getName() + "].");

    return constantToReplace;
  }

  private static Object getSystemPropertyValue(CmdbType attributeType, DataItems dataItems) {
    String systemPropertyName = (String)dataItems.getDataItemByName("SYSTEM_PROPERTY_NAME").getValue();
    GetSystemPropertyVisitor getSystemPropertyVisitor = new GetSystemPropertyVisitor(systemPropertyName);
    attributeType.accept(getSystemPropertyVisitor);
    return getSystemPropertyVisitor.getResult();
  }

  private static <IDType extends CmdbDataID, Type extends CmdbData<IDType>> Map<IDType, CmdbProperties> createIdToPropertyMap(CmdbDatas<IDType, Type> objectsForType) {
    Map idToPropertiesMap = new HashMap(objectsForType.size());
    for (Iterator i$ = objectsForType.iterator(); i$.hasNext(); ) { CmdbData object = (CmdbData)i$.next();
      CmdbProperties properties = object.getUnmodifiableProperties();
      CmdbProperties newProperties = CmdbPropertyFactory.createProperties();

      for (Iterator i$ = properties.iterator(); i$.hasNext(); ) { CmdbProperty property = (CmdbProperty)i$.next();
        newProperties.add(property);
      }
      idToPropertiesMap.put(object.getID(), newProperties);
    }
    return idToPropertiesMap;
  }
}