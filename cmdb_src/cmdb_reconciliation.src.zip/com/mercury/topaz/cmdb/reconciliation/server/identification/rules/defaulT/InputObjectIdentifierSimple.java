package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

class InputObjectIdentifierSimple extends AbstractInputObjectIdentifier
{
  private CmdbDataID _id;
  private CmdbProperties _properties;
  private Collection<FixedValueAttribute> _fixedValueAttributes;

  public InputObjectIdentifierSimple(CmdbDataID id)
  {
    this._id = id;
    this._properties = CmdbPropertyFactory.createProperties();
    this._fixedValueAttributes = new ArrayList(1);
  }

  public InputObjectIdentifierSimple() {
    this._id = null;
    this._properties = CmdbPropertyFactory.createProperties();
    this._fixedValueAttributes = new ArrayList(1);
  }

  public int hashCode()
  {
    int ans = 0;
    for (Iterator i$ = this._properties.iterator(); i$.hasNext(); ) { CmdbProperty property = (CmdbProperty)i$.next();
      ans += property.hashCode();
    }
    return ((null == this._id) ? ans : ans + this._id.hashCode());
  }

  public boolean equals(Object obj)
  {
    if (!(obj instanceof InputObjectIdentifierSimple))
      return false;

    InputObjectIdentifierSimple anotherIdentifier = (InputObjectIdentifierSimple)obj;

    if (!(GeneralUtils.equals(getId(), anotherIdentifier.getId()))) {
      return false;
    }

    if (getProperties().size() != anotherIdentifier.getProperties().size())
      return false;

    for (Iterator i$ = getProperties().iterator(); i$.hasNext(); ) { CmdbProperty property = (CmdbProperty)i$.next();
      if (!(property.equals(anotherIdentifier.getProperties().get(property.getKey()))))
        return false;
    }

    return true;
  }

  public CmdbDataID getId() {
    return this._id;
  }

  protected CmdbProperties getProperties() {
    return this._properties;
  }

  public void setId(CmdbDataID id) {
    this._id = id;
  }

  public void add(CmdbProperty property) {
    this._properties.add(property);
  }

  public void addFixedValue(FixedValueAttribute fixedValueAttribute) {
    this._fixedValueAttributes.add(fixedValueAttribute);
  }

  public String toString() {
    StringBuilder desc = new StringBuilder("(id=").append(this._id).append(" properties=").append(this._properties).append(")");
    return desc.toString();
  }

  public InputObjectIdentifierSimple clone()
  {
    InputObjectIdentifierSimple clonedObject = (InputObjectIdentifierSimple)super.clone();
    clonedObject._properties = this._properties.clone();

    clonedObject._fixedValueAttributes = ((ArrayList)((ArrayList)this._fixedValueAttributes).clone());
    return clonedObject;
  }

  public boolean equals(CmdbData<?> d1, CmdbData<?> d2)
  {
    for (Iterator i$ = this._fixedValueAttributes.iterator(); i$.hasNext(); ) { FixedValueAttribute fixedValueAttribute = (FixedValueAttribute)i$.next();
      String attributeName = fixedValueAttribute.getAttributeName();
      Object value = fixedValueAttribute.getValue();
      CmdbProperty propertyFromD1 = d1.getProperty(attributeName);
      CmdbProperty propertyFromD2 = d2.getProperty(attributeName);

      if (!(equals(propertyFromD1, propertyFromD2, value)))
        return false;
    }

    return true;
  }

  private boolean equals(CmdbProperty p1, CmdbProperty p2, Object masterValue) {
    if (p1 == p2) {
      return true;
    }

    if ((isMasterValue(p1, masterValue)) || (isMasterValue(p2, masterValue))) {
      return true;
    }

    if ((p1 == null) || (p2 == null)) {
      return false;
    }

    String p1Value = (String)p1.getValue();
    String p2Value = (String)p2.getValue();

    return ((p1Value.equals(masterValue)) || (p2Value.equals(masterValue)) || (p1Value.equals(p2Value)));
  }

  private boolean isMasterValue(CmdbProperty p1, Object masterValue) {
    return ((p1 != null) && (((p1.isValueEmpty()) || (masterValue.equals(p1.getValue())))));
  }
}