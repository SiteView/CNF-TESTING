package com.mercury.topaz.cmdb.reconciliation.server.merge.operation;

import com.mercury.topaz.cmdb.shared.manage.operation.CmdbOperation;

public abstract interface MergeOperation extends CmdbOperation
{
}