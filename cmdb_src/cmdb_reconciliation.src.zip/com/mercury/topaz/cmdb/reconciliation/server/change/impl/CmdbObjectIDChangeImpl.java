package com.mercury.topaz.cmdb.reconciliation.server.change.impl;

import com.mercury.topaz.cmdb.reconciliation.server.change.CmdbObjectIDChange;
import com.mercury.topaz.cmdb.reconciliation.server.change.listener.CmdbIDChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;

class CmdbObjectIDChangeImpl extends AbstractCmdbIDChange
  implements CmdbObjectIDChange
{
  private CmdbObjectID _oldID;
  private CmdbObjectID _newID;

  public CmdbObjectIDChangeImpl(CmdbObjectID oldID, CmdbObjectID newID)
  {
    setOldID(oldID);
    setNewID(newID);
  }

  void execute(CmdbIDChangeListenerFineGrained changeListener) {
    changeListener.onCmdbObjectIDChange(getOldID(), getNewID());
  }

  private CmdbObjectID getOldID() {
    return this._oldID;
  }

  private void setOldID(CmdbObjectID oldID) {
    this._oldID = oldID;
  }

  private CmdbObjectID getNewID() {
    return this._newID;
  }

  private void setNewID(CmdbObjectID newID) {
    this._newID = newID;
  }

  public String toString() {
    StringBuilder msg = new StringBuilder("Object ID Change: ID ").append(this._oldID).append(" was changed to ").append(this._newID);

    return msg.toString();
  }
}