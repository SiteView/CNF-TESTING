package com.mercury.topaz.cmdb.reconciliation.server.change;

public abstract interface CmdbLinkIDChange extends CmdbIDChange
{
}