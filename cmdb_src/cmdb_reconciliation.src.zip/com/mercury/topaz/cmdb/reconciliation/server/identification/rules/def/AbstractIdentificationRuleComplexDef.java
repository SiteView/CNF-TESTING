package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public abstract class AbstractIdentificationRuleComplexDef extends IdentificationRuleDef
  implements Iterable<IdentificationRuleDef>
{
  private final Collection<IdentificationRuleDef> _childs;

  protected AbstractIdentificationRuleComplexDef()
  {
    this(new LinkedList());
  }

  protected AbstractIdentificationRuleComplexDef(Collection<IdentificationRuleDef> childs) {
    this._childs = childs;
  }

  public Collection<IdentificationRuleDef> getChilds() {
    return this._childs;
  }

  public Iterator<IdentificationRuleDef> iterator() {
    return this._childs.iterator();
  }

  public boolean add(IdentificationRuleDef identificationRuleDef) {
    return this._childs.add(identificationRuleDef);
  }
}