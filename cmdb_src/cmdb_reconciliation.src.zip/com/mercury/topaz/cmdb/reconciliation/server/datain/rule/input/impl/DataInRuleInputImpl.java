package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInAnomalyInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import java.util.List;
import java.util.Map;
import java.util.Set;

class DataInRuleInputImpl
  implements DataInRuleInput
{
  private Changer _changer;
  private String _type;
  private DataContainer _dataContainer;
  private InputIdToCmdbDatasMapping _existingDataMap;
  private Map<CmdbDataID, CmdbDataIDs> _inputIDToReconciledIDsMap;
  private Map<String, CmdbDataIDs> _inputIDAsStringToReconciledIDsMap;
  private List<DataInInfo> _dataInInfoList;
  private List<DataInAnomalyInfo> _dataInAnomalyInfoList;
  private Set<String> _isOwnerByType;
  private Map<CmdbDataID, CmdbDataID> _idChanges;

  public DataInRuleInputImpl(Changer changer, String type, DataContainer dataContainer, InputIdToCmdbDatasMapping existingDataMap, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDsMap, Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap, List<DataInInfo> dataInInfoList, List<DataInAnomalyInfo> dataInAnomalyInfoList, Set<String> isOwnerByType, Map<CmdbDataID, CmdbDataID> idChanges)
  {
    setChanger(changer);
    setType(type);
    setDataContainer(dataContainer);
    setExistingDataMap(existingDataMap);
    setInputIDToReconciledIDsMap(inputIDToReconciledIDsMap);
    setDataInInfoList(dataInInfoList);
    setDataInAnomalyInfoList(dataInAnomalyInfoList);
    setInputIDAsStringToReconciledIDsMap(inputIDAsStringToReconciledIDsMap);
    setOwnerByType(isOwnerByType);
    setIdChanges(idChanges);
  }

  public Changer getChanger() {
    return this._changer;
  }

  private void setChanger(Changer changer) {
    this._changer = changer;
  }

  public String getType() {
    return this._type;
  }

  private void setType(String type) {
    this._type = type;
  }

  public DataContainer getDataContainer() {
    return this._dataContainer;
  }

  private void setDataContainer(DataContainer dataContainer) {
    this._dataContainer = dataContainer;
  }

  public InputIdToCmdbDatasMapping getExistingDataMap() {
    return this._existingDataMap;
  }

  private void setExistingDataMap(InputIdToCmdbDatasMapping existingDataMap) {
    this._existingDataMap = existingDataMap;
  }

  public Map<CmdbDataID, CmdbDataIDs> getInputIDToReconciledIDsMap() {
    return this._inputIDToReconciledIDsMap;
  }

  private void setInputIDToReconciledIDsMap(Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap) {
    this._inputIDToReconciledIDsMap = inputIDToReconciledIDsMap;
  }

  public List<DataInInfo> getDataInInfoList() {
    return this._dataInInfoList;
  }

  private void setDataInInfoList(List<DataInInfo> dataInInfoList) {
    this._dataInInfoList = dataInInfoList;
  }

  public Map<String, CmdbDataIDs> getInputIDAsStringToReconciledIDsMap() {
    return this._inputIDAsStringToReconciledIDsMap;
  }

  private void setInputIDAsStringToReconciledIDsMap(Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDsMap) {
    this._inputIDAsStringToReconciledIDsMap = inputIDAsStringToReconciledIDsMap;
  }

  public Set<String> getOwnerByType() {
    return this._isOwnerByType;
  }

  private void setOwnerByType(Set<String> isOwnerByType) {
    this._isOwnerByType = isOwnerByType;
  }

  public List<DataInAnomalyInfo> getDataInAnomalyInfoList() {
    return this._dataInAnomalyInfoList;
  }

  private void setDataInAnomalyInfoList(List<DataInAnomalyInfo> dataInAnomalyInfoList) {
    this._dataInAnomalyInfoList = dataInAnomalyInfoList;
  }

  public Map<CmdbDataID, CmdbDataID> getIdChanges() {
    return this._idChanges;
  }

  private void setIdChanges(Map<CmdbDataID, CmdbDataID> idChanges) {
    this._idChanges = idChanges;
  }
}