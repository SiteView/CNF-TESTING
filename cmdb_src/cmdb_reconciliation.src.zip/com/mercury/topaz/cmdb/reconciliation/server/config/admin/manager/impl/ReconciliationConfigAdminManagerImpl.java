package com.mercury.topaz.cmdb.reconciliation.server.config.admin.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.config.admin.manager.ReconciliationConfigAdminManager;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;

class ReconciliationConfigAdminManagerImpl extends CmdbSubsystemManagerImpl
  implements ReconciliationConfigAdminManager, MultiReadSingleWrite
{
  public ReconciliationConfigAdminManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public void startUp()
  {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation Config Admin Manager is started up properly !!!");
  }

  public void shutdown() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation Config Admin Manager is shutdown up properly !!!");
  }

  public String getName() {
    return "Reconciliation Config Task";
  }
}