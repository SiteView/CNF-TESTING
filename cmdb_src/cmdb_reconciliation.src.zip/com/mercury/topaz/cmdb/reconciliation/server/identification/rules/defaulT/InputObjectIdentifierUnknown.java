package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.util.Collections;
import java.util.Set;

class InputObjectIdentifierUnknown extends AbstractInputObjectIdentifier
{
  private static final InputObjectIdentifierUnknown _instance = new InputObjectIdentifierUnknown();

  static InputObjectIdentifierUnknown instance()
  {
    return _instance;
  }

  public int hashCode()
  {
    return -2147483648;
  }

  public boolean equals(Object obj)
  {
    return obj instanceof InputObjectIdentifierUnknown;
  }

  public <TypeID extends CmdbDataID> Set<TypeID> createInitialSet()
  {
    return Collections.emptySet();
  }

  public <TypeID extends CmdbDataID> boolean addToSet(Set<TypeID> set, TypeID obj)
  {
    return false;
  }

  public InputObjectIdentifierUnknown clone()
  {
    return this;
  }
}