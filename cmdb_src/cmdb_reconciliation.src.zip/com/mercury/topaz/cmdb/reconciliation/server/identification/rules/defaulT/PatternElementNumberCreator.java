package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;

class PatternElementNumberCreator
{
  private static int n = 107000;

  static PatternElementNumber create()
  {
    return PatternElementNumberFactory.createElementNumber(n++);
  }
}