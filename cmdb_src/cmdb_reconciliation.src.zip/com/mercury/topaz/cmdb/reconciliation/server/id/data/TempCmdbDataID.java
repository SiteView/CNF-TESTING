package com.mercury.topaz.cmdb.reconciliation.server.id.data;

import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.io.Serializable;

public abstract interface TempCmdbDataID
{
}