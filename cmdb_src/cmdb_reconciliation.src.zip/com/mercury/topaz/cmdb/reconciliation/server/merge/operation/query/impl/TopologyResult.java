package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl;

import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import java.util.Collection;

class TopologyResult
{
  private final TqlResultMap _resultMap;
  private final Collection<PatternElementNumber> _objectsToReplaceElementNumbers;

  TopologyResult(TqlResultMap resultMap, Collection<PatternElementNumber> objectsToReplaceElementNumbers)
  {
    this._resultMap = resultMap;
    this._objectsToReplaceElementNumbers = objectsToReplaceElementNumbers;
  }

  public TqlResultMap getResultMap() {
    return this._resultMap;
  }

  public Collection<PatternElementNumber> getObjectsToReplaceElementNumbers() {
    return this._objectsToReplaceElementNumbers;
  }
}