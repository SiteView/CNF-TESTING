package com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ConfigurationParamConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.DataChangeConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.DataChangeRuleConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.OwnerConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.OwnersConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ReconciliationConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.ReconciliationConfigDefImpl;
import com.mercury.topaz.cmdb.reconciliation.server.config.exception.ReconciliationConfigException;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl.DataInDefaultRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl.DataInRuleDefinitionFactory;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.exception.ReconciliationException;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationUtil;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl.LinkIDIdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl.ObjectIDIdentificationRule;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocCmdbMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class ReconciliationConfigCacheManagerImpl extends CmdbSubsystemManagerImpl
  implements ReconciliationConfigCacheManager, MultiReadSingleWrite
{
  Map<String, ReconciliationConfigDef> _configDefCache;
  Map<String, Collection<String>> _ownerByTypeCache;
  Map<IsOwnerKey, Boolean> _isOwnerByTypeCache;
  Map<String, RuleWrapper<DataInRule>> _dataInRuleByTypeCache;
  Map<String, RuleWrapper<Collection<IdentificationRule>>> _identificationRuleByTypeCache;
  Map<String, Collection<Pattern>> _identificationRuleLayoutPatternsByLinkTypeCache;

  public ReconciliationConfigCacheManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public void startUp() {
    setOwnerByTypeCache(new HashMap());
    setIsOwnerByTypeCache(new HashMap());
    setDataInRuleByTypeCache(new HashMap());
    setIdentificationRuleByTypeCache(new HashMap());
    setIdentificationRuleLayoutPatternsByLinkTypeCache(new HashMap());

    initializeCache();
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation Config Cache Manager is started up properly !!!");
  }

  public void shutdown() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation Config Cache Manager is shutdown up properly !!!");
  }

  public String getName() {
    return "Reconciliation Config Cache Task";
  }

  public boolean isConfigExists(String configName) {
    return getConfigDefCache().containsKey(configName);
  }

  public ReconciliationConfigDef getConfigDef(String configName) {
    return ((ReconciliationConfigDef)getConfigDefCache().get(configName));
  }

  public void addOrUpdateConfigDef(ReconciliationConfigDef configDef) {
    getConfigDefCache().put(configDef.getType(), configDef);
    cleanCache();
  }

  public void removeConfigDef(String configName) {
    getConfigDefCache().remove(configName);
    cleanCache();
  }

  private void cleanCache()
  {
    getIsOwnerByTypeCache().clear();
    getOwnerByTypeCache().clear();
    getIsOwnerByTypeCache().clear();
    getDataInRuleByTypeCache().clear();
    getIdentificationRuleByTypeCache().clear();
    getIdentificationRuleLayoutPatternsByLinkTypeCache().clear();
    initializeIdentificationRuleCache(true);
  }

  private void initializeCache() {
    CmdbObjects configObjects = getConfigObjectsFromModel();
    setConfigDefCache(new HashMap(configObjects.size()));
    for (Iterator i$ = configObjects.iterator(); i$.hasNext(); ) { CmdbObject configObject = (CmdbObject)i$.next();
      String configDefAsXml = (String)configObject.getProperty("configuration").getValue();
      ReconciliationConfigDef configDef = (ReconciliationConfigDef)XmlUtils.fromXML(configDefAsXml, ReconciliationConfigDefImpl.class);
      getConfigDefCache().put((String)configObject.getProperty("data_name").getValue(), configDef);
    }
    initializeIdentificationRuleCache(false);
  }

  private void initializeIdentificationRuleCache(boolean failOnError) {
    for (Iterator i$ = getConfigDefCache().entrySet().iterator(); i$.hasNext(); ) { Map.Entry currentConfig = (Map.Entry)i$.next();
      String type = (String)currentConfig.getKey();
      ReconciliationConfigDef configDef = (ReconciliationConfigDef)currentConfig.getValue();
      setIdentificationRulesFromDef(type, configDef, failOnError); }
  }

  private void setIdentificationRulesFromDef(String type, ReconciliationConfigDef configDef, boolean failOnError) {
    Collection identificationRules;
    try {
      identificationRules = IdentificationUtil.getIdentificationRulesFromDef(configDef);
      if (!(identificationRules.isEmpty()))
        getIdentificationRuleByTypeCache().put(type, new RuleWrapper(identificationRules, type));
    }
    catch (Exception e) {
      String errorMessage = "Reconciliation Config Cache Manager encountered an error while trying to load identification rule!!!";
      CmdbLogFactory.getCMDBInfoLog().error("Reconciliation Config Cache Manager encountered an error while trying to load identification rule!!!", e);
      if (failOnError)
        throw new ReconciliationException("Reconciliation Config Cache Manager encountered an error while trying to load identification rule!!!", e);
    }
  }

  protected CmdbObjects getConfigObjectsFromModel()
  {
    PatternElementNumber nodeNumber = PatternElementNumberFactory.createElementNumber(1);
    ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition("reconciliation_configuration", false);
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition);
    PatternNode node = PatternGraphFactory.createPatternNode(nodeNumber, elementCondition, true, null);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(node);

    PatternGroupId patternGroup = PatternGroupId.PATTERN_GROUP_VIEW;
    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("getReconciliationConfiguration", patternGroup, patternGraph);

    PatternLayout layout = PatternLayoutFactory.createLayout();
    ElementSimpleLayout elementSimpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    elementSimpleLayout.addKey("data_name");
    elementSimpleLayout.addKey("configuration");

    layout.setElementLayout(nodeNumber, elementSimpleLayout);

    TqlQueryGetAdHocCmdbMap getMap = new TqlQueryGetAdHocCmdbMap(pattern, layout);
    executeOperation(getMap);
    TqlResultMap resultMap = (getMap.isDividedToChunks()) ? DataInUtil.getResultInChunks(getMap.getChunkRequest()) : getMap.getResultMap();
    if (resultMap.containsElementNumber(nodeNumber)) {
      return resultMap.getObjects(nodeNumber);
    }

    return CmdbObjectFactory.createObjectsList();
  }

  public DataInRule getDataInRuleByType(String type, CmdbClassModel classModel)
  {
    return ((DataInRule)getDataInRuleWrapperByType(type, classModel).getRule());
  }

  private RuleWrapper<DataInRule> getDataInRuleWrapperByType(String type, CmdbClassModel classModel)
  {
    if (getDataInRuleByTypeCache().containsKey(type)) {
      return ((RuleWrapper)getDataInRuleByTypeCache().get(type));
    }

    RuleWrapper ruleWrapper = null;
    ReconciliationConfigDef configDef = null;
    for (CmdbClass currentClass = classModel.getClass(type); (ruleWrapper == null) && (configDef == null) && (!(currentClass.getName().equals("none"))); currentClass = currentClass.getResolvedSuperClass()) {
      String currentClassName = currentClass.getName();
      ruleWrapper = (RuleWrapper)getDataInRuleByTypeCache().get(currentClassName);
      if (ruleWrapper == null) {
        ReconciliationConfigDef tempConfigDef = (ReconciliationConfigDef)getConfigDefCache().get(currentClass.getName());
        if (containsDataInRuleConfiguration(tempConfigDef))
          configDef = tempConfigDef;

      }

    }

    if (null == ruleWrapper)
      if (configDef == null) {
        ruleWrapper = new RuleWrapper(DataInDefaultRule.getDefaultRuleInstance(), "root");
      } else {
        DataChangeRuleConfigDef rule = configDef.getDataChangeConfigDef().getRuleConfigDef();
        String ruleJavaClassName = rule.getClassName();
        Map configurationParams = getConfigurationParamsMapFromDef(rule.getConfigurationParams());
        DataInRuleDefinition ruleDef = DataInRuleDefinitionFactory.createDataInRuleDefinition(configurationParams);
        String actualType = configDef.getType();

        if ((ruleJavaClassName == null) || (ruleJavaClassName.length() == 0))
          ruleWrapper = new RuleWrapper(new DataInDefaultRule(ruleDef), actualType);
        else
          try {
            DataInRule dataInRule = (DataInRule)Class.forName(ruleJavaClassName).getConstructor(new Class[] { DataInRuleDefinition.class }).newInstance(new Object[] { ruleDef });
            ruleWrapper = new RuleWrapper(dataInRule, actualType);
          } catch (Exception e) {
            throw new ReconciliationConfigException("Error while trying to load the data in rule class: " + e, e);
          }
      }


    getDataInRuleByTypeCache().put(type, ruleWrapper);
    return ruleWrapper;
  }

  Map<String, String> getConfigurationParamsMapFromDef(Collection<ConfigurationParamConfigDef> configurationParamDefs) {
    int size = (configurationParamDefs == null) ? 0 : configurationParamDefs.size();
    Map configParams = new HashMap(size);
    if (configurationParamDefs != null)
      for (Iterator i$ = configurationParamDefs.iterator(); i$.hasNext(); ) { ConfigurationParamConfigDef configParam = (ConfigurationParamConfigDef)i$.next();
        configParams.put(configParam.getParamName(), configParam.getValue());
      }

    return configParams;
  }

  public Collection<String> getOwnersByType(String type, CmdbClassModel classModel)
  {
    if (getOwnerByTypeCache().containsKey(type)) {
      return ((Collection)getOwnerByTypeCache().get(type));
    }

    ReconciliationConfigDef configDef = findOwnersDefByType(type, classModel);
    if (configDef == null) {
      Collection ownersAsString = new ArrayList(0);
      getOwnerByTypeCache().put(type, ownersAsString);
      return ownersAsString;
    }
    OwnersConfigDef owners = configDef.getDataChangeConfigDef().getOwnersConfigDef();
    Collection ownersAsString = new ArrayList(owners.getOwnersCollection().size());
    for (Iterator i$ = owners.getOwnersCollection().iterator(); i$.hasNext(); ) { OwnerConfigDef owner = (OwnerConfigDef)i$.next();
      ownersAsString.add(owner.getName());
    }
    getOwnerByTypeCache().put(type, ownersAsString);
    return ownersAsString;
  }

  public boolean isOwnerByType(String dataStore, String type, CmdbClassModel classModel)
  {
    IsOwnerKey cacheKey = new IsOwnerKey(this, dataStore, type);
    if (getIsOwnerByTypeCache().containsKey(cacheKey)) {
      return ((Boolean)getIsOwnerByTypeCache().get(cacheKey)).booleanValue();
    }

    ReconciliationConfigDef configDef = findOwnersDefByType(type, classModel);
    if (configDef == null) {
      getIsOwnerByTypeCache().put(cacheKey, Boolean.FALSE);
      return false;
    }
    OwnersConfigDef owners = configDef.getDataChangeConfigDef().getOwnersConfigDef();
    for (Iterator i$ = owners.getOwnersCollection().iterator(); i$.hasNext(); ) { OwnerConfigDef owner = (OwnerConfigDef)i$.next();
      if (dataStore.equals(owner.getName())) {
        getIsOwnerByTypeCache().put(cacheKey, Boolean.TRUE);
        return true;
      }
    }
    getIsOwnerByTypeCache().put(cacheKey, Boolean.FALSE);
    return false;
  }

  private ReconciliationConfigDef findOwnersDefByType(String type, CmdbClassModel classModel) {
    ReconciliationConfigDef configDef = null;
    CmdbClass currentClass = classModel.getClass(type);
    while (true) { do { if ((configDef != null) || (currentClass.getName().equals("none"))) break label80;
        configDef = (ReconciliationConfigDef)getConfigDefCache().get(currentClass.getName());
        if ((configDef != null) && 
          (!(containsOwnersConfiguration(configDef))))
          configDef = null;
      }

      while (configDef != null);
      currentClass = currentClass.getResolvedSuperClass();
    }

    label80: return configDef;
  }

  private boolean containsOwnersConfiguration(ReconciliationConfigDef configDef) {
    return ((configDef.getDataChangeConfigDef() != null) && (configDef.getDataChangeConfigDef().getOwnersConfigDef() != null));
  }

  private boolean containsDataInRuleConfiguration(ReconciliationConfigDef configDef) {
    return ((configDef != null) && (configDef.getDataChangeConfigDef() != null) && (configDef.getDataChangeConfigDef().getRuleConfigDef() != null));
  }

  public Collection<IdentificationRule> getIdentificationRuleByType(String type, CmdbClassModel classModel) {
    return ((Collection)getIdentificationRuleWrapperByType(type, classModel).getRule());
  }

  private RuleWrapper<Collection<IdentificationRule>> getIdentificationRuleWrapperByType(String type, CmdbClassModel classModel)
  {
    Collection identificationRule;
    if (getIdentificationRuleByTypeCache().containsKey(type)) {
      return ((RuleWrapper)getIdentificationRuleByTypeCache().get(type));
    }

    CmdbClass currentClass = classModel.getClass(type).getResolvedSuperClass();
    while (!(currentClass.getName().equals("none"))) {
      String currentClassName = currentClass.getName();
      if (getIdentificationRuleByTypeCache().containsKey(currentClassName)) {
        RuleWrapper ruleWrapper = (RuleWrapper)getIdentificationRuleByTypeCache().get(currentClassName);
        getIdentificationRuleByTypeCache().put(type, ruleWrapper);
        return ruleWrapper;
      }
      currentClass = currentClass.getResolvedSuperClass();
    }

    CmdbClass cmdbClass = classModel.getClass(type);
    if (cmdbClass == null)
      throw new ReconciliationConfigException("There is no class " + type + " in the class model.");

    if (cmdbClass.isTypeOfObject()) {
      identificationRule = Arrays.asList(new IdentificationRule[] { ObjectIDIdentificationRule.getInstance() });
    }
    else
      identificationRule = Arrays.asList(new IdentificationRule[] { LinkIDIdentificationRule.getInstance() });

    RuleWrapper ruleWrapper = new RuleWrapper(identificationRule, type);
    getIdentificationRuleByTypeCache().put(type, ruleWrapper);
    return ruleWrapper;
  }

  public Collection<Pattern> getIdentificationLayoutPatternForLinkType(String linkType, CmdbClassModel classModel)
  {
    if (getIdentificationRuleLayoutPatternsByLinkTypeCache().containsKey(linkType)) {
      return ((Collection)getIdentificationRuleLayoutPatternsByLinkTypeCache().get(linkType));
    }

    Collection foundPatterns = new ArrayList();
    Iterator it = getIdentificationRuleByTypeCache().entrySet().iterator();
    int num = 1;
    while (it.hasNext()) {
      Map.Entry currentEntry = (Map.Entry)it.next();
      Collection rules = (Collection)((RuleWrapper)currentEntry.getValue()).getRule();
      for (Iterator i$ = rules.iterator(); i$.hasNext(); ) { IdentificationRule rule = (IdentificationRule)i$.next();
        PatternElementNumber elementNumber = PatternElementNumberFactory.createElementNumber(num++);
        Pattern layoutPattern = rule.getLayoutPattern((String)currentEntry.getKey(), elementNumber);
        if ((layoutPattern != null) && 
          (layoutPattern.getPatternGraph().getLinkAmount() > 0)) {
          ReadOnlyIterator linksIt = layoutPattern.getPatternGraph().getLinksIterator();
          while (linksIt.hasNext()) {
            PatternLink currentLink = (PatternLink)linksIt.next();
            if ((currentLink.getLinkCondition() != null) && (currentLink.getLinkCondition().getClassCondition() != null)) {
              ElementClassCondition classCondition = currentLink.getLinkCondition().getClassCondition();
              String className = classCondition.getClassName();
              if ((linkType.equals(className)) || ((classCondition.isDerived()) && (classModel.isTypeOf(className, linkType))))
                foundPatterns.add(layoutPattern);
            }
          }
        }
      }

    }

    getIdentificationRuleLayoutPatternsByLinkTypeCache().put(linkType, foundPatterns);
    return foundPatterns;
  }

  public Map<String, String> getActualIdentificationRuleConfiguredTypes(Collection<String> types) {
    CmdbClassModel cmdbClassModel = getSynchronizedClassModel();
    Map typeToActualTypeMap = new HashMap(types.size());
    for (Iterator i$ = types.iterator(); i$.hasNext(); ) { String type = (String)i$.next();
      String actualType = getIdentificationRuleWrapperByType(type, cmdbClassModel).getActualType();
      typeToActualTypeMap.put(type, actualType);
    }
    return typeToActualTypeMap;
  }

  public Map<String, String> getActualDataInRuleConfiguredTypes(Collection<String> types) {
    CmdbClassModel cmdbClassModel = getSynchronizedClassModel();
    Map typeToActualTypeMap = new HashMap(types.size());
    for (Iterator i$ = types.iterator(); i$.hasNext(); ) { String type = (String)i$.next();
      String actualType = getDataInRuleWrapperByType(type, cmdbClassModel).getActualType();
      typeToActualTypeMap.put(type, actualType);
    }
    return typeToActualTypeMap;
  }

  private Map<String, ReconciliationConfigDef> getConfigDefCache() {
    return this._configDefCache;
  }

  private void setConfigDefCache(Map<String, ReconciliationConfigDef> configDefCache) {
    this._configDefCache = configDefCache;
  }

  private Map<String, Collection<String>> getOwnerByTypeCache() {
    return this._ownerByTypeCache;
  }

  private void setOwnerByTypeCache(Map<String, Collection<String>> ownerByTypeCache) {
    this._ownerByTypeCache = ownerByTypeCache;
  }

  private Map<IsOwnerKey, Boolean> getIsOwnerByTypeCache() {
    return this._isOwnerByTypeCache;
  }

  private void setIsOwnerByTypeCache(Map<IsOwnerKey, Boolean> isOwnerByTypeCache) {
    this._isOwnerByTypeCache = isOwnerByTypeCache;
  }

  private Map<String, RuleWrapper<DataInRule>> getDataInRuleByTypeCache() {
    return this._dataInRuleByTypeCache;
  }

  private void setDataInRuleByTypeCache(Map<String, RuleWrapper<DataInRule>> dataInRuleByTypeCache) {
    this._dataInRuleByTypeCache = dataInRuleByTypeCache;
  }

  private Map<String, RuleWrapper<Collection<IdentificationRule>>> getIdentificationRuleByTypeCache() {
    return this._identificationRuleByTypeCache;
  }

  private void setIdentificationRuleByTypeCache(Map<String, RuleWrapper<Collection<IdentificationRule>>> identificationRuleByTypeCache) {
    this._identificationRuleByTypeCache = identificationRuleByTypeCache;
  }

  private Map<String, Collection<Pattern>> getIdentificationRuleLayoutPatternsByLinkTypeCache() {
    return this._identificationRuleLayoutPatternsByLinkTypeCache;
  }

  private void setIdentificationRuleLayoutPatternsByLinkTypeCache(Map<String, Collection<Pattern>> identificationRuleLayoutPatternsByLinkTypeCache) {
    this._identificationRuleLayoutPatternsByLinkTypeCache = identificationRuleLayoutPatternsByLinkTypeCache;
  }

  private class IsOwnerKey {
    private String _dataStore;
    private String _type;

    public IsOwnerKey(, String paramString1, String paramString2) {
      this._dataStore = paramString1;
      this._type = paramString2;
    }

    public boolean equals() {
      if (this == o)
        return true;

      if ((o == null) || (super.getClass() != o.getClass())) {
        return false;
      }

      IsOwnerKey that = (IsOwnerKey)o;

      if (this._dataStore != null) if (!(this._dataStore.equals(that._dataStore))); else if (that._dataStore == null) if (this._type != null) if (this._type.equals(that._type)) break label91; 
      label91: return (that._type == null);
    }

    public int hashCode()
    {
      int result = (this._dataStore != null) ? this._dataStore.hashCode() : 0;
      result = 29 * result + ((this._type != null) ? this._type.hashCode() : 0);
      return result;
    }
  }
}