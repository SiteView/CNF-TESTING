package com.mercury.topaz.cmdb.reconciliation.server.identification.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.identification.manager.IdentificationManager;
import com.mercury.topaz.cmdb.reconciliation.server.identification.operation.impl.AbstractIdentificationOperation;
import com.mercury.topaz.cmdb.reconciliation.server.identification.operation.query.IdentificationQueryOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractIdentificationQueryOperation extends AbstractIdentificationOperation
  implements IdentificationQueryOperation
{
  public void identificationExecute(IdentificationManager identificationManager, CmdbResponse response)
  {
    identificationQueryExecute(identificationManager, response);
  }
}