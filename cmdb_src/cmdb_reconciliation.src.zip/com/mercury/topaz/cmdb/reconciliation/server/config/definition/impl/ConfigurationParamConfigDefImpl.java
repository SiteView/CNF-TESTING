package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ConfigurationParamConfigDef;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class ConfigurationParamConfigDefImpl
  implements ConfigurationParamConfigDef, IUnmarshallable, IMarshallable
{
  private String _paramName;
  private String _value;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public String getParamName()
  {
    return this._paramName;
  }

  public void setParamName(String paramName) {
    this._paramName = paramName;
  }

  public String getValue() {
    return this._value;
  }

  public void setValue(String value) {
    this._value = value;
  }
}