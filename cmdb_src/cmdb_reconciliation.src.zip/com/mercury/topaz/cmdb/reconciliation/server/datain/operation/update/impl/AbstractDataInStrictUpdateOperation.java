package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelExternalUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.StrictModelUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModelUpdateBulkInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModifiableModelUpdateBulkInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.impl.CmdbModelUpdateBulkInfoFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsStrict;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public abstract class AbstractDataInStrictUpdateOperation extends AbstractDataInUpdateDataOperation
{
  private ModelUpdateBulksStrict _updateBulk;

  protected AbstractDataInStrictUpdateOperation(DataContainer dataContainer, Changer changer)
  {
    super(dataContainer, changer);
  }

  protected void addToModelUpdateOperations(List<? extends ModelUpdate> modelUpdateOperations) {
    if ((!(modelUpdateOperations.isEmpty())) && (getUpdateBulk() == null)) {
      setUpdateBulk(new ModelUpdateBulksStrict(getChanger()));
    }

    for (Iterator i$ = modelUpdateOperations.iterator(); i$.hasNext(); ) { StrictModelUpdate modelUpdateOperation = (StrictModelUpdate)i$.next();
      getUpdateBulk().addStrictModelUpdateOperation(modelUpdateOperation);
    }
  }

  protected List<? extends ModelUpdate> createModelUpdateOperations(CmdbObjectIds idsToRemove)
  {
    return Arrays.asList(new StrictModelUpdate[] { new ModelUpdateRemoveObjectsStrict(idsToRemove, getChanger()) });
  }

  protected ModelExternalUpdate getModelUpdateOperation() {
    return getUpdateBulk();
  }

  protected CmdbModelUpdateBulkInfo sendToModelUpdate(DataInManager dataInManager) {
    if (getUpdateBulk() != null) {
      dataInManager.executeOperation(getUpdateBulk());
      return getUpdateBulk().getModelUpdateBulkInfo();
    }
    return CmdbModelUpdateBulkInfoFactory.create().getCmdbModelUpdateBulkInfo();
  }

  private ModelUpdateBulksStrict getUpdateBulk() {
    return this._updateBulk;
  }

  private void setUpdateBulk(ModelUpdateBulksStrict updateBulk) {
    this._updateBulk = updateBulk;
  }
}