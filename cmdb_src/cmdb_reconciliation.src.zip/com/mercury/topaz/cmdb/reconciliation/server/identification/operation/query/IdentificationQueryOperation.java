package com.mercury.topaz.cmdb.reconciliation.server.identification.operation.query;

import com.mercury.topaz.cmdb.reconciliation.server.identification.manager.IdentificationManager;
import com.mercury.topaz.cmdb.reconciliation.server.identification.operation.IdentificationOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;

public abstract interface IdentificationQueryOperation
{
  public abstract void identificationQueryExecute(IdentificationManager paramIdentificationManager, CmdbResponse paramCmdbResponse);
}