package com.mercury.topaz.cmdb.reconciliation.server.id.link.impl;

import com.mercury.topaz.cmdb.reconciliation.server.id.data.impl.TempCmdbDataIDImpl;
import com.mercury.topaz.cmdb.reconciliation.server.id.link.TempCmdbLinkID;

class TempCmdbLinkIDImpl extends TempCmdbDataIDImpl
  implements TempCmdbLinkID
{
  public TempCmdbLinkIDImpl(String id)
  {
    super(id);
  }

  public boolean isObjectID() {
    return false;
  }
}