package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.exception.DataInException;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.impl.DataInRuleOutputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.TempMergePropertiesInput;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.impl.MergeInputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl.MergeTopologyOutput;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddLinksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddOrIgnoreLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.add.ModelUpdateAddUpdateOrIgnoreLinks;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.link.remove.ModelUpdateRemoveLinksStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddObjectsStrict;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddOrIgnoreObjects;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddOrUpdateObjects;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsIfExist;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsStrict;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DataInSERule extends DataInDefaultRule
{
  public DataInSERule(DataInRuleDefinition ruleDefinition)
  {
    super(ruleDefinition);
  }

  public DataInRuleOutput onAddOrUpdateData(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, boolean ignoreInvalidLinks) {
    return onAdd(environment, dataInRuleInput, AddType.addOrUpdate);
  }

  public DataInRuleOutput onAddOrIgnoreData(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onAdd(environment, dataInRuleInput, AddType.addOrIgnore);
  }

  public DataInRuleOutput onAddDataStrict(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return onAdd(environment, dataInRuleInput, AddType.addStrict);
  }

  private DataInRuleOutput onAdd(ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, AddType addType)
  {
    CmdbObjectIds updatedIdsToRemove;
    CmdbObjects objectsForUpdate = dataInRuleInput.getDataContainer().getObjectsForUpdate("application");
    Map idChangesMap = new HashMap(objectsForUpdate.size());
    CmdbObjects seToAdd = CmdbObjectFactory.createHashMapObjects();
    CmdbObjects seToRemove = CmdbObjectFactory.createHashMapObjects();
    CmdbObjects seToAddOrIgnore = CmdbObjectFactory.createHashMapObjects();
    CmdbLinks linksToAdd = CmdbLinkFactory.createLinks();
    CmdbLinks linksToRemove = CmdbLinkFactory.createLinks();
    Collection mergePropertiesInputs = new ArrayList(objectsForUpdate.size());
    List mergeTopologyInputs = new ArrayList(objectsForUpdate.size());
    CmdbDataIDs idsForTouch = CmdbDataIdsFactory.create();

    InputToExistingRule[] rules = createInputToExistingRules();

    for (Iterator i$ = objectsForUpdate.iterator(); i$.hasNext(); ) { CmdbObject currentObject = (CmdbObject)i$.next();
      boolean isStrongSE = isStrongSE(currentObject);
      InputToExistingRule[] arr$ = rules; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { InputToExistingRule currentRule = arr$[i$];
        currentRule.handle(currentObject, isStrongSE, seToAdd, seToRemove, mergePropertiesInputs, mergeTopologyInputs, idsForTouch, addType, environment, dataInRuleInput, idChangesMap);
      }

    }

    Map mergeTopologyOutput = DataInUtil.mergeTopology(mergeTopologyInputs, dataInRuleInput.getDataInInfoList(), idChangesMap);
    processMergeTopologyResult(seToAdd, seToAddOrIgnore, seToRemove, linksToAdd, mergeTopologyOutput);

    Map mergePropertiesResultMap = DataInUtil.mergeCIProperties(mergePropertiesInputs, dataInRuleInput.getOwnerByType(), dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());
    for (Iterator i$ = mergePropertiesResultMap.values().iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
      if (null != object) {
        seToAdd.add(object);
      }

    }

    List modelUpdates = new ArrayList(5);

    CmdbObjectIds idsToRemove = seToRemove.asIds();
    if ((dataInRuleInput.getIdChanges() == null) || (dataInRuleInput.getIdChanges().isEmpty())) {
      updatedIdsToRemove = idsToRemove;
    }
    else {
      updatedIdsToRemove = CmdbObjectIdsFactory.createIdsList(2 * idsToRemove.size());
      for (Iterator i$ = idsToRemove.iterator(); i$.hasNext(); ) { CmdbObjectID idToRemove = (CmdbObjectID)i$.next();
        updatedIdsToRemove.add(idToRemove);
        CmdbObjectID changedID = (CmdbObjectID)dataInRuleInput.getIdChanges().get(idToRemove);
        if (changedID != null)
          updatedIdsToRemove.add(changedID);
      }

    }

    addType.addModelUpdateRemoveOperations(modelUpdates, updatedIdsToRemove, linksToRemove, dataInRuleInput.getChanger());
    addType.addModelUpdateAddObjectsOperation(modelUpdates, seToAdd, dataInRuleInput.getChanger());
    if (!(seToAddOrIgnore.isEmpty()))
      modelUpdates.add(new ModelUpdateAddOrIgnoreObjects(seToAddOrIgnore, dataInRuleInput.getChanger()));

    addType.addModelUpdateAddLinksOperation(modelUpdates, linksToAdd, dataInRuleInput.getChanger());

    return DataInRuleOutputFactory.createDataInRuleOutput(idChangesMap, modelUpdates, idsForTouch);
  }

  private void processMergeTopologyResult(CmdbObjects seToAdd, CmdbObjects seToAddOrIgnore, CmdbObjects seToRemove, CmdbLinks linksToAdd, Map<CmdbObjectID, MergeTopologyOutput> mergeTopologyOutput) {
    for (Iterator i$ = mergeTopologyOutput.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      MergeTopologyOutput output = (MergeTopologyOutput)entry.getValue();
      for (Iterator i$ = output.getObjectsToAdd().iterator(); i$.hasNext(); ) { CmdbObject objectToAdd = (CmdbObject)i$.next();
        if (((CmdbObjectID)objectToAdd.getID()).equals(entry.getKey())) {
          seToAdd.add(objectToAdd);
        }
        else
          seToAddOrIgnore.add(objectToAdd);
      }

      for (i$ = output.getObjectsToRemove().iterator(); i$.hasNext(); ) { CmdbObject objectToRemove = (CmdbObject)i$.next();
        seToRemove.add(objectToRemove);
      }
      for (i$ = output.getLinksToAdd().iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
        linksToAdd.add(link);
      }
    }
  }

  private static boolean isStrongSE(CmdbObject se) {
    return (!(se.getType().equals("application")));
  }

  private static void addToInputToReconciledData(Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap, CmdbDataID inputID, CmdbObject reconciledObject)
  {
    if (inputID.equals(reconciledObject.getID())) {
      return;
    }

    CmdbDataIDs ids = (CmdbDataIDs)inputIDToReconciledIDsMap.get(inputID);
    if (ids == null) {
      ids = CmdbDataIdsFactory.create();
      inputIDToReconciledIDsMap.put(inputID, ids);
    }
    if (!(ids.contains((CmdbDataID)reconciledObject.getID())))
      ids.add((CmdbDataID)reconciledObject.getID());
  }

  private InputToExistingRule[] createInputToExistingRules()
  {
    return { new InputToNothingRule(null), new InputAndCmdbWithTheSameIDRule(null), new StrongInputToWeakInBulk(null), new WeakInputToStrongInBulk(null), new WeakInputToStrongInCmdb(null), new StrongInputToWeakInCmdb(null), new InputToSameInBulkNotInCmdb(null) };
  }

  private static boolean doesStrongObjectExist(Collection<CmdbObject> datas)
  {
    for (Iterator i$ = datas.iterator(); i$.hasNext(); ) { CmdbObject data = (CmdbObject)i$.next();
      if (isStrongSE(data))
        return true;
    }

    return false;
  }

  private static class InputToSameInBulkNotInCmdb
  implements DataInSERule.InputToExistingRule
  {
    public void handle(CmdbObject inputObject, boolean isInputObjectStrong, CmdbObjects seToAdd, CmdbObjects seToRemove, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<MergeInput<CmdbObject>> mergeTopologyInputs, CmdbDataIDs idsForTouch, DataInSERule.AddType addType, ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, Map<CmdbDataID, CmdbDataID> idChanges)
    {
      if (dataInRuleInput.getExistingDataMap().containsKeyWithNotEmptyValue((CmdbDataID)inputObject.getID()))
        return;

      Collection datasFromBulk = dataInRuleInput.getExistingDataMap().getInBulk((CmdbDataID)inputObject.getID());
      if ((datasFromBulk != null) && (!(datasFromBulk.isEmpty()))) {
        for (Iterator i$ = datasFromBulk.iterator(); i$.hasNext(); ) { CmdbObject dataFromBulk = (CmdbObject)i$.next();
          boolean isObjectFromBulkStrong = DataInSERule.access$900(dataFromBulk);

          if (isObjectFromBulkStrong != isInputObjectStrong)
            return;
        }

        CmdbObjects resolvedObjects = DataInUtil.resolveCmdbData(environment.getDataFactory(), inputObject, dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getInputIDToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());
        seToAdd.add(resolvedObjects);
      }
    }
  }

  private static class WeakInputToStrongInBulk
  implements DataInSERule.InputToExistingRule
  {
    public void handle(CmdbObject inputObject, boolean isInputObjectStrong, CmdbObjects seToAdd, CmdbObjects seToRemove, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<MergeInput<CmdbObject>> mergeTopologyInputs, CmdbDataIDs idsForTouch, DataInSERule.AddType addType, ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, Map<CmdbDataID, CmdbDataID> idChanges)
    {
      if (isInputObjectStrong)
        return;

      Collection datasFromBulk = dataInRuleInput.getExistingDataMap().getInBulk((CmdbDataID)inputObject.getID());
      if ((datasFromBulk != null) && (!(datasFromBulk.isEmpty())))
        for (Iterator i$ = datasFromBulk.iterator(); i$.hasNext(); ) { CmdbObject dataFromBulk = (CmdbObject)i$.next();
          if (DataInSERule.access$900(dataFromBulk)) {
            CmdbDataIDs ids = CmdbDataIdsFactory.create();
            if (dataInRuleInput.getInputIDAsStringToReconciledIDsMap().containsKey(((CmdbObjectID)dataFromBulk.getID()).toString())) {
              for (Iterator i$ = ((CmdbDataIDs)dataInRuleInput.getInputIDAsStringToReconciledIDsMap().get(((CmdbObjectID)dataFromBulk.getID()).toString())).iterator(); i$.hasNext(); ) { CmdbDataID idFromBulk = (CmdbDataID)i$.next();
                ids.add(idFromBulk);
              }
            }
            else {
              CmdbObjects resolvedDataFromBulk = DataInUtil.resolveCmdbData(environment.getDataFactory(), dataFromBulk, dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getInputIDToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());
              for (Iterator i$ = resolvedDataFromBulk.iterator(); i$.hasNext(); ) { CmdbObject currentResolved = (CmdbObject)i$.next();
                ids.add((CmdbDataID)currentResolved.getID());
              }
            }
            dataInRuleInput.getInputIDAsStringToReconciledIDsMap().put(((CmdbObjectID)inputObject.getID()).toString(), ids);
            dataInRuleInput.getInputIDToReconciledIDsMap().put(inputObject.getID(), ids);
            return;
          }
        }
    }
  }

  private static class WeakInputToStrongInCmdb
  implements DataInSERule.InputToExistingRule
  {
    public void handle(CmdbObject inputObject, boolean isInputObjectStrong, CmdbObjects seToAdd, CmdbObjects seToRemove, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<MergeInput<CmdbObject>> mergeTopologyInputs, CmdbDataIDs idsForTouch, DataInSERule.AddType addType, ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, Map<CmdbDataID, CmdbDataID> idChanges)
    {
      if (isInputObjectStrong)
        return;

      CmdbObjectID inputObjectID = (CmdbObjectID)inputObject.getID();
      Collection datasFromCmdb = dataInRuleInput.getExistingDataMap().get(inputObjectID);
      if ((datasFromCmdb != null) && (!(datasFromCmdb.isEmpty())))
        for (Iterator i$ = datasFromCmdb.iterator(); i$.hasNext(); ) { CmdbObject dataFromCmdb = (CmdbObject)i$.next();
          if (DataInSERule.access$900(dataFromCmdb)) {
            Map inputIDAsStringToReconciledIDsMap = dataInRuleInput.getInputIDAsStringToReconciledIDsMap();
            Map inputIDToReconciledIDsMap = dataInRuleInput.getInputIDToReconciledIDsMap();

            CmdbDataIDs reconciledIds = (CmdbDataIDs)inputIDToReconciledIDsMap.get(inputObjectID);
            CmdbObjectID dataCmdbId = (CmdbObjectID)dataFromCmdb.getID();
            if (dataInRuleInput.getIdChanges() != null) {
              CmdbObjectID changedCmdbId = (CmdbObjectID)dataInRuleInput.getIdChanges().get(dataCmdbId);
              if (changedCmdbId != null)
                dataCmdbId = changedCmdbId;

            }

            if (reconciledIds == null) {
              reconciledIds = CmdbDataIdsFactory.create();
              reconciledIds.add(dataCmdbId);
              inputIDAsStringToReconciledIDsMap.put(inputObjectID.toString(), reconciledIds);
              inputIDToReconciledIDsMap.put(inputObjectID, reconciledIds);
            }
            else if ((!(reconciledIds.isEmpty())) && (!(reconciledIds.contains(dataCmdbId)))) {
              reconciledIds.clear();
            }
          }
        }
    }
  }

  private static class StrongInputToWeakInBulk
  implements DataInSERule.InputToExistingRule
  {
    public void handle(CmdbObject inputObject, boolean isInputObjectStrong, CmdbObjects seToAdd, CmdbObjects seToRemove, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<MergeInput<CmdbObject>> mergeTopologyInputs, CmdbDataIDs idsForTouch, DataInSERule.AddType addType, ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, Map<CmdbDataID, CmdbDataID> idChanges)
    {
      if (!(isInputObjectStrong))
        return;

      Collection datasFromBulk = dataInRuleInput.getExistingDataMap().getInBulk((CmdbDataID)inputObject.getID());
      if ((datasFromBulk != null) && (!(datasFromBulk.isEmpty())))
        for (Iterator i$ = datasFromBulk.iterator(); i$.hasNext(); ) { CmdbObject dataFromBulk = (CmdbObject)i$.next();
          if (!(DataInSERule.access$900(dataFromBulk))) {
            CmdbObjects resolvedObjects = DataInUtil.resolveCmdbData(environment.getDataFactory(), inputObject, dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getInputIDToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());
            seToAdd.add(resolvedObjects);
            return;
          }
        }
    }
  }

  private static class StrongInputToWeakInCmdb
  implements DataInSERule.InputToExistingRule
  {
    public void handle(CmdbObject inputObject, boolean isInputObjectStrong, CmdbObjects seToAdd, CmdbObjects seToRemove, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<MergeInput<CmdbObject>> mergeTopologyInputs, CmdbDataIDs idsForTouch, DataInSERule.AddType addType, ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, Map<CmdbDataID, CmdbDataID> idChanges)
    {
      if (!(isInputObjectStrong))
        return;

      Collection datasFromCmdb = dataInRuleInput.getExistingDataMap().get((CmdbDataID)inputObject.getID());
      if ((datasFromCmdb != null) && (!(datasFromCmdb.isEmpty())))
        for (Iterator i$ = datasFromCmdb.iterator(); i$.hasNext(); ) { CmdbObject dataFromCmdb = (CmdbObject)i$.next();
          if (!(DataInSERule.access$900(dataFromCmdb))) {
            CmdbObjects resolvedObjects = DataInUtil.resolveCmdbData(environment.getDataFactory(), inputObject, dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getInputIDToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());
            for (Iterator i$ = resolvedObjects.iterator(); i$.hasNext(); ) { CmdbObject currentResolved = (CmdbObject)i$.next();
              mergeTopologyInputs.add(MergeInputFactory.createMergeInput(Arrays.asList(new CmdbObject[] { dataFromCmdb }), currentResolved));
            }
            return;
          }
        }
    }
  }

  private static class InputAndCmdbWithTheSameIDRule
  implements DataInSERule.InputToExistingRule
  {
    public void handle(CmdbObject inputObject, boolean isInputObjectStrong, CmdbObjects seToAdd, CmdbObjects seToRemove, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<MergeInput<CmdbObject>> mergeTopologyInputs, CmdbDataIDs idsForTouch, DataInSERule.AddType addType, ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, Map<CmdbDataID, CmdbDataID> idChanges)
    {
      Collection datasFromCmdb = dataInRuleInput.getExistingDataMap().get((CmdbDataID)inputObject.getID());
      if ((datasFromCmdb != null) && (!(datasFromCmdb.isEmpty())))
        for (Iterator i$ = datasFromCmdb.iterator(); i$.hasNext(); ) { CmdbObject objectFromCmdb = (CmdbObject)i$.next();

          boolean isObjectFromCmdbStrong = DataInSERule.access$900(objectFromCmdb);
          if (isObjectFromCmdbStrong == isInputObjectStrong)
          {
            if ((isInputObjectStrong) || (!(DataInSERule.access$1000(dataInRuleInput.getExistingDataMap().getInBulk((CmdbDataID)inputObject.getID())))))
              addType.addToMergeProperties(dataInRuleInput, inputObject, objectFromCmdb, mergePropertiesInputs, idsForTouch);

            return;
          }
        }
    }
  }

  private static class InputToNothingRule
  implements DataInSERule.InputToExistingRule
  {
    public void handle(CmdbObject inputObject, boolean isInputObjectStrong, CmdbObjects seToAdd, CmdbObjects seToRemove, Collection<TempMergePropertiesInput<CmdbObject>> mergePropertiesInputs, Collection<MergeInput<CmdbObject>> mergeTopologyInputs, CmdbDataIDs idsForTouch, DataInSERule.AddType addType, ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput, Map<CmdbDataID, CmdbDataID> idChanges)
    {
      if ((dataInRuleInput.getExistingDataMap().containsKeyWithNotEmptyValue((CmdbDataID)inputObject.getID())) || (dataInRuleInput.getExistingDataMap().containsKeyWithNotEmptyValueInBulk((CmdbDataID)inputObject.getID())))
        return;

      CmdbObjects resolvedObjects = DataInUtil.resolveCmdbData(environment.getDataFactory(), inputObject, dataInRuleInput.getInputIDAsStringToReconciledIDsMap(), dataInRuleInput.getInputIDToReconciledIDsMap(), dataInRuleInput.getDataInInfoList());
      seToAdd.add(resolvedObjects);
    }
  }

  private static abstract interface InputToExistingRule
  {
    public abstract void handle(CmdbObject paramCmdbObject, boolean paramBoolean, CmdbObjects paramCmdbObjects1, CmdbObjects paramCmdbObjects2, Collection<TempMergePropertiesInput<CmdbObject>> paramCollection, Collection<MergeInput<CmdbObject>> paramCollection1, CmdbDataIDs paramCmdbDataIDs, DataInSERule.AddType paramAddType, ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput, Map<CmdbDataID, CmdbDataID> paramMap);
  }

  private static abstract enum AddType
  {
    addStrict, addOrIgnore, addOrUpdate;

    public static final AddType[] values()
    {
      return ((AddType[])$VALUES.clone());
    }

    public abstract void addToMergeProperties(DataInRuleInput paramDataInRuleInput, CmdbObject paramCmdbObject1, CmdbObject paramCmdbObject2, Collection<TempMergePropertiesInput<CmdbObject>> paramCollection, CmdbDataIDs paramCmdbDataIDs);

    public abstract void addModelUpdateRemoveOperations(List<ModelUpdate> paramList, CmdbObjectIds paramCmdbObjectIds, CmdbLinks paramCmdbLinks, Changer paramChanger);

    public abstract void addModelUpdateAddObjectsOperation(List<ModelUpdate> paramList, CmdbObjects paramCmdbObjects, Changer paramChanger);

    public abstract void addModelUpdateAddLinksOperation(List<ModelUpdate> paramList, CmdbLinks paramCmdbLinks, Changer paramChanger);
  }
}