package com.mercury.topaz.cmdb.reconciliation.server.datain.data;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public abstract interface DataContainer extends Serializable
{
  public abstract CmdbObjects getObjectsForUpdate(String paramString);

  public abstract CmdbLinks getLinksForUpdate(String paramString);

  public abstract CmdbObjects getReferencedObjects(String paramString);

  public abstract CmdbLinks getReferencedLinks(String paramString);

  public abstract void addObjectForUpdate(CmdbObject paramCmdbObject);

  public abstract void addObjectsForUpdate(CmdbObjects paramCmdbObjects);

  public abstract void addReferencedObject(CmdbObject paramCmdbObject);

  public abstract void addReferencedObjects(CmdbObjects paramCmdbObjects);

  public abstract void addLinkForUpdate(CmdbLink paramCmdbLink);

  public abstract void addLinksForUpdate(CmdbLinks paramCmdbLinks);

  public abstract void addReferencedLink(CmdbLink paramCmdbLink);

  public abstract void addReferencedLinks(CmdbLinks paramCmdbLinks);

  public abstract boolean contains(CmdbObjectID paramCmdbObjectID);

  public abstract boolean contains(CmdbLinkID paramCmdbLinkID);

  public abstract Iterator<Map.Entry<String, CmdbObjects>> getObjectsForUpdateIteratorByType();

  public abstract Iterator<Map.Entry<String, CmdbLinks>> getLinksForUpdateIteratorByType();

  public abstract Iterator<Map.Entry<String, CmdbObjects>> getReferencedObjectsIteratorByType();

  public abstract Iterator<Map.Entry<String, CmdbLinks>> getReferencedLinksIteratorByType();

  public abstract Iterator<? extends CmdbData> getDatasForUpdateIteratorByType(String paramString);

  public abstract Collection<String> getAllTypes();

  public abstract void orderTypes(Map<String, String> paramMap);

  public abstract int sizeOfDataForUpdate();

  public abstract boolean isDataForUpdateEmpty();

  public abstract int sizeOfReferencedData();

  public abstract boolean isReferencedDataEmpty();

  public abstract CmdbLinks getCmdbLinksByEnd1(CmdbObjectID paramCmdbObjectID);

  public abstract CmdbLinks getCmdbLinksByEnd2(CmdbObjectID paramCmdbObjectID);

  public abstract CmdbObject getCmdbObject(CmdbObjectID paramCmdbObjectID);

  public abstract CmdbLink getCmdbLink(CmdbLinkID paramCmdbLinkID);

  public abstract Iterator<CmdbObject> getCmdbObjectsIteratorByType(String paramString);

  public abstract int getObjectsForUpdateSize();

  public abstract int getLinksForUpdateSize();

  public abstract int getReferencedObjectsSize();

  public abstract int getReferencedLinksSize();

  public abstract int getObjectsForUpdateSize(String paramString);

  public abstract int getLinksForUpdateSize(String paramString);

  public abstract int getReferencedObjectsSize(String paramString);

  public abstract int getReferencedLinksSize(String paramString);

  public abstract boolean containsObjectForUpdate(CmdbObjectID paramCmdbObjectID);

  public abstract boolean containsReferencedObject(CmdbObjectID paramCmdbObjectID);

  public abstract boolean containsLinkForUpdate(CmdbLinkID paramCmdbLinkID);

  public abstract boolean containsReferencedLink(CmdbLinkID paramCmdbLinkID);

  public abstract CmdbObject getObjectForUpdate(CmdbObjectID paramCmdbObjectID);

  public abstract CmdbObject getReferencedObject(CmdbObjectID paramCmdbObjectID);

  public abstract CmdbLink getLinkForUpdate(CmdbLinkID paramCmdbLinkID);

  public abstract CmdbLink getReferencedLink(CmdbLinkID paramCmdbLinkID);

  public abstract Iterator<CmdbObject> getObjectsForUpdateIterator();

  public abstract Iterator<CmdbObject> getReferencedObjectsIterator();

  public abstract Iterator<CmdbLink> getLinksForUpdateIterator();

  public abstract Iterator<CmdbLink> getReferencedLinksIterator();

  public abstract Iterator<CmdbObject> getObjectsForUpdateIterator(String paramString);

  public abstract Iterator<CmdbObject> getReferencedObjectsIterator(String paramString);

  public abstract Iterator<CmdbLink> getLinksForUpdateIterator(String paramString);

  public abstract Iterator<CmdbLink> getReferencedLinksIterator(String paramString);
}