package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import java.util.Collection;
import java.util.Iterator;

public class DataInMergeTopologyInfo
  implements DataInInfo
{
  private CmdbObject _inputObject;
  private Collection<CmdbObject> _datasToMerge;
  private CmdbObjects _objectsToRemove;
  private CmdbObjects _objectsToAdd;
  private CmdbLinks _linksToRemove;
  private CmdbLinks _linksToAdd;

  public DataInMergeTopologyInfo(CmdbObject inputObject, Collection<CmdbObject> datasToMerge, CmdbObjects objectsToRemove, CmdbObjects objectsToAdd, CmdbLinks linksToRemove, CmdbLinks linksToAdd)
  {
    this._inputObject = inputObject;
    this._datasToMerge = datasToMerge;
    this._objectsToRemove = objectsToRemove;
    this._objectsToAdd = objectsToAdd;
    this._linksToRemove = linksToRemove;
    this._linksToAdd = linksToAdd;
  }

  public String getShortMessage() {
    StringBuilder info = new StringBuilder("Merged Topology: \n\t[input object:");
    info.append(this._inputObject);
    info.append("]\n\t[objects to merge:");
    appendObjects(info, 2, this._datasToMerge);
    info.append("]\n\t[result:\n\t\t(objects to add-");
    appendObjects(info, 3, this._objectsToAdd).append(")\n\t\t(objects to remove-");
    appendObjects(info, 3, this._objectsToRemove);
    info.append(")\n\t\t(links to add-");
    appendObjects(info, 3, this._linksToAdd).append(")\n\t\t(links to remove-");
    appendObjects(info, 3, this._linksToRemove).append(")");
    return info.toString();
  }

  private <Type> StringBuilder appendObjects(StringBuilder sb, int numberOfTabs, Iterable<Type> objects) {
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { Object obj = i$.next();
      sb.append("\n");
      addTabs(sb, numberOfTabs);
      sb.append(obj);
    }
    return sb;
  }

  private static void addTabs(StringBuilder sb, int numberOfTabs) {
    for (int i = 0; i < numberOfTabs; ++i)
      sb.append("\t");
  }
}