package com.mercury.topaz.cmdb.reconciliation.server.config.definition;

import java.io.Serializable;
import java.util.Collection;

public abstract interface DataChangeRuleConfigDef extends Serializable
{
  public abstract String getClassName();

  public abstract Collection<ConfigurationParamConfigDef> getConfigurationParams();
}