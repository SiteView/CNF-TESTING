package com.mercury.topaz.cmdb.reconciliation.server.config.admin.manager.impl;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public class ReconciliationConfigAdminManagerFactory extends AbstractSubsystemManagerFactory
{
  public static final String NAME = "Reconciliation Config Task";

  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new ReconciliationConfigAdminManagerImpl(localEnvironment);
  }
}