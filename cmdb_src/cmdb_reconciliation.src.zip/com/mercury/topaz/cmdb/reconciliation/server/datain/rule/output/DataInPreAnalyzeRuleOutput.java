package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output;

import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;

public abstract interface DataInPreAnalyzeRuleOutput
{
  public abstract CmdbObjectIds getObjectsToRemove();
}