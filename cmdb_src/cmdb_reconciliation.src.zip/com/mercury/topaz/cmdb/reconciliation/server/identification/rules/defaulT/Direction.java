package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import java.io.Serializable;

abstract interface Direction extends Serializable
{
  public abstract CmdbObjectID getSource(CmdbLink paramCmdbLink);

  public abstract CmdbObjectID getTarget(CmdbLink paramCmdbLink);

  public abstract PatternLink createPatternLink(PatternElementNumber paramPatternElementNumber1, PatternElementNumber paramPatternElementNumber2, PatternElementNumber paramPatternElementNumber3, ElementCondition paramElementCondition, boolean paramBoolean);

  public abstract CmdbLinks getLinksFromDataContainerBySource(DataContainer paramDataContainer, CmdbObjectID paramCmdbObjectID);
}