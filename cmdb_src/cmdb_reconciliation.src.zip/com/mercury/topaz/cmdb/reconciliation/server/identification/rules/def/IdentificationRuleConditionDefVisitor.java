package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

public abstract interface IdentificationRuleConditionDefVisitor
{
  public abstract void visit(IdentificationRuleAttributesConditionDef paramIdentificationRuleAttributesConditionDef);

  public abstract void visit(IdentificationRuleByIdDef paramIdentificationRuleByIdDef);

  public abstract void visit(IdentificationRuleByLinkIdDef paramIdentificationRuleByLinkIdDef);

  public abstract void visit(IdentificationRuleEmptyConditionDef paramIdentificationRuleEmptyConditionDef);
}