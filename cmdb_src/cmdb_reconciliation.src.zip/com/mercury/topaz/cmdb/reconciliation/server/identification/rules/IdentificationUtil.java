package com.mercury.topaz.cmdb.reconciliation.server.identification.rules;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ReconciliationConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.IdentificationConfiguration;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.IdentificationRuleConfig;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.IdentificationRuleProprietaryConfig;
import com.mercury.topaz.cmdb.reconciliation.server.config.exception.ReconciliationConfigException;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT.DefaultIdentificationRuleFactory;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

public class IdentificationUtil
{
  public static Collection<IdentificationRule> getIdentificationRulesFromDef(ReconciliationConfigDef def)
  {
    Collection identificationRules = new ArrayList(1);
    IdentificationConfiguration identificationConfig = def.getIdentificationConfigDef();
    if (identificationConfig != null) {
      Collection configs;
      Iterator i$;
      IdentificationRule identificationRule;
      if (identificationConfig.getIdentificationRuleConfig() != null) {
        configs = identificationConfig.getIdentificationRuleConfig();
        for (i$ = configs.iterator(); i$.hasNext(); ) { IdentificationRuleConfig config = (IdentificationRuleConfig)i$.next();
          identificationRule = createIdentificationRule(config);
          identificationRules.add(identificationRule);
        }
      }
      if (identificationConfig.getIdentificationRuleProprietaryConfig() != null) {
        configs = identificationConfig.getIdentificationRuleProprietaryConfig();
        for (i$ = configs.iterator(); i$.hasNext(); ) { IdentificationRuleProprietaryConfig config = (IdentificationRuleProprietaryConfig)i$.next();
          identificationRule = createIdentificationRule(config);
          identificationRules.add(identificationRule);
        }
      }
    }

    if (identificationRules.isEmpty())
      return Collections.emptyList();
    return identificationRules;
  }

  private static IdentificationRule createIdentificationRule(IdentificationRuleProprietaryConfig config) {
    IdentificationRule identificationRule;
    try {
      if ((config.getStringConfiguration() != null) && (config.getStringConfiguration().length() > 0)) {
        identificationRule = (IdentificationRule)Class.forName(config.getClassName()).getConstructor(new Class[] { IdentificationRuleProprietaryConfig.class }).newInstance(new Object[] { config });
      }
      else
        identificationRule = (IdentificationRule)Class.forName(config.getClassName()).newInstance();
    }
    catch (Exception e)
    {
      throw new ReconciliationConfigException("Error while trying to load the identification rule class: " + e, e);
    }
    return identificationRule; }

  private static IdentificationRule createIdentificationRule(IdentificationRuleConfig config) {
    IdentificationRule identificationRule;
    String className;
    try {
      className = config.getClassName();
      if (className == null) {
        identificationRule = DefaultIdentificationRuleFactory.createDefaultIdentificationRule(config);
      }
      else
        identificationRule = (IdentificationRule)Class.forName(className).getConstructor(new Class[] { IdentificationRuleConfig.class }).newInstance(new Object[] { config });
    }
    catch (Exception e)
    {
      throw new ReconciliationConfigException("Error while trying to load the identification rule class: " + e, e);
    }
    return identificationRule;
  }
}