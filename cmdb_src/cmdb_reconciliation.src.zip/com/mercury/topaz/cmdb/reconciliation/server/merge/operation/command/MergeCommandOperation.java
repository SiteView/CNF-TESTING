package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.command;

import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.MergeOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.command.CmdbCommand;

public abstract interface MergeCommandOperation
{
}