package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update;

import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import java.util.Map;

public abstract interface DataInUpdateDataOperation extends DataInUpdateOperation
{
  public abstract Map<CmdbDataID, CmdbDataIDs> getInputIDToReconciledIDsMap();
}