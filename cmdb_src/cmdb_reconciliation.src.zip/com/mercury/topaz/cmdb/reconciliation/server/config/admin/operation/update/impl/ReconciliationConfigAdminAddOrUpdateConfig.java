package com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.admin.manager.ReconciliationConfigAdminManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.update.impl.ReconciliationConfigCacheAddOrUpdateConfig;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ReconciliationConfigDef;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.add.ModelUpdateAddOrUpdateObjects;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class ReconciliationConfigAdminAddOrUpdateConfig extends AbstractReconciliationConfigUpdateAdminOperation
{
  private Collection<ReconciliationConfigDef> _configDefs;

  public ReconciliationConfigAdminAddOrUpdateConfig(ReconciliationConfigDef configDef, Changer changer)
  {
    super(changer);
    Collection configDefs = new ArrayList(1);
    configDefs.add(configDef);
    setConfigDefs(configDefs);
  }

  public ReconciliationConfigAdminAddOrUpdateConfig(Collection<ReconciliationConfigDef> configDefs, Changer changer) {
    super(changer);
    setConfigDefs(configDefs);
  }

  public String getOperationName() {
    return "Reconciliation Config Admin - Add Or Update Config";
  }

  public void configUpdateExecute(ReconciliationConfigAdminManager configAdminManager, CmdbResponse response) throws CmdbException
  {
    DataFactory dataFactory = DataFactoryCreator.create(configAdminManager.getSynchronizedClassModel());
    CmdbObjects configObjects = CmdbObjectFactory.createObjects();
    for (Iterator i$ = getConfigDefs().iterator(); i$.hasNext(); ) { ReconciliationConfigDef configDef = (ReconciliationConfigDef)i$.next();
      CmdbProperties props = CmdbPropertyFactory.createProperties();
      props.add(CmdbPropertyFactory.createProperty("data_name", configDef.getType()));
      props.add(CmdbPropertyFactory.createXmlProperty("configuration", configDef.toXml()));
      CmdbObject configObject = dataFactory.createObject("reconciliation_configuration", props);
      configObjects.add(configObject);
    }

    if (!(configObjects.isEmpty()))
    {
      updatePersistency(configObjects);

      updateCache();
    }
  }

  private void updatePersistency(CmdbObjects configObjects) {
    ServerApiFacade.executeOperation(new ModelUpdateAddOrUpdateObjects(configObjects, getChanger()));
  }

  private void updateCache() {
    ServerApiFacade.executeOperation(new ReconciliationConfigCacheAddOrUpdateConfig(getConfigDefs()));
  }

  private Collection<ReconciliationConfigDef> getConfigDefs() {
    return this._configDefs;
  }

  private void setConfigDefs(Collection<ReconciliationConfigDef> configDefs) {
    this._configDefs = configDefs;
  }
}