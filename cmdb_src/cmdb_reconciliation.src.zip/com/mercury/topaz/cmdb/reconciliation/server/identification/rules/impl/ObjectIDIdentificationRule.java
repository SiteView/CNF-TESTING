package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ModelUtil;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.model.operation.query.topology.separation.ModelTopologyQueryCheckObjectsExistence;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ObjectIDIdentificationRule extends IDIdentificationRule
{
  private static final ObjectIDIdentificationRule _instance = new ObjectIDIdentificationRule();

  public static ObjectIDIdentificationRule getInstance()
  {
    return _instance;
  }

  public void identify(IdentificationRuleInput input) {
    DataFactory dataFactory = input.getReconciliationRuleEnvironment().getDataFactory();
    InputIdToCmdbDatasMapping identificationMap = input.getAlreadyReconciledData();
    DataContainer dataContainer = input.getDataContainer();
    CmdbObjects objectsToIdentify = dataContainer.getObjectsForUpdate(input.getTypeToIdentify());

    IdentificationScope identificationScope = input.getIdentifierScope();
    if (identificationScope.isContainCMDB()) {
      identifyInCmdb(objectsToIdentify, identificationMap, dataFactory);
    }

    if (identificationScope.isContainBulk())
      identifyInBulk(objectsToIdentify, identificationMap, dataFactory, dataContainer);
  }

  private void identifyInCmdb(CmdbObjects objectsToIdentify, InputIdToCmdbDatasMapping identificationMap, DataFactory dataFactory)
  {
    CmdbObjectID inputId;
    Map realIdToInputObject = new HashMap();
    CmdbObjects objectsToFind = CmdbObjectFactory.createObjectsList();

    for (Iterator i$ = objectsToIdentify.iterator(); i$.hasNext(); ) { CmdbObject currentObject = (CmdbObject)i$.next();
      CmdbObjectID id = (CmdbObjectID)currentObject.getID();
      Collection objectsWithRealID = ModelUtil.createObjectWithRealId(currentObject, identificationMap, dataFactory, IdentificationScope.CMDB);
      if (objectsWithRealID.isEmpty())
      {
        identificationMap.add(id, Collections.emptyList());
      }
      else for (Iterator i$ = objectsWithRealID.iterator(); i$.hasNext(); ) { CmdbObject objectWithRealID = (CmdbObject)i$.next();
          objectsToFind.add(objectWithRealID);
          realIdToInputObject.put(objectWithRealID.getID(), currentObject);
        }
    }

    ModelTopologyQueryCheckObjectsExistence getData = new ModelTopologyQueryCheckObjectsExistence(objectsToFind);
    ServerApiFacade.executeOperation(getData);

    for (Iterator i$ = getData.getExistingObjects().iterator(); i$.hasNext(); ) { CmdbObject existObject = (CmdbObject)i$.next();
      inputId = (CmdbObjectID)((CmdbObject)realIdToInputObject.get(existObject.getID())).getID();
      addExistingObjectToMap(identificationMap, existObject, inputId);
    }
    for (i$ = getData.getNonExistingObjects().iterator(); i$.hasNext(); ) { CmdbObject notExistObject = (CmdbObject)i$.next();
      inputId = (CmdbObjectID)((CmdbObject)realIdToInputObject.get(notExistObject.getID())).getID();
      identificationMap.add(inputId, Collections.emptyList());
    }
  }

  private void addExistingObjectToMap(InputIdToCmdbDatasMapping identificationDatas, CmdbObject existObject, CmdbObjectID inputId)
  {
    Collection existingObjects = identificationDatas.get(inputId);
    if (existingObjects == null) {
      existingObjects = new ArrayList(1);
      identificationDatas.add(inputId, existingObjects);
    }
    for (Iterator i$ = existingObjects.iterator(); i$.hasNext(); ) { CmdbObject currentExistsObject = (CmdbObject)i$.next();
      if (((CmdbObjectID)currentExistsObject.getID()).equals(existObject.getID()))
        return;
    }

    existingObjects.add(existObject);
  }

  private void identifyInBulk(CmdbObjects objectsToIdentify, InputIdToCmdbDatasMapping identificationMap, DataFactory dataFactory, DataContainer dataContainer) {
    for (Iterator i$ = objectsToIdentify.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
      CmdbObjectID objectID = (CmdbObjectID)object.getID();

      Collection allPossibleObjects = ModelUtil.createObjectWithRealId(object, identificationMap, dataFactory, IdentificationScope.BULK);
      if ((allPossibleObjects.size() == 1) && (((CmdbObjectID)((CmdbObject)allPossibleObjects.iterator().next()).getID()).equals(objectID))) {
        identificationMap.addInBulk(objectID, Collections.emptyList());
      } else {
        Collection identifiedObjects = new ArrayList(allPossibleObjects.size());
        for (Iterator i$ = allPossibleObjects.iterator(); i$.hasNext(); ) { CmdbObject objectToGetFromDataConainer = (CmdbObject)i$.next();
          CmdbObjectID objectIdToGetFromDataContainer = (CmdbObjectID)objectToGetFromDataConainer.getID();
          if (!(objectIdToGetFromDataContainer.equals(objectID))) {
            CmdbObject objectFromDataContainer = dataContainer.getCmdbObject(objectIdToGetFromDataContainer);
            if (objectFromDataContainer != null)
              identifiedObjects.add(objectFromDataContainer);
          }
        }

        identificationMap.addInBulk(objectID, identifiedObjects);
      }
    }
  }
}