package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.util.Collection;

public abstract interface MergeInputs<ID extends CmdbDataID, Type extends CmdbData> extends Iterable<MergeInput<Type>>
{
  public abstract MergeInput<Type> getMergeInputByUpdatingDataId(ID paramID);

  public abstract Collection<MergeInput<Type>> getAllMergeInputs();

  public abstract MergeInput<Type> add(Type paramType, CmdbDatas<ID, Type> paramCmdbDatas);

  public abstract MergeInput<Type> add(Type paramType, Collection<Type> paramCollection);

  public abstract MergeInput<Type> add(Type paramType1, Type paramType2);

  public abstract boolean isEmpty();

  public abstract int size();
}