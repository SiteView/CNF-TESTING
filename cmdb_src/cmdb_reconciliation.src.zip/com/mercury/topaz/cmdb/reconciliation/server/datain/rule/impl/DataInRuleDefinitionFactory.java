package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;
import java.util.Map;

public class DataInRuleDefinitionFactory
{
  public static DataInRuleDefinition createDataInRuleDefinition(Map<String, String> configurationParams)
  {
    return new DataInRuleDefinitionImpl(configurationParams);
  }
}