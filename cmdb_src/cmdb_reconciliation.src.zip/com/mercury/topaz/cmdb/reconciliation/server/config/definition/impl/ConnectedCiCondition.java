package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import java.io.Serializable;

public class ConnectedCiCondition
  implements Serializable
{
  protected CiIdCondition ciIdCondition;
  protected AttributeCondition attributeCondition;
  protected And and;
  protected Or or;
  protected String ciType;
  protected String linkType;
  protected boolean isDirectionForward;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public ConnectedCiCondition()
  {
    this.isDirectionForward = true;
  }

  public CiIdCondition getCiIdCondition() {
    return this.ciIdCondition;
  }

  public void setCiIdCondition(CiIdCondition ciIdCondition) {
    this.ciIdCondition = ciIdCondition;
  }

  public AttributeCondition getAttributeCondition() {
    return this.attributeCondition;
  }

  public void setAttributeCondition(AttributeCondition attributeCondition) {
    this.attributeCondition = attributeCondition;
  }

  public And getAnd() {
    return this.and;
  }

  public void setAnd(And and) {
    this.and = and;
  }

  public Or getOr() {
    return this.or;
  }

  public void setOr(Or or) {
    this.or = or;
  }

  public String getCiType() {
    return this.ciType;
  }

  public void setCiType(String ciType) {
    this.ciType = ciType;
  }

  public String getLinkType() {
    return this.linkType;
  }

  public void setLinkType(String linkType) {
    this.linkType = linkType;
  }

  public boolean getIsDirectionForward() {
    return this.isDirectionForward;
  }

  public void setIsDirectionForward(boolean isDirectionForward) {
    this.isDirectionForward = isDirectionForward;
  }
}