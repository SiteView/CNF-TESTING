package com.mercury.topaz.cmdb.reconciliation.server.environment;

import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;

public abstract interface ReconciliationEnvironment
{
  public abstract CmdbClassModel getCmdbClassModel();

  public abstract DataFactory getDataFactory();
}