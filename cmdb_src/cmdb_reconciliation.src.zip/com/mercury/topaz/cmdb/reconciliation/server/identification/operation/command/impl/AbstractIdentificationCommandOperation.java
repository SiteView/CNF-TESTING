package com.mercury.topaz.cmdb.reconciliation.server.identification.operation.command.impl;

import com.mercury.topaz.cmdb.reconciliation.server.identification.manager.IdentificationManager;
import com.mercury.topaz.cmdb.reconciliation.server.identification.operation.command.IdentificationCommandOperation;
import com.mercury.topaz.cmdb.reconciliation.server.identification.operation.impl.AbstractIdentificationOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractIdentificationCommandOperation extends AbstractIdentificationOperation
  implements IdentificationCommandOperation
{
  public void identificationExecute(IdentificationManager identificationManager, CmdbResponse response)
  {
    identificationCommandExecute(identificationManager, response);
  }
}