package com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation;

import com.mercury.topaz.cmdb.reconciliation.server.config.admin.manager.ReconciliationConfigAdminManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.CmdbOperation;

public abstract interface ReconciliationConfigAdminOperation extends CmdbOperation
{
  public abstract void configExecute(ReconciliationConfigAdminManager paramReconciliationConfigAdminManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}