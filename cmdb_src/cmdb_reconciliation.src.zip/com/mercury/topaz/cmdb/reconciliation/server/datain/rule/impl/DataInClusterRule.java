package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.And;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.AttributeCondition;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.CiIdCondition;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.ConnectedCiCondition;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.IdentificationRuleConfig;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT.DefaultIdentificationRuleFactory;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl.InputIdToCmdbDatasMappingFactory;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.impl.IdentificationRuleInputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.impl.MergeInputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl.AbstractPatternCreator;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl.PatternAndLayoutContainer;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl.PatternCreator;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.model.operation.query.impl.ModelQueryFactory;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalOperator;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.operation.query.ModelQueryGetObjectsLayoutByIDs;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyValuesFactory;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbStringPropertyValues;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ConditionOperator;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.NodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DataInClusterRule extends DataInHostRule
{
  public DataInClusterRule(DataInRuleDefinition ruleDefinition)
  {
    super(ruleDefinition);
  }

  protected void customise(CmdbObjects objectsToAdd, CmdbObjects objectsToAddRoIgnore, CmdbObjectIds objectsToRemove, CmdbLinks linksToAdd, CmdbLinks linksToRemove, DataInRuleInput ruleInput, ReconciliationEnvironment environment)
  {
    DataContainer dataContainer = ruleInput.getDataContainer();
    CmdbObjects clusters = dataContainer.getObjectsForUpdate(ruleInput.getType());
    Map existingCompleteHostsMap = findAllCompleteHosts(clusters, ruleInput, environment);

    List mergeTopologyInputs = new ArrayList(existingCompleteHostsMap.size());
    for (Iterator i$ = existingCompleteHostsMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      Collection existingCompleteHosts = (Collection)entry.getValue();
      if (!(existingCompleteHosts.isEmpty())) {
        CmdbObject cluster = (CmdbObject)entry.getKey();
        mergeTopologyInputs.add(MergeInputFactory.createMergeInput(existingCompleteHosts, cluster));
      }
    }

    PatternCreator patternCreator = new ClusterPatternCreator(mergeTopologyInputs, ruleInput);
    Map mergeTopologyOutput = DataInUtil.mergeTopology(mergeTopologyInputs, ruleInput.getDataInInfoList(), null, patternCreator, false);
    processMergeTopologyResult(objectsToAdd, objectsToAddRoIgnore, objectsToRemove, linksToAdd, linksToRemove, mergeTopologyOutput);
  }

  private Map<CmdbObject, Collection<CmdbObject>> findAllCompleteHosts(CmdbObjects clusters, DataInRuleInput ruleInput, ReconciliationEnvironment environment) {
    ConnectedCiCondition connectedCondition = new ConnectedCiCondition();
    connectedCondition.setCiType("ip");
    connectedCondition.setLinkType("contained");
    connectedCondition.setCiIdCondition(new CiIdCondition());

    And and = new And();
    and.setConnectedCiCondition(connectedCondition);
    AttributeCondition isCompleteAttributeCondition = new AttributeCondition();
    isCompleteAttributeCondition.setAttributeName("host_iscomplete");
    and.addAttributeCondition(isCompleteAttributeCondition);
    IdentificationRuleConfig identificationRuleConfig = new IdentificationRuleConfig();
    identificationRuleConfig.setTargetType("host");
    identificationRuleConfig.setAnd(and);

    IdentificationRule identificationRule = DefaultIdentificationRuleFactory.createDefaultIdentificationRule(identificationRuleConfig);
    int numberOfClusters = clusters.size();
    InputIdToCmdbDatasMapping existingMap = InputIdToCmdbDatasMappingFactory.create(numberOfClusters);
    IdentificationRuleInput identificationRuleInput = IdentificationRuleInputFactory.create(environment, ruleInput.getDataContainer(), ruleInput.getType(), existingMap, IdentificationScope.CMDB);
    identificationRule.identify(identificationRuleInput);

    Map ans = new HashMap(numberOfClusters);
    for (Iterator i$ = existingMap.iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();

      Collection existingCompleteHosts = (Collection)entry.getValue();
      if (!(existingCompleteHosts.isEmpty())) {
        CmdbObjectID id = (CmdbObjectID)entry.getKey();
        CmdbObject cluster = (CmdbObject)clusters.get(id);
        ans.put(cluster, existingCompleteHosts);
      }
    }
    return ans;
  }

  private static class ClusterPatternCreator extends AbstractPatternCreator {
    private final List<MergeInput<CmdbObject>> _mergeTopologyInputs;
    private final DataInRuleInput _dataInRuleInput;

    public ClusterPatternCreator(List<MergeInput<CmdbObject>> mergeTopologyInputs, DataInRuleInput dataInRuleInput) {
      this._mergeTopologyInputs = mergeTopologyInputs;
      this._dataInRuleInput = dataInRuleInput;
    }

    public PatternAndLayoutContainer create(CmdbObjectIds ids) {
      int nodeNumber = 0;
      PatternElementNumber containsObjectsNodeNumber = PatternElementNumberFactory.createElementNumber(nodeNumber++);
      PatternElementNumber compoundContainerLinkElementNumber = PatternElementNumberFactory.createElementNumber(nodeNumber++);
      PatternElementNumber containedObjectsNodeNumber = PatternElementNumberFactory.createElementNumber(nodeNumber++);

      PatternElementNumber innerObjectsElementNumber = PatternElementNumberFactory.createElementNumber(nodeNumber++);
      PatternElementNumber innerLinksElementNumber = PatternElementNumberFactory.createElementNumber(nodeNumber++);

      ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
      PatternElementNumber mainNodeElementNumber = PatternElementNumberFactory.createElementNumber(nodeNumber++);
      PatternElementNumber linkNodeElementNumber = PatternElementNumberFactory.createElementNumber(nodeNumber);
      addNodeWithIdConditionFromInput(patternGraph, mainNodeElementNumber, "object", ids);
      addNodeWithPropertiesCondition(patternGraph, containsObjectsNodeNumber, "application", this._mergeTopologyInputs, this._dataInRuleInput.getDataContainer());
      addLink(patternGraph, linkNodeElementNumber, mainNodeElementNumber, containsObjectsNodeNumber);
      addNode(patternGraph, containedObjectsNodeNumber, "object");
      addCompoundLink(patternGraph, compoundContainerLinkElementNumber, containsObjectsNodeNumber, containedObjectsNodeNumber, innerObjectsElementNumber, innerLinksElementNumber);

      Pattern pattern = PatternDefinitionFactory.createPattern("DataInClusterRule - Merge Topology Pattern!", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);
      ElementSimpleLayout fullLayout = createFullLayout();
      pattern.getLayout().setElementLayout(containsObjectsNodeNumber, fullLayout);
      pattern.getLayout().setElementLayout(containedObjectsNodeNumber, fullLayout);

      return new PatternAndLayoutContainer(pattern, Arrays.asList(new PatternElementNumber[] { containsObjectsNodeNumber, containedObjectsNodeNumber }));
    }

    protected void addNodeWithPropertiesCondition(ModifiablePatternGraph patternGraph, PatternElementNumber elementNumber, String type, List<MergeInput<CmdbObject>> mergeTopologyInputs, DataContainer dataContainer) {
      CmdbStringPropertyValues ipAddresses = CmdbPropertyValuesFactory.createCmdbStringPropertyValues();
      CmdbObjectIds ipIdsToRetrieveAddressFromCmdb = fillAllIpAddressesFromDataContainer(mergeTopologyInputs, dataContainer, ipAddresses);
      fillIpAddressesFromCmdb(ipIdsToRetrieveAddressFromCmdb, ipAddresses);

      ModifiableElementPropertiesCondition propertiesCondition = PatternConditionFactory.createElementPropertiesCondition();
      propertiesCondition.addPropertyCondition(PatternConditionFactory.createPropertyCondition("application_ip", ConditionOperator.IN, ipAddresses, false));
      ElementClassCondition classCondition = PatternConditionFactory.createElementClassCondition(type, true);
      ElementCondition elementCondition = PatternConditionFactory.createElementCondition(classCondition, propertiesCondition);
      NodeLinksCondition nodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
      patternGraph.addNode(PatternGraphFactory.createPatternNode(elementNumber, elementCondition, true, nodeLinksCondition));
    }

    private CmdbObjectIds fillAllIpAddressesFromDataContainer(List<MergeInput<CmdbObject>> mergeTopologyInputs, DataContainer dataContainer, CmdbStringPropertyValues ipAddressesToFill) {
      CmdbObjectIds ipIdsToRetrieveAddressFromCmdb = CmdbObjectIdsFactory.create();
      for (Iterator i$ = mergeTopologyInputs.iterator(); i$.hasNext(); ) { MergeInput mergeInput = (MergeInput)i$.next();
        CmdbObject host = (CmdbObject)mergeInput.getUpdatingData();
        CmdbLinks linksFromHost = dataContainer.getCmdbLinksByEnd1((CmdbObjectID)host.getID());
        for (Iterator i$ = linksFromHost.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
          CmdbObjectID potentiallyIpId = link.getEnd2();
          CmdbObject potentiallyIp = dataContainer.getCmdbObject(potentiallyIpId);
          if (potentiallyIp.getType().equals("ip")) {
            CmdbProperty ipAddressProperty = potentiallyIp.getProperty("ip_address");
            if ((ipAddressProperty != null) && (!(ipAddressProperty.isValueEmpty()))) {
              String ipAddress = (String)ipAddressProperty.getValue();
              ipAddressesToFill.add(ipAddress);
            } else {
              ipIdsToRetrieveAddressFromCmdb.add(potentiallyIpId);
            }
          }
        }
      }
      return ipIdsToRetrieveAddressFromCmdb;
    }

    private void fillIpAddressesFromCmdb(CmdbObjectIds ipIdsToRetrieveAddressFromCmdb, CmdbStringPropertyValues ips) {
      if (!(ipIdsToRetrieveAddressFromCmdb.isEmpty())) {
        CmdbObjects missingIps = getObjects(ipIdsToRetrieveAddressFromCmdb, new String[] { "ip_address" });
        for (Iterator i$ = missingIps.iterator(); i$.hasNext(); ) { CmdbObject ip = (CmdbObject)i$.next();
          CmdbProperty ipAddressProperty = ip.getProperty("ip_address");
          if ((ipAddressProperty != null) && (!(ipAddressProperty.isValueEmpty()))) {
            String ipAddress = (String)ipAddressProperty.getValue();
            ips.add(ipAddress);
          }
        }
      }
    }

    private CmdbObjects getObjects(CmdbObjectIds ids, String[] requestedProperties) {
      ElementSimpleLayout layout = PatternLayoutFactory.createElementSimpleLayout();
      String[] arr$ = requestedProperties; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String propertyName = arr$[i$];
        layout.addKey(propertyName);
      }
      ModelQueryGetObjectsLayoutByIDs getObjects = ModelQueryFactory.getInternalModelQueryGetObjectsLayoutByIdOperation(layout, ids);
      ServerApiFacade.executeOperation(getObjects);
      return getObjects.getResultObjects();
    }

    private void addLink(ModifiablePatternGraph patternGraph, PatternElementNumber linkElementNumber, PatternElementNumber end1ElementNumber, PatternElementNumber end2ElementNumber) {
      ElementCondition tripleLinkCondition = PatternConditionFactory.createElementCondition("link", true);
      patternGraph.addLink(PatternGraphFactory.createPatternLink(linkElementNumber, end1ElementNumber, end2ElementNumber, tripleLinkCondition, true, false));

      addDefaultLinkCardinality(patternGraph, linkElementNumber, end1ElementNumber, LogicalOperator.AND);
      addDefaultLinkCardinality(patternGraph, linkElementNumber, end2ElementNumber, LogicalOperator.AND);
    }
  }
}