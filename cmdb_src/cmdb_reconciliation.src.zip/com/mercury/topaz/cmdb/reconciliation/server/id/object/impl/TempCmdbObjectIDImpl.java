package com.mercury.topaz.cmdb.reconciliation.server.id.object.impl;

import com.mercury.topaz.cmdb.reconciliation.server.id.data.impl.TempCmdbDataIDImpl;
import com.mercury.topaz.cmdb.reconciliation.server.id.object.TempCmdbObjectID;

class TempCmdbObjectIDImpl extends TempCmdbDataIDImpl
  implements TempCmdbObjectID
{
  public TempCmdbObjectIDImpl(String id)
  {
    super(id);
  }

  public boolean isObjectID() {
    return true;
  }

  public void addStringId(StringBuffer sb) {
    sb.append(toString());
  }

  public int compareTo(Object o) {
    throw new UnsupportedOperationException("TempCmdbObjectID does not support compare!!! ");
  }
}