package com.mercury.topaz.cmdb.reconciliation.server.datain.exception;

import com.mercury.topaz.cmdb.reconciliation.server.exception.ReconciliationException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;

public class DataInException extends ReconciliationException
{
  public DataInException(String message)
  {
    super(message);
  }

  public DataInException(String message, ErrorCode errorCode) {
    super(message, errorCode);
  }

  public DataInException(String message, Throwable cause) {
    super(message, cause);
  }

  public DataInException(String message, Throwable cause, ErrorCode errorCode) {
    super(message, cause, errorCode);
  }

  public DataInException(Throwable cause) {
    super(cause);
  }

  public DataInException(Throwable cause, ErrorCode errorCode) {
    super(cause, errorCode);
  }
}