package com.mercury.topaz.cmdb.reconciliation.server.identification.manager.impl;

import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.infra.setting.SettingServiceAPI;
import com.mercury.infra.setting.SettingsFactory;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.identification.manager.IdentificationManager;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadMultiWrite;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.CmdbConstants.Enrichment.Action;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalOperator;
import com.mercury.topaz.cmdb.shared.enrichment.admin.operation.update.impl.EnrichmentUpdateAddEnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.admin.operation.update.impl.EnrichmentUpdateRemoveEnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.calculator.operation.command.impl.EnrichmentCommandAdHocCalculator;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentDefinition;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentMutableActions;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentObject;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.EnrichmentParam;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.impl.EnrichmentActionFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.impl.EnrichmentDefinitionFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.impl.EnrichmentObjectFactory;
import com.mercury.topaz.cmdb.shared.enrichment.definition.definition.impl.EnrichmentParamFactory;
import com.mercury.topaz.cmdb.shared.manage.Environment;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Priority.PatternPriorityType;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ConditionOperator;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.CmdbPatternIDFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdatePatternCreate;
import com.mercury.topaz.cmdb.shared.tql.operation.update.impl.TqlUpdatePatternRemove;

public class IdentificationManagerFactory extends AbstractSubsystemManagerFactory
{
  public static final String NAME = "Reconciliation Identification Task";
  private static final String ENRICHMENT_NAME = "ReconciliationDoubleHostsEnrichment";

  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new IdentificationManagerImpl(localEnvironment);
  }

  private static class IdentificationManagerImpl extends CmdbSubsystemManagerImpl
  implements IdentificationManager, MultiReadMultiWrite
  {
    IdentificationManagerImpl(LocalEnvironment localEnvironment) {
      super(localEnvironment);
    }

    public void startUp() {
      upgrade();
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation Identification Manager is started up properly !!!");
    }

    public void shutdown() {
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation Identification Manager is shutdown up properly !!!");
    }

    public String getName() {
      return "Reconciliation Identification Task";
    }

    private void upgrade() {
      if (shouldRunUpgrade()) {
        CmdbPatternID patternID = CmdbPatternIDFactory.createObjectID("ReconciliationDoubleHostsEnrichment");
        PatternElementNumber hostNCNumber = PatternElementNumberFactory.createElementNumber(1);

        createDoubleHostPattern(hostNCNumber);
        createDoubleHostEnrichment(patternID, hostNCNumber);
        try
        {
          EnrichmentCommandAdHocCalculator runEnrichment = new EnrichmentCommandAdHocCalculator("ReconciliationDoubleHostsEnrichment");
          executeOperation(runEnrichment);
        }
        finally {
          removeEnrichment();
          removeDoubleHostPattern(patternID);
        }

        updateShouldRunUpgradeParam();
      }
    }

    private boolean shouldRunUpgrade() {
      if ((Environment.TEST_MODE) || (!(getLocalSettings().getBoolean("reconciliation.should.run.upgrade", true)))) {
        return false;
      }

      return (getSynchronizedClassModel().getClass("host") != null);
    }

    private void updateShouldRunUpgradeParam() {
      setParamValue();
    }

    private void createDoubleHostEnrichment(CmdbPatternID patternID, PatternElementNumber hostNCNumber)
    {
      EnrichmentMutableActions enrichmentActions = EnrichmentActionFactory.createEnrichmentMutableActions();
      EnrichmentParam enrichmentParam = EnrichmentParamFactory.create(CmdbConstants.Enrichment.Action.REMOVE, hostNCNumber, "host", null);
      EnrichmentObject enrichmentObject = EnrichmentObjectFactory.create(enrichmentParam);
      enrichmentActions.add(enrichmentObject);
      EnrichmentDefinition def = EnrichmentDefinitionFactory.create("ReconciliationDoubleHostsEnrichment", patternID, false, enrichmentActions);
      EnrichmentUpdateAddEnrichmentDefinition addEnrich = new EnrichmentUpdateAddEnrichmentDefinition(def);
      executeOperation(addEnrich);
    }

    private void createDoubleHostPattern(PatternElementNumber hostNCNumber) {
      PatternElementNumber hostCNumber = PatternElementNumberFactory.createElementNumber(2);
      PatternElementNumber ipNumber = PatternElementNumberFactory.createElementNumber(3);
      PatternElementNumber hostClinkNumber = PatternElementNumberFactory.createElementNumber(4);
      PatternElementNumber hostNClinkNumber = PatternElementNumberFactory.createElementNumber(5);

      ModifiableNodeLinksCondition hostCNodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
      hostCNodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(hostClinkNumber.getNumber(), 1, -1));
      ModifiableNodeLinksCondition hostNCNodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
      hostNCNodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(hostNClinkNumber.getNumber(), 1, -1));
      ModifiableNodeLinksCondition ipNodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
      ipNodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(hostClinkNumber.getNumber(), 1, -1));
      ipNodeLinksCondition.addLogicalOperator(LogicalOperator.AND);
      ipNodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(hostNClinkNumber.getNumber(), 1, -1));

      ElementClassCondition hostClassCondition = PatternConditionFactory.createElementClassCondition("host", true);

      ModifiableElementPropertiesCondition hostCPropsCondition = PatternConditionFactory.createElementPropertiesCondition();
      hostCPropsCondition.addPropertyCondition(PatternConditionFactory.createPropertyCondition("host_iscomplete", ConditionOperator.EQUEL, Boolean.valueOf(true), false));
      ElementCondition hostCElementCondition = PatternConditionFactory.createElementCondition(hostClassCondition, hostCPropsCondition);

      ModifiableElementPropertiesCondition hostNCPropsCondition = PatternConditionFactory.createElementPropertiesCondition();
      hostNCPropsCondition.addPropertyCondition(PatternConditionFactory.createPropertyCondition("host_iscomplete", ConditionOperator.EQUEL, Boolean.valueOf(false), false));
      hostNCPropsCondition.addLogicalOperator(LogicalOperator.OR);
      hostNCPropsCondition.addPropertyCondition(PatternConditionFactory.createPropertyCondition("host_iscomplete", ConditionOperator.IS_NULL, null, false));
      ElementCondition hostNCElementCondition = PatternConditionFactory.createElementCondition(hostClassCondition, hostNCPropsCondition);

      ElementCondition ipElementCondition = PatternConditionFactory.createElementCondition("ip", true);
      ElementCondition hostCLinkElementCondition = PatternConditionFactory.createElementCondition("contained", true);
      ElementCondition hostNCLinkElementCondition = PatternConditionFactory.createElementCondition("contained", true);

      PatternNode hostCPatternNode = PatternGraphFactory.createPatternNode(hostCNumber, hostCElementCondition, true, hostCNodeLinksCondition);
      PatternNode hostNCPatternNode = PatternGraphFactory.createPatternNode(hostNCNumber, hostNCElementCondition, true, hostNCNodeLinksCondition);
      PatternNode ipPatternNode = PatternGraphFactory.createPatternNode(ipNumber, ipElementCondition, true, ipNodeLinksCondition);
      PatternLink hostCPatternLink = PatternGraphFactory.createPatternLink(hostClinkNumber, hostCNumber, ipNumber, hostCLinkElementCondition, true);
      PatternLink hostNCPatternLink = PatternGraphFactory.createPatternLink(hostNClinkNumber, hostNCNumber, ipNumber, hostNCLinkElementCondition, true);
      ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
      patternGraph.addNode(hostCPatternNode);
      patternGraph.addNode(hostNCPatternNode);
      patternGraph.addNode(ipPatternNode);
      patternGraph.addLink(hostCPatternLink);
      patternGraph.addLink(hostNCPatternLink);
      ModifiablePattern pattern = PatternDefinitionFactory.createPattern("ReconciliationDoubleHostsEnrichment", PatternGroupId.PATTERN_GROUP_SERVERDATA, patternGraph);
      pattern.setState(PatternDefinitionFactory.createPatternState(false, false, PatternPriorityType.MED_PRIORITY, false));
      TqlUpdatePatternCreate createPattern = new TqlUpdatePatternCreate(pattern);
      executeOperation(createPattern);
    }

    private void removeDoubleHostPattern(CmdbPatternID patternID) {
      TqlUpdatePatternRemove remove = new TqlUpdatePatternRemove(patternID);
      executeOperation(remove);
    }

    private void removeEnrichment() {
      EnrichmentUpdateRemoveEnrichmentDefinition remove = new EnrichmentUpdateRemoveEnrichmentDefinition("ReconciliationDoubleHostsEnrichment");
      executeOperation(remove);
    }

    private void setParamValue() {
      SettingServiceAPI settingServiceAPI = SettingsFactory.create();
      try
      {
        settingServiceAPI.setVariablePerCustomer("cmdb", "reconciliation.should.run.upgrade", getCustomerID().getID(), "false");
      }
      catch (Throwable e) {
        CmdbLogFactory.getCMDBInfoLog().error("Couldn't update the value of reconciliation.should.run.upgrade: " + e);
      }
    }
  }
}