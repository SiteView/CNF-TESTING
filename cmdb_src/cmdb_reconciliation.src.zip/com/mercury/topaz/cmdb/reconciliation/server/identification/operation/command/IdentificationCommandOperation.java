package com.mercury.topaz.cmdb.reconciliation.server.identification.operation.command;

import com.mercury.topaz.cmdb.reconciliation.server.identification.manager.IdentificationManager;
import com.mercury.topaz.cmdb.reconciliation.server.identification.operation.IdentificationOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.command.CmdbCommand;

public abstract interface IdentificationCommandOperation
{
  public abstract void identificationCommandExecute(IdentificationManager paramIdentificationManager, CmdbResponse paramCmdbResponse);
}