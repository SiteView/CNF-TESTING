package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.impl.AbstractDataInOperation;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.query.DataInQueryOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractDataInQueryOperation extends AbstractDataInOperation
  implements DataInQueryOperation
{
  public String getExecutionTaskQueueName()
  {
    return "Reconciliation DataIn Query Task";
  }

  public void dataInExecute(DataInManager dataInManager, CmdbResponse response) throws CmdbException {
    dataInQueryExecute(dataInManager, response);
  }
}