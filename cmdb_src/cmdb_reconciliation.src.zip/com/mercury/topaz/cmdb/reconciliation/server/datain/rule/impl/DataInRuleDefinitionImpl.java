package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;
import java.util.Map;

class DataInRuleDefinitionImpl
  implements DataInRuleDefinition
{
  private Map<String, String> _configurationParams;

  public DataInRuleDefinitionImpl(Map<String, String> configurationParams)
  {
    setConfigurationParams(configurationParams);
  }

  public String getConfigurationParam(String key) {
    return ((String)getConfigurationParams().get(key));
  }

  public boolean containsParam(String key) {
    return getConfigurationParams().containsKey(key);
  }

  public Map<String, String> getConfigurationParams() {
    return this._configurationParams;
  }

  private void setConfigurationParams(Map<String, String> configurationParams) {
    this._configurationParams = configurationParams;
  }
}