package com.mercury.topaz.cmdb.reconciliation.server.config.definition;

import java.io.Serializable;
import java.util.Collection;

public abstract interface OwnersConfigDef extends Serializable
{
  public abstract Collection<OwnerConfigDef> getOwnersCollection();

  public abstract void setOwnersCollection(Collection<OwnerConfigDef> paramCollection);
}