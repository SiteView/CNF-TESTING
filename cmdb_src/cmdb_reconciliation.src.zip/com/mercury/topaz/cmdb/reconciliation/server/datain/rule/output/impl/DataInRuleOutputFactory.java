package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInRuleOutput;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelUpdate;
import java.util.List;
import java.util.Map;

public class DataInRuleOutputFactory
{
  public static DataInRuleOutput createDataInRuleOutput(Map<CmdbDataID, CmdbDataID> idChangesMap, List<ModelUpdate> modelUpdateOperations, CmdbDataIDs idsForTouch)
  {
    return new DataInRuleOutputImpl(idChangesMap, modelUpdateOperations, idsForTouch);
  }

  public static DataInRuleOutput createDataInRuleOutput(Map<CmdbDataID, CmdbDataID> idChangesMap, List<ModelUpdate> modelUpdateOperations) {
    return new DataInRuleOutputImpl(idChangesMap, modelUpdateOperations, null);
  }

  public static DataInRuleOutput createDataInRuleOutput(List<ModelUpdate> modelUpdateOperations) {
    return new DataInRuleOutputImpl(null, modelUpdateOperations, null);
  }

  public static DataInRuleOutput createDataInRuleOutput(List<ModelUpdate> modelUpdateOperations, CmdbDataIDs idsForTouch) {
    return new DataInRuleOutputImpl(null, modelUpdateOperations, idsForTouch);
  }

  public static DataInRuleOutput createDataInRuleOutput(CmdbDataIDs idsForTouch) {
    return new DataInRuleOutputImpl(null, null, idsForTouch);
  }
}