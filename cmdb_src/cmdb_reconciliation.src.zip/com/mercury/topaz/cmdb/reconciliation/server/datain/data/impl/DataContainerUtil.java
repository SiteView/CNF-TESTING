package com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.IndependentDataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ModelUtil;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DataContainerUtil
{
  public static List<IndependentDataContainer> splitDataContainerAndOrderTypes(Map<String, String> typeToRelevantSuperTypeMap, CmdbClassModel classModel, DataContainer dataContainer)
  {
    List dataContainers = split(classModel, dataContainer);

    for (Iterator i$ = dataContainers.iterator(); i$.hasNext(); ) { IndependentDataContainer currDataContainer = (IndependentDataContainer)i$.next();
      currDataContainer.orderTypes(typeToRelevantSuperTypeMap);
    }

    return dataContainers;
  }

  public static List<IndependentDataContainer> split(CmdbClassModel classModel, DataContainer dataContainer) {
    CmdbObject object;
    CmdbLink link;
    Integer end1DataContainerIndex;
    Integer end2DataContainerIndex;
    Map toStringIdToObjectIdMap = getToStringToObjectMap(dataContainer);
    List dataContainers = new ArrayList();
    dataContainers.add(IndependentDataContainerFactory.createDataContainer(dataContainers));
    Map objectIdToDattaContainerIndex = new HashMap(dataContainer.sizeOfDataForUpdate() + dataContainer.sizeOfReferencedData());

    CmdbObjects objectsForUpdate = CmdbObjectFactory.createHashMapObjects();
    objectsForUpdate.add(((DataContainerImpl)dataContainer).getObjectsForUpdate());
    CmdbObjects objectsForReference = CmdbObjectFactory.createHashMapObjects();
    objectsForReference.add(((DataContainerImpl)dataContainer).getReferencedObjects());

    while (!(objectsForUpdate.isEmpty())) {
      object = (CmdbObject)objectsForUpdate.iterator().next();
      put(object, dataContainers, objectIdToDattaContainerIndex, toStringIdToObjectIdMap, classModel, objectsForUpdate, objectsForReference);
    }

    while (!(objectsForReference.isEmpty())) {
      object = (CmdbObject)objectsForReference.iterator().next();
      put(object, dataContainers, objectIdToDattaContainerIndex, toStringIdToObjectIdMap, classModel, objectsForUpdate, objectsForReference);
    }

    for (Iterator i$ = ((DataContainerImpl)dataContainer).getLinksForUpdate().iterator(); i$.hasNext(); ) { link = (CmdbLink)i$.next();
      end1DataContainerIndex = getDataContainerIndex(objectIdToDattaContainerIndex, link.getEnd1());
      end2DataContainerIndex = getDataContainerIndex(objectIdToDattaContainerIndex, link.getEnd2());
      ((IndependentDataContainer)dataContainers.get(Math.max(end1DataContainerIndex.intValue(), end2DataContainerIndex.intValue()))).addLinkForUpdate(link);
    }

    for (i$ = ((DataContainerImpl)dataContainer).getReferencedLinks().iterator(); i$.hasNext(); ) { link = (CmdbLink)i$.next();
      end1DataContainerIndex = getDataContainerIndex(objectIdToDattaContainerIndex, link.getEnd1());
      end2DataContainerIndex = getDataContainerIndex(objectIdToDattaContainerIndex, link.getEnd2());
      ((IndependentDataContainer)dataContainers.get(Math.max(end1DataContainerIndex.intValue(), end2DataContainerIndex.intValue()))).addReferencedLink(link);
    }
    return dataContainers;
  }

  private static Integer getDataContainerIndex(Map<CmdbObjectID, Integer> objectIdToDattaContainerIndex, CmdbObjectID id) {
    Integer index = (Integer)objectIdToDattaContainerIndex.get(id);
    return Integer.valueOf((null == index) ? 0 : index.intValue());
  }

  private static int put(CmdbObject object, List<IndependentDataContainer> dataContainers, Map<CmdbObjectID, Integer> objectIdToDataContainerIndex, Map<String, CmdbObject> toStringIdToObjectIdMap, CmdbClassModel classModel, CmdbObjects objectsForUpdate, CmdbObjects objectsForReference) {
    Collection containedByObjects = ModelUtil.getContainedByObjects(object, classModel, toStringIdToObjectIdMap);
    int dataContainerIndex = 0;

    for (Iterator i$ = containedByObjects.iterator(); i$.hasNext(); ) { CmdbObject containedByObject = (CmdbObject)i$.next();
      Integer dataContainerIndexOfContainsObject = (Integer)objectIdToDataContainerIndex.get(containedByObject.getID());
      if (null == dataContainerIndexOfContainsObject)
        dataContainerIndexOfContainsObject = Integer.valueOf(put(containedByObject, dataContainers, objectIdToDataContainerIndex, toStringIdToObjectIdMap, classModel, objectsForUpdate, objectsForReference));

      dataContainerIndex = Math.max(dataContainerIndexOfContainsObject.intValue() + 1, dataContainerIndex);
    }

    CmdbObjectID objectID = (CmdbObjectID)object.getID();
    objectIdToDataContainerIndex.put(objectID, Integer.valueOf(dataContainerIndex));
    if (dataContainers.size() == dataContainerIndex)
      dataContainers.add(IndependentDataContainerFactory.createDataContainer(dataContainers));

    DataContainer dataContainer = (DataContainer)dataContainers.get(dataContainerIndex);
    if (objectsForUpdate.contains(objectID)) {
      dataContainer.addObjectForUpdate((CmdbObject)objectsForUpdate.get(objectID));
      objectsForUpdate.remove(objectID);
    }
    if (objectsForReference.contains(objectID)) {
      dataContainer.addReferencedObject((CmdbObject)objectsForReference.get(objectID));
      objectsForReference.remove(objectID);
    }
    return dataContainerIndex;
  }

  public static Map<String, CmdbObject> getToStringToObjectMap(DataContainer dataContainer) {
    return getToStringToObjectMap(dataContainer, new HashMap(dataContainer.sizeOfDataForUpdate() + dataContainer.sizeOfReferencedData()));
  }

  private static Map<String, CmdbObject> getToStringToObjectMap(DataContainer dataContainer, Map<String, CmdbObject> toStringIdToObjectIdMap) {
    CmdbObject object;
    for (Iterator i$ = ((DataContainerImpl)dataContainer).getObjectsForUpdate().iterator(); i$.hasNext(); ) { object = (CmdbObject)i$.next();
      toStringIdToObjectIdMap.put(((CmdbObjectID)object.getID()).toString(), object);
    }

    for (i$ = ((DataContainerImpl)dataContainer).getReferencedObjects().iterator(); i$.hasNext(); ) { object = (CmdbObject)i$.next();
      toStringIdToObjectIdMap.put(((CmdbObjectID)object.getID()).toString(), object);
    }
    return toStringIdToObjectIdMap;
  }

  public static Map<String, CmdbObject> getToStringToObjectMap(Iterable<? extends DataContainer> dataContainers) {
    int size = 0;
    for (Iterator i$ = dataContainers.iterator(); i$.hasNext(); ) { DataContainer dataContainer = (DataContainer)i$.next();
      size += dataContainer.sizeOfDataForUpdate() + dataContainer.sizeOfReferencedData();
    }
    Map toStringIdToObjectIdMap = new HashMap(size);
    for (Iterator i$ = dataContainers.iterator(); i$.hasNext(); ) { DataContainer dataContainer = (DataContainer)i$.next();
      getToStringToObjectMap(dataContainer, toStringIdToObjectIdMap);
    }
    return toStringIdToObjectIdMap;
  }

  public static void cleanDataContainer(IndependentDataContainer dataContainer, CmdbClassModel classModel, Map<CmdbObjectID, Collection<CmdbData>> objectsToRemoveByHostID) {
    List allDataContainers = dataContainer.getAllDataContainers();
    Map toStringToObjectMap = getToStringToObjectMap(allDataContainers);
    for (Iterator i$ = allDataContainers.iterator(); i$.hasNext(); ) { IndependentDataContainer currentDataContainer = (IndependentDataContainer)i$.next();
      currentDataContainer.clean(classModel, objectsToRemoveByHostID, toStringToObjectMap);
    }
  }
}