package com.mercury.topaz.cmdb.reconciliation.server.identification.manager;

import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public abstract interface IdentificationManager extends CmdbSubsystemManager
{
}