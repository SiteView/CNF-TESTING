package com.mercury.topaz.cmdb.reconciliation.server.config.definition;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.IdentificationConfiguration;
import java.io.Serializable;

public abstract interface ReconciliationConfigDef extends Serializable
{
  public abstract DataChangeConfigDef getDataChangeConfigDef();

  public abstract IdentificationConfiguration getIdentificationConfigDef();

  public abstract String getType();

  public abstract String toXml();
}