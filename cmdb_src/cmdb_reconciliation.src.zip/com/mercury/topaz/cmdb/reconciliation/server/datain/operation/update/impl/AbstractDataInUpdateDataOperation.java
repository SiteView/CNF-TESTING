package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.change.CmdbIDChange;
import com.mercury.topaz.cmdb.reconciliation.server.change.impl.CmdbLinkIDChangeFactory;
import com.mercury.topaz.cmdb.reconciliation.server.change.impl.CmdbObjectIDChangeFactory;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl.ReconciliationConfigCacheQueryGetActualDataInConfiguredTypes;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl.ReconciliationConfigCacheQueryGetDataInRule;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl.ReconciliationConfigCacheQueryIsOwnerByType;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.IndependentDataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl.DataContainerUtil;
import com.mercury.topaz.cmdb.reconciliation.server.datain.exception.DataInException;
import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.query.impl.DataInQueryGetPreAnalyzeRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.DataInUpdateDataOperation;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInAnomalyInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInPreAnalyzeRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInPreAnalyzeRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.impl.DataInPreAnalyzeRuleInputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.impl.DataInRuleInputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInPreAnalyzeRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.environment.impl.ReconciliationEnvironmentFactory;
import com.mercury.topaz.cmdb.reconciliation.server.id.data.TempCmdbDataID;
import com.mercury.topaz.cmdb.reconciliation.server.identification.operation.query.impl.IdentificationQueryOptimizedGetExistingData;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl.InputIdToCmdbDatasMappingFactory;
import com.mercury.topaz.cmdb.reconciliation.server.utils.OldToNewIdMapping;
import com.mercury.topaz.cmdb.reconciliation.server.utils.PreReconciliationDataManipulation;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ReconciliationLogs;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.util.time.CmdbTime;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.change.impl.CmdbChangeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCommonOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.aging.operation.update.ModelUpdateMarkDataAsAccessed;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelExternalUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModelUpdateBulkInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModifiableModelUpdateBulkInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbUpdatedLinksInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.impl.CmdbModelUpdateBulkInfoFactory;
import com.mercury.topaz.cmdb.shared.notification.operation.command.impl.DeploymentCommandPublishChanges;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public abstract class AbstractDataInUpdateDataOperation extends AbstractDataInUpdateOperation
  implements DataInUpdateDataOperation
{
  public static final String INPUT_TO_RECONCILED_IDS_MAP = "inputToReconciledIDsMap";
  private static Log _reconciliationLogger = ReconciliationLogs.getReconciliationLog();
  private static Log _reconciliationAuditLogger = ReconciliationLogs.getReconciliationAuditLog();
  private DataContainer _dataContainer;
  private Map<CmdbDataID, CmdbDataIDs> _inputIDToReconciledIDsMap;
  private List<DataInInfo> _dataInInfoList;
  private List<DataInAnomalyInfo> _dataInAnomalytInfoList;
  private Map<CmdbDataID, CmdbDataID> _idChanges;
  private CmdbDataIDs _idsForTouch;
  private CmdbDataIDs _idsUpdatedByOwner;
  private long _identificationDuration;
  private long _dataInAnalysisDuration;
  private long _modelDuration;

  protected AbstractDataInUpdateDataOperation(DataContainer dataContainer, Changer changer)
  {
    super(changer);
    setDataContainer(dataContainer);
    setInputIDToReconciledIDsMap(new HashMap());
  }

  public void dataInUpdateExecute(DataInManager dataInManager, CmdbResponse response) throws CmdbException {
    InputIdToCmdbDatasMapping existingDataMap = null;
    setDataInAnomalytInfoList(new ArrayList());
    try
    {
      CmdbClassModel classModel = dataInManager.getSynchronizedClassModel();
      DataFactory dataFactory = DataFactoryCreator.create(classModel);

      OldToNewIdMapping idMapping = new OldToNewIdMapping();
      setDataContainer(PreReconciliationDataManipulation.manipulate(getDataContainer(), dataFactory, idMapping));

      Map inputIDAsStringToReconciledIDs = new HashMap();
      existingDataMap = InputIdToCmdbDatasMappingFactory.create(10);

      ReconciliationEnvironment rulesEnv = ReconciliationEnvironmentFactory.createReconciliationRuleEnvironment(dataFactory, classModel);

      long identificationStartTime = CmdbTime.currentTimeMillis();
      if (getDataContainer().sizeOfDataForUpdate() + getDataContainer().sizeOfReferencedData() > 0)
      {
        IdentificationQueryOptimizedGetExistingData getExisting = new IdentificationQueryOptimizedGetExistingData(getDataContainer(), getChanger().getDataStoreOrigin(), existingDataMap, shouldAddLinkEnds());
        ServerApiFacade.executeOperation(getExisting);
      }

      this._identificationDuration = (CmdbTime.currentTimeMillis() - identificationStartTime);

      Map typeToRelevantSuperType = getTypeToRelevantSuperTypeMap(getDataContainer());
      List dataContainers = DataContainerUtil.splitDataContainerAndOrderTypes(typeToRelevantSuperType, classModel, getDataContainer());

      Set isOwnerByType = createIsOwnerByType(typeToRelevantSuperType.keySet(), existingDataMap);

      runPreAnalyzeRules(dataInManager, rulesEnv, dataContainers, existingDataMap);

      long dataInAnalysisStartTime = CmdbTime.currentTimeMillis();
      for (Iterator i$ = dataContainers.iterator(); i$.hasNext(); ) { IndependentDataContainer dataContainer = (IndependentDataContainer)i$.next();
        if (dataContainer.sizeOfDataForUpdate() + dataContainer.sizeOfReferencedData() > 0)
        {
          analyzeData(rulesEnv, dataContainer, existingDataMap, inputIDAsStringToReconciledIDs, isOwnerByType);
        }
      }
      this._dataInAnalysisDuration = (CmdbTime.currentTimeMillis() - dataInAnalysisStartTime);

      long modelStartTime = CmdbTime.currentTimeMillis();
      CmdbModelUpdateBulkInfo tempBulkInfo = prepareAndSendToModelUpdate(dataInManager);
      this._modelDuration = (CmdbTime.currentTimeMillis() - modelStartTime);

      warnAboutIgnoredLinks(tempBulkInfo, existingDataMap);
      CmdbModelUpdateBulkInfo bulkInfo = DataInUtil.filterBulkStatistics(getDataContainer(), tempBulkInfo, getInputIDToReconciledIDsMap());
      setBulkInfo(bulkInfo);

      fixInputToReconciledMap(idMapping);

      sendNotifications(dataInManager);
    }
    catch (Throwable e) {
      StringBuilder desc = new StringBuilder("!!! FAIL at ").append(getDetailedMessage(existingDataMap));

      throw new DataInException("Error occured while trying to execute operation " + getOperationName(), e);
    }
    finally
    {
      printAnomalies();
    }

    if (_reconciliationLogger.isDebugEnabled()) {
      StringBuilder msg = getDetailedMessage(existingDataMap);
      _reconciliationLogger.debug(msg.toString().replaceAll("\n", "\n\t"));
    }

    response.addResult("inputToReconciledIDsMap", (Serializable)getInputIDToReconciledIDsMap());
  }

  private void fixInputToReconciledMap(OldToNewIdMapping idMapping) {
    Map.Entry entry;
    Map dataIDsMap = getInputIDToReconciledIDsMap();
    Map newDataIdsMap = new HashMap(dataIDsMap.size());

    for (Iterator i$ = dataIDsMap.entrySet().iterator(); i$.hasNext(); ) { entry = (Map.Entry)i$.next();
      CmdbDataID id = (CmdbDataID)entry.getKey();
      if (id.isObjectID()) {
        CmdbObjectID oldId = idMapping.getOldId((CmdbObjectID)id);
        newDataIdsMap.put(oldId, entry.getValue());
      } else {
        newDataIdsMap.put(id, entry.getValue());
      }
    }

    for (i$ = idMapping.iterator(); i$.hasNext(); ) { entry = (Map.Entry)i$.next();
      CmdbObjectID oldId = (CmdbObjectID)entry.getKey();
      CmdbObjectID newId = (CmdbObjectID)entry.getValue();
      CmdbDataIDs ids = CmdbDataIdsFactory.create(1);
      ids.add(newId);
      newDataIdsMap.put(oldId, ids);
    }
    setInputIDToReconciledIDsMap(newDataIdsMap);
  }

  private Set<String> createIsOwnerByType(Collection<String> inputTypes, InputIdToCmdbDatasMapping existingDataMap) {
    Set allTypes = new HashSet(inputTypes.size() + existingDataMap.size());
    allTypes.addAll(inputTypes);
    for (Iterator i$ = existingDataMap.iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      for (Iterator i$ = ((Collection)entry.getValue()).iterator(); i$.hasNext(); ) { CmdbData data = (CmdbData)i$.next();
        allTypes.add(data.getType());
      }
    }
    ReconciliationConfigCacheQueryIsOwnerByType isOwnerOperation = new ReconciliationConfigCacheQueryIsOwnerByType(getChanger().getDataStoreOrigin(), allTypes);
    ServerApiFacade.executeOperation(isOwnerOperation);
    return isOwnerOperation.getIsOwnerByTypeMap();
  }

  private Map<String, String> getTypeToRelevantSuperTypeMap(DataContainer dataContainer) {
    ReconciliationConfigCacheQueryGetActualDataInConfiguredTypes getActualConfiguredTypes = new ReconciliationConfigCacheQueryGetActualDataInConfiguredTypes(dataContainer.getAllTypes());
    ServerApiFacade.executeOperation(getActualConfiguredTypes);
    return getActualConfiguredTypes.getTypesMap();
  }

  private void printAnomalies() {
    if ((getDataInAnomalytInfoList() != null) && (!(getDataInAnomalytInfoList().isEmpty())) && (ReconciliationLogs.getReconciliationAnomaliesLog().isInfoEnabled())) {
      StringBuilder msg = new StringBuilder();
      msg.append("The following anomalies were found: ");
      for (Iterator i$ = getDataInAnomalytInfoList().iterator(); i$.hasNext(); ) { DataInInfo info = (DataInAnomalyInfo)i$.next();
        msg.append("\n").append(info.getShortMessage());
      }
      ReconciliationLogs.getReconciliationAnomaliesLog().info(msg);
    }
  }

  protected abstract boolean shouldAddLinkEnds();

  private void runPreAnalyzeRules(OperationExecutor operationExecutor, ReconciliationEnvironment rulesEnv, List<IndependentDataContainer> dataContainers, InputIdToCmdbDatasMapping existingDataMap)
  {
    Collection analyzeRules = getPreAnalyzeRules(dataContainers, operationExecutor);

    DataInPreAnalyzeRuleInput dataInPreAnalyzeRuleInput = DataInPreAnalyzeRuleInputFactory.createDataInPreAnalyzeRuleInput(dataContainers, existingDataMap, getDataInAnomalytInfoList());

    CmdbObjectIds idsToRemove = CmdbObjectIdsFactory.createIdsList();

    for (Iterator i$ = analyzeRules.iterator(); i$.hasNext(); ) { DataInPreAnalyzeRule rule = (DataInPreAnalyzeRule)i$.next();
      DataInPreAnalyzeRuleOutput ruleOutput = rule.preAnalyze(rulesEnv, dataInPreAnalyzeRuleInput);
      idsToRemove.add(ruleOutput.getObjectsToRemove());
    }

    if (!(idsToRemove.isEmpty())) {
      List modelUpdateOperationsForPreAnalyzeRules = createModelUpdateOperations(idsToRemove);
      addToModelUpdateOperations(modelUpdateOperationsForPreAnalyzeRules);
    }
  }

  protected abstract List<? extends ModelUpdate> createModelUpdateOperations(CmdbObjectIds paramCmdbObjectIds);

  private Collection<DataInPreAnalyzeRule> getPreAnalyzeRules(List<IndependentDataContainer> dataContainers, OperationExecutor operationExecutor) {
    Collection types = new LinkedList();
    for (Iterator i$ = dataContainers.iterator(); i$.hasNext(); ) { DataContainer dataContainer = (IndependentDataContainer)i$.next();
      addToCollectionOfKeys(types, dataContainer.getObjectsForUpdateIteratorByType());
      addToCollectionOfKeys(types, dataContainer.getReferencedObjectsIteratorByType());
      addToCollectionOfKeys(types, dataContainer.getLinksForUpdateIteratorByType());
      addToCollectionOfKeys(types, dataContainer.getReferencedLinksIteratorByType());
    }
    DataInQueryGetPreAnalyzeRule getPreAnalyzeRule = new DataInQueryGetPreAnalyzeRule(types);
    operationExecutor.executeOperation(getPreAnalyzeRule);
    return getPreAnalyzeRule.getDataInRules();
  }

  private <Type> void addToCollectionOfKeys(Collection<String> types, Iterator<Map.Entry<String, Type>> iter) {
    while (iter.hasNext())
      types.add(((Map.Entry)iter.next()).getKey());
  }

  private void warnAboutIgnoredLinks(CmdbModelUpdateBulkInfo tempBulkInfo, InputIdToCmdbDatasMapping existingDataMap)
  {
    if (_reconciliationLogger.isWarnEnabled()) {
      boolean hasIgnored = false;
      ReadOnlyIterator info = tempBulkInfo.getLinksInfo();
      StringBuilder invalidLinksMessage = new StringBuilder("links ignored: ");
      while (info.hasNext()) {
        CmdbUpdatedLinksInfo updatedLinksInfo = (CmdbUpdatedLinksInfo)info.next();

        StringBuilder tempMsg = new StringBuilder();
        Iterable invalidLinks = updatedLinksInfo.invalidIDsIterator();
        for (Iterator i$ = invalidLinks.iterator(); i$.hasNext(); ) { CmdbDataID linkId = (CmdbDataID)i$.next();
          hasIgnored = true;
          tempMsg.append(linkId).append(", ");
        }

        if (tempMsg.length() > 0)
          invalidLinksMessage.append("\ntype=<").append(updatedLinksInfo.getClassName()).append(">{").append(tempMsg).append("}");

      }

      if (hasIgnored) {
        invalidLinksMessage.append(getDetailedMessage(existingDataMap));
        _reconciliationLogger.warn(invalidLinksMessage);
      }
    }
  }

  private CmdbModelUpdateBulkInfo prepareAndSendToModelUpdate(DataInManager dataInManager)
  {
    touch(dataInManager);

    if (getModelUpdateOperation() != null) {
      getModelUpdateOperation().setUserOperation(isUserOperation());
      if ((getIdsUpdatedByOwner() != null) && (!(getIdsUpdatedByOwner().isEmpty())))
      {
        getModelUpdateOperation().setIsUpdatedByOwnerCmdbIds(getIdsUpdatedByOwner());
      }
      return sendToModelUpdate(dataInManager);
    }
    return CmdbModelUpdateBulkInfoFactory.create().getCmdbModelUpdateBulkInfo();
  }

  private void touch(DataInManager dataInManager)
  {
    if ((getIdsForTouch() != null) && (!(getIdsForTouch().isEmpty()))) {
      ModelUpdateMarkDataAsAccessed touch = new ModelUpdateMarkDataAsAccessed(getIdsForTouch(), getChanger());
      dataInManager.executeOperation(touch);
    }
  }

  protected abstract ModelExternalUpdate getModelUpdateOperation();

  public void updateWithResponse(CmdbResponse response) {
    super.updateWithResponse(response);

    setInputIDToReconciledIDsMap((Map)response.getResult("inputToReconciledIDsMap"));
  }

  private void analyzeData(ReconciliationEnvironment env, DataContainer dataContainer, InputIdToCmdbDatasMapping existingDataMap, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs, Set<String> isOwnerByType)
  {
    List infoList = new ArrayList();
    List infoAnomalyList = new ArrayList();

    addReferenceDataToInputIDToReconciledIDsMap(env.getDataFactory(), dataContainer, existingDataMap, inputIDAsStringToReconciledIDs, infoList);

    Iterator it = dataContainer.getObjectsForUpdateIteratorByType();
    runDataInRuleForDatas(env, dataContainer, it, infoList, infoAnomalyList, existingDataMap, inputIDAsStringToReconciledIDs, isOwnerByType);

    it = dataContainer.getLinksForUpdateIteratorByType();
    runDataInRuleForDatas(env, dataContainer, it, infoList, infoAnomalyList, existingDataMap, inputIDAsStringToReconciledIDs, isOwnerByType);

    addDataInInfoList(infoList, infoAnomalyList);
  }

  private void runDataInRuleForDatas(ReconciliationEnvironment env, DataContainer dataContainer, Iterator<? extends Map.Entry<String, ? extends CmdbDatas>> it, List<DataInInfo> infoList, List<DataInAnomalyInfo> infoAnomalyList, InputIdToCmdbDatasMapping existingDataMap, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs, Set<String> isOwnerByType) {
    while (it.hasNext()) {
      Map.Entry entry = (Map.Entry)it.next();
      String type = (String)entry.getKey();
      DataInRuleInput input = DataInRuleInputFactory.createDataInRuleInput(getChanger(), type, dataContainer, existingDataMap, inputIDAsStringToReconciledIDs, getInputIDToReconciledIDsMap(), infoList, infoAnomalyList, isOwnerByType, getIdChanges());
      DataInRuleOutput dataInRuleOutput = runDataInRule(getDataInRule(type), env, input);
      addDataInOutput(dataInRuleOutput);
      addIDsUpdatedByOwner(isOwnerByType, (CmdbDatas)entry.getValue());
    }
  }

  protected void addIDsUpdatedByOwner(Set<String> isOwnerSet, CmdbDatas datasForUpdate) {
    CmdbDataIDs idsUpdatedByOwner = CmdbDataIdsFactory.create();
    for (Iterator i$ = datasForUpdate.iterator(); i$.hasNext(); ) { Object dataForUpdateBeforeCast = i$.next();
      CmdbData dataForUpdate = (CmdbData)dataForUpdateBeforeCast;
      if (isOwnerSet.contains(dataForUpdate.getType())) {
        CmdbDataID currentDataID = dataForUpdate.getDataID();
        if (getInputIDToReconciledIDsMap().containsKey(currentDataID)) {
          idsUpdatedByOwner.addAll((CmdbDataIDs)getInputIDToReconciledIDsMap().get(currentDataID));
        }
        else if (!(currentDataID instanceof TempCmdbDataID))
          idsUpdatedByOwner.add(currentDataID);
      }

    }

    addIDsUpdatedByOwner(idsUpdatedByOwner);
  }

  private void addIDsUpdatedByOwner(CmdbDataIDs idsUpdatedByOwner) {
    if ((idsUpdatedByOwner == null) || (idsUpdatedByOwner.isEmpty()))
      return;

    if ((getIdsUpdatedByOwner() == null) || (getIdsUpdatedByOwner().isEmpty())) {
      setIdsUpdatedByOwner(idsUpdatedByOwner);
    }
    else
      getIdsUpdatedByOwner().addAll(idsUpdatedByOwner);
  }

  private void addDataInOutput(DataInRuleOutput dataInRuleOutput)
  {
    addToModelUpdateOperations(dataInRuleOutput.getModelUpdateOperations());
    addIDChanges(dataInRuleOutput.getIDChangesMap());
    addIdsForTouch(dataInRuleOutput.getIDsForTouch());
  }

  private void addIDChanges(Map<CmdbDataID, CmdbDataID> idChanges) {
    if ((idChanges == null) || (idChanges.isEmpty())) {
      return;
    }

    if ((getIdChanges() == null) || (getIdChanges().isEmpty())) {
      setIdChanges(idChanges);
    }
    else
      getIdChanges().putAll(idChanges);
  }

  private void addDataInInfoList(List<DataInInfo> dataInInfoList, List<DataInAnomalyInfo> dataInAnomalyInfoList)
  {
    if ((dataInInfoList != null) && (!(dataInInfoList.isEmpty())))
      if ((getDataInInfoList() == null) || (getDataInInfoList().isEmpty())) {
        setDataInInfoList(dataInInfoList);
      }
      else
        getDataInInfoList().addAll(dataInInfoList);


    if ((dataInAnomalyInfoList != null) && (!(dataInAnomalyInfoList.isEmpty())))
      if ((getDataInAnomalytInfoList() == null) || (getDataInAnomalytInfoList().isEmpty())) {
        setDataInAnomalytInfoList(dataInAnomalyInfoList);
      }
      else
        getDataInAnomalytInfoList().addAll(dataInAnomalyInfoList);
  }

  private void addIdsForTouch(CmdbDataIDs ids)
  {
    if ((ids == null) || (ids.isEmpty())) {
      return;
    }

    if ((getIdsForTouch() == null) || (getIdsForTouch().isEmpty())) {
      setIdsForTouch(ids);
    }
    else
      getIdsForTouch().addAll(ids);
  }

  private DataInRule getDataInRule(String classType)
  {
    ReconciliationConfigCacheQueryGetDataInRule getRule = new ReconciliationConfigCacheQueryGetDataInRule(classType);
    ServerApiFacade.executeOperation(getRule);
    return getRule.getDataInRule();
  }

  private void addReferenceDataToInputIDToReconciledIDsMap(DataFactory dataFactory, DataContainer dataContainer, InputIdToCmdbDatasMapping existingDataMap, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDs, List<DataInInfo> infoList)
  {
    Iterator refObjectsIt = dataContainer.getReferencedObjectsIterator();
    while (refObjectsIt.hasNext()) {
      CmdbObject currentObj = (CmdbObject)refObjectsIt.next();
      if ((existingDataMap.containsKeyWithNotEmptyValue((CmdbDataID)currentObj.getID())) || (existingDataMap.containsKeyWithNotEmptyValueInBulk((CmdbDataID)currentObj.getID())))
      {
        Iterator i$;
        CmdbObject anExistingData;
        Collection existingData = existingDataMap.get((CmdbDataID)currentObj.getID());

        Collection existingDataInBulk = existingDataMap.getInBulk((CmdbDataID)currentObj.getID());
        CmdbDataIDs existingObjectIds = CmdbDataIdsFactory.create();
        if ((existingData != null) && (!(existingData.isEmpty())))
          for (i$ = existingData.iterator(); i$.hasNext(); ) { anExistingData = (CmdbObject)i$.next();
            existingObjectIds.add((CmdbDataID)anExistingData.getID());
          }

        if ((existingDataInBulk != null) && (!(existingDataInBulk.isEmpty())))
          for (i$ = existingDataInBulk.iterator(); i$.hasNext(); ) { anExistingData = (CmdbObject)i$.next();
            existingObjectIds.add((CmdbDataID)anExistingData.getID());
          }

        if ((existingObjectIds.size() != 1) || (!(((CmdbDataID)existingObjectIds.getIdsIterator().next()).equals(currentObj.getDataID()))))
          inputIDAsStringToReconciledIDs.put(((CmdbObjectID)currentObj.getID()).toString(), existingObjectIds);

      }
      else
      {
        DataInUtil.resolveCmdbData(dataFactory, currentObj, inputIDAsStringToReconciledIDs, null, infoList);
      }

    }

    Iterator refLinksIt = dataContainer.getReferencedLinksIterator();
    while (refLinksIt.hasNext()) {
      CmdbLink currentLink = (CmdbLink)refLinksIt.next();
      if ((existingDataMap.containsKeyWithNotEmptyValue((CmdbDataID)currentLink.getID())) || (existingDataMap.containsKeyWithNotEmptyValueInBulk((CmdbDataID)currentLink.getID())))
      {
        Iterator i$;
        CmdbLink anExisitngData;
        Collection existingData = existingDataMap.get((CmdbDataID)currentLink.getID());

        Collection existingDataInBulk = existingDataMap.getInBulk((CmdbDataID)currentLink.getID());
        CmdbDataIDs existingLinkIds = CmdbDataIdsFactory.create();
        if ((existingData != null) && (!(existingData.isEmpty())))
          for (i$ = existingData.iterator(); i$.hasNext(); ) { anExisitngData = (CmdbLink)i$.next();
            existingLinkIds.add((CmdbDataID)anExisitngData.getID());
          }

        if ((existingDataInBulk != null) && (!(existingDataInBulk.isEmpty())))
          for (i$ = existingDataInBulk.iterator(); i$.hasNext(); ) { anExisitngData = (CmdbLink)i$.next();
            existingLinkIds.add((CmdbDataID)anExisitngData.getID());
          }

        if ((existingLinkIds.size() != 1) || (!(((CmdbDataID)existingLinkIds.getIdsIterator().next()).equals(currentLink.getDataID()))))
          inputIDAsStringToReconciledIDs.put(((CmdbLinkID)currentLink.getID()).toString(), existingLinkIds);
      }
      else
      {
        DataInUtil.resolveCmdbData(dataFactory, currentLink, inputIDAsStringToReconciledIDs, null, infoList);
      }
    }
  }

  private StringBuilder getDetailedMessage(InputIdToCmdbDatasMapping existingDataMap) {
    StringBuilder desc = new StringBuilder(getShortAuditMessage());
    desc.append("\n").append(getDataContainer()).append("\n");
    if (null != existingDataMap)
      desc.append("existing map:\n").append(existingDataMap);

    if (getDataInInfoList() != null)
      for (Iterator i$ = getDataInInfoList().iterator(); i$.hasNext(); ) { DataInInfo dataInInfo = (DataInInfo)i$.next();
        desc.append("\n").append(dataInInfo.getShortMessage());
      }

    return desc;
  }

  private StringBuilder getOperationNameStringBuilder(String prefix) {
    StringBuilder desc = new StringBuilder(prefix);
    desc.append("[Operation Name=").append(getOperationName()).append("] ");
    return desc;
  }

  private void sendNotifications(DataInManager dataInManager) {
    if ((getIdChanges() != null) && (!(getIdChanges().isEmpty()))) {
      CmdbChanges changes = CmdbChangeFactory.createCmdbChanges(getChanger());
      Iterator it = getIdChanges().entrySet().iterator();

      while (it.hasNext()) {
        CmdbIDChange idChange;
        Map.Entry currentEntry = (Map.Entry)it.next();
        if (((CmdbDataID)currentEntry.getKey()).isObjectID()) {
          idChange = CmdbObjectIDChangeFactory.createObjectIDChange((CmdbObjectID)currentEntry.getKey(), (CmdbObjectID)currentEntry.getValue());
        }
        else
          idChange = CmdbLinkIDChangeFactory.createLinkIDChange((CmdbLinkID)currentEntry.getKey(), (CmdbLinkID)currentEntry.getValue());

        changes.add(idChange);
      }
      if (!(changes.isEmpty())) {
        DeploymentCommandPublishChanges publishChanges = new DeploymentCommandPublishChanges(FrameworkConstants.Subsystem.RECONCILIATION, changes);
        dataInManager.executeAsynchronousOperation(publishChanges);

        if (ReconciliationLogs.getReconciliationNotificationLog().isInfoEnabled())
          ReconciliationLogs.getReconciliationNotificationLog().info(changes);
      }
    }
  }

  protected abstract DataInRuleOutput runDataInRule(DataInRule paramDataInRule, ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput);

  protected abstract void addToModelUpdateOperations(List<? extends ModelUpdate> paramList);

  protected Log getshortAuditLogger() {
    return _reconciliationAuditLogger;
  }

  private void appendInfoToMsg(StringBuilder msg, Iterator<? extends Map.Entry<String, ? extends CmdbDatas>> it) {
    while (it.hasNext()) {
      Map.Entry entry = (Map.Entry)it.next();
      String type = (String)entry.getKey();
      int size = ((CmdbDatas)entry.getValue()).size();
      msg.append(" ").append(type).append("(").append(size).append(")");
    }
  }

  public String getShortAuditMessage() {
    StringBuilder msg = getOperationNameStringBuilder("");
    msg.append("[Data Store=").append(getChanger().getDataStoreOrigin()).append("] [Objects For Update -");
    Iterator it = getDataContainer().getObjectsForUpdateIteratorByType();
    appendInfoToMsg(msg, it);
    msg.append("] [Links For Update -");
    it = getDataContainer().getLinksForUpdateIteratorByType();
    appendInfoToMsg(msg, it);
    msg.append("]");
    if (getModelUpdateOperation() != null) {
      msg.append(" [Model Update ID: ").append(((AbstractCommonOperation)getModelUpdateOperation()).getID()).append("]");
    }
    else
      msg.append(" [Wasn't sent to model update]");

    msg.append(" [identification duration=").append(this._identificationDuration);
    msg.append("] [dataIn analysis duration=").append(this._dataInAnalysisDuration);
    msg.append("] [model update duration=").append(this._modelDuration).append("] ");
    return msg.toString();
  }

  protected DataContainer getDataContainer() {
    return this._dataContainer;
  }

  private void setDataContainer(DataContainer dataContainer) {
    if (dataContainer == null)
      throw new IllegalArgumentException("data container is null");

    this._dataContainer = dataContainer;
  }

  public Map<CmdbDataID, CmdbDataIDs> getInputIDToReconciledIDsMap()
  {
    return this._inputIDToReconciledIDsMap;
  }

  private void setInputIDToReconciledIDsMap(Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap) {
    this._inputIDToReconciledIDsMap = inputIDToReconciledIDsMap;
  }

  public List<DataInInfo> getDataInInfoList() {
    return this._dataInInfoList;
  }

  private void setDataInInfoList(List<DataInInfo> dataInInfoList) {
    this._dataInInfoList = dataInInfoList;
  }

  private Map<CmdbDataID, CmdbDataID> getIdChanges() {
    return this._idChanges;
  }

  private void setIdChanges(Map<CmdbDataID, CmdbDataID> idChanges) {
    this._idChanges = idChanges;
  }

  protected CmdbDataIDs getIdsForTouch() {
    return this._idsForTouch;
  }

  private void setIdsForTouch(CmdbDataIDs idsForTouch) {
    this._idsForTouch = idsForTouch;
  }

  private CmdbDataIDs getIdsUpdatedByOwner() {
    return this._idsUpdatedByOwner;
  }

  private void setIdsUpdatedByOwner(CmdbDataIDs idsUpdatedByOwner) {
    this._idsUpdatedByOwner = idsUpdatedByOwner;
  }

  private List<DataInAnomalyInfo> getDataInAnomalytInfoList() {
    return this._dataInAnomalytInfoList;
  }

  private void setDataInAnomalytInfoList(List<DataInAnomalyInfo> dataInAnomalytInfoList) {
    this._dataInAnomalytInfoList = dataInAnomalytInfoList;
  }
}