package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import java.util.Collection;
import java.util.Iterator;

public class DataInAnomalyInfo
  implements DataInInfo
{
  private CmdbData _inputData;
  private String _conflictAction;
  private Collection<? extends CmdbData> _resolvedDatas;
  private Collection<CmdbData> _affectedDatas;
  private String _additionalInfo;

  public DataInAnomalyInfo(CmdbData inputData, String conflictAction, Collection<? extends CmdbData> resolvedDatas, Collection<CmdbData> affectedDatas, String additionalInfo)
  {
    this._inputData = inputData;
    this._conflictAction = conflictAction;
    this._resolvedDatas = resolvedDatas;
    this._affectedDatas = affectedDatas;
    this._additionalInfo = additionalInfo;
  }

  private String getCIShortDesc(CmdbData data) {
    StringBuilder msg = new StringBuilder();
    msg.append(data.getType()).append(";").append(data.getID());
    CmdbProperty displayLabel = data.getProperty("display_label");
    if (displayLabel != null)
      msg.append(";").append(displayLabel.getValue());

    return msg.toString();
  }

  private String getDataIDsFromDatas(Collection<? extends CmdbData> datas) {
    StringBuilder msg = new StringBuilder();
    for (Iterator i$ = datas.iterator(); i$.hasNext(); ) { CmdbData currentData = (CmdbData)i$.next();
      msg.append(currentData.getID()).append(",");
    }
    if (msg.length() > 0)
      msg.deleteCharAt(msg.length() - 1);

    return msg.toString();
  }

  public String getShortMessage() {
    StringBuilder msg = new StringBuilder("[input data=");
    msg.append(getCIShortDesc(this._inputData)).append("] [mapped to ids=").append(getDataIDsFromDatas(this._resolvedDatas)).append("] [action=").append(this._conflictAction).append("]");

    if ((this._additionalInfo != null) && (this._additionalInfo.length() > 0))
      msg.append(" [").append(this._additionalInfo).append("]");

    if (this._affectedDatas != null) {
      for (Iterator i$ = this._affectedDatas.iterator(); i$.hasNext(); ) { CmdbData affectedData = (CmdbData)i$.next();
        if (!(affectedData.getDataID().equals(this._inputData.getID())))
          msg.append("\n    ").append("[input data=").append(getCIShortDesc(affectedData)).append("] [root cause id=").append(this._inputData.getDataID()).append("] [action=").append(this._conflictAction).append("]");

      }

    }

    return msg.toString();
  }
}