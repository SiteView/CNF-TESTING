package com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.admin.manager.ReconciliationConfigAdminManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.ReconciliationConfigAdminOperation;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCmdbOperation;

public abstract class AbstractReconciliationConfigAdminOperation extends AbstractCmdbOperation
  implements ReconciliationConfigAdminOperation
{
  protected void doExecute(SubsystemManager manager, CmdbResponse response)
    throws CmdbException
  {
    configExecute((ReconciliationConfigAdminManager)manager, response);
  }

  public String getExecutionTaskQueueName() {
    return "Reconciliation Config Task";
  }

  public String getServiceName() {
    return "CMDB_RECONCILE";
  }
}