package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;

public class DataInAddOrIgnoreData extends AbstractDataInOptimisticUpdateOperation
{
  public DataInAddOrIgnoreData(DataContainer dataContainer, Changer changer)
  {
    super(dataContainer, changer);
  }

  public String getOperationName() {
    return "Data In - Add Or Ignore Data";
  }

  protected DataInRuleOutput runDataInRule(DataInRule dataInRule, ReconciliationEnvironment environment, DataInRuleInput dataInRuleInput) {
    return dataInRule.onAddOrIgnoreData(environment, dataInRuleInput);
  }

  protected boolean shouldAddLinkEnds() {
    return true;
  }
}