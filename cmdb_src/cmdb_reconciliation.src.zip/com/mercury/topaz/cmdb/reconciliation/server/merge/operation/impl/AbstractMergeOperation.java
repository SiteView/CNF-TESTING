package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.impl;

import com.mercury.topaz.cmdb.reconciliation.server.merge.manager.MergeManager;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.MergeOperation;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCmdbOperation;

public abstract class AbstractMergeOperation extends AbstractCmdbOperation
  implements MergeOperation
{
  public final String getExecutionTaskQueueName()
  {
    return "Reconciliation Merge Task";
  }

  protected final void doExecute(SubsystemManager manager, CmdbResponse response) throws CmdbException
  {
    MergeManager mergeManager = (MergeManager)manager;
    mergeExecute(mergeManager, response);
  }

  public String getServiceName() {
    return "CMDB_RECONCILE";
  }

  protected abstract void mergeExecute(MergeManager paramMergeManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}