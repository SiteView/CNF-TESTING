package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.merge.manager.MergeManager;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.MergeOperation;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ReconciliationLogs;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertiesHash;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

abstract class AbstractMergeDataPropertiesOperation<IDType extends CmdbDataID, Type extends CmdbData<IDType>> extends AbstractMergeCommandOperation
  implements MergeOperation
{
  private final Collection<MergeInput<Type>> _input;
  private final Map<Type, Type> _result;
  private CmdbClassModel _classModel;

  protected AbstractMergeDataPropertiesOperation(Collection<MergeInput<Type>> input)
  {
    this._input = input;
    this._result = new HashMap(input.size());
  }

  protected void mergeCommandExecute(MergeManager manager, CmdbResponse response) throws CmdbException
  {
    setClassModelIfNeeded(manager);
    for (Iterator i$ = this._input.iterator(); i$.hasNext(); ) { MergeInput mergeInput = (MergeInput)i$.next();
      String type = mergeType(mergeInput.iterator());
      if (null != type) {
        CmdbDataID id = mergeIDs(mergeInput.iterator());
        CmdbProperties cmdbProperties = mergeProperties(mergeInput.iterator(), type);
        this._result.put(mergeInput.getUpdatingData(), merge(mergeInput, type, id, cmdbProperties));
      } else {
        this._result.put(mergeInput.getUpdatingData(), null);
      }
    }
    this._classModel = null;
  }

  private void setClassModelIfNeeded(MergeManager manager) {
    if (this._classModel == null)
      this._classModel = manager.getSynchronizedClassModel();
  }

  protected abstract Type merge(MergeInput<Type> paramMergeInput, String paramString, CmdbDataID paramCmdbDataID, CmdbProperties paramCmdbProperties) throws CmdbException;

  private IDType mergeIDs(Iterator<Type> datasToMerge)
  {
    return ((CmdbDataID)((CmdbData)datasToMerge.next()).getID());
  }

  private String mergeType(Iterator<Type> datasToMerge) {
    return ((CmdbData)datasToMerge.next()).getType();
  }

  private CmdbProperties mergeProperties(Iterator<Type> datasToMerge, String type) {
    CmdbData firstCmdbData = (CmdbData)datasToMerge.next();
    CmdbPropertiesHash properties = new CmdbPropertiesHash();

    fillWithKeyProperties(properties, firstCmdbData);
    while (datasToMerge.hasNext()) {
      CmdbData cmdbData = (CmdbData)datasToMerge.next();
      mergeProperties(properties, type, cmdbData);
    }
    return properties.toListProperties();
  }

  private void fillWithKeyProperties(CmdbPropertiesHash properties, Type data) {
    CmdbClass dataClass = getClassModel().getClass(data.getType());
    CmdbAttributes cmdbAttributes = dataClass.getAttributesByQualifier(CmdbAttributeQualifierDefs.ID_ATTRIBUTE.getName());
    ReadOnlyIterator iter = cmdbAttributes.getIterator();
    while (iter.hasNext()) {
      String cmdbAttributeName = ((CmdbAttributeDefinition)iter.next()).getName();
      CmdbProperty cmdbProperty = data.getProperty(cmdbAttributeName);
      if (null != cmdbProperty)
        properties.add(cmdbProperty);
    }
  }

  private void mergeProperties(CmdbPropertiesHash properties, String type, Type cmdbData) {
    List ignoredAttributes = new LinkedList();

    CmdbClass ciType = getClassModel().getClass(type);
    for (ReadOnlyIterator propertiesIter = cmdbData.getPropertiesIterator(); propertiesIter.hasNext(); ) {
      CmdbProperty currentProperty = (CmdbProperty)propertiesIter.next();
      CmdbAttribute currentAttribute = ciType.getAttributeByName(currentProperty.getKey());
      if (currentAttribute == null) {
        ignoredAttributes.add(currentProperty.toString());
      }
      else if ((!(currentProperty.isValueEmpty())) && (!(currentAttribute.hasQualifier(CmdbAttributeQualifierDefs.ID_ATTRIBUTE.getName()))) && (!(currentAttribute.getName().equals("root_class"))))
      {
        properties.add(currentProperty);
      }

    }

    if ((!(ignoredAttributes.isEmpty())) && (ReconciliationLogs.getReconciliationLog().isWarnEnabled())) {
      StringBuilder msg = new StringBuilder("A few attributes was ignored because the remaining object is <");
      msg.append(type).append("> and we tried to merge properties of <").append(cmdbData).append(">.\n");
      msg.append("\t\tthe attributes are: ").append(ignoredAttributes).append(".");
      ReconciliationLogs.getReconciliationLog().warn(msg);
    }
  }

  protected void setClassModel(CmdbClassModel classModel) {
    this._classModel = classModel;
  }

  protected CmdbClassModel getClassModel() {
    return this._classModel;
  }

  public Map<Type, Type> getResult() {
    return this._result;
  }
}