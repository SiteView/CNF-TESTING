package com.mercury.topaz.cmdb.reconciliation.server.identification.rules;

import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import java.io.Serializable;

public abstract interface IdentificationRule extends Serializable
{
  public abstract void identify(IdentificationRuleInput paramIdentificationRuleInput);

  public abstract Pattern getLayoutPattern(String paramString, PatternElementNumber paramPatternElementNumber);
}