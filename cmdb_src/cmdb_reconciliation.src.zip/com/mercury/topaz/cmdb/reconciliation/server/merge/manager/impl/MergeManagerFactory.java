package com.mercury.topaz.cmdb.reconciliation.server.merge.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.merge.manager.MergeManager;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadMultiWrite;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;

public class MergeManagerFactory extends AbstractSubsystemManagerFactory
{
  public static final String NAME = "Reconciliation Merge Task";

  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new MergeManagerImpl(localEnvironment);
  }

  private static class MergeManagerImpl extends CmdbSubsystemManagerImpl
  implements MergeManager, MultiReadMultiWrite
  {
    MergeManagerImpl(LocalEnvironment localEnvironment) {
      super(localEnvironment);
    }

    public void startUp() {
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation Merge Manager is started up properly !!!");
    }

    public void shutdown() {
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation Merge Manager is shutdown up properly !!!");
    }

    public String getName() {
      return "Reconciliation Merge Task";
    }
  }
}