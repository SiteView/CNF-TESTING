package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;

abstract class TypeOfLink
  implements TypeOfData<CmdbLinkID, CmdbLink>
{
  public final CmdbLink createData(CmdbLink oldData, CmdbLinkID newId, String classType, CmdbProperties newProperties, OldToNewIdMapping oldToNewIdMapping)
  {
    CmdbObjectID end1Id = oldToNewIdMapping.get(oldData.getEnd1());
    CmdbObjectID end2Id = oldToNewIdMapping.get(oldData.getEnd2());

    return CmdbLinkFactory.createLink(newId, end1Id, end2Id, classType, newProperties);
  }

  public final CmdbLink createData(CmdbLink oldData, String classType, CmdbProperties properties, DataFactory dataFactory, OldToNewIdMapping oldToNewIdMapping) {
    CmdbObjectID end1Id = oldToNewIdMapping.get(oldData.getEnd1());
    CmdbObjectID end2Id = oldToNewIdMapping.get(oldData.getEnd2());

    return dataFactory.createLink(classType, end1Id, end2Id, properties);
  }
}