package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl.ReconciliationConfigCacheQueryGetDataInRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.exception.DataInException;
import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInPreAnalyzeRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DataInQueryGetPreAnalyzeRule extends AbstractDataInQueryOperation
{
  private static final String NAME = "DataInQuery - Get Pre Analyze Rule";
  private static final String DATAIN_RULE = "DataInRule";
  private final Collection<String> _types;
  private Collection<DataInPreAnalyzeRule> _dataInRules;

  public DataInQueryGetPreAnalyzeRule(Collection<String> types)
  {
    this._types = types;
  }

  public String getOperationName() {
    return "DataInQuery - Get Pre Analyze Rule";
  }

  public void dataInQueryExecute(DataInManager dataInManager, CmdbResponse response) throws CmdbException {
    CmdbClassModel classModel = dataInManager.getSynchronizedClassModel();
    Map rules = new HashMap();

    for (Iterator i$ = this._types.iterator(); i$.hasNext(); ) { String currType = (String)i$.next();
      createRuleAndAddItToMapIfNeeded(dataInManager, classModel, "host", currType, rules, "com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl.DataInHostPreAnalyzeRule");
    }
    setDataInRules(new ArrayList(rules.values()));
    response.addResult("DataInRule", (Serializable)this._dataInRules);
  }

  private void createRuleAndAddItToMapIfNeeded(OperationExecutor executor, CmdbClassModel classModel, String superType, String actualType, Map<String, DataInPreAnalyzeRule> rules, String preAnalyzeRuleClassName) {
    if ((classModel.isTypeOf(superType, actualType)) && (!(rules.containsKey(superType))))
    {
      ReconciliationConfigCacheQueryGetDataInRule getDataInRule = new ReconciliationConfigCacheQueryGetDataInRule(superType);
      executor.executeOperation(getDataInRule);
      rules.put(superType, getPreAnalyzeRule(preAnalyzeRuleClassName, getDataInRule.getDataInRule().getRuleDefinition()));
    }
  }

  private DataInPreAnalyzeRule getPreAnalyzeRule(String preAnalyzeRuleClassName, DataInRuleDefinition ruleDefinition) {
    try {
      return ((DataInPreAnalyzeRule)Class.forName(preAnalyzeRuleClassName).getConstructor(new Class[] { DataInRuleDefinition.class }).newInstance(new Object[] { ruleDefinition }));
    } catch (Exception e) {
      throw new DataInException("cannot load pre analyze rule class <" + preAnalyzeRuleClassName + ">", e);
    }
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
    setDataInRules((Collection)response.getResult("DataInRule"));
  }

  public Collection<String> getTypes() {
    return this._types;
  }

  public Collection<DataInPreAnalyzeRule> getDataInRules() {
    return this._dataInRules;
  }

  public void setDataInRules(Collection<DataInPreAnalyzeRule> dataInRules) {
    this._dataInRules = dataInRules;
  }
}