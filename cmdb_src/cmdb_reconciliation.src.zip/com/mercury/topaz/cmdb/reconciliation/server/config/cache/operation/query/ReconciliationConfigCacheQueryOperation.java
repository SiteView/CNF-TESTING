package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.ReconciliationConfigCacheOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;

public abstract interface ReconciliationConfigCacheQueryOperation
{
  public abstract void configCacheQueryExecute(ReconciliationConfigCacheManager paramReconciliationConfigCacheManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}