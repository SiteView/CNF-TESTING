package com.mercury.topaz.cmdb.reconciliation.server.change.impl;

import com.mercury.topaz.cmdb.reconciliation.server.change.CmdbObjectIDChange;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;

public class CmdbObjectIDChangeFactory
{
  public static CmdbObjectIDChange createObjectIDChange(CmdbObjectID oldID, CmdbObjectID newID)
  {
    return new CmdbObjectIDChangeImpl(oldID, newID);
  }
}