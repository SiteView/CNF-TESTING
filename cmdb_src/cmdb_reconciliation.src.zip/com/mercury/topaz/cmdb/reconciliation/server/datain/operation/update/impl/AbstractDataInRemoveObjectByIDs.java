package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.DataInUpdateOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModelUpdateBulkInfo;

public abstract class AbstractDataInRemoveObjectByIDs extends AbstractDataInUpdateOperation
  implements DataInUpdateOperation
{
  private CmdbObjectIds _inputIDs;

  protected AbstractDataInRemoveObjectByIDs(CmdbObjectIds inputIDs, Changer changer)
  {
    super(changer);
    setInputIDs(inputIDs);
  }

  public void dataInUpdateExecute(DataInManager dataInManager, CmdbResponse response) throws CmdbException {
    CmdbModelUpdateBulkInfo bulkInfo = sendToModelUpdate(dataInManager);
    setBulkInfo(bulkInfo);
  }

  protected CmdbObjectIds getInputIDs() {
    return this._inputIDs;
  }

  private void setInputIDs(CmdbObjectIds inputIDs) {
    this._inputIDs = inputIDs;
  }
}