package com.mercury.topaz.cmdb.reconciliation.server.config.jmx;

public abstract interface ReconciliationJmxServicesInterface
{
  public abstract String getReconciliationConfiguration(Integer paramInteger, String paramString);

  public abstract String deployReconciliationConfiguration(Integer paramInteger, String paramString);

  public abstract void unDeployReconciliationConfiguration(Integer paramInteger, String paramString);
}