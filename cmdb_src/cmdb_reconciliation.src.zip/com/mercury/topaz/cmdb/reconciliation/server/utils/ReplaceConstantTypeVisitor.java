package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.topaz.cmdb.shared.classmodel.type.TypeVisitor;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBytesType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDateType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDoubleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbFloatType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.Numeric;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import java.util.Date;

class ReplaceConstantTypeVisitor
  implements TypeVisitor
{
  private final CmdbProperty _property;
  private final Object _constantToReplace;
  private final Object _value;
  private CmdbProperty _newCmdbProperty;

  ReplaceConstantTypeVisitor(CmdbProperty property, Object constantToReplace, Object value)
  {
    this._property = property;
    this._constantToReplace = constantToReplace;
    this._value = value;
    this._newCmdbProperty = null;
  }

  public void visit(CmdbSimpleType simpleCmdbType) {
  }

  public void visit(Numeric numericType) {
  }

  public void visit(CmdbIntegerType integerType) {
    if (this._constantToReplace.equals(this._property.getValue()))
      this._newCmdbProperty = CmdbPropertyFactory.createProperty(this._property.getKey(), (Integer)this._value);
  }

  public void visit(CmdbLongType longType)
  {
    if (this._constantToReplace.equals(this._property.getValue()))
      this._newCmdbProperty = CmdbPropertyFactory.createProperty(this._property.getKey(), (Long)this._value);
  }

  public void visit(CmdbFloatType floatType)
  {
    if (this._constantToReplace.equals(this._property.getValue()))
      this._newCmdbProperty = CmdbPropertyFactory.createProperty(this._property.getKey(), (Float)this._value);
  }

  public void visit(CmdbDoubleType doubleType)
  {
    if (this._constantToReplace.equals(this._property.getValue()))
      this._newCmdbProperty = CmdbPropertyFactory.createProperty(this._property.getKey(), (Double)this._value);
  }

  public void visit(CmdbStringType stringType)
  {
    if (!(this._property.isValueEmpty())) {
      String oldValue = (String)this._property.getValue();
      String constantToReplace = (String)this._constantToReplace;
      if (oldValue.contains(constantToReplace)) {
        String newString = (String)this._value;
        String newValue = replace(oldValue, constantToReplace, newString);
        this._newCmdbProperty = CmdbPropertyFactory.createProperty(this._property.getKey(), newValue);
      }
    }
  }

  public void visit(CmdbXmlType xmlType) {
    if (!(this._property.isValueEmpty())) {
      String oldValue = (String)this._property.getValue();
      String constantToReplace = (String)this._constantToReplace;
      if (oldValue.contains(constantToReplace)) {
        String newString = (String)this._value;
        String newValue = replace(oldValue, constantToReplace, newString);
        this._newCmdbProperty = CmdbPropertyFactory.createProperty(this._property.getKey(), newValue);
      }
    }
  }

  private String replace(String oldValue, String constantToReplace, String newString) {
    int startIndex = oldValue.indexOf(constantToReplace);
    if (startIndex != -1)
      oldValue = oldValue.subSequence(0, startIndex) + newString + oldValue.subSequence(startIndex + constantToReplace.length(), oldValue.length());

    return oldValue;
  }

  public void visit(CmdbBooleanType cmdbBooleanType) {
    if (this._constantToReplace.equals(this._property.getValue()))
      this._newCmdbProperty = CmdbPropertyFactory.createProperty(this._property.getKey(), (Boolean)this._value);
  }

  public void visit(CmdbDateType cmdbDateType)
  {
    if (this._constantToReplace.equals(this._property.getValue()))
      this._newCmdbProperty = CmdbPropertyFactory.createProperty(this._property.getKey(), new Date(((Long)this._value).longValue()));
  }

  public void visit(CmdbBytesType cmdbBytesType)
  {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbSimpleList cmdbSimpleList) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbStringListType cmdbStringListType) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbIntegerListType cmdbIntegerListType) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbTypeDef typeDef) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbEnum cmdbEnum) {
    if (this._constantToReplace.equals(this._property.getValue()))
      this._newCmdbProperty = CmdbPropertyFactory.createProperty(this._property.getKey(), (Integer)this._value);
  }

  public void visit(CmdbList cmdbList)
  {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbExternalResource externalResource) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public CmdbProperty getNewCmdbProperty() {
    return this._newCmdbProperty;
  }
}