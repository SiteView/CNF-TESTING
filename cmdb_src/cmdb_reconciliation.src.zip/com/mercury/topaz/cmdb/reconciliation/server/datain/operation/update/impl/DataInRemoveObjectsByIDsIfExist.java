package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.ModelUpdateBulksOptimistic;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModelUpdateBulkInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.object.remove.ModelUpdateRemoveObjectsIfExist;

public class DataInRemoveObjectsByIDsIfExist extends AbstractDataInRemoveObjectByIDs
{
  public DataInRemoveObjectsByIDsIfExist(CmdbObjectIds inputIDs, Changer changer)
  {
    super(inputIDs, changer);
  }

  public String getOperationName() {
    return "Data In - Remove Objects By IDs If Exist";
  }

  protected CmdbModelUpdateBulkInfo sendToModelUpdate(DataInManager dataInManager) {
    ModelUpdateBulksOptimistic updateBulk = new ModelUpdateBulksOptimistic(getChanger());
    updateBulk.addOptimisticModelUpdateOperation(new ModelUpdateRemoveObjectsIfExist(getInputIDs(), getChanger()));
    updateBulk.setUserOperation(isUserOperation());
    dataInManager.executeOperation(updateBulk);
    return updateBulk.getModelUpdateBulkInfo();
  }
}