package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

public class IdentificationRuleByIdDef extends AbstractIdentificationRuleConditionDef
{
  public void accept(IdentificationRuleConditionDefVisitor visitor)
  {
    visitor.visit(this);
  }
}