package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output;

import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.operation.update.ModelUpdate;
import java.util.List;
import java.util.Map;

public abstract interface DataInRuleOutput
{
  public abstract Map<CmdbDataID, CmdbDataID> getIDChangesMap();

  public abstract List<ModelUpdate> getModelUpdateOperations();

  public abstract CmdbDataIDs getIDsForTouch();
}