package com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.impl;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public class ReconciliationConfigCacheManagerFactory extends AbstractSubsystemManagerFactory
{
  public static final String NAME = "Reconciliation Config Cache Task";

  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new ReconciliationConfigCacheManagerImpl(localEnvironment);
  }
}