package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import java.io.Serializable;
import java.util.ArrayList;

public class Or
  implements Serializable
{
  protected ConnectedCiCondition connectedCiCondition;
  protected ArrayList attributeConditionList;
  protected ArrayList andList;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public Or()
  {
    this.attributeConditionList = new ArrayList();

    this.andList = new ArrayList();
  }

  public void addAttributeCondition(AttributeCondition attributeCondition)
  {
    this.attributeConditionList.add(attributeCondition);
  }

  public AttributeCondition getAttributeCondition(int index) {
    return ((AttributeCondition)this.attributeConditionList.get(index));
  }

  public int sizeAttributeConditionList() {
    return this.attributeConditionList.size();
  }

  public ConnectedCiCondition getConnectedCiCondition() {
    return this.connectedCiCondition;
  }

  public void setConnectedCiCondition(ConnectedCiCondition connectedCiCondition) {
    this.connectedCiCondition = connectedCiCondition;
  }

  public void addAnd(And and) {
    this.andList.add(and);
  }

  public And getAnd(int index) {
    return ((And)this.andList.get(index));
  }

  public int sizeAndList() {
    return this.andList.size();
  }
}