package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;

public abstract class AbstractDataInRule
  implements DataInRule
{
  private DataInRuleDefinition _ruleDefinition;

  protected AbstractDataInRule(DataInRuleDefinition ruleDefinition)
  {
    setRuleDefinition(ruleDefinition);
  }

  public DataInRuleDefinition getRuleDefinition() {
    return this._ruleDefinition;
  }

  private void setRuleDefinition(DataInRuleDefinition ruleDefinition) {
    this._ruleDefinition = ruleDefinition;
  }
}