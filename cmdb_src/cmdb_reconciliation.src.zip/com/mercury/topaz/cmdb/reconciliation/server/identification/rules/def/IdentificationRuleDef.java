package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

import java.io.Serializable;

public abstract class IdentificationRuleDef
  implements Serializable
{
  public abstract void accept(IdentificationRuleDefVisitor paramIdentificationRuleDefVisitor);
}