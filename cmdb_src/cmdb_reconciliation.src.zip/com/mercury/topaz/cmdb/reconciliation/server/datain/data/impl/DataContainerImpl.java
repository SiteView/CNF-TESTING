package com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ReconciliationLogs;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertiesHash;
import com.mercury.topaz.cmdb.shared.util.collections.impl.EmptyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class DataContainerImpl
  implements DataContainer
{
  protected final CmdbObjects _objectsForUpdate;
  protected final CmdbLinks _linksForUpdate;
  protected final CmdbObjects _referencedObjects;
  protected final CmdbLinks _referencedLinks;
  protected final Map<String, CmdbObjects> _objectsForUpdateByType;
  protected final Map<String, CmdbLinks> _linksForUpdateByType;
  protected final Map<String, CmdbObjects> _referencedObjectsByType;
  protected final Map<String, CmdbLinks> _referencedLinksByType;
  protected final Map<CmdbObjectID, CmdbLinks> _linksByEnd1Id;
  protected final Map<CmdbObjectID, CmdbLinks> _linksByEnd2Id;

  DataContainerImpl()
  {
    this._objectsForUpdate = CmdbObjectFactory.createHashMapObjects();
    this._linksForUpdate = CmdbLinkFactory.createLinks();
    this._referencedObjects = CmdbObjectFactory.createHashMapObjects();
    this._referencedLinks = CmdbLinkFactory.createLinks();

    this._objectsForUpdateByType = new HashMap();
    this._linksForUpdateByType = new HashMap();
    this._referencedObjectsByType = new HashMap();
    this._referencedLinksByType = new HashMap();

    this._linksByEnd1Id = new HashMap();
    this._linksByEnd2Id = new HashMap();
  }

  CmdbObjects getObjectsForUpdate() {
    return this._objectsForUpdate;
  }

  public CmdbObjects getObjectsForUpdate(String type) {
    return ((CmdbObjects)this._objectsForUpdateByType.get(type));
  }

  public void addObjectForUpdate(CmdbObject object) {
    CmdbObject existingObject;
    CmdbObjectID objectId = (CmdbObjectID)object.getID();
    if (this._referencedObjects.contains(objectId)) {
      existingObject = (CmdbObject)this._referencedObjects.get(objectId);
      this._referencedObjects.remove(objectId);
      String existingObjectType = existingObject.getType();
      CmdbObjects cmdbObjects = (CmdbObjects)this._referencedObjectsByType.get(existingObjectType);
      cmdbObjects.remove(objectId);
      if (cmdbObjects.isEmpty())
        this._referencedObjectsByType.remove(existingObjectType);

      Log log = ReconciliationLogs.getReconciliationLog();
      if ((!(existingObjectType.equals(object.getType()))) && (log.isWarnEnabled()))
        log.warn("While trying to add object for update, DataContainer found reference object with the same id and with a different type.:\nOld Object=" + existingObject + "\nNew Object=" + object);

    }
    else if (this._objectsForUpdate.contains(objectId)) {
      existingObject = (CmdbObject)this._objectsForUpdate.get(objectId);
      object = CmdbObjectFactory.createObject((CmdbObjectID)object.getID(), object.getType(), getMergedProperties(existingObject, object));
    }
    addObject(object, this._objectsForUpdate, this._objectsForUpdateByType);
  }

  public void addReferencedObject(CmdbObject object) {
    if (!(this._objectsForUpdate.contains((CmdbDataID)object.getID())))
      addObject(object, this._referencedObjects, this._referencedObjectsByType);
  }

  private void addObject(CmdbObject object, CmdbObjects objects, Map<String, CmdbObjects> objectsByType)
  {
    if (objects.contains((CmdbDataID)object.getID())) {
      CmdbObject existingObject = (CmdbObject)objects.get((CmdbDataID)object.getID());
      String existingObjectType = existingObject.getType();
      CmdbObjectID existingObjectId = (CmdbObjectID)existingObject.getID();

      objects.remove(existingObjectId);
      CmdbObjects objectsForType = (CmdbObjects)objectsByType.get(existingObjectType);
      objectsForType.remove(existingObjectId);
      if (objectsForType.isEmpty())
        objectsByType.remove(existingObjectType);

      Log log = ReconciliationLogs.getReconciliationLog();
      if ((!(existingObjectType.equals(object.getType()))) && (log.isWarnEnabled()))
        log.warn("While trying to add object DataContainer found object with the same id and with a different type.:\nOld Object=" + existingObject + "\nNew Object=" + object);

    }

    addObjectToMapByItsType(objectsByType, object);
    objects.add(object);
  }

  public void addLinkForUpdate(CmdbLink link) {
    CmdbLinkID linkId = (CmdbLinkID)link.getID();
    if (this._referencedLinks.contains(linkId)) {
      this._referencedLinks.remove(linkId);
      String linkType = link.getType();
      CmdbLinks cmdbLinks = (CmdbLinks)this._referencedLinksByType.get(linkType);
      cmdbLinks.remove(linkId);
      if (cmdbLinks.isEmpty())
        this._referencedLinksByType.remove(linkType);

    }
    else if (this._linksForUpdate.contains(linkId)) {
      CmdbLink existingLink = (CmdbLink)this._linksForUpdate.get(linkId);
      link = CmdbLinkFactory.createLink((CmdbLinkID)link.getID(), link.getEnd1(), link.getEnd2(), link.getType(), getMergedProperties(existingLink, link));
    }
    addLink(link, this._linksForUpdate, this._linksForUpdateByType);
  }

  private <Type extends CmdbDataID> CmdbProperties getMergedProperties(CmdbData<Type> existingData, CmdbData<Type> newData) {
    CmdbPropertiesHash props = new CmdbPropertiesHash();
    ReadOnlyIterator exisitngPropsIt = existingData.getPropertiesIterator();
    while (exisitngPropsIt.hasNext())
      props.add((CmdbProperty)exisitngPropsIt.next());

    ReadOnlyIterator newPropsIt = newData.getPropertiesIterator();
    while (newPropsIt.hasNext())
      props.add((CmdbProperty)newPropsIt.next());

    return props.toListProperties();
  }

  public void addReferencedLink(CmdbLink link) {
    if (!(this._linksForUpdate.contains((CmdbDataID)link.getID())))
      addLink(link, this._referencedLinks, this._referencedLinksByType);
  }

  private void addLink(CmdbLink link, CmdbLinks links, Map<String, CmdbLinks> linksByType)
  {
    String type = link.getType();
    CmdbLinks linksForType = (CmdbLinks)linksByType.get(type);
    if (null == linksForType) {
      linksForType = CmdbLinkFactory.createLinks();
      linksByType.put(type, linksForType);
    }
    linksForType.add(link);
    links.add(link);
    CmdbLinks cmdbLinksByEnd1Id = (CmdbLinks)this._linksByEnd1Id.get(link.getEnd1());
    if (null == cmdbLinksByEnd1Id) {
      cmdbLinksByEnd1Id = CmdbLinkFactory.createLinks();
      this._linksByEnd1Id.put(link.getEnd1(), cmdbLinksByEnd1Id);
    }
    cmdbLinksByEnd1Id.add(link);
    CmdbLinks cmdbLinksByEnd2Id = (CmdbLinks)this._linksByEnd1Id.get(link.getEnd2());
    if (null == cmdbLinksByEnd2Id) {
      cmdbLinksByEnd2Id = CmdbLinkFactory.createLinks();
      this._linksByEnd2Id.put(link.getEnd2(), cmdbLinksByEnd2Id);
    }
    cmdbLinksByEnd2Id.add(link);
  }

  public Iterator<Map.Entry<String, CmdbObjects>> getObjectsForUpdateIteratorByType() {
    return this._objectsForUpdateByType.entrySet().iterator();
  }

  public Iterator<Map.Entry<String, CmdbLinks>> getLinksForUpdateIteratorByType() {
    return this._linksForUpdateByType.entrySet().iterator();
  }

  public Iterator<Map.Entry<String, CmdbObjects>> getReferencedObjectsIteratorByType() {
    return this._referencedObjectsByType.entrySet().iterator();
  }

  public Iterator<Map.Entry<String, CmdbLinks>> getReferencedLinksIteratorByType() {
    return this._referencedLinksByType.entrySet().iterator();
  }

  public Iterator<? extends CmdbData> getDatasForUpdateIteratorByType(String type) {
    CmdbObjects objectsForUpdate = getObjectsForUpdate(type);
    CmdbLinks linksForUpdate = getLinksForUpdate(type);
    return ((linksForUpdate != null) ? linksForUpdate.iterator() : (objectsForUpdate != null) ? objectsForUpdate.iterator() : EmptyIterator.getInstance());
  }

  public Collection<String> getAllTypes()
  {
    Set objectsForUpdateTypes = this._objectsForUpdateByType.keySet();
    Set linksForUpdateTypes = this._linksForUpdateByType.keySet();
    Set referencedObjectsTypes = this._referencedObjectsByType.keySet();
    Set referencedLinksTypes = this._referencedLinksByType.keySet();

    Set allTypes = new HashSet(objectsForUpdateTypes.size() + linksForUpdateTypes.size() + referencedObjectsTypes.size() + referencedLinksTypes.size());

    allTypes.addAll(objectsForUpdateTypes);
    allTypes.addAll(linksForUpdateTypes);
    allTypes.addAll(referencedObjectsTypes);
    allTypes.addAll(referencedLinksTypes);
    return allTypes;
  }

  public boolean contains(CmdbObjectID id) {
    return ((getObjectsForUpdate().contains(id)) || (getReferencedObjects().contains(id)));
  }

  public boolean contains(CmdbLinkID id) {
    return ((getLinksForUpdate().contains(id)) || (getReferencedLinks().contains(id)));
  }

  CmdbLinks getLinksForUpdate() {
    return this._linksForUpdate;
  }

  public CmdbLinks getLinksForUpdate(String type) {
    return ((CmdbLinks)this._linksForUpdateByType.get(type));
  }

  CmdbObjects getReferencedObjects() {
    return this._referencedObjects;
  }

  public CmdbObjects getReferencedObjects(String type) {
    return ((CmdbObjects)this._referencedObjectsByType.get(type));
  }

  CmdbLinks getReferencedLinks() {
    return this._referencedLinks;
  }

  public CmdbLinks getReferencedLinks(String type) {
    return ((CmdbLinks)this._referencedLinksByType.get(type));
  }

  public int sizeOfDataForUpdate() {
    return (getObjectsForUpdate().size() + getLinksForUpdate().size());
  }

  public boolean isDataForUpdateEmpty() {
    return ((getObjectsForUpdate().isEmpty()) && (getLinksForUpdate().isEmpty()));
  }

  public int sizeOfReferencedData() {
    return (getReferencedObjects().size() + getReferencedLinks().size());
  }

  public boolean isReferencedDataEmpty() {
    return ((getReferencedObjects().isEmpty()) && (getReferencedLinks().isEmpty()));
  }

  public CmdbLinks getCmdbLinksByEnd1(CmdbObjectID end1Id) {
    CmdbLinks ans = (CmdbLinks)this._linksByEnd1Id.get(end1Id);
    return ((null == ans) ? CmdbLinkFactory.createEmptyLinks() : ans);
  }

  public CmdbLinks getCmdbLinksByEnd2(CmdbObjectID end2Id) {
    CmdbLinks ans = (CmdbLinks)this._linksByEnd2Id.get(end2Id);
    return ((null == ans) ? CmdbLinkFactory.createEmptyLinks() : ans);
  }

  public CmdbObject getCmdbObject(CmdbObjectID id) {
    return ((getReferencedObjects().contains(id)) ? (CmdbObject)getReferencedObjects().get(id) : (getObjectsForUpdate().contains(id)) ? (CmdbObject)getObjectsForUpdate().get(id) : null);
  }

  public CmdbLink getCmdbLink(CmdbLinkID id) {
    return ((getReferencedLinks().contains(id)) ? (CmdbLink)getReferencedLinks().get(id) : (getLinksForUpdate().contains(id)) ? (CmdbLink)getLinksForUpdate().get(id) : null);
  }

  public Iterator<CmdbObject> getCmdbObjectsIteratorByType(String type) {
    CmdbObjects ans = CmdbObjectFactory.createObjects();
    CmdbObjects objectsForUpdateByType = (CmdbObjects)this._objectsForUpdateByType.get(type);
    if (null != objectsForUpdateByType)
      ans.add(objectsForUpdateByType);

    CmdbObjects referencedObjectsByType = (CmdbObjects)this._referencedObjectsByType.get(type);
    if (null != referencedObjectsByType)
      ans.add(referencedObjectsByType);

    return ans.iterator();
  }

  public String toString() {
    int totalSize = getObjectsForUpdate().size() + getLinksForUpdate().size() + getReferencedObjects().size() + getReferencedLinks().size();
    StringBuilder desc = new StringBuilder("DataContainer (total size=").append(totalSize).append("):");
    append("Objects For Update", desc, getObjectsForUpdate());
    append("Links For Update", desc, getLinksForUpdate());
    append("Referenced Objects", desc, getReferencedObjects());
    append("Referenced Links", desc, getReferencedLinks());
    return desc.toString();
  }

  private static StringBuilder append(String title, StringBuilder sb, CmdbDatas<? extends CmdbDataID, ? extends CmdbData> datas) {
    sb.append("\n").append(title).append("(size=").append(datas.size()).append(")");
    for (Iterator i$ = datas.iterator(); i$.hasNext(); ) { CmdbData data = (CmdbData)i$.next();
      sb.append("\n\t").append(data);
    }
    return sb;
  }

  public void orderTypes(Map<String, String> typeToRelevantSuperTypeMap) {
    CmdbObject object;
    this._objectsForUpdateByType.clear();
    this._referencedObjectsByType.clear();

    for (Iterator i$ = this._objectsForUpdate.iterator(); i$.hasNext(); ) { object = (CmdbObject)i$.next();
      addObjectByRelevantSuperType(typeToRelevantSuperTypeMap, object, this._objectsForUpdateByType);
    }

    for (i$ = this._referencedObjects.iterator(); i$.hasNext(); ) { object = (CmdbObject)i$.next();
      addObjectByRelevantSuperType(typeToRelevantSuperTypeMap, object, this._referencedObjectsByType);
    }
  }

  private void addObjectToMapByItsType(Map<String, CmdbObjects> objectsByType, CmdbObject object) {
    String type = object.getType();
    addObjectToMapByType(objectsByType, object, type);
  }

  private void addObjectToMapByType(Map<String, CmdbObjects> objectsByType, CmdbObject object, String type) {
    CmdbObjects objectsForType = (CmdbObjects)objectsByType.get(type);
    if (objectsForType == null) {
      objectsForType = CmdbObjectFactory.createHashMapObjects();
      objectsByType.put(type, objectsForType);
    }

    objectsForType.add(object);
  }

  private void addObjectByRelevantSuperType(Map<String, String> typeToRelevantSuperTypeMap, CmdbObject object, Map<String, CmdbObjects> map) {
    String objectType = object.getType();
    String relevantSuperType = (String)typeToRelevantSuperTypeMap.get(objectType);
    if (relevantSuperType == null)
      addObjectToMapByType(map, object, objectType);
    else
      addObjectToMapByType(map, object, relevantSuperType);
  }

  public void addObjectsForUpdate(CmdbObjects objects)
  {
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
      addObjectForUpdate(object);
    }
  }

  public void addReferencedObjects(CmdbObjects objects) {
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
      addReferencedObject(object);
    }
  }

  public void addLinksForUpdate(CmdbLinks links) {
    for (Iterator i$ = links.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
      addLinkForUpdate(link);
    }
  }

  public void addReferencedLinks(CmdbLinks links) {
    for (Iterator i$ = links.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
      addReferencedLink(link);
    }
  }

  public int getObjectsForUpdateSize() {
    return getObjectsForUpdate().size();
  }

  public int getLinksForUpdateSize() {
    return getLinksForUpdate().size();
  }

  public int getReferencedObjectsSize() {
    return getReferencedObjects().size();
  }

  public int getReferencedLinksSize() {
    return getReferencedLinks().size();
  }

  public int getObjectsForUpdateSize(String type) {
    return getObjectsForUpdate(type).size();
  }

  public int getLinksForUpdateSize(String type) {
    return getLinksForUpdate(type).size();
  }

  public int getReferencedObjectsSize(String type) {
    return getReferencedObjects(type).size();
  }

  public int getReferencedLinksSize(String type) {
    return getReferencedLinks(type).size();
  }

  public boolean containsObjectForUpdate(CmdbObjectID id) {
    return getObjectsForUpdate().contains(id);
  }

  public boolean containsReferencedObject(CmdbObjectID id) {
    return getReferencedObjects().contains(id);
  }

  public boolean containsLinkForUpdate(CmdbLinkID id) {
    return getLinksForUpdate().contains(id);
  }

  public boolean containsReferencedLink(CmdbLinkID id) {
    return getReferencedLinks().contains(id);
  }

  public CmdbObject getObjectForUpdate(CmdbObjectID id) {
    return ((CmdbObject)getObjectsForUpdate().get(id));
  }

  public CmdbObject getReferencedObject(CmdbObjectID id) {
    return ((CmdbObject)getReferencedObjects().get(id));
  }

  public CmdbLink getLinkForUpdate(CmdbLinkID id) {
    return ((CmdbLink)getLinksForUpdate().get(id));
  }

  public CmdbLink getReferencedLink(CmdbLinkID id) {
    return ((CmdbLink)getReferencedLinks().get(id));
  }

  public Iterator<CmdbObject> getObjectsForUpdateIterator() {
    return getObjectsForUpdate().iterator();
  }

  public Iterator<CmdbObject> getReferencedObjectsIterator() {
    return getReferencedObjects().iterator();
  }

  public Iterator<CmdbLink> getLinksForUpdateIterator() {
    return getLinksForUpdate().iterator();
  }

  public Iterator<CmdbLink> getReferencedLinksIterator() {
    return getReferencedLinks().iterator();
  }

  public Iterator<CmdbObject> getObjectsForUpdateIterator(String type) {
    return getObjectsForUpdate(type).iterator();
  }

  public Iterator<CmdbObject> getReferencedObjectsIterator(String type) {
    return getReferencedObjects(type).iterator();
  }

  public Iterator<CmdbLink> getLinksForUpdateIterator(String type) {
    return getLinksForUpdate(type).iterator();
  }

  public Iterator<CmdbLink> getReferencedLinksIterator(String type) {
    return getReferencedLinks(type).iterator();
  }
}