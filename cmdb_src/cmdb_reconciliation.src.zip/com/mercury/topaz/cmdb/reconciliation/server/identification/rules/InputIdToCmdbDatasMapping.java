package com.mercury.topaz.cmdb.reconciliation.server.identification.rules;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map.Entry;

public abstract interface InputIdToCmdbDatasMapping extends Iterable<Map.Entry<CmdbDataID, Collection<? extends CmdbData>>>, Serializable
{
  public abstract void add(CmdbDataID paramCmdbDataID, Collection<? extends CmdbData> paramCollection);

  public abstract void addInBulk(CmdbDataID paramCmdbDataID, Collection<? extends CmdbData> paramCollection);

  public abstract void addAll(InputIdToCmdbDatasMapping paramInputIdToCmdbDatasMapping);

  public abstract Collection<? extends CmdbData> get(String paramString);

  public abstract Collection<? extends CmdbData> get(CmdbDataID paramCmdbDataID);

  public abstract boolean containsKey(String paramString);

  public abstract boolean containsKey(CmdbDataID paramCmdbDataID);

  public abstract boolean containsKeyWithNotEmptyValue(String paramString);

  public abstract boolean containsKeyWithNotEmptyValue(CmdbDataID paramCmdbDataID);

  public abstract int size();

  public abstract Iterator<Map.Entry<CmdbDataID, Collection<? extends CmdbData>>> iterator();

  public abstract Collection<? extends CmdbData> getInBulk(String paramString);

  public abstract Collection<? extends CmdbData> getInBulk(CmdbDataID paramCmdbDataID);

  public abstract boolean containsKeyInBulk(String paramString);

  public abstract boolean containsKeyInBulk(CmdbDataID paramCmdbDataID);

  public abstract boolean containsKeyWithNotEmptyValueInBulk(String paramString);

  public abstract boolean containsKeyWithNotEmptyValueInBulk(CmdbDataID paramCmdbDataID);

  public abstract int sizeInBulk();

  public abstract Iterator<Map.Entry<CmdbDataID, Collection<? extends CmdbData>>> iteratorInBulk();
}