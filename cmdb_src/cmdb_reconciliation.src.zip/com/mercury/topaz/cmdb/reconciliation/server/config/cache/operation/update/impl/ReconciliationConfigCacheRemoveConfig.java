package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.Collection;
import java.util.Iterator;

public class ReconciliationConfigCacheRemoveConfig extends AbstractReconciliationConfigCacheUpdateOperation
{
  private Collection<String> _configNames;

  public ReconciliationConfigCacheRemoveConfig(Collection<String> configNames)
  {
    setConfigNames(configNames);
  }

  public String getOperationName() {
    return "Reconciliation Config Cache - Remove Config";
  }

  public void configCacheUpdateExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response) throws CmdbException {
    for (Iterator i$ = getConfigNames().iterator(); i$.hasNext(); ) { String configName = (String)i$.next();
      configCacheManager.removeConfigDef(configName);
    }
  }

  private Collection<String> getConfigNames() {
    return this._configNames;
  }

  private void setConfigNames(Collection<String> configNames) {
    this._configNames = configNames;
  }
}