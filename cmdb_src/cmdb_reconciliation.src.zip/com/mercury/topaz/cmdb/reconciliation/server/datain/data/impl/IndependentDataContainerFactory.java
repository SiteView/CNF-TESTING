package com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.IndependentDataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ModelUtil;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class IndependentDataContainerFactory
{
  public static IndependentDataContainer createDataContainer(List<IndependentDataContainer> allDataContainers)
  {
    return new IndependentDataContainerImpl(allDataContainers);
  }

  private static class IndependentDataContainerImpl extends DataContainerImpl
  implements IndependentDataContainer
  {
    final List<IndependentDataContainer> _allDataContainers;

    public IndependentDataContainerImpl(List<IndependentDataContainer> allDataContainers)
    {
      this._allDataContainers = allDataContainers;
    }

    public List<IndependentDataContainer> getAllDataContainers() {
      return this._allDataContainers;
    }

    public void clean(CmdbClassModel classModel, Map<CmdbObjectID, Collection<CmdbData>> objectsToRemoveByHostID, Map<String, CmdbObject> toStringToObjectMap) {
      cleanLinks(this._linksByEnd1Id, getLinksForUpdate(), this._linksForUpdateByType, objectsToRemoveByHostID);
      cleanObjects(getObjectsForUpdate(), this._objectsForUpdateByType, objectsToRemoveByHostID, toStringToObjectMap, classModel);
      cleanLinks(this._linksByEnd1Id, getReferencedLinks(), this._referencedLinksByType, objectsToRemoveByHostID);
      cleanObjects(getReferencedObjects(), this._referencedObjectsByType, objectsToRemoveByHostID, toStringToObjectMap, classModel);
    }

    private void cleanObjects(CmdbObjects objects, Map<String, CmdbObjects> objectsByType, Map<CmdbObjectID, Collection<CmdbData>> objectsToRemoveByHostID, Map<String, CmdbObject> toStringToObjectMap, CmdbClassModel classModel) {
      Map.Entry entry;
      String type;
      Map objectsCollectedToRemove = new HashMap();

      for (Iterator i$ = objectsByType.entrySet().iterator(); i$.hasNext(); ) { entry = (Map.Entry)i$.next();
        type = (String)entry.getKey();
        CmdbObjects objectsForType = (CmdbObjects)entry.getValue();
        for (Iterator i$ = objectsForType.iterator(); i$.hasNext(); ) { CmdbObject currentObject = (CmdbObject)i$.next();
          CmdbObjectID causeIdToRemove = getCauseToRemove(currentObject, objectsToRemoveByHostID, classModel, toStringToObjectMap);
          if (null != causeIdToRemove) {
            CmdbObjectID currentObjectID = (CmdbObjectID)currentObject.getID();
            addToHashMap(objectsCollectedToRemove, type, currentObjectID);
            Collection collectionToRemoveForHost = (Collection)objectsToRemoveByHostID.get(causeIdToRemove);
            if ((!($assertionsDisabled)) && (collectionToRemoveForHost == null)) throw new AssertionError();
            collectionToRemoveForHost.add(currentObject);
            objectsToRemoveByHostID.put(currentObjectID, collectionToRemoveForHost);
          }
        }
      }

      for (i$ = objectsCollectedToRemove.entrySet().iterator(); i$.hasNext(); ) { entry = (Map.Entry)i$.next();
        type = (String)entry.getKey();
        for (Iterator i$ = ((CmdbObjectIds)entry.getValue()).iterator(); i$.hasNext(); ) { CmdbObjectID idToRemove = (CmdbObjectID)i$.next();
          objects.remove(idToRemove);
          CmdbObjects objectsForType = (CmdbObjects)objectsByType.get(type);
          objectsForType.remove(idToRemove);
          if (objectsForType.isEmpty())
            objectsByType.remove(type);
        }
      }
    }

    private CmdbObjectID getCauseToRemove(CmdbObject object, Map<CmdbObjectID, Collection<CmdbData>> objectsToRemoveByHostId, CmdbClassModel classModel, Map<String, CmdbObject> toStringToObjectMap)
    {
      if (objectsToRemoveByHostId.containsKey(object.getID())) {
        return ((CmdbObjectID)object.getID());
      }

      for (Iterator i$ = ModelUtil.getContainedByObjects(object, classModel, toStringToObjectMap).iterator(); i$.hasNext(); ) { CmdbObject containedByObject = (CmdbObject)i$.next();
        if (objectsToRemoveByHostId.containsKey(containedByObject.getID()))
          return ((CmdbObjectID)containedByObject.getID());
      }

      return null;
    }

    private void addToHashMap(Map<String, CmdbObjectIds> map, String type, CmdbObjectID currentObjectID) {
      CmdbObjectIds cmdbObjectIds = (CmdbObjectIds)map.get(type);
      if (null == cmdbObjectIds) {
        cmdbObjectIds = CmdbObjectIdsFactory.create();
        map.put(type, cmdbObjectIds);
      }
      cmdbObjectIds.add(currentObjectID);
    }

    private void addToHashMap(Map<String, CmdbLinks> map, String type, CmdbLink currentLink) {
      CmdbLinks cmdbLinks = (CmdbLinks)map.get(type);
      if (null == cmdbLinks) {
        cmdbLinks = CmdbLinkFactory.createLinks();
        map.put(type, cmdbLinks);
      }
      cmdbLinks.add(currentLink);
    }

    private void cleanLinks(Map<CmdbObjectID, CmdbLinks> linksByEnd1Id, CmdbLinks links, Map<String, CmdbLinks> linksByType, Map<CmdbObjectID, Collection<CmdbData>> objectsToRemoveByHostID) {
      Map.Entry entry;
      String type;
      Map linksCollectedToRemove = new HashMap();

      for (Iterator i$ = linksByType.entrySet().iterator(); i$.hasNext(); ) { entry = (Map.Entry)i$.next();
        type = (String)entry.getKey();
        CmdbLinks linksForType = (CmdbLinks)entry.getValue();
        for (Iterator i$ = linksForType.iterator(); i$.hasNext(); ) { CmdbLink currentLink = (CmdbLink)i$.next();
          Collection byEnd1Collection = (Collection)objectsToRemoveByHostID.get(currentLink.getEnd1());
          Collection byEnd2Collection = (Collection)objectsToRemoveByHostID.get(currentLink.getEnd2());
          if ((byEnd1Collection != null) || (byEnd2Collection != null)) {
            addToHashMap(linksCollectedToRemove, type, currentLink);
            if (null != byEnd1Collection) {
              byEnd1Collection.add(currentLink);
              if ((null != byEnd2Collection) && (byEnd1Collection != byEnd2Collection))
                byEnd2Collection.add(currentLink);
            }
            else {
              byEnd2Collection.add(currentLink);
            }
          }
        }
      }

      for (i$ = linksCollectedToRemove.entrySet().iterator(); i$.hasNext(); ) { entry = (Map.Entry)i$.next();
        type = (String)entry.getKey();
        for (Iterator i$ = ((CmdbLinks)entry.getValue()).iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
          CmdbLinkID linkId = (CmdbLinkID)link.getID();
          links.remove(linkId);
          CmdbLinks cmdbLinks = (CmdbLinks)linksByType.get(type);
          cmdbLinks.remove(linkId);
          if (cmdbLinks.isEmpty())
            linksByType.remove(type);

          CmdbObjectID end1Id = link.getEnd1();
          cmdbLinks = (CmdbLinks)linksByEnd1Id.get(end1Id);
          cmdbLinks.remove(linkId);
          if (cmdbLinks.isEmpty())
            linksByEnd1Id.remove(end1Id);
        }
      }
    }
  }
}