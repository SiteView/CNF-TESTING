package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.IndependentDataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInAnomalyInfo;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import java.util.List;

public abstract interface DataInPreAnalyzeRuleInput
{
  public abstract List<IndependentDataContainer> getDataContainers();

  public abstract InputIdToCmdbDatasMapping getExistingDataMap();

  public abstract List<DataInAnomalyInfo> getDataInAnomalyInfoList();
}