package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.impl.AbstractDataInOperation;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.DataInUpdateOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModelUpdateBulkInfo;

public abstract class AbstractDataInUpdateOperation extends AbstractDataInOperation
  implements DataInUpdateOperation
{
  public static final String BULK_INFO = "bulkInfo";
  private Changer _changer;
  private CmdbModelUpdateBulkInfo _bulkInfo;
  private boolean _userOperation;

  protected AbstractDataInUpdateOperation(Changer changer)
  {
    setChanger(changer);
  }

  public String getExecutionTaskQueueName() {
    return ((isUserOperation()) ? "Reconciliation DataIn User Task" : "Reconciliation DataIn System Task");
  }

  public void dataInExecute(DataInManager dataInManager, CmdbResponse response) throws CmdbException {
    try {
      dataInUpdateExecute(dataInManager, response);
    }
    finally {
      response.addResult("bulkInfo", getBulkInfo());
    }
  }

  public void updateWithResponse(CmdbResponse response) {
    setBulkInfo((CmdbModelUpdateBulkInfo)response.getResult("bulkInfo"));
  }

  protected abstract CmdbModelUpdateBulkInfo sendToModelUpdate(DataInManager paramDataInManager);

  protected Changer getChanger() {
    return this._changer;
  }

  private void setChanger(Changer changer) {
    this._changer = changer;
  }

  public CmdbModelUpdateBulkInfo getBulkInfo() {
    return this._bulkInfo;
  }

  protected void setBulkInfo(CmdbModelUpdateBulkInfo bulkInfo) {
    this._bulkInfo = bulkInfo;
  }

  protected boolean isUserOperation() {
    return this._userOperation;
  }

  public void setUserOperation(boolean userOperation) {
    this._userOperation = userOperation;
  }
}