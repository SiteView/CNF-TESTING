package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.IndependentDataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInAnomalyInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInPreAnalyzeRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import java.util.List;

class DataInPreAnalyzeRuleInputImpl
  implements DataInPreAnalyzeRuleInput
{
  private final List<IndependentDataContainer> _dataContainers;
  private final InputIdToCmdbDatasMapping _existingDataMap;
  private List<DataInAnomalyInfo> _dataInAnomalyInfoList;

  public DataInPreAnalyzeRuleInputImpl(List<IndependentDataContainer> dataContainers, InputIdToCmdbDatasMapping existingDataMap, List<DataInAnomalyInfo> dataInAnomalyInfoList)
  {
    this._dataContainers = dataContainers;
    this._existingDataMap = existingDataMap;
    this._dataInAnomalyInfoList = dataInAnomalyInfoList;
  }

  public List<IndependentDataContainer> getDataContainers() {
    return this._dataContainers;
  }

  public InputIdToCmdbDatasMapping getExistingDataMap() {
    return this._existingDataMap;
  }

  public List<DataInAnomalyInfo> getDataInAnomalyInfoList() {
    return this._dataInAnomalyInfoList;
  }
}