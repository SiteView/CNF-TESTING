package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import java.io.Serializable;
import java.util.ArrayList;

public class And
  implements Serializable
{
  protected ConnectedCiCondition connectedCiCondition;
  protected ArrayList attributeConditionList;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public And()
  {
    this.attributeConditionList = new ArrayList();
  }

  public void addAttributeCondition(AttributeCondition attributeCondition)
  {
    this.attributeConditionList.add(attributeCondition);
  }

  public AttributeCondition getAttributeCondition(int index) {
    return ((AttributeCondition)this.attributeConditionList.get(index));
  }

  public int sizeAttributeConditionList() {
    return this.attributeConditionList.size();
  }

  public ConnectedCiCondition getConnectedCiCondition() {
    return this.connectedCiCondition;
  }

  public void setConnectedCiCondition(ConnectedCiCondition connectedCiCondition) {
    this.connectedCiCondition = connectedCiCondition;
  }
}