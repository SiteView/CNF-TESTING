package com.mercury.topaz.cmdb.reconciliation.server.datain.operation;

import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.CmdbOperation;

public abstract interface DataInOperation extends CmdbOperation
{
  public abstract void dataInExecute(DataInManager paramDataInManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}