package com.mercury.topaz.cmdb.reconciliation.server.config.definition;

import java.io.Serializable;

public abstract interface DataChangeConfigDef extends Serializable
{
  public abstract OwnersConfigDef getOwnersConfigDef();

  public abstract DataChangeRuleConfigDef getRuleConfigDef();
}