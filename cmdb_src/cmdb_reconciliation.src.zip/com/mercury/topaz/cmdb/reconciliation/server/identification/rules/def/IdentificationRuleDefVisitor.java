package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

public abstract interface IdentificationRuleDefVisitor
{
  public abstract void visit(IdentificationRulePatternDef paramIdentificationRulePatternDef);

  public abstract void visit(IdentificationRuleComplexOrDef paramIdentificationRuleComplexOrDef);

  public abstract void visit(IdentificationRuleComplexAndDef paramIdentificationRuleComplexAndDef);
}