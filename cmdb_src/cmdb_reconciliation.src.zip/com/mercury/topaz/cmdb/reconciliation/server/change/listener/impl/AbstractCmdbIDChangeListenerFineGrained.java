package com.mercury.topaz.cmdb.reconciliation.server.change.listener.impl;

import com.mercury.topaz.cmdb.reconciliation.server.change.listener.CmdbIDChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.impl.AbstractCmdbChangeListener;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public abstract class AbstractCmdbIDChangeListenerFineGrained extends AbstractCmdbChangeListener
  implements CmdbIDChangeListenerFineGrained
{
  protected AbstractCmdbIDChangeListenerFineGrained(CmdbCustomerID customerID)
  {
    super(FrameworkConstants.Subsystem.RECONCILIATION, customerID);
  }
}