package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.IdentificationRuleConfig;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;

public class DefaultIdentificationRuleFactory
{
  public static IdentificationRule createDefaultIdentificationRule(IdentificationRuleConfig ruleDef)
  {
    return new DefaultIdentificationRule(ruleDef);
  }
}