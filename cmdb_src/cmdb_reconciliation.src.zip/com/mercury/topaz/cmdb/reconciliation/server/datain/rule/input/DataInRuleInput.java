package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInAnomalyInfo;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract interface DataInRuleInput
{
  public abstract Changer getChanger();

  public abstract String getType();

  public abstract DataContainer getDataContainer();

  public abstract InputIdToCmdbDatasMapping getExistingDataMap();

  public abstract Map<CmdbDataID, CmdbDataIDs> getInputIDToReconciledIDsMap();

  public abstract Map<String, CmdbDataIDs> getInputIDAsStringToReconciledIDsMap();

  public abstract List<DataInInfo> getDataInInfoList();

  public abstract List<DataInAnomalyInfo> getDataInAnomalyInfoList();

  public abstract Set<String> getOwnerByType();

  public abstract Map<CmdbDataID, CmdbDataID> getIdChanges();
}