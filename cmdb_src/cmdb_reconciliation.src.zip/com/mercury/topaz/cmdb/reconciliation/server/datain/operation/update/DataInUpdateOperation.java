package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update;

import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.DataInOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModelUpdateBulkInfo;

public abstract interface DataInUpdateOperation
{
  public abstract void dataInUpdateExecute(DataInManager paramDataInManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;

  public abstract CmdbModelUpdateBulkInfo getBulkInfo();
}