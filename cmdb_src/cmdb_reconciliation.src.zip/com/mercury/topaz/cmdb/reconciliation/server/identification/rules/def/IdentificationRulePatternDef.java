package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

public class IdentificationRulePatternDef extends IdentificationRuleDef
{
  private final PatternElementNumber _elementNumber;
  private AbstractIdentificationRuleConditionDef _identificationRuleConditionDef;
  private Collection<IdentificationRuleConnectedNodeConditionDef> _identificationRuleConnectedNodeConditionDefs;

  public IdentificationRulePatternDef(AbstractIdentificationRuleConditionDef identificationRuleConditionDef, Collection<IdentificationRuleConnectedNodeConditionDef> identificationRuleConnectedNodeConditionDefs)
  {
    this._elementNumber = PatternElementNumberCreator.create();

    this._identificationRuleConditionDef = identificationRuleConditionDef;
    this._identificationRuleConnectedNodeConditionDefs = identificationRuleConnectedNodeConditionDefs;
  }

  public IdentificationRulePatternDef() {
    this(IdentificationRuleEmptyConditionDef.instance(), new ArrayList(1));
  }

  public IdentificationRulePatternDef(IdentificationRuleConnectedNodeConditionDefs identificationRuleConnectedNodeConditionDefs) {
    this(IdentificationRuleEmptyConditionDef.instance(), identificationRuleConnectedNodeConditionDefs);
  }

  public IdentificationRulePatternDef(AbstractIdentificationRuleConditionDef identificationRuleConditionDef) {
    this(identificationRuleConditionDef, new IdentificationRuleConnectedNodeConditionDefs(Collections.emptyList()));
  }

  public IdentificationRulePatternDef(Collection<IdentificationRuleConnectedNodeConditionDef> identificationRuleConnectedNodeConditionDefs) {
    this(new IdentificationRuleConnectedNodeConditionDefs(identificationRuleConnectedNodeConditionDefs));
  }

  public void accept(IdentificationRuleDefVisitor visitor) {
    visitor.visit(this);
  }

  public AbstractIdentificationRuleConditionDef getCondition() {
    return this._identificationRuleConditionDef;
  }

  private AbstractIdentificationRuleConditionDef getConditionForJibX()
  {
    return ((this._identificationRuleConditionDef == IdentificationRuleEmptyConditionDef.instance()) ? null : this._identificationRuleConditionDef);
  }

  public Collection<IdentificationRuleConnectedNodeConditionDef> getConnectedNodeConditions() {
    return this._identificationRuleConnectedNodeConditionDefs;
  }

  public PatternElementNumber getElementNumber() {
    return this._elementNumber;
  }

  public void setCondition(AbstractIdentificationRuleConditionDef identificationRuleConditionDef) {
    if (null == identificationRuleConditionDef)
      return;
    this._identificationRuleConditionDef = identificationRuleConditionDef;
  }

  public void setIdentificationRuleConnectedNodeConditionDefs(IdentificationRuleConnectedNodeConditionDefs identificationRuleConnectedNodeConditionDefs) {
    this._identificationRuleConnectedNodeConditionDefs = identificationRuleConnectedNodeConditionDefs;
  }

  public boolean addToConnectedConditions(IdentificationRuleConnectedNodeConditionDef connectedNodeConditionDef) {
    return getConnectedNodeConditions().add(connectedNodeConditionDef);
  }

  public Iterator<IdentificationRuleConnectedNodeConditionDef> getConnectedConditionsIterator() {
    return getConnectedNodeConditions().iterator();
  }
}