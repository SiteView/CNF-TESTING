package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.exception.ReconciliationException;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ModelUtil;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.TypeVisitor;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBytesType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDateType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDoubleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbFloatType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.Numeric;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreator;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreatorFactory;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalOperator;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyValuesFactory;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbBooleanPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbIntegerPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbLongPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbStringPropertyValues;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ConditionOperator;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableElementPropertiesCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.PropertyCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class Condition
  implements Serializable
{
  private Collection<String> _attributes;
  private Collection<FixedValueAttribute> _fixedValueAttributes;
  private Collection<String> _containersAttributes;
  private boolean _isIdCondition;
  private Collection<ConnectedCondition> _connectedConditions;
  private final PatternElementNumber _elementNumber;

  Condition(Collection<String> attributes, Collection<FixedValueAttribute> fixedValueAttributes, boolean isIdCondition, Collection<ConnectedCondition> connectedConditions)
  {
    this._elementNumber = PatternElementNumberCreator.create();

    this._containersAttributes = new ArrayList(1);
    this._attributes = new ArrayList(attributes.size());
    for (Iterator i$ = attributes.iterator(); i$.hasNext(); ) { String attributeName = (String)i$.next();
      if ("root_container".equals(attributeName))
        this._containersAttributes.add(attributeName);
      else
        this._attributes.add(attributeName);
    }

    this._isIdCondition = isIdCondition;
    this._connectedConditions = new ArrayList(connectedConditions);
    this._fixedValueAttributes = new ArrayList(fixedValueAttributes);
  }

  public Condition(Collection<String> attributes) {
    this(attributes, Collections.emptyList(), false, Collections.emptyList());
  }

  public Condition(Collection<String> attributes, Collection<FixedValueAttribute> fixedValueAttributes) {
    this(attributes, fixedValueAttributes, false, Collections.emptyList());
  }

  public Condition(boolean isIdCondition) {
    this(Collections.emptyList(), Collections.emptyList(), isIdCondition, Collections.emptyList());
  }

  public Condition(Collection<ConnectedCondition> connectedConditions, boolean isIdCondition) {
    this(Collections.emptyList(), Collections.emptyList(), isIdCondition, connectedConditions);
  }

  public Condition() {
    this(Collections.emptyList(), Collections.emptyList(), false, Collections.emptyList());
  }

  public void append(Condition anotherCond) {
    getAttributes().addAll(anotherCond.getAttributes());
    getFixedValueAttributes().addAll(anotherCond.getFixedValueAttributes());
    getContainersAttributes().addAll(anotherCond.getContainersAttributes());
    this._isIdCondition |= anotherCond.isIdCondition();
    getConnectedConditions().addAll(anotherCond.getConnectedConditions());
  }

  public void addToLayoutPattern(ModifiablePattern pattern, String type, PatternElementNumber nodeNumber)
  {
    addNodeToLayoutPattern(pattern, type, nodeNumber);

    for (Iterator i$ = getConnectedConditions().iterator(); i$.hasNext(); ) { ConnectedCondition connectedCondition = (ConnectedCondition)i$.next();
      connectedCondition.addConnectedNodeToLayoutPattern(pattern, nodeNumber);
    }
  }

  protected void addNodeToLayoutPattern(ModifiablePattern pattern, String type, PatternElementNumber nodeNumber)
  {
    ModifiableNodeLinksCondition linksCondition;
    ElementCondition condition = PatternConditionFactory.createElementCondition(type, true);

    boolean hasPreviousDef = pattern.getModifiableGraph().hasDefinitionElement(nodeNumber);
    if (hasPreviousDef) {
      linksCondition = pattern.getModifiableGraph().getModifiableNode(nodeNumber).getModifiableLinksCondition();
    }
    else {
      linksCondition = PatternConditionFactory.createNodeLinksCondition();
    }

    addToNodeLinksCondition(linksCondition);

    PatternNode patternNode = (hasPreviousDef) ? pattern.getModifiableGraph().getModifiableNode(nodeNumber) : PatternGraphFactory.createPatternNode(nodeNumber, condition, true, linksCondition);

    if (!(hasPreviousDef))
      pattern.getModifiableGraph().addNode(patternNode);

    addToLayout(pattern, nodeNumber);
  }

  protected void addToNodeLinksCondition(ModifiableNodeLinksCondition linksCondition) {
    for (Iterator i$ = getConnectedConditions().iterator(); i$.hasNext(); ) { ConnectedCondition connectedCondition = (ConnectedCondition)i$.next();
      if (linksCondition.getNumberOfElements() > 0)
        linksCondition.addLogicalOperator(LogicalOperator.AND);

      linksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(connectedCondition.getLinkElementNumber().getNumber(), 0, -1));
    }
  }

  protected ElementLayout addToLayout(ModifiablePattern pattern, PatternElementNumber nodeNumber) {
    String attributeName;
    ElementLayout elementLayout = pattern.getLayout().getElementLayout(nodeNumber);
    if (elementLayout == null) {
      elementLayout = PatternLayoutFactory.createElementSimpleLayout();
      pattern.getLayout().setElementLayout(nodeNumber, elementLayout);
    }
    for (Iterator i$ = getAttributes().iterator(); i$.hasNext(); ) { attributeName = (String)i$.next();
      elementLayout.addKey(attributeName);
    }
    for (i$ = getFixedValueAttributes().iterator(); i$.hasNext(); ) { FixedValueAttribute fixedValueAttribute = (FixedValueAttribute)i$.next();
      elementLayout.addKey(fixedValueAttribute.getAttributeName());
    }
    for (i$ = getContainersAttributes().iterator(); i$.hasNext(); ) { attributeName = (String)i$.next();
      elementLayout.addKey(attributeName);
    }
    return elementLayout;
  }

  public boolean addToPattern(ModifiablePattern pattern, IdentificationRuleInput input, Map<PatternElementNumber, InputObjectIdentifierToCmdbDataMap<? extends CmdbDataID>> inputObjectsIdentifierToIdsMaps, String targetType, boolean targetTypeDerived, IdentificationScope identificationScope)
  {
    InputObjectIdentifierToCmdbDataMap inputObjectsIdentifierToIdsMap = new InputObjectIdentifierToCmdbDataMap();
    inputObjectsIdentifierToIdsMaps.put(getElementNumber(), inputObjectsIdentifierToIdsMap);

    DataFactory dataFactory = input.getReconciliationRuleEnvironment().getDataFactory();
    CmdbClassModel classModel = dataFactory.getClassModel();
    String typeToIdentify = input.getTypeToIdentify();
    PropertyCreator propertyCreator = PropertyCreatorFactory.create();
    CmdbClass theClass = classModel.getClass(typeToIdentify);
    for (Iterator i$ = getFixedValueAttributes().iterator(); i$.hasNext(); ) { FixedValueAttribute fixedValueAttribute = (FixedValueAttribute)i$.next();
      String attributeName = fixedValueAttribute.getAttributeName();
      CmdbType type = theClass.getAttributeByName(attributeName).getResolvedType();
      CmdbProperty cmdbProperty = propertyCreator.createProperty(type, attributeName, fixedValueAttribute.getValue());
      fixedValueAttribute.setProperty(cmdbProperty);
    }
    DataContainer dataContainer = input.getDataContainer();
    CmdbObjects objectsToIdentify = dataContainer.getObjectsForUpdate(typeToIdentify);
    InputIdToCmdbDatasMapping alreadyIdentifiedData = input.getAlreadyReconciledData();
    CmdbObjects targetObjects = (identificationScope.isContainBulk()) ? createTargetObjects(dataContainer, targetType, targetTypeDerived, classModel) : objectsToIdentify;
    boolean conditionWasAdded = addNode(pattern, dataFactory, inputObjectsIdentifierToIdsMap, targetType, targetTypeDerived, targetObjects, alreadyIdentifiedData, identificationScope);

    for (Iterator i$ = getConnectedConditions().iterator(); i$.hasNext(); ) { ConnectedCondition connectedCondition = (ConnectedCondition)i$.next();
      conditionWasAdded |= connectedCondition.addConnectedNodeToPattern(pattern, getElementNumber(), input, inputObjectsIdentifierToIdsMaps, alreadyIdentifiedData, identificationScope);
    }
    return conditionWasAdded;
  }

  protected boolean addNode(ModifiablePattern pattern, DataFactory dataFactory, InputObjectIdentifierToCmdbDataMap<CmdbObjectID> inputObjectsIdentifierToIdsMap, String type, boolean targetTypeDerived, CmdbObjects objectsToIdentify, InputIdToCmdbDatasMapping identificationMap, IdentificationScope identificationScope)
  {
    Map idToIdentifierMap = new HashMap(objectsToIdentify.size());

    ElementSimpleLayout elementLayout = PatternLayoutFactory.createElementSimpleLayout();

    ElementClassCondition classCondition = PatternConditionFactory.createElementClassCondition(type, targetTypeDerived);
    ModifiableElementPropertiesCondition modifiableElementPropertiesCondition = PatternConditionFactory.createElementPropertiesCondition();

    fillPropertiesCondition(dataFactory.getClassModel(), type, objectsToIdentify, elementLayout, modifiableElementPropertiesCondition, idToIdentifierMap, identificationMap, identificationScope);
    fillIdToIdentifiersMap(idToIdentifierMap, objectsToIdentify, identificationMap, dataFactory, identificationScope);

    CmdbObjectIds objectIdsForCondition = (isIdCondition()) ? createIdsCondition(idToIdentifierMap) : null;
    boolean conditionWasAdded = (objectIdsForCondition != null) || (modifiableElementPropertiesCondition.getNumberOfElements() > 0);

    for (Iterator i$ = objectsToIdentify.iterator(); i$.hasNext(); ) { CmdbObject objectToIdentify = (CmdbObject)i$.next();
      CmdbObjectID id = (CmdbObjectID)objectToIdentify.getID();
      if (!(idToIdentifierMap.containsKey(id)))
        idToIdentifierMap.put(id, createCollection(new InputObjectIdentifier[] { InputObjectIdentifierEmpty.instance() }));

    }

    ModifiableNodeLinksCondition linksCondition = PatternConditionFactory.createNodeLinksCondition();
    ElementCondition condition = PatternConditionFactory.createElementCondition(classCondition, modifiableElementPropertiesCondition, objectIdsForCondition);
    fillObjectsMap(inputObjectsIdentifierToIdsMap, idToIdentifierMap);
    pattern.getModifiableGraph().addNode(PatternGraphFactory.createPatternNode(getElementNumber(), condition, true, linksCondition));
    pattern.getLayout().setElementLayout(getElementNumber(), elementLayout);

    return conditionWasAdded;
  }

  protected void fillPropertiesCondition(CmdbClassModel classModel, String type, CmdbObjects objectsToIdentify, ElementSimpleLayout elementLayout, ModifiableElementPropertiesCondition modifiableElementPropertiesCondition, Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap, InputIdToCmdbDatasMapping alreadyReconciledData, IdentificationScope identificationScope) {
    String attributeName;
    for (Iterator i$ = getAttributes().iterator(); i$.hasNext(); ) { attributeName = (String)i$.next();
      fillPropertiesConditionForAttribute(classModel, type, objectsToIdentify, elementLayout, modifiableElementPropertiesCondition, idToConditionMap, alreadyReconciledData, attributeName, identificationScope);
    }
    for (i$ = getContainersAttributes().iterator(); i$.hasNext(); ) { attributeName = (String)i$.next();
      fillPropertiesConditionForAttribute(classModel, type, objectsToIdentify, elementLayout, modifiableElementPropertiesCondition, idToConditionMap, alreadyReconciledData, attributeName, identificationScope);
    }
    if (classModel.isTypeOf("host", type))
      elementLayout.addKey("host_iscomplete");

    for (i$ = getFixedValueAttributes().iterator(); i$.hasNext(); ) { FixedValueAttribute fixedValueAttribute = (FixedValueAttribute)i$.next();
      String attributeName = fixedValueAttribute.getAttributeName();
      Object value = fixedValueAttribute.getValue();
      CmdbStringPropertyValues propertyValues = CmdbPropertyValuesFactory.createCmdbStringPropertyValues();

      CmdbType attributeCmdbType = classModel.getClass(type).getAttributeByName(attributeName).getResolvedType();
      PropertyConditionValueCreator propertyConditionValueCreator = PropertyConditionValueCreator.getByConditionOperator(ConditionOperator.EQUEL);
      CmdbPropertyValues propertyConditionValue = propertyConditionValueCreator.create(attributeName, attributeCmdbType, type, objectsToIdentify, new HashMap(5), alreadyReconciledData, identificationScope);
      propertyValues.addAll((CmdbStringPropertyValues)propertyConditionValue);

      propertyValues.add((String)value);
      for (Iterator i$ = objectsToIdentify.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
        CmdbProperty property = object.getProperty(attributeName);
        CmdbObjectID id = (CmdbObjectID)object.getID();

        if ((property != null) && (!(property.isValueEmpty()))) {
          String valueFromProperty = (String)property.getValue();
          propertyValues.add(valueFromProperty);
        }
        addFixedPropertyToMap(idToConditionMap, id, fixedValueAttribute);
      }

      elementLayout.addKey(attributeName);
    }
  }

  private void fillPropertiesConditionForAttribute(CmdbClassModel classModel, String type, CmdbObjects objectsToIdentify, ElementSimpleLayout elementLayout, ModifiableElementPropertiesCondition modifiableElementPropertiesCondition, Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap, InputIdToCmdbDatasMapping alreadyReconciledData, String attributeName, IdentificationScope identificationScope) {
    elementLayout.addKey(attributeName);
    CmdbType attributeCmdbType = classModel.getClass(type).getAttributeByName(attributeName).getResolvedType();
    PropertyConditionValueCreator propertyConditionValueCreator = PropertyConditionValueCreator.getByConditionOperator(ConditionOperator.EQUEL);
    CmdbPropertyValues propertyConditionValue = propertyConditionValueCreator.create(attributeName, attributeCmdbType, type, objectsToIdentify, idToConditionMap, alreadyReconciledData, identificationScope);
    if (!(propertyConditionValue.isEmpty())) {
      PropertyCondition propertyCondition = PatternConditionFactory.createPropertyCondition(attributeName, propertyConditionValueCreator.getOutputOperator(), propertyConditionValue, false);
      addPropertyCondition(modifiableElementPropertiesCondition, propertyCondition);
    }
  }

  private void addPropertyCondition(ModifiableElementPropertiesCondition modifiableElementPropertiesCondition, PropertyCondition propertyCondition) {
    if (modifiableElementPropertiesCondition.getNumberOfElements() > 0)
      modifiableElementPropertiesCondition.addLogicalOperator(LogicalOperator.AND);

    modifiableElementPropertiesCondition.addPropertyCondition(propertyCondition);
  }

  protected CmdbObjectIds createIdsCondition(Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap) {
    CmdbObjectIds idsCondition = CmdbObjectIdsFactory.create();
    for (Iterator i$ = idToConditionMap.values().iterator(); i$.hasNext(); ) { Collection identifiersCollection = (Collection)i$.next();
      for (Iterator i$ = identifiersCollection.iterator(); i$.hasNext(); ) { InputObjectIdentifier identifier = (InputObjectIdentifier)i$.next();
        CmdbObjectID id = (CmdbObjectID)identifier.getId();
        if (null != id)
          idsCondition.add(id);
      }
    }

    return idsCondition;
  }

  private void fillIdToIdentifiersMap(Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap, CmdbObjects objects, InputIdToCmdbDatasMapping identificationMap, DataFactory dataFactory, IdentificationScope identificationScope) {
    if (isIdCondition())
      for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
        Collection objectRealIDsTemp = getObjectWithRealId(object, identificationScope, identificationMap, dataFactory);
        if (identificationScope.isContainBulk()) {
          Collection objectRealIDs = new ArrayList(objectRealIDsTemp.size() + 1);
          objectRealIDs.addAll(objectRealIDsTemp);
          objectRealIDs.add(object);
          fillIdToIdentifiersMap(idToConditionMap, (CmdbObjectID)object.getID(), objectRealIDs);
        } else {
          fillIdToIdentifiersMap(idToConditionMap, (CmdbObjectID)object.getID(), objectRealIDsTemp);
        }
      }
  }

  private Collection<CmdbObject> getObjectWithRealId(CmdbObject object, IdentificationScope identificationScope, InputIdToCmdbDatasMapping identificationMap, DataFactory dataFactory)
  {
    Collection objectRealIDs = identificationScope.getResults(identificationMap, (CmdbDataID)object.getID());
    return ((null != objectRealIDs) ? objectRealIDs : ModelUtil.createObjectWithRealId(object, identificationMap, dataFactory, identificationScope));
  }

  private void fillIdToIdentifiersMap(Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap, CmdbObjectID id, Collection<CmdbObject> objectRealIDs) {
    for (Iterator i$ = objectRealIDs.iterator(); i$.hasNext(); ) { CmdbObject realObject = (CmdbObject)i$.next();
      CmdbObjectID objectRealID = (CmdbObjectID)realObject.getID();
      Collection identifiers = (Collection)idToConditionMap.get(id);
      if ((null == identifiers) || (identifiers.isEmpty())) {
        identifiers = new ArrayList(1);
        identifiers.add(new InputObjectIdentifierSimple(objectRealID));
        idToConditionMap.put(id, identifiers);
      } else {
        for (Iterator i$ = identifiers.iterator(); i$.hasNext(); ) { InputObjectIdentifier identifier = (InputObjectIdentifier)i$.next();
          identifier.setId(objectRealID);
        }
      }
    }
  }

  protected static void fillObjectsMap(InputObjectIdentifierToCmdbDataMap<CmdbObjectID> conditionToIdsMap, Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap) {
    for (Iterator i$ = idToConditionMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      CmdbObjectID id = (CmdbObjectID)entry.getKey();
      Collection identifiers = (Collection)entry.getValue();
      for (Iterator i$ = identifiers.iterator(); i$.hasNext(); ) { InputObjectIdentifier identifier = (InputObjectIdentifier)i$.next();
        conditionToIdsMap.addToMap(identifier, id);
      }
    }
  }

  protected static void fillLinksMap(InputObjectIdentifierToCmdbDataMap<CmdbLinkID> conditionToIdsMap, Map<CmdbDataID, InputObjectIdentifier> idToConditionMap) {
    for (Iterator i$ = idToConditionMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      CmdbLinkID id = (CmdbLinkID)entry.getKey();
      InputObjectIdentifier condition = (InputObjectIdentifier)entry.getValue();

      conditionToIdsMap.addToMap(condition, id);
    }
  }

  public void identify(IdentificationRuleInput input, TqlResultMap resultMap, Map<PatternElementNumber, InputObjectIdentifierToCmdbDataMap<? extends CmdbDataID>> inputObjectsIdentifiersToIdsMap, IdentificationScope identificationScope, String targetType, boolean targetTypeDerived, boolean shouldIncludeSiblings) {
    DataContainer dataContainer = input.getDataContainer();
    String typeToIdentify = input.getTypeToIdentify();
    CmdbClassModel classModel = input.getReconciliationRuleEnvironment().getCmdbClassModel();
    InputIdToCmdbDatasMapping identifiedData = input.getAlreadyReconciledData();

    if (identificationScope.isContainCMDB()) {
      identifyExistingInCMDB(resultMap, dataContainer, identifiedData, inputObjectsIdentifiersToIdsMap, classModel, shouldIncludeSiblings);
    }

    if (identificationScope.isContainBulk())
      identifyExistingInBulk(dataContainer, identifiedData, typeToIdentify, inputObjectsIdentifiersToIdsMap, targetType, targetTypeDerived, shouldIncludeSiblings, classModel);
  }

  private CmdbObjects createTargetObjects(DataContainer dataContainer, String targetType, boolean targetTypeDerived, CmdbClassModel classModel)
  {
    CmdbObjects targetObjects = CmdbObjectFactory.createObjects();
    for (Iterator iter = dataContainer.getObjectsForUpdateIteratorByType(); iter.hasNext(); ) {
      Map.Entry entry = (Map.Entry)iter.next();
      if (entry.getValue() != null)
        for (Iterator i$ = ((CmdbObjects)entry.getValue()).iterator(); i$.hasNext(); ) { CmdbObject currentObject = (CmdbObject)i$.next();
          String type = currentObject.getType();
          if (targetTypeDerived) if (!(classModel.isTypeOf(targetType, type))) continue; 
          else if (!(type.equals(targetType))) continue;
          targetObjects.add(currentObject);
        }

    }

    return targetObjects;
  }

  private void identifyExistingInCMDB(TqlResultMap resultMap, DataContainer dataContainer, InputIdToCmdbDatasMapping identifiedData, Map<PatternElementNumber, InputObjectIdentifierToCmdbDataMap<? extends CmdbDataID>> inputObjectsIdentifiersToIdsMap, CmdbClassModel classModel, boolean shouldIncludeSiblings) {
    if (resultMap.containsElementNumber(getElementNumber())) {
      CmdbObjects mainObjectsFromCmdb = resultMap.getObjects(getElementNumber());
      if ((getConnectedConditions() == null) || (getConnectedConditions().isEmpty()))
      {
        InputObjectIdentifierToCmdbDataMap identifiersToIdsMap = (InputObjectIdentifierToCmdbDataMap)inputObjectsIdentifiersToIdsMap.get(getElementNumber());

        identifyInCmdbByOneNodeOnly(mainObjectsFromCmdb, identifiedData, identifiersToIdsMap, dataContainer, shouldIncludeSiblings, classModel);
      }
      else {
        identifyInCmdbByTopology(resultMap, dataContainer, mainObjectsFromCmdb, identifiedData, inputObjectsIdentifiersToIdsMap, shouldIncludeSiblings, classModel);
      }
    }
  }

  private void identifyInCmdbByOneNodeOnly(CmdbObjects mainObjectsFromCmdb, InputIdToCmdbDatasMapping identifiedData, InputObjectIdentifierToCmdbDataMap<CmdbObjectID> inputObjectsIdentifiersToIdsMap, DataContainer dataContainer, boolean shouldIncludeSiblings, CmdbClassModel classModel)
  {
    for (Iterator i$ = mainObjectsFromCmdb.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
      Collection identifiers = createIdentifier(object);
      for (Iterator i$ = identifiers.iterator(); i$.hasNext(); ) { InputObjectIdentifier identifier = (InputObjectIdentifier)i$.next();
        Set mainObjectsDataIDs = inputObjectsIdentifiersToIdsMap.get(identifier);
        if (mainObjectsDataIDs != null)
          for (Iterator i$ = mainObjectsDataIDs.iterator(); i$.hasNext(); ) { CmdbDataID id = (CmdbObjectID)i$.next();
            CmdbObject objectToIdentify = dataContainer.getCmdbObject((CmdbObjectID)id);

            if (identifier.equals(objectToIdentify, object))
            {
              addToIdentifiedData(identifiedData.get(id), object, objectToIdentify.getType(), shouldIncludeSiblings, classModel);
            }
          }
      }
    }
  }

  private void identifyInCmdbByTopology(TqlResultMap resultMap, DataContainer dataContainer, CmdbObjects mainObjectsFromCmdb, InputIdToCmdbDatasMapping identifiedData, Map<PatternElementNumber, InputObjectIdentifierToCmdbDataMap<? extends CmdbDataID>> inputObjectsIdentifiersToIdsMap, boolean shouldIncludeSiblings, CmdbClassModel classModel)
  {
    InputObjectIdentifierToCmdbDataMap mainObjectIdentifiersToCmdbDataMap = (InputObjectIdentifierToCmdbDataMap)inputObjectsIdentifiersToIdsMap.get(getElementNumber());

    for (Iterator i$ = getConnectedConditions().iterator(); i$.hasNext(); ) { ConnectedCondition connectedCondition = (ConnectedCondition)i$.next();
      if (resultMap.containsElementNumber(connectedCondition.getLinkElementNumber()))
      {
        InputObjectIdentifierToCmdbDataMap linkIdentifierToCmdbDataMap = (InputObjectIdentifierToCmdbDataMap)inputObjectsIdentifiersToIdsMap.get(connectedCondition.getLinkElementNumber());

        InputObjectIdentifierToCmdbDataMap connectedObjectsIdentifierToCmdbDataMap = (InputObjectIdentifierToCmdbDataMap)inputObjectsIdentifiersToIdsMap.get(connectedCondition.getElementNumber());

        Direction direction = connectedCondition.getDirection();
        Map linksByTarget = getLinksByTarget(linkIdentifierToCmdbDataMap.values(), dataContainer, direction);

        CmdbObjects connectedObjects = resultMap.getObjects(connectedCondition.getElementNumber());
        CmdbLinks links = resultMap.getLinks(connectedCondition.getLinkElementNumber());
        for (Iterator i$ = links.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
          CmdbObject mainObject = (CmdbObject)mainObjectsFromCmdb.get(direction.getSource(link));
          CmdbObject connectedObject = (CmdbObject)connectedObjects.get(direction.getTarget(link));

          Collection mainObjectIdentifiers = createIdentifier(mainObject);
          InputObjectIdentifier linkCondition = connectedCondition.createLinkIdentifier();
          Collection connectedObjectIdentifiers = connectedCondition.createIdentifier(connectedObject);

          for (Iterator i$ = mainObjectIdentifiers.iterator(); i$.hasNext(); ) { InputObjectIdentifier mainObjectIdentifier = (InputObjectIdentifier)i$.next();
            for (Iterator i$ = connectedObjectIdentifiers.iterator(); i$.hasNext(); ) { InputObjectIdentifier connectedObjectIdentifier = (InputObjectIdentifier)i$.next();

              Set inputMainObjectsDataIDs = mainObjectIdentifiersToCmdbDataMap.get(mainObjectIdentifier);
              Set inputLinks = linkIdentifierToCmdbDataMap.get(linkCondition);
              Set inputConnectedObjectsDataIDs = connectedObjectsIdentifierToCmdbDataMap.get(connectedObjectIdentifier);

              if ((inputConnectedObjectsDataIDs != null) && (!(inputConnectedObjectsDataIDs.isEmpty())))
              {
                Iterator i$;
                if (inputLinks.size() < inputConnectedObjectsDataIDs.size())
                  for (i$ = inputLinks.iterator(); i$.hasNext(); ) { CmdbLinkID inputLinkId = (CmdbLinkID)i$.next();
                    CmdbLink inputLink = dataContainer.getCmdbLink(inputLinkId);
                    CmdbObjectID sourceId = direction.getSource(inputLink);
                    CmdbObjectID targetId = direction.getTarget(inputLink);
                    CmdbObject sourceCI = dataContainer.getCmdbObject(sourceId);
                    CmdbObject targetCI = dataContainer.getCmdbObject(targetId);

                    if ((inputMainObjectsDataIDs.contains(sourceId)) && (inputConnectedObjectsDataIDs.contains(targetId)) && 
                      (mainObjectIdentifier.equals(sourceCI, mainObject)) && (connectedObjectIdentifier.equals(targetCI, connectedObject)))
                    {
                      addToIdentifiedData(identifiedData.get(sourceId), mainObject, sourceCI.getType(), shouldIncludeSiblings, classModel);
                    }
                  }

                else
                  for (i$ = inputConnectedObjectsDataIDs.iterator(); i$.hasNext(); ) { CmdbObjectID inputEnd2ObjectID = (CmdbObjectID)i$.next();
                    CmdbLinks inputLinksForConnectedObject = (CmdbLinks)linksByTarget.get(inputEnd2ObjectID);
                    for (Iterator i$ = inputLinksForConnectedObject.iterator(); i$.hasNext(); ) { CmdbLink inputLink = (CmdbLink)i$.next();
                      if (inputMainObjectsDataIDs.contains(direction.getSource(inputLink))) {
                        CmdbObjectID sourceId = direction.getSource(inputLink);
                        CmdbObjectID targetId = direction.getTarget(inputLink);
                        CmdbObject sourceCI = dataContainer.getCmdbObject(sourceId);
                        CmdbObject targetCI = dataContainer.getCmdbObject(targetId);

                        if ((mainObjectIdentifier.equals(sourceCI, mainObject)) && (connectedObjectIdentifier.equals(targetCI, connectedObject)))
                        {
                          addToIdentifiedData(identifiedData.get(sourceId), mainObject, sourceCI.getType(), shouldIncludeSiblings, classModel);
                        }
                      }
                    }
                  }
              }
            }
          }
        }
      }
    }
  }

  private void addToIdentifiedData(Collection<CmdbObject> identifiedObjects, CmdbObject objectToAdd, String inputCIType, boolean shouldIncludeSiblings, CmdbClassModel classModel)
  {
    for (Iterator i$ = identifiedObjects.iterator(); i$.hasNext(); ) { CmdbObject currentObject = (CmdbObject)i$.next();
      if (((CmdbObjectID)currentObject.getID()).equals(objectToAdd.getID()))
        return;
    }

    if ((!(shouldIncludeSiblings)) && (!(classModel.isTypeOf(objectToAdd.getType(), inputCIType))) && (!(classModel.isTypeOf(inputCIType, objectToAdd.getType()))))
      return;

    identifiedObjects.add(objectToAdd);
  }

  private void identifyExistingInBulk(DataContainer dataContainer, InputIdToCmdbDatasMapping identifiedData, String typeToIdentify, Map<PatternElementNumber, InputObjectIdentifierToCmdbDataMap<? extends CmdbDataID>> inputObjectsIdentifiersToIdsMap, String targetType, boolean targetTypeDerived, boolean shouldIncludeSiblings, CmdbClassModel classModel) {
    if ((getConnectedConditions() == null) || (getConnectedConditions().isEmpty()))
    {
      identifyInBulkByOneNodeOnly(dataContainer, identifiedData, typeToIdentify, createTargetObjects(dataContainer, targetType, targetTypeDerived, classModel), shouldIncludeSiblings, classModel);
    }
    else
      identifyInBulkByTopology(dataContainer, identifiedData, inputObjectsIdentifiersToIdsMap);
  }

  private void identifyInBulkByOneNodeOnly(DataContainer dataContainer, InputIdToCmdbDatasMapping identifiedData, String typeToIdentify, CmdbObjects targetObjects, boolean shouldIncludeSiblings, CmdbClassModel classModel)
  {
    CmdbObjects objectsToIdentify = dataContainer.getObjectsForUpdate(typeToIdentify);
    Map inputIdToIdentifiersMap = new HashMap(objectsToIdentify.size());
    Map originalIdentifierToIdMap = new HashMap(objectsToIdentify.size());
    for (Iterator i$ = objectsToIdentify.iterator(); i$.hasNext(); ) { CmdbObject objectToIdentify = (CmdbObject)i$.next();
      CmdbObjectID id = (CmdbObjectID)objectToIdentify.getID();

      addToMapValueCollection(originalIdentifierToIdMap, createIdentifier(objectToIdentify), id);
      inputIdToIdentifiersMap.put(id, createIdentifierInBulk(objectToIdentify, identifiedData));
    }
    for (i$ = targetObjects.iterator(); i$.hasNext(); ) { CmdbObject targetObject = (CmdbObject)i$.next();
      addToMapValueCollection(originalIdentifierToIdMap, createIdentifier(targetObject), targetObject.getID());
    }
    for (i$ = inputIdToIdentifiersMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      CmdbObjectID idToIdentify = (CmdbObjectID)entry.getKey();
      CmdbObject objectToIdentify = dataContainer.getCmdbObject(idToIdentify);
      for (Iterator i$ = ((Collection)entry.getValue()).iterator(); i$.hasNext(); ) { InputObjectIdentifier identifier = (InputObjectIdentifier)i$.next();
        if (!(InputObjectIdentifierUnknown.instance().equals(identifier))) {
          Collection identifiedIds = (Collection)originalIdentifierToIdMap.get(identifier);
          if (null != identifiedIds)
            for (Iterator i$ = identifiedIds.iterator(); i$.hasNext(); ) { CmdbObjectID identifiedId = (CmdbObjectID)i$.next();
              if (!(idToIdentify.equals(identifiedId))) {
                CmdbObject identifiedObject = dataContainer.getCmdbObject(identifiedId);
                if (identifier.equals(objectToIdentify, identifiedObject))
                {
                  addToIdentifiedData(identifiedData.getInBulk(idToIdentify), identifiedObject, objectToIdentify.getType(), shouldIncludeSiblings, classModel);
                }
              }
            }
        }
      }
    }
  }

  private static <KeyType, ValueType> void addToMapValueCollection(Map<KeyType, Collection<ValueType>> map, Collection<KeyType> keys, ValueType value)
  {
    for (Iterator i$ = keys.iterator(); i$.hasNext(); ) { Object key = i$.next();
      Collection idsForIdentifier = (Collection)map.get(key);
      if (null == idsForIdentifier) {
        idsForIdentifier = new HashSet(1);
        map.put(key, idsForIdentifier);
      }
      idsForIdentifier.add(value);
    }
  }

  private Map<CmdbObjectID, CmdbLinks> getLinksByTarget(Collection<Set<CmdbLinkID>> setsOfLinks, DataContainer dataContainer, Direction direction) {
    Map linksByTarget = new HashMap(setsOfLinks.size());
    for (Iterator i$ = setsOfLinks.iterator(); i$.hasNext(); ) { Set links = (Set)i$.next();
      for (Iterator i$ = links.iterator(); i$.hasNext(); ) { CmdbLinkID linkId = (CmdbLinkID)i$.next();
        CmdbLink link = dataContainer.getCmdbLink(linkId);

        addToMap(linksByTarget, direction.getTarget(link), link);
      }
    }
    return linksByTarget;
  }

  private void identifyInBulkByTopology(DataContainer dataContainer, InputIdToCmdbDatasMapping identifiedData, Map<PatternElementNumber, InputObjectIdentifierToCmdbDataMap<? extends CmdbDataID>> inputObjectsIdentifiersToIdsMap)
  {
    InputObjectIdentifierToCmdbDataMap mainObjectIdentifierToCmdbDataMap = (InputObjectIdentifierToCmdbDataMap)inputObjectsIdentifiersToIdsMap.get(getElementNumber());

    for (Iterator i$ = getConnectedConditions().iterator(); i$.hasNext(); ) { ConnectedCondition connectedCondition = (ConnectedCondition)i$.next();
      Direction direction = connectedCondition.getDirection();
      PatternElementNumber linkNumber = connectedCondition.getLinkElementNumber();
      PatternElementNumber connectedCiElementNumber = connectedCondition.getElementNumber();

      InputObjectIdentifierToCmdbDataMap linkIdentifierToCmdbDataMap = (InputObjectIdentifierToCmdbDataMap)inputObjectsIdentifiersToIdsMap.get(linkNumber);

      InputObjectIdentifierToCmdbDataMap connectedIdentifierToCmdbDataMap = (InputObjectIdentifierToCmdbDataMap)inputObjectsIdentifiersToIdsMap.get(connectedCiElementNumber);

      Map linksByEnd2Map = getLinksByTarget(linkIdentifierToCmdbDataMap.values(), dataContainer, direction);
      for (Iterator i$ = connectedIdentifierToCmdbDataMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        InputObjectIdentifier targetIdentifier = (InputObjectIdentifier)entry.getKey();
        Set objectIds = (Set)entry.getValue();
        CmdbLinks linksToIdentify = CmdbLinkFactory.createLinks();
        for (Iterator i$ = objectIds.iterator(); i$.hasNext(); ) { CmdbObjectID targetIdToIdentify = (CmdbObjectID)i$.next();
          CmdbLinks cmdbLinks = (CmdbLinks)linksByEnd2Map.get(targetIdToIdentify);
          if (cmdbLinks != null)
            linksToIdentify.add(cmdbLinks);
        }

        for (i$ = linksToIdentify.iterator(); i$.hasNext(); ) { CmdbLink linkToIdentify = (CmdbLink)i$.next();
          InputObjectIdentifier linkCondition = connectedCondition.createLinkIdentifier();
          Set linksForCondition = linkIdentifierToCmdbDataMap.get(linkCondition);

          CmdbObjectID sourceIdToIdentify = direction.getSource(linkToIdentify);
          CmdbObject sourceToIdentify = dataContainer.getCmdbObject(sourceIdToIdentify);
          Collection sourceIdentifiers = createIdentifier(sourceToIdentify);

          CmdbObjectID targetIdToIdentify = direction.getTarget(linkToIdentify);
          CmdbObject targetToIdentify = dataContainer.getCmdbObject(targetIdToIdentify);

          for (Iterator i$ = sourceIdentifiers.iterator(); i$.hasNext(); ) { InputObjectIdentifier sourceIdentifier = (InputObjectIdentifier)i$.next();
            Set sourceObjectIdsForCondition = mainObjectIdentifierToCmdbDataMap.get(sourceIdentifier);

            for (Iterator i$ = linksToIdentify.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
              if ((linksForCondition.contains(link.getID())) && (sourceObjectIdsForCondition.contains(direction.getSource(link))) && (!(((CmdbLinkID)link.getID()).equals(linkToIdentify.getID())))) {
                CmdbObject theIdentifiedObject = dataContainer.getCmdbObject(direction.getSource(link));
                CmdbObjectID identifiedTargetId = direction.getTarget(link);
                CmdbObject identifiedTarget = dataContainer.getCmdbObject(identifiedTargetId);

                if ((sourceIdentifier.equals(sourceToIdentify, theIdentifiedObject)) && (targetIdentifier.equals(targetToIdentify, identifiedTarget)))
                {
                  identifiedData.getInBulk(sourceIdToIdentify).add(theIdentifiedObject);
                }
              }
            }
          }
        }
      }
    }
  }

  protected Collection<InputObjectIdentifier> createIdentifier(CmdbObject object) {
    Collection attributes = getAttributes();
    Collection containerAttributes = getContainersAttributes();
    Collection fixedValueAttributes = getFixedValueAttributes();
    if (isIdCondition())
      return createIdentifier(object, (CmdbDataID)object.getID(), fixedValueAttributes, new Collection[] { attributes, containerAttributes });

    if ((!(attributes.isEmpty())) || (!(containerAttributes.isEmpty())) || (!(fixedValueAttributes.isEmpty()))) {
      return createIdentifier(object, fixedValueAttributes, new Collection[] { attributes, containerAttributes });
    }

    return createCollection(new InputObjectIdentifier[] { InputObjectIdentifierEmpty.instance() });
  }

  private static Collection<InputObjectIdentifier> createIdentifier(CmdbData<?> data, CmdbDataID id, Collection<FixedValueAttribute> fixedValueAttributes, Collection<String>[] attributess) {
    Collection identifiers = createIdentifier(data, fixedValueAttributes, attributess);
    for (Iterator i$ = identifiers.iterator(); i$.hasNext(); ) { InputObjectIdentifier identifier = (InputObjectIdentifier)i$.next();
      identifier.setId(id);
    }
    return identifiers;
  }

  private static Collection<InputObjectIdentifier> createIdentifier(CmdbData<?> data, Collection<FixedValueAttribute> fixedValueAttributes, Collection<String>[] attributess) {
    InputObjectIdentifier identifier = new InputObjectIdentifierSimple();
    Collection[] arr$ = attributess; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Collection attributes = arr$[i$];
      for (Iterator i$ = attributes.iterator(); i$.hasNext(); ) { String attributeName = (String)i$.next();
        CmdbProperty cmdbProperty = data.getProperty(attributeName);
        if ((null == cmdbProperty) || (cmdbProperty.isValueEmpty()))
          return createCollection(new InputObjectIdentifier[] { InputObjectIdentifierUnknown.instance() });

        identifier.add(cmdbProperty);
      }
    }
    for (Iterator i$ = fixedValueAttributes.iterator(); i$.hasNext(); ) { FixedValueAttribute fixedValueAttribute = (FixedValueAttribute)i$.next();
      identifier.addFixedValue(fixedValueAttribute);
    }
    Collection identifiers = new ArrayList(1);
    identifiers.add(identifier);
    return identifiers;
  }

  private static Collection<InputObjectIdentifier> createIdentifiersInBulk(CmdbData<?> data, Collection<String> attributes, Collection<String> containersAttributes, Collection<FixedValueAttribute> fixedValueAttributes, InputIdToCmdbDatasMapping identifiedData) {
    InputObjectIdentifier identifier = new InputObjectIdentifierSimple();
    for (Iterator i$ = attributes.iterator(); i$.hasNext(); ) { String attributeName = (String)i$.next();
      CmdbProperty cmdbProperty = data.getProperty(attributeName);
      if ((null == cmdbProperty) || (cmdbProperty.isValueEmpty()))
        return createCollection(new InputObjectIdentifier[] { InputObjectIdentifierUnknown.instance() });

      identifier.add(cmdbProperty);
    }
    for (i$ = fixedValueAttributes.iterator(); i$.hasNext(); ) { FixedValueAttribute fixedValueAttribute = (FixedValueAttribute)i$.next();
      identifier.addFixedValue(fixedValueAttribute);
    }
    Collection identifiers = new ArrayList(Math.max(containersAttributes.size(), 1) * (int)Math.pow(2.0D, fixedValueAttributes.size()));
    identifiers.add(identifier);
    for (Iterator i$ = containersAttributes.iterator(); i$.hasNext(); ) { String attributeName = (String)i$.next();
      CmdbProperty cmdbProperty = data.getProperty(attributeName);
      if ((null == cmdbProperty) || (cmdbProperty.isValueEmpty()))
        return createCollection(new InputObjectIdentifier[] { InputObjectIdentifierUnknown.instance() });

      String containingObjectId = (String)cmdbProperty.getValue();
      Collection existingDatas = identifiedData.getInBulk(containingObjectId);
      List containerProperties = createAllContainingPropertiesForAttribute(attributeName, cmdbProperty, existingDatas);
      addPropertiesToIdentifiers(identifiers, containerProperties);
    }
    return identifiers;
  }

  private static List<CmdbProperty> createAllContainingPropertiesForAttribute(String attributeName, CmdbProperty originalProperty, Collection<? extends CmdbData> existingDatas) {
    if (existingDatas == null)
      existingDatas = Collections.emptyList();

    List allRootContainersProperties = new ArrayList(existingDatas.size());
    allRootContainersProperties.add(originalProperty);
    for (Iterator i$ = existingDatas.iterator(); i$.hasNext(); ) { CmdbData currentExistingData = (CmdbData)i$.next();
      String newContainingObjectIdString = currentExistingData.getDataID().toString();
      CmdbProperty newProperty = CmdbPropertyFactory.createProperty(attributeName, newContainingObjectIdString);
      allRootContainersProperties.add(newProperty);
    }
    return allRootContainersProperties;
  }

  private Collection<InputObjectIdentifier> createIdentifierInBulk(CmdbObject objectToIdentify, InputIdToCmdbDatasMapping identifiedData) {
    return createIdentifiersInBulk(objectToIdentify, getAttributes(), getContainersAttributes(), getFixedValueAttributes(), identifiedData);
  }

  private static <Type> void addToMap(Map<Type, CmdbLinks> map, Type key, CmdbLink link) {
    CmdbLinks cmdbLinks = (CmdbLinks)map.get(key);
    if (null == cmdbLinks) {
      cmdbLinks = CmdbLinkFactory.createLinks();
      map.put(key, cmdbLinks);
    }
    cmdbLinks.add(link);
  }

  public Collection<String> getContainersAttributes() {
    return this._containersAttributes;
  }

  public Collection<String> getAttributes() {
    return this._attributes;
  }

  public boolean isIdCondition() {
    return this._isIdCondition;
  }

  public Collection<ConnectedCondition> getConnectedConditions() {
    return this._connectedConditions;
  }

  public PatternElementNumber getElementNumber() {
    return this._elementNumber;
  }

  public void setAttributes(Collection<String> attributes) {
    this._attributes = attributes;
  }

  public void setConnectedConditions(Collection<ConnectedCondition> connectedConditions) {
    this._connectedConditions = connectedConditions;
  }

  public Collection<FixedValueAttribute> getFixedValueAttributes() {
    return this._fixedValueAttributes;
  }

  private static void addPropertyToMap(Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap, CmdbDataID dataID, CmdbProperty cmdbProperty)
  {
    Collection conditions = (Collection)idToConditionMap.get(dataID);
    if (null == conditions) {
      conditions = new ArrayList(1);
      conditions.add(new InputObjectIdentifierSimple());
      idToConditionMap.put(dataID, conditions);
    }
    for (Iterator i$ = conditions.iterator(); i$.hasNext(); ) { InputObjectIdentifier identifier = (InputObjectIdentifier)i$.next();
      identifier.add(cmdbProperty);
    }
  }

  private static void addFixedPropertyToMap(Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap, CmdbDataID dataID, FixedValueAttribute fixedValueAttribute) {
    Collection conditions = (Collection)idToConditionMap.get(dataID);
    if (null == conditions) {
      conditions = new ArrayList(1);
      conditions.add(new InputObjectIdentifierSimple());
      idToConditionMap.put(dataID, conditions);
    }
    for (Iterator i$ = conditions.iterator(); i$.hasNext(); ) { InputObjectIdentifier identifier = (InputObjectIdentifier)i$.next();
      identifier.addFixedValue(fixedValueAttribute);
    }
  }

  private static Collection<InputObjectIdentifier> addPropertiesToIdentifiers(Collection<InputObjectIdentifier> oldIdentifiers, List<CmdbProperty> properties)
  {
    Set newIdentifiers;
    if ((null == oldIdentifiers) || (oldIdentifiers.isEmpty())) {
      oldIdentifiers = new ArrayList(1);
      oldIdentifiers.add(new InputObjectIdentifierSimple());
      newIdentifiers = new HashSet(properties.size());
    } else {
      newIdentifiers = new HashSet(oldIdentifiers.size() * properties.size());
    }

    for (Iterator i$ = oldIdentifiers.iterator(); i$.hasNext(); ) { InputObjectIdentifier identifier = (InputObjectIdentifier)i$.next();
      int lastIndex = properties.size() - 1;
      for (int i = 0; i < lastIndex; ++i) {
        CmdbProperty cmdbProperty = (CmdbProperty)properties.get(i);
        InputObjectIdentifier newIdentifier = identifier.clone();
        newIdentifier.add(cmdbProperty);
        newIdentifiers.add(newIdentifier);
      }

      if (lastIndex >= 0) {
        CmdbProperty cmdbProperty = (CmdbProperty)properties.get(lastIndex);
        identifier.add(cmdbProperty);
        newIdentifiers.add(identifier);
      }
    }

    oldIdentifiers.clear();
    oldIdentifiers.addAll(newIdentifiers);
    return oldIdentifiers;
  }

  private static <Type> Collection<Type> createCollection(Type[] values) {
    Collection ans = new ArrayList(values.length);
    ans.addAll(Arrays.asList(values));
    return ans;
  }

  protected static class CmdbPropertyValuesCreatorVisitor<IDType extends CmdbDataID, Type extends CmdbData<IDType>>
  implements TypeVisitor
  {
    private final String _attributeName;
    private final CmdbDatas<IDType, Type> _data;
    private CmdbPropertyValues _values;
    private final Map<CmdbDataID, Collection<InputObjectIdentifier>> _idToConditionMap;
    private final InputIdToCmdbDatasMapping _identificationMap;
    private final IdentificationScope _identificationScope;

    public CmdbPropertyValuesCreatorVisitor(String attributeName, CmdbDatas<IDType, Type> data, Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap, InputIdToCmdbDatasMapping identificationMap, IdentificationScope identificationScope)
    {
      this._attributeName = attributeName;
      this._data = data;
      this._idToConditionMap = idToConditionMap;
      this._identificationMap = identificationMap;
      this._identificationScope = identificationScope;
    }

    public CmdbPropertyValues getValues() {
      return this._values;
    }

    public void visit(CmdbSimpleType simpleCmdbType) {
    }

    public void visit(Numeric numericType) {
    }

    public void visit(CmdbIntegerType integerType) {
      CmdbIntegerPropertyValues cmdbIntegerPropertyValues = CmdbPropertyValuesFactory.createCmdbIntegerPropertyValues();
      for (Iterator i$ = this._data.iterator(); i$.hasNext(); ) { CmdbData currObject = (CmdbData)i$.next();
        CmdbProperty cmdbProperty = currObject.getProperty(this._attributeName);
        if ((null != cmdbProperty) && (!(cmdbProperty.isValueEmpty()))) {
          cmdbIntegerPropertyValues.add((Integer)cmdbProperty.getValue());
          Condition.access$100(this._idToConditionMap, currObject.getDataID(), cmdbProperty);
        } else {
          this._idToConditionMap.put(currObject.getDataID(), Condition.access$200(new InputObjectIdentifier[] { InputObjectIdentifierUnknown.instance() }));
        }
      }
      this._values = cmdbIntegerPropertyValues;
    }

    public void visit(CmdbLongType longType) {
      CmdbLongPropertyValues cmdbLongPropertyValues = CmdbPropertyValuesFactory.createCmdbLongPropertyValues();
      for (Iterator i$ = this._data.iterator(); i$.hasNext(); ) { CmdbData currObject = (CmdbData)i$.next();
        CmdbProperty cmdbProperty = currObject.getProperty(this._attributeName);
        if ((null != cmdbProperty) && (!(cmdbProperty.isValueEmpty()))) {
          cmdbLongPropertyValues.add((Long)cmdbProperty.getValue());
          Condition.access$100(this._idToConditionMap, currObject.getDataID(), cmdbProperty);
        } else {
          this._idToConditionMap.put(currObject.getDataID(), Condition.access$200(new InputObjectIdentifier[] { InputObjectIdentifierUnknown.instance() }));
        }
      }
      this._values = cmdbLongPropertyValues;
    }

    public void visit(CmdbFloatType floatType) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbDoubleType doubleType) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbStringType stringType) {
      Iterator i$;
      CmdbData currObject;
      CmdbProperty cmdbProperty;
      CmdbStringPropertyValues cmdbStringPropertyValues = CmdbPropertyValuesFactory.createCmdbStringPropertyValues();
      if ("root_container".equals(this._attributeName))
        for (i$ = this._data.iterator(); i$.hasNext(); ) { currObject = (CmdbData)i$.next();
          cmdbProperty = currObject.getProperty(this._attributeName);
          if ((null != cmdbProperty) && (!(cmdbProperty.isValueEmpty()))) {
            String containerId = (String)cmdbProperty.getValue();
            Collection existingContainingObjects = this._identificationScope.getResults(this._identificationMap, containerId);
            List allRootContainersProperties = new ArrayList(extractSize(existingContainingObjects) + 1);
            if (null == existingContainingObjects) {
              allRootContainersProperties.add(cmdbProperty);
            } else {
              addContainingObjectId(cmdbStringPropertyValues, allRootContainersProperties, containerId);
              for (Iterator i$ = existingContainingObjects.iterator(); i$.hasNext(); ) { CmdbData data = (CmdbData)i$.next();
                String newContainingObjectIdString = data.getDataID().toString();
                addContainingObjectId(cmdbStringPropertyValues, allRootContainersProperties, newContainingObjectIdString);
              }
            }
            addPropertiesToMap(this._idToConditionMap, currObject.getDataID(), allRootContainersProperties);
          } else {
            this._idToConditionMap.put(currObject.getDataID(), Condition.access$200(new InputObjectIdentifier[] { InputObjectIdentifierUnknown.instance() }));
          }
        }
      else
        for (i$ = this._data.iterator(); i$.hasNext(); ) { currObject = (CmdbData)i$.next();
          cmdbProperty = currObject.getProperty(this._attributeName);
          if ((null != cmdbProperty) && (!(cmdbProperty.isValueEmpty()))) {
            cmdbStringPropertyValues.add((String)cmdbProperty.getValue());
            Condition.access$100(this._idToConditionMap, currObject.getDataID(), cmdbProperty);
          } else {
            this._idToConditionMap.put(currObject.getDataID(), Condition.access$200(new InputObjectIdentifier[] { InputObjectIdentifierUnknown.instance() }));
          }
        }

      this._values = cmdbStringPropertyValues;
    }

    private void addContainingObjectId(CmdbStringPropertyValues cmdbStringPropertyValues, List<CmdbProperty> allRootContainersProperties, String newContainingObjectIdString) {
      cmdbStringPropertyValues.add(newContainingObjectIdString);
      CmdbProperty newProperty = CmdbPropertyFactory.createProperty(this._attributeName, newContainingObjectIdString);
      allRootContainersProperties.add(newProperty);
    }

    private int extractSize(Collection<?> col) {
      return ((col == null) ? 0 : col.size());
    }

    public void visit(CmdbXmlType xmlType) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbBooleanType cmdbBooleanType) {
      CmdbBooleanPropertyValues cmdbBooleanPropertyValues = CmdbPropertyValuesFactory.createCmdbBooleanPropertyValues();
      for (Iterator i$ = this._data.iterator(); i$.hasNext(); ) { CmdbData currObject = (CmdbData)i$.next();
        CmdbProperty cmdbProperty = currObject.getProperty(this._attributeName);
        if ((null != cmdbProperty) && (!(cmdbProperty.isValueEmpty()))) {
          cmdbBooleanPropertyValues.add((Boolean)cmdbProperty.getValue());
          Condition.access$100(this._idToConditionMap, currObject.getDataID(), cmdbProperty);
        } else {
          this._idToConditionMap.put(currObject.getDataID(), Condition.access$200(new InputObjectIdentifier[] { InputObjectIdentifierUnknown.instance() }));
        }
      }
      this._values = cmdbBooleanPropertyValues;
    }

    public void visit(CmdbDateType cmdbDateType) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbBytesType cmdbBytesType) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbSimpleList cmdbSimpleList) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbStringListType cmdbStringListType) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbIntegerListType cmdbIntegerListType) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbTypeDef typeDef) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbEnum cmdbEnum) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbList cmdbList) {
      throw new ReconciliationException("method not implemented!!!");
    }

    public void visit(CmdbExternalResource externalResource) {
      throw new ReconciliationException("method not implemented!!!");
    }

    private void addPropertiesToMap(Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap, CmdbDataID dataID, List<CmdbProperty> properties) {
      if (properties.isEmpty())
        return;
      Collection identifiers = (Collection)idToConditionMap.get(dataID);
      identifiers = Condition.access$300(identifiers, properties);
      idToConditionMap.put(dataID, identifiers);
    }
  }

  protected static abstract enum PropertyConditionValueCreator
  {
    private static final Map<ConditionOperator, PropertyConditionValueCreator> map;

    public static final PropertyConditionValueCreator[] values()
    {
      return ((PropertyConditionValueCreator[])$VALUES.clone());
    }

    public abstract <IDType extends CmdbDataID, Type extends CmdbData<IDType>> CmdbPropertyValues create(String paramString1, CmdbType paramCmdbType, String paramString2, CmdbDatas<IDType, Type> paramCmdbDatas, Map<CmdbDataID, Collection<InputObjectIdentifier>> paramMap, InputIdToCmdbDatasMapping paramInputIdToCmdbDatasMapping, IdentificationScope paramIdentificationScope);

    public abstract ConditionOperator[] getSupportedOperators();

    public abstract ConditionOperator getOutputOperator();

    public static PropertyConditionValueCreator getByConditionOperator(ConditionOperator conditionOperator)
    {
      return ((PropertyConditionValueCreator)map.get(conditionOperator));
    }

    static
    {
      EQUAL = new PropertyConditionValueCreator("EQUAL", 0) {
        public <IDType extends CmdbDataID, Type extends CmdbData<IDType>> CmdbPropertyValues create(String attributeName, CmdbType attributeCmdbType, String type, CmdbDatas<IDType, Type> data, Map<CmdbDataID, Collection<InputObjectIdentifier>> idToConditionMap, InputIdToCmdbDatasMapping alreadyReconciledData, IdentificationScope identificationScope) {
          Condition.CmdbPropertyValuesCreatorVisitor typeVisitor = new Condition.CmdbPropertyValuesCreatorVisitor(attributeName, data, idToConditionMap, alreadyReconciledData, identificationScope);
          attributeCmdbType.accept(typeVisitor);
          return typeVisitor.getValues(); }

        public ConditionOperator[] getSupportedOperators() {
          return { ConditionOperator.EQUEL }; }

        public ConditionOperator getOutputOperator() {
          return ConditionOperator.IN;
        }
      };
      $VALUES = { EQUAL };

      PropertyConditionValueCreator[] propertyConditionValueCreators = values();
      map = new HashMap(propertyConditionValueCreators.length);
      PropertyConditionValueCreator[] arr$ = propertyConditionValueCreators; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { PropertyConditionValueCreator propertyConditionValueCreator = arr$[i$];
        ConditionOperator[] arr$ = propertyConditionValueCreator.getSupportedOperators(); int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { ConditionOperator operator = arr$[i$];
          if ((!($assertionsDisabled)) && (map.containsKey(operator))) throw new AssertionError("2 PropertyConditionValueCreator(s) cannot support the same ConditionOperator!");
          map.put(operator, propertyConditionValueCreator);
        }
      }
    }
  }
}