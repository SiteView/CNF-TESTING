package com.mercury.topaz.cmdb.reconciliation.server.identification.rules;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.util.Collection;

public enum IdentificationScope
{
  CMDB, BULK, ALL;

  public static final IdentificationScope[] values()
  {
    return ((IdentificationScope[])$VALUES.clone());
  }

  public abstract boolean isContainCMDB();

  public abstract boolean isContainBulk();

  public abstract <IDType extends CmdbDataID, Type extends CmdbData<IDType>> Collection<Type> getResults(InputIdToCmdbDatasMapping paramInputIdToCmdbDatasMapping, IDType paramIDType);

  public abstract <IDType extends CmdbDataID, Type extends CmdbData<IDType>> Collection<Type> getResults(InputIdToCmdbDatasMapping paramInputIdToCmdbDatasMapping, String paramString);
}