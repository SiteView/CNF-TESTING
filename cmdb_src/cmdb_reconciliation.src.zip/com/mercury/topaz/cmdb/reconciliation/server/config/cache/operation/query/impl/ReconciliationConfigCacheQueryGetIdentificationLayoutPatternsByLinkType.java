package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import java.io.Serializable;
import java.util.Collection;

public class ReconciliationConfigCacheQueryGetIdentificationLayoutPatternsByLinkType extends AbstractReconciliationConfigCacheQueryOperation
{
  public static final String LAYOUT_PATTERNS = "layoutPatterns";
  private String _linkType;
  private Collection<Pattern> _layoutPatterns;

  public ReconciliationConfigCacheQueryGetIdentificationLayoutPatternsByLinkType(String linkType)
  {
    setLinkType(linkType);
  }

  public String getOperationName() {
    return "Reconciliation Config Cache Query - Get Identification Layout Patterns By Link Type";
  }

  public void configCacheQueryExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response) throws CmdbException
  {
    setLayoutPatterns(configCacheManager.getIdentificationLayoutPatternForLinkType(getLinkType(), configCacheManager.getSynchronizedClassModel()));
    response.addResult("layoutPatterns", (Serializable)getLayoutPatterns());
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setLayoutPatterns((Collection)response.getResult("layoutPatterns"));
  }

  private String getLinkType() {
    return this._linkType;
  }

  private void setLinkType(String linkType) {
    this._linkType = linkType;
  }

  public Collection<Pattern> getLayoutPatterns() {
    return this._layoutPatterns;
  }

  private void setLayoutPatterns(Collection<Pattern> layoutPatterns) {
    this._layoutPatterns = layoutPatterns;
  }
}