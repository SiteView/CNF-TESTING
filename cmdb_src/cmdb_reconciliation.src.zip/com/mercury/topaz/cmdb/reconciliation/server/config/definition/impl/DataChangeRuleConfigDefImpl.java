package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ConfigurationParamConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.DataChangeRuleConfigDef;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class DataChangeRuleConfigDefImpl
  implements DataChangeRuleConfigDef, IUnmarshallable, IMarshallable
{
  private String _className;
  private Collection<ConfigurationParamConfigDef> _configurationParams;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public DataChangeRuleConfigDefImpl()
  {
    setConfigurationParams(new ArrayList());
  }

  public void addConfigParam(Object param) {
    getConfigurationParams().add((ConfigurationParamConfigDef)param);
  }

  public Iterator getIterator() {
    return getConfigurationParams().iterator();
  }

  public Collection<ConfigurationParamConfigDef> getConfigurationParams() {
    return this._configurationParams;
  }

  public void setConfigurationParams(Collection<ConfigurationParamConfigDef> configurationParams) {
    this._configurationParams = configurationParams;
  }

  public String getClassName() {
    return this._className;
  }

  public void setClassName(String className) {
    this._className = className;
  }
}