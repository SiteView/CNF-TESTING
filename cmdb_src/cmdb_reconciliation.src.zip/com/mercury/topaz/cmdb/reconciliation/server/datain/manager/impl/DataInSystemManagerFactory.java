package com.mercury.topaz.cmdb.reconciliation.server.datain.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.change.listener.impl.ReconciliationJMSAdapter;
import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;

public class DataInSystemManagerFactory extends AbstractSubsystemManagerFactory
{
  public static final String NAME = "Reconciliation DataIn System Task";

  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new DataInSystemManagerImpl(localEnvironment);
  }

  private static class DataInSystemManagerImpl extends CmdbSubsystemManagerImpl
  implements DataInManager, SingleReadSingleWrite
  {
    private CmdbChangeListenerCorseGrained _reconciliationChangesAdapter;

    DataInSystemManagerImpl(LocalEnvironment localEnvironment) {
      super(localEnvironment);
      this._reconciliationChangesAdapter = new ReconciliationJMSAdapter(localEnvironment.getGlobalEnvironment().getJmsPublisher(), getCustomerID());
    }

    public void startUp() {
      registerListener(this._reconciliationChangesAdapter);
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation DataIn System Manager is started up properly !!!");
    }

    public void shutdown() {
      unregisterListener(this._reconciliationChangesAdapter);
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation DataIn System Manager is shutdown up properly !!!");
    }

    public String getName() {
      return "Reconciliation DataIn System Task";
    }
  }
}