package com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.update;

import com.mercury.topaz.cmdb.reconciliation.server.config.admin.manager.ReconciliationConfigAdminManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.ReconciliationConfigAdminOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;

public abstract interface ReconciliationConfigUpdateAdminOperation
{
  public abstract void configUpdateExecute(ReconciliationConfigAdminManager paramReconciliationConfigAdminManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}