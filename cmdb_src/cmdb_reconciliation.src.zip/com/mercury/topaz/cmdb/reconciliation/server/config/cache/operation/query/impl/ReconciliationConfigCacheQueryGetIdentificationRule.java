package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.io.Serializable;
import java.util.Collection;

public class ReconciliationConfigCacheQueryGetIdentificationRule extends AbstractReconciliationConfigCacheQueryOperation
{
  public static final String IDENTIFICATION_RULE = "identificationRule";
  private String _type;
  private Collection<IdentificationRule> _identificationRule;

  public ReconciliationConfigCacheQueryGetIdentificationRule(String type)
  {
    setType(type);
  }

  public String getOperationName() {
    return "Reconciliation Config Cache Query - Get Identification Rule for " + getType();
  }

  public void configCacheQueryExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response) throws CmdbException {
    CmdbClassModel classModel = configCacheManager.getSynchronizedClassModel();
    Collection identificationRules = configCacheManager.getIdentificationRuleByType(getType(), classModel);
    setIdentificationRule(identificationRules);
    response.addResult("identificationRule", (Serializable)identificationRules);
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
    setIdentificationRule((Collection)response.getResult("identificationRule"));
  }

  public Collection<IdentificationRule> getIdentificationRule() {
    return this._identificationRule;
  }

  private void setIdentificationRule(Collection<IdentificationRule> identificationRule) {
    this._identificationRule = identificationRule;
  }

  private String getType() {
    return this._type;
  }

  private void setType(String type) {
    this._type = type;
  }
}