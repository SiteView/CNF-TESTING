package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.command.impl;

import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import java.util.Collection;
import java.util.List;

public class MergeCIsPropertiesOperation extends AbstractMergeDataPropertiesOperation<CmdbObjectID, CmdbObject>
{
  public MergeCIsPropertiesOperation(Collection<MergeInput<CmdbObject>> input)
  {
    super(input);
  }

  protected MergeCIsPropertiesOperation(List<MergeInput<CmdbObject>> input, CmdbClassModel classModel)
  {
    this(input);
    setClassModel(classModel);
  }

  protected CmdbObject merge(MergeInput<CmdbObject> datas, String mergedType, CmdbDataID mergedID, CmdbProperties mergedProperties) throws CmdbException
  {
    return CmdbObjectFactory.createObject((CmdbObjectID)mergedID, mergedType, mergedProperties);
  }

  public String getOperationName() {
    return "Merge CIs Properties";
  }
}