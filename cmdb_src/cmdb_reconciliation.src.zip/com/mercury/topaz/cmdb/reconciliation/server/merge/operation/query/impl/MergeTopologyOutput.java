package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl;

import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import java.io.Serializable;

public class MergeTopologyOutput
  implements Serializable
{
  private final CmdbObjects _objectsToRemove;
  private final CmdbObjects _objectsToAdd;
  private final CmdbLinks _linksToRemove;
  private final CmdbLinks _linksToAdd;

  public MergeTopologyOutput()
  {
    this._objectsToRemove = CmdbObjectFactory.createHashMapObjects();
    this._objectsToAdd = CmdbObjectFactory.createHashMapObjects();
    this._linksToRemove = CmdbLinkFactory.createLinks();
    this._linksToAdd = CmdbLinkFactory.createLinks();
  }

  public CmdbObjects getObjectsToRemove() {
    return this._objectsToRemove;
  }

  public CmdbObjects getObjectsToAdd() {
    return this._objectsToAdd;
  }

  public CmdbLinks getLinksToRemove() {
    return this._linksToRemove;
  }

  public CmdbLinks getLinksToAdd() {
    return this._linksToAdd;
  }
}