package com.mercury.topaz.cmdb.reconciliation.server.config.definition;

import java.io.Serializable;

public abstract interface ConfigurationParamConfigDef extends Serializable
{
  public abstract String getParamName();

  public abstract String getValue();
}