package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class IdentificationRuleProprietaryConfig extends AbstractIdentificationRuleConfig
  implements IUnmarshallable, IMarshallable
{
  protected String className;
  private String _StringConfiguration;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public String getClassName()
  {
    return this.className;
  }

  public void setClassName(String className) {
    this.className = className;
  }

  public String getStringConfiguration() {
    return this._StringConfiguration;
  }

  public void setStringConfiguration(String stringConfiguration) {
    this._StringConfiguration = stringConfiguration;
  }
}