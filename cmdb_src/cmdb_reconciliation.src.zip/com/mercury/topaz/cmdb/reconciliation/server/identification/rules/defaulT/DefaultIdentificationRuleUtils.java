package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.And;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.AttributeCondition;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.CiIdCondition;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.ConnectedCiCondition;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.IdentificationRuleConfig;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.Or;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

class DefaultIdentificationRuleUtils
{
  static Collection<Condition> createConditions(IdentificationRuleConfig ruleDef)
  {
    Collection allConditions = new LinkedList();
    allConditions.addAll(createConditions(ruleDef.getAnd()));
    allConditions.addAll(createConditions(ruleDef.getAttributeCondition()));
    allConditions.addAll(createConditions(ruleDef.getOr()));
    allConditions.addAll(createConditions(ruleDef.getConnectedCiCondition()));
    return allConditions;
  }

  private static Collection<Condition> createConditions(ConnectedCiCondition connectedCiCondition) {
    if (null == connectedCiCondition)
      return Collections.emptyList();
    Collection allConditions = new LinkedList();
    allConditions.addAll(createConditions(connectedCiCondition.getAnd()));
    allConditions.addAll(createConditions(connectedCiCondition.getAttributeCondition()));
    allConditions.addAll(createConditions(connectedCiCondition.getOr()));
    allConditions.addAll(createConditions(connectedCiCondition.getCiIdCondition()));

    Collection ans = new ArrayList(allConditions.size());

    String linkType = connectedCiCondition.getLinkType();
    String ciType = connectedCiCondition.getCiType();
    boolean isLinkDirectionForward = connectedCiCondition.getIsDirectionForward();
    for (Iterator i$ = allConditions.iterator(); i$.hasNext(); ) { Condition cond = (Condition)i$.next();
      Condition condition = new Condition(false);
      ConnectedCondition connectedCondition = new ConnectedCondition(cond, linkType, isLinkDirectionForward, ciType);
      Collection connectedConditions = Arrays.asList(new ConnectedCondition[] { connectedCondition });
      condition.setConnectedConditions(connectedConditions);
      ans.add(condition);
    }
    return ans;
  }

  private static Collection<Condition> createConditions(CiIdCondition ciIdCondition) {
    if (null == ciIdCondition)
      return Collections.emptyList();
    return Arrays.asList(new Condition[] { new Condition(true) });
  }

  private static Collection<Condition> createConditions(Or or) {
    if (null == or)
      return Collections.emptyList();
    Collection allConditions = new LinkedList();
    for (int i = 0; i < or.sizeAndList(); ++i)
      allConditions.addAll(createConditions(or.getAnd(i)));
    for (i = 0; i < or.sizeAttributeConditionList(); ++i)
      allConditions.addAll(createConditions(or.getAttributeCondition(i)));
    allConditions.addAll(createConditions(or.getConnectedCiCondition()));
    return allConditions;
  }

  private static Collection<Condition> createConditions(AttributeCondition attributeCondition) {
    Condition cond;
    if (null == attributeCondition)
      return Collections.emptyList();
    String attributeName = attributeCondition.getAttributeName();
    String fixedValue = attributeCondition.getFixedValue();

    if (fixedValue != null) {
      FixedValueAttribute fixedValueAttribute = new FixedValueAttribute(attributeName, fixedValue);
      List fixedValueAttributes = Arrays.asList(new FixedValueAttribute[] { fixedValueAttribute });
      cond = new Condition(Collections.emptyList(), fixedValueAttributes);
    } else {
      List stringList = Arrays.asList(new String[] { attributeName });
      cond = new Condition(stringList);
    }
    return Arrays.asList(new Condition[] { cond });
  }

  private static Collection<Condition> createConditions(And and) {
    if (null == and)
      return Collections.emptyList();

    Collection allConditionsToAnd = new ArrayList(and.sizeAttributeConditionList() + 1);

    for (int i = 0; i < and.sizeAttributeConditionList(); ++i)
      allConditionsToAnd.add(createConditions(and.getAttributeCondition(i)));
    Collection connectedCiConditions = createConditions(and.getConnectedCiCondition());

    if (!(connectedCiConditions.isEmpty()))
      allConditionsToAnd.add(connectedCiConditions);

    Collection permutations = GeneralUtils.getAllPermutations(allConditionsToAnd);
    Collection ans = new ArrayList(permutations.size());
    for (Iterator i$ = permutations.iterator(); i$.hasNext(); ) { Collection col = (Collection)i$.next();
      Condition cond = new Condition();
      for (Iterator i$ = col.iterator(); i$.hasNext(); ) { Condition currCond = (Condition)i$.next();
        cond.append(currCond);
      }
      ans.add(cond);
    }
    return ans;
  }
}