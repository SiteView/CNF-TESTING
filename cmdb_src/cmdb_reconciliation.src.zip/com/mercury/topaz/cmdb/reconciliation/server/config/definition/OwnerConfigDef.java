package com.mercury.topaz.cmdb.reconciliation.server.config.definition;

import java.io.Serializable;

public abstract interface OwnerConfigDef extends Serializable
{
  public abstract String getName();
}