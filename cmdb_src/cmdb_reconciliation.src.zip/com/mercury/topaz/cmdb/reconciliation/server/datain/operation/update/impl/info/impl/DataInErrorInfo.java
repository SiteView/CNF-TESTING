package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;

public class DataInErrorInfo
  implements DataInInfo
{
  private String _shortMessage;

  public DataInErrorInfo(String shortMessage)
  {
    this._shortMessage = shortMessage;
  }

  public String getShortMessage() {
    return this._shortMessage;
  }
}