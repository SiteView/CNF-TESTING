package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.ReconciliationConfigCacheOperation;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCmdbOperation;

public abstract class AbstractReconciliationConfigCacheOperation extends AbstractCmdbOperation
  implements ReconciliationConfigCacheOperation
{
  protected void doExecute(SubsystemManager manager, CmdbResponse response)
    throws CmdbException
  {
    configCacheExecute((ReconciliationConfigCacheManager)manager, response);
  }

  public String getExecutionTaskQueueName() {
    return "Reconciliation Config Cache Task";
  }

  public String getServiceName() {
    return "CMDB_RECONCILE";
  }
}