package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.OwnerConfigDef;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class OwnerConfigDefImpl
  implements OwnerConfigDef, IUnmarshallable, IMarshallable
{
  private String _name;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public String getName()
  {
    return this._name;
  }

  public void setName(String name) {
    this._name = name;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    OwnerConfigDefImpl that = (OwnerConfigDefImpl)o;

    if (this._name != null) if (this._name.equals(that._name)) break label62;
    label62: return (that._name == null);
  }

  public int hashCode()
  {
    return ((this._name != null) ? this._name.hashCode() : 0);
  }
}