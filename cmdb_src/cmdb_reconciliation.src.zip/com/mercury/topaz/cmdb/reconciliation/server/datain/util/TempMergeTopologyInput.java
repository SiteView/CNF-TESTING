package com.mercury.topaz.cmdb.reconciliation.server.datain.util;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import java.util.Collection;

public class TempMergeTopologyInput<Type extends CmdbData> extends TempMergeInput<Type>
{
  public TempMergeTopologyInput(Type remainingObject, Collection<Type> datasFromCmdb)
  {
    super(remainingObject, datasFromCmdb);
  }
}