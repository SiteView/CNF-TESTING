package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;

abstract class TypeOfObject
  implements TypeOfData<CmdbObjectID, CmdbObject>
{
  public final CmdbObject createData(CmdbObject oldData, CmdbObjectID newId, String classType, CmdbProperties newProperties, OldToNewIdMapping oldToNewIdMapping)
  {
    return CmdbObjectFactory.createObject(newId, classType, newProperties);
  }

  public final CmdbObject createData(CmdbObject oldData, String classType, CmdbProperties properties, DataFactory dataFactory, OldToNewIdMapping oldToNewIdMapping) {
    CmdbObject newObject = dataFactory.createObject(classType, properties);
    CmdbObjectID oldId = (CmdbObjectID)oldData.getID();
    CmdbObjectID newId = (CmdbObjectID)newObject.getID();
    if (!(oldId.equals(newId)))
      oldToNewIdMapping.put(oldId, newId);

    return newObject;
  }
}