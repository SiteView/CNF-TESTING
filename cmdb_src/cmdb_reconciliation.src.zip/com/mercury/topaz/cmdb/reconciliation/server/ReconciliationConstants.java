package com.mercury.topaz.cmdb.reconciliation.server;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;

public class ReconciliationConstants
{
  public static final String CIT_NAME_HOST = "host";
  public static final String CIT_NAME_IP = "ip";
  public static final String CIT_NAME_CSG = "clusteredservice";
  public static final String CIT_NAME_SOFTWARE_ELEMENT = "application";
  public static final String CIT_NAME_MONITOR = "monitor";
  public static final String CIT_NAME_CONTAINED = "contained";
  public static final String CIT_NAME_MONITOR_LINK = "monitored_by";
  public static final String ATTRIBUTE_NAME_ROOT_CONTAINER = "root_container";
  public static final String ATTRIBUTE_QUALIFIER_NAME_CONTAINED_BY = CmdbAttributeQualifierDefs.CONTAINED_BY.getName();
  public static final String ATTRIBUTE_NAME_HOST_IS_COMPLETE = "host_iscomplete";
  public static final String ATTRIBUTE_NAME_HOST_KEY = "host_key";
  public static final String ATTRIBUTE_NAME_DISPLAY_LABEL = "display_label";
  public static final String ATTRIBUTE_NAME_HOST_IS_VIRTUAL = "host_isvirtual";
  public static final String ATTRIBUTE_NAME_IP_DOMAIN = "ip_domain";
  public static final String ATTRIBUTE_NAME_APPLICATION_IP = "application_ip";
  public static final String ATTRIBUTE_NAME_PROCESS_COMMAND_LINE = "process_cmdline";
  public static final String DISCOVERY_DS = "UCMDBDiscovery";
  public static final String RECONCILIATION_CONFIG_CIT = "reconciliation_configuration";
  public static final String RECONCILIATION_CONFIG_ATTR_NAME = "configuration";
  public static final String DATA_IN_MORE_THAN_ONE_MATCH_PARAM_NAME = "more-than-one-match";
  public static final String DATA_IN_MORE_THAN_ONE_MATCH_PARAM_IGNORE_VALUE = "IGNORE";
  public static final String DATA_IN_MORE_THAN_ONE_MATCH_PARAM_ERROR_VALUE = "ERROR";
  public static final String DATA_IN_MORE_THAN_ONE_MATCH_PARAM_DEFAULT_VALUE = "IGNORE";
  public static final String SHOULD_RUN_UPGRADE_PARAM_NAME = "reconciliation.should.run.upgrade";
}