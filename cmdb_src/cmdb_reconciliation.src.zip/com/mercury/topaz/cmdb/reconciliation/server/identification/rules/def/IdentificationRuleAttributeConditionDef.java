package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ConditionOperator;

public class IdentificationRuleAttributeConditionDef
{
  private String _attributeName;
  private ConditionOperator _conditionOperator;

  public IdentificationRuleAttributeConditionDef(String attributeName, ConditionOperator conditionOperator)
  {
    this._attributeName = attributeName;
    this._conditionOperator = conditionOperator;
  }

  public String getAttributeName() {
    return this._attributeName;
  }

  public ConditionOperator getConditionOperator() {
    return this._conditionOperator;
  }

  public void setAttributeName(String attributeName) {
    this._attributeName = attributeName;
  }

  public void setConditionOperatorFromString(String conditionOperatorString) {
    this._conditionOperator = ConditionOperator.fromString(conditionOperatorString);
  }

  public String getConditionOperatorString() {
    return getConditionOperator().toString();
  }
}