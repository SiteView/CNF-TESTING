package com.mercury.topaz.cmdb.reconciliation.server.id.object.impl;

import com.mercury.topaz.cmdb.reconciliation.server.id.object.TempCmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.id.impl.CmdbRandomID;

public class TempObjectIDFactory
{
  public static TempCmdbObjectID createTempObjectID(String id)
  {
    return new TempCmdbObjectIDImpl(id); }

  public static TempCmdbObjectID createTempObjectID() {
    return new TempCmdbObjectIDImpl(CmdbRandomID.getRandomString());
  }
}