package com.mercury.topaz.cmdb.reconciliation.server.config.exception;

import com.mercury.topaz.cmdb.reconciliation.server.exception.ReconciliationException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;

public class ReconciliationConfigException extends ReconciliationException
{
  public ReconciliationConfigException(String message)
  {
    super(message);
  }

  public ReconciliationConfigException(String message, ErrorCode errorCode) {
    super(message, errorCode);
  }

  public ReconciliationConfigException(String message, Throwable cause) {
    super(message, cause);
  }

  public ReconciliationConfigException(String message, Throwable cause, ErrorCode errorCode) {
    super(message, cause, errorCode);
  }

  public ReconciliationConfigException(Throwable cause) {
    super(cause);
  }

  public ReconciliationConfigException(Throwable cause, ErrorCode errorCode) {
    super(cause, errorCode);
  }
}