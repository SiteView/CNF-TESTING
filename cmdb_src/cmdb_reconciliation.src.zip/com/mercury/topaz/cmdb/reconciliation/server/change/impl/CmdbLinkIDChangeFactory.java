package com.mercury.topaz.cmdb.reconciliation.server.change.impl;

import com.mercury.topaz.cmdb.reconciliation.server.change.CmdbLinkIDChange;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;

public class CmdbLinkIDChangeFactory
{
  public static CmdbLinkIDChange createLinkIDChange(CmdbLinkID oldID, CmdbLinkID newID)
  {
    return new CmdbLinkIDChangeImpl(oldID, newID);
  }
}