package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;

public class IdentificationRuleConnectedNodeConditionDef
{
  private String _ciType;
  private String _linkType;
  private AbstractIdentificationRuleConditionDef _condition;
  private AbstractIdentificationRuleConditionDef _linkCondition;
  private final PatternElementNumber _elementNumber;
  private final PatternElementNumber _linkElementNumber;

  public IdentificationRuleConnectedNodeConditionDef(String ciType, AbstractIdentificationRuleConditionDef condition, String linkType, AbstractIdentificationRuleConditionDef linkCondition)
  {
    this._elementNumber = PatternElementNumberCreator.create();
    this._linkElementNumber = PatternElementNumberCreator.create();

    this._ciType = ciType;
    this._linkType = linkType;
    this._condition = condition;
    this._linkCondition = linkCondition;
  }

  public IdentificationRuleConnectedNodeConditionDef() {
    this(null, IdentificationRuleEmptyConditionDef.instance(), null, IdentificationRuleEmptyConditionDef.instance());
  }

  public IdentificationRuleConnectedNodeConditionDef(String ciType, AbstractIdentificationRuleConditionDef identificationRuleConditionDefs, String linkType) {
    this(ciType, identificationRuleConditionDefs, linkType, IdentificationRuleEmptyConditionDef.instance());
  }

  public IdentificationRuleConnectedNodeConditionDef(String ciType, String linkType, AbstractIdentificationRuleConditionDef linkCondition) {
    this(ciType, IdentificationRuleEmptyConditionDef.instance(), linkType, linkCondition);
  }

  public String getCiType() {
    return this._ciType;
  }

  public String getLinkType() {
    return this._linkType;
  }

  private AbstractIdentificationRuleConditionDef getConditionForJibX()
  {
    return ((this._condition == IdentificationRuleEmptyConditionDef.instance()) ? null : this._condition);
  }

  public AbstractIdentificationRuleConditionDef getCondition() {
    return this._condition;
  }

  private AbstractIdentificationRuleConditionDef getLinkConditionForJibX()
  {
    return ((this._linkCondition == IdentificationRuleEmptyConditionDef.instance()) ? null : this._linkCondition);
  }

  public AbstractIdentificationRuleConditionDef getLinkCondition() {
    return this._linkCondition;
  }

  public PatternElementNumber getElementNumber() {
    return this._elementNumber;
  }

  public PatternElementNumber getLinkElementNumber() {
    return this._linkElementNumber;
  }

  public void setCiType(String ciType) {
    this._ciType = ciType;
  }

  public void setLinkType(String linkType) {
    this._linkType = linkType;
  }

  public void setCondition(AbstractIdentificationRuleConditionDef condition) {
    this._condition = condition;
  }

  public void setLinkCondition(AbstractIdentificationRuleConditionDef linkCondition) {
    this._linkCondition = linkCondition;
  }
}