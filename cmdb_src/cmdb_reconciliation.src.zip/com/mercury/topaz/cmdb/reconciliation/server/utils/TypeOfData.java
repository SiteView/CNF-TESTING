package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import java.util.Iterator;
import java.util.Map.Entry;

abstract interface TypeOfData<IDType extends CmdbDataID, Type extends CmdbData<IDType>>
{
  public abstract Iterator<? extends Map.Entry<String, ? extends CmdbDatas<IDType, Type>>> get(DataContainer paramDataContainer);

  public abstract void add(DataContainer paramDataContainer, Type paramType);

  public abstract void addAll(DataContainer paramDataContainer, CmdbDatas<IDType, Type> paramCmdbDatas);

  public abstract Type createData(Type paramType, IDType paramIDType, String paramString, CmdbProperties paramCmdbProperties, OldToNewIdMapping paramOldToNewIdMapping);

  public abstract Type createData(Type paramType, String paramString, CmdbProperties paramCmdbProperties, DataFactory paramDataFactory, OldToNewIdMapping paramOldToNewIdMapping);
}