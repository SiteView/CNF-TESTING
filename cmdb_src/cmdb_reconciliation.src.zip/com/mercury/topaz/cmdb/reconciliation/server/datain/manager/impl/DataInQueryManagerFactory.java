package com.mercury.topaz.cmdb.reconciliation.server.datain.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;

public class DataInQueryManagerFactory extends AbstractSubsystemManagerFactory
{
  public static final String NAME = "Reconciliation DataIn Query Task";

  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new DataInQueryManagerImpl(localEnvironment);
  }

  private static class DataInQueryManagerImpl extends CmdbSubsystemManagerImpl
  implements DataInManager, MultiReadSingleWrite
  {
    DataInQueryManagerImpl(LocalEnvironment localEnvironment) {
      super(localEnvironment);
    }

    public void startUp() {
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation DataIn Query Manager is started up properly !!!");
    }

    public void shutdown() {
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation DataIn Query Manager is shutdown up properly !!!");
    }

    public String getName() {
      return "Reconciliation DataIn Query Task";
    }
  }
}