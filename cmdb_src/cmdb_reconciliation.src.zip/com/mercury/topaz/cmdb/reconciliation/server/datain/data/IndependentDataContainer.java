package com.mercury.topaz.cmdb.reconciliation.server.datain.data;

import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public abstract interface IndependentDataContainer extends DataContainer
{
  public abstract void clean(CmdbClassModel paramCmdbClassModel, Map<CmdbObjectID, Collection<CmdbData>> paramMap, Map<String, CmdbObject> paramMap1);

  public abstract List<IndependentDataContainer> getAllDataContainers();
}