package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.DataChangeConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ReconciliationConfigDef;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class ReconciliationConfigDefImpl
  implements ReconciliationConfigDef, IUnmarshallable, IMarshallable
{
  private String _type;
  private DataChangeConfigDef _dataChangeConfigDef;
  private IdentificationConfiguration _identificationConfigDef;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public String toXml()
  {
    return XmlUtils.toXML(this);
  }

  public String getType() {
    return this._type;
  }

  public void setType(String type) {
    this._type = type;
  }

  public DataChangeConfigDef getDataChangeConfigDef() {
    return this._dataChangeConfigDef;
  }

  public void setDataChangeConfigDef(DataChangeConfigDef dataChangeConfigDef) {
    this._dataChangeConfigDef = dataChangeConfigDef;
  }

  public IdentificationConfiguration getIdentificationConfigDef() {
    return this._identificationConfigDef;
  }

  public void setIdentificationConfigDef(IdentificationConfiguration identificationConfigDef) {
    this._identificationConfigDef = identificationConfigDef;
  }

  public boolean equals(Object obj) {
    if (this == obj)
      return true;

    if ((obj == null) || (super.getClass() != obj.getClass())) {
      return false;
    }

    ReconciliationConfigDefImpl otherConfigDef = (ReconciliationConfigDefImpl)obj;

    return ((equals(getDataChangeConfigDef(), otherConfigDef.getDataChangeConfigDef())) && (equals(getIdentificationConfigDef(), otherConfigDef.getIdentificationConfigDef())) && (equals(getType(), otherConfigDef.getType())));
  }

  private boolean equals(Object o1, Object o2)
  {
    return ((o1 == o2) || ((o1 != null) && (o1.equals(o2))));
  }

  public int hashCode()
  {
    int result = (this._type != null) ? this._type.hashCode() : 0;
    result = 29 * result + ((this._dataChangeConfigDef != null) ? this._dataChangeConfigDef.hashCode() : 0);
    return result;
  }
}