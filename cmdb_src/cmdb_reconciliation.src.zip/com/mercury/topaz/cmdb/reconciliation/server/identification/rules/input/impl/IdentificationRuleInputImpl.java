package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;

class IdentificationRuleInputImpl
  implements IdentificationRuleInput
{
  private final ReconciliationEnvironment _env;
  private final DataContainer _data;
  private final String _typeToReconcile;
  private final InputIdToCmdbDatasMapping _alreayReconciledData;
  private IdentificationScope _identificationScope;

  public IdentificationRuleInputImpl(ReconciliationEnvironment env, DataContainer data, String typeToReconcile, InputIdToCmdbDatasMapping alreayReconciledData, IdentificationScope identificationScope)
  {
    this._env = env;
    this._data = data;
    this._typeToReconcile = typeToReconcile;
    this._alreayReconciledData = alreayReconciledData;
    this._identificationScope = identificationScope;
  }

  public ReconciliationEnvironment getReconciliationRuleEnvironment() {
    return this._env;
  }

  public DataContainer getDataContainer() {
    return this._data;
  }

  public String getTypeToIdentify() {
    return this._typeToReconcile;
  }

  public InputIdToCmdbDatasMapping getAlreadyReconciledData() {
    return this._alreayReconciledData;
  }

  public IdentificationScope getIdentifierScope() {
    return this._identificationScope;
  }
}