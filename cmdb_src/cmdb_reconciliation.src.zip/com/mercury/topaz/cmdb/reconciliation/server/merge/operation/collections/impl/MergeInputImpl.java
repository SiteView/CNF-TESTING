package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.impl;

import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

class MergeInputImpl<Type extends CmdbData>
  implements MergeInput<Type>
{
  private final Collection<Type> _datasToMerge;
  private final Type _updatingData;

  MergeInputImpl(int initialCapacity, Type updatingData)
  {
    this._updatingData = updatingData;
    this._datasToMerge = new ArrayList(initialCapacity);
  }

  MergeInputImpl(Collection<Type> list, Type updatingData) {
    this._updatingData = updatingData;
    this._datasToMerge = list;
  }

  public Type getUpdatingData() {
    return this._updatingData;
  }

  public Iterator<Type> getDatasIteratorToMerge() {
    return this._datasToMerge.iterator();
  }

  public Collection<Type> getDatasToMerge() {
    return this._datasToMerge;
  }

  public int getNumberOfDatas() {
    return this._datasToMerge.size();
  }

  public boolean add(Type data) {
    return this._datasToMerge.add(data);
  }

  public Iterator<Type> iterator() {
    return new Iterator(this) {
      private final Iterator<Type> _datasToMergeIter;
      private boolean _usedFirst;

      public boolean hasNext() { return ((!(this._usedFirst)) || (this._datasToMergeIter.hasNext()));
      }

      public Type next() {
        if (!(this._usedFirst)) {
          this._usedFirst = true;
          return MergeInputImpl.access$000(this.this$0);
        }
        return ((CmdbData)this._datasToMergeIter.next());
      }

      public void remove() {
        throw new UnsupportedOperationException("cannot remove with this iterator!!");
      }
    };
  }

  public String toString() {
    StringBuilder desc = new StringBuilder("Merge Input [updating data: ");
    desc.append(getUpdatingData()).append(" datas to merge: ").append(getDatasToMerge()).append("]");
    return desc.toString();
  }

  public boolean equals(Object o)
  {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    MergeInputImpl that = (MergeInputImpl)o;
    if (this._updatingData != null) if (this._updatingData.getID().equals(that._updatingData.getID())) break label72; 
    else if (that._updatingData == null) break label72;
    return false;

    label72: return (getIDsFromCollection(this._datasToMerge).equals(getIDsFromCollection(that._datasToMerge)));
  }

  public int hashCode()
  {
    int result = getIDsFromCollection(this._datasToMerge).hashCode();
    result = 29 * result + ((this._updatingData != null) ? this._updatingData.getID().hashCode() : 0);
    return result;
  }

  private CmdbDataIDs getIDsFromCollection(Collection<Type> datas) {
    CmdbDataIDs ids = CmdbDataIdsFactory.create();
    if (datas != null)
      for (Iterator i$ = datas.iterator(); i$.hasNext(); ) { CmdbData data = (CmdbData)i$.next();
        ids.add(data.getDataID());
      }

    return ids;
  }
}