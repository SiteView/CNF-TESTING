package com.mercury.topaz.cmdb.reconciliation.server.change.impl;

import com.mercury.topaz.cmdb.reconciliation.server.change.CmdbIDChange;
import com.mercury.topaz.cmdb.reconciliation.server.change.listener.CmdbIDChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.change.impl.AbstractCMDBChange;

public abstract class AbstractCmdbIDChange extends AbstractCMDBChange
  implements CmdbIDChange
{
  public void execute(CmdbChangeListenerFineGrained changeListener)
  {
    execute((CmdbIDChangeListenerFineGrained)changeListener);
  }

  abstract void execute(CmdbIDChangeListenerFineGrained paramCmdbIDChangeListenerFineGrained);
}