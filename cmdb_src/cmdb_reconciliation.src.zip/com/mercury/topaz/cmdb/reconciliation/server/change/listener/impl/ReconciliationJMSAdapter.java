package com.mercury.topaz.cmdb.reconciliation.server.change.listener.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.AbstractJMSPublisherAdapter;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher.JMSPublisher;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.util.Properties;

public class ReconciliationJMSAdapter extends AbstractJMSPublisherAdapter
{
  private static Log _logger = LogFactory.getEasyLog(ReconciliationJMSAdapter.class);

  public ReconciliationJMSAdapter(JMSPublisher jmsPublisher, CmdbCustomerID customerID)
  {
    super(jmsPublisher, FrameworkConstants.Subsystem.RECONCILIATION, customerID);
  }

  protected CmdbChanges addSpecificJMSInfo(CmdbChanges cmdbChanges, Properties jmsProps, StringBuffer logMessage) {
    return cmdbChanges;
  }

  protected Log getLogger() {
    return _logger;
  }
}