package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.DataInInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInAnomalyInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DataInRuleInputFactory
{
  public static DataInRuleInput createDataInRuleInput(Changer changer, String type, DataContainer dataContainer, InputIdToCmdbDatasMapping existingDataMap, Map<String, CmdbDataIDs> inputIDAsStringToReconciledIDsMap, Map<CmdbDataID, CmdbDataIDs> inputIDToReconciledIDsMap, List<DataInInfo> dataInInfoList, List<DataInAnomalyInfo> dataInAnomalyInfoList, Set<String> isOwnerByType, Map<CmdbDataID, CmdbDataID> idChanges)
  {
    return new DataInRuleInputImpl(changer, type, dataContainer, existingDataMap, inputIDAsStringToReconciledIDsMap, inputIDToReconciledIDsMap, dataInInfoList, dataInAnomalyInfoList, isOwnerByType, idChanges);
  }
}