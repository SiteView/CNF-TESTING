package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class IdentificationRuleConnectedNodeConditionDefs
  implements Collection<IdentificationRuleConnectedNodeConditionDef>
{
  private Collection<IdentificationRuleConnectedNodeConditionDef> _identificationRuleConnectedNodeConditionDefs;

  public IdentificationRuleConnectedNodeConditionDefs(Collection<IdentificationRuleConnectedNodeConditionDef> identificationRuleConnectedNodeConditionDefs)
  {
    this._identificationRuleConnectedNodeConditionDefs = identificationRuleConnectedNodeConditionDefs;
  }

  public IdentificationRuleConnectedNodeConditionDefs() {
    this(new LinkedList());
  }

  public int size() {
    return this._identificationRuleConnectedNodeConditionDefs.size();
  }

  public boolean isEmpty() {
    return this._identificationRuleConnectedNodeConditionDefs.isEmpty();
  }

  public boolean contains(Object o) {
    return this._identificationRuleConnectedNodeConditionDefs.contains(o);
  }

  public Iterator<IdentificationRuleConnectedNodeConditionDef> iterator() {
    return this._identificationRuleConnectedNodeConditionDefs.iterator();
  }

  public Object[] toArray() {
    return this._identificationRuleConnectedNodeConditionDefs.toArray();
  }

  public <T> T[] toArray(T[] a) {
    return this._identificationRuleConnectedNodeConditionDefs.toArray(a);
  }

  public boolean add(IdentificationRuleConnectedNodeConditionDef o) {
    return this._identificationRuleConnectedNodeConditionDefs.add(o);
  }

  public boolean remove(Object o) {
    return this._identificationRuleConnectedNodeConditionDefs.remove(o);
  }

  public boolean containsAll(Collection<?> c) {
    return this._identificationRuleConnectedNodeConditionDefs.containsAll(c);
  }

  public boolean addAll(Collection<? extends IdentificationRuleConnectedNodeConditionDef> c) {
    return this._identificationRuleConnectedNodeConditionDefs.addAll(c);
  }

  public boolean removeAll(Collection<?> c) {
    return this._identificationRuleConnectedNodeConditionDefs.removeAll(c);
  }

  public boolean retainAll(Collection<?> c) {
    return this._identificationRuleConnectedNodeConditionDefs.retainAll(c);
  }

  public void clear() {
    this._identificationRuleConnectedNodeConditionDefs.clear();
  }

  public void addConnectedCondition(IdentificationRuleConnectedNodeConditionDef connectedCondition) {
    this._identificationRuleConnectedNodeConditionDefs.add(connectedCondition);
  }
}