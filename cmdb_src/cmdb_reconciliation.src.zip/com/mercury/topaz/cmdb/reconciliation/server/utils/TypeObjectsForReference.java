package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import java.util.Iterator;
import java.util.Map.Entry;

class TypeObjectsForReference extends TypeOfObject
{
  public Iterator<Map.Entry<String, CmdbObjects>> get(DataContainer dataContainer)
  {
    return dataContainer.getReferencedObjectsIteratorByType();
  }

  public void add(DataContainer dataContainer, CmdbObject cmdbObject) {
    dataContainer.addReferencedObject(cmdbObject);
  }

  public void addAll(DataContainer dataContainer, CmdbDatas<CmdbObjectID, CmdbObject> datas) {
    dataContainer.addReferencedObjects((CmdbObjects)datas);
  }
}