package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

public class IdentificationRuleByLinkIdDef extends AbstractIdentificationRuleConditionDef
{
  public void accept(IdentificationRuleConditionDefVisitor visitor)
  {
    visitor.visit(this);
  }
}