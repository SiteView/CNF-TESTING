package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info;

public abstract interface DataInInfo
{
  public abstract String getShortMessage();
}