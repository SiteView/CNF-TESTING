package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ReconciliationConfigCacheQueryIsOwnerByType extends AbstractReconciliationConfigCacheQueryOperation
{
  private static final String NAME = "Reconciliation Config Cache Query - Get Owner By Type";
  private Collection<String> _typesCollection;
  private Set<String> _isOwnerByTypeSet;
  public static final String OWNER_BY_TYPE = "ownerByType";
  private String _dataStore;

  public ReconciliationConfigCacheQueryIsOwnerByType(String dataStore, Collection<String> typesCollection)
  {
    setTypesCollection(typesCollection);
    setDataStore(dataStore);
  }

  public ReconciliationConfigCacheQueryIsOwnerByType(String dataStore, String type) {
    Collection types = new ArrayList(1);
    types.add(type);
    setTypesCollection(types);
    setDataStore(dataStore);
  }

  public String getOperationName() {
    return "Reconciliation Config Cache Query - Get Owner By Type";
  }

  public void configCacheQueryExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response) throws CmdbException {
    CmdbClassModel classModel = configCacheManager.getSynchronizedClassModel();
    Set isOwnerByType = new HashSet(getTypesCollection().size());
    for (Iterator i$ = getTypesCollection().iterator(); i$.hasNext(); ) { String currentType = (String)i$.next();
      if (configCacheManager.isOwnerByType(getDataStore(), currentType, classModel))
        isOwnerByType.add(currentType);
    }

    setIsOwnerByTypeMap(isOwnerByType);
    response.addResult("ownerByType", (Serializable)isOwnerByType);
  }

  public void updateQueryWithResponse(CmdbResponse response)
  {
    setIsOwnerByTypeMap((Set)response.getResult("ownerByType"));
  }

  private Collection<String> getTypesCollection() {
    return this._typesCollection;
  }

  private void setTypesCollection(Collection<String> typesCollection) {
    this._typesCollection = typesCollection;
  }

  public Set<String> getIsOwnerByTypeMap() {
    return this._isOwnerByTypeSet;
  }

  private void setIsOwnerByTypeMap(Set<String> ownerByTypeMap) {
    this._isOwnerByTypeSet = ownerByTypeMap;
  }

  private String getDataStore() {
    return this._dataStore;
  }

  private void setDataStore(String dataStore) {
    this._dataStore = dataStore;
  }
}