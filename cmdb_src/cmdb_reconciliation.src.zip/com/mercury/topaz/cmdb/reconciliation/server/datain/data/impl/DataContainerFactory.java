package com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;

public class DataContainerFactory
{
  public static DataContainer createDataContainer()
  {
    return new DataContainerImpl();
  }
}