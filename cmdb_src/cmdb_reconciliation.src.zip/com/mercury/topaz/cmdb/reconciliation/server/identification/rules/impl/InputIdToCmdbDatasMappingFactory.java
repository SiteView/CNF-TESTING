package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl;

import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;

public class InputIdToCmdbDatasMappingFactory
{
  public static InputIdToCmdbDatasMapping create(int initSize)
  {
    return new InputIdToCmdbDatasMappingImpl(initSize);
  }
}