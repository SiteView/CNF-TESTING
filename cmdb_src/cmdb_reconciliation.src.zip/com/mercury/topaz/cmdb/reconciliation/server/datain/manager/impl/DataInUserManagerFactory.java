package com.mercury.topaz.cmdb.reconciliation.server.datain.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;

public class DataInUserManagerFactory extends AbstractSubsystemManagerFactory
{
  public static final String NAME = "Reconciliation DataIn User Task";

  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new DataInUserManagerImpl(localEnvironment);
  }

  private static class DataInUserManagerImpl extends CmdbSubsystemManagerImpl
  implements DataInManager, SingleReadSingleWrite
  {
    DataInUserManagerImpl(LocalEnvironment localEnvironment) {
      super(localEnvironment);
    }

    public void startUp() {
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation DataIn User Manager is started up properly !!!");
    }

    public void shutdown() {
      CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: Reconciliation DataIn User Manager is shutdown up properly !!!");
    }

    public String getName() {
      return "Reconciliation DataIn User Task";
    }
  }
}