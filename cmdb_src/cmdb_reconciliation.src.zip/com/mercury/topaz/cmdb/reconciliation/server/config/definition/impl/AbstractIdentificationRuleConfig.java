package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import java.io.Serializable;

public class AbstractIdentificationRuleConfig
  implements Serializable
{
  private String _targetType;
  private boolean _isTargetTypeDerived;
  private boolean _shouldIncludeSiblings;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public String getTargetType()
  {
    return this._targetType;
  }

  public void setTargetType(String targetType) {
    this._targetType = targetType;
  }

  public boolean isTargetTypeDerived() {
    return this._isTargetTypeDerived;
  }

  public void setTargetTypeDerived(boolean targetTypeDerived) {
    this._isTargetTypeDerived = targetTypeDerived;
  }

  public boolean shouldIncludeSiblings() {
    return this._shouldIncludeSiblings;
  }

  public void setShouldIncludeSiblings(boolean shouldIncludeSiblings) {
    this._shouldIncludeSiblings = shouldIncludeSiblings;
  }
}