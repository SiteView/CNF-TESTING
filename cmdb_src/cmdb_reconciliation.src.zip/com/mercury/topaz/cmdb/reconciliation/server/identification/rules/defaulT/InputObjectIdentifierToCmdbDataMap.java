package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class InputObjectIdentifierToCmdbDataMap<TypeID extends CmdbDataID>
{
  private final Map<InputObjectIdentifier, Set<TypeID>> _map;

  InputObjectIdentifierToCmdbDataMap()
  {
    this(10);
  }

  InputObjectIdentifierToCmdbDataMap(int initialCapacity) {
    this._map = new HashMap(initialCapacity);
  }

  void addToMap(InputObjectIdentifier inputObjectIdentifier, TypeID id) {
    Set ids = (Set)this._map.get(inputObjectIdentifier);
    if (null == ids) {
      ids = inputObjectIdentifier.createInitialSet();
      this._map.put(inputObjectIdentifier, ids);
    }
    inputObjectIdentifier.addToSet(ids, id);
  }

  Set<TypeID> get(InputObjectIdentifier inputObjectIdentifier) {
    return ((Set)this._map.get(inputObjectIdentifier));
  }

  Collection<Set<TypeID>> values() {
    return this._map.values();
  }

  Collection<Map.Entry<InputObjectIdentifier, Set<TypeID>>> entrySet() {
    return this._map.entrySet();
  }

  int size() {
    return this._map.size();
  }

  public String toString() {
    return this._map.toString();
  }
}