package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import java.util.Iterator;
import java.util.Map.Entry;

class TypeLinksForUpdate extends TypeOfLink
{
  public Iterator<Map.Entry<String, CmdbLinks>> get(DataContainer dataContainer)
  {
    return dataContainer.getLinksForUpdateIteratorByType();
  }

  public void add(DataContainer dataContainer, CmdbLink cmdbLink) {
    dataContainer.addLinkForUpdate(cmdbLink);
  }

  public void addAll(DataContainer dataContainer, CmdbDatas<CmdbLinkID, CmdbLink> datas) {
    dataContainer.addLinksForUpdate((CmdbLinks)datas);
  }
}