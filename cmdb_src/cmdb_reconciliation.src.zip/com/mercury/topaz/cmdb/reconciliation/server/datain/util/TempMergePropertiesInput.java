package com.mercury.topaz.cmdb.reconciliation.server.datain.util;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import java.util.Collection;

public class TempMergePropertiesInput<Type extends CmdbData> extends TempMergeInput<Type>
{
  private final Collection<Type> _datasFromBulk;

  public TempMergePropertiesInput(Type remainingObject, Collection<Type> datasFromCmdb, Collection<Type> datasFromBulk)
  {
    super(remainingObject, datasFromCmdb);
    this._datasFromBulk = datasFromBulk;
  }

  public Collection<Type> getDatasFromBulk() {
    return this._datasFromBulk;
  }
}