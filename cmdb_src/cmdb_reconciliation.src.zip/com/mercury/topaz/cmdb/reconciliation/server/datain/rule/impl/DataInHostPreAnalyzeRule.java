package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.IndependentDataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl.DataContainerUtil;
import com.mercury.topaz.cmdb.reconciliation.server.datain.exception.DataInException;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInAnomalyInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInPreAnalyzeRule;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRuleDefinition;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInPreAnalyzeRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInPreAnalyzeRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.impl.DataInPreAnalyzeRuleOutputFactory;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.id.data.TempCmdbDataID;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DataInHostPreAnalyzeRule
  implements DataInPreAnalyzeRule
{
  private DataInRuleDefinition _ruleDefinition;

  public DataInHostPreAnalyzeRule(DataInRuleDefinition ruleDefinition)
  {
    setRuleDefinition(ruleDefinition);
  }

  public DataInPreAnalyzeRuleOutput preAnalyze(ReconciliationEnvironment rulesEnv, DataInPreAnalyzeRuleInput input) {
    List dataContainers = input.getDataContainers();
    InputIdToCmdbDatasMapping existingDataMap = input.getExistingDataMap();

    String moreThanOneMatchAction = getRuleDefinition().getConfigurationParam("more-than-one-match");
    boolean shouldCleanDuplicateHosts = (moreThanOneMatchAction == null) || (moreThanOneMatchAction.equals("IGNORE")) || (moreThanOneMatchAction.equals("ERROR"));

    Collection datasRemovedFromDataContainer = removeFromDataContainer(dataContainers, existingDataMap, rulesEnv, input.getDataInAnomalyInfoList(), moreThanOneMatchAction, shouldCleanDuplicateHosts);
    CmdbObjectIds idsToRemoveFromCmdb = removeFromCmdb(dataContainers, existingDataMap, input.getDataInAnomalyInfoList(), moreThanOneMatchAction, shouldCleanDuplicateHosts);

    if ((moreThanOneMatchAction != null) && (moreThanOneMatchAction.equals("ERROR"))) {
      if (!(datasRemovedFromDataContainer.isEmpty()))
        throw new DataInException("Some of the hosts have more than one exisitng data:\n" + input.getDataInAnomalyInfoList());

      if (!(idsToRemoveFromCmdb.isEmpty()))
        throw new DataInException("Some of the complete hosts have the same incomplete host in cmdb:\n" + input.getDataInAnomalyInfoList());
    }

    return DataInPreAnalyzeRuleOutputFactory.createDataInRuleOutput(idsToRemoveFromCmdb);
  }

  private Collection<CmdbData> removeFromDataContainer(List<IndependentDataContainer> dataContainers, InputIdToCmdbDatasMapping existingDataMap, ReconciliationEnvironment rulesEnv, List<DataInAnomalyInfo> dataInAnomalyInfoList, String moreThanOneAction, boolean shouldCleanDuplicateHosts)
  {
    Collection datasRemovedFromDataContainer = cleanDataContainer((IndependentDataContainer)dataContainers.get(0), existingDataMap, rulesEnv.getDataFactory(), dataInAnomalyInfoList, moreThanOneAction, shouldCleanDuplicateHosts);
    return datasRemovedFromDataContainer;
  }

  private CmdbObjectIds removeFromCmdb(List<IndependentDataContainer> dataContainers, InputIdToCmdbDatasMapping existingDataMap, List<DataInAnomalyInfo> dataInAnomalyInfoList, String moreThanOneAction, boolean shouldCleanDuplicateHosts) {
    Collection hostsToRemoveFromCmdb = getObjectsToRemoveFromCmdb(dataContainers, existingDataMap, dataInAnomalyInfoList, moreThanOneAction, shouldCleanDuplicateHosts);
    CmdbObjectIds idsToRemoveFromCmdb = CmdbObjectIdsFactory.createIdsList(hostsToRemoveFromCmdb.size());
    for (Iterator i$ = hostsToRemoveFromCmdb.iterator(); i$.hasNext(); ) { CmdbObject currObjectToRemove = (CmdbObject)i$.next();
      idsToRemoveFromCmdb.add((CmdbObjectID)currObjectToRemove.getID());
    }
    return idsToRemoveFromCmdb;
  }

  private Collection<CmdbObject> getObjectsToRemoveFromCmdb(List<IndependentDataContainer> dataContainers, InputIdToCmdbDatasMapping existingDataMap, List<DataInAnomalyInfo> dataInAnomalyInfoList, String moreThanOneAction, boolean shouldCleanDuplicateHosts) {
    Collection hostsRemoved = new HashSet();

    CmdbObjects inCompleteExistingHosts = CmdbObjectFactory.createHashMapObjects();
    Map inCompleteHostToCompleteHostsMap = new HashMap();
    for (Iterator i$ = dataContainers.iterator(); i$.hasNext(); ) { IndependentDataContainer dataContainer = (IndependentDataContainer)i$.next();
      Iterator iter = dataContainer.getCmdbObjectsIteratorByType("host");
      while (iter.hasNext()) {
        CmdbObject host = (CmdbObject)iter.next();
        if (DataInHostRule.isCompleteHost(host)) {
          CmdbObjectID hostId = (CmdbObjectID)host.getID();

          Collection existingObjectsCollection = existingDataMap.get(hostId);
          for (Iterator i$ = existingObjectsCollection.iterator(); i$.hasNext(); ) { CmdbObject existingObject = (CmdbObject)i$.next();
            if (!(DataInHostRule.isCompleteHost(existingObject))) {
              CmdbObjectID existingObjectId = (CmdbObjectID)existingObject.getID();
              Collection completeHosts = (Collection)inCompleteHostToCompleteHostsMap.get(existingObjectId);
              if (completeHosts == null) {
                completeHosts = new ArrayList(1);
                inCompleteHostToCompleteHostsMap.put(existingObjectId, completeHosts);
              }
              completeHosts.add(host);
              inCompleteExistingHosts.add(existingObject);
            }
          }
        }
      }

    }

    for (i$ = inCompleteHostToCompleteHostsMap.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      Collection completeHosts = (Collection)entry.getValue();
      if (completeHosts.size() > 1) {
        CmdbObjectID idToRemove = (CmdbObjectID)entry.getKey();
        String completeHostsIDsList = getIDsStringListFromCmdbObjectCollection(completeHosts);
        for (Iterator i$ = completeHosts.iterator(); i$.hasNext(); ) { CmdbObject completeHost = (CmdbObject)i$.next();
          CmdbObject inCompleteHost = (CmdbObject)inCompleteExistingHosts.get(idToRemove);
          Collection inCompleteHosts = new ArrayList(1);
          inCompleteHosts.add(inCompleteHost);
          StringBuilder additionalInfo = new StringBuilder("The incomplete host: ").append(idToRemove).append(" is mapped to the following complete hosts: ").append(completeHostsIDsList);

          DataInAnomalyInfo info = new DataInAnomalyInfo(completeHost, moreThanOneAction, inCompleteHosts, null, additionalInfo.toString());
          dataInAnomalyInfoList.add(info);
          if (shouldCleanDuplicateHosts) {
            Collection existingObjectsCollection = existingDataMap.get((CmdbDataID)completeHost.getID());
            CmdbObject cmdbObjectRemoved = (CmdbObject)DataInUtil.removeObjectById(existingObjectsCollection, idToRemove);
            hostsRemoved.add(cmdbObjectRemoved);
          }
        }
      }
    }
    return hostsRemoved;
  }

  private String getIDsStringListFromCmdbObjectCollection(Collection<CmdbObject> objects) {
    StringBuilder list = new StringBuilder();
    for (Iterator i$ = objects.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
      list.append(object.getID()).append(",");
    }
    if (list.length() > 1)
      list.deleteCharAt(list.length() - 1);

    return list.toString();
  }

  private Collection<CmdbData> cleanDataContainer(IndependentDataContainer dataContainer, InputIdToCmdbDatasMapping existingDataMap, DataFactory dataFactory, List<DataInAnomalyInfo> dataInAnomalyInfoList, String moreThanOneMatchAction, boolean shouldCleanDuplicateHosts) {
    CmdbClassModel classModel = dataFactory.getClassModel();
    Map objectsToRemoveByHostID = new HashMap();
    Collection hostsToRemove = new LinkedList();
    Iterator hostsIterator = dataContainer.getCmdbObjectsIteratorByType("host");
    while (hostsIterator.hasNext()) {
      CmdbObject host = (CmdbObject)hostsIterator.next();
      if (!(DataInHostRule.isCompleteHost(host))) {
        CmdbObjectID hostIdToRemove = (CmdbObjectID)host.getID();

        Collection existingHosts = existingDataMap.get(hostIdToRemove);

        Collection existingInBulkHosts = existingDataMap.getInBulk(hostIdToRemove);
        if (checkIfNeededToRemove(existingHosts, existingInBulkHosts, dataFactory)) {
          LinkedList datas = new LinkedList();
          datas.add(host);
          objectsToRemoveByHostID.put(hostIdToRemove, datas);
          hostsToRemove.add(host);

          for (Iterator i$ = existingInBulkHosts.iterator(); i$.hasNext(); ) { CmdbObject existingInBulkObject = (CmdbObject)i$.next();
            DataInUtil.removeObjectById(existingDataMap.getInBulk((CmdbDataID)existingInBulkObject.getID()), hostIdToRemove);
          }
        }
      }
    }
    if ((!(hostsToRemove.isEmpty())) && (shouldCleanDuplicateHosts)) {
      DataContainerUtil.cleanDataContainer(dataContainer, classModel, objectsToRemoveByHostID);
    }

    Collection ans = new LinkedList();
    for (Iterator i$ = hostsToRemove.iterator(); i$.hasNext(); ) { CmdbObject hostToRemove = (CmdbObject)i$.next();
      Collection datasToRemove = (Collection)objectsToRemoveByHostID.get(hostToRemove.getID());
      if (shouldCleanDuplicateHosts)
        ans.addAll(datasToRemove);

      Collection existingData = existingDataMap.get((CmdbDataID)hostToRemove.getID());
      existingData.addAll(existingDataMap.getInBulk((CmdbDataID)hostToRemove.getID()));
      DataInAnomalyInfo info = new DataInAnomalyInfo(hostToRemove, moreThanOneMatchAction, existingData, datasToRemove, null);
      dataInAnomalyInfoList.add(info);
    }
    return ans;
  }

  private boolean checkIfNeededToRemove(Collection<CmdbObject> existingHosts, Collection<CmdbObject> existingInBulkHosts, DataFactory dataFactory) {
    Iterator i$;
    CmdbObject existingHost;
    CmdbObjectID firstCompleteHostId = null;
    if (existingHosts != null)
      for (i$ = existingHosts.iterator(); i$.hasNext(); ) { existingHost = (CmdbObject)i$.next();
        if ((DataInHostRule.isCompleteHost(existingHost)) && (!(((CmdbObjectID)existingHost.getID()).equals(firstCompleteHostId))))
          if (null == firstCompleteHostId)
            firstCompleteHostId = (CmdbObjectID)existingHost.getID();
          else
            return true;

      }


    if (existingInBulkHosts != null)
      for (i$ = existingInBulkHosts.iterator(); i$.hasNext(); ) { existingHost = (CmdbObject)i$.next();
        CmdbObjectID existingHostId = getRealId(dataFactory, existingHost);
        if ((DataInHostRule.isCompleteHost(existingHost)) && (!(existingHostId.equals(firstCompleteHostId))))
          if (null == firstCompleteHostId)
            firstCompleteHostId = existingHostId;
          else
            return true;

      }


    return false;
  }

  private CmdbObjectID getRealId(DataFactory dataFactory, CmdbObject object) {
    CmdbObjectID originalId = (CmdbObjectID)object.getID();
    if (originalId instanceof TempCmdbDataID)
      return dataFactory.createObjectID(object.getType(), object.getUnmodifiableProperties());

    return originalId;
  }

  private DataInRuleDefinition getRuleDefinition() {
    return this._ruleDefinition;
  }

  private void setRuleDefinition(DataInRuleDefinition ruleDefinition) {
    this._ruleDefinition = ruleDefinition;
  }
}