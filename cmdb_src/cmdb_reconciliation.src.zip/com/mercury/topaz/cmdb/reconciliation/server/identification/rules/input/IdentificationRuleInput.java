package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;

public abstract interface IdentificationRuleInput
{
  public abstract ReconciliationEnvironment getReconciliationRuleEnvironment();

  public abstract DataContainer getDataContainer();

  public abstract String getTypeToIdentify();

  public abstract InputIdToCmdbDatasMapping getAlreadyReconciledData();

  public abstract IdentificationScope getIdentifierScope();
}