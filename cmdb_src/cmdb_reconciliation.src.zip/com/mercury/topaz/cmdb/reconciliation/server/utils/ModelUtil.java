package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.topaz.cmdb.reconciliation.server.ReconciliationConstants;
import com.mercury.topaz.cmdb.reconciliation.server.exception.ReconciliationException;
import com.mercury.topaz.cmdb.reconciliation.server.id.object.TempCmdbObjectID;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributeDefinition;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public class ModelUtil
{
  public static boolean isContainedInObject(CmdbObject object, CmdbClassModel classModel)
  {
    CmdbProperty cmdbProperty = object.getProperty("root_container");
    if ((cmdbProperty != null) && (!(cmdbProperty.isValueEmpty())))
      return true;

    CmdbClass cmdbClass = classModel.getClass(object.getType());
    CmdbAttributes attributes = cmdbClass.getAttributesByQualifier(ReconciliationConstants.ATTRIBUTE_QUALIFIER_NAME_CONTAINED_BY);
    ReadOnlyIterator readOnlyIterator = attributes.getIterator();
    while (readOnlyIterator.hasNext()) {
      CmdbAttributeDefinition attributeDefinition = (CmdbAttributeDefinition)readOnlyIterator.next();
      cmdbProperty = object.getProperty(attributeDefinition.getName());
      if ((null != cmdbProperty) && (!(cmdbProperty.isValueEmpty())))
        return true;
    }

    return false;
  }

  public static CmdbProperties copyProperties(CmdbData<?> data) {
    CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
    for (Iterator i$ = data.getUnmodifiableProperties().iterator(); i$.hasNext(); ) { CmdbProperty cmdbProperty = (CmdbProperty)i$.next();
      cmdbProperties.add(cmdbProperty);
    }
    return cmdbProperties;
  }

  public static boolean hasAllKeyProperties(CmdbObject object, CmdbClassModel cmdbClassModel) {
    CmdbClass cmdbClass = cmdbClassModel.getClass(object.getType());
    CmdbAttributes attributes = cmdbClass.getIDAttributesSortedByName();
    ReadOnlyIterator attributesIter = attributes.getIterator();
    do if (!(attributesIter.hasNext())) break label64;
    while (object.getProperty(((CmdbAttributeDefinition)attributesIter.next()).getName()) != null);
    return false;
    label64: return true;
  }

  public static boolean hasAllKeyProperties(CmdbProperties properties, CmdbClass cmdbClass) {
    CmdbAttributes attributes = cmdbClass.getIDAttributesSortedByName();
    ReadOnlyIterator attributesIter = attributes.getIterator();
    do if (!(attributesIter.hasNext())) break label48;
    while (properties.contains(((CmdbAttributeDefinition)attributesIter.next()).getName()));
    return false;
    label48: return true;
  }

  public static Collection<CmdbObject> getContainedByObjects(CmdbObject object, CmdbClassModel classModel, Map<String, CmdbObject> toStringIdToObjectIdMap) {
    Collection containingProperties = getContainedByProperties(object, classModel);

    Collection containedByObjects = new ArrayList(containingProperties.size());

    for (Iterator i$ = containingProperties.iterator(); i$.hasNext(); ) { CmdbProperty property = (CmdbProperty)i$.next();
      String propertyValue = (String)property.getValue();
      CmdbObject containedByObject = (CmdbObject)toStringIdToObjectIdMap.get(propertyValue);
      if (null != containedByObject)
        containedByObjects.add(containedByObject);
    }

    return containedByObjects;
  }

  public static Collection<CmdbProperty> getContainedByProperties(CmdbObject object, CmdbClassModel classModel) {
    Collection containedByObjects = new ArrayList();

    CmdbClass theClass = classModel.getClass(object.getType());
    if (null == theClass)
      throw new ReconciliationException("a CI type that does not exist in the class model has been sent to reconciliation. the ci is: <" + object + ">.", ErrorCode.CLASS_NOT_IN_CLASS_MODEL);

    CmdbAttributes containedByAttributes = theClass.getAttributesByQualifier(ReconciliationConstants.ATTRIBUTE_QUALIFIER_NAME_CONTAINED_BY);

    CmdbProperty cmdbProperty = object.getProperty("root_container");
    if ((null != cmdbProperty) && (!(cmdbProperty.isValueEmpty())))
      containedByObjects.add(cmdbProperty);
    for (ReadOnlyIterator iterator = containedByAttributes.getIterator(); iterator.hasNext(); ) {
      String attributeName = ((CmdbAttributeDefinition)iterator.next()).getName();
      cmdbProperty = object.getProperty(attributeName);
      if ((null != cmdbProperty) && (!(cmdbProperty.isValueEmpty())))
        containedByObjects.add(cmdbProperty);
    }
    return containedByObjects;
  }

  public static boolean isContainerProperty(String className, CmdbProperty cmdbProperty, CmdbClassModel classModel) {
    if (cmdbProperty.getKey().equals("root_container"))
      return true;

    CmdbClass cmdbClass = classModel.getClass(className);
    CmdbAttribute attribute = cmdbClass.getAttributeByName(cmdbProperty.getKey());
    return attribute.hasQualifier(ReconciliationConstants.ATTRIBUTE_QUALIFIER_NAME_CONTAINED_BY);
  }

  public static Collection<CmdbObject> createObjectWithRealId(CmdbObject currentObject, InputIdToCmdbDatasMapping identificationDatas, DataFactory dataFactory, IdentificationScope scope) {
    CmdbClass aClass = dataFactory.getClassModel().getClass(currentObject.getType());
    CmdbProperties originalProperties = currentObject.getUnmodifiableProperties();
    String containerAttributeName = getContainerAttributeName(aClass, originalProperties);

    if (containerAttributeName == null) {
      return Arrays.asList(new CmdbObject[] { recreateObject(currentObject, dataFactory) });
    }

    Collection containers = scope.getResults(identificationDatas, (String)originalProperties.get(containerAttributeName).getValue());

    if (containers == null) {
      return Arrays.asList(new CmdbObject[] { recreateObject(currentObject, dataFactory) });
    }

    Collection propertiess = createAllPropertiesCombinations(originalProperties, containerAttributeName, containers);
    Collection realIdObjects = new ArrayList(containers.size());
    for (Iterator i$ = propertiess.iterator(); i$.hasNext(); ) { CmdbProperties properties = (CmdbProperties)i$.next();
      realIdObjects.add(dataFactory.createObject(currentObject.getType(), properties));
    }
    return realIdObjects;
  }

  private static Collection<CmdbProperties> createAllPropertiesCombinations(CmdbProperties originalProperties, String containerAttributeName, Collection<CmdbObject> containers) {
    Collection propertiess = new ArrayList(containers.size());

    int propertiesSize = originalProperties.size();
    for (int i = 0; i < containers.size(); ++i) {
      propertiess.add(CmdbPropertyFactory.createProperties(propertiesSize));
    }

    for (Iterator i$ = originalProperties.iterator(); i$.hasNext(); ) { CmdbProperty cmdbProperty = (CmdbProperty)i$.next();
      for (Iterator i$ = propertiess.iterator(); i$.hasNext(); ) { CmdbProperties properties = (CmdbProperties)i$.next();
        properties.add(cmdbProperty);
      }
    }

    Iterator iter = containers.iterator();
    for (Iterator i$ = propertiess.iterator(); i$.hasNext(); ) { CmdbProperties properties = (CmdbProperties)i$.next();
      properties.add(CmdbPropertyFactory.createProperty(containerAttributeName, ((CmdbObjectID)((CmdbObject)iter.next()).getID()).toString()));
    }
    return propertiess;
  }

  private static CmdbObject recreateObject(CmdbObject currentObject, DataFactory dataFactory) {
    if (currentObject.getID() instanceof TempCmdbObjectID)
      return dataFactory.createObject(currentObject.getType(), currentObject.getUnmodifiableProperties());

    return currentObject;
  }

  private static String getContainerAttributeName(CmdbClass aClass, CmdbProperties properties)
  {
    if (properties.contains("root_container"))
      return "root_container";

    CmdbAttributes cmdbAttributes = aClass.getAttributesByQualifier(ReconciliationConstants.ATTRIBUTE_QUALIFIER_NAME_CONTAINED_BY);
    if ((!($assertionsDisabled)) && (cmdbAttributes.getSize() > 1)) throw new AssertionError();
    return ((cmdbAttributes.isEmpty()) ? null : ((CmdbAttributeDefinition)cmdbAttributes.getIterator().next()).getName());
  }
}