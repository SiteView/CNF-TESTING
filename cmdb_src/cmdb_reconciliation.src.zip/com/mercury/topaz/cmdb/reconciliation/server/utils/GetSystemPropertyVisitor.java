package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.classmodel.type.TypeVisitor;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBytesType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDateType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDoubleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbFloatType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.Numeric;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;

class GetSystemPropertyVisitor
  implements TypeVisitor
{
  private Object _result;
  private final String _systemPropertyName;

  GetSystemPropertyVisitor(String systemPropertyName)
  {
    this._systemPropertyName = systemPropertyName;
  }

  public void visit(CmdbSimpleType simpleCmdbType) {
  }

  public void visit(Numeric numericType) {
  }

  public void visit(CmdbIntegerType integerType) {
    this._result = Integer.valueOf(ServerApiFacade.getSettingsReader().getInt(this._systemPropertyName, -1));
  }

  public void visit(CmdbLongType longType) {
    this._result = Long.valueOf(ServerApiFacade.getSettingsReader().getLong(this._systemPropertyName, -1L));
  }

  public void visit(CmdbFloatType floatType) {
    this._result = Float.valueOf(ServerApiFacade.getSettingsReader().getFloat(this._systemPropertyName, -1.0F));
  }

  public void visit(CmdbDoubleType doubleType) {
    this._result = Float.valueOf(ServerApiFacade.getSettingsReader().getFloat(this._systemPropertyName, -1.0F));
  }

  public void visit(CmdbStringType stringType) {
    this._result = ServerApiFacade.getSettingsReader().getString(this._systemPropertyName, null);
  }

  public void visit(CmdbXmlType xmlType) {
    this._result = ServerApiFacade.getSettingsReader().getString(this._systemPropertyName, null);
  }

  public void visit(CmdbBooleanType cmdbBooleanType) {
    this._result = Boolean.valueOf(ServerApiFacade.getSettingsReader().getBoolean(this._systemPropertyName, false));
  }

  public void visit(CmdbDateType cmdbDateType) {
    this._result = Long.valueOf(ServerApiFacade.getSettingsReader().getLong(this._systemPropertyName, -1L));
  }

  public void visit(CmdbBytesType cmdbBytesType) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbSimpleList cmdbSimpleList) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbStringListType cmdbStringListType) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbIntegerListType cmdbIntegerListType) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbTypeDef typeDef) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbEnum cmdbEnum) {
    this._result = Integer.valueOf(ServerApiFacade.getSettingsReader().getInt(this._systemPropertyName, -1));
  }

  public void visit(CmdbList cmdbList) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public void visit(CmdbExternalResource externalResource) {
    throw new UnsupportedOperationException("cannot replace value");
  }

  public Object getResult() {
    return this._result;
  }
}