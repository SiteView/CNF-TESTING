package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import java.util.Set;

abstract interface InputObjectIdentifier extends Cloneable
{
  public abstract void add(CmdbProperty paramCmdbProperty);

  public abstract void addFixedValue(FixedValueAttribute paramFixedValueAttribute);

  public abstract void setId(CmdbDataID paramCmdbDataID);

  public abstract <TypeID extends CmdbDataID> Set<TypeID> createInitialSet();

  public abstract <TypeID extends CmdbDataID> boolean addToSet(Set<TypeID> paramSet, TypeID paramTypeID);

  public abstract InputObjectIdentifier clone();

  public abstract CmdbDataID getId();

  public abstract boolean equals(CmdbData<?> paramCmdbData1, CmdbData<?> paramCmdbData2);
}