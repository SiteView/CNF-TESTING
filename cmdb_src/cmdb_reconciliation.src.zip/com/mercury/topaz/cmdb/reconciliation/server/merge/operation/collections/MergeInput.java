package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;

public abstract interface MergeInput<Type extends CmdbData> extends Iterable<Type>, Serializable
{
  public abstract Type getUpdatingData();

  public abstract Iterator<Type> getDatasIteratorToMerge();

  public abstract Collection<Type> getDatasToMerge();

  public abstract int getNumberOfDatas();

  public abstract boolean add(Type paramType);
}