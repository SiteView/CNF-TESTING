package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInPreAnalyzeRuleOutput;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;

class DataInPreAnalyzeRuleOutputImpl
  implements DataInPreAnalyzeRuleOutput
{
  private final CmdbObjectIds _objectsToRemove;

  DataInPreAnalyzeRuleOutputImpl(CmdbObjectIds objectsToRemove)
  {
    this._objectsToRemove = objectsToRemove;
  }

  public CmdbObjectIds getObjectsToRemove() {
    return this._objectsToRemove;
  }
}