package com.mercury.topaz.cmdb.reconciliation.server.identification;

import com.mercury.topaz.cmdb.reconciliation.server.exception.ReconciliationException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;

public class IdentificationException extends ReconciliationException
{
  public IdentificationException(String message)
  {
    super(message);
  }

  public IdentificationException(String message, ErrorCode errorCode) {
    super(message, errorCode);
  }

  public IdentificationException(String message, Throwable cause) {
    super(message, cause);
  }

  public IdentificationException(String message, Throwable cause, ErrorCode errorCode) {
    super(message, cause, errorCode);
  }

  public IdentificationException(Throwable cause) {
    super(cause);
  }

  public IdentificationException(Throwable cause, ErrorCode errorCode) {
    super(cause, errorCode);
  }
}