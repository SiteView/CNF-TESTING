package com.mercury.topaz.cmdb.reconciliation.server.change.impl;

import com.mercury.topaz.cmdb.reconciliation.server.change.CmdbLinkIDChange;
import com.mercury.topaz.cmdb.reconciliation.server.change.listener.CmdbIDChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;

class CmdbLinkIDChangeImpl extends AbstractCmdbIDChange
  implements CmdbLinkIDChange
{
  private CmdbLinkID _oldID;
  private CmdbLinkID _newID;

  public CmdbLinkIDChangeImpl(CmdbLinkID oldID, CmdbLinkID newID)
  {
    setOldID(oldID);
    setNewID(newID);
  }

  void execute(CmdbIDChangeListenerFineGrained changeListener) {
    changeListener.onCmdbLinkIDChange(getOldID(), getNewID());
  }

  private CmdbLinkID getOldID() {
    return this._oldID;
  }

  private void setOldID(CmdbLinkID oldID) {
    this._oldID = oldID;
  }

  private CmdbLinkID getNewID() {
    return this._newID;
  }

  private void setNewID(CmdbLinkID newID) {
    this._newID = newID;
  }

  public String toString() {
    StringBuilder msg = new StringBuilder("Link ID Change: ID ").append(this._oldID).append(" was changed to ").append(this._newID);

    return msg.toString();
  }
}