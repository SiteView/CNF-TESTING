package com.mercury.topaz.cmdb.reconciliation.server.config.jmx.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.update.impl.ReconciliationConfigAdminAddOrUpdateConfig;
import com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.update.impl.ReconciliationConfigAdminRemoveConfig;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl.ReconciliationConfigCacheQueryGetConfigByName;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ReconciliationConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.ReconciliationConfigDefImpl;
import com.mercury.topaz.cmdb.reconciliation.server.identification.operation.command.impl.IdentificationCommandValidateRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationUtil;
import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=CMDB Reconciliation Services", description="CMDB Reconciliation Services")
public class ReconciliationJmxServices extends AbstractCmdbJmx
{
  Changer _changer;

  public ReconciliationJmxServices()
  {
    this._changer = ChangerFactory.createChanger("UCMDB", "JMX"); } 
  @ManagedOperation(description="Retrieves the xml that describes the reconciliation configuration for a specific class")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="Object Type (host ip etc..)")})
  public String getReconciliationConfiguration(Integer customerID, String className) { // Byte code:
    //   0: new 6	com/mercury/topaz/cmdb/reconciliation/server/config/cache/operation/query/impl/ReconciliationConfigCacheQueryGetConfigByName
    //   3: dup
    //   4: aload_2
    //   5: invokespecial 7	com/mercury/topaz/cmdb/reconciliation/server/config/cache/operation/query/impl/ReconciliationConfigCacheQueryGetConfigByName:<init>	(Ljava/lang/String;)V
    //   8: astore_3
    //   9: aload_0
    //   10: aload_3
    //   11: aload_1
    //   12: invokevirtual 8	com/mercury/topaz/cmdb/reconciliation/server/config/jmx/impl/ReconciliationJmxServices:invokeOperation	(Lcom/mercury/topaz/cmdb/shared/manage/operation/FrameworkOperation;Ljava/lang/Integer;)Lcom/mercury/topaz/cmdb/shared/manage/CmdbResponse;
    //   15: pop
    //   16: aload_3
    //   17: invokevirtual 9	com/mercury/topaz/cmdb/reconciliation/server/config/cache/operation/query/impl/ReconciliationConfigCacheQueryGetConfigByName:getConfigDef	()Lcom/mercury/topaz/cmdb/reconciliation/server/config/definition/ReconciliationConfigDef;
    //   20: astore 4
    //   22: aload 4
    //   24: ifnull +20 -> 44
    //   27: aload 4
    //   29: invokestatic 10	com/mercury/topaz/cmdb/shared/util/XmlUtils:toXML	(Ljava/lang/Object;)Ljava/lang/String;
    //   32: astore 5
    //   34: aload 5
    //   36: invokestatic 11	com/mercury/topaz/cmdb/shared/util/XmlUtils:convertStringWithXmlTags	(Ljava/lang/String;)Ljava/lang/String;
    //   39: astore 5
    //   41: goto +24 -> 65
    //   44: new 12	java/lang/StringBuilder
    //   47: dup
    //   48: invokespecial 13	java/lang/StringBuilder:<init>	()V
    //   51: ldc 14
    //   53: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: aload_2
    //   57: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: invokevirtual 16	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   63: astore 5
    //   65: aload 5
    //   67: areturn
    //   68: astore_3
    //   69: aload_3
    //   70: iconst_1
    //   71: anewarray 18	java/lang/String
    //   74: dup
    //   75: iconst_0
    //   76: new 12	java/lang/StringBuilder
    //   79: dup
    //   80: invokespecial 13	java/lang/StringBuilder:<init>	()V
    //   83: ldc 19
    //   85: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   88: aload_2
    //   89: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   92: ldc 20
    //   94: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: invokevirtual 16	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   100: aastore
    //   101: invokestatic 21	com/mercury/topaz/cmdb/reconciliation/server/config/jmx/impl/ReconciliationJmxServices:createStringFromException	(Ljava/lang/Throwable;[Ljava/lang/String;)Ljava/lang/String;
    //   104: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	67	68	java/lang/Throwable } 
  @ManagedOperation(description="Inserts reconciliation configuration for a specific type")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="xmlConfiguration", description="The xml configuration")})
  public String deployReconciliationConfiguration(Integer customerID, String xmlConfiguration) { // Byte code:
    //   0: aload_2
    //   1: ldc_w 22
    //   4: invokestatic 23	com/mercury/topaz/cmdb/shared/util/XmlUtils:fromXML	(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;
    //   7: checkcast 24	com/mercury/topaz/cmdb/reconciliation/server/config/definition/ReconciliationConfigDef
    //   10: astore_3
    //   11: aconst_null
    //   12: astore 4
    //   14: aload_3
    //   15: invokestatic 25	com/mercury/topaz/cmdb/reconciliation/server/identification/rules/IdentificationUtil:getIdentificationRulesFromDef	(Lcom/mercury/topaz/cmdb/reconciliation/server/config/definition/ReconciliationConfigDef;)Ljava/util/Collection;
    //   18: invokeinterface 26 1 0
    //   23: astore 5
    //   25: aload 5
    //   27: invokeinterface 27 1 0
    //   32: ifeq +55 -> 87
    //   35: aload 5
    //   37: invokeinterface 28 1 0
    //   42: checkcast 29	com/mercury/topaz/cmdb/reconciliation/server/identification/rules/IdentificationRule
    //   45: astore 6
    //   47: aload 6
    //   49: ifnull +35 -> 84
    //   52: new 30	com/mercury/topaz/cmdb/reconciliation/server/identification/operation/command/impl/IdentificationCommandValidateRule
    //   55: dup
    //   56: aload_3
    //   57: invokeinterface 31 1 0
    //   62: aload 6
    //   64: invokespecial 32	com/mercury/topaz/cmdb/reconciliation/server/identification/operation/command/impl/IdentificationCommandValidateRule:<init>	(Ljava/lang/String;Lcom/mercury/topaz/cmdb/reconciliation/server/identification/rules/IdentificationRule;)V
    //   67: astore 7
    //   69: aload_0
    //   70: aload 7
    //   72: aload_1
    //   73: invokevirtual 8	com/mercury/topaz/cmdb/reconciliation/server/config/jmx/impl/ReconciliationJmxServices:invokeOperation	(Lcom/mercury/topaz/cmdb/shared/manage/operation/FrameworkOperation;Ljava/lang/Integer;)Lcom/mercury/topaz/cmdb/shared/manage/CmdbResponse;
    //   76: pop
    //   77: aload 7
    //   79: invokevirtual 33	com/mercury/topaz/cmdb/reconciliation/server/identification/operation/command/impl/IdentificationCommandValidateRule:getInvalidDataMap	()Ljava/util/Map;
    //   82: astore 4
    //   84: goto -59 -> 25
    //   87: aload 4
    //   89: ifnull +13 -> 102
    //   92: aload 4
    //   94: invokeinterface 34 1 0
    //   99: ifeq +28 -> 127
    //   102: new 35	com/mercury/topaz/cmdb/reconciliation/server/config/admin/operation/update/impl/ReconciliationConfigAdminAddOrUpdateConfig
    //   105: dup
    //   106: aload_3
    //   107: aload_0
    //   108: getfield 5	com/mercury/topaz/cmdb/reconciliation/server/config/jmx/impl/ReconciliationJmxServices:_changer	Lcom/mercury/topaz/cmdb/shared/model/changer/Changer;
    //   111: invokespecial 36	com/mercury/topaz/cmdb/reconciliation/server/config/admin/operation/update/impl/ReconciliationConfigAdminAddOrUpdateConfig:<init>	(Lcom/mercury/topaz/cmdb/reconciliation/server/config/definition/ReconciliationConfigDef;Lcom/mercury/topaz/cmdb/shared/model/changer/Changer;)V
    //   114: astore 5
    //   116: aload_0
    //   117: aload 5
    //   119: aload_1
    //   120: invokevirtual 8	com/mercury/topaz/cmdb/reconciliation/server/config/jmx/impl/ReconciliationJmxServices:invokeOperation	(Lcom/mercury/topaz/cmdb/shared/manage/operation/FrameworkOperation;Ljava/lang/Integer;)Lcom/mercury/topaz/cmdb/shared/manage/CmdbResponse;
    //   123: pop
    //   124: ldc 37
    //   126: areturn
    //   127: new 12	java/lang/StringBuilder
    //   130: dup
    //   131: ldc 38
    //   133: invokespecial 39	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   136: aload_3
    //   137: invokeinterface 31 1 0
    //   142: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: ldc 40
    //   147: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: astore 5
    //   152: aload 5
    //   154: ldc 41
    //   156: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   159: ldc 42
    //   161: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: aload 4
    //   167: invokeinterface 43 1 0
    //   172: invokeinterface 44 1 0
    //   177: astore 6
    //   179: aload 6
    //   181: invokeinterface 27 1 0
    //   186: ifeq +79 -> 265
    //   189: aload 6
    //   191: invokeinterface 28 1 0
    //   196: checkcast 45	java/util/Map$Entry
    //   199: astore 7
    //   201: aload 5
    //   203: ldc 46
    //   205: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: aload 7
    //   210: invokeinterface 47 1 0
    //   215: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   218: ldc 49
    //   220: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: aload 7
    //   225: invokeinterface 50 1 0
    //   230: checkcast 51	java/util/Collection
    //   233: invokeinterface 52 1 0
    //   238: invokevirtual 53	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   241: ldc 54
    //   243: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   246: ldc 55
    //   248: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   251: aload 7
    //   253: invokeinterface 50 1 0
    //   258: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   261: pop
    //   262: goto -83 -> 179
    //   265: aload 5
    //   267: invokevirtual 16	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   270: areturn
    //   271: astore_3
    //   272: aload_3
    //   273: iconst_1
    //   274: anewarray 18	java/lang/String
    //   277: dup
    //   278: iconst_0
    //   279: ldc 56
    //   281: aastore
    //   282: invokestatic 21	com/mercury/topaz/cmdb/reconciliation/server/config/jmx/impl/ReconciliationJmxServices:createStringFromException	(Ljava/lang/Throwable;[Ljava/lang/String;)Ljava/lang/String;
    //   285: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	126	271	java/lang/Throwable
    //   127	270	271	java/lang/Throwable } 
  @ManagedOperation(description="Removes reconciliation configuration for a specific type")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="className", description="Object Type (host ip etc..)")})
  public String unDeployReconciliationConfiguration(Integer customerID, String className) { ReconciliationConfigAdminRemoveConfig remove = new ReconciliationConfigAdminRemoveConfig(className, this._changer);
    try {
      invokeOperation(remove, customerID);
    } catch (Throwable e) {
      return createStringFromException(e, new String[] { "load or reload of [" + className + "] failed. Exception is:\n" });
    }
    return "Finished!";
  }
}