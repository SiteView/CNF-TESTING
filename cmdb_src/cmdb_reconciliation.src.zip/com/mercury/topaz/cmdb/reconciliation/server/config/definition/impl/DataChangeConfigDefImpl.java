package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.DataChangeConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.DataChangeRuleConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.config.definition.OwnersConfigDef;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class DataChangeConfigDefImpl
  implements DataChangeConfigDef, IUnmarshallable, IMarshallable
{
  private DataChangeRuleConfigDef _ruleConfigDef;
  private OwnersConfigDef _ownersConfigDef;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.JiBX_bindingFactory|";

  public OwnersConfigDef getOwnersConfigDef()
  {
    return this._ownersConfigDef;
  }

  public void setOwnersConfigDef(OwnersConfigDef ownersConfigDef) {
    this._ownersConfigDef = ownersConfigDef;
  }

  public DataChangeRuleConfigDef getRuleConfigDef() {
    return this._ruleConfigDef;
  }

  public void setRuleConfigDef(DataChangeRuleConfigDef ruleConfigDef) {
    this._ruleConfigDef = ruleConfigDef;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    DataChangeConfigDefImpl that = (DataChangeConfigDefImpl)o;

    if (this._ownersConfigDef != null) if (this._ownersConfigDef.equals(that._ownersConfigDef)) break label62; 
    else if (that._ownersConfigDef == null) break label62;
    return false;

    if (this._ruleConfigDef != null) label62: if (this._ruleConfigDef.equals(that._ruleConfigDef)) break label95;
    label95: return (that._ruleConfigDef == null);
  }

  public int hashCode()
  {
    int result = (this._ownersConfigDef != null) ? this._ownersConfigDef.hashCode() : 0;
    result = 29 * result + ((this._ruleConfigDef != null) ? this._ruleConfigDef.hashCode() : 0);
    return result;
  }
}