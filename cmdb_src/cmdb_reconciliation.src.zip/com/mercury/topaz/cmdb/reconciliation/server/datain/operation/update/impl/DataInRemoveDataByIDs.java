package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbUnresolvedDataIDs;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.bulk.info.CmdbModelUpdateBulkInfo;
import com.mercury.topaz.cmdb.shared.model.operation.update.impl.condition.remove.ModelUpdateRemoveByIDsCondition;

public class DataInRemoveDataByIDs extends AbstractDataInUpdateOperation
{
  private CmdbUnresolvedDataIDs _unresolvedDataIDs;
  private CmdbIDsCollection _inputIDs;

  public DataInRemoveDataByIDs(CmdbIDsCollection inputIDs, Changer changer)
  {
    super(changer);
    setInputIDs(inputIDs);
  }

  public DataInRemoveDataByIDs(CmdbUnresolvedDataIDs unresolvedDataIDs, Changer changer) {
    super(changer);
    setUnresolvedDataIDs(unresolvedDataIDs);
  }

  public String getOperationName() {
    return "Data In - Remove Data By IDs";
  }

  public void dataInUpdateExecute(DataInManager dataInManager, CmdbResponse response) throws CmdbException {
    CmdbModelUpdateBulkInfo bulkInfo = sendToModelUpdate(dataInManager);
    setBulkInfo(bulkInfo);
  }

  protected CmdbModelUpdateBulkInfo sendToModelUpdate(DataInManager dataInManager) {
    ModelUpdateRemoveByIDsCondition remove = null;
    if (getUnresolvedDataIDs() != null) {
      remove = new ModelUpdateRemoveByIDsCondition(getUnresolvedDataIDs(), getChanger());
    }
    else
      remove = new ModelUpdateRemoveByIDsCondition(getInputIDs(), getChanger());

    dataInManager.executeOperation(remove);
    return remove.getModelUpdateBulkInfo();
  }

  private CmdbUnresolvedDataIDs getUnresolvedDataIDs() {
    return this._unresolvedDataIDs;
  }

  private void setUnresolvedDataIDs(CmdbUnresolvedDataIDs unresolvedDataIDs) {
    this._unresolvedDataIDs = unresolvedDataIDs;
  }

  private CmdbIDsCollection getInputIDs() {
    return this._inputIDs;
  }

  private void setInputIDs(CmdbIDsCollection inputIDs) {
    this._inputIDs = inputIDs;
  }
}