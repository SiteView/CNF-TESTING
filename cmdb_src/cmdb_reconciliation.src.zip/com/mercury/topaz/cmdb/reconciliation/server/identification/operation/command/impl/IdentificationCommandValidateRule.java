package com.mercury.topaz.cmdb.reconciliation.server.identification.operation.command.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.impl.DataContainerFactory;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.environment.impl.ReconciliationEnvironmentFactory;
import com.mercury.topaz.cmdb.reconciliation.server.identification.manager.IdentificationManager;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl.IDIdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl.InputIdToCmdbDatasMappingFactory;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.impl.IdentificationRuleInputFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocCmdbMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.chunk.ChunkRequest;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.CmdbLinkResultEntry;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.CmdbObjectResultEntry;
import com.mercury.topaz.cmdb.shared.tql.util.TqlResultMapUtils;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class IdentificationCommandValidateRule extends AbstractIdentificationCommandOperation
{
  public static final String INVALID_DATA_MAP = "invalidDataMap";
  private IdentificationRule _identificationRule;
  private String _type;
  private Map<CmdbDataID, Collection<? extends CmdbData>> _invalidDataMap;

  public IdentificationCommandValidateRule(String type, IdentificationRule identificationRule)
  {
    setIdentificationRule(identificationRule);
    setType(type);
    setInvalidDataMap(new HashMap());
  }

  public String getOperationName() {
    return "Identification Command - Validate Rule";
  }

  public void identificationCommandExecute(IdentificationManager identificationManager, CmdbResponse response)
  {
    if (getIdentificationRule() instanceof IDIdentificationRule) {
      return;
    }

    PatternElementNumber elementNumber = PatternElementNumberFactory.createElementNumber(101);
    Pattern layoutPattern = getIdentificationRule().getLayoutPattern(getType(), elementNumber);
    TqlQueryGetAdHocCmdbMap runTql = new TqlQueryGetAdHocCmdbMap(layoutPattern, null);
    identificationManager.executeOperation(runTql);
    TqlResultMap resultMap = (runTql.isDividedToChunks()) ? getResultInChunks(identificationManager, runTql.getChunkRequest()) : runTql.getResultMap();

    DataContainer dataContainer = buildDataContainersFromResult(resultMap, elementNumber);
    if (!(dataContainer.isDataForUpdateEmpty()))
      validateRule(identificationManager, dataContainer);

    response.addResult("invalidDataMap", (Serializable)this._invalidDataMap);
  }

  public void updateWithResponse(CmdbResponse response)
  {
    setInvalidDataMap((Map)response.getResult("invalidDataMap"));
  }

  private DataContainer buildDataContainersFromResult(TqlResultMap resultMap, PatternElementNumber elementNumber)
  {
    DataContainer dataContainer = DataContainerFactory.createDataContainer();

    if (!(resultMap.containsElementNumber(elementNumber))) {
      return dataContainer;
    }

    ReadOnlyIterator objectsIt = resultMap.getObjectResultEntryIterator();
    while (objectsIt.hasNext()) {
      CmdbObjectResultEntry currentResultEntry = (CmdbObjectResultEntry)objectsIt.next();
      CmdbObjects objects = (CmdbObjects)currentResultEntry.getObjects();
      if (currentResultEntry.getElementNumber().equals(elementNumber))
      {
        dataContainer.addObjectsForUpdate(objects);
      }
      else
      {
        dataContainer.addReferencedObjects(objects);
      }

    }

    ReadOnlyIterator linksIt = resultMap.getLinkResultEntryIterator();
    while (linksIt.hasNext()) {
      CmdbLinkResultEntry currentResultEntry = (CmdbLinkResultEntry)linksIt.next();
      CmdbLinks links = currentResultEntry.getLinks();
      if (currentResultEntry.getElementNumber().equals(elementNumber))
      {
        dataContainer.addLinksForUpdate(links);
      }
      else
      {
        dataContainer.addReferencedLinks(links);
      }
    }
    return dataContainer;
  }

  private TqlResultMap getResultInChunks(OperationExecutor executor, ChunkRequest chunkRequest) {
    return TqlResultMapUtils.getResultInChunks(chunkRequest, executor, true);
  }

  private void validateRule(IdentificationManager manager, DataContainer dataContainer) {
    CmdbClassModel classModel = manager.getSynchronizedClassModel();

    ReconciliationEnvironment env = ReconciliationEnvironmentFactory.createReconciliationRuleEnvironment(DataFactoryCreator.create(classModel), classModel);
    InputIdToCmdbDatasMapping exisitngData = InputIdToCmdbDatasMappingFactory.create(dataContainer.getObjectsForUpdateSize());
    IdentificationRuleInput input = IdentificationRuleInputFactory.create(env, dataContainer, getType(), exisitngData, IdentificationScope.BULK);
    getIdentificationRule().identify(input);

    Iterator it = exisitngData.iteratorInBulk();
    while (it.hasNext()) {
      Map.Entry entry = (Map.Entry)it.next();
      if (!(((Collection)entry.getValue()).isEmpty()))
      {
        this._invalidDataMap.put(entry.getKey(), entry.getValue());
      }
    }
  }

  private IdentificationRule getIdentificationRule() {
    return this._identificationRule;
  }

  private void setIdentificationRule(IdentificationRule identificationRule) {
    this._identificationRule = identificationRule;
  }

  private String getType() {
    return this._type;
  }

  private void setType(String type) {
    this._type = type;
  }

  public Map<CmdbDataID, Collection<? extends CmdbData>> getInvalidDataMap() {
    return this._invalidDataMap;
  }

  private void setInvalidDataMap(Map<CmdbDataID, Collection<? extends CmdbData>> invalidDataMap) {
    this._invalidDataMap = invalidDataMap;
  }
}