package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.merge.manager.MergeManager;
import com.mercury.topaz.cmdb.reconciliation.server.merge.operation.collections.MergeInput;
import com.mercury.topaz.cmdb.reconciliation.server.utils.ModelUtil;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementTypeLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocCmdbMap;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetNeighborsMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.impl.EmptyTqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.resultentry.CmdbLinkResultEntry;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MergeTopologyQueryOperation extends AbstractMergeQueryOperation
{
  private final List<MergeInput<CmdbObject>> _input;
  private final PatternCreator _patternCreator;
  private Map<CmdbObjectID, MergeTopologyOutput> _output;
  private Map<CmdbDataID, CmdbDataID> _oldToNewObjectMap;
  private Map<CmdbObjectID, MergeTopologyOutput> _objectIdToMergeOutput;
  private final boolean _shouldRemoveMainObjects;
  int nodeNumber;
  protected final PatternElementNumber containsObjectsNodeNumber;
  protected final PatternElementNumber compoundContainerLinkElementNumber;
  protected final PatternElementNumber containedObjectsNodeNumber;
  protected final PatternElementNumber innerObjectsElementNumber;
  protected final PatternElementNumber innerLinksElementNumber;

  public MergeTopologyQueryOperation(List<MergeInput<CmdbObject>> input, PatternCreator patternCreator, boolean shouldRemoveMainObjects)
  {
    this.nodeNumber = 0;
    this.containsObjectsNodeNumber = PatternElementNumberFactory.createElementNumber(this.nodeNumber++);
    this.compoundContainerLinkElementNumber = PatternElementNumberFactory.createElementNumber(this.nodeNumber++);
    this.containedObjectsNodeNumber = PatternElementNumberFactory.createElementNumber(this.nodeNumber++);

    this.innerObjectsElementNumber = PatternElementNumberFactory.createElementNumber(this.nodeNumber++);
    this.innerLinksElementNumber = PatternElementNumberFactory.createElementNumber(this.nodeNumber);

    if ((null == input) || (input.size() < 1))
      throw new IllegalArgumentException("merge topology must receive at least 1 MergeInput!!!");
    this._input = input;
    this._patternCreator = patternCreator;
    this._shouldRemoveMainObjects = shouldRemoveMainObjects;
  }

  public MergeTopologyQueryOperation(List<MergeInput<CmdbObject>> input)
  {
    this.nodeNumber = 0;
    this.containsObjectsNodeNumber = PatternElementNumberFactory.createElementNumber(this.nodeNumber++);
    this.compoundContainerLinkElementNumber = PatternElementNumberFactory.createElementNumber(this.nodeNumber++);
    this.containedObjectsNodeNumber = PatternElementNumberFactory.createElementNumber(this.nodeNumber++);

    this.innerObjectsElementNumber = PatternElementNumberFactory.createElementNumber(this.nodeNumber++);
    this.innerLinksElementNumber = PatternElementNumberFactory.createElementNumber(this.nodeNumber);

    if ((null == input) || (input.size() < 1))
      throw new IllegalArgumentException("merge topology must receive at least 1 MergeInput!!!");
    this._input = input;
    this._patternCreator = new DefaultPatternCreator(this);
    this._shouldRemoveMainObjects = true;
  }

  private void initOutput(TqlResultMap resultMap) {
    this._output = new HashMap(this._input.size());
    for (Iterator i$ = this._input.iterator(); i$.hasNext(); ) { MergeInput mergeInput = (MergeInput)i$.next();
      if (mergeInput.getNumberOfDatas() < 1)
        throw new IllegalArgumentException("cannot merge topology with less then 2 objects. nothing to merge!!!");

      this._output.put(((CmdbObject)mergeInput.getUpdatingData()).getID(), new MergeTopologyOutput());
    }
    this._oldToNewObjectMap = new HashMap(resultMap.size());
    this._objectIdToMergeOutput = new HashMap(resultMap.objectsSize());
  }

  protected void mergeQueryExecute(MergeManager manager, CmdbResponse response) throws CmdbException {
    DataFactory dataFactory = DataFactoryCreator.create(manager.getSynchronizedClassModel());

    replaceObjects(getAllObjectsToReplace(), dataFactory);
    replaceLinks(getAllLinksToReplace(), dataFactory);
  }

  void replaceObjects(TopologyResult topologyResult, DataFactory dataFactory)
  {
    TqlResultMap resultMap = topologyResult.getResultMap();
    initOutput(resultMap);
    CmdbObjects containedObjects = getObjectsFromResultMap(resultMap, topologyResult.getObjectsToReplaceElementNumbers());

    Map containerLinksByEnd1Id = getLinksByEnd1IdMap(resultMap);

    for (Iterator i$ = this._input.iterator(); i$.hasNext(); ) { MergeInput mergeInput = (MergeInput)i$.next();
      CmdbObject updatingObject = (CmdbObject)mergeInput.getUpdatingData();
      CmdbObjectID updatingObjectID = (CmdbObjectID)updatingObject.getID();
      MergeTopologyOutput output = (MergeTopologyOutput)this._output.get(updatingObjectID);

      output.getObjectsToAdd().add(updatingObject);

      for (Iterator i$ = mergeInput.getDatasToMerge().iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
        if (shouldRemoveObjectFromCmdb(dataFactory.getClassModel(), object, updatingObject)) {
          if (this._shouldRemoveMainObjects)
            output.getObjectsToRemove().add(object);

          this._oldToNewObjectMap.put(object.getID(), updatingObjectID);
          this._objectIdToMergeOutput.put(object.getID(), output);
          mergeTopology(dataFactory, containedObjects, containerLinksByEnd1Id, (CmdbObjectID)object.getID(), updatingObjectID, output);
        }
      }
    }
  }

  private boolean shouldRemoveObjectFromCmdb(CmdbClassModel classModel, CmdbObject objectFromCmdb, CmdbObject updatingObject) {
    return ((!(((CmdbObjectID)objectFromCmdb.getID()).equals(updatingObject.getID()))) || ((!(objectFromCmdb.getType().equals(updatingObject.getType()))) && (classModel.isDescendant(objectFromCmdb.getType(), updatingObject.getType()))));
  }

  private void mergeTopology(DataFactory dataFactory, CmdbObjects containedObjects, Map<CmdbObjectID, CmdbLinks> containerLinksByEnd1Id, CmdbObjectID id, CmdbObjectID newId, MergeTopologyOutput output)
  {
    CmdbLinks cmdbLinks = (CmdbLinks)containerLinksByEnd1Id.get(id);
    if (null != cmdbLinks)
      for (Iterator i$ = cmdbLinks.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
        CmdbObjectID end2ObjectId = link.getEnd2();
        CmdbObject end2Object = (CmdbObject)containedObjects.get(end2ObjectId);
        CmdbObject newEnd2Object = createNewObject(dataFactory, end2Object, newId);
        CmdbObjectID newEnd2ObjectId = (CmdbObjectID)newEnd2Object.getID();

        CmdbClass linkClass = dataFactory.getClassModel().getClass(link.getType());
        if ((!(((CmdbObjectID)end2Object.getID()).equals(newEnd2Object.getID()))) || ((linkClass != null) && (linkClass.hasQualifier(CmdbClassQualifierDefs.RECURSIVE_DELETE.getName())))) {
          output.getObjectsToRemove().add(end2Object);
          output.getObjectsToAdd().add(newEnd2Object);

          this._oldToNewObjectMap.put(end2ObjectId, newEnd2ObjectId);
          this._objectIdToMergeOutput.put(end2ObjectId, output);

          mergeTopology(dataFactory, containedObjects, containerLinksByEnd1Id, end2ObjectId, newEnd2ObjectId, output);
        }
      }
  }

  private static CmdbObjects getObjectsFromResultMap(TqlResultMap tqlResultMap, Collection<PatternElementNumber> elementNumbers)
  {
    int size = 0;
    for (Iterator i$ = elementNumbers.iterator(); i$.hasNext(); ) { PatternElementNumber elementNumber = (PatternElementNumber)i$.next();
      if (tqlResultMap.containsElementNumber(elementNumber))
        size += tqlResultMap.getObjects(elementNumber).size();

    }

    if (size <= 0) {
      return CmdbObjectFactory.createEmptyObjects();
    }

    CmdbObjects objects = CmdbObjectFactory.createHashMapObjects(size);
    for (Iterator i$ = elementNumbers.iterator(); i$.hasNext(); ) { PatternElementNumber elementNumber = (PatternElementNumber)i$.next();
      if (tqlResultMap.containsElementNumber(elementNumber)) {
        CmdbObjects resultObjects = tqlResultMap.getObjects(elementNumber);
        objects.add(resultObjects);
      }
    }
    return objects;
  }

  private CmdbLinks getLinksFromResultMap(TqlResultMap tqlResultMap, PatternElementNumber elementNumber)
  {
    if (tqlResultMap.containsElementNumber(elementNumber))
      return tqlResultMap.getLinks(elementNumber);
    return CmdbLinkFactory.createEmptyLinks();
  }

  private CmdbObjectID getFinalCmdbObjectID(CmdbObjectID id) {
    CmdbObjectID newId = (CmdbObjectID)getOldToNewObjectMap().get(id);
    return ((null == newId) ? id : newId);
  }

  private void replaceLink(MergeTopologyOutput output, CmdbLink link, CmdbLink newLink) {
    if (output != null) {
      output.getLinksToRemove().add(link);
      output.getLinksToAdd().add(newLink);
      if (link != newLink) {
        CmdbLinkID oldLinkID = (CmdbLinkID)link.getID();
        CmdbLinkID newLinkID = (CmdbLinkID)newLink.getID();
        this._oldToNewObjectMap.put(oldLinkID, newLinkID);
      }
    }
  }

  private Map<CmdbObjectID, CmdbLinks> getLinksByEnd1IdMap(TqlResultMap tqlResultMap) {
    Map linksByEnd1Id = new HashMap();
    for (ReadOnlyIterator linkResultEntryIterator = tqlResultMap.getLinkResultEntryIterator(); linkResultEntryIterator.hasNext(); )
      for (Iterator i$ = ((CmdbLinkResultEntry)linkResultEntryIterator.next()).getLinks().iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
        CmdbObjectID end1 = link.getEnd1();
        if (linksByEnd1Id.containsKey(end1)) {
          ((CmdbLinks)linksByEnd1Id.get(end1)).add(link);
        } else {
          CmdbLinks links = CmdbLinkFactory.createLinks();
          links.add(link);
          linksByEnd1Id.put(end1, links);
        }
      }

    return linksByEnd1Id;
  }

  private CmdbLink createNewLink(DataFactory dataFactory, CmdbLink oldLink, CmdbObjectID newEnd1Id, CmdbObjectID newEnd2Id) {
    if ((newEnd1Id.equals(oldLink.getEnd1())) && (newEnd2Id.equals(oldLink.getEnd2())))
      return oldLink;

    return dataFactory.createLink(oldLink.getType(), newEnd1Id, newEnd2Id, oldLink.getUnmodifiableProperties());
  }

  private CmdbObject createNewObject(DataFactory dataFactory, CmdbObject oldObject, CmdbObjectID containerId) {
    CmdbProperties cmdbProperties = CmdbPropertyFactory.createProperties();
    ReadOnlyIterator iter = oldObject.getPropertiesIterator();
    boolean isPropertyChanged = false;
    while (iter.hasNext()) {
      CmdbProperty cmdbProperty = (CmdbProperty)iter.next();
      if (!(ModelUtil.isContainerProperty(oldObject.getType(), cmdbProperty, dataFactory.getClassModel()))) {
        cmdbProperties.add(cmdbProperty);
      } else {
        cmdbProperties.add(CmdbPropertyFactory.createProperty(cmdbProperty.getKey(), containerId.toString()));
        isPropertyChanged = true;
      }
    }
    return ((isPropertyChanged) ? dataFactory.createObject(oldObject.getType(), cmdbProperties) : oldObject);
  }

  private TopologyResult getAllObjectsToReplace() {
    PatternAndLayoutContainer patternAndLayoutContainer = createPatternToGetObjectsToReplace();
    Pattern pattern = patternAndLayoutContainer.getPattern();
    TqlQueryGetAdHocCmdbMap queryGetAdHocMap = new TqlQueryGetAdHocCmdbMap(pattern, pattern.getLayout());
    ServerApiFacade.executeOperation(queryGetAdHocMap);
    TqlResultMap resultMap = (queryGetAdHocMap.isDividedToChunks()) ? DataInUtil.getResultInChunks(queryGetAdHocMap.getChunkRequest()) : queryGetAdHocMap.getResultMap();
    return new TopologyResult(resultMap, patternAndLayoutContainer.getElementNumbersToReplace());
  }

  protected PatternAndLayoutContainer createPatternToGetObjectsToReplace()
  {
    return this._patternCreator.create(createInputIds());
  }

  private CmdbObjectIds createInputIds()
  {
    CmdbObjectIds cmdbObjectIds = CmdbObjectIdsFactory.create();
    for (Iterator i$ = this._input.iterator(); i$.hasNext(); ) { MergeInput mergeInput = (MergeInput)i$.next();
      Iterator objectsIter = mergeInput.getDatasIteratorToMerge();
      cmdbObjectIds.add((CmdbObjectID)((CmdbObject)mergeInput.getUpdatingData()).getID());
      while (objectsIter.hasNext())
        cmdbObjectIds.add((CmdbObjectID)((CmdbObject)objectsIter.next()).getID());
    }
    return cmdbObjectIds;
  }

  private TqlResultMap getAllLinksToReplace() {
    CmdbObjects objectsToRemove = getAllObjectsToRemove(getOutput());

    if (objectsToRemove.isEmpty())
      return EmptyTqlResultMap.getInstance();

    CmdbObjectIds ids = CmdbObjectIdsFactory.createIdsList(this._oldToNewObjectMap.size());
    for (Iterator i$ = objectsToRemove.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
      ids.add((CmdbObjectID)object.getID());
    }

    ElementTypeLayout elementLayout = PatternLayoutFactory.createTypeLayout();
    elementLayout.addSimpleLayout("link", createFullLayout());
    TqlQueryGetNeighborsMap queryGetNeighborsGraph = new TqlQueryGetNeighborsMap(null, ids, 1, "link", Arrays.asList(new String[] { "object" }), elementLayout);
    ServerApiFacade.executeOperation(queryGetNeighborsGraph);
    return queryGetNeighborsGraph.getResultMap();
  }

  private static ElementSimpleLayout createFullLayout() {
    ElementSimpleLayout fullLayout = PatternLayoutFactory.createElementSimpleLayout();
    fullLayout.setAllLayer(true);
    return fullLayout;
  }

  void replaceLinks(TqlResultMap tqlResultMap, DataFactory dataFactory) {
    ReadOnlyIterator linksEntryReadOnlyIterator = tqlResultMap.getLinkResultEntryIterator();
    while (linksEntryReadOnlyIterator.hasNext()) {
      CmdbLinkResultEntry linkResultEntry = (CmdbLinkResultEntry)linksEntryReadOnlyIterator.next();
      CmdbLinks cmdbLinks = linkResultEntry.getLinks();
      for (Iterator i$ = cmdbLinks.iterator(); i$.hasNext(); ) { CmdbLink linkToReplace = (CmdbLink)i$.next();
        CmdbObjectID finalEnd1Id = getFinalCmdbObjectID(linkToReplace.getEnd1());
        CmdbObjectID finalEnd2Id = getFinalCmdbObjectID(linkToReplace.getEnd2());
        CmdbLink newLink = createNewLink(dataFactory, linkToReplace, finalEnd1Id, finalEnd2Id);
        MergeTopologyOutput output1 = (MergeTopologyOutput)this._objectIdToMergeOutput.get(linkToReplace.getEnd1());
        MergeTopologyOutput output2 = (MergeTopologyOutput)this._objectIdToMergeOutput.get(linkToReplace.getEnd2());
        replaceLink(output1, linkToReplace, newLink);
        replaceLink(output2, linkToReplace, newLink);
      }
    }
  }

  public String getOperationName() {
    return "Merge CIs Topology";
  }

  public Map<CmdbObjectID, MergeTopologyOutput> getOutput() {
    return this._output;
  }

  public Map<CmdbDataID, CmdbDataID> getOldToNewObjectMap() {
    return this._oldToNewObjectMap;
  }

  public static CmdbObjects getAllObjectsToAdd(Map<CmdbObjectID, MergeTopologyOutput> outputMap) {
    CmdbObjects objects = CmdbObjectFactory.createObjects();
    for (Iterator i$ = outputMap.values().iterator(); i$.hasNext(); ) { MergeTopologyOutput output = (MergeTopologyOutput)i$.next();
      objects.add(output.getObjectsToAdd()); }
    return objects;
  }

  public static CmdbObjects getAllObjectsToRemove(Map<CmdbObjectID, MergeTopologyOutput> outputMap) {
    CmdbObjects objects = CmdbObjectFactory.createObjects();
    for (Iterator i$ = outputMap.values().iterator(); i$.hasNext(); ) { MergeTopologyOutput output = (MergeTopologyOutput)i$.next();
      objects.add(output.getObjectsToRemove()); }
    return objects;
  }

  public static CmdbLinks getAllLinksToAdd(Map<CmdbObjectID, MergeTopologyOutput> outputMap) {
    CmdbLinks links = CmdbLinkFactory.createLinks();
    for (Iterator i$ = outputMap.values().iterator(); i$.hasNext(); ) { MergeTopologyOutput output = (MergeTopologyOutput)i$.next();
      links.add(output.getLinksToAdd()); }
    return links;
  }

  public static CmdbLinks getAllLinksToRemove(Map<CmdbObjectID, MergeTopologyOutput> outputMap) {
    CmdbLinks links = CmdbLinkFactory.createLinks();
    for (Iterator i$ = outputMap.values().iterator(); i$.hasNext(); ) { MergeTopologyOutput output = (MergeTopologyOutput)i$.next();
      links.add(output.getLinksToRemove()); }
    return links;
  }

  class DefaultPatternCreator extends AbstractPatternCreator
  {
    public PatternAndLayoutContainer create()
    {
      ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
      addNodeWithIdConditionFromInput(patternGraph, this.this$0.containsObjectsNodeNumber, "object", idsFromInput);
      addNode(patternGraph, this.this$0.containedObjectsNodeNumber, "object");
      addCompoundLink(patternGraph, this.this$0.compoundContainerLinkElementNumber, this.this$0.containsObjectsNodeNumber, this.this$0.containedObjectsNodeNumber, this.this$0.innerObjectsElementNumber, this.this$0.innerLinksElementNumber);

      Pattern pattern = PatternDefinitionFactory.createPattern("Merge Topology Pattern!", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);
      pattern.getLayout().setElementLayout(this.this$0.containedObjectsNodeNumber, createFullLayout());

      return new PatternAndLayoutContainer(pattern, Arrays.asList(new PatternElementNumber[] { this.this$0.containedObjectsNodeNumber }));
    }
  }
}