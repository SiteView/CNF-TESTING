package com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.ReconciliationConfigDef;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import java.util.Collection;
import java.util.Map;

public abstract interface ReconciliationConfigCacheManager extends CmdbSubsystemManager
{
  public abstract boolean isConfigExists(String paramString);

  public abstract ReconciliationConfigDef getConfigDef(String paramString);

  public abstract void addOrUpdateConfigDef(ReconciliationConfigDef paramReconciliationConfigDef);

  public abstract void removeConfigDef(String paramString);

  public abstract Collection<String> getOwnersByType(String paramString, CmdbClassModel paramCmdbClassModel);

  public abstract boolean isOwnerByType(String paramString1, String paramString2, CmdbClassModel paramCmdbClassModel);

  public abstract DataInRule getDataInRuleByType(String paramString, CmdbClassModel paramCmdbClassModel);

  public abstract Collection<IdentificationRule> getIdentificationRuleByType(String paramString, CmdbClassModel paramCmdbClassModel);

  public abstract Collection<Pattern> getIdentificationLayoutPatternForLinkType(String paramString, CmdbClassModel paramCmdbClassModel);

  public abstract Map<String, String> getActualIdentificationRuleConfiguredTypes(Collection<String> paramCollection);

  public abstract Map<String, String> getActualDataInRuleConfiguredTypes(Collection<String> paramCollection);
}