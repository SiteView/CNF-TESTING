package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.exception.DataInException;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalOperator;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCardinality;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

class ConnectedCondition extends Condition
{
  private final String _linkType;
  private final Direction _direction;
  private final String _ciType;
  private final PatternElementNumber _linkElementNumber;

  ConnectedCondition(Collection<String> attributes, Collection<FixedValueAttribute> fixedValueAttributes, boolean idCondition, Collection<ConnectedCondition> connectedConditions, String linkType, boolean isDirectionForward, String ciType)
  {
    super(attributes, fixedValueAttributes, idCondition, connectedConditions);

    this._linkElementNumber = PatternElementNumberCreator.create();

    this._linkType = linkType;
    this._direction = new DirectionForward();
    this._ciType = ciType;
  }

  ConnectedCondition(Condition cond, String linkType, boolean isDirectionForward, String ciType) {
    this(cond.getAttributes(), cond.getFixedValueAttributes(), cond.isIdCondition(), cond.getConnectedConditions(), linkType, isDirectionForward, ciType);
  }

  public void addConnectedNodeToLayoutPattern(ModifiablePattern pattern, PatternElementNumber srcElementNumber)
  {
    addNodeToLayoutPattern(pattern, getCiType(), getElementNumber());

    ModifiableNodeLinksCondition modifiableNodeLinksCondition = pattern.getModifiableGraph().getModifiableNode(getElementNumber()).getModifiableLinksCondition();
    if (modifiableNodeLinksCondition.getNumberOfElements() > 0)
      modifiableNodeLinksCondition.addLogicalOperator(LogicalOperator.AND);

    modifiableNodeLinksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(getLinkElementNumber().getNumber(), 1, -1));

    ModifiableElementCondition linkCondition = PatternConditionFactory.createElementCondition(getLinkType(), true);
    PatternLink patternLink = getDirection().createPatternLink(getLinkElementNumber(), srcElementNumber, getElementNumber(), linkCondition, true);
    pattern.getModifiableGraph().addLink(patternLink);
  }

  public boolean addConnectedNodeToPattern(ModifiablePattern pattern, PatternElementNumber srcElementNumber, IdentificationRuleInput input, Map<PatternElementNumber, InputObjectIdentifierToCmdbDataMap<? extends CmdbDataID>> inputObjectsIdentifierToIdsMaps, InputIdToCmdbDatasMapping alreadyIdentifiedData, IdentificationScope identificationScope) {
    boolean conditionWasAdded = false;
    InputObjectIdentifierToCmdbDataMap inputObjectsIdentifierToIdsMap = new InputObjectIdentifierToCmdbDataMap();
    inputObjectsIdentifierToIdsMaps.put(getElementNumber(), inputObjectsIdentifierToIdsMap);
    InputObjectIdentifierToCmdbDataMap inputLinksIdentifierToIdsMap = new InputObjectIdentifierToCmdbDataMap();
    inputObjectsIdentifierToIdsMaps.put(getLinkElementNumber(), inputLinksIdentifierToIdsMap);

    DataFactory dataFactory = input.getReconciliationRuleEnvironment().getDataFactory();
    CmdbClassModel classModel = input.getReconciliationRuleEnvironment().getCmdbClassModel();
    DataContainer dataContainer = input.getDataContainer();
    CmdbObjects objectsToIdentify = dataContainer.getObjectsForUpdate(input.getTypeToIdentify());

    CmdbObjects connectedObjects = CmdbObjectFactory.createObjects();
    CmdbLinks links = CmdbLinkFactory.createLinks();
    for (Iterator i$ = objectsToIdentify.iterator(); i$.hasNext(); ) { CmdbObject object = (CmdbObject)i$.next();
      CmdbLinks cmdbLinks = getDirection().getLinksFromDataContainerBySource(dataContainer, (CmdbObjectID)object.getID());
      for (Iterator i$ = cmdbLinks.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
        String linkActualType = link.getType();
        if (classModel.isTypeOf(getLinkType(), linkActualType)) {
          CmdbObject connectedObject = dataContainer.getCmdbObject(getDirection().getTarget(link));
          if (null == connectedObject)
            throw new DataInException("The link <" + link + "> is used for identification! data container doesn't include end2/1!!!");

          String connectedObjectActualType = connectedObject.getType();
          if (classModel.isTypeOf(getCiType(), connectedObjectActualType)) {
            connectedObjects.add(connectedObject);
            links.add(link);
          }
        }
      }
    }
    if (!(links.isEmpty())) {
      conditionWasAdded = addNode(pattern, dataFactory, inputObjectsIdentifierToIdsMap, getCiType(), true, connectedObjects, alreadyIdentifiedData, identificationScope);
      if (conditionWasAdded) {
        addLink(pattern, srcElementNumber, links, inputLinksIdentifierToIdsMap);

        ModifiableNodeLinksCondition linksCondition = PatternConditionFactory.createNodeLinksCondition();
        int linkNumber = getLinkElementNumber().getNumber();
        LinkCardinality linkCardinality = PatternConditionFactory.createLinkCardinality(linkNumber, 1, -1);
        linksCondition.addLinkCardinality(linkCardinality);
        pattern.getModifiableGraph().getModifiableNode(getElementNumber()).setLinksCondition(linksCondition);

        ModifiableNodeLinksCondition srcNodeModifiableNodeLinksCondition = pattern.getModifiableGraph().getModifiableNode(srcElementNumber).getModifiableLinksCondition();
        if (srcNodeModifiableNodeLinksCondition.getNumberOfElements() > 0)
          srcNodeModifiableNodeLinksCondition.addLogicalOperator(LogicalOperator.AND);

        srcNodeModifiableNodeLinksCondition.addLinkCardinality(linkCardinality);
      }
    }
    return conditionWasAdded;
  }

  private void addLink(ModifiablePattern pattern, PatternElementNumber srcElementNumber, CmdbLinks links, InputObjectIdentifierToCmdbDataMap<CmdbLinkID> inputLinksIdentifierToIdsMap) {
    ModifiableElementCondition linkCondition = PatternConditionFactory.createElementCondition(getLinkType(), true);
    PatternLink patternLink = getDirection().createPatternLink(getLinkElementNumber(), srcElementNumber, getElementNumber(), linkCondition, true);
    pattern.getModifiableGraph().addLink(patternLink);

    for (Iterator i$ = links.iterator(); i$.hasNext(); ) { CmdbLink link = (CmdbLink)i$.next();
      inputLinksIdentifierToIdsMap.addToMap(InputObjectIdentifierEmpty.instance(), (CmdbDataID)link.getID());
    }
  }

  protected void addToNodeLinksCondition(ModifiableNodeLinksCondition linksCondition) {
    super.addToNodeLinksCondition(linksCondition);
    if (linksCondition.getNumberOfElements() > 0) {
      linksCondition.addLogicalOperator(LogicalOperator.AND);
    }

    linksCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(getLinkElementNumber().getNumber(), 1, -1));
  }

  protected InputObjectIdentifier createLinkIdentifier() {
    return InputObjectIdentifierEmpty.instance();
  }

  public String getLinkType() {
    return this._linkType;
  }

  public Direction getDirection() {
    return this._direction;
  }

  public String getCiType() {
    return this._ciType;
  }

  public PatternElementNumber getLinkElementNumber() {
    return this._linkElementNumber;
  }
}