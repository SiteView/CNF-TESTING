package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.impl;

import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class InputIdToCmdbDatasMappingImpl
  implements InputIdToCmdbDatasMapping
{
  private final Map<String, Collection<? extends CmdbData>> _byStringMap;
  private final Map<CmdbDataID, Collection<? extends CmdbData>> _byDataIdMap;
  private final Map<String, Collection<? extends CmdbData>> _byStringMapInBulk;
  private final Map<CmdbDataID, Collection<? extends CmdbData>> _byDataIdMapInBulk;

  public InputIdToCmdbDatasMappingImpl(int initSize)
  {
    this._byStringMap = new HashMap(initSize);
    this._byDataIdMap = new HashMap(initSize);
    this._byStringMapInBulk = new HashMap(initSize);
    this._byDataIdMapInBulk = new HashMap(initSize);
  }

  public Collection<? extends CmdbData> get(String toStringID)
  {
    return ((Collection)this._byStringMap.get(toStringID));
  }

  public Collection<? extends CmdbData> get(CmdbDataID id) {
    return ((Collection)this._byDataIdMap.get(id));
  }

  public boolean containsKey(String toStringID) {
    return this._byStringMap.containsKey(toStringID);
  }

  public boolean containsKey(CmdbDataID id) {
    return this._byDataIdMap.containsKey(id);
  }

  public boolean containsKeyWithNotEmptyValue(String toStringID) {
    Collection values = get(toStringID);
    return ((values != null) && (!(values.isEmpty())));
  }

  public boolean containsKeyWithNotEmptyValue(CmdbDataID id) {
    Collection values = get(id);
    return ((values != null) && (!(values.isEmpty())));
  }

  public int size() {
    return this._byDataIdMap.size();
  }

  public void add(CmdbDataID id, Collection<? extends CmdbData> datas) {
    if ((!($assertionsDisabled)) && (id == null)) throw new AssertionError();
    if ((!($assertionsDisabled)) && (datas == null)) throw new AssertionError();
    append(id, datas);
  }

  private void append(CmdbDataID id, Collection<? extends CmdbData> datasToAppend)
  {
    Collection cmdbDatas = (Collection)this._byDataIdMap.get(id);
    if (cmdbDatas == null) {
      overrideAdd(id, datasToAppend);
    }
    else if (id.isObjectID())
      cmdbDatas.addAll(datasToAppend);
    else
      cmdbDatas.addAll(datasToAppend);
  }

  private void overrideAdd(CmdbDataID id, Collection<? extends CmdbData> datas)
  {
    this._byDataIdMap.put(id, datas);
    this._byStringMap.put(id.toString(), datas);
  }

  public void addAll(InputIdToCmdbDatasMapping mapping) {
    Map.Entry entry;
    CmdbDataID key;
    Collection datas;
    for (Iterator i$ = mapping.iterator(); i$.hasNext(); ) { entry = (Map.Entry)i$.next();
      key = (CmdbDataID)entry.getKey();
      datas = (Collection)entry.getValue();
      append(key, datas);
    }
    Iterator it = mapping.iteratorInBulk();
    while (it.hasNext()) {
      entry = (Map.Entry)it.next();
      key = (CmdbDataID)entry.getKey();
      datas = (Collection)entry.getValue();
      appendInBulk(key, datas);
    }
  }

  public Iterator<Map.Entry<CmdbDataID, Collection<? extends CmdbData>>> iterator() {
    return this._byDataIdMap.entrySet().iterator();
  }

  public void addInBulk(CmdbDataID id, Collection<? extends CmdbData> datas)
  {
    if ((!($assertionsDisabled)) && (id == null)) throw new AssertionError();
    if ((!($assertionsDisabled)) && (datas == null)) throw new AssertionError();
    appendInBulk(id, datas);
  }

  private void appendInBulk(CmdbDataID id, Collection<? extends CmdbData> datasToAppend)
  {
    Collection cmdbDatas = (Collection)this._byDataIdMapInBulk.get(id);
    if (cmdbDatas == null) {
      overrideAddInBulk(id, datasToAppend);
    }
    else if (id.isObjectID())
      cmdbDatas.addAll(datasToAppend);
    else
      cmdbDatas.addAll(datasToAppend);
  }

  private void overrideAddInBulk(CmdbDataID id, Collection<? extends CmdbData> datas)
  {
    this._byDataIdMapInBulk.put(id, datas);
    this._byStringMapInBulk.put(id.toString(), datas);
  }

  public Collection<? extends CmdbData> getInBulk(String toStringID) {
    return ((Collection)this._byStringMapInBulk.get(toStringID));
  }

  public Collection<? extends CmdbData> getInBulk(CmdbDataID id) {
    return ((Collection)this._byDataIdMapInBulk.get(id));
  }

  public boolean containsKeyInBulk(String toStringID) {
    return this._byStringMapInBulk.containsKey(toStringID);
  }

  public boolean containsKeyInBulk(CmdbDataID id) {
    return this._byDataIdMapInBulk.containsKey(id);
  }

  public boolean containsKeyWithNotEmptyValueInBulk(String toStringID) {
    Collection values = getInBulk(toStringID);
    return ((values != null) && (!(values.isEmpty())));
  }

  public boolean containsKeyWithNotEmptyValueInBulk(CmdbDataID id) {
    Collection values = getInBulk(id);
    return ((values != null) && (!(values.isEmpty())));
  }

  public int sizeInBulk() {
    return this._byDataIdMapInBulk.size();
  }

  public Iterator<Map.Entry<CmdbDataID, Collection<? extends CmdbData>>> iteratorInBulk() {
    return this._byDataIdMapInBulk.entrySet().iterator();
  }

  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("InputIdToCmdbDatasMappingImpl>existingData:");
    append(sb, 1, this._byDataIdMap);
    sb.append("\nInputIdToCmdbDatasMappingImpl>existingDataInBulk:");
    append(sb, 1, this._byDataIdMapInBulk);
    return sb.toString();
  }

  private static <Type1, Type2> StringBuilder append(StringBuilder sb, int numberOfTabs, Map<Type1, Type2> map) {
    for (Iterator i$ = map.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      append(sb, numberOfTabs, entry);
    }
    return sb;
  }

  private static <Type1, Type2> StringBuilder append(StringBuilder sb, int numberOfTabs, Map.Entry<Type1, Type2> entry) {
    sb.append("\n");
    appendTabs(sb, numberOfTabs);
    sb.append("key=<").append(entry.getKey()).append(">\n");
    appendTabs(sb, numberOfTabs);
    sb.append("\tvalue=<").append(entry.getValue()).append(">");
    return sb;
  }

  private static void appendTabs(StringBuilder sb, int numberOfTabs) {
    for (int i = 0; i < numberOfTabs; ++i)
      sb.append("\t");
  }
}