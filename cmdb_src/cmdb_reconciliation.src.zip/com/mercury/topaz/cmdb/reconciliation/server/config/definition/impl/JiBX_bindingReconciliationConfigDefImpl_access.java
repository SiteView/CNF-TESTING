package com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl;

import org.jibx.runtime.IMarshaller;
import org.jibx.runtime.IUnmarshaller;

public class JiBX_bindingReconciliationConfigDefImpl_access
  implements IUnmarshaller, IMarshaller
{
}