package com.mercury.topaz.cmdb.reconciliation.server.id.link;

import com.mercury.topaz.cmdb.reconciliation.server.id.data.TempCmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;

public abstract interface TempCmdbLinkID
{
}