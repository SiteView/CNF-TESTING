package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class ReconciliationConfigCacheQueryIsConfigExists extends AbstractReconciliationConfigCacheQueryOperation
{
  public static final String CONFIG_DEF_EXISTS = "configDefExists";
  private String _configName;
  private Boolean _configExists;

  public ReconciliationConfigCacheQueryIsConfigExists(String configName)
  {
    setConfigName(configName);
  }

  public String getOperationName() {
    return "Reconciliation Config Cache Query - Get Config By Name";
  }

  public void configCacheQueryExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response) throws CmdbException {
    setConfigExists(Boolean.valueOf(configCacheManager.isConfigExists(getConfigName())));
    response.addResult("configDefExists", getConfigExists());
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setConfigExists((Boolean)response.getResult("configDefExists"));
  }

  private String getConfigName() {
    return this._configName;
  }

  private void setConfigName(String configName) {
    this._configName = configName;
  }

  public Boolean getConfigExists() {
    return this._configExists;
  }

  private void setConfigExists(Boolean configExists) {
    this._configExists = configExists;
  }
}