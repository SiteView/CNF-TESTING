package com.mercury.topaz.cmdb.reconciliation.server.datain.rule;

import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInRuleOutput;
import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import java.io.Serializable;

public abstract interface DataInRule extends Serializable
{
  public abstract DataInRuleOutput onAddOrUpdateData(ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput, boolean paramBoolean);

  public abstract DataInRuleOutput onAddOrIgnoreData(ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput);

  public abstract DataInRuleOutput onAddDataStrict(ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput);

  public abstract DataInRuleOutput onRemoveDataIfExist(ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput);

  public abstract DataInRuleOutput onRemoveDataStrict(ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput);

  public abstract DataInRuleOutput onUpdateDataIfExist(ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput);

  public abstract DataInRuleOutput onUpdateDataStrict(ReconciliationEnvironment paramReconciliationEnvironment, DataInRuleInput paramDataInRuleInput);

  public abstract DataInRuleDefinition getRuleDefinition();
}