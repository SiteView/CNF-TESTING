package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.impl.AbstractReconciliationConfigCacheOperation;
import com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.update.ReconciliationConfigCacheUpdateOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractReconciliationConfigCacheUpdateOperation extends AbstractReconciliationConfigCacheOperation
  implements ReconciliationConfigCacheUpdateOperation
{
  public void configCacheExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response)
    throws CmdbException
  {
    configCacheUpdateExecute(configCacheManager, response);
  }
}