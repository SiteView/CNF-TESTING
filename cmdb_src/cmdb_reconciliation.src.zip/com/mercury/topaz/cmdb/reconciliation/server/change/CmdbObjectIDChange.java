package com.mercury.topaz.cmdb.reconciliation.server.change;

public abstract interface CmdbObjectIDChange extends CmdbIDChange
{
}