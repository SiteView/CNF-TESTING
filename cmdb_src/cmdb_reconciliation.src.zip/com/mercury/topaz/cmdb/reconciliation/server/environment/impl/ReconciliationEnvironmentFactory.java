package com.mercury.topaz.cmdb.reconciliation.server.environment.impl;

import com.mercury.topaz.cmdb.reconciliation.server.environment.ReconciliationEnvironment;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;

public class ReconciliationEnvironmentFactory
{
  public static ReconciliationEnvironment createReconciliationRuleEnvironment(DataFactory dataFactory, CmdbClassModel cmdbClassModel)
  {
    return new ReconciliationEnvironmentImpl(dataFactory, cmdbClassModel);
  }
}