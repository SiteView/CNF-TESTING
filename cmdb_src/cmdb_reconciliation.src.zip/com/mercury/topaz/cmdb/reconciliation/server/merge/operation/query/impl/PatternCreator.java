package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl;

import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import java.io.Serializable;

public abstract interface PatternCreator extends Serializable
{
  public abstract PatternAndLayoutContainer create(CmdbObjectIds paramCmdbObjectIds);
}