package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl;

import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import java.util.Collection;

public class PatternAndLayoutContainer
{
  private final Pattern _pattern;
  private final Collection<PatternElementNumber> _elementNumbersToReplace;

  public PatternAndLayoutContainer(Pattern pattern, Collection<PatternElementNumber> elementNumbersToReplace)
  {
    this._pattern = pattern;
    this._elementNumbersToReplace = elementNumbersToReplace;
  }

  public Pattern getPattern() {
    return this._pattern;
  }

  public Collection<PatternElementNumber> getElementNumbersToReplace() {
    return this._elementNumbersToReplace;
  }
}