package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.DataInOperation;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCmdbOperation;

public abstract class AbstractDataInOperation extends AbstractCmdbOperation
  implements DataInOperation
{
  protected void doExecute(SubsystemManager manager, CmdbResponse response)
    throws CmdbException
  {
    dataInExecute((DataInManager)manager, response);
  }

  public String getServiceName() {
    return "CMDB_RECONCILE";
  }
}