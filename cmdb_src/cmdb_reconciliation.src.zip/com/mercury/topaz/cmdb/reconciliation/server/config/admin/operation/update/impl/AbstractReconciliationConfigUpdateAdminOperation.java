package com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.update.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.admin.manager.ReconciliationConfigAdminManager;
import com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.impl.AbstractReconciliationConfigAdminOperation;
import com.mercury.topaz.cmdb.reconciliation.server.config.admin.operation.update.ReconciliationConfigUpdateAdminOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;

public abstract class AbstractReconciliationConfigUpdateAdminOperation extends AbstractReconciliationConfigAdminOperation
  implements ReconciliationConfigUpdateAdminOperation
{
  private Changer _changer;

  protected AbstractReconciliationConfigUpdateAdminOperation(Changer changer)
  {
    setChanger(changer);
  }

  public void configExecute(ReconciliationConfigAdminManager configAdminManager, CmdbResponse response) throws CmdbException {
    configUpdateExecute(configAdminManager, response);
  }

  protected Changer getChanger() {
    return this._changer;
  }

  private void setChanger(Changer changer) {
    this._changer = changer;
  }
}