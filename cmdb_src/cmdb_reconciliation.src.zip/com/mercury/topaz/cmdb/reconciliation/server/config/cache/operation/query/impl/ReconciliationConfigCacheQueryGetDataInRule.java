package com.mercury.topaz.cmdb.reconciliation.server.config.cache.operation.query.impl;

import com.mercury.topaz.cmdb.reconciliation.server.config.cache.manager.ReconciliationConfigCacheManager;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.DataInRule;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class ReconciliationConfigCacheQueryGetDataInRule extends AbstractReconciliationConfigCacheQueryOperation
{
  public static final String DATA_IN_RULE = "dataInRule";
  private String _type;
  private DataInRule _dataInRule;

  public ReconciliationConfigCacheQueryGetDataInRule(String type)
  {
    setType(type);
  }

  public String getOperationName() {
    return "Reconciliation Config Cache Query - Get Data In Rule for " + getType();
  }

  public void configCacheQueryExecute(ReconciliationConfigCacheManager configCacheManager, CmdbResponse response) throws CmdbException {
    CmdbClassModel classModel = configCacheManager.getSynchronizedClassModel();
    DataInRule dataInRule = configCacheManager.getDataInRuleByType(getType(), classModel);
    setDataInRule(dataInRule);
    response.addResult("dataInRule", dataInRule);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setDataInRule((DataInRule)response.getResult("dataInRule"));
  }

  private String getType() {
    return this._type;
  }

  private void setType(String type) {
    this._type = type;
  }

  public DataInRule getDataInRule() {
    return this._dataInRule;
  }

  private void setDataInRule(DataInRule dataInRule) {
    this._dataInRule = dataInRule;
  }
}