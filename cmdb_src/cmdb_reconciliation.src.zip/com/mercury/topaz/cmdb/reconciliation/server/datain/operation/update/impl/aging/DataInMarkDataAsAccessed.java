package com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.aging;

import com.mercury.topaz.cmdb.reconciliation.server.datain.manager.DataInManager;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.impl.AbstractDataInOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.aging.operation.update.ModelUpdateMarkDataAsAccessed;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbUnresolvedDataIDs;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;

public class DataInMarkDataAsAccessed extends AbstractDataInOperation
{
  public static String FOUND_IDS_KEY = ModelUpdateMarkDataAsAccessed.FOUND_IDS_KEY;
  public static String NOT_FOUND_IDS_KEY = ModelUpdateMarkDataAsAccessed.NOT_FOUND_IDS_KEY;
  public static String NOT_FOUND_UNRESOLVED_IDS_KEY = ModelUpdateMarkDataAsAccessed.NOT_FOUND_UNRESOLVED_IDS_KEY;
  private CmdbIDsCollection _inputIDs;
  private CmdbIDsCollection _foundIDs;
  private CmdbIDsCollection _notFoundIDs;
  private Changer _changer;
  private CmdbUnresolvedDataIDs _unresolvedInputIDs;
  private CmdbUnresolvedDataIDs _unresolvedNotFoundIDs;

  public DataInMarkDataAsAccessed(CmdbIDsCollection inputIDs, Changer changer)
  {
    setInputIDs(inputIDs);
    setChanger(changer);
  }

  public DataInMarkDataAsAccessed(CmdbUnresolvedDataIDs unresolvedDataIDs, Changer changer) {
    setUnresolvedInputIDs(unresolvedDataIDs);
    setChanger(changer);
  }

  public String getOperationName() {
    return "Data In - Mark Data As Accessed";
  }

  public String getExecutionTaskQueueName() {
    return "Reconciliation DataIn System Task";
  }

  public void dataInExecute(DataInManager dataInManager, CmdbResponse response)
    throws CmdbException
  {
    ModelUpdateMarkDataAsAccessed touch;
    if (getInputIDs() != null) {
      touch = new ModelUpdateMarkDataAsAccessed(getInputIDs(), getChanger());
    }
    else {
      touch = new ModelUpdateMarkDataAsAccessed(getUnresolvedInputIDs(), getChanger());
    }

    dataInManager.executeOperation(touch);
    setFoundIDs(touch.getFoundIDs());
    setNotFoundIDs(touch.getNotFoundIDs());
    setUnresolvedNotFoundIDs(touch.getUnresolvedNotFoundIDs());
    response.addResult(FOUND_IDS_KEY, getFoundIDs());
    response.addResult(NOT_FOUND_IDS_KEY, getNotFoundIDs());
    response.addResult(NOT_FOUND_UNRESOLVED_IDS_KEY, getUnresolvedNotFoundIDs());
  }

  public void updateWithResponse(CmdbResponse response)
  {
    setFoundIDs((CmdbIDsCollection)response.getResult(FOUND_IDS_KEY));
    setNotFoundIDs((CmdbIDsCollection)response.getResult(NOT_FOUND_IDS_KEY));
    setUnresolvedNotFoundIDs((CmdbUnresolvedDataIDs)response.getResult(NOT_FOUND_UNRESOLVED_IDS_KEY));
  }

  private CmdbIDsCollection getInputIDs() {
    return this._inputIDs;
  }

  private void setInputIDs(CmdbIDsCollection inputIDs) {
    if ((inputIDs == null) || (inputIDs.size() == 0))
      throw new IllegalArgumentException("input ids is null or empty");

    this._inputIDs = inputIDs;
  }

  public CmdbIDsCollection getFoundIDs() {
    return this._foundIDs;
  }

  private void setFoundIDs(CmdbIDsCollection foundIDs) {
    this._foundIDs = foundIDs;
  }

  public CmdbIDsCollection getNotFoundIDs() {
    return this._notFoundIDs;
  }

  private void setNotFoundIDs(CmdbIDsCollection notFoundIDs) {
    this._notFoundIDs = notFoundIDs;
  }

  private Changer getChanger() {
    return this._changer;
  }

  private void setChanger(Changer changer) {
    if (changer == null)
      throw new IllegalArgumentException("changer is null");

    this._changer = changer;
  }

  private CmdbUnresolvedDataIDs getUnresolvedInputIDs() {
    return this._unresolvedInputIDs;
  }

  private void setUnresolvedInputIDs(CmdbUnresolvedDataIDs unresolvedDataIDs) {
    if ((unresolvedDataIDs == null) || (unresolvedDataIDs.size() == 0))
      throw new IllegalArgumentException("unresolved data ids is null");

    this._unresolvedInputIDs = unresolvedDataIDs;
  }

  public CmdbUnresolvedDataIDs getUnresolvedNotFoundIDs() {
    return this._unresolvedNotFoundIDs;
  }

  private void setUnresolvedNotFoundIDs(CmdbUnresolvedDataIDs unresolvedNotFoundIDs) {
    this._unresolvedNotFoundIDs = unresolvedNotFoundIDs;
  }
}