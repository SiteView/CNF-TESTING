package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.reconciliation.server.config.definition.impl.IdentificationRuleConfig;
import com.mercury.topaz.cmdb.reconciliation.server.datain.data.DataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.util.DataInUtil;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationRule;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.IdentificationScope;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.input.IdentificationRuleInput;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocCmdbMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.impl.EmptyTqlResultMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DefaultIdentificationRule
  implements IdentificationRule
{
  private final Collection<Condition> _conditions;
  private final String _targetType;
  private final boolean _targetTypeDerived;
  private final boolean _shouldIncludeSiblings;

  DefaultIdentificationRule(IdentificationRuleConfig ruleDef)
  {
    this._conditions = DefaultIdentificationRuleUtils.createConditions(ruleDef);
    this._targetType = ruleDef.getTargetType();
    this._targetTypeDerived = ruleDef.isTargetTypeDerived();
    this._shouldIncludeSiblings = ruleDef.shouldIncludeSiblings();
  }

  public void identify(IdentificationRuleInput input) {
    String typeToIdentify = input.getTypeToIdentify();
    String targetType = getTargetType(typeToIdentify);
    InputIdToCmdbDatasMapping identifiedData = input.getAlreadyReconciledData();
    CmdbObjects objectsToIdentify = input.getDataContainer().getObjectsForUpdate(typeToIdentify);

    for (Iterator i$ = objectsToIdentify.iterator(); i$.hasNext(); ) { CmdbObject objectToIdentify = (CmdbObject)i$.next();
      if (!(identifiedData.containsKey((CmdbDataID)objectToIdentify.getID()))) {
        identifiedData.add((CmdbDataID)objectToIdentify.getID(), new ArrayList(1));
        identifiedData.addInBulk((CmdbDataID)objectToIdentify.getID(), new ArrayList(1));
      }
    }

    if (input.getIdentifierScope().isContainCMDB()) {
      identify(input, targetType, IdentificationScope.CMDB);
    }

    if (input.getIdentifierScope().isContainBulk())
      identify(input, targetType, IdentificationScope.BULK);
  }

  private void identify(IdentificationRuleInput input, String targetType, IdentificationScope identificationScope)
  {
    ModifiablePattern modifiablePattern = PatternDefinitionFactory.createPattern("DefaultIdentificationRule pattern.", PatternGroupId.PATTERN_GROUP_ALL, PatternGraphFactory.createModifiableGraph());
    modifiablePattern.setDefaultLayout(PatternLayoutFactory.createLayout());

    Map inputObjectsIdentifierToIdsMaps = new HashMap(3);

    boolean conditionWasAdded = false;
    for (Iterator i$ = this._conditions.iterator(); i$.hasNext(); ) { Condition cond = (Condition)i$.next();
      conditionWasAdded |= cond.addToPattern(modifiablePattern, input, inputObjectsIdentifierToIdsMaps, targetType, this._targetTypeDerived, identificationScope);
    }

    if (conditionWasAdded)
    {
      TqlResultMap tqlResultMap;
      if (identificationScope.isContainCMDB()) {
        TqlQueryGetAdHocCmdbMap op = new TqlQueryGetAdHocCmdbMap(modifiablePattern, null);
        ServerApiFacade.executeOperation(op);
        tqlResultMap = (op.isDividedToChunks()) ? DataInUtil.getResultInChunks(op.getChunkRequest()) : op.getResultMap();
      } else {
        tqlResultMap = EmptyTqlResultMap.getInstance();
      }

      for (Iterator i$ = this._conditions.iterator(); i$.hasNext(); ) { Condition cond = (Condition)i$.next();
        cond.identify(input, tqlResultMap, inputObjectsIdentifierToIdsMaps, identificationScope, targetType, this._targetTypeDerived, this._shouldIncludeSiblings);
      }
    }
  }

  public Pattern getLayoutPattern(String type, PatternElementNumber nodeElementNumber) {
    ModifiablePattern modifiablePattern = PatternDefinitionFactory.createPattern("DefaultIdentificationRule pattern.", PatternGroupId.PATTERN_GROUP_ALL, PatternGraphFactory.createModifiableGraph());
    modifiablePattern.setDefaultLayout(PatternLayoutFactory.createLayout());
    for (Iterator i$ = this._conditions.iterator(); i$.hasNext(); ) { Condition cond = (Condition)i$.next();
      cond.addToLayoutPattern(modifiablePattern, type, nodeElementNumber);
    }
    return modifiablePattern;
  }

  public String getTargetType(String type) {
    return (((this._targetType == null) || (this._targetType.length() == 0)) ? type : this._targetType);
  }
}