package com.mercury.topaz.cmdb.reconciliation.server.identification.operation;

import com.mercury.topaz.cmdb.reconciliation.server.identification.manager.IdentificationManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface IdentificationOperation extends FrameworkOperation
{
  public abstract void identificationExecute(IdentificationManager paramIdentificationManager, CmdbResponse paramCmdbResponse);
}