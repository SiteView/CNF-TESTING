package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.def;

public abstract class AbstractIdentificationRuleConditionDef
{
  public abstract void accept(IdentificationRuleConditionDefVisitor paramIdentificationRuleConditionDefVisitor);
}