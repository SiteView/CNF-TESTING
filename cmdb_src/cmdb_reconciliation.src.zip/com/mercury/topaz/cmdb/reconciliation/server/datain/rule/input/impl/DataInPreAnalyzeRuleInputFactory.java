package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.data.IndependentDataContainer;
import com.mercury.topaz.cmdb.reconciliation.server.datain.operation.update.impl.info.impl.DataInAnomalyInfo;
import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.input.DataInPreAnalyzeRuleInput;
import com.mercury.topaz.cmdb.reconciliation.server.identification.rules.InputIdToCmdbDatasMapping;
import java.util.List;

public class DataInPreAnalyzeRuleInputFactory
{
  public static DataInPreAnalyzeRuleInput createDataInPreAnalyzeRuleInput(List<IndependentDataContainer> dataContainers, InputIdToCmdbDatasMapping existingDataMap, List<DataInAnomalyInfo> dataInAnomalyInfoList)
  {
    return new DataInPreAnalyzeRuleInputImpl(dataContainers, existingDataMap, dataInAnomalyInfoList);
  }
}