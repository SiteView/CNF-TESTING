package com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.impl;

import com.mercury.topaz.cmdb.reconciliation.server.datain.rule.output.DataInPreAnalyzeRuleOutput;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;

public class DataInPreAnalyzeRuleOutputFactory
{
  public static DataInPreAnalyzeRuleOutput createDataInRuleOutput(CmdbObjectIds objectsToRemove)
  {
    return new DataInPreAnalyzeRuleOutputImpl(objectsToRemove);
  }
}