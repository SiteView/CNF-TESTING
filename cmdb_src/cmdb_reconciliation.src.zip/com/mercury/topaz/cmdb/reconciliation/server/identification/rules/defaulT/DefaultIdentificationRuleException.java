package com.mercury.topaz.cmdb.reconciliation.server.identification.rules.defaulT;

import com.mercury.topaz.cmdb.reconciliation.server.identification.IdentificationException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;

class DefaultIdentificationRuleException extends IdentificationException
{
  public DefaultIdentificationRuleException(String message)
  {
    super(message);
  }

  public DefaultIdentificationRuleException(String message, ErrorCode errorCode) {
    super(message, errorCode);
  }

  public DefaultIdentificationRuleException(String message, Throwable cause) {
    super(message, cause);
  }

  public DefaultIdentificationRuleException(String message, Throwable cause, ErrorCode errorCode) {
    super(message, cause, errorCode);
  }

  public DefaultIdentificationRuleException(Throwable cause) {
    super(cause);
  }

  public DefaultIdentificationRuleException(Throwable cause, ErrorCode errorCode) {
    super(cause, errorCode);
  }
}