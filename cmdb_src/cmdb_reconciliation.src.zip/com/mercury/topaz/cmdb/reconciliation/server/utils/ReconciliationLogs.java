package com.mercury.topaz.cmdb.reconciliation.server.utils;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;

public class ReconciliationLogs
{
  public static Log getReconciliationLog()
  {
    return LogFactory.getEasyLog("cmdb.reconciliation");
  }

  public static Log getReconciliationAuditLog() {
    return LogFactory.getEasyLog("cmdb.reconciliation.audit");
  }

  public static Log getReconciliationAnomaliesLog() {
    return LogFactory.getEasyLog("cmdb.reconciliation.anomalies");
  }

  public static Log getReconciliationNotificationLog() {
    return LogFactory.getEasyLog("cmdb.reconciliation.notification");
  }

  public static Log getReconciliationDataManipulatorLog() {
    return LogFactory.getEasyLog("cmdb.reconciliation.data.manipulator");
  }
}