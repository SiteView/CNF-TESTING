package com.mercury.topaz.cmdb.reconciliation.server.config.admin.manager;

import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public abstract interface ReconciliationConfigAdminManager extends CmdbSubsystemManager
{
}