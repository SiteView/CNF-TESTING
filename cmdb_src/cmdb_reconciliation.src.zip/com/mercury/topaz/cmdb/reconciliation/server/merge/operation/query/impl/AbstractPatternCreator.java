package com.mercury.topaz.cmdb.reconciliation.server.merge.operation.query.impl;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbModifiableClassQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.impl.CmdbClassQualifierFactory;
import com.mercury.topaz.cmdb.shared.common.expression.LogicalOperator;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.LinkCardinality;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.NodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.functions.PatternLinkCompoundParameter;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.triple.PatternTriplets;

public abstract class AbstractPatternCreator
  implements PatternCreator
{
  private static final int MAX_DEPTH = 20;

  protected NodeLinksCondition getDefaultNodeLinksCondition(PatternElementNumber elementNumber)
  {
    ModifiableNodeLinksCondition nodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
    nodeLinksCondition.addLinkCardinality(createDefaultLinkCardinality(elementNumber));
    return nodeLinksCondition;
  }

  protected LinkCardinality createDefaultLinkCardinality(PatternElementNumber elementNumber) {
    return PatternConditionFactory.createLinkCardinality(elementNumber.getNumber(), 1, -1);
  }

  protected void addDefaultLinkCardinality(ModifiablePatternGraph patternGraph, PatternElementNumber linkElementNumber, PatternElementNumber endElementNumber, LogicalOperator logicalOperator) {
    ModifiableNodeLinksCondition modifiableNodeLinksCondition = patternGraph.getModifiableNode(endElementNumber).getModifiableLinksCondition();
    if (modifiableNodeLinksCondition.getNumberOfElements() > 0)
      modifiableNodeLinksCondition.addLogicalOperator(logicalOperator);

    modifiableNodeLinksCondition.addLinkCardinality(createDefaultLinkCardinality(linkElementNumber));
  }

  protected void addNodeWithIdConditionFromInput(ModifiablePatternGraph patternGraph, PatternElementNumber elementNumber, String type, CmdbObjectIds cmdbObjectIds) {
    NodeLinksCondition nodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
    ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition(type, true);
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(elementClassCondition, null, cmdbObjectIds);
    patternGraph.addNode(PatternGraphFactory.createPatternNode(elementNumber, elementCondition, true, nodeLinksCondition));
  }

  protected void addNode(ModifiablePatternGraph patternGraph, PatternElementNumber elementNumber, String type) {
    NodeLinksCondition nodeLinksCondition = PatternConditionFactory.createNodeLinksCondition();
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(type, true);
    patternGraph.addNode(PatternGraphFactory.createPatternNode(elementNumber, elementCondition, true, nodeLinksCondition));
  }

  protected void addCompoundLink(ModifiablePatternGraph patternGraph, PatternElementNumber elementNumber, PatternElementNumber end1ElementNumber, PatternElementNumber end2ElementNumber, PatternElementNumber innerObjectsElementNumber, PatternElementNumber innerLinksElementNumber) {
    int nodeNumber = 50000;
    PatternElementNumber tripleSrcNodeNumber = PatternElementNumberFactory.createElementNumber(nodeNumber++);
    PatternElementNumber tripleLinkNodeNumber = PatternElementNumberFactory.createElementNumber(nodeNumber++);
    PatternElementNumber tripleTrgNodeNumber = PatternElementNumberFactory.createElementNumber(nodeNumber);

    NodeLinksCondition tripleLinksCondition = getDefaultNodeLinksCondition(tripleLinkNodeNumber);

    PatternTriplets triplets = PatternGraphFactory.createTriplets();
    ElementCondition objectCondition = PatternConditionFactory.createElementCondition("object", true);
    PatternNode tripleObject1 = PatternGraphFactory.createPatternNode(tripleSrcNodeNumber, objectCondition, true, tripleLinksCondition);
    PatternNode tripleObject2 = PatternGraphFactory.createPatternNode(tripleTrgNodeNumber, objectCondition, true, tripleLinksCondition);
    CmdbModifiableClassQualifiers linkQualifiers = CmdbClassQualifierFactory.createQualifiers();
    linkQualifiers.add(CmdbClassQualifierFactory.createQualifier(CmdbClassQualifierDefs.CONTAINER.getName()));
    linkQualifiers.add(CmdbClassQualifierFactory.createQualifier(CmdbClassQualifierDefs.RECURSIVE_DELETE.getName()));
    ElementClassCondition linkClassCondition = PatternConditionFactory.createElementClassQualifierCondition("link", true, linkQualifiers, false, false);
    ElementCondition tripleLinkCondition = PatternConditionFactory.createElementCondition(linkClassCondition);
    PatternLink tripleLink = PatternGraphFactory.createPatternLink(tripleLinkNodeNumber, tripleSrcNodeNumber, tripleTrgNodeNumber, tripleLinkCondition, true, false);
    triplets.add(PatternGraphFactory.createTriple(tripleObject1, tripleLink, tripleObject2));
    PatternLinkCompoundParameter patternLinkCompoundParameter = PatternGraphFactory.createPatternLinkCompoundParameter("merge query compound link", 20, 0, triplets, innerObjectsElementNumber, innerLinksElementNumber, false, true);
    ElementCondition linkCondition = PatternConditionFactory.createElementCondition("link", true);
    patternGraph.addLink(PatternGraphFactory.createPatternLinkCompound(elementNumber, end1ElementNumber, end2ElementNumber, linkCondition, true, "merge query compound link", patternLinkCompoundParameter));

    addDefaultLinkCardinality(patternGraph, elementNumber, end1ElementNumber, LogicalOperator.OR);
    addDefaultLinkCardinality(patternGraph, elementNumber, end2ElementNumber, LogicalOperator.OR);
  }

  protected ElementSimpleLayout createFullLayout() {
    ElementSimpleLayout fullLayout = PatternLayoutFactory.createElementSimpleLayout();
    fullLayout.setAllLayer(true);
    return fullLayout;
  }
}