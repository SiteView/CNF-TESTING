package com.mercury.topaz.cmdb.server.transaction.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.transaction.Context;
import com.mercury.topaz.cmdb.server.transaction.TransactionExecutor;

public class TransactionExecutorFactory
{
  public static <T extends Context> TransactionExecutor<T> createFifo(Log log)
  {
    return new FifoTransactionExecutor(log);
  }
}