package com.mercury.topaz.cmdb.server.transaction;

public enum StatusEnum
{
  SUCCESSES, WARN, FAIL, NOT_RUN;

  public static final StatusEnum[] values()
  {
    return ((StatusEnum[])$VALUES.clone());
  }
}