package com.mercury.topaz.cmdb.server.transaction.impl;

import com.mercury.topaz.cmdb.server.transaction.CommandStatus;
import com.mercury.topaz.cmdb.server.transaction.Status;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class FifoStatus
  implements Status
{
  private List<CommandStatus> commandStatus;
  private Throwable error;
  private LinkedList<CommandStatus> rollbackErrors;

  FifoStatus()
  {
    this.commandStatus = new ArrayList();
    this.rollbackErrors = new LinkedList();
  }

  public List<CommandStatus> getCommandsStatus() {
    return this.commandStatus;
  }

  public List<CommandStatus> getRollbackStatus() {
    return this.rollbackErrors;
  }

  public void addCommandStatus(CommandStatus command) {
    this.commandStatus.add(command);
    if (command.getError() != null)
      this.error = command.getError();
  }

  public void addRollbackStatus(CommandStatus status)
  {
    this.rollbackErrors.addFirst(status); }

  public void rethrow() throws CmdbException {
    if (this.error != null)
      throw new CmdbException("erorr while executing transaction", this.error);
  }
}