package com.mercury.topaz.cmdb.server.transaction;

import java.util.List;

public abstract interface Status
{
  public abstract List<CommandStatus> getRollbackStatus();

  public abstract List<CommandStatus> getCommandsStatus();

  public abstract void rethrow()
    throws RuntimeException;
}