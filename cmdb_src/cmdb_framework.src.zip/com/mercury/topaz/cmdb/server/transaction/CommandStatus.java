package com.mercury.topaz.cmdb.server.transaction;

public abstract interface CommandStatus
{
  public abstract String getCommandName();

  public abstract Throwable getError();

  public abstract StatusEnum getStatus();
}