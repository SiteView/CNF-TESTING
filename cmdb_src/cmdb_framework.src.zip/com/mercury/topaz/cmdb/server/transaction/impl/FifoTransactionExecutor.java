package com.mercury.topaz.cmdb.server.transaction.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.transaction.CommandStatus;
import com.mercury.topaz.cmdb.server.transaction.Context;
import com.mercury.topaz.cmdb.server.transaction.Status;
import com.mercury.topaz.cmdb.server.transaction.StatusEnum;
import com.mercury.topaz.cmdb.server.transaction.TransactionCommand;
import com.mercury.topaz.cmdb.server.transaction.TransactionExecutor;
import java.util.LinkedList;
import java.util.ListIterator;

public class FifoTransactionExecutor<T extends Context>
  implements TransactionExecutor<T>
{
  private LinkedList<TransactionCommand<T>> commands;
  private Log logger;

  FifoTransactionExecutor(Log logger)
  {
    if (logger == null)
      throw new IllegalArgumentException("logger must not be null");

    this.commands = new LinkedList();
    this.logger = logger;
  }

  public void addCommand(TransactionCommand<T> command)
  {
    this.commands.addLast(command);
  }

  public Status execute(T context)
  {
    ListIterator itr = this.commands.listIterator();
    FifoStatus status = new FifoStatus();
    try {
      while (itr.hasNext()) {
        TransactionCommand command = (TransactionCommand)itr.next();
        try {
          if (this.logger.isDebugEnabled())
            this.logger.debug("execute command " + command.getDebugMessage());

          command.execute(context);
          CommandStatus commandStatus = command.getStatus();
          if (commandStatus.getStatus() == StatusEnum.FAIL)
            this.logger.error("Non-transactional failure when executing command: " + command.getName(), commandStatus.getError());

          status.addCommandStatus(commandStatus);
        } catch (Throwable t) {
          this.logger.error("failed to execute command: " + command.getName(), t);
          status.addCommandStatus(new CommandStatusImpl(command.getName(), StatusEnum.FAIL, t));
          throw new RuntimeException("failed to execute command: " + command.getName(), t);
        }
      }
    } catch (Throwable t) {
      TransactionCommand command;
      int idx = itr.previousIndex();
      while (itr.hasNext()) {
        command = (TransactionCommand)itr.next();
        status.addCommandStatus(new CommandStatusImpl(command.getName(), StatusEnum.NOT_RUN));
      }
      itr = this.commands.listIterator(idx);
      while (itr.hasPrevious()) {
        command = (TransactionCommand)itr.previous();
        try {
          if (this.logger.isDebugEnabled()) {
            this.logger.debug("rollback command " + command.getDebugMessage());
          }

          command.onFail(context);
          status.addRollbackStatus(new CommandStatusImpl(command.getName(), StatusEnum.SUCCESSES));
        } catch (Throwable rollbackError) {
          this.logger.error("failed to rollback command: " + command.getName(), t);
          status.addRollbackStatus(new CommandStatusImpl(command.getName(), StatusEnum.FAIL, rollbackError));
        }
      }
    }
    return status;
  }
}