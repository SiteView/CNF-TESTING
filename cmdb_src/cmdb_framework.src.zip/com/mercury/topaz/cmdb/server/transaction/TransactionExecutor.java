package com.mercury.topaz.cmdb.server.transaction;

public abstract interface TransactionExecutor<T extends Context>
{
  public abstract void addCommand(TransactionCommand<T> paramTransactionCommand);

  public abstract Status execute(T paramT);
}