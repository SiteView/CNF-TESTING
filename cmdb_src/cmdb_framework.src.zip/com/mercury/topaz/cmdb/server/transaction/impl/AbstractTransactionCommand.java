package com.mercury.topaz.cmdb.server.transaction.impl;

import com.mercury.topaz.cmdb.server.transaction.CommandStatus;
import com.mercury.topaz.cmdb.server.transaction.Context;
import com.mercury.topaz.cmdb.server.transaction.StatusEnum;
import com.mercury.topaz.cmdb.server.transaction.TransactionCommand;

public abstract class AbstractTransactionCommand<T extends Context>
  implements TransactionCommand<T>
{
  public CommandStatus getStatus()
  {
    return new CommandStatusImpl(getName(), StatusEnum.SUCCESSES);
  }
}