package com.mercury.topaz.cmdb.server.transaction.impl;

import com.mercury.topaz.cmdb.server.transaction.CommandStatus;
import com.mercury.topaz.cmdb.server.transaction.StatusEnum;

public class CommandStatusImpl
  implements CommandStatus
{
  private StatusEnum status;
  private Throwable error;
  private String name;

  public CommandStatusImpl(String name, StatusEnum status, Throwable error)
  {
    this.status = status;
    this.error = error;
    this.name = name;
  }

  public CommandStatusImpl(String name, StatusEnum status)
  {
    this(name, status, null);
  }

  public String getCommandName() {
    return this.name;
  }

  public Throwable getError() {
    return this.error;
  }

  public StatusEnum getStatus() {
    return this.status;
  }
}