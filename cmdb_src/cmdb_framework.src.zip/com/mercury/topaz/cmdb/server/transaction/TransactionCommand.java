package com.mercury.topaz.cmdb.server.transaction;

public abstract interface TransactionCommand<T extends Context>
{
  public abstract void execute(T paramT)
    throws Exception;

  public abstract void onFail(T paramT)
    throws Exception;

  public abstract String getName();

  public abstract String getDebugMessage();

  public abstract CommandStatus getStatus();
}