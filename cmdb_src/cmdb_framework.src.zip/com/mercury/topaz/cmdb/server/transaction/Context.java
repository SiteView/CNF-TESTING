package com.mercury.topaz.cmdb.server.transaction;

public abstract interface Context
{
}