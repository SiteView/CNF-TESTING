package com.mercury.topaz.cmdb.server.base.itc.schedule;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

public class Scheduler
{
  private static Log _logger = LogFactory.getEasyLog(Scheduler.class);
  Timer _timer;
  Map<Object, TaskWrapper> _tasks;

  public Scheduler(String name)
  {
    this._timer = new Timer(name, true);
    this._tasks = new HashMap();
  }

  public void startUp()
  {
  }

  public synchronized void shutdown()
  {
    Set tasksToRemove = new HashSet();
    for (Iterator i$ = this._tasks.keySet().iterator(); i$.hasNext(); ) { Object taskId = i$.next();
      tasksToRemove.add(taskId);
    }

    for (i$ = tasksToRemove.iterator(); i$.hasNext(); ) { Object idToRemove = i$.next();
      removePeriodicTask(idToRemove);
    }
  }

  public synchronized void addPeriodicTask(PeriodicTaskable task, long delayInMilli)
  {
    int interval = task.getIntervalInSec();

    if (interval <= 0) {
      throw new IllegalArgumentException("Periodic task has non positive interval: interval=" + interval + " task=" + task);
    }

    Object id = task.getTaskId();
    if (this._tasks.containsKey(id)) {
      _logger.warn("Attempt to add periodic task has failed, as task already exists: " + id);
      return;
    }

    TaskWrapper taskWrapper = new TaskWrapper(this, task);
    this._tasks.put(id, taskWrapper);

    long intervalMS = 1000L * interval;
    this._timer.schedule(taskWrapper, delayInMilli, intervalMS);
  }

  public synchronized void removePeriodicTask(PeriodicTaskable task)
  {
    if (task == null)
      throw new IllegalArgumentException("periodic task is null !!!");

    removePeriodicTask(task.getTaskId());
  }

  public synchronized void removePeriodicTask(Object taskId)
  {
    if (taskId == null)
      throw new IllegalArgumentException("task id is null !!!");

    TaskWrapper taskWrapper = (TaskWrapper)this._tasks.remove(taskId);
    if (taskWrapper != null)
      taskWrapper.cancel();
  }

  private final class TaskWrapper extends TimerTask
  {
    PeriodicTaskable _periodicTaskable;

    public TaskWrapper(, PeriodicTaskable paramPeriodicTaskable)
    {
      this._periodicTaskable = periodicTaskable;
    }

    public void run()
    {
      try
      {
        this._periodicTaskable.execute();
      }
      catch (Throwable t) {
        Scheduler.access$000().error("error occured during execution of periodic task [" + this._periodicTaskable + "], details:", t);
      }
    }
  }
}