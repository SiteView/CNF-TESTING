package com.mercury.topaz.cmdb.server.base.itc.schedule;

import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbContextRepository;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;

public class LocalPeriodicTaskWrapper
  implements PeriodicTaskable
{
  private final PeriodicTaskable target;
  private final CmdbCustomerID customerID;

  public LocalPeriodicTaskWrapper(PeriodicTaskable target, CmdbCustomerID customerID)
  {
    this.target = target;
    this.customerID = customerID;
  }

  public void execute() {
    CmdbContext context = CmdbContextFactory.createCmdbContext(this.customerID, "Periodic task " + getTaskId());
    CmdbContextRepository.push(context);
    try {
      this.target.execute();
    } finally {
      CmdbContextRepository.pop();
    }
  }

  public int getIntervalInSec() {
    return this.target.getIntervalInSec();
  }

  public Object getTaskId() {
    return this.target.getTaskId();
  }
}