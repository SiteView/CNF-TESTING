package com.mercury.topaz.cmdb.server.base.util.cache;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractCommonSubsystemManager;
import com.mercury.topaz.cmdb.shared.util.cache.ExpiredCache;
import com.mercury.topaz.cmdb.shared.util.cache.InternalExpiredCache;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.List;

public abstract class AbstractCacheManager<KEY, VALUE> extends AbstractCommonSubsystemManager
  implements ExpiredCache<KEY, VALUE>
{
  private InternalExpiredCache<KEY, VALUE> _internalCache;

  public AbstractCacheManager(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
    this._internalCache = initCache();
  }

  protected abstract InternalExpiredCache<KEY, VALUE> initCache();

  public void shutdown() {
    this._internalCache = null;
  }

  public void startUp() {
  }

  public VALUE get(KEY key) {
    return this._internalCache.get(key);
  }

  public VALUE put(KEY key, VALUE value) {
    return this._internalCache.put(key, value);
  }

  public VALUE remove(KEY key) {
    return this._internalCache.remove(key);
  }

  public void shrink() {
    this._internalCache.shrink();
  }

  public void updateDuration(long interval) {
    this._internalCache.updateDuration(interval);
  }

  public void touch(List<KEY> keys) {
    this._internalCache.touch(keys);
  }

  public int size() {
    return this._internalCache.size();
  }

  protected ReadOnlyIterator<VALUE> values() {
    return this._internalCache.values();
  }
}