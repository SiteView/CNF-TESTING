package com.mercury.topaz.cmdb.server.base.dispatcher;

import com.mercury.infra.utils.logger.Log;

public abstract interface InternalDispatcher extends Dispatcher
{
  public abstract void init(Log paramLog, int paramInt, ExecutableWorkerQueue<?> paramExecutableWorkerQueue, CommandFactory paramCommandFactory);

  public abstract DispatcherPeriodicTask createPeriodicTask();

  public abstract long getTimeInterval();
}