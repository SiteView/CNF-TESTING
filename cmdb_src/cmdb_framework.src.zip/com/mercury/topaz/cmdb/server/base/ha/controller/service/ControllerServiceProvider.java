package com.mercury.topaz.cmdb.server.base.ha.controller.service;

import com.mercury.am.platform.controller.Service;
import com.mercury.am.platform.controller.ServiceDescriptor;
import com.mercury.am.platform.controller.spi.LauncherJMXFacade;
import com.mercury.infra.adapter.CustomersFactory;
import com.mercury.infra.adapter.CustomersProvider;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.impl.ControllerServiceInstance;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.impl.ControllerServicesFactory;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.comm.CommunicationManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.instance.CmdbInstanceManager;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.server.manage.quota.load.QuotaLoader;
import com.mercury.topaz.cmdb.server.manage.quota.load.impl.QuotaLoaderFactory;
import com.mercury.topaz.cmdb.server.monitors.MonitorsFactory;
import com.mercury.topaz.cmdb.server.monitors.operation.command.impl.MonitorsCommandAddCollectors;
import com.mercury.topaz.cmdb.server.monitors.operation.update.impl.MonitorsUpdateAddInfosOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.API;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Default;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID.Factory;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl.CmdbCustomerQueryIsServiceStarted;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.update.impl.CmdbCustomerUpdateShutdownService;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.update.impl.CmdbCustomerUpdateStartupService;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkGlobalOperation;
import com.mercury.topaz.cmdb.shared.manage.quota.config.QuotaConfig;
import com.mercury.topaz.cmdb.shared.manage.quota.config.QuotasConfig;
import com.mercury.topaz.cmdb.shared.manage.quota.handler.QuotaCountHandler;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl.QuotaUpdateAddCountHandler;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl.QuotaUpdateAddCustomerQuotaInfo;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl.QuotaUpdateRemoveCustomerCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl.UpdateCustomerQuotaCounts;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ControllerServiceProvider
  implements CmdbServiceProvider
{
  private final String _serviceName;
  private final Service[] _services;

  public ControllerServiceProvider(String serviceName)
  {
    this._serviceName = serviceName;
    this._services = { Service.getService(serviceName) };
    ControllerServicesFactory.getInstance().registerServiceProvder(serviceName, this);
  }

  public Log getStartupLog() {
    return CmdbLogFactory.getStartupLog();
  }

  public double getCapacityUsage() {
    return -1.0D;
  }

  public double getCapacityUsageByService(ServiceDescriptor serviceDescriptor) {
    return -1.0D;
  }

  public Service[] getServices() {
    return this._services;
  }

  public String getStatistics() {
    return "getStatistics is not implemented yet !!!";
  }

  public void register() throws Exception {
    try {
      LauncherJMXFacade.getFacade().registerProvider(this);
      getStartupLog().info(this._serviceName + " service is registered in controller !!!");
    } catch (Exception e) {
      getStartupLog().error("Could not register " + this._serviceName + " service due to exception: " + e, e);
      throw e;
    }
  }

  public boolean isServiceAlive(ServiceDescriptor serviceDescriptor) {
    CmdbCustomerID customerID = createCustomerID(serviceDescriptor.getCustomerID());
    return isServiceAlive(customerID, serviceDescriptor.getService().getName());
  }

  private boolean isServiceAlive(CmdbCustomerID customerID, String serviceName) {
    CmdbCustomerQueryIsServiceStarted isServiceStarted = new CmdbCustomerQueryIsServiceStarted(customerID, serviceName);

    executeGlobalOperation(isServiceStarted);
    return isServiceStarted.isServiceStarted();
  }

  private CmdbCustomerID createCustomerID(int customerIDInt)
  {
    CmdbCustomerID customerID;
    boolean _isCmdbStandAlone = System.getProperty("MamStandAlone") != null;

    if (_isCmdbStandAlone)
      if (customerIDInt == 1)
        customerID = FrameworkConstants.Customer.Default.ID;
      else
        customerID = CmdbCustomerID.Factory.createCMDBCustomerID(customerIDInt);

    else
      customerID = createTBPCustomerID(customerIDInt);

    return customerID;
  }

  private CmdbCustomerID createTBPCustomerID(int customerIDInt) {
    String customerName;
    CustomersProvider customersProvider = CustomersFactory.getCustomersProvider();
    try
    {
      customerName = customersProvider.getCustomerName(customerIDInt);
    } catch (Exception e) {
      throw new CmdbException("Cannot find a customer with ID " + customerIDInt, e);
    }
    return CmdbCustomerID.Factory.createCMDBCustomerID(customerIDInt, customerName);
  }

  public void startService(ServiceDescriptor serviceDescriptor) throws Exception {
    startService(createCustomerID(serviceDescriptor.getCustomerID())); }

  public void startService(CmdbCustomerID customerID) {
    CmdbCustomerQueryIsServiceStarted op;
    try {
      op = new CmdbCustomerQueryIsServiceStarted(customerID, getServiceName());
      executeGlobalOperation(op);

      if (op.isServiceStarted())
        stopService(customerID);
    }
    catch (Exception e) {
      getStartupLog().error("Error occurred while checking for start status or shutting down service [" + getServiceName() + "] for customer [" + customerID + "] prior to service startup", e);
    }

    try
    {
      getStartupLog().info("*******  Starting service " + getServiceName() + " for customer " + customerID + " *******");

      CmdbCustomerUpdateStartupService customerUpdateStartupService = new CmdbCustomerUpdateStartupService(customerID, getServiceName());

      executeGlobalOperation(customerUpdateStartupService);

      Framework.getInstance().getCommManager().bindService(getServiceName());

      configureQuota(customerID);
      configureMonitors();

      getStartupLog().info("*******  Service " + getServiceName() + " for customer " + customerID + " has been started *******");

      postStartup(customerID);
    } catch (RuntimeException e) {
      getStartupLog().error("******* Failed to start service " + getServiceName() + " for customer " + customerID + " *******", e);

      throw e;
    }
  }

  private void addCustomerQuotas(CmdbCustomerID customerID, String customerQuotaName) {
    LocalEnvironment localEnvironment = Framework.getInstance().getInstanceManager().getInstance(customerID).getLocalEnvironment();

    QuotaLoader quotaLoader = QuotaLoaderFactory.createQuotaLoader(localEnvironment.getSettingsReader());

    int customerQuota = quotaLoader.getQuotaValue(customerQuotaName);
    QuotaUpdateAddCustomerQuotaInfo quotaUpdateAddCustomerQuotaInfo = new QuotaUpdateAddCustomerQuotaInfo(customerID, customerQuotaName, customerQuota);

    executeGlobalOperation(quotaUpdateAddCustomerQuotaInfo);
  }

  protected void postStartup(CmdbCustomerID customerID) {
    try {
      updateQuotaCounts(customerID);
      specificPostStartup(customerID);
    } catch (RuntimeException e) {
      getStartupLog().error("Error in post-startup of " + getServiceName() + " service", e);
    }
  }

  protected void specificPostStartup(CmdbCustomerID customerID)
  {
  }

  public void startServiceProvider() throws Exception {
  }

  protected void configureMonitors() {
    MonitorsFactory factory = Framework.getInstance().getMonitorsFactory();
    List monitorsCollectors = factory.getCollectors(getServiceName());
    if (monitorsCollectors == null) {
      return;
    }

    MonitorsCommandAddCollectors monitorsCommandAddCollectors = new MonitorsCommandAddCollectors(monitorsCollectors);

    executeGlobalOperation(monitorsCommandAddCollectors);

    Map monitorsInfo = factory.getInfos();
    Map monitors = factory.getMonitors(getServiceName());
    MonitorsUpdateAddInfosOperation monitorsUpdateAddInfosOperation = new MonitorsUpdateAddInfosOperation(monitorsInfo, monitors);

    executeGlobalOperation(monitorsUpdateAddInfosOperation);
  }

  private void configureQuota(CmdbCustomerID customerID) {
    Iterator i$ = QuotasConfig.instance().configs().iterator();
    while (true) { QuotaConfig quotaConfig;
      while (true) { if (!(i$.hasNext())) return; quotaConfig = (QuotaConfig)i$.next();
        if (quotaConfig.getControllerServiceName().equals(getServiceName()))
          break;
      }

      QuotaCountHandler quotaCountHandler = quotaConfig.getQuotaHandler();
      addQuotaCountHandler(customerID, quotaCountHandler);
      addCustomerQuotas(customerID, quotaCountHandler.getCustomerQuotaName());
    }
  }

  private void addQuotaCountHandler(CmdbCustomerID customerID, QuotaCountHandler quotaCountHandler) {
    QuotaUpdateAddCountHandler quotaUpdateAddCountHandler = new QuotaUpdateAddCountHandler(customerID, quotaCountHandler);

    executeGlobalOperation(quotaUpdateAddCountHandler);
  }

  public void stopService(ServiceDescriptor serviceDescriptor) throws Exception {
    int customerIDInt = serviceDescriptor.getCustomerID();
    CmdbCustomerID customerID = createCustomerID(customerIDInt);
    stopService(customerID);
  }

  public void stopService(CmdbCustomerID customerID) {
    String serviceName = getServiceName();
    getStartupLog().info("*******  Shutting down service " + serviceName + " for customer " + customerID.getID() + " *******");

    CmdbCustomerUpdateShutdownService customerUpdateShutdownService = new CmdbCustomerUpdateShutdownService(customerID, serviceName);

    executeGlobalOperation(customerUpdateShutdownService);

    removeCustomerQuotas(customerID);

    getStartupLog().info("*******  Service " + serviceName + " for customer " + customerID.getID() + " has been shut down *******");
  }

  private void removeCustomerQuotas(CmdbCustomerID customerID)
  {
    QuotaUpdateRemoveCustomerCounts quotaUpdateRemoveCustomerCounts = new QuotaUpdateRemoveCustomerCounts(customerID);

    executeGlobalOperation(quotaUpdateRemoveCustomerCounts);
  }

  public void stopServiceProvider() throws Exception {
  }

  public void stop() {
    LauncherJMXFacade.getFacade().unregisterProvider(this);
    Framework.getInstance().getCommManager().unbindService(getServiceName());
  }

  public void executeGlobalOperation(FrameworkGlobalOperation globalOperation) {
    CmdbApiFactory.createCMDBAPI(CmdbApi.LOCAL_TYPE).executeCMDBOperation(globalOperation, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);
  }

  public ControllerServiceInstance createServiceInstance(CustomerInstance customerInstance)
  {
    return new ControllerServiceInstance(getServiceName(), customerInstance);
  }

  public String getServiceName() {
    return this._serviceName;
  }

  private void updateQuotaCounts(CmdbCustomerID customerID) {
    executeGlobalOperation(new UpdateCustomerQuotaCounts(customerID));
  }

  public String toString() {
    return "Service provider for " + getServiceName();
  }
}