package com.mercury.topaz.cmdb.server.base.dispatcher;

public abstract interface ReadOnlyWorkerQueue<T>
{
  public abstract void swap();

  public abstract boolean offer(T paramT);
}