package com.mercury.topaz.cmdb.server.base.itc.lock;

public abstract interface ConcurrentReadSingleWrite
{
}