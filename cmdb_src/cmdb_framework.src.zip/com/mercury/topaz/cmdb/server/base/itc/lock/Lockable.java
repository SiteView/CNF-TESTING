package com.mercury.topaz.cmdb.server.base.itc.lock;

public abstract interface Lockable
{
  public abstract CmdbReadWriteLock getLock();

  public abstract void setLock(CmdbReadWriteLock paramCmdbReadWriteLock);
}