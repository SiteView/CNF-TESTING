package com.mercury.topaz.cmdb.server.base.dispatcher.command;

import com.mercury.topaz.cmdb.server.base.dispatcher.PrioritizedWorker;
import com.mercury.topaz.cmdb.server.base.dispatcher.PrioritizedWorkerType;
import com.mercury.topaz.cmdb.server.base.dispatcher.WorkerOrdering;

public abstract class AbstractPrioritizedWorker
  implements PrioritizedWorker<AbstractPrioritizedWorker>
{
  private long insertOrder;

  public void setOrder(long order)
  {
    this.insertOrder = order;
  }

  protected long getInsertOrder() {
    return this.insertOrder;
  }

  protected int getPriority() {
    return ((PrioritizedWorkerType)getType()).getPriority();
  }

  protected WorkerOrdering getOrdering() {
    return ((PrioritizedWorkerType)getType()).getOrdering();
  }

  public int compareTo(AbstractPrioritizedWorker other)
  {
    if (getPriority() != other.getPriority()) {
      return Integer.valueOf(getPriority()).compareTo(Integer.valueOf(other.getPriority()));
    }

    if ((!($assertionsDisabled)) && (getOrdering() != other.getOrdering())) { throw new AssertionError();
    }

    return ((getOrdering() == WorkerOrdering.FIFO) ? Long.valueOf(getInsertOrder()).compareTo(Long.valueOf(other.getInsertOrder())) : Long.valueOf(other.getInsertOrder()).compareTo(Long.valueOf(getInsertOrder())));
  }
}