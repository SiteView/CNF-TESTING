package com.mercury.topaz.cmdb.server.base.log;

import org.apache.log4j.PatternLayout;
import org.apache.log4j.helpers.PatternParser;

public class LogPatternLayout extends PatternLayout
{
  protected PatternParser createPatternParser(String string)
  {
    return new LogPatternParser(string);
  }
}