package com.mercury.topaz.cmdb.server.base.itc.schedule;

public abstract interface PeriodicTaskable
{
  public abstract int getIntervalInSec();

  public abstract void execute();

  public abstract Object getTaskId();
}