package com.mercury.topaz.cmdb.server.base.ha.controller.service.impl;

import com.mercury.topaz.cmdb.server.base.ha.controller.service.CmdbServiceProvider;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import java.util.HashMap;
import java.util.Map;

public class ControllerServicesFactory
{
  private static final ControllerServicesFactory INSTANCE = new ControllerServicesFactory();
  private final Map<String, CmdbServiceProvider> _serviceProviders;

  public ControllerServicesFactory()
  {
    this._serviceProviders = new HashMap(); }

  public static ControllerServicesFactory getInstance() {
    return INSTANCE;
  }

  public ControllerServiceInstance createServiceInstance(String serviceName, CustomerInstance customerInstance) {
    return getServiceProvider(serviceName).createServiceInstance(customerInstance);
  }

  public void registerServiceProvder(String serviceName, CmdbServiceProvider provider) {
    this._serviceProviders.put(serviceName, provider);
  }

  private CmdbServiceProvider getServiceProvider(String serviceName) {
    CmdbServiceProvider cmdbServiceProvider = (CmdbServiceProvider)this._serviceProviders.get(serviceName);
    if (cmdbServiceProvider == null)
      throw new CmdbException("No service instance provider registered for service " + serviceName);

    return cmdbServiceProvider;
  }
}