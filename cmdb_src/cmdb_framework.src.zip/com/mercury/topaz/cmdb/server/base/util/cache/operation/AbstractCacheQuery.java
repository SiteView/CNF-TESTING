package com.mercury.topaz.cmdb.server.base.util.cache.operation;

import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.util.cache.ExpiredCache;
import com.mercury.topaz.cmdb.shared.util.cache.GenericCache;
import java.io.Serializable;

abstract class AbstractCacheQuery<KEY extends Serializable, VALUE extends Serializable> extends AbstractCacheOperation<KEY, VALUE>
{
  private static final String RESULT_KEY = "CACHE_RESULT";
  private VALUE value;
  private KEY key;

  public AbstractCacheQuery(String name, String queue, String serviceName, KEY key)
  {
    super(name, queue, serviceName);
    this.key = key;
  }

  protected void doCache(ExpiredCache<KEY, VALUE> cache, CmdbResponse response)
  {
    this.value = getResult(cache);

    response.addResult("CACHE_RESULT", this.value);
  }

  protected abstract VALUE getResult(GenericCache<KEY, VALUE> paramGenericCache);

  public void updateQueryWithResponse(CmdbResponse response)
  {
    this.value = ((Serializable)response.getResult("CACHE_RESULT"));
  }

  public VALUE getValue() {
    return this.value; }

  protected KEY getKey() {
    return this.key;
  }
}