package com.mercury.topaz.cmdb.server.base.itc.lock.impl;

import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbLock;
import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbReadWriteLock;
import com.mercury.topaz.cmdb.server.manage.semaphore.BottlenecksHistory;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class CmdbReadWriteLockImpl
  implements CmdbReadWriteLock
{
  private ReadWriteLock _lock;
  private CmdbLock _readLock;
  private CmdbLock _writeLock;

  public CmdbReadWriteLockImpl()
  {
    this(null);
  }

  public CmdbReadWriteLockImpl(BottlenecksHistory bottleneckHistory) {
    setLock(new ReentrantReadWriteLock(true));

    setReadLock(new CmdbLockImpl(getLock().readLock(), bottleneckHistory));
    setWriteLock(new CmdbLockImpl(getLock().writeLock(), bottleneckHistory));
  }

  public CmdbLock readLock()
  {
    return getReadLock();
  }

  public CmdbLock writeLock()
  {
    return getWriteLock();
  }

  private ReadWriteLock getLock() {
    return this._lock;
  }

  private void setLock(ReadWriteLock lock) {
    this._lock = lock;
  }

  private CmdbLock getReadLock() {
    return this._readLock;
  }

  private void setReadLock(CmdbLock readLock) {
    this._readLock = readLock;
  }

  private CmdbLock getWriteLock() {
    return this._writeLock;
  }

  private void setWriteLock(CmdbLock writeLock) {
    this._writeLock = writeLock;
  }
}