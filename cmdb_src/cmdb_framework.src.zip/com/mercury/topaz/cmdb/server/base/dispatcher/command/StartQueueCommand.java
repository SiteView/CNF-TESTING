package com.mercury.topaz.cmdb.server.base.dispatcher.command;

import appilog.framework.shared.base.MamException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.dispatcher.ExecutableQueue;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class StartQueueCommand extends ExecuteQueueCommand
{
  StartQueueCommand(ExecutableQueue queue, String deActivateTaskName, String taskName, String serviceName)
  {
    super(queue, deActivateTaskName, taskName, serviceName);
  }

  protected void commonExecute(CommonManager manager, CmdbResponse response) throws MamException {
    try {
      this.queue.start();
    } catch (Throwable t) {
      log.error("failed to start queue");
    }
    super.commonExecute(manager, response);
  }
}