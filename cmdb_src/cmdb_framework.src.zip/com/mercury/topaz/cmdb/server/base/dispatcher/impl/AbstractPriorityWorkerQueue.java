package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import appilog.framework.shared.manage.MamContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.dispatcher.PrioritizedWorker;
import com.mercury.topaz.cmdb.server.base.dispatcher.WorkersFactory;
import java.util.PriorityQueue;

public abstract class AbstractPriorityWorkerQueue<L, T extends PrioritizedWorker<L>> extends AbstractWorkerQueue<T>
{
  private long insertCounter;

  public AbstractPriorityWorkerQueue(MamContext context, WorkersFactory<T> factory, Log log, Log stat)
  {
    super(context, factory, log, stat, new SwapableQueue(new PriorityQueue(), new PriorityQueue()));
  }

  public boolean offer(T o)
  {
    o.setOrder(++this.insertCounter);
    return super.offer(o);
  }
}