package com.mercury.topaz.cmdb.server.base.dispatcher;

public abstract interface WorkersFactory<T extends QueuedWorker>
{
  public abstract void putBack(T paramT);

  public abstract T getWorker(WorkerType paramWorkerType);
}