package com.mercury.topaz.cmdb.server.base.cfg.impl;

import com.mercury.infra.utils.environment.Environment;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesFileSettingsLoader
{
  private static Log _infoLogger = CmdbLogFactory.getCMDBInfoLog();
  private File _configFile;
  private String _systemPath;
  private Properties _properties;
  public static final String CONFIGURATION_DIRECTORY = "conf" + File.separator;
  public static final String DEFUALT_CONFIG_FILE_NAME = "cmdb.conf";
  public static final String CMDB_CONFIG_PATH_PARAM = "cmdbConfPath";

  public PropertiesFileSettingsLoader()
  {
    this(System.getProperty("cmdbConfPath", "cmdb.conf"));
  }

  public PropertiesFileSettingsLoader(String fileName)
  {
    if (!(new File(fileName).isAbsolute()))
    {
      setSystemPath(Environment.getInstance().getEnvironmentHomePath() + File.separator);
      setConfigFile(new File(getSystemPath() + CONFIGURATION_DIRECTORY + fileName));
      _infoLogger.info("Configuration File [" + getSystemPath() + CONFIGURATION_DIRECTORY + fileName + "]");
    }
    else
    {
      setConfigFile(new File(fileName));
      _infoLogger.info("Configuration File [" + fileName + "]");
    }
  }

  public SettingsReader loadSettingsReader()
  {
    FileInputStream fis = null;
    Properties newProperties = new Properties();
    try {
      fis = new FileInputStream(getConfigFile());
      newProperties.load(fis);
      fis.close();
      setProperties(newProperties);
    }
    catch (IOException e) {
      _infoLogger.error("configuration file [" + getConfigFile() + "] " + "not found (use default properties as error handling)");

      return CmdbSettingsFactory.createDefaultSettingsReader();
    }

    return CmdbSettingsFactory.createSettings(getProperties(), getSourceName());
  }

  private String getSourceName() {
    return "Properties File: " + getConfigFile().getName();
  }

  private File getConfigFile()
  {
    return this._configFile;
  }

  private void setConfigFile(File configFile) {
    this._configFile = configFile;
  }

  private String getSystemPath() {
    return this._systemPath;
  }

  private void setSystemPath(String systemPath) {
    this._systemPath = systemPath;
  }

  private Properties getProperties() {
    return this._properties;
  }

  private void setProperties(Properties properties) {
    this._properties = properties;
  }
}