package com.mercury.topaz.cmdb.server.base.itc.lock;

import com.mercury.topaz.cmdb.server.base.itc.lock.impl.CmdbReadWriteLockImpl;
import com.mercury.topaz.cmdb.server.base.itc.lock.impl.ConcurrentReadSingleWriteLock;
import com.mercury.topaz.cmdb.server.base.itc.lock.impl.ReadWriteLockForMultipleReadersAndWrites;
import com.mercury.topaz.cmdb.server.base.itc.lock.impl.ReadWriteLockForSingleReaderWriterImpl;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.rpm.RequestProcessor;
import com.mercury.topaz.cmdb.server.manage.semaphore.BottlenecksHistory;
import com.mercury.topaz.cmdb.shared.base.CmdbException;

public class CmdbReadWriteLockFactory
{
  public static CmdbReadWriteLock createReadWriteLock()
  {
    return new CmdbReadWriteLockImpl();
  }

  public static CmdbReadWriteLock createReadWriteLock(BottlenecksHistory bottleneckHistory) {
    return new CmdbReadWriteLockImpl(bottleneckHistory);
  }

  public static CmdbReadWriteLock createReadWriteLockForSingleReaderWriter()
  {
    return new ReadWriteLockForSingleReaderWriterImpl();
  }

  public static CmdbReadWriteLock createReadWriteLockForSingleReaderWriter(BottlenecksHistory bottleneckHistory) {
    return new ReadWriteLockForSingleReaderWriterImpl(bottleneckHistory);
  }

  public static CmdbReadWriteLock createReadWriteLockForMultipleReadersAndWrites()
  {
    return new ReadWriteLockForMultipleReadersAndWrites();
  }

  public static CmdbReadWriteLock createLockForConcurrentReadersSingleWriter(BottlenecksHistory bottlenecksHistory) {
    return new ConcurrentReadSingleWriteLock(bottlenecksHistory);
  }

  public static void setLock(Lockable lockOwner) {
    BottlenecksHistory bottleneckHistory = Framework.getInstance().getRequestProcessor().getBottleneckHistory();
    if (lockOwner instanceof SingleReadSingleWrite)
      lockOwner.setLock(createReadWriteLockForSingleReaderWriter(bottleneckHistory));
    else if (lockOwner instanceof MultiReadSingleWrite)
      lockOwner.setLock(createReadWriteLock(bottleneckHistory));
    else if (lockOwner instanceof MultiReadMultiWrite)
      lockOwner.setLock(createReadWriteLockForMultipleReadersAndWrites());
    else if (lockOwner instanceof ConcurrentReadSingleWrite)
      lockOwner.setLock(createLockForConcurrentReadersSingleWriter(bottleneckHistory));
    else
      throw new CmdbException("Lock owner (" + lockOwner + ") doesn't implement any of read/write interfaces");
  }
}