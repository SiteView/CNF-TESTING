package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import com.mercury.topaz.cmdb.server.base.dispatcher.WorkerQueue;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class SwapableQueue<T>
  implements WorkerQueue<T>
{
  private Queue<T> queue1;
  private Queue<T> queue2;
  private Queue<T> writeQueue;
  private Queue<T> readQueue;

  public SwapableQueue()
  {
    this.queue1 = new LinkedList();
    this.queue2 = new LinkedList();
    init();
  }

  public SwapableQueue(Queue<T> first, Queue<T> second) {
    this.queue1 = first;
    this.queue2 = second;
    init();
  }

  private void init() {
    this.queue1.clear();
    this.queue2.clear();
    setWriteQueue(this.queue1);
    setReadQueue(this.queue2);
  }

  protected void setReadQueue(Queue<T> notActiveQueue) {
    this.readQueue = notActiveQueue;
  }

  protected Queue<T> getReadQueue() {
    return this.readQueue;
  }

  protected void setWriteQueue(Queue<T> writeQueue) {
    this.writeQueue = writeQueue;
  }

  protected Queue<T> getWriteQueue() {
    return this.writeQueue;
  }

  public void swap()
  {
    Queue temp = getWriteQueue();
    setWriteQueue(getReadQueue());
    setReadQueue(temp);
  }

  public Iterator<T> iterator()
  {
    return this.readQueue.iterator();
  }

  public int size()
  {
    return (this.readQueue.size() + this.writeQueue.size());
  }

  public boolean offer(T o)
  {
    return getWriteQueue().offer(o);
  }

  public T peek()
  {
    return getReadQueue().peek();
  }

  public void clear()
  {
    getReadQueue().clear();
  }

  public T remove()
  {
    return getReadQueue().remove();
  }

  public T poll() {
    return getReadQueue().poll();
  }
}