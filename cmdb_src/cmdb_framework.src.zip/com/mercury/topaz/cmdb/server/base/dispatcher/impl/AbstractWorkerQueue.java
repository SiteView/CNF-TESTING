package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import appilog.framework.shared.manage.MamContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.dispatcher.ExecutableWorkerQueue;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;
import com.mercury.topaz.cmdb.server.base.dispatcher.WorkerQueue;
import com.mercury.topaz.cmdb.server.base.dispatcher.WorkerQueueState;
import com.mercury.topaz.cmdb.server.base.dispatcher.WorkersFactory;
import java.util.Iterator;

public abstract class AbstractWorkerQueue<T extends QueuedWorker>
  implements ExecutableWorkerQueue<T>
{
  private MamContext context;
  private WorkerQueueState state;
  private WorkersFactory<T> workersFactory;
  protected Log stat;
  protected Log log;
  private WorkerQueue<T> workerQueue;

  public AbstractWorkerQueue(MamContext context, WorkersFactory<T> factory, Log log, Log stat)
  {
    this.context = context;
    this.workersFactory = factory;
    this.log = log;
    this.stat = stat;
    this.workerQueue = new SwapableQueue();
  }

  public AbstractWorkerQueue(MamContext context, WorkersFactory<T> factory, Log log, Log stat, WorkerQueue<T> workerQueue)
  {
    this.context = context;
    this.workersFactory = factory;
    this.log = log;
    this.stat = stat;
    this.workerQueue = workerQueue;
  }

  protected Log getLogger() {
    return this.log;
  }

  protected Log getStatLogger() {
    return this.stat;
  }

  public void swap()
  {
    this.workerQueue.swap();
  }

  public void setState(WorkerQueueState state)
  {
    this.state = state;
  }

  public MamContext getMamContext()
  {
    return this.context;
  }

  public WorkerQueueState getState()
  {
    return this.state;
  }

  public void start()
  {
  }

  public void execute()
  {
    if (this.log.isDebugEnabled())
      this.log.debug("executing queue: " + getKey());

    while (this.workerQueue.peek() != null) {
      QueuedWorker worker = (QueuedWorker)this.workerQueue.remove();
      executeWorker(worker);
      getWorkerFactory().putBack(worker);
    }
  }

  protected void executeWorker(T worker) {
    try {
      if (this.log.isDebugEnabled())
        this.log.debug("executing worker [" + getKey() + "] :" + worker);
      long time = System.currentTimeMillis();
      worker.doWork(this);
      if (this.stat.isInfoEnabled())
        this.stat.info("[" + getKey() + ":" + getMamContext() + "] worker: " + worker.getType() + " duration: " + (System.currentTimeMillis() - time) + " ms");

      cleanAfterWorker(worker);
    } catch (Throwable ex) {
      this.log.error("failed to execute worker due to exception", ex);
    }
  }

  protected void cleanAfterWorker(T worker) {
  }

  protected WorkersFactory<T> getWorkerFactory() {
    return this.workersFactory;
  }

  public Iterator<T> iterator() {
    return this.workerQueue.iterator();
  }

  public int size() {
    return this.workerQueue.size();
  }

  public boolean offer(T o)
  {
    return this.workerQueue.offer(o);
  }

  public T peek()
  {
    return ((QueuedWorker)this.workerQueue.peek());
  }

  public T poll()
  {
    return ((QueuedWorker)this.workerQueue.poll());
  }

  public T remove() {
    return ((QueuedWorker)this.workerQueue.remove()); }

  public boolean isEmpty() {
    return (this.workerQueue.size() == 0); }

  public void clear() {
    this.workerQueue.clear();
  }
}