package com.mercury.topaz.cmdb.server.base.dispatcher;

public abstract interface PrioritizedWorker<T> extends QueuedWorker, Ordered, Comparable<T>
{
}