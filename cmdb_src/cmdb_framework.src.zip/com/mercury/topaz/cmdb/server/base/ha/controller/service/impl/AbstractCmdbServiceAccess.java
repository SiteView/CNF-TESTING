package com.mercury.topaz.cmdb.server.base.ha.controller.service.impl;

import com.mercury.am.platform.controller.ServiceNotAvailableException;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.CmdbServiceAccess;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbReqestImpl;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

abstract class AbstractCmdbServiceAccess
  implements CmdbServiceAccess
{
  public CmdbResponse executeCMDBOperation(FrameworkOperation operation, CmdbContext context, boolean isSynchronous)
    throws CmdbResponseException, ServiceNotAvailableException
  {
    CmdbReqestImpl reqest = new CmdbReqestImpl("General CMDB request", context, operation, isSynchronous);
    CmdbResponse response = handleRequest(reqest);
    if (isSynchronous)
      operation.updateWithResponse(response);

    return response;
  }

  public CmdbResponse executeCMDBOperation(FrameworkOperation operation, CmdbContext context) throws CmdbResponseException, ServiceNotAvailableException {
    return executeCMDBOperation(operation, context, true);
  }

  public final CmdbResponse handleRequest(CmdbRequest request) throws CmdbResponseException, ServiceNotAvailableException {
    return doHandleRequest(request);
  }

  protected abstract CmdbResponse doHandleRequest(CmdbRequest paramCmdbRequest)
    throws CmdbResponseException, ServiceNotAvailableException;
}