package com.mercury.topaz.cmdb.server.base.util.cache.operation;

import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;
import com.mercury.topaz.cmdb.shared.util.cache.ExpiredCache;
import java.io.Serializable;

public class CacheUpdateUpdateDuration<KEY extends Serializable, VALUE extends Serializable> extends AbstractCacheOperation<KEY, VALUE>
  implements CmdbUpdate
{
  private long duration;

  public CacheUpdateUpdateDuration(String queue, String serviceName, long duration)
  {
    super("CACHE_UPDATE_UPDATE_DURATION", queue, serviceName);
    this.duration = duration;
  }

  protected void doCache(ExpiredCache<KEY, VALUE> cache, CmdbResponse response)
  {
    cache.updateDuration(this.duration);
  }

  public void updateUpdateWithResponse(CmdbResponse response)
  {
  }
}