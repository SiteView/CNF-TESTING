package com.mercury.topaz.cmdb.server.base.dispatcher;

public class PrioritizedWorkerType extends WorkerType
{
  private int priority;
  private WorkerOrdering ordering;

  public PrioritizedWorkerType(int type, String name, int priority, WorkerOrdering ordering)
  {
    super(type, name);
    this.priority = priority;
    this.ordering = ordering;
  }

  public WorkerOrdering getOrdering()
  {
    return this.ordering;
  }

  public int getPriority() {
    return this.priority;
  }
}