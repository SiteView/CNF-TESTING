package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import com.mercury.topaz.cmdb.server.base.dispatcher.CommandFactory;
import com.mercury.topaz.cmdb.server.base.dispatcher.ExecutableWorkerQueue;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;

class ActiveState extends AbstractQueueState
{
  protected ActiveState()
  {
    super("ACTIVE");
  }

  public void put(ExecutableWorkerQueue queue, QueuedWorker worker) {
    queue.offer(worker);
  }

  public void activate(CommandFactory factory, ExecutableWorkerQueue queue)
  {
  }

  public void deActivate(ExecutableWorkerQueue queue) {
    if (queue.isEmpty())
      queue.setState(AbstractQueueState.STATE_NOT_ACTIVE);
    else
      queue.setState(AbstractQueueState.STATE_READY);
  }

  public boolean readyToDelete(ExecutableWorkerQueue queue)
  {
    return false;
  }
}