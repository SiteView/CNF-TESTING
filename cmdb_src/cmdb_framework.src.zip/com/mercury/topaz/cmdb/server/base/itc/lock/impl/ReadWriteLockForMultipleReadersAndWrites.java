package com.mercury.topaz.cmdb.server.base.itc.lock.impl;

import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbLock;
import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbReadWriteLock;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public class ReadWriteLockForMultipleReadersAndWrites
  implements CmdbReadWriteLock
{
  private CmdbLock _lock;

  public ReadWriteLockForMultipleReadersAndWrites()
  {
    setLock(new EmptyLock(null));
  }

  public CmdbLock readLock() {
    return this._lock;
  }

  public CmdbLock writeLock() {
    return this._lock;
  }

  private void setLock(CmdbLock lock) {
    this._lock = lock;
  }

  private static class EmptyLock
  implements CmdbLock
  {
    public void lock()
    {
    }

    public void lock(FrameworkOperation operation)
      throws InterruptedException
    {
    }

    public void unlock()
    {
    }
  }
}