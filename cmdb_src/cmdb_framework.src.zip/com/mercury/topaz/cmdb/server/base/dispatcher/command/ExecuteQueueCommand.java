package com.mercury.topaz.cmdb.server.base.dispatcher.command;

import appilog.framework.client.manage.api.MamApi;
import appilog.framework.client.manage.api.impl.MamApiFactory;
import appilog.framework.shared.base.MamConstants.DISPATCHER.Log;
import appilog.framework.shared.base.MamException;
import appilog.framework.shared.manage.impl.MamContextFactory;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.server.base.dispatcher.ExecutableQueue;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class ExecuteQueueCommand extends AbstractDispatcherCommand
{
  protected static Log log = LogFactory.getEasyLog(MamConstants.DISPATCHER.Log.LOGGER_COMMANDS);
  private static final String NAME = "CONSUMER";
  protected ExecutableQueue queue;
  private String deActivateTaskName;

  ExecuteQueueCommand(ExecutableQueue queue, String deActivateTaskName, String taskName, String serviceName)
  {
    super(taskName, serviceName);
    this.deActivateTaskName = deActivateTaskName;
    this.queue = queue;
  }

  protected void commonExecute(CommonManager manager, CmdbResponse response) throws MamException
  {
    try {
      this.queue.execute();
    }
    catch (Throwable ex) {
      log.error("error in queue: " + this.queue.getKey(), ex);
    } finally {
      MamApiFactory.createAPI(CmdbApi.LOCAL_TYPE).executeOperation(getDeActivateCommand(this.queue.getKey()), MamContextFactory.create(((SubsystemManager)manager).getCustomerID()), false);
    }
  }

  public String getOperationName() {
    return "CONSUMER"; }

  protected DeActivateQueueCommand getDeActivateCommand(Object key) {
    return new DeActivateQueueCommand(key, getDeActivateTaskName(), getServiceName());
  }

  private String getDeActivateTaskName() {
    return this.deActivateTaskName;
  }
}