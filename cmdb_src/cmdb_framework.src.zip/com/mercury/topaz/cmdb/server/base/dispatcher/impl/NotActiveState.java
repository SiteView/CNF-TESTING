package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import com.mercury.topaz.cmdb.server.base.dispatcher.CommandFactory;
import com.mercury.topaz.cmdb.server.base.dispatcher.ExecutableWorkerQueue;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;

class NotActiveState extends AbstractQueueState
{
  protected NotActiveState()
  {
    super("NOT-ACTIVE");
  }

  public void put(ExecutableWorkerQueue queue, QueuedWorker worker) {
    queue.setState(AbstractQueueState.STATE_READY);
    queue.offer(worker);
  }

  public void activate(CommandFactory factory, ExecutableWorkerQueue queue)
  {
  }

  public void deActivate(ExecutableWorkerQueue queue) {
    throw new IllegalStateException("Can't DeActive A NOT_READY queue on queue: " + queue.getKey());
  }

  public boolean readyToDelete(ExecutableWorkerQueue queue) {
    return queue.readyToDelete();
  }
}