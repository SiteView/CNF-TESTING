package com.mercury.topaz.cmdb.server.base.dispatcher;

public class WorkerType
{
  private final int type;
  private String name;

  public WorkerType(int type)
  {
    this(type, ""); }

  public WorkerType(int type, String name) {
    this.type = type;
    this.name = name; }

  public boolean equals(Object other) {
    if (other instanceof WorkerType)
      return (this.type == ((WorkerType)other).type);

    return false; }

  public int hashCode() {
    return this.type; }

  public String toString() {
    return this.name + ":" + this.type;
  }
}