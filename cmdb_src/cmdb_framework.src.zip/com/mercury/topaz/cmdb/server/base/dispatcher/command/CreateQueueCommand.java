package com.mercury.topaz.cmdb.server.base.dispatcher.command;

import appilog.framework.shared.base.MamException;
import com.mercury.topaz.cmdb.server.base.dispatcher.Dispatcher;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.List;

public class CreateQueueCommand extends AbstractDispatcherCommand
{
  private static final String NAME = "Create Queue";
  private Object _queueKey;
  private List<QueuedWorker> _workers;

  CreateQueueCommand(Object queueKey, List<QueuedWorker> workers, String taskName, String serviceName)
  {
    this(queueKey, taskName, serviceName);
    this._workers = workers; }

  CreateQueueCommand(Object queueKey, String taskName, String serviceName) {
    super(taskName, serviceName);
    this._queueKey = queueKey;
  }

  protected void commonExecute(CommonManager manager, CmdbResponse response) throws MamException
  {
    Dispatcher dispatcher = (Dispatcher)manager;
    dispatcher.createQueue(this._queueKey, this._workers);
  }

  public String getOperationName() {
    return "Create Queue";
  }
}