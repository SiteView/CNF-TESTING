package com.mercury.topaz.cmdb.server.base.ha.controller.service.impl;

import com.mercury.am.platform.controller.Server;
import com.mercury.am.platform.controller.Service;
import com.mercury.am.platform.controller.ServiceAccess;
import com.mercury.am.platform.controller.ServiceNotAvailableException;
import com.mercury.am.platform.controller.spi.RMIServiceAccessFactory;
import com.mercury.topaz.cmdb.client.manage.api.util.CmdbApiUtil;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.CmdbServiceAccess;
import com.mercury.topaz.cmdb.shared.manage.CmdbFacade;
import java.rmi.server.RemoteObject;

public class CmdServiceAccessFactoryImpl extends RMIServiceAccessFactory
{
  private static final CmdbServiceAccess LOCAL_SERVICE_ACCESS_INSTANCE = new LocalServiceAccessImpl();

  public Class getAccessClass(Service service)
  {
    return CmdbServiceAccess.class;
  }

  public static CmdbServiceAccess getLocalAccess()
  {
    return LOCAL_SERVICE_ACCESS_INSTANCE;
  }

  public ServiceAccess createLocalAccess(Service service) throws ServiceNotAvailableException {
    return getLocalAccess();
  }

  protected String getJNDIName(Service service) {
    return CmdbApiUtil.getJndiNameOfService(service.getName());
  }

  protected ServiceAccess createRemoteAccess(RemoteObject remoteObject, Service service, Server server) {
    return new RMIServiceAccessImpl((CmdbFacade)remoteObject, server);
  }
}