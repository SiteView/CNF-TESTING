package com.mercury.topaz.cmdb.server.base.dispatcher;

import appilog.framework.shared.manage.MamContext;

public abstract interface ExecutableWorkerQueue<T extends QueuedWorker> extends ExecutableQueue, ReadOnlyWorkerQueue<T>
{
  public abstract MamContext getMamContext();

  public abstract WorkerQueueState getState();

  public abstract boolean readyToDelete();

  public abstract ExecutableWorkerQueue<T> newInstance(Object paramObject);

  public abstract void setState(WorkerQueueState paramWorkerQueueState);

  public abstract boolean isEmpty();
}