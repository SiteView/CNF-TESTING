package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import com.mercury.topaz.cmdb.server.base.dispatcher.CommandFactory;
import com.mercury.topaz.cmdb.server.base.dispatcher.ExecutableWorkerQueue;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;

class ReadyNotStarted extends AbstractQueueState
{
  protected ReadyNotStarted()
  {
    super("READY-NOT-STARTED");
  }

  public void put(ExecutableWorkerQueue queue, QueuedWorker worker) {
    queue.offer(worker);
  }

  public void activate(CommandFactory factory, ExecutableWorkerQueue queue) {
    queue.setState(AbstractQueueState.STATE_ACTIVE);
    queue.swap();
    executeQueue(factory, queue);
  }

  private void executeQueue(CommandFactory factory, ExecutableWorkerQueue queue)
  {
    factory.startQueue(queue);
  }

  public void deActivate(ExecutableWorkerQueue queue) {
    throw new IllegalStateException("Can't move from READY-NOT-STARTED state 2 NOT_ACTIVE state on queue: " + queue.getKey());
  }

  public boolean readyToDelete(ExecutableWorkerQueue queue) {
    return false;
  }
}