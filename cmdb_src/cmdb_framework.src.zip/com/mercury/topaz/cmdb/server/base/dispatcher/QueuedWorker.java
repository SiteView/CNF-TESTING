package com.mercury.topaz.cmdb.server.base.dispatcher;

public abstract interface QueuedWorker
{
  public abstract void doWork(ExecutableWorkerQueue paramExecutableWorkerQueue);

  public abstract QueuedWorker newInstance();

  public abstract WorkerType getType();

  public abstract void recycle();
}