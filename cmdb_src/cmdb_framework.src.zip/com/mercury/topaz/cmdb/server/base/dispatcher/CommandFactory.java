package com.mercury.topaz.cmdb.server.base.dispatcher;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface CommandFactory
{
  public abstract FrameworkOperation getTimerTickCommand();

  public abstract String getProcessingTaskName();

  public abstract void startQueue(ExecutableQueue paramExecutableQueue);

  public abstract void executeQueue(ExecutableQueue paramExecutableQueue);
}