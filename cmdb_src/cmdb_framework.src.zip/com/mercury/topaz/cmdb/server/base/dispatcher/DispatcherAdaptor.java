package com.mercury.topaz.cmdb.server.base.dispatcher;

import java.util.List;

public abstract interface DispatcherAdaptor
{
  public abstract void createQueue(String paramString, List<QueuedWorker> paramList);

  public abstract void createQueue(String paramString);

  public abstract void addWorker2Queue(String paramString, QueuedWorker paramQueuedWorker);

  public abstract void addWorkers2Queue(String paramString, List<QueuedWorker> paramList);
}