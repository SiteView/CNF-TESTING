package com.mercury.topaz.cmdb.server.base.itc.lock.impl;

import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbLock;
import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbReadWriteLock;
import com.mercury.topaz.cmdb.server.manage.semaphore.BottlenecksHistory;
import java.util.concurrent.locks.ReentrantLock;

public class ReadWriteLockForSingleReaderWriterImpl
  implements CmdbReadWriteLock
{
  private CmdbLock _lock;

  public ReadWriteLockForSingleReaderWriterImpl()
  {
    this(null);
  }

  public ReadWriteLockForSingleReaderWriterImpl(BottlenecksHistory bottleneckHistory) {
    setLock(new CmdbLockImpl(new ReentrantLock(true), bottleneckHistory));
  }

  public CmdbLock readLock() {
    return this._lock;
  }

  public CmdbLock writeLock() {
    return this._lock;
  }

  public void setLock(CmdbLock lock) {
    this._lock = lock;
  }
}