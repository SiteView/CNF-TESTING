package com.mercury.topaz.cmdb.server.base.ha.controller.service;

import com.mercury.am.platform.controller.ServiceAccess;
import com.mercury.am.platform.controller.ServiceNotAvailableException;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface CmdbServiceAccess extends ServiceAccess
{
  public abstract CmdbResponse executeCMDBOperation(FrameworkOperation paramFrameworkOperation, CmdbContext paramCmdbContext, boolean paramBoolean)
    throws CmdbResponseException, ServiceNotAvailableException;

  public abstract byte[] executeBinaryRequest(byte[] paramArrayOfByte)
    throws CmdbResponseException, ServiceNotAvailableException;
}