package com.mercury.topaz.cmdb.server.base.util.cache.operation;

import appilog.framework.client.manage.api.MamApi;
import appilog.framework.client.manage.api.impl.MamApiFactory;
import appilog.framework.shared.base.log.MamLogFactory;
import appilog.framework.shared.manage.MamContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi.TYPE;
import com.mercury.topaz.cmdb.server.base.itc.schedule.Scheduler;
import com.mercury.topaz.cmdb.server.base.util.cache.CacheFacade;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.io.Serializable;
import java.util.List;

public abstract class CacheFacadeImpl<KEY extends Serializable, VALUE extends Serializable>
  implements CacheFacade<KEY, VALUE>
{
  protected Log log = MamLogFactory.getServerFacadeLog();
  private String _service;
  private String _queue;
  private MamContext _mamContext;
  private MamApi _mamApi = MamApiFactory.createAPI();

  protected CacheFacadeImpl(String service, String queue, MamContext mamContext)
  {
    this._service = service;
    this._queue = queue;
    this._mamContext = mamContext;
    this._mamApi = MamApiFactory.createAPI();
  }

  protected CacheFacadeImpl(String service, String queue, MamContext mamContext, CmdbApi.TYPE type) {
    this._service = service;
    this._queue = queue;
    this._mamContext = mamContext;
    this._mamApi = MamApiFactory.createAPI(type);
  }

  public VALUE get(KEY key) {
    CacheQueryGet query = new CacheQueryGet(getQueue(), getService(), key);
    executeOperation(query);
    return query.getValue();
  }

  protected void executeOperation(FrameworkOperation query) {
    this._mamApi.executeOperation(query, this._mamContext);
  }

  private String getService() {
    return this._service;
  }

  private String getQueue() {
    return this._queue;
  }

  public VALUE put(KEY key, VALUE value) {
    CacheUpdatePut update = new CacheUpdatePut(getQueue(), getService(), key, value);
    executeOperation(update);
    return update.getValue();
  }

  public VALUE remove(KEY key) {
    CacheUpdateRemove update = new CacheUpdateRemove(getQueue(), getService(), key);
    executeOperation(update);
    return update.getValue();
  }

  public void shrink() {
    CacheUpdateShrink update = new CacheUpdateShrink(getQueue(), getService());
    executeOperation(update);
  }

  public String createShrinkTask(String taskName, long interval, LocalEnvironment localEvironment) {
    CachePriodicTask cpt = new CachePriodicTask(taskName, getService(), interval, this._mamContext);
    localEvironment.getScheduler().addPeriodicTask(cpt, interval);
    return cpt.getTaskId().toString();
  }

  public String createShrinkTask(long interval, LocalEnvironment localEvironment) {
    return createShrinkTask(getQueue(), interval, localEvironment);
  }

  public void removeShrinkTask(String taskName, LocalEnvironment localEvironment) {
    localEvironment.getScheduler().removePeriodicTask(taskName);
  }

  public void updateDuration(long interval) {
    CacheUpdateUpdateDuration op = new CacheUpdateUpdateDuration(getQueue(), getService(), interval);

    executeOperation(op);
  }

  public void touch(List<KEY> keys) {
    CacheUpdateTouch cut = new CacheUpdateTouch(getQueue(), getService(), keys);
    executeOperation(cut);
  }
}