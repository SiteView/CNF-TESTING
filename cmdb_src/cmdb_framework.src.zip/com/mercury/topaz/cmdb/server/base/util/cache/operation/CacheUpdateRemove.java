package com.mercury.topaz.cmdb.server.base.util.cache.operation;

import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;
import com.mercury.topaz.cmdb.shared.util.cache.GenericCache;
import java.io.Serializable;

class CacheUpdateRemove<KEY extends Serializable, VALUE extends Serializable> extends AbstractCacheQuery<KEY, VALUE>
  implements CmdbUpdate
{
  public CacheUpdateRemove(String queue, String serviceName, KEY key)
  {
    super("CACHE_UPDATE_REMOVE", queue, serviceName, key);
  }

  protected VALUE getResult(GenericCache<KEY, VALUE> cache)
  {
    return ((Serializable)cache.remove(getKey()));
  }

  public void updateUpdateWithResponse(CmdbResponse response)
  {
    super.updateQueryWithResponse(response);
  }
}