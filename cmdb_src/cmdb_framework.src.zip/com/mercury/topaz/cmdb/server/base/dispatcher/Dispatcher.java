package com.mercury.topaz.cmdb.server.base.dispatcher;

import java.util.List;

public abstract interface Dispatcher
{
  public abstract void onTick();

  public abstract void deActivateQueue(Object paramObject);

  public abstract void put(Object paramObject, QueuedWorker paramQueuedWorker);

  public abstract void createQueue(Object paramObject, List<QueuedWorker> paramList);
}