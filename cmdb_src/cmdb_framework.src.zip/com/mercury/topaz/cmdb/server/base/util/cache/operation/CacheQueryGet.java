package com.mercury.topaz.cmdb.server.base.util.cache.operation;

import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;
import com.mercury.topaz.cmdb.shared.util.cache.GenericCache;
import java.io.Serializable;

class CacheQueryGet<KEY extends Serializable, VALUE extends Serializable> extends AbstractCacheQuery<KEY, VALUE>
  implements CmdbQuery
{
  public CacheQueryGet(String queue, String serviceName, KEY key)
  {
    super("CACHE_QUERY_GET", queue, serviceName, key);
  }

  protected VALUE getResult(GenericCache<KEY, VALUE> cache)
  {
    return ((Serializable)cache.get(getKey()));
  }
}