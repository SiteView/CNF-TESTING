package com.mercury.topaz.cmdb.server.base.dispatcher;

public abstract interface WorkerQueue<T> extends Iterable<T>, ReadOnlyWorkerQueue<T>
{
  public abstract void swap();

  public abstract boolean offer(T paramT);

  public abstract T poll();

  public abstract T remove();

  public abstract T peek();

  public abstract int size();

  public abstract void clear();
}