package com.mercury.topaz.cmdb.server.base.dispatcher.command;

import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCommonOperation;

public abstract class AbstractDispatcherCommand extends AbstractCommonOperation
{
  private String taskName;
  private String serviceName;

  public AbstractDispatcherCommand(String taskName, String serviceName)
  {
    this.taskName = taskName;
    this.serviceName = serviceName;
  }

  public String getExecutionTaskQueueName()
  {
    return this.taskName;
  }

  public String getServiceName() {
    return this.serviceName;
  }

  public String getShortAuditMessage()
  {
    return getAdditionalLogMessage();
  }

  public boolean isPeriodicOperation()
  {
    return false;
  }

  public void updateWithResponse(CmdbResponse response) {
  }

  public String getAdditionalLogMessage() {
    return getOperationName();
  }
}