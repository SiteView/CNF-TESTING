package com.mercury.topaz.cmdb.server.base.itc.schedule.impl;

import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.base.itc.schedule.PeriodicTaskable;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract class AbstractPeriodicTask
  implements PeriodicTaskable
{
  private String _taskName;
  private long _interval;
  private CmdbContext _context;
  private CmdbApi _cmdbApi;

  public AbstractPeriodicTask(String taskName, long intervalMilliSeconds, CmdbContext context)
  {
    setTaskName(taskName);
    setInterval(intervalMilliSeconds);
    setContext(context);
  }

  public int getIntervalInSec() {
    return (int)(getInterval() / 1000L);
  }

  public Object getTaskId() {
    return getTaskName();
  }

  public void execute()
  {
    FrameworkOperation command = createCommand();

    getApi().executeCMDBOperation(command, getContext(), false);
  }

  protected abstract FrameworkOperation createCommand();

  private CmdbApi getApi() throws CmdbResponseException
  {
    if (getCmdbApi() == null)
      try {
        setCmdbApi(CmdbApiFactory.createCMDBAPI(CmdbApi.LOCAL_TYPE));
      }
      catch (CmdbException e) {
        throw new MamResponseException("Can't createCalculationState local API to CMDB server due to an exception: " + e.getMessage(), e, "");
      }


    return getCmdbApi();
  }

  protected String getTaskName()
  {
    return this._taskName;
  }

  private void setTaskName(String taskName) {
    this._taskName = taskName;
  }

  private long getInterval() {
    return this._interval;
  }

  private void setInterval(long interval) {
    this._interval = interval;
  }

  private CmdbContext getContext() {
    return this._context;
  }

  private void setContext(CmdbContext context) {
    this._context = context;
  }

  private CmdbApi getCmdbApi() {
    return this._cmdbApi;
  }

  private void setCmdbApi(CmdbApi cmdbApi) {
    this._cmdbApi = cmdbApi;
  }
}