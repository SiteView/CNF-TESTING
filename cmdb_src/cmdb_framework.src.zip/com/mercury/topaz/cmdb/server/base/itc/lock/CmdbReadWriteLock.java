package com.mercury.topaz.cmdb.server.base.itc.lock;

public abstract interface CmdbReadWriteLock
{
  public abstract CmdbLock readLock();

  public abstract CmdbLock writeLock();
}