package com.mercury.topaz.cmdb.server.base.dispatcher.command;

import appilog.framework.shared.base.MamException;
import com.mercury.topaz.cmdb.server.base.dispatcher.Dispatcher;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.Iterator;
import java.util.List;

public class AddWorkers2QueueCommand extends AbstractDispatcherCommand
{
  private static final String NAME = "execute workers";
  private Object _queueKey;
  private List<QueuedWorker> _workers;

  AddWorkers2QueueCommand(Object queueKey, List<QueuedWorker> workers, String taskName, String serviceName)
  {
    super(taskName, serviceName);
    this._queueKey = queueKey;
    this._workers = workers;
  }

  protected void commonExecute(CommonManager manager, CmdbResponse response) throws MamException
  {
    Dispatcher dispatcher = (Dispatcher)manager;
    for (Iterator i$ = this._workers.iterator(); i$.hasNext(); ) { QueuedWorker worker = (QueuedWorker)i$.next();
      dispatcher.put(this._queueKey, worker);
    }
  }

  public String getOperationName() {
    return "execute workers";
  }
}