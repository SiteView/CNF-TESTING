package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;
import com.mercury.topaz.cmdb.server.base.dispatcher.WorkerType;
import com.mercury.topaz.cmdb.server.base.dispatcher.WorkersFactory;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public abstract class AbstractWorkersFactory<T extends QueuedWorker>
  implements WorkersFactory<T>
{
  protected int size;
  protected Map<WorkerType, List<T>> workers;

  public AbstractWorkersFactory(int size)
  {
    this.workers = new HashMap();
    this.size = size;
  }

  protected void put(T worker, int size)
  {
    List l = new LinkedList();
    l.add(worker);
    for (int i = 1; i < size; ++i)
      l.add(worker.newInstance());

    this.workers.put(worker.getType(), l);
  }

  public synchronized void putBack(T worker) {
    worker.recycle();
    List l = getList(worker.getType());
    synchronized (l) {
      if (l.size() < this.size) {
        worker.recycle();
        l.add(worker);
      }
    }
  }

  public T getWorker(WorkerType type)
  {
    List l = getList(type);
    synchronized (l) {
      if (l.size() != 1) break label38;
      return ((QueuedWorker)l.get(0)).newInstance();

      label38: return ((QueuedWorker)l.remove(0));
    }
  }

  private List<T> getList(WorkerType type)
  {
    return ((List)this.workers.get(type));
  }
}