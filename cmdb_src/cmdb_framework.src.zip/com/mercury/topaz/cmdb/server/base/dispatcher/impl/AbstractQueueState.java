package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import com.mercury.topaz.cmdb.server.base.dispatcher.WorkerQueueState;

public abstract class AbstractQueueState
  implements WorkerQueueState
{
  public static final WorkerQueueState STATE_READY = new ReadyState();
  public static final WorkerQueueState STATE_ACTIVE = new ActiveState();
  public static final WorkerQueueState STATE_NOT_ACTIVE = new NotActiveState();
  public static final WorkerQueueState STATE_NOT_STARTED = new ReadyNotStarted();
  private String name;

  protected AbstractQueueState(String name)
  {
    this.name = name;
  }

  public String toString() {
    return this.name;
  }
}