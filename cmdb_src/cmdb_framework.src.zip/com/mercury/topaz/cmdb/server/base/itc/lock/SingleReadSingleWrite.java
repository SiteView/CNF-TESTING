package com.mercury.topaz.cmdb.server.base.itc.lock;

public abstract interface SingleReadSingleWrite
{
}