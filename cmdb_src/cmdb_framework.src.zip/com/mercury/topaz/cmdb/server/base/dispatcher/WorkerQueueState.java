package com.mercury.topaz.cmdb.server.base.dispatcher;

public abstract interface WorkerQueueState
{
  public abstract void put(ExecutableWorkerQueue paramExecutableWorkerQueue, QueuedWorker paramQueuedWorker);

  public abstract void activate(CommandFactory paramCommandFactory, ExecutableWorkerQueue paramExecutableWorkerQueue);

  public abstract void deActivate(ExecutableWorkerQueue paramExecutableWorkerQueue);

  public abstract boolean readyToDelete(ExecutableWorkerQueue paramExecutableWorkerQueue);
}