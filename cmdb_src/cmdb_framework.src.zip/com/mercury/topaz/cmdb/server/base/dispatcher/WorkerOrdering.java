package com.mercury.topaz.cmdb.server.base.dispatcher;

public enum WorkerOrdering
{
  FIFO, LIFO;

  public static final WorkerOrdering[] values()
  {
    return ((WorkerOrdering[])$VALUES.clone());
  }
}