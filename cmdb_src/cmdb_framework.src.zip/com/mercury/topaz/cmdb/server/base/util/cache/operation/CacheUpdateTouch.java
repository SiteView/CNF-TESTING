package com.mercury.topaz.cmdb.server.base.util.cache.operation;

import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;
import com.mercury.topaz.cmdb.shared.util.cache.ExpiredCache;
import java.io.Serializable;
import java.util.List;

public class CacheUpdateTouch<KEY extends Serializable, VALUE extends Serializable> extends AbstractCacheOperation<KEY, VALUE>
  implements CmdbUpdate
{
  private List<KEY> keys;

  public CacheUpdateTouch(String queue, String serviceName, List<KEY> keys)
  {
    super("CACHE_UPDATE_TOUCH", queue, serviceName);
    this.keys = keys;
  }

  protected void doCache(ExpiredCache<KEY, VALUE> cache, CmdbResponse response)
  {
    cache.touch(this.keys);
  }

  public void updateUpdateWithResponse(CmdbResponse response)
  {
  }
}