package com.mercury.topaz.cmdb.server.base.dispatcher;

public abstract interface ExecutableQueue
{
  public abstract void execute();

  public abstract void start();

  public abstract void stop();

  public abstract Object getKey();
}