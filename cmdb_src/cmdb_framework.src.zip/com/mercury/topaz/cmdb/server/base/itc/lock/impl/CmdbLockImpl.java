package com.mercury.topaz.cmdb.server.base.itc.lock.impl;

import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbLock;
import com.mercury.topaz.cmdb.server.manage.semaphore.BottlenecksHistory;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.util.concurrent.locks.Lock;

public class CmdbLockImpl
  implements CmdbLock
{
  private Lock lock;
  private BottlenecksHistory bottleneckHistory;

  public CmdbLockImpl(Lock lock)
  {
    this(lock, null);
  }

  public CmdbLockImpl(Lock lock, BottlenecksHistory bottleneckHistory) {
    this.bottleneckHistory = bottleneckHistory;
    setLock(lock);
  }

  public void lock()
    throws InterruptedException
  {
    getLock().lockInterruptibly();
  }

  public void lock(FrameworkOperation operation) throws InterruptedException {
    if (getLock().tryLock()) {
      return;
    }

    if (this.bottleneckHistory != null)
      this.bottleneckHistory.recordContention(operation, this.lock);

    getLock().lockInterruptibly();
  }

  public void unlock()
  {
    getLock().unlock();
  }

  public Lock getLock() {
    return this.lock;
  }

  private void setLock(Lock lock) {
    this.lock = lock;
  }
}