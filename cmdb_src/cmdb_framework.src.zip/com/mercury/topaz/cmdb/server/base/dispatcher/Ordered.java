package com.mercury.topaz.cmdb.server.base.dispatcher;

public abstract interface Ordered
{
  public abstract void setOrder(long paramLong);
}