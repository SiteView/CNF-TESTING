package com.mercury.topaz.cmdb.server.base.itc.schedule;

import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class LocalScheduler extends Scheduler
{
  private final CmdbCustomerID customerID;

  public LocalScheduler(CmdbCustomerID customerID)
  {
    super("UCMDB - scheduler for customer " + customerID);
    this.customerID = customerID;
  }

  public synchronized void addPeriodicTask(PeriodicTaskable task, long delayInMilli) {
    super.addPeriodicTask(new LocalPeriodicTaskWrapper(task, this.customerID), delayInMilli);
  }
}