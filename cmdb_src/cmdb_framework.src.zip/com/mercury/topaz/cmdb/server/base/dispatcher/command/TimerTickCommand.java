package com.mercury.topaz.cmdb.server.base.dispatcher.command;

import appilog.framework.shared.base.MamException;
import com.mercury.topaz.cmdb.server.base.dispatcher.Dispatcher;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class TimerTickCommand extends AbstractDispatcherCommand
{
  private static final String NAME = "Queue Timer Tick";

  TimerTickCommand(String taskName, String serviceName)
  {
    super(taskName, serviceName);
  }

  protected void commonExecute(CommonManager manager, CmdbResponse response) throws MamException {
    Dispatcher dispatcher = (Dispatcher)manager;
    dispatcher.onTick();
  }

  public String getOperationName() {
    return "Queue Timer Tick";
  }

  public boolean isPeriodicOperation()
  {
    return true;
  }
}