package com.mercury.topaz.cmdb.server.base.cfg.impl;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import java.util.Properties;

public class CmdbSettingsFactory
{
  public static SettingsReader createSettings(Properties properties)
  {
    return new CmdbSettingsReaderImpl(properties);
  }

  public static SettingsReader createSettings(Properties properties, String settingsSourceName)
  {
    return new CmdbSettingsReaderImpl(properties, settingsSourceName);
  }

  public static SettingsReader createDefaultSettingsReader()
  {
    return new CmdbSettingsReaderImpl();
  }
}