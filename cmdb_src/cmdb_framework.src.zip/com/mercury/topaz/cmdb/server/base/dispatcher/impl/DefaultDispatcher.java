package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.dispatcher.CommandFactory;
import com.mercury.topaz.cmdb.server.base.dispatcher.Dispatcher;
import com.mercury.topaz.cmdb.server.base.dispatcher.DispatcherPeriodicTask;
import com.mercury.topaz.cmdb.server.base.dispatcher.ExecutableWorkerQueue;
import com.mercury.topaz.cmdb.server.base.dispatcher.InternalDispatcher;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;
import com.mercury.topaz.cmdb.server.base.itc.schedule.Scheduler;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractCommonSubsystemManager;
import java.util.List;

public abstract class DefaultDispatcher extends AbstractCommonSubsystemManager
  implements Dispatcher
{
  private InternalDispatcher internalDispatcher;
  private DispatcherPeriodicTask task;

  public DefaultDispatcher(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
    this.internalDispatcher = createInternalDispatcher();
  }

  protected InternalDispatcher createInternalDispatcher()
  {
    return new DefaultInternalDispatcher(getContext());
  }

  protected void init(Log logger, int interval, ExecutableWorkerQueue<?> prototype, CommandFactory commandFactory) {
    this.internalDispatcher.init(logger, interval, prototype, commandFactory);
  }

  public void onTick()
  {
    this.internalDispatcher.onTick();
  }

  public void startUp() {
    this.task = this.internalDispatcher.createPeriodicTask();
    getLocalEnvironment().getScheduler().addPeriodicTask(this.task, this.internalDispatcher.getTimeInterval());
  }

  public void shutdown()
  {
    getLocalEnvironment().getScheduler().removePeriodicTask(this.task);
  }

  public void createQueue(Object key, List<QueuedWorker> workers) {
    this.internalDispatcher.createQueue(key, workers);
  }

  public void deActivateQueue(Object key)
  {
    this.internalDispatcher.deActivateQueue(key);
  }

  public void put(Object key, QueuedWorker worker)
  {
    this.internalDispatcher.put(key, worker);
  }
}