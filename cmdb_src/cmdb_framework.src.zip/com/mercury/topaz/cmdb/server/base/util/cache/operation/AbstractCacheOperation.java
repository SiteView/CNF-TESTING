package com.mercury.topaz.cmdb.server.base.util.cache.operation;

import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCommonOperation;
import com.mercury.topaz.cmdb.shared.util.cache.ExpiredCache;
import java.io.Serializable;

abstract class AbstractCacheOperation<KEY extends Serializable, VALUE extends Serializable> extends AbstractCommonOperation
{
  private String _queue;
  private String _name;
  private String _serviceName;

  public AbstractCacheOperation(String name, String queue, String serviceName)
  {
    this._queue = queue;
    this._name = name;
    this._serviceName = serviceName;
  }

  public void commonExecute(CommonManager manager, CmdbResponse response) throws CmdbResponseException {
    doCache((ExpiredCache)manager, response);
  }

  protected abstract void doCache(ExpiredCache<KEY, VALUE> paramExpiredCache, CmdbResponse paramCmdbResponse);

  public String getExecutionTaskQueueName() {
    return this._queue;
  }

  public String getOperationName() {
    return this._name;
  }

  public String getServiceName() {
    return this._serviceName;
  }

  public String getAdditionalLogMessage() {
    return getOperationName();
  }

  public String getShortAuditMessage()
  {
    return getOperationName();
  }

  public void updateWithResponse(CmdbResponse response)
  {
  }
}