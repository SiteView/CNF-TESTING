package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import com.mercury.topaz.cmdb.server.base.dispatcher.CommandFactory;
import com.mercury.topaz.cmdb.server.base.dispatcher.ExecutableWorkerQueue;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;

class ReadyState extends AbstractQueueState
{
  protected ReadyState()
  {
    super("READY");
  }

  public void put(ExecutableWorkerQueue queue, QueuedWorker worker) {
    queue.offer(worker);
  }

  public void activate(CommandFactory factory, ExecutableWorkerQueue queue) {
    queue.setState(AbstractQueueState.STATE_ACTIVE);
    queue.swap();
    executeQueue(factory, queue);
  }

  private void executeQueue(CommandFactory factory, ExecutableWorkerQueue queue) {
    factory.executeQueue(queue);
  }

  public void deActivate(ExecutableWorkerQueue queue) {
    throw new IllegalStateException("Can't move from READY state 2 NOT_ACTIVE state on queue: " + queue.getKey());
  }

  public boolean readyToDelete(ExecutableWorkerQueue queue) {
    return false;
  }
}