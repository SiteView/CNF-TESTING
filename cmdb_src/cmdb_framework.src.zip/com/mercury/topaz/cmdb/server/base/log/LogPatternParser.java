package com.mercury.topaz.cmdb.server.base.log;

import org.apache.log4j.helpers.PatternConverter;
import org.apache.log4j.helpers.PatternParser;

public class LogPatternParser extends PatternParser
{
  private static final char CUSTOMER_ID = 73;

  public LogPatternParser(String pattern)
  {
    super(pattern);
  }

  protected void finalizeConverter(char c)
  {
    switch (c)
    {
    case 'I':
      PatternConverter converter = new LogCustomerIDConverter();
      this.currentLiteral.setLength(0);
      addConverter(converter);
      break;
    default:
      super.finalizeConverter(c);
    }
  }
}