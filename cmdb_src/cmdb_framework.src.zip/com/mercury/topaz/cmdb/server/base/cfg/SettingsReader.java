package com.mercury.topaz.cmdb.server.base.cfg;

import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Properties;

public abstract interface SettingsReader
{
  public abstract String getTopazHome();

  public abstract int getInt(String paramString, int paramInt);

  public abstract long getLong(String paramString, long paramLong);

  public abstract float getFloat(String paramString, float paramFloat);

  public abstract boolean getBoolean(String paramString, boolean paramBoolean);

  public abstract String getString(String paramString1, String paramString2);

  public abstract boolean isExist(String paramString);

  public abstract ReadOnlyIterator<String> getPropertyNames();

  public abstract Properties asProperties();
}