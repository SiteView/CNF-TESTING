package com.mercury.topaz.cmdb.server.base.ha.controller.service.impl;

import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.server.manage.service.ServiceComponent;
import com.mercury.topaz.cmdb.server.manage.service.config.ServiceConfig;
import com.mercury.topaz.cmdb.server.manage.service.config.ServicesConfig;
import com.mercury.topaz.cmdb.server.manage.service.config.impl.ObserversConfig;
import com.mercury.topaz.cmdb.server.manage.service.impl.ServiceComponentImpl;
import com.mercury.topaz.cmdb.server.manage.subsystem.ServiceComponentsGroup;
import com.mercury.topaz.cmdb.server.manage.subsystem.observer.SubsystemManagersObserver;
import com.mercury.topaz.cmdb.shared.base.CmdbRuntimeException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class ControllerServiceInstance extends ServiceComponentsGroup
{
  private final String serviceName;

  public ControllerServiceInstance(String serviceName, CustomerInstance customerInstance)
  {
    super(customerInstance, findComponentsForService(serviceName));
    this.serviceName = serviceName;
  }

  private static List<ServiceComponent> findComponentsForService(String serviceName) {
    List serviceComponents = new ArrayList();
    List serviceComponentConfigs = Framework.getInstance().getServicesConfig().getServicesConfig();

    for (Iterator i$ = serviceComponentConfigs.iterator(); i$.hasNext(); ) { ServiceConfig componentConfig = (ServiceConfig)i$.next();
      if (componentConfig.getControllerServiceName().equals(serviceName)) {
        ServiceComponent component = new ServiceComponentImpl(componentConfig);
        serviceComponents.add(component);
      }
    }
    return serviceComponents;
  }

  protected Collection<SubsystemManagersObserver> createSubsystemManagersObservers() {
    Collection observersClasses = Framework.getInstance().getObserversConfig().getObserversOfService(getServiceName());
    Collection observers = new ArrayList();
    for (Iterator i$ = observersClasses.iterator(); i$.hasNext(); ) { Class observerClass = (Class)i$.next();
      try {
        Constructor constructor = observerClass.getConstructor(new Class[] { LocalEnvironment.class });
        observers.add(constructor.newInstance(new Object[] { this.localEnvironment }));
      } catch (NoSuchMethodException e) {
        throw new CmdbRuntimeException("Observer " + observerClass.getName() + " does not have a public constructor taking LocalEnvironment", e);
      } catch (InstantiationException e) {
        throw new CmdbRuntimeException("Failed to create observer of class " + observerClass.getName(), e);
      } catch (IllegalAccessException e) {
        throw new CmdbRuntimeException("Observer " + observerClass.getName() + " does not have a public constructor taking LocalEnvironment", e);
      } catch (InvocationTargetException e) {
        throw new CmdbRuntimeException("Failed to create observer of class " + observerClass.getName(), e);
      }
    }
    return observers;
  }

  public String getServiceName() {
    return this.serviceName;
  }
}