package com.mercury.topaz.cmdb.server.base.log;

import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbContextRepository;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import org.apache.log4j.helpers.PatternConverter;
import org.apache.log4j.spi.LoggingEvent;

public class LogCustomerIDConverter extends PatternConverter
{
  private String constructCustomerID(String original, CmdbCustomerID customerID)
  {
    char separator = '.';
    StringBuilder builder = new StringBuilder();
    if (original.charAt(original.length() - 1) != '.') {
      builder.append('.');
    }

    builder.append(" ").append("Customer <ID: ").append(customerID.getID()).append(", Name: ").append(customerID.getIDName()).append(">");

    return builder.toString();
  }

  private String constructMessage(Object original) {
    CmdbContext context = CmdbContextRepository.get();
    String message = "";
    if (context != null)
      message = constructCustomerID(original.toString(), context.getCustomerID());

    return message;
  }

  protected String convert(LoggingEvent loggingEvent) {
    return constructMessage(loggingEvent.getMessage());
  }
}