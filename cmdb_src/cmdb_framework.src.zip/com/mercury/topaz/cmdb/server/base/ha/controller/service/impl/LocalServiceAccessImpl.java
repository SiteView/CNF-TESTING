package com.mercury.topaz.cmdb.server.base.ha.controller.service.impl;

import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.am.platform.controller.ServiceNotAvailableException;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class LocalServiceAccessImpl extends AbstractCmdbServiceAccess
{
  protected CmdbResponse doHandleRequest(CmdbRequest request)
    throws CmdbResponseException, ServiceNotAvailableException
  {
    return Framework.getInstance().handleRequest(request); }

  public byte[] executeBinaryRequest(byte[] serializedRequest) throws CmdbResponseException, ServiceNotAvailableException {
    ObjectInputStream objectInputStream;
    try {
      objectInputStream = new ObjectInputStream(new ByteArrayInputStream(serializedRequest));
      CmdbRequest request = (CmdbRequest)objectInputStream.readObject();
      CmdbResponse response = doHandleRequest(request);
      ByteArrayOutputStream serializedResponse = new ByteArrayOutputStream();
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(serializedResponse);
      objectOutputStream.writeObject(response);
      objectOutputStream.close();
      return serializedResponse.toByteArray();
    } catch (IOException e) {
      throw new MamResponseException(e, "N/A");
    } catch (ClassNotFoundException e) {
      throw new MamResponseException(e, "N/A");
    }
  }
}