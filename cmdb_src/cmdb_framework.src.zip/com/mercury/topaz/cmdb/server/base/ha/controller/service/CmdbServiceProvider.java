package com.mercury.topaz.cmdb.server.base.ha.controller.service;

import com.mercury.am.platform.controller.spi.ServiceProvider;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.impl.ControllerServiceInstance;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;

public abstract interface CmdbServiceProvider extends ServiceProvider
{
  public abstract ControllerServiceInstance createServiceInstance(CustomerInstance paramCustomerInstance);
}