package com.mercury.topaz.cmdb.server.base.util.cache.operation;

import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;
import com.mercury.topaz.cmdb.shared.util.cache.GenericCache;
import java.io.Serializable;

class CacheUpdatePut<KEY extends Serializable, VALUE extends Serializable> extends AbstractCacheQuery<KEY, VALUE>
  implements CmdbUpdate
{
  private VALUE newValue;

  public CacheUpdatePut(String queue, String serviceName, KEY key, VALUE value)
  {
    super("CACHE_UPDATE_PUT", queue, serviceName, key);
    this.newValue = value;
  }

  protected VALUE getResult(GenericCache<KEY, VALUE> cache)
  {
    return ((Serializable)cache.put(getKey(), this.newValue));
  }

  public void updateUpdateWithResponse(CmdbResponse response)
  {
    super.updateQueryWithResponse(response);
  }
}