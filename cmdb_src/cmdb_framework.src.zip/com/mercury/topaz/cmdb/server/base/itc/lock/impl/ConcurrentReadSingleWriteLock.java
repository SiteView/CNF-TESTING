package com.mercury.topaz.cmdb.server.base.itc.lock.impl;

import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbLock;
import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbReadWriteLock;
import com.mercury.topaz.cmdb.server.manage.semaphore.BottlenecksHistory;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.util.concurrent.locks.ReentrantLock;

public class ConcurrentReadSingleWriteLock
  implements CmdbReadWriteLock
{
  private final CmdbLock writeLock;
  private final CmdbLock readLock;

  public ConcurrentReadSingleWriteLock()
  {
    this(null);
  }

  public ConcurrentReadSingleWriteLock(BottlenecksHistory bottleneckHistory) {
    this.writeLock = new CmdbLockImpl(new ReentrantLock(true), bottleneckHistory);
    this.readLock = new CmdbLock(this) {
      public void lock() throws InterruptedException {
      }

      public void lock() throws InterruptedException {
      }

      public void unlock() throws InterruptedException {
      }
    };
  }

  public CmdbLock readLock() {
    return this.readLock;
  }

  public CmdbLock writeLock() {
    return this.writeLock;
  }
}