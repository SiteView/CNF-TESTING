package com.mercury.topaz.cmdb.server.base.dispatcher.command;

import appilog.framework.shared.base.MamException;
import com.mercury.topaz.cmdb.server.base.dispatcher.Dispatcher;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class DeActivateQueueCommand extends AbstractDispatcherCommand
{
  private static final String NAME = "DE_ACTIVATE_QUEUE";
  private Object queueKey;

  DeActivateQueueCommand(Object key, String taskName, String serviceName)
  {
    super(taskName, serviceName);
    this.queueKey = key;
  }

  protected void commonExecute(CommonManager manager, CmdbResponse response)
    throws MamException
  {
    Dispatcher dispatcher = (Dispatcher)manager;
    dispatcher.deActivateQueue(getQueueKey());
  }

  private Object getQueueKey()
  {
    return this.queueKey;
  }

  public String getOperationName() {
    return "DE_ACTIVATE_QUEUE";
  }
}