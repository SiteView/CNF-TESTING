package com.mercury.topaz.cmdb.server.base.util.cache;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.util.cache.ExpiredCache;

public abstract interface CacheFacade<KEY, VALUE> extends ExpiredCache<KEY, VALUE>
{
  public abstract String createShrinkTask(String paramString, long paramLong, LocalEnvironment paramLocalEnvironment);

  public abstract String createShrinkTask(long paramLong, LocalEnvironment paramLocalEnvironment);

  public abstract void removeShrinkTask(String paramString, LocalEnvironment paramLocalEnvironment);
}