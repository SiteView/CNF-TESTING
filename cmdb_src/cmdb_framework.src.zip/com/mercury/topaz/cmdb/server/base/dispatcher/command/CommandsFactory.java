package com.mercury.topaz.cmdb.server.base.dispatcher.command;

import appilog.framework.client.manage.api.MamApi;
import appilog.framework.client.manage.api.impl.MamApiFactory;
import appilog.framework.shared.manage.MamContext;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.server.base.dispatcher.CommandFactory;
import com.mercury.topaz.cmdb.server.base.dispatcher.DispatcherAdaptor;
import com.mercury.topaz.cmdb.server.base.dispatcher.ExecutableQueue;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.util.List;

public class CommandsFactory
  implements CommandFactory, DispatcherAdaptor
{
  private String _queueTaskName;
  private String _serviceName;
  private String _processingTaskName;
  private MamContext _context;

  public CommandsFactory(String queueTaskName, String processingTaskName, String serviceName, MamContext context)
  {
    setServiceName(serviceName);
    setQueueTaskName(queueTaskName);
    setProcessingTaskName(processingTaskName);
    this._context = context;
  }

  private AddWorker2QueueCommand getAddWorker2QueueCommand(Object queueKey, QueuedWorker worker) {
    return new AddWorker2QueueCommand(queueKey, worker, getQueueTaskName(), getServiceName());
  }

  private AddWorkers2QueueCommand getAddWorkers2QueueCommand(Object queueKey, List<QueuedWorker> workers) {
    return new AddWorkers2QueueCommand(queueKey, workers, getQueueTaskName(), getServiceName());
  }

  public FrameworkOperation getTimerTickCommand() {
    return new TimerTickCommand(getQueueTaskName(), getServiceName());
  }

  private ExecuteQueueCommand getExecuteQueueCommand(ExecutableQueue queue) {
    return new ExecuteQueueCommand(queue, getQueueTaskName(), getProcessingTaskName(), getServiceName());
  }

  public String getProcessingTaskName() {
    return this._processingTaskName;
  }

  private FrameworkOperation getCreateQueueCommand(Object key, List<QueuedWorker> workers) {
    return new CreateQueueCommand(key, workers, getQueueTaskName(), getServiceName());
  }

  private FrameworkOperation getCreateQueueCommand(Object key) {
    return new CreateQueueCommand(key, getQueueTaskName(), getServiceName());
  }

  public ExecuteQueueCommand getStartQueueCommand(ExecutableQueue queue) {
    return new StartQueueCommand(queue, getQueueTaskName(), getProcessingTaskName(), getServiceName());
  }

  public void executeQueue(ExecutableQueue queue) {
    execute(getExecuteQueueCommand(queue), false);
  }

  public void startQueue(ExecutableQueue queue) {
    execute(getStartQueueCommand(queue), false);
  }

  public void createQueue(String queueKey, List<QueuedWorker> workers) {
    execute(getCreateQueueCommand(queueKey, workers));
  }

  public void createQueue(String queueKey) {
    execute(getCreateQueueCommand(queueKey));
  }

  public void addWorker2Queue(String queueKey, QueuedWorker worker) {
    execute(getAddWorker2QueueCommand(queueKey, worker));
  }

  public void addWorkers2Queue(String queueKey, List<QueuedWorker> workers) {
    execute(getAddWorkers2QueueCommand(queueKey, workers));
  }

  private void execute(FrameworkOperation command) {
    execute(command, true);
  }

  private void execute(FrameworkOperation command, boolean isSynchronic) {
    MamApiFactory.createAPI(CmdbApi.LOCAL_TYPE).executeOperation(command, this._context, isSynchronic);
  }

  private void setQueueTaskName(String queueTaskName) {
    this._queueTaskName = queueTaskName;
  }

  private String getQueueTaskName() {
    return this._queueTaskName;
  }

  private void setProcessingTaskName(String processingTaskName) {
    this._processingTaskName = processingTaskName;
  }

  public String getServiceName() {
    return this._serviceName;
  }

  public void setServiceName(String serviceName) {
    this._serviceName = serviceName;
  }
}