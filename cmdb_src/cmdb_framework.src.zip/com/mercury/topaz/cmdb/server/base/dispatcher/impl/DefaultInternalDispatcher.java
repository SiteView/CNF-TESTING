package com.mercury.topaz.cmdb.server.base.dispatcher.impl;

import appilog.framework.shared.base.MamException;
import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.dispatcher.CommandFactory;
import com.mercury.topaz.cmdb.server.base.dispatcher.DispatcherPeriodicTask;
import com.mercury.topaz.cmdb.server.base.dispatcher.ExecutableWorkerQueue;
import com.mercury.topaz.cmdb.server.base.dispatcher.InternalDispatcher;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;
import com.mercury.topaz.cmdb.server.base.dispatcher.WorkerQueueState;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DefaultInternalDispatcher
  implements InternalDispatcher
{
  private CommandFactory commandFactory;
  private Log logger;
  private int interval;
  private Map<Object, ExecutableWorkerQueue<?>> queues = new HashMap();
  private ExecutableWorkerQueue<?> prototype;
  private CmdbContext context;

  public DefaultInternalDispatcher(MamContext context)
  {
    this.context = context;
  }

  public void init(Log logger, int interval, ExecutableWorkerQueue<?> prototype, CommandFactory commandFactory)
  {
    this.prototype = prototype;
    this.commandFactory = commandFactory;
    this.logger = logger;
    this.interval = interval;
  }

  protected ExecutableWorkerQueue<?> getPrototype() {
    return this.prototype;
  }

  public void onTick()
  {
    Iterator itr = getQueuesIterator();
    while (itr.hasNext())
    {
      ExecutableWorkerQueue queue = (ExecutableWorkerQueue)itr.next();
      try {
        if (queue.getState().readyToDelete(queue)) {
          itr.remove();
          if (this.logger.isDebugEnabled())
            this.logger.debug("[" + getCustomerID() + "] queue " + queue.getKey() + " was removed");
        }
        else {
          if (this.logger.isDebugEnabled()) {
            this.logger.debug("[" + getCustomerID() + "] Activating queue: " + queue.getKey() + " state is: " + queue.getState());
          }

          queue.getState().activate(this.commandFactory, queue);
        }
      } catch (Exception ex) {
        this.logger.warn("exception during queue activating: " + queue.getKey(), ex);
      }
    }
  }

  private MamCustomerID getCustomerID() {
    return getContext().getCustomerID();
  }

  public void deActivateQueue(Object key)
  {
    ExecutableWorkerQueue queue = getQueue(key);
    if (queue != null) {
      if (this.logger.isDebugEnabled())
        this.logger.debug("[" + getCustomerID() + "] deactivating queue: " + key);

      queue.getState().deActivate(queue);
    }
  }

  public void put(Object key, QueuedWorker worker)
  {
    ExecutableWorkerQueue queue = getQueue(key);
    if (queue != null) {
      if (this.logger.isDebugEnabled())
        this.logger.debug("[" + getCustomerID() + "] add worker 2 Queue[ " + key + "] worker:" + worker);

      queue.getState().put(queue, worker);
    }
  }

  private ExecutableWorkerQueue<?> getQueue(Object key) {
    return ((ExecutableWorkerQueue)this.queues.get(key));
  }

  private Iterator<ExecutableWorkerQueue<?>> getQueuesIterator() {
    return this.queues.values().iterator();
  }

  public DispatcherPeriodicTask createPeriodicTask()
  {
    return new DispatcherPeriodicTask(this.commandFactory, this.interval, getContext());
  }

  private CmdbContext getContext() {
    return this.context;
  }

  public long getTimeInterval()
  {
    return this.interval;
  }

  public void createQueue(Object key, List<QueuedWorker> workers) {
    ExecutableWorkerQueue queue = (ExecutableWorkerQueue)this.queues.get(key);
    if (queue == null)
      try {
        queue = this.prototype.newInstance(key);
        this.queues.put(key, queue);
        queue.setState(AbstractQueueState.STATE_NOT_STARTED);
        if (this.logger.isDebugEnabled())
          this.logger.debug("[" + getCustomerID() + "] queue " + key + " was created");
      }
      catch (Exception ex) {
        this.logger.error("error while creating a new queue:", ex);
        throw new MamException(ex, -1);
      }

    if (workers != null)
      for (Iterator i$ = workers.iterator(); i$.hasNext(); ) { QueuedWorker worker = (QueuedWorker)i$.next();
        put(key, worker);
      }
  }
}