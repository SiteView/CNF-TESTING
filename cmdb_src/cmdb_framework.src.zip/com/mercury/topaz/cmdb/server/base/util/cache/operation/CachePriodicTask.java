package com.mercury.topaz.cmdb.server.base.util.cache.operation;

import appilog.framework.shared.manage.MamContext;
import com.mercury.topaz.cmdb.server.base.itc.schedule.impl.AbstractPeriodicTask;
import com.mercury.topaz.cmdb.shared.manage.operation.command.CmdbCommand;

public class CachePriodicTask extends AbstractPeriodicTask
{
  private String _serviceName;

  public CachePriodicTask(String taskName, String serviceName, long intervalMilliSeconds, MamContext context)
  {
    super(taskName, intervalMilliSeconds, context);
    this._serviceName = serviceName;
  }

  protected CmdbCommand createCommand()
  {
    return new CacheUpdateShrink(getTaskName(), this._serviceName);
  }
}