package com.mercury.topaz.cmdb.server.base.ha.controller.service.impl;

import com.mercury.am.platform.controller.Server;
import com.mercury.am.platform.controller.ServiceNotAvailableException;
import com.mercury.am.platform.controller.spi.ServerCommunicationException;
import com.mercury.am.platform.controller.spi.ServiceLocationMismatchException;
import com.mercury.topaz.cmdb.shared.manage.CmdbFacade;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbCustomerNotExistException;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.util.Exceptions;
import java.rmi.RemoteException;

public class RMIServiceAccessImpl extends AbstractCmdbServiceAccess
{
  private CmdbFacade _cmdbFacade;
  private Server _server;

  public RMIServiceAccessImpl(CmdbFacade cmdbFacade, Server server)
  {
    setCmdbFacade(cmdbFacade);
    setServer(server);
  }

  protected CmdbResponse doHandleRequest(CmdbRequest request) throws CmdbResponseException, ServiceNotAvailableException {
    try {
      return getCmdbFacade().handleRequest(request);
    } catch (RuntimeException e) {
      ServiceNotAvailableException sna = (ServiceNotAvailableException)Exceptions.findClassInCauseChain(ServiceNotAvailableException.class, e);
      if (sna != null)
        throw sna;

      CmdbCustomerNotExistException cne = (CmdbCustomerNotExistException)Exceptions.findClassInCauseChain(CmdbCustomerNotExistException.class, e);
      if (cne != null)
        throw new ServiceLocationMismatchException(e);

      throw e;
    }
    catch (RemoteException e) {
      throw new ServerCommunicationException("Failed to communicate with CMDB server on " + getServer(), e);
    }
  }

  public byte[] executeBinaryRequest(byte[] serializedRequest) throws CmdbResponseException, ServiceNotAvailableException {
    try {
      return getCmdbFacade().handleBinaryRequest(serializedRequest);
    } catch (RuntimeException e) {
      ServiceNotAvailableException sna = (ServiceNotAvailableException)Exceptions.findClassInCauseChain(ServiceNotAvailableException.class, e);
      if (sna != null)
        throw sna;

      CmdbCustomerNotExistException cne = (CmdbCustomerNotExistException)Exceptions.findClassInCauseChain(CmdbCustomerNotExistException.class, e);
      if (cne != null)
        throw new ServiceLocationMismatchException(e);

      throw e;
    } catch (RemoteException e) {
      throw new ServerCommunicationException("Failed to communicate with CMDB server on " + getServer(), e);
    }
  }

  private CmdbFacade getCmdbFacade() {
    return this._cmdbFacade;
  }

  private void setCmdbFacade(CmdbFacade cmdbFacade) {
    if (cmdbFacade == null)
      throw new IllegalArgumentException("cmdb facade is null !!!");

    this._cmdbFacade = cmdbFacade;
  }

  private Server getServer() {
    return this._server;
  }

  private void setServer(Server server) {
    this._server = server;
  }
}