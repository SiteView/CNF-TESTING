package com.mercury.topaz.cmdb.server.base.itc.lock;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface CmdbLock
{
  public abstract void lock()
    throws InterruptedException;

  public abstract void lock(FrameworkOperation paramFrameworkOperation)
    throws InterruptedException;

  public abstract void unlock()
    throws InterruptedException;
}