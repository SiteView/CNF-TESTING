package com.mercury.topaz.cmdb.server.base.cfg.impl;

import com.mercury.infra.utils.environment.Environment;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.EmptyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

class CmdbSettingsReaderImpl
  implements SettingsReader
{
  static Log _logger = LogFactory.getEasyLog(CmdbSettingsReaderImpl.class);
  private Properties _properties;
  private String _settingsSourceName;

  public CmdbSettingsReaderImpl()
  {
    this(new Properties(), "Cmdb Default Settings Reader");
  }

  public CmdbSettingsReaderImpl(Properties properties)
  {
    this(properties, "N/A");
  }

  public CmdbSettingsReaderImpl(Properties properties, String settingsSourceName)
  {
    setProperties((Properties)properties.clone());
    setSettingsSourceName(settingsSourceName);
  }

  public String getTopazHome()
  {
    return Environment.getInstance().getEnvironmentHomePath();
  }

  public int getInt(String paramName, int defaultValue)
  {
    String intAsString = getProperty(paramName);

    if ((intAsString == null) || (intAsString.length() == 0))
      return defaultValue;

    try
    {
      return Integer.parseInt(intAsString);
    }
    catch (NumberFormatException nfe) {
      logFormatErrorMessage(paramName, intAsString, "integer"); }
    return defaultValue;
  }

  public long getLong(String paramName, long defaultValue)
  {
    String longAsString = getProperty(paramName);

    if ((longAsString == null) || (longAsString.length() == 0))
      return defaultValue;

    try
    {
      return Long.parseLong(longAsString);
    }
    catch (NumberFormatException nfe) {
      logFormatErrorMessage(paramName, longAsString, "long"); }
    return defaultValue;
  }

  public float getFloat(String paramName, float defaultValue)
  {
    String floatAsString = getProperty(paramName);

    if ((floatAsString == null) || (floatAsString.length() == 0))
      return defaultValue;

    try
    {
      return Float.parseFloat(floatAsString);
    }
    catch (NumberFormatException nfe) {
      logFormatErrorMessage(paramName, floatAsString, "Float"); }
    return defaultValue;
  }

  public boolean getBoolean(String paramName, boolean defaultValue)
  {
    String booleanAsString = getProperty(paramName);

    if ((booleanAsString == null) || (booleanAsString.length() == 0)) {
      return defaultValue;
    }

    if ((booleanAsString.equalsIgnoreCase("true")) || (booleanAsString.equalsIgnoreCase("t")))
      return true;
    if ((booleanAsString.equalsIgnoreCase("false")) || (booleanAsString.equalsIgnoreCase("f")))
      return false;

    logFormatErrorMessage(paramName, booleanAsString, "Boolean");
    return defaultValue;
  }

  public String getString(String paramName, String defaultValue)
  {
    String value = getProperty(paramName);
    if (value == null)
      return defaultValue;

    return value;
  }

  public boolean isExist(String paramName)
  {
    return (getProperties().getProperty(paramName) != null);
  }

  public ReadOnlyIterator<String> getPropertyNames()
  {
    if (getProperties().size() == 0)
      return EmptyIterator.getInstance();

    Iterator itr = getProperties().keySet().iterator();
    return new ReadOnlyIteratorImpl(itr);
  }

  private String getProperty(String paramName)
  {
    String parametrValue = getProperties().getProperty(paramName.trim());
    if (parametrValue == null) {
      _logger.error("parameter [" + paramName + "] doesn't exist in configuration file <" + getSettingsSourceName() + ">");
      return null;
    }
    return parametrValue;
  }

  private void logFormatErrorMessage(String paramName, String value, String type)
  {
    _logger.error("parameter [" + paramName + "] gets value" + "[" + value + "] that not suitable for " + type + " format in configuration source name <" + getSettingsSourceName() + ">");
  }

  private Properties getProperties()
  {
    return this._properties;
  }

  public Properties asProperties() {
    return ((Properties)getProperties().clone());
  }

  public void setProperties(Properties properties) {
    if (properties == null)
      throw new IllegalArgumentException("Attempt to set 'null' properties");

    this._properties = properties;
  }

  public String getSettingsSourceName() {
    return this._settingsSourceName;
  }

  public void setSettingsSourceName(String settingsSourceName)
  {
    if (settingsSourceName == null)
      throw new IllegalArgumentException("Attempt to set 'null' settings source name");

    this._settingsSourceName = settingsSourceName;
  }
}