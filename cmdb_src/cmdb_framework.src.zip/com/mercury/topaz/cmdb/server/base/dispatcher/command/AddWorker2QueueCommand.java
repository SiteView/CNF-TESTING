package com.mercury.topaz.cmdb.server.base.dispatcher.command;

import appilog.framework.shared.base.MamException;
import com.mercury.topaz.cmdb.server.base.dispatcher.Dispatcher;
import com.mercury.topaz.cmdb.server.base.dispatcher.QueuedWorker;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class AddWorker2QueueCommand extends AbstractDispatcherCommand
{
  private static final String NAME = "Add Worker 2 Queue";
  private QueuedWorker worker;
  private Object queueKey;

  AddWorker2QueueCommand(Object queueKey, QueuedWorker worker, String taskName, String serviceName)
  {
    super(taskName, serviceName);
    this.worker = worker;
    this.queueKey = queueKey;
  }

  protected void commonExecute(CommonManager manager, CmdbResponse response) throws MamException
  {
    Dispatcher dispatcher = (Dispatcher)manager;
    dispatcher.put(this.queueKey, this.worker);
  }

  public String getOperationName() {
    return "Add Worker 2 Queue";
  }

  public String getAdditionalLogMessage()
  {
    return String.valueOf(this.worker.getType());
  }
}