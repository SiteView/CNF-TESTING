package com.mercury.topaz.cmdb.server.base.util.cache.operation;

import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.command.CmdbCommand;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;
import com.mercury.topaz.cmdb.shared.util.cache.ExpiredCache;
import java.io.Serializable;

class CacheUpdateShrink<KEY extends Serializable, VALUE extends Serializable> extends AbstractCacheOperation<KEY, VALUE>
  implements CmdbUpdate, CmdbCommand
{
  public CacheUpdateShrink(String queue, String serviceName)
  {
    super("CACHE_UPDATE_SHRINK", queue, serviceName);
  }

  protected void doCache(ExpiredCache<KEY, VALUE> cache, CmdbResponse response)
  {
    cache.shrink();
  }

  public void updateUpdateWithResponse(CmdbResponse response)
  {
  }
}