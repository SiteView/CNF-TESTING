package com.mercury.topaz.cmdb.server.base.dispatcher;

import com.mercury.topaz.cmdb.server.base.itc.schedule.impl.AbstractPeriodicTask;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public class DispatcherPeriodicTask extends AbstractPeriodicTask
{
  private CommandFactory commandsFactory;

  public DispatcherPeriodicTask(CommandFactory commandsFactory, long intervalMilliSeconds, CmdbContext context)
  {
    super(commandsFactory.getProcessingTaskName(), intervalMilliSeconds, context);
    this.commandsFactory = commandsFactory;
  }

  protected FrameworkOperation createCommand()
  {
    return this.commandsFactory.getTimerTickCommand();
  }
}