package com.mercury.topaz.cmdb.server.monitors.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsQueryManager;
import com.mercury.topaz.cmdb.server.monitors.operation.impl.AbstractMonitorsOperation;
import com.mercury.topaz.cmdb.server.monitors.operation.query.MonitorsQueryOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractMonitorsQueryOperation extends AbstractMonitorsOperation
  implements MonitorsQueryOperation
{
  protected void doExecute(GlobalSubsystemManager manager, CmdbResponse response)
    throws CmdbException
  {
    monitorQueryExecute((MonitorsQueryManager)manager, response);
  }
}