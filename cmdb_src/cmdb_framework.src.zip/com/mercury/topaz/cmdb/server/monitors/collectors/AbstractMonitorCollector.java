package com.mercury.topaz.cmdb.server.monitors.collectors;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl.CmdbCustomerQueryGetLoadedCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.operation.util.AbstractOperationExecutor;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;

public abstract class AbstractMonitorCollector
  implements MonitorCollector
{
  protected CmdbCustomerIDs getLoadedCustomerIDs(GlobalSubsystemManager globalManager)
  {
    CmdbCustomerQueryGetLoadedCustomerIDs getLoadedCustomerIDs = new CmdbCustomerQueryGetLoadedCustomerIDs();
    globalManager.executeGlobalOperation(getLoadedCustomerIDs);
    return getLoadedCustomerIDs.getCustomerIDs();
  }

  protected OperationExecutor createOperationExecutor(CmdbCustomerID customerID)
  {
    return new AbstractOperationExecutor(this, customerID)
    {
    };
  }
}