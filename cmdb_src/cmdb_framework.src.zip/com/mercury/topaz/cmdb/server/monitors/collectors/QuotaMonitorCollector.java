package com.mercury.topaz.cmdb.server.monitors.collectors;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.info.impl.QuotaMonitorInfo;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.query.impl.QuotaQueryGetQuotaAndCountInfo;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class QuotaMonitorCollector extends AbstractMonitorCollector
{
  private static Log _logger = CmdbLogFactory.getMonitorLog();

  public CmdbMonitorInfo collect(GlobalSubsystemManager globalManager)
  {
    QuotaQueryGetQuotaAndCountInfo quotaQueryGetQuotaAndCountInfo = new QuotaQueryGetQuotaAndCountInfo();
    globalManager.executeGlobalOperation(quotaQueryGetQuotaAndCountInfo);
    Map serverQuotaAndCountInfo = quotaQueryGetQuotaAndCountInfo.getServerQuotasAndCounts();
    Map customersQuotaAndCount = quotaQueryGetQuotaAndCountInfo.getQuotaAndCountInfo();

    if (_logger.isInfoEnabled())
    {
      _logger.info("************************************************************");
      _logger.info("          Quota And Count Monitor Info was refreshed");
      for (Iterator itr = customersQuotaAndCount.keySet().iterator(); itr.hasNext(); ) {
        CmdbCustomerID customerID = (CmdbCustomerID)itr.next();
        CustomerQuotasAndCounts custQuotasAndCounts = (CustomerQuotasAndCounts)customersQuotaAndCount.get(customerID);
        _logger.info("Customer ID [" + customerID.getID() + "]");
        for (Iterator itr2 = custQuotasAndCounts.getQuotaNames().iterator(); itr2.hasNext(); ) {
          String quotaName = (String)itr2.next();
          QuotaCount quotaCount = custQuotasAndCounts.getQuotaCount(quotaName);
          _logger.info("quota [" + quotaName + "], current count set to : " + quotaCount.getCount() + " quota is : " + quotaCount.getQuota());
        }
      }

      Set serverQuotaNames = serverQuotaAndCountInfo.keySet();
      for (Iterator itr = serverQuotaNames.iterator(); itr.hasNext(); ) {
        String quotaName = (String)itr.next();
        QuotaCount quotaCount = (QuotaCount)serverQuotaAndCountInfo.get(quotaName);
        _logger.info("server quota [" + quotaName + "], current count set to : " + quotaCount.getCount() + " quota is : " + quotaCount.getQuota());
      }
      _logger.info("************************************************************");
    }
    return new QuotaMonitorInfo(serverQuotaAndCountInfo, customersQuotaAndCount);
  }
}