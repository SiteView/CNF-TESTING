package com.mercury.topaz.cmdb.server.monitors;

import com.mercury.topaz.cmdb.server.monitors.collectors.MonitorCollector;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfoWrapper;
import java.util.List;
import java.util.Map;

public abstract interface MonitorsFactory
{
  public abstract List<MonitorCollector> getCollectors(String paramString);

  public abstract Map<String, CmdbMonitorInfoWrapper> getInfos();

  public abstract Map<String, CmdbMonitor> getMonitors(String paramString);
}