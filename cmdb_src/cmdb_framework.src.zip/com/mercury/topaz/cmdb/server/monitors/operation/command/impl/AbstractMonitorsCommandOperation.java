package com.mercury.topaz.cmdb.server.monitors.operation.command.impl;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsCollectorsManager;
import com.mercury.topaz.cmdb.server.monitors.operation.command.MonitorsCommandOperation;
import com.mercury.topaz.cmdb.server.monitors.operation.impl.AbstractMonitorsOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractMonitorsCommandOperation extends AbstractMonitorsOperation
  implements MonitorsCommandOperation
{
  public String getExecutionTaskQueueName()
  {
    return "Monitors Collect Task";
  }

  protected void doExecute(GlobalSubsystemManager manager, CmdbResponse response) throws CmdbException {
    monitorCommandExecute((MonitorsCollectorsManager)manager, response);
  }
}