package com.mercury.topaz.cmdb.server.monitors.metadata;

public abstract interface CmdbMultiThresholdMonitorMetaData extends CmdbMonitorMetaData
{
  public abstract double getWarningLevel(Object paramObject);

  public abstract double getErrorLevel(Object paramObject);
}