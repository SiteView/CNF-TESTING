package com.mercury.topaz.cmdb.server.monitors.metadata;

import java.io.Serializable;

public abstract interface CmdbMonitorMetaData extends Serializable
{
}