package com.mercury.topaz.cmdb.server.monitors.operation.update.impl;

import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsQueryManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class MonitorsUpdateInfoOperation extends AbstractMonitorsUpdateOperation
{
  private CmdbMonitorInfo _monitorInfo = null;

  public MonitorsUpdateInfoOperation(CmdbMonitorInfo monitorInfo)
  {
    setMonitorInfo(monitorInfo);
  }

  public String getOperationName() {
    return "Monitor Update - Update the monitor info of different monitors in the system";
  }

  public String getExecutionTaskQueueName()
  {
    return "Monitors Query Task";
  }

  public void monitorUpdateExecute(MonitorsQueryManager manager, CmdbResponse response) {
    manager.setMonitorInfo(getMonitorInfo());
  }

  CmdbMonitorInfo getMonitorInfo() {
    return this._monitorInfo;
  }

  private void setMonitorInfo(CmdbMonitorInfo monitorInfo) {
    if (monitorInfo == null)
      throw new IllegalArgumentException("Monitor info is null !!!");

    this._monitorInfo = monitorInfo;
  }

  public String getServiceName() {
    return "Framework service";
  }
}