package com.mercury.topaz.cmdb.server.monitors.metadata;

public abstract interface CmdbThresholdMonitorMetaData extends CmdbMonitorMetaData
{
  public abstract double getWarningLevel();

  public abstract double getErrorLevel();
}