package com.mercury.topaz.cmdb.server.monitors.manager;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.server.monitors.CmdbMonitor;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfoWrapper;
import java.util.Map;

public abstract interface MonitorsQueryManager extends GlobalSubsystemManager
{
  public abstract void setMonitorInfo(CmdbMonitorInfo paramCmdbMonitorInfo);

  public abstract CmdbMonitor getMonitor(String paramString);

  public abstract void addMonitorsInfo(Map<String, CmdbMonitorInfoWrapper> paramMap);

  public abstract void addMonitors(Map<String, CmdbMonitor> paramMap);
}