package com.mercury.topaz.cmdb.server.monitors.info.impl;

import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfoWrapper;

class CmdbMonitorInfoWrapperImpl
  implements CmdbMonitorInfoWrapper
{
  private CmdbMonitorInfo _monitorInfo;

  CmdbMonitorInfoWrapperImpl(CmdbMonitorInfo monitorInfo)
  {
    setMonitorInfo(monitorInfo); }

  public CmdbMonitorInfo getMonitorInfo() {
    return this._monitorInfo;
  }

  public void setMonitorInfo(CmdbMonitorInfo monitorInfo) {
    this._monitorInfo = monitorInfo;
  }
}