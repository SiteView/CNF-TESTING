package com.mercury.topaz.cmdb.server.monitors.manager;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.server.monitors.collectors.MonitorCollector;
import java.util.List;

public abstract interface MonitorsCollectorsManager extends GlobalSubsystemManager
{
  public abstract List<MonitorCollector> getCollectors();

  public abstract void addCollectors(List<MonitorCollector> paramList);
}