package com.mercury.topaz.cmdb.server.monitors.impl;

import com.mercury.topaz.cmdb.server.monitors.CmdbMonitor;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfoWrapper;
import com.mercury.topaz.cmdb.server.monitors.metadata.CmdbMonitorMetaData;

public class CmdbMonitorFactory
{
  public static CmdbMonitor createMonitor(String monitorName, CmdbMonitorInfoWrapper monitorInfoWrapper, CmdbMonitorMetaData monitorMetaData)
  {
    return new CmdbMonitorImpl(monitorName, monitorInfoWrapper, monitorMetaData);
  }
}