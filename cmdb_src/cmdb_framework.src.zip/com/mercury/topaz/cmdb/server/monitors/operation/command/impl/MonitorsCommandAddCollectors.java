package com.mercury.topaz.cmdb.server.monitors.operation.command.impl;

import com.mercury.topaz.cmdb.server.monitors.collectors.MonitorCollector;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsCollectorsManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.List;

public class MonitorsCommandAddCollectors extends AbstractMonitorsCommandOperation
{
  private List<MonitorCollector> _monitorCollectors;

  public String getOperationName()
  {
    return "MonitorsCommandAddCollectors";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public MonitorsCommandAddCollectors(List<MonitorCollector> monitorCollectors) {
    this._monitorCollectors = monitorCollectors;
  }

  public void monitorCommandExecute(MonitorsCollectorsManager monitorManager, CmdbResponse response) {
    monitorManager.addCollectors(this._monitorCollectors);
  }
}