package com.mercury.topaz.cmdb.server.monitors.info;

import java.io.Serializable;

public abstract interface CmdbMonitorInfo extends Serializable
{
  public abstract String getMonitorInfoName();
}