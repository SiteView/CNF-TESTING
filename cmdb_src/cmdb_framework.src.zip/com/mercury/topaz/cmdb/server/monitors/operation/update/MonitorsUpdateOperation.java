package com.mercury.topaz.cmdb.server.monitors.operation.update;

import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsQueryManager;
import com.mercury.topaz.cmdb.server.monitors.operation.MonitorsOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract interface MonitorsUpdateOperation extends MonitorsOperation
{
  public abstract void monitorUpdateExecute(MonitorsQueryManager paramMonitorsQueryManager, CmdbResponse paramCmdbResponse);
}