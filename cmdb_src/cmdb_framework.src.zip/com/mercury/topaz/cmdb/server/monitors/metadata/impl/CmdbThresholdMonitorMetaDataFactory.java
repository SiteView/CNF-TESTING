package com.mercury.topaz.cmdb.server.monitors.metadata.impl;

import com.mercury.topaz.cmdb.server.monitors.metadata.CmdbThresholdMonitorMetaData;

public class CmdbThresholdMonitorMetaDataFactory
{
  public static CmdbThresholdMonitorMetaData create(double warningLevel, double errorLevel)
  {
    return new ThresholdMonitorMetaDataImpl(warningLevel, errorLevel);
  }
}