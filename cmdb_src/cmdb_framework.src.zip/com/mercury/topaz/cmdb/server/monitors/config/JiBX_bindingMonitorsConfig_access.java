package com.mercury.topaz.cmdb.server.monitors.config;

import org.jibx.runtime.IMarshaller;
import org.jibx.runtime.IUnmarshaller;

public class JiBX_bindingMonitorsConfig_access
  implements IUnmarshaller, IMarshaller
{
}