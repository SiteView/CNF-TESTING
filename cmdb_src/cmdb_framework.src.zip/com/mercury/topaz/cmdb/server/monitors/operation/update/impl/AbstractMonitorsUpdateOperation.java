package com.mercury.topaz.cmdb.server.monitors.operation.update.impl;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsQueryManager;
import com.mercury.topaz.cmdb.server.monitors.operation.impl.AbstractMonitorsOperation;
import com.mercury.topaz.cmdb.server.monitors.operation.update.MonitorsUpdateOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractMonitorsUpdateOperation extends AbstractMonitorsOperation
  implements MonitorsUpdateOperation
{
  protected void doExecute(GlobalSubsystemManager manager, CmdbResponse response)
    throws CmdbException
  {
    monitorUpdateExecute((MonitorsQueryManager)manager, response);
  }
}