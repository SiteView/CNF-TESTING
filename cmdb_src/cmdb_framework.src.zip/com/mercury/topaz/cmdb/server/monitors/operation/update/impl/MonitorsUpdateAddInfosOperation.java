package com.mercury.topaz.cmdb.server.monitors.operation.update.impl;

import com.mercury.topaz.cmdb.server.monitors.CmdbMonitor;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfoWrapper;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsQueryManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.Map;

public class MonitorsUpdateAddInfosOperation extends AbstractMonitorsUpdateOperation
{
  Map<String, CmdbMonitorInfoWrapper> _monitorsInfo;
  Map<String, CmdbMonitor> _monitors;

  public MonitorsUpdateAddInfosOperation(Map<String, CmdbMonitorInfoWrapper> monitorsInfo, Map<String, CmdbMonitor> monitors)
  {
    this._monitorsInfo = monitorsInfo;
    this._monitors = monitors;
  }

  public String getOperationName() {
    return "Monitor Update - Update the monitors info of different monitors in the system";
  }

  public String getExecutionTaskQueueName() {
    return "Monitors Query Task";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public void monitorUpdateExecute(MonitorsQueryManager manager, CmdbResponse response) {
    manager.addMonitorsInfo(this._monitorsInfo);
    manager.addMonitors(this._monitors);
  }
}