package com.mercury.topaz.cmdb.server.monitors.config;

class MonitorConfig
{
  private String name;
  private String controllerServiceName;

  String getName()
  {
    return this.name;
  }

  String getControllerServiceName() {
    return this.controllerServiceName;
  }
}