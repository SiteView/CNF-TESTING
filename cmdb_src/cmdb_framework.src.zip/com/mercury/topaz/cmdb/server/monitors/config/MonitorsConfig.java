package com.mercury.topaz.cmdb.server.monitors.config;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.shared.util.JibxFileMatcher;
import com.mercury.topaz.cmdb.shared.util.filesystem.traverse.FilesTraverse;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class MonitorsConfig
  implements IUnmarshallable, IMarshallable
{
  private static final String CONFIG_FILE_NAME = "monitors.xml";
  private static MonitorsConfig instance = null;
  private Map<String, String> monitorsConfig = new HashMap(16);
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.server.manage.service.config.impl.JiBX_bindingFactory|";

  public static MonitorsConfig instance()
  {
    synchronized (MonitorsConfig.class) {
      if (instance == null)
        instance = loadConfig();
    }

    return instance;
  }

  private static MonitorsConfig loadConfig()
  {
    JibxFileMatcher matcher = new JibxFileMatcher()
    {
      public boolean match(String fileName) {
        return fileName.endsWith("monitors.xml");
      }

      public Class<MonitorsConfig> getResultClass() {
        return MonitorsConfig.class;
      }

    };
    return ((MonitorsConfig)FilesTraverse.findAndHandle(getConfigFolder(), matcher));
  }

  private static String getConfigFolder() {
    return Framework.getInstance().getGlobalSettings().getTopazHome() + File.separator + "cmdb/services";
  }

  public String getControllerServiceName(String monitorName) {
    return ((String)this.monitorsConfig.get(monitorName));
  }

  private void addMonitorConfig(Object obj)
  {
    if ((obj == null) || (!(obj instanceof MonitorConfig))) {
      throw new IllegalArgumentException("Argument is either null or not an instance of " + MonitorConfig.class);
    }

    MonitorConfig config = (MonitorConfig)obj;
    this.monitorsConfig.put(config.getName(), config.getControllerServiceName());
  }

  private Iterator<Map.Entry<String, String>> iterator()
  {
    return this.monitorsConfig.entrySet().iterator();
  }
}