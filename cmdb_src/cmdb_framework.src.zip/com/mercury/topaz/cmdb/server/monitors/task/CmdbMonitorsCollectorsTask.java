package com.mercury.topaz.cmdb.server.monitors.task;

public class CmdbMonitorsCollectorsTask
{
  public static final String NAME = "Monitors Collect Task";
}