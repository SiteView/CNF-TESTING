package com.mercury.topaz.cmdb.server.monitors.operation.query.impl;

import com.mercury.topaz.cmdb.server.monitors.CmdbMonitor;
import com.mercury.topaz.cmdb.server.monitors.config.MonitorsConfig;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsQueryManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.AbstractOpDestinationResolver;
import com.mercury.topaz.cmdb.shared.manage.operation.OpDestinationResolver;
import com.mercury.topaz.cmdb.shared.manage.operation.ServerAndCategoryOperation;

public class MonitorsQueryReadMonitorOperation extends AbstractMonitorsQueryOperation
  implements ServerAndCategoryOperation
{
  private CmdbMonitor _monitor;
  private String _monitorName;
  private OpDestinationResolver destinationResolver;

  public MonitorsQueryReadMonitorOperation(String monitorName)
  {
    setMonitorName(monitorName);
    this.destinationResolver = new AbstractOpDestinationResolver(this)
    {
      protected String doResolve() {
        return MonitorsConfig.instance().getControllerServiceName(this.this$0.getMonitorName());
      }
    };
  }

  public String getOperationName() {
    return "Monitor Query - Read the requested monitor";
  }

  public String getExecutionTaskQueueName()
  {
    return "Monitors Query Task";
  }

  public void monitorQueryExecute(MonitorsQueryManager manager, CmdbResponse response) {
    setMonitor(manager.getMonitor(getMonitorName()));
    response.addResult("monitorResult", getMonitor());
  }

  public void updateWithResponse(CmdbResponse response) {
    setMonitor((CmdbMonitor)response.getResult("monitorResult"));
  }

  public CmdbMonitor getMonitor() {
    return this._monitor;
  }

  private void setMonitor(CmdbMonitor monitor) {
    if (monitor == null)
      throw new IllegalArgumentException("monitor is null !!!");

    this._monitor = monitor;
  }

  public String getMonitorName() {
    return this._monitorName;
  }

  public void setMonitorName(String monitorName) {
    this._monitorName = monitorName;
  }

  public void resolveServiceName() {
    this.destinationResolver.resolveServiceName();
  }

  public String getServiceName() {
    return this.destinationResolver.getServiceName();
  }

  public boolean needsResolving() {
    return this.destinationResolver.needsResolving();
  }
}