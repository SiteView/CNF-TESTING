package com.mercury.topaz.cmdb.server.monitors.metadata.impl;

import com.mercury.topaz.cmdb.server.monitors.metadata.CmdbThresholdMonitorMetaData;

class ThresholdMonitorMetaDataImpl
  implements CmdbThresholdMonitorMetaData
{
  double _warningLevel;
  double _errorLevel;

  public ThresholdMonitorMetaDataImpl(double warningLevel, double errorLevel)
  {
    setWarningLevel(warningLevel);
    setErroLevel(errorLevel);
  }

  public double getWarningLevel() {
    return this._warningLevel;
  }

  public double getErrorLevel() {
    return this._errorLevel;
  }

  private void setWarningLevel(double warningLevel) {
    this._warningLevel = warningLevel;
  }

  private void setErroLevel(double errorLevel) {
    this._errorLevel = errorLevel;
  }
}