package com.mercury.topaz.cmdb.server.monitors.impl;

import com.mercury.topaz.cmdb.server.monitors.CmdbMonitor;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfoWrapper;
import com.mercury.topaz.cmdb.server.monitors.metadata.CmdbMonitorMetaData;

class CmdbMonitorImpl
  implements CmdbMonitor
{
  private CmdbMonitorInfoWrapper _monitorInfoWrapper;
  private CmdbMonitorMetaData _monitorMetadata;

  public CmdbMonitorImpl(String monitorName, CmdbMonitorInfoWrapper monitorInfoWrapper, CmdbMonitorMetaData monitorMetaData)
  {
    setMonitorInfoWrapper(monitorInfoWrapper);
    setMoitorMetadata(monitorMetaData);
  }

  public CmdbMonitorInfo getMonitorInfo() {
    return this._monitorInfoWrapper.getMonitorInfo();
  }

  public CmdbMonitorMetaData getMonitorMetaData() {
    return this._monitorMetadata;
  }

  private void setMoitorMetadata(CmdbMonitorMetaData moitorMetadata) {
    this._monitorMetadata = moitorMetadata;
  }

  private void setMonitorInfoWrapper(CmdbMonitorInfoWrapper monitorInfoWrapper) {
    this._monitorInfoWrapper = monitorInfoWrapper;
  }
}