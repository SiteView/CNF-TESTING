package com.mercury.topaz.cmdb.server.monitors.operation.command.impl;

import com.mercury.topaz.cmdb.server.monitors.collectors.MonitorCollector;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsCollectorsManager;
import com.mercury.topaz.cmdb.server.monitors.operation.update.impl.MonitorsUpdateInfoOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.Iterator;
import java.util.List;

public class MonitorsCommandCollectInfo extends AbstractMonitorsCommandOperation
{
  public String getOperationName()
  {
    return "monitors collect info";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public void monitorCommandExecute(MonitorsCollectorsManager monitorManager, CmdbResponse response)
  {
    List collectors = monitorManager.getCollectors();

    for (Iterator i$ = collectors.iterator(); i$.hasNext(); ) { MonitorCollector collector = (MonitorCollector)i$.next();
      CmdbMonitorInfo monitorInfo = collector.collect(monitorManager);
      MonitorsUpdateInfoOperation monitorUpdateInfo = new MonitorsUpdateInfoOperation(monitorInfo);
      monitorManager.executeGlobalOperation(monitorUpdateInfo);
    }
  }
}