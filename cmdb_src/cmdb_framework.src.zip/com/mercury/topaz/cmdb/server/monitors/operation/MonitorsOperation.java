package com.mercury.topaz.cmdb.server.monitors.operation;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkGlobalOperation;

public abstract interface MonitorsOperation extends FrameworkGlobalOperation
{
}