package com.mercury.topaz.cmdb.server.monitors.collectors;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;

public abstract interface MonitorCollector
{
  public abstract CmdbMonitorInfo collect(GlobalSubsystemManager paramGlobalSubsystemManager);
}