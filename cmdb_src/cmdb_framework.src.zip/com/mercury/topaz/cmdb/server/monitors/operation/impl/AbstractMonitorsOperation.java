package com.mercury.topaz.cmdb.server.monitors.operation.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.monitors.operation.MonitorsOperation;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractFrameworkGlobalOperation;

public abstract class AbstractMonitorsOperation extends AbstractFrameworkGlobalOperation
  implements MonitorsOperation
{
  protected static Log _logger = CmdbLogFactory.getMonitorLog();

  public String getExecutionTaskQueueName()
  {
    return "Monitors Query Task";
  }
}