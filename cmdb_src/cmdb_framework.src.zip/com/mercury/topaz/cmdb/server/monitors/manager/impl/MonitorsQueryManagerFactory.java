package com.mercury.topaz.cmdb.server.monitors.manager.impl;

import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsQueryManager;

public class MonitorsQueryManagerFactory
{
  public static MonitorsQueryManager create(GlobalEnvironment globalEnvironment)
  {
    return new MonitorsQueryManagerImpl(globalEnvironment);
  }
}