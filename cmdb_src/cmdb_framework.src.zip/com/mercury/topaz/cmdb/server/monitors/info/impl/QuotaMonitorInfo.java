package com.mercury.topaz.cmdb.server.monitors.info.impl;

import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class QuotaMonitorInfo extends AbstractCmdbMonitorInfo
{
  public static final String MONITOR_INFO_NAME = "QuotaMonitorInfo";
  private Map<String, QuotaCount> _serversQuotasAndCounts;
  private Map<CmdbCustomerID, CustomerQuotasAndCounts> _customersQuotasAndCounts;

  public QuotaMonitorInfo()
  {
    setServersQuotasAndCounts(new HashMap());
    setCustomersQuotasAndCounts(new HashMap());
  }

  public QuotaMonitorInfo(Map<String, QuotaCount> serversQuotasAndCounts, Map<CmdbCustomerID, CustomerQuotasAndCounts> customersQuotasAndCounts)
  {
    for (Iterator itr = serversQuotasAndCounts.keySet().iterator(); itr.hasNext(); ) {
      String quotaName = (String)itr.next();
      getServersQuotasAndCounts().put(quotaName, ((QuotaCount)serversQuotasAndCounts.get(quotaName)).getClone());
    }
    for (itr = customersQuotasAndCounts.keySet().iterator(); itr.hasNext(); ) {
      CmdbCustomerID customerID = (CmdbCustomerID)itr.next();
      getCustomersQuotasAndCounts().put(customerID, ((CustomerQuotasAndCounts)customersQuotasAndCounts.get(customerID)).getClone());
    }
  }

  public Map<CmdbCustomerID, CustomerQuotasAndCounts> getCustomersQuotasAndCountsClone()
  {
    Map customersQuotasAndCountsClone = new HashMap(getCustomersQuotasAndCounts().size());
    Set customerIDs = getCustomersQuotasAndCounts().keySet();
    for (Iterator itr = customerIDs.iterator(); itr.hasNext(); ) {
      CmdbCustomerID customerID = (CmdbCustomerID)itr.next();
      CustomerQuotasAndCounts customerQuotasAndCounts = (CustomerQuotasAndCounts)getCustomersQuotasAndCounts().get(customerID);
      customersQuotasAndCountsClone.put(customerID, customerQuotasAndCounts.getClone());
    }
    return customersQuotasAndCountsClone;
  }

  public Map<String, QuotaCount> getServerQuotasAndCountsClone() {
    Map serverQuotasAndCountsClone = new HashMap(getServersQuotasAndCounts().size());
    Set quotaNames = getServersQuotasAndCounts().keySet();
    for (Iterator itr = quotaNames.iterator(); itr.hasNext(); ) {
      String quotaName = (String)itr.next();
      QuotaCount quotaCount = getServerQuotaCount(quotaName);
      serverQuotasAndCountsClone.put(quotaName, quotaCount.getClone());
    }
    return serverQuotasAndCountsClone;
  }

  public String getMonitorInfoName()
  {
    return "QuotaMonitorInfo";
  }

  private Map<String, QuotaCount> getServersQuotasAndCounts()
  {
    return this._serversQuotasAndCounts;
  }

  private void setServersQuotasAndCounts(Map<String, QuotaCount> serversQuotasAndCounts) {
    this._serversQuotasAndCounts = serversQuotasAndCounts;
  }

  private Map<CmdbCustomerID, CustomerQuotasAndCounts> getCustomersQuotasAndCounts() {
    return this._customersQuotasAndCounts;
  }

  private void setCustomersQuotasAndCounts(Map<CmdbCustomerID, CustomerQuotasAndCounts> customersQuotasAndCounts) {
    this._customersQuotasAndCounts = customersQuotasAndCounts;
  }

  private QuotaCount getServerQuotaCount(String quotaName)
  {
    QuotaCount serverQuotaCount = (QuotaCount)getServersQuotasAndCounts().get(quotaName);
    if (serverQuotaCount == null)
      throw new CmdbException("quota with name [" + quotaName + "] is not defined for server !!!");

    return serverQuotaCount;
  }
}