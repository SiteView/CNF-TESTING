package com.mercury.topaz.cmdb.server.monitors.operation.query;

import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsQueryManager;
import com.mercury.topaz.cmdb.server.monitors.operation.MonitorsOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract interface MonitorsQueryOperation extends MonitorsOperation
{
  public abstract void monitorQueryExecute(MonitorsQueryManager paramMonitorsQueryManager, CmdbResponse paramCmdbResponse);
}