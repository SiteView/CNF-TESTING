package com.mercury.topaz.cmdb.server.monitors.info.impl;

import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;

public class CmdbMonitorInfoWrapperFactory
{
  public static CmdbMonitorInfoWrapperImpl create(CmdbMonitorInfo monitorInfo)
  {
    return new CmdbMonitorInfoWrapperImpl(monitorInfo);
  }
}