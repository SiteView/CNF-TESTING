package com.mercury.topaz.cmdb.server.monitors.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractGlobalSubsystemManager;
import com.mercury.topaz.cmdb.server.monitors.collectors.MonitorCollector;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsCollectorsManager;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import java.util.ArrayList;
import java.util.List;

class MonitorsCollectorsManagerImpl extends AbstractGlobalSubsystemManager
  implements MonitorsCollectorsManager, SingleReadSingleWrite
{
  final List<MonitorCollector> _collectors = new ArrayList();

  public MonitorsCollectorsManagerImpl(GlobalEnvironment globalEnvironment)
  {
    super(globalEnvironment);
    Framework.getInstance().setLock(this);
  }

  public void startUp()
  {
    CmdbLogFactory.getCMDBInfoLog().info("Monitors Collectors Manager is started up properly !!!");
  }

  public void shutdown()
  {
    CmdbLogFactory.getCMDBInfoLog().info("Monitors Collectors Manager is shutdown properly !!!");
  }

  public List<MonitorCollector> getCollectors() {
    return this._collectors;
  }

  public void addCollectors(List<MonitorCollector> collectors) {
    this._collectors.addAll(collectors);
  }

  public String getName() {
    return "Monitors Collect Task";
  }
}