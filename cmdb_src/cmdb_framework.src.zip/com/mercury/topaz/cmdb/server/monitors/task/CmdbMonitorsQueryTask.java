package com.mercury.topaz.cmdb.server.monitors.task;

public class CmdbMonitorsQueryTask
{
  public static final String NAME = "Monitors Query Task";
}