package com.mercury.topaz.cmdb.server.monitors.operation.command;

import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsCollectorsManager;
import com.mercury.topaz.cmdb.server.monitors.operation.MonitorsOperation;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract interface MonitorsCommandOperation extends MonitorsOperation
{
  public abstract void monitorCommandExecute(MonitorsCollectorsManager paramMonitorsCollectorsManager, CmdbResponse paramCmdbResponse);
}