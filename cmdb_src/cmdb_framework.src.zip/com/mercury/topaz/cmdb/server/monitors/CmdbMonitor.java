package com.mercury.topaz.cmdb.server.monitors;

import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.metadata.CmdbMonitorMetaData;
import java.io.Serializable;

public abstract interface CmdbMonitor extends Serializable
{
  public static final String MONITOR_RESULT = "monitorResult";

  public abstract CmdbMonitorInfo getMonitorInfo();

  public abstract CmdbMonitorMetaData getMonitorMetaData();
}