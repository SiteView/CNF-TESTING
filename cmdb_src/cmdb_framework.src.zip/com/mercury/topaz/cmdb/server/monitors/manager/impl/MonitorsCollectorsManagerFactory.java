package com.mercury.topaz.cmdb.server.monitors.manager.impl;

import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsCollectorsManager;

public class MonitorsCollectorsManagerFactory
{
  public static MonitorsCollectorsManager create(GlobalEnvironment globalEnvironment)
  {
    return new MonitorsCollectorsManagerImpl(globalEnvironment);
  }
}