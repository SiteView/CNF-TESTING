package com.mercury.topaz.cmdb.server.monitors.info.impl;

import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;

public abstract class AbstractCmdbMonitorInfo
  implements CmdbMonitorInfo
{
  public int hashCode()
  {
    return getMonitorInfoName().hashCode();
  }

  public boolean equals(Object obj)
  {
    if ((obj == null) || (!(obj instanceof CmdbMonitorInfo)))
      return false;

    return getMonitorInfoName().equals(((CmdbMonitorInfo)obj).getMonitorInfoName());
  }
}