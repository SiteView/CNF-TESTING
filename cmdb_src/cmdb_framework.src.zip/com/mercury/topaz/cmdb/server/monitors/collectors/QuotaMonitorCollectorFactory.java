package com.mercury.topaz.cmdb.server.monitors.collectors;

public class QuotaMonitorCollectorFactory
{
  public static QuotaMonitorCollector create()
  {
    return new QuotaMonitorCollector();
  }
}