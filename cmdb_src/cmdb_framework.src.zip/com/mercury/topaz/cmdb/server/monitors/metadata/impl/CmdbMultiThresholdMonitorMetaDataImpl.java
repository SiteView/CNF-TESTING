package com.mercury.topaz.cmdb.server.monitors.metadata.impl;

import com.mercury.topaz.cmdb.server.monitors.metadata.CmdbMultiThresholdMonitorMetaData;
import java.util.Map;

class CmdbMultiThresholdMonitorMetaDataImpl
  implements CmdbMultiThresholdMonitorMetaData
{
  Map<Object, Double> _warningLevels;
  Map<Object, Double> _errorLevels;

  public double getWarningLevel(Object key)
  {
    return ((Double)getWarningLevels().get(key)).doubleValue();
  }

  public double getErrorLevel(Object key) {
    return ((Double)getErrorLevels().get(key)).doubleValue();
  }

  public CmdbMultiThresholdMonitorMetaDataImpl(Map<Object, Double> warningLevels, Map<Object, Double> errorLevels)
  {
    setWarningLevels(warningLevels);
    setErroLevels(errorLevels);
  }

  public void addWarningLevel(Object key, double warningLevel)
  {
    this._warningLevels.put(key, Double.valueOf(warningLevel));
  }

  public void addErrorLevel(Object key, double errorLevel) {
    this._errorLevels.put(key, Double.valueOf(errorLevel));
  }

  private Map<Object, Double> getWarningLevels() {
    return this._warningLevels;
  }

  private Map<Object, Double> getErrorLevels() {
    return this._errorLevels;
  }

  private void setWarningLevels(Map levels) {
    this._warningLevels = levels;
  }

  private void setErroLevels(Map levels) {
    this._errorLevels = levels;
  }
}