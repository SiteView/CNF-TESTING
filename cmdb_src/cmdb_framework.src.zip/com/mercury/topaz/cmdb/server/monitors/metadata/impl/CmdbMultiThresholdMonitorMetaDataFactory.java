package com.mercury.topaz.cmdb.server.monitors.metadata.impl;

import com.mercury.topaz.cmdb.server.monitors.metadata.CmdbMultiThresholdMonitorMetaData;
import java.util.Map;

public class CmdbMultiThresholdMonitorMetaDataFactory
{
  public static CmdbMultiThresholdMonitorMetaData create(Map<Object, Double> warningLevels, Map<Object, Double> errorLevels)
  {
    return new CmdbMultiThresholdMonitorMetaDataImpl(warningLevels, errorLevels);
  }
}