package com.mercury.topaz.cmdb.server.monitors.info;

import java.io.Serializable;

public abstract interface CmdbMonitorInfoWrapper extends Serializable
{
  public abstract CmdbMonitorInfo getMonitorInfo();

  public abstract void setMonitorInfo(CmdbMonitorInfo paramCmdbMonitorInfo);
}