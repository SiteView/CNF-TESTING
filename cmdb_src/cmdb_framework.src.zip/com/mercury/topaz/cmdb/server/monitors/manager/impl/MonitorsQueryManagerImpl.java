package com.mercury.topaz.cmdb.server.monitors.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractGlobalSubsystemManager;
import com.mercury.topaz.cmdb.server.monitors.CmdbMonitor;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfo;
import com.mercury.topaz.cmdb.server.monitors.info.CmdbMonitorInfoWrapper;
import com.mercury.topaz.cmdb.server.monitors.manager.MonitorsQueryManager;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import java.util.HashMap;
import java.util.Map;

class MonitorsQueryManagerImpl extends AbstractGlobalSubsystemManager
  implements MonitorsQueryManager, MultiReadSingleWrite
{
  private final Map<String, CmdbMonitorInfoWrapper> _monitorsInfo = new HashMap();
  private final Map<String, CmdbMonitor> _monitors = new HashMap();

  public MonitorsQueryManagerImpl(GlobalEnvironment globalEnvironment)
  {
    super(globalEnvironment);

    Framework.getInstance().setLock(this, 1);
  }

  public void startUp()
  {
    CmdbLogFactory.getCMDBInfoLog().info("Monitors Query Manager is started up properly !!!");
  }

  public void shutdown() {
    CmdbLogFactory.getCMDBInfoLog().info("Monitors Collectors Manager is shutdown properly !!!");
  }

  public void setMonitorInfo(CmdbMonitorInfo monitorInfo) {
    if (monitorInfo == null)
      throw new IllegalArgumentException("monitor info is null !!!");

    ((CmdbMonitorInfoWrapper)getAllMonitorsInfo().get(monitorInfo.getMonitorInfoName())).setMonitorInfo(monitorInfo);
  }

  private Map<String, CmdbMonitorInfoWrapper> getAllMonitorsInfo()
  {
    return this._monitorsInfo;
  }

  private Map<String, CmdbMonitor> getAllMonitors() {
    return this._monitors;
  }

  public CmdbMonitor getMonitor(String monitorName) {
    return ((CmdbMonitor)getAllMonitors().get(monitorName));
  }

  public void addMonitorsInfo(Map<String, CmdbMonitorInfoWrapper> monitorsInfo) {
    this._monitorsInfo.putAll(monitorsInfo);
  }

  public void addMonitors(Map<String, CmdbMonitor> monitors) {
    this._monitors.putAll(monitors);
  }

  public String getName() {
    return "Monitors Query Task";
  }
}