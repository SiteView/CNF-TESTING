package com.mercury.topaz.cmdb.server.manage.lock.operation.update;

import com.mercury.topaz.cmdb.server.manage.lock.DataForLock;
import com.mercury.topaz.cmdb.server.manage.lock.DataLockManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractDataLockSwitch extends AbstractDataLockAction
{
  private DataForLock _dataForRelease;

  public AbstractDataLockSwitch(DataForLock dataForRelease, DataForLock dataForLock)
  {
    super(dataForLock);
    this._dataForRelease = dataForRelease;
  }

  public final void executeDataLock(DataLockManager dataLockManager, CmdbResponse response) throws CmdbException {
    dataLockManager.switchLock(this._dataForRelease, getDataForLock());
  }

  public DataForLock getDataForRelease() {
    return this._dataForRelease;
  }
}