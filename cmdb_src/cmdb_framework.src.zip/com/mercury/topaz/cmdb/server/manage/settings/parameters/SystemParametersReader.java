package com.mercury.topaz.cmdb.server.manage.settings.parameters;

import com.mercury.infra.setting.SettingServiceAPI;
import com.mercury.infra.setting.SettingsFactory;
import com.mercury.infra.setting.utils.SettingException;
import com.mercury.infra.utils.environment.Environment;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Global;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class SystemParametersReader
  implements SettingsReader
{
  private static final Log log = LogFactory.getEasyLog(SystemParametersReader.class.getName());
  private static final SettingServiceAPI SETTING_SERVICE_API = SettingsFactory.create();
  private final int customerID;
  private final Map<String, String> contextsMap = new HashMap();

  public SystemParametersReader(int customerID)
  {
    this.customerID = customerID;
    buildContextsMap();
  }

  private void buildContextsMap() {
    Collection contexts;
    try {
      contexts = SETTING_SERVICE_API.getContextNames();
      for (Iterator i$ = contexts.iterator(); i$.hasNext(); ) { String context = (String)i$.next();

        Collection names = SETTING_SERVICE_API.getSettingNames(context);
        for (Iterator i$ = names.iterator(); i$.hasNext(); ) { String name = (String)i$.next();
          this.contextsMap.put(name, context);
        }
      }
    } catch (Exception e) {
      log.error("Error in settings API", e);
    }
  }

  private static Map<String, String> serverApiGlobalSettings(String context)
    throws RemoteException, SettingException
  {
    return SETTING_SERVICE_API.getGlobalSettings(context);
  }

  private static Map<String, String> serverApiCustomerSettings(String context, int customerID)
    throws RemoteException, SettingException
  {
    return SETTING_SERVICE_API.getCustomerSettings(context, customerID);
  }

  public String getTopazHome()
  {
    return Environment.getInstance().getEnvironmentHomePath();
  }

  public int getInt(String paramName, int defaultValue)
  {
    String val = getStringValue(paramName);
    if (val != null)
      try {
        return Integer.parseInt(val);
      } catch (NumberFormatException ex) {
        log.error("SystemParametersReader: NumberFormatException. int property [" + paramName + "]. use default [" + defaultValue + "]");
        return defaultValue;
      }

    log.warn("SystemParametersReader: int property not found [" + paramName + "]. use default [" + defaultValue + "]");
    return defaultValue;
  }

  public long getLong(String paramName, long defaultValue)
  {
    String val = getStringValue(paramName);
    if (val != null)
      try {
        return Long.parseLong(val);
      } catch (NumberFormatException ex) {
        log.error("SystemParametersReader: NumberFormatException. long property [" + paramName + "]. use default [" + defaultValue + "]");
        return defaultValue;
      }

    log.warn("SystemParametersReader: long property not found [" + paramName + "]. use default [" + defaultValue + "]");
    return defaultValue;
  }

  private String getStringValue(String paramName)
  {
    String context = (String)this.contextsMap.get(paramName);
    if (context == null)
      return null;

    return getStringValue(context, paramName);
  }

  private String getStringValue(String context, String paramName) {
    String value = null;
    try {
      if (!(isGlobal())) {
        value = SETTING_SERVICE_API.getVariablePerCustomer(context, paramName, this.customerID);
        if (value != null)
          return value;
      }

      value = SETTING_SERVICE_API.getGlobalVariable(context, paramName);
    } catch (Exception e) {
      log.error("Error reading setting [" + paramName + "], context [" + context + "]", e);
    }
    return value;
  }

  private boolean isGlobal() {
    return (FrameworkConstants.Customer.Global.ID.getID() == this.customerID);
  }

  public float getFloat(String paramName, float defaultValue)
  {
    String val = getStringValue(paramName);
    if (val != null)
      try {
        return Float.parseFloat(val);
      } catch (NumberFormatException ex) {
        log.error("SystemParametersReader: NumberFormatException. float property [" + paramName + "]. use default [" + defaultValue + "]");
        return defaultValue;
      }

    log.warn("SystemParametersReader: float property not found [" + paramName + "]. use default [" + defaultValue + "]");
    return defaultValue;
  }

  public boolean getBoolean(String paramName, boolean defaultValue)
  {
    String booleanAsString = getProperty(paramName);

    if (booleanAsString == null) {
      log.warn("SystemParametersReader: boolean property not found [" + paramName + "]. use default [" + defaultValue + "]");
      return defaultValue;
    }

    if ((booleanAsString.equalsIgnoreCase("true")) || (booleanAsString.equalsIgnoreCase("t")))
      return true;
    if ((booleanAsString.equalsIgnoreCase("false")) || (booleanAsString.equalsIgnoreCase("f")))
      return false;

    log.error("parameter [ " + paramName + " ] gets value" + "[" + booleanAsString + "] that not suitable for Boolean format");
    return defaultValue;
  }

  public String getString(String paramName, String defaultValue)
  {
    String value = getProperty(paramName);
    if (value == null) {
      log.warn("SystemParametersReader: string property not found [" + paramName + "]. use default [" + defaultValue + "]");
      return defaultValue;
    }
    return value;
  }

  public boolean isExist(String paramName) {
    return (getProperty(paramName) != null);
  }

  public ReadOnlyIterator<String> getPropertyNames()
  {
    return new ReadOnlyIteratorImpl(asProperties().keySet().iterator());
  }

  public Properties asProperties() {
    Properties props = new Properties();
    for (Iterator i$ = this.contextsMap.values().iterator(); i$.hasNext(); ) { String context = (String)i$.next();
      try {
        props.putAll(serverApiGlobalSettings(context));
        if (!(isGlobal()))
          props.putAll(serverApiCustomerSettings(context, this.customerID));
      }
      catch (Exception e) {
        log.error("Error fetching all properties", e);
      }
    }
    return props;
  }

  private String getProperty(String paramName) {
    String parametrValue = getStringValue(paramName.trim());
    if (parametrValue == null) {
      if (log.isDebugEnabled())
        log.debug("parameter [" + paramName + "] doesn't exist");

      return null;
    }
    return parametrValue;
  }
}