package com.mercury.topaz.cmdb.server.manage.environment.subsystem.impl;

import com.mercury.topaz.cmdb.server.manage.environment.subsystem.CmdbSubsystemEnvironment;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import java.util.HashMap;
import java.util.Map;

public class CmdbSubsystemEnvironmentFactory
{
  public static Map<FrameworkConstants.Subsystem, CmdbSubsystemEnvironment> createSubsystemEnvironmentsMap()
  {
    Map subsystemEnvironmentsMap = new HashMap();

    subsystemEnvironmentsMap.put(FrameworkConstants.Subsystem.DAL, new DalCmdbSubsystemEnvironment(false));
    subsystemEnvironmentsMap.put(FrameworkConstants.Subsystem.CLASS_MODEL, new ClassModelCmdbSubsystemEnvironment(false));

    return subsystemEnvironmentsMap;
  }
}