package com.mercury.topaz.cmdb.server.manage.subsystem.observer;

public abstract interface SubsystemManagerLifecycleHandler
{
  public abstract void preStartup();

  public abstract void postStartup();
}