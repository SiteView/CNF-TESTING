package com.mercury.topaz.cmdb.server.manage.dal;

import java.util.Iterator;

public abstract interface CmdbDalCommandsContainer
{
  public abstract void addCommand(CmdbDalCommand paramCmdbDalCommand);

  public abstract Iterator<CmdbDalCommand> getCommandsIterator();
}