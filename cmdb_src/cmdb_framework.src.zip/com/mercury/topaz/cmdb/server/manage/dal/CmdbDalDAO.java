package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.db.pools.DBType;

public abstract interface CmdbDalDAO
{
  public abstract <T> CmdbDalCommandResult<T> executeQuery(CmdbDalCommand<T> paramCmdbDalCommand);

  public abstract void execute(CmdbDalCommand<Void> paramCmdbDalCommand);

  public abstract ConnectionPoolManager getConnectionsPoolManager();

  public abstract DBType getDBType();

  public abstract void execute(CmdbDalCommandsContainer paramCmdbDalCommandsContainer);
}