package com.mercury.topaz.cmdb.server.manage.service.config;

public abstract interface ServiceDependency
{
  public abstract String getDependencyName();
}