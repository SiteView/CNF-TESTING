package com.mercury.topaz.cmdb.server.manage.dal.jdbc_template;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;

public abstract interface RowHandler
{
  public abstract void processRow(CmdbDalResultSet paramCmdbDalResultSet)
    throws SQLException;
}