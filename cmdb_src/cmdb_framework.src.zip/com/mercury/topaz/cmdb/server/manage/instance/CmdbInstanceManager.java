package com.mercury.topaz.cmdb.server.manage.instance;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.customer.id.impl.CmdbCustomerIDsFactory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbCustomerNotExistException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class CmdbInstanceManager
  implements InstanceManager
{
  static Log _infoLogger = CmdbLogFactory.getCMDBInfoLog();
  private final Map<CmdbCustomerID, InstanceHolder> _instances;

  public CmdbInstanceManager()
  {
    this._instances = new HashMap(); }

  public synchronized CustomerInstance createInstanceForService(CmdbCustomerID customerID, String serviceName) {
    InstanceHolder instanceHolder = (InstanceHolder)getInstances().get(customerID);
    if (instanceHolder == null) {
      instanceHolder = createInstanceHolder(customerID);
      getInstances().put(customerID, instanceHolder);
      try {
        instanceHolder.getInstance().startUp();
      } catch (Throwable t) {
        _infoLogger.fatal("Couldn't startUp server instance, calling removeInstance.", t);
        getInstances().remove(customerID);
        throw new CmdbException(t);
      }
    }
    instanceHolder.addClient(serviceName);
    return instanceHolder.getInstance();
  }

  private InstanceHolder createInstanceHolder(CmdbCustomerID customerID) {
    CustomerInstance instance = createInstance(customerID);
    return new InstanceHolder(instance);
  }

  private CustomerInstance createInstance(CmdbCustomerID customerID) throws CmdbException {
    return new CustomerInstanceImpl(customerID);
  }

  public synchronized void destroyInstanceForService(CmdbCustomerID customerID, String serviceName) {
    InstanceHolder instanceHolder = (InstanceHolder)getInstances().get(customerID);
    if (instanceHolder == null)
      return;

    instanceHolder.getInstance().removeServiceInstance(serviceName);
    instanceHolder.removeClient(serviceName);
    if (!(InstanceHolder.access$000(instanceHolder))) {
      instanceHolder.getInstance().shutdown();
      getInstances().remove(customerID);
    }
  }

  public synchronized CustomerInstance getInstance(CmdbCustomerID customerID) {
    InstanceHolder instanceHolder = (InstanceHolder)getInstances().get(customerID);
    if (instanceHolder == null)
      throw new CmdbCustomerNotExistException("Asking for an instance [customerID=" + customerID + "] that doesn't exist", "N/A");

    return instanceHolder.getInstance();
  }

  public synchronized boolean hasInstanceForService(CmdbCustomerID customerID, String serviceName) {
    InstanceHolder instanceHolder = (InstanceHolder)getInstances().get(customerID);
    if (instanceHolder == null)
      return false;

    return instanceHolder.hasClient(serviceName);
  }

  public synchronized CmdbCustomerIDs getLoadedCustomerIDs(String serviceName) {
    CmdbCustomerIDs cmdbCustomerIDs = CmdbCustomerIDsFactory.createCustomerIDs();
    for (Iterator i$ = getInstances().entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
      InstanceHolder instanceHolder = (InstanceHolder)entry.getValue();
      CustomerInstance customerInstance = instanceHolder.getInstance();

      if (customerInstance.isServiceInstanceStartedUp(serviceName))
        cmdbCustomerIDs.addCustomerID((CmdbCustomerID)entry.getKey());
    }

    return cmdbCustomerIDs;
  }

  public synchronized CmdbCustomerIDs getLoadedCustomerIDs() {
    CmdbCustomerIDs cmdbCustomerIDs = CmdbCustomerIDsFactory.createCustomerIDs();
    for (Iterator i$ = getInstances().keySet().iterator(); i$.hasNext(); ) { CmdbCustomerID customerID = (CmdbCustomerID)i$.next();
      cmdbCustomerIDs.addCustomerID(customerID);
    }
    return cmdbCustomerIDs;
  }

  private Map<CmdbCustomerID, InstanceHolder> getInstances() {
    return this._instances;
  }

  private static class InstanceHolder {
    private final CustomerInstance _instance;
    private final Set<String> _clients = new HashSet();

    public InstanceHolder(CustomerInstance instance) {
      this._instance = instance;
    }

    public void addClient(String name) {
      this._clients.add(name);
    }

    public boolean hasClient(String name) {
      return this._clients.contains(name);
    }

    public void removeClient(String name) {
      this._clients.remove(name);
    }

    private boolean hasClients() {
      return (!(this._clients.isEmpty()));
    }

    public CustomerInstance getInstance() {
      return this._instance;
    }
  }
}