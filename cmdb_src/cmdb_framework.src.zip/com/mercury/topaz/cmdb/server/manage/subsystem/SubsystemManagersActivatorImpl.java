package com.mercury.topaz.cmdb.server.manage.subsystem;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import java.util.Iterator;
import java.util.Stack;

public class SubsystemManagersActivatorImpl extends SubsystemManagersContainerImpl
  implements SubsystemManagersActivator
{
  private Stack<CommonManager> stacked;
  private final Log log;

  public SubsystemManagersActivatorImpl()
  {
    this(CmdbLogFactory.getCMDBInfoLog());
  }

  public SubsystemManagersActivatorImpl(Log log)
  {
    this.stacked = new Stack();

    this.log = log;
  }

  public synchronized void addManager(CommonManager manager) {
    super.addManager(manager);
    this.stacked.push(manager);
  }

  public synchronized void removeManager(CommonManager manager) {
    super.removeManager(manager);
    this.stacked.push(manager);
  }

  public synchronized void startup() {
    for (Iterator i$ = this.stacked.iterator(); i$.hasNext(); ) { CommonManager manager = (CommonManager)i$.next();
      manager.startUp();
    }
  }

  public synchronized void shutdown() {
    super.clear();
    while (!(this.stacked.isEmpty())) {
      CommonManager manager = (CommonManager)this.stacked.pop();
      try {
        manager.shutdown();
      } catch (Throwable t) {
        this.log.error("error occured in subsystem [" + manager + "] during shutdown ,details:", t);
      }
    }
  }
}