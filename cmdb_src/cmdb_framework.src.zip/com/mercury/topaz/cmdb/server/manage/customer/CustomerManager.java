package com.mercury.topaz.cmdb.server.manage.customer;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public abstract interface CustomerManager extends GlobalSubsystemManager
{
  public abstract void startupService(CmdbCustomerID paramCmdbCustomerID, String paramString);

  public abstract void shutdownService(CmdbCustomerID paramCmdbCustomerID, String paramString);
}