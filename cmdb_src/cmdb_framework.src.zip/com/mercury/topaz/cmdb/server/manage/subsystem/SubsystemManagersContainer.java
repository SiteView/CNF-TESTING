package com.mercury.topaz.cmdb.server.manage.subsystem;

public abstract interface SubsystemManagersContainer extends SubsystemManagersAccessor
{
  public abstract void addManager(CommonManager paramCommonManager);

  public abstract void removeManager(CommonManager paramCommonManager);
}