package com.mercury.topaz.cmdb.server.manage.rpm;

public abstract interface LoadConfigurator
{
  public abstract int getPendingRequestsThreshold();

  public abstract long getMaxPendingTime();
}