package com.mercury.topaz.cmdb.server.manage.environment.subsystem.impl;

import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;

public class DalCmdbSubsystemEnvironment extends AbstractCmdbSubsystemEnvironment
{
  private boolean _disableCoarseGrainElementsInsert = false;

  public DalCmdbSubsystemEnvironment(boolean disableCoarseGrainElementsInsert)
  {
    setDisableCoarseGrainElementsInsert(disableCoarseGrainElementsInsert);
  }

  public FrameworkConstants.Subsystem getSubsystem() {
    return FrameworkConstants.Subsystem.DAL;
  }

  public boolean isDisableCoarseGrainElementsInsert() {
    return this._disableCoarseGrainElementsInsert;
  }

  private void setDisableCoarseGrainElementsInsert(boolean disableCoarseGrainElementsInsert) {
    this._disableCoarseGrainElementsInsert = disableCoarseGrainElementsInsert;
  }
}