package com.mercury.topaz.cmdb.server.manage.instance;

import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public abstract interface InstanceManager
{
  public abstract CustomerInstance createInstanceForService(CmdbCustomerID paramCmdbCustomerID, String paramString);

  public abstract void destroyInstanceForService(CmdbCustomerID paramCmdbCustomerID, String paramString);

  public abstract CustomerInstance getInstance(CmdbCustomerID paramCmdbCustomerID);
}