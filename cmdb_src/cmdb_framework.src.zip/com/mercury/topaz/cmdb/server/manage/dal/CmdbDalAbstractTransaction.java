package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;

public class CmdbDalAbstractTransaction
  implements CmdbDalTransaction
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalAbstractTransaction.class);
  private int refCount = 1;
  private final CmdbDalConnection connection;

  public CmdbDalAbstractTransaction(CmdbDalConnection connection)
  {
    this.connection = connection;
  }

  public void commit() {
    try {
      if (this.connection.isUpdateExecuted())
        this.connection.commit();
    }
    catch (CmdbDalException e)
    {
      throw e;
    } finally {
      releaseConnections();
    }
  }

  public void rollback() {
    try {
      rollbackConnections();
    } finally {
      releaseConnections();
    }
  }

  private void releaseConnections() {
    try {
      this.connection.release();
    } catch (Exception e) {
      _logger.error("Error releasing connection", e);
    }
  }

  private void rollbackConnections() {
    try {
      if (this.connection != null)
        this.connection.rollback();
    }
    catch (Exception e) {
      _logger.error("Error rolling back connection", e);
    }
  }

  public int incrementRefCount()
  {
    return (++this.refCount);
  }

  public int decrementRefCount()
  {
    if (this.refCount == 0)
      throw new RuntimeException("refCount = 0");

    return (--this.refCount);
  }

  public CmdbDalConnection getConnection() {
    return this.connection;
  }

  public String toString()
  {
    return this.connection.toString();
  }
}