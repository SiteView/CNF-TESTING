package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.util.retry.RetriableExecutor;
import com.mercury.topaz.cmdb.shared.util.retry.exception.RetryFailException;
import com.mercury.topaz.cmdb.shared.util.retry.exception.RetryFailUnexpectedCheckedException;
import com.mercury.topaz.cmdb.shared.util.retry.impl.AbstractRetriable;
import com.mercury.topaz.cmdb.shared.util.retry.impl.RetriableExecutorFactory;
import java.util.Iterator;

public class CmdbDalJdbcDAO
  implements CmdbDalDAO
{
  protected static final int RETRIES_NUM = 5;
  protected static final int INTERVAL_BETWEEN_RETRIES_MILL_SEC = 50;
  private static Log _logger = LogFactory.getEasyLog(CmdbDalJdbcDAO.class);
  private RetriableExecutor _retriableExecutor;
  private ConnectionPoolManager connectionPoolManager;

  public CmdbDalJdbcDAO(ConnectionPoolManager connectionPoolManager)
  {
    this.connectionPoolManager = connectionPoolManager;
    setRetriableExecutor(RetriableExecutorFactory.create(5, 50L));
  }

  public <RESULT> CmdbDalCommandResult<RESULT> executeQuery(CmdbDalCommand<RESULT> command) {
    CmdbDalCommandsContainer commandsContainer = CmdbDalCommandsContainerFactory.create();
    commandsContainer.addCommand(command);

    return executeQuery(commandsContainer); }

  protected <RESULT> CmdbDalCommandResult<RESULT> executeQuery(CmdbDalCommandsContainer commandsContainer) {
    RetriableExecutor retriableExecutor;
    try {
      retriableExecutor = getRetriableExecutor();
      CmdbDalDeadlockRetriable retriable = new CmdbDalDeadlockRetriable(this, commandsContainer);

      return ((CmdbDalCommandResult)retriableExecutor.execute(retriable));
    } catch (RetryFailException e) {
      throw new CmdbDalException("All retries ran out for commands container [" + commandsContainer + "]", e);
    } catch (RetryFailUnexpectedCheckedException e) {
      throw new CmdbDalException(e);
    }
  }

  public void execute(CmdbDalCommand<Void> command) {
    CmdbDalCommandsContainer commandsContainer = CmdbDalCommandsContainerFactory.create();
    commandsContainer.addCommand(command);

    execute(commandsContainer); }

  public void execute(CmdbDalCommandsContainer commandsContainer) {
    RetriableExecutor retriableExecutor;
    try {
      retriableExecutor = getRetriableExecutor();
      CmdbDalDeadlockRetriable retriable = new CmdbDalDeadlockRetriable(this, commandsContainer);

      retriableExecutor.execute(retriable);
    } catch (RetryFailException e) {
      throw new CmdbDalException("All deadlock retries ran out for commands container [" + commandsContainer + "]", e);
    } catch (RetryFailUnexpectedCheckedException e) {
      throw new CmdbDalException(e);
    }
  }

  private RetriableExecutor getRetriableExecutor() {
    return this._retriableExecutor;
  }

  private void setRetriableExecutor(RetriableExecutor retriableExecutor) {
    this._retriableExecutor = retriableExecutor;
  }

  public ConnectionPoolManager getConnectionsPoolManager() {
    return this.connectionPoolManager;
  }

  public DBType getDBType() {
    return getConnectionsPoolManager().getDBType();
  }

  private class CmdbDalDeadlockRetriable<RESULT> extends AbstractRetriable<CmdbDalCommandResult<RESULT>>
  {
    private final CmdbDalCommandsContainer commandsContainer;

    public CmdbDalDeadlockRetriable(, CmdbDalCommandsContainer paramCmdbDalCommandsContainer) {
      this.commandsContainer = commandsContainer;
    }

    public CmdbDalCommandResult<RESULT> performAction() throws Throwable {
      try {
        TransactionManager.start(this.this$0.getConnectionsPoolManager());
        CmdbDalCommandResult result = null;
        Iterator commandsIter = this.commandsContainer.getCommandsIterator();
        while (commandsIter.hasNext()) {
          CmdbDalCommand complexCommand = (CmdbDalCommand)commandsIter.next();
          result = complexCommand.execute();
        }
        TransactionManager.commit();
        return result;
      } catch (Exception e) {
        TransactionManager.rollback();
        throw new CmdbDalException(e);
      }
    }

    public Class[] getListOfExceptions() {
      return { CmdbDalException.class };
    }

    public String getActionDescription() {
      return "DAL transaction of commands [" + this.commandsContainer + "]";
    }

    public Log getLogger() {
      return CmdbDalJdbcDAO.access$000();
    }

    public boolean isExpectedException() {
      if (exception instanceof CmdbDalException) {
        CmdbDalException dalException = (CmdbDalException)exception;
        return dalException.isDeadlockException();
      }

      return false;
    }
  }
}