package com.mercury.topaz.cmdb.server.manage.quota.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaCheckResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import com.mercury.topaz.cmdb.shared.manage.quota.exception.CmdbQuotaException;
import java.util.Map;
import java.util.Set;

public abstract interface QuotaChecker
{
  public abstract Map<CmdbCustomerID, CustomerQuotasAndCounts> getCustomersQuotasAndCountsClone();

  public abstract Map<String, QuotaCount> getServerQuotasAndCountsClone();

  public abstract Set getExistingCustomerIDs();

  public abstract void addCustomerQuotaInfo(CmdbCustomerID paramCmdbCustomerID, String paramString, int paramInt);

  public abstract void changeCustomerQuota(CmdbCustomerID paramCmdbCustomerID, String paramString, int paramInt)
    throws CmdbQuotaException;

  public abstract void addServerQuotaInfo(String paramString1, int paramInt, String paramString2);

  public abstract void changeServerQuota(String paramString, int paramInt)
    throws CmdbQuotaException;

  public abstract void setCustomerCurrentCount(CmdbCustomerID paramCmdbCustomerID, String paramString, int paramInt);

  public abstract QuotaCheckResponse checkQuota(CmdbCustomerID paramCmdbCustomerID, String paramString, int paramInt);

  public abstract void resetAllCurrentCounts();

  public abstract void removeCustomerQuotaAndCounts(CmdbCustomerID paramCmdbCustomerID);
}