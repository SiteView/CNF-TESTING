package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.SQLException;

public class CmdbDalException extends CmdbException
{
  private static Log _logger = LogFactory.getEasyLog(CmdbDalException.class);
  public static final String DEADLOCK_SQLSTATE_CODE = "40001";
  public static final String ORACLE_DEADLOCK_MESSAGE = "ORA-00060";
  public static final String ORACLE_RESOURCE_BUSY_MESSAGE = "ORA-00054";
  private boolean _deadlockException = false;

  public CmdbDalException(String message)
  {
    super(message);
  }

  public CmdbDalException(String message, Throwable cause) {
    super(message, cause);
    processException(message, cause);
  }

  public CmdbDalException(String message, Throwable cause, ErrorCode errorCode) {
    super(message, cause, errorCode);
    processException(message, cause);
  }

  public CmdbDalException(Throwable cause) {
    super(cause);
    processException(null, cause);
  }

  public void processException(String message, SQLException cause) {
    String errMsg = (message == null) ? "null" : extractSqlExceptionErrorMessage(cause, message);
    _logger.error("Sql exception occured. Details:\n" + errMsg);
    setDeadlockException(isDeadlockOccured(cause));
  }

  public void processException(String message, CmdbDalException cause) {
    setDeadlockException(cause.isDeadlockException());
  }

  public void processException(String message, Throwable cause)
  {
  }

  private String extractSqlExceptionErrorMessage(SQLException cause, String originalMessage) {
    StringBuffer errMsg = new StringBuffer();
    SQLException tmpCause = cause;
    errMsg.append(originalMessage).append(". The exceptions in the chain:");
    int i = 0;

    while (tmpCause != null) {
      ++i;

      String stackTrace = extractStackTrace(tmpCause);
      errMsg.append("\nCause (").append(i).append("): ").append(tmpCause);
      errMsg.append("\nStack trace (").append(i).append("): \n").append(stackTrace);
      tmpCause = tmpCause.getNextException();
    }

    return errMsg.toString();
  }

  private String extractStackTrace(SQLException cause) {
    Writer result = new StringWriter();
    PrintWriter printWriter = new PrintWriter(result);
    cause.printStackTrace(printWriter);
    return result.toString();
  }

  public boolean isDeadlockException() {
    return this._deadlockException;
  }

  private void setDeadlockException(boolean deadlockException) {
    this._deadlockException = deadlockException;
  }

  private boolean isDeadlockOccured(SQLException e)
  {
    SQLException tmpCause = e;

    while (tmpCause != null) {
      if ((tmpCause.getMessage() != null) && (tmpCause.getMessage().indexOf("ORA-00060") > -1))
        return true;

      if ((tmpCause.getMessage() != null) && (tmpCause.getMessage().indexOf("ORA-00054") > -1))
        return true;

      if ((tmpCause.getSQLState() != null) && (tmpCause.getSQLState().equals("40001"))) {
        return true;
      }

      tmpCause = tmpCause.getNextException();
    }

    return false;
  }
}