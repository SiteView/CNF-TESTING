package com.mercury.topaz.cmdb.server.manage.environment.subsystem.impl;

import com.mercury.topaz.cmdb.server.manage.environment.subsystem.CmdbSubsystemEnvironment;
import com.mercury.topaz.cmdb.shared.bean.AbstractCmdbImmutableBean;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;
import java.io.ObjectStreamException;

abstract class AbstractCmdbSubsystemEnvironment extends AbstractCmdbImmutableBean
  implements CmdbSubsystemEnvironment
{
  public CmdbDigest getDigest()
  {
    throw new UnsupportedOperationException("wasn't implemented");
  }

  protected Object doReadResolve() throws ObjectStreamException {
    return this;
  }
}