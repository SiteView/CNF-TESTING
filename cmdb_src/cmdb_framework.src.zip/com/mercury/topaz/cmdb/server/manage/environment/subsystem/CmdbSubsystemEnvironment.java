package com.mercury.topaz.cmdb.server.manage.environment.subsystem;

import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import java.io.Serializable;

public abstract interface CmdbSubsystemEnvironment extends Serializable
{
  public abstract FrameworkConstants.Subsystem getSubsystem();
}