package com.mercury.topaz.cmdb.server.manage;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.instance.CmdbInstanceManager;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbContextRepository;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkGlobalOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public class ServerApiFacade
{
  private static final CmdbApi cmdbApi = CmdbApiFactory.createCMDBAPI();

  public static void executeOperation(FrameworkOperation operation)
  {
    executeOperation(operation, true);
  }

  public static void executeOperationAsynchronously(FrameworkOperation operation)
  {
    executeOperation(operation, false);
  }

  public static void executeGlobalOperation(FrameworkGlobalOperation globalOperation)
  {
    CmdbApiFactory.createCMDBAPI(CmdbApi.LOCAL_TYPE).executeOperation(globalOperation, CmdbContextRepository.get());
  }

  private static void executeOperation(FrameworkOperation frameworkOperation, boolean isSynchronic) {
    cmdbApi.executeCMDBOperation(frameworkOperation, CmdbContextRepository.get(), isSynchronic);
  }

  public static LocalEnvironment getLocalEnvironment()
  {
    CmdbCustomerID customerID = CmdbContextRepository.get().getCustomerID();
    CustomerInstance customerInstance = Framework.getInstance().getInstanceManager().getInstance(customerID);
    return customerInstance.getLocalEnvironment();
  }

  public static CmdbCustomerID getCustomerID() {
    return CmdbContextRepository.get().getCustomerID();
  }

  public static SettingsReader getSettingsReader()
  {
    CmdbCustomerID customerID = CmdbContextRepository.get().getCustomerID();
    return SettingsReaderManager.getInstance().getSettingsReader(customerID);
  }
}