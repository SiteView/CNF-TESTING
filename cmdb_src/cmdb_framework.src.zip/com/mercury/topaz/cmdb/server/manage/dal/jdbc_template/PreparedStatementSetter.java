package com.mercury.topaz.cmdb.server.manage.dal.jdbc_template;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import java.sql.SQLException;

public abstract interface PreparedStatementSetter
{
  public abstract void setValues(CmdbDalPreparedStatement paramCmdbDalPreparedStatement)
    throws SQLException;
}