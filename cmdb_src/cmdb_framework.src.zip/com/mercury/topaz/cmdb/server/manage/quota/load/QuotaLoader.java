package com.mercury.topaz.cmdb.server.manage.quota.load;

public abstract interface QuotaLoader
{
  public abstract int getQuotaValue(String paramString);
}