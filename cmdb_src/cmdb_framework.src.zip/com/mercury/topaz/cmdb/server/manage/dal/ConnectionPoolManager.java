package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.db.pools.ConnectionManager;
import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionPoolManager
{
  private static Log _logger = LogFactory.getEasyLog(ConnectionPoolManager.class);
  private static final String USE_DIRTY_READ = "dal.use.dirty.read";
  private String _dataTableSpaceName = null;
  private String _indexTableSpaceName = null;
  private SettingsReader settingsReader;
  private DbContext dbContext;
  private int customerID;

  public ConnectionPoolManager(SettingsReader settingsReader, DbContext dbContext, int customerID)
  {
    this.settingsReader = settingsReader;
    this.dbContext = dbContext;
    this.customerID = customerID;

    long timeoutInMillis = settingsReader.getInt("db.connection.pool.timeout", 600);
    if (timeoutInMillis > 0L) {
      ConnectionManager.getInstance().setConfiguredHeldTimeout(timeoutInMillis);
    }

    String initMsg = "Initialize connection pool. DB context: " + getDbContext().toString();

    if (_logger.isInfoEnabled())
      _logger.info(initMsg);
  }

  protected String getDefaultTableSpaceName()
  {
    String defaultTableSpaceName = "";
    if (isUsingOracleDB()) {
      CmdbDalConnection connection = null;
      CmdbDalPreparedStatement preparedStatement = null;
      CmdbDalResultSet resultSet = null;
      try {
        connection = getConnection();
        String sqlString = "SELECT TABLESPACE_NAME from user_tables WHERE TABLE_NAME = '" + getDefaultTableNameForTableSpace() + "'";
        preparedStatement = connection.prepareStatement4Select(sqlString);

        resultSet = preparedStatement.executeQuery();
        resultSet.next();
        defaultTableSpaceName = resultSet.getString(1);

        resultSet.close();
        preparedStatement.close();
      }
      catch (Exception e)
      {
        String errMsg;
        throw new CmdbDalException(errMsg, e);
      }
      finally {
        releaseConnection(connection, resultSet, preparedStatement);
      }
    }
    return defaultTableSpaceName;
  }

  protected String getDefaultTableNameForTableSpace() {
    return "CCM_CLASSES";
  }

  public CmdbDalConnection getConnection()
    throws CmdbDalException
  {
    DbContext dbContext = getDbContext();
    try
    {
      Connection connection = ConnectionManager.getConnection(dbContext);
      return CmdbDalConnectionFactory.create(connection, dbContext, this);
    }
    catch (Exception e) {
      throw new CmdbDalException("Error getting connection from pool", e, ErrorCode.DATABASE_NOT_AVAILABLE);
    }
  }

  public CmdbDalConnection getPrivateConnection(Properties properties)
  {
    DbContext dbContext = getDbContext();
    try
    {
      Connection connection = ConnectionManager.getPrivateConnection(dbContext, properties);

      return CmdbDalConnectionFactory.create(connection, dbContext, this);
    }
    catch (Exception e) {
      String errMsg = "Error getting private connection from pool, due to exception: " + e;

      _logger.error(errMsg);
      throw new CmdbDalException(errMsg, e, ErrorCode.DATABASE_NOT_AVAILABLE);
    }
  }

  public CmdbDalConnection getPrivateConnection()
  {
    DbContext dbContext = getDbContext();
    try
    {
      Connection connection = ConnectionManager.getPrivateConnection(dbContext);

      return CmdbDalConnectionFactory.create(connection, dbContext, this);
    }
    catch (Exception e) {
      String errMsg = "Error getting private connection from pool, due to exception: " + e;

      _logger.error(errMsg);
      throw new CmdbDalException(errMsg, e, ErrorCode.DATABASE_NOT_AVAILABLE);
    }
  }

  public void resetTimeout(CmdbDalConnection cmdbDalConnection)
  {
    ConnectionManager.getInstance().resetTimeout(cmdbDalConnection.getDbContext(), cmdbDalConnection.getConnection());
  }

  public boolean isUsingOracleDB()
  {
    return DBType.isOracle(getDbContext().getDbTypeEnum());
  }

  public boolean isUsingMSSqlDB()
  {
    return DBType.isMsSql(getDbContext().getDbTypeEnum());
  }

  public boolean isUsingOracle10gDB()
    throws SQLException
  {
    if (!(isUsingOracleDB())) {
      return false;
    }

    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;
    CmdbDalConnection connection = null;
    try {
      String sql = "select 1 from v$version where banner like '%10g%'";
      connection = getConnection();
      preparedStatement = connection.prepareStatement4Select(sql);
      resultSet = preparedStatement.executeQuery();

      boolean bool = resultSet.next();

      return bool;
    }
    finally
    {
      releaseConnection(connection, resultSet, preparedStatement);
    }
  }

  public boolean isUsingOracle10gDBRelease1()
    throws SQLException
  {
    if (!(isUsingOracle10gDB())) {
      return false;
    }

    CmdbDalPreparedStatement preparedStatement = null;
    CmdbDalResultSet resultSet = null;
    CmdbDalConnection connection = null;
    try
    {
      String sql = "select 1 from v$version where upper(banner) like '%CORE%10.1.0%'";
      connection = getConnection();
      preparedStatement = connection.prepareStatement4Select(sql);
      resultSet = preparedStatement.executeQuery();

      boolean bool = resultSet.next();

      return bool;
    }
    finally
    {
      releaseConnection(connection, resultSet, preparedStatement);
    }
  }

  public DBType getDBType()
  {
    return getDbContext().getDbTypeEnum();
  }

  public CmdbDalConnection getTransactionalConnection()
  {
    DbContext dbContext = getDbContext();
    try
    {
      Connection connection = ConnectionManager.getTransactionalConnection(dbContext);

      return CmdbDalConnectionFactory.create(connection, dbContext, this);
    }
    catch (Exception e) {
      String errMsg = "Error getting connection from pool, due to exception: " + e;

      _logger.error(errMsg);
      throw new CmdbDalException(errMsg, e, ErrorCode.DATABASE_NOT_AVAILABLE);
    }
  }

  public void releaseConnection(CmdbDalConnection cmdbDalConnection, CmdbDalResultSet resultSet, CmdbDalPreparedStatement stmt)
  {
    if (stmt != null)
      try {
        stmt.close();
      } catch (Exception e) {
        _logger.error(e);
      }

    if (resultSet != null)
      try {
        resultSet.close();
      } catch (Exception e) {
        _logger.error(e);
      }

    if (cmdbDalConnection != null)
    {
      try
      {
        cmdbDalConnection.setTransactionIsolation(2);

        cmdbDalConnection.close();
        ConnectionManager.releaseConnection(cmdbDalConnection.getDbContext(), cmdbDalConnection.getConnection());
      } catch (Exception e) {
        _logger.error(e);
      }
    }
  }

  public void releaseConnection(CmdbDalConnection cmdbDalConnection, CmdbDalResultSet resultSet) {
    releaseConnection(cmdbDalConnection, resultSet, null);
  }

  public void releaseConnection(CmdbDalConnection cmdbDalConnection) {
    releaseConnection(cmdbDalConnection, null, null);
  }

  public void releasePrivateConnection(CmdbDalConnection cmdbDalConnection)
  {
    if (cmdbDalConnection != null) {
      cmdbDalConnection.close();
      ConnectionManager.releasePrivateConnection(cmdbDalConnection.getConnection());
    }
  }

  public DbContext getDbContext() {
    return this.dbContext;
  }

  public String getDataTableSpaceName() {
    String dataTableSpaceName = this._dataTableSpaceName;
    if (dataTableSpaceName == null) {
      dataTableSpaceName = getSettingsDataTableSpaceName();
      setDataTableSpaceName(dataTableSpaceName);
    }
    return dataTableSpaceName;
  }

  private String getSettingsDataTableSpaceName() {
    return getDefaultTableSpaceName();
  }

  private String getSettingsIndexTableSpaceName() {
    return getDefaultTableSpaceName();
  }

  protected void setDataTableSpaceName(String dataTableSpaceName) {
    this._dataTableSpaceName = dataTableSpaceName;
  }

  boolean isUseDirtyRead()
  {
    return this.settingsReader.getBoolean("dal.use.dirty.read", true);
  }

  public String getIndexTableSpaceName() {
    String indexTableSpaceName = this._indexTableSpaceName;
    if (indexTableSpaceName == null) {
      indexTableSpaceName = getSettingsIndexTableSpaceName();
      setIndexTableSpaceName(indexTableSpaceName);
    }
    return indexTableSpaceName;
  }

  protected void setIndexTableSpaceName(String indexTableSpaceName) {
    this._indexTableSpaceName = indexTableSpaceName;
  }

  public int getCustomerID() {
    return this.customerID;
  }
}