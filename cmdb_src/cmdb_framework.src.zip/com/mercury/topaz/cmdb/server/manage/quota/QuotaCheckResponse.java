package com.mercury.topaz.cmdb.server.manage.quota;

import java.io.Serializable;

public abstract interface QuotaCheckResponse extends Serializable
{
  public abstract boolean canBeIncreased();

  public abstract String getCheckInfo();
}