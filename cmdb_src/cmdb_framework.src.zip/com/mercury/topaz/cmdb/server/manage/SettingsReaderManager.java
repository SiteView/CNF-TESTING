package com.mercury.topaz.cmdb.server.manage;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.instance.CmdbInstanceManager;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class SettingsReaderManager
{
  private static final SettingsReaderManager instance = new SettingsReaderManager();
  private SettingsReaderForTests settingsReaderForTests;

  public static SettingsReaderManager getInstance()
  {
    return instance;
  }

  SettingsReader getSettingsReader(CmdbCustomerID customerID) {
    if (this.settingsReaderForTests != null)
      return this.settingsReaderForTests;

    CustomerInstance customerInstance = Framework.getInstance().getInstanceManager().getInstance(customerID);
    return customerInstance.getLocalEnvironment().getSettingsReader();
  }

  public synchronized void setTestSetting(String name, String value) {
    if (this.settingsReaderForTests == null)
      this.settingsReaderForTests = new SettingsReaderForTests(null);

    this.settingsReaderForTests.setProperty(name, value);
  }

  public synchronized void setTopazHome(String topazHome) {
    if (this.settingsReaderForTests == null)
      this.settingsReaderForTests = new SettingsReaderForTests(null);

    this.settingsReaderForTests.setTopazHome(topazHome); }

  private static class SettingsReaderForTests
  implements SettingsReader { private String topazHome;
    private Properties properties;

    private SettingsReaderForTests() { this.properties = new Properties(); }

    public Properties asProperties() {
      return this.properties;
    }

    public boolean getBoolean(String paramName, boolean defaultValue) {
      String value = (String)this.properties.get(paramName);
      if (value == null)
        return defaultValue;

      return Boolean.parseBoolean(value);
    }

    public float getFloat(String paramName, float defaultValue)
    {
      String value = (String)this.properties.get(paramName);
      if (value == null)
        return defaultValue;

      return Float.parseFloat(value);
    }

    public int getInt(String paramName, int defaultValue)
    {
      String value = (String)this.properties.get(paramName);
      if (value == null)
        return defaultValue;

      return Integer.parseInt(value);
    }

    public long getLong(String paramName, long defaultValue)
    {
      String value = (String)this.properties.get(paramName);
      if (value == null)
        return defaultValue;

      return Long.parseLong(value);
    }

    public ReadOnlyIterator<String> getPropertyNames()
    {
      Iterator iterator = this.properties.keySet().iterator();
      return new ReadOnlyIteratorImpl(iterator);
    }

    public String getString(String paramName, String defaultValue) {
      String value = (String)this.properties.get(paramName);
      if (value == null)
        return defaultValue;

      return value;
    }

    public String getTopazHome()
    {
      if (this.topazHome == null)
        throw new UnsupportedOperationException("Not supported in unit tests");

      return this.topazHome;
    }

    public boolean isExist(String paramName) {
      return this.properties.containsKey(paramName);
    }

    public void setProperty(String name, String value) {
      this.properties.setProperty(name, value);
    }

    public void setTopazHome(String topazHome) {
      this.topazHome = topazHome;
    }
  }
}