package com.mercury.topaz.cmdb.server.manage.lock.exception;

import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;

public class DataLockException extends CmdbException
{
  public DataLockException(String message)
  {
    super(message);
  }

  public DataLockException(String message, ErrorCode errorCode) {
    super(message, errorCode);
  }

  public DataLockException(String message, Throwable cause) {
    super(message, cause);
  }

  public DataLockException(String message, Throwable cause, ErrorCode errorCode) {
    super(message, cause, errorCode);
  }

  public DataLockException(Throwable cause) {
    super(cause);
  }

  public DataLockException(Throwable cause, ErrorCode errorCode) {
    super(cause, errorCode);
  }
}