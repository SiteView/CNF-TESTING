package com.mercury.topaz.cmdb.server.manage.quota;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import com.mercury.topaz.cmdb.shared.manage.quota.exception.CmdbQuotaException;
import com.mercury.topaz.cmdb.shared.manage.quota.handler.QuotaCountHandler;
import java.util.List;
import java.util.Map;

public abstract interface QuotaManager extends GlobalSubsystemManager
{
  public abstract List<QuotaCountHandler> getCountHandlers(CmdbCustomerID paramCmdbCustomerID);

  public abstract void addCountHandler(CmdbCustomerID paramCmdbCustomerID, QuotaCountHandler paramQuotaCountHandler);

  public abstract Map<CmdbCustomerID, CustomerQuotasAndCounts> getCustomersQuotasAndCounts();

  public abstract Map<String, QuotaCount> getServerQuotasAndCounts();

  public abstract void addCustomerQuotaInfo(CmdbCustomerID paramCmdbCustomerID, String paramString, int paramInt);

  public abstract void changeCustomerQuota(CmdbCustomerID paramCmdbCustomerID, String paramString, int paramInt)
    throws CmdbQuotaException;

  public abstract void addServerQuotaInfo(String paramString1, int paramInt, String paramString2);

  public abstract void changeServerQuota(String paramString, int paramInt)
    throws CmdbQuotaException;

  public abstract QuotaCheckResponse checkQuota(CmdbCustomerID paramCmdbCustomerID, String paramString, int paramInt);

  public abstract void setCustomerCurrentCount(CmdbCustomerID paramCmdbCustomerID, String paramString, int paramInt);

  public abstract void resetAllCounts();

  public abstract void removeCustomerCounts(CmdbCustomerID paramCmdbCustomerID);

  public abstract void checkQuotas(CmdbRequest paramCmdbRequest);
}