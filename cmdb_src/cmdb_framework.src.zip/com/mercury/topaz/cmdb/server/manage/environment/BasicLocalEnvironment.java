package com.mercury.topaz.cmdb.server.manage.environment;

import com.mercury.infra.setting.SettingServiceAPI;
import com.mercury.infra.setting.SettingsFactory;
import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.schedule.LocalScheduler;
import com.mercury.topaz.cmdb.server.base.itc.schedule.Scheduler;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalDAO;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalJdbcDAO;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolFactory;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.manage.environment.subsystem.CmdbSubsystemEnvironment;
import com.mercury.topaz.cmdb.server.manage.environment.subsystem.impl.CmdbSubsystemEnvironmentFactory;
import com.mercury.topaz.cmdb.server.manage.settings.parameters.SettingsReaderFactory;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class BasicLocalEnvironment
  implements LocalEnvironment
{
  private static final Log LOGGER = CmdbLogFactory.getStartupLog();
  private SettingsReader _settingsReader;
  private GlobalEnvironment _globalEnvironment;
  private CmdbCustomerID _customerID;
  private Scheduler _scheduler;
  private final ConnectionPoolManager connectionPoolManager;
  private final CmdbDalDAO dao;
  private final Map<String, Object> _envParamTable;
  private Map<FrameworkConstants.Subsystem, CmdbSubsystemEnvironment> _subsystemEnvironmentsMap;
  private final List<NeedsShutdown> _shutdownListeners;

  public BasicLocalEnvironment(CmdbCustomerID customerID)
  {
    this(customerID, null);
  }

  public BasicLocalEnvironment(CmdbCustomerID customerID, DbContext dbContext)
  {
    this._envParamTable = new HashMap();

    this._shutdownListeners = new ArrayList();

    setCustomerID(customerID);
    setGlobalEnvironment(Framework.getInstance().getGlobalEnvironment());
    reloadSettings();
    setSubsystemEnvironmentsMap(CmdbSubsystemEnvironmentFactory.createSubsystemEnvironmentsMap());
    if (dbContext == null)
      this.connectionPoolManager = ConnectionPoolFactory.createCmdbPool(customerID.getID(), this._settingsReader);
    else
      this.connectionPoolManager = ConnectionPoolFactory.createDbContextPool(customerID.getID(), this._settingsReader, dbContext);

    this.dao = new CmdbDalJdbcDAO(this.connectionPoolManager);
  }

  public void startUp() {
    LOGGER.info("Local environment start up for customer [id=" + getCustomerID() + "]");
    setScheduler(new LocalScheduler(getCustomerID()));
  }

  public void shutdown() {
    LOGGER.info("Local environment shutdown for customer [id=" + getCustomerID() + "]");
    for (Iterator i$ = this._shutdownListeners.iterator(); i$.hasNext(); ) { NeedsShutdown needsShutdown = (NeedsShutdown)i$.next();
      try {
        needsShutdown.shutdown();
      } catch (Exception e) {
        LOGGER.error("Error shutting down listener " + needsShutdown.getClass().getName() + " in local environment of customer " + getCustomerID());
      }
    }
    getScheduler().shutdown();
  }

  public void addShutdownListener(NeedsShutdown listener) {
    this._shutdownListeners.add(listener);
  }

  public void reloadSettings() {
    setSettingsReader(SettingsReaderFactory.createCustomerReader(getCustomerID().getID(), "server"));
  }

  protected void setSettingsReader(SettingsReader settingsReader)
  {
    this._settingsReader = settingsReader;
  }

  public SettingsReader getSettingsReader() {
    return this._settingsReader;
  }

  public GlobalEnvironment getGlobalEnvironment() {
    return this._globalEnvironment;
  }

  protected void setGlobalEnvironment(GlobalEnvironment globalEnvironment) {
    this._globalEnvironment = globalEnvironment;
  }

  public CmdbCustomerID getCustomerID() {
    return this._customerID;
  }

  protected void setCustomerID(CmdbCustomerID customerID) {
    this._customerID = customerID;
  }

  public Scheduler getScheduler() {
    return this._scheduler;
  }

  public ConnectionPoolManager getConnectionsPoolManager() {
    return this.connectionPoolManager;
  }

  public CmdbDalDAO getDao() {
    return this.dao;
  }

  private void setScheduler(Scheduler scheduler) {
    this._scheduler = scheduler;
  }

  public synchronized void setParam(String paramName, Object paramValue) {
    this._envParamTable.put(paramName, paramValue);
  }

  public synchronized Object getParam(String paramName) {
    return this._envParamTable.get(paramName);
  }

  public int getSystemParameter(String name, int defaultValue) {
    return getSettingsReader().getInt(name, defaultValue);
  }

  public String getSystemParameter(String name, String defaultValue) {
    return getSettingsReader().getString(name, defaultValue);
  }

  public boolean getSystemParameter(String name, boolean defaultValue) {
    return getSettingsReader().getBoolean(name, defaultValue);
  }

  public float getSystemParameter(String name, float defaultValue) {
    return getSettingsReader().getFloat(name, defaultValue);
  }

  public long getSystemParameter(String name, long defaultValue) {
    return getSettingsReader().getLong(name, defaultValue);
  }

  public void setSystemParameter(String key, String value) {
    SettingServiceAPI settingServiceAPI = SettingsFactory.create();
    try {
      settingServiceAPI.setVariablePerCustomer("cmdb", key, getCustomerID().getID(), value);
    }
    catch (Exception ex) {
      LogFactory.getEasyLog(super.getClass()).error("Failed to set " + key + " to " + value + " in settings", ex);
    }
  }

  public synchronized CmdbSubsystemEnvironment getSubsystemEnvironment(FrameworkConstants.Subsystem subsystem) {
    CmdbSubsystemEnvironment cmdbSubsystemEnvironment = (CmdbSubsystemEnvironment)getSubsystemEnvironmentsMap().get(subsystem);
    if (cmdbSubsystemEnvironment == null)
      throw new CmdbException("There is no subsystem environment for subsystem [" + subsystem + "] !!!");

    return cmdbSubsystemEnvironment;
  }

  public synchronized void setSubsystemEnvironment(CmdbSubsystemEnvironment subsystemEnvironment) {
    getSubsystemEnvironmentsMap().put(subsystemEnvironment.getSubsystem(), subsystemEnvironment);
  }

  private Map<FrameworkConstants.Subsystem, CmdbSubsystemEnvironment> getSubsystemEnvironmentsMap() {
    return this._subsystemEnvironmentsMap;
  }

  private void setSubsystemEnvironmentsMap(Map<FrameworkConstants.Subsystem, CmdbSubsystemEnvironment> subsystemEnvironmentsMap) {
    if (subsystemEnvironmentsMap == null)
      throw new IllegalArgumentException("subsystemEnvironmentsMap is null !!!");

    this._subsystemEnvironmentsMap = subsystemEnvironmentsMap;
  }
}