package com.mercury.topaz.cmdb.server.manage.lock.operation.update;

import com.mercury.topaz.cmdb.server.manage.lock.DataForLock;
import com.mercury.topaz.cmdb.server.manage.lock.DataLockManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractDataLockRelease extends AbstractDataLockAction
{
  public AbstractDataLockRelease(DataForLock dataForLock)
  {
    super(dataForLock);
  }

  public void executeDataLock(DataLockManager dataLockManager, CmdbResponse response) throws CmdbException {
    dataLockManager.release(getDataForLock());
  }
}