package com.mercury.topaz.cmdb.server.manage.environment;

public abstract interface NeedsShutdown
{
  public abstract void shutdown();
}