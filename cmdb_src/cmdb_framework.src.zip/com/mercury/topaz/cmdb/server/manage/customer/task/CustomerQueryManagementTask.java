package com.mercury.topaz.cmdb.server.manage.customer.task;

public class CustomerQueryManagementTask
{
  public static final String NAME = "Customer Query Management Task";
}