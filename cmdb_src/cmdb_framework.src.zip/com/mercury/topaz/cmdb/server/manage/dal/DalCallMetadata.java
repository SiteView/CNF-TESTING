package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.manage.OperationStack;
import com.mercury.topaz.cmdb.shared.util.Stopper;

class DalCallMetadata
{
  private static Log logger = LogFactory.getEasyLog(DalCallMetadata.class);
  private final CmdbDalCommand<?> command;
  private Stopper stopper;

  DalCallMetadata(CmdbDalCommand<?> command)
  {
    this.command = command;

    if (logger.isInfoEnabled()) {
      this.stopper = new Stopper();
      this.stopper.start();
    }
  }

  public String toShortString() {
    return "command [" + this.command + "]";
  }

  public String toString()
  {
    String elapsedTimeAsString = (this.stopper != null) ? Long.toString(this.stopper.elapsedTime()) : "NA";

    String buf = "";

    if (this.command != null) {
      buf = buf + "command [" + this.command + "]";
    }

    buf = buf + " time [" + elapsedTimeAsString + " ms]";

    buf = buf + " customer ID [" + ServerApiFacade.getCustomerID() + "]";

    String opStack = OperationStack.asString();

    if (StringUtils.isNotEmpty(opStack))
      buf = buf + " operation stack [" + opStack + "]";

    return buf;
  }
}