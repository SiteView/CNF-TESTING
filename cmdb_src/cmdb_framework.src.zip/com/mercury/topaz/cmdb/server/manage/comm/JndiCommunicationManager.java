package com.mercury.topaz.cmdb.server.manage.comm;

import com.mercury.am.platform.controller.Process;
import com.mercury.am.platform.controller.util.JndiAccessor;
import com.mercury.am.platform.controller.util.JndiAccessorFactory;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.client.manage.api.util.CmdbApiUtil;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.CmdbFacade;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class JndiCommunicationManager
  implements CommunicationManager
{
  private CmdbFacade facade;
  private final Collection<String> bindings;

  public JndiCommunicationManager()
  {
    this.bindings = new HashSet(); }

  public void startUp() {
    try {
      setFacade(new CmdbFacadeImpl());
    } catch (RemoteException e) {
      throw new CmdbException(e);
    }

    String currentProcessName = Process.getLocalProcess().getProcessName();
    bindService(CmdbApiUtil.getJndiNameOfServer(currentProcessName));
    CmdbLogFactory.getCMDBInfoLog().info("Communication manager is started successfully");
  }

  public synchronized void shutdown() {
    for (Iterator i$ = this.bindings.iterator(); i$.hasNext(); ) { String bindName = (String)i$.next();
      JndiAccessorFactory.getInstance().getJndiAccessor().unbind(bindName);
    }
    CmdbLogFactory.getCMDBInfoLog().info("Communication manager is shut down successfully");
  }

  public synchronized void bindService(String serviceName) {
    String bindName = CmdbApiUtil.getJndiNameOfService(serviceName);
    if (this.bindings.contains(serviceName))
      return;

    JndiAccessorFactory.getInstance().getJndiAccessor().bind(bindName, getFacade());
    this.bindings.add(bindName);
  }

  public synchronized void unbindService(String serviceName) {
    String bindName = CmdbApiUtil.getJndiNameOfService(serviceName);
    JndiAccessorFactory.getInstance().getJndiAccessor().unbind(bindName);
    this.bindings.remove(bindName);
  }

  private CmdbFacade getFacade() {
    return this.facade;
  }

  private void setFacade(CmdbFacade facade) {
    this.facade = facade;
  }
}