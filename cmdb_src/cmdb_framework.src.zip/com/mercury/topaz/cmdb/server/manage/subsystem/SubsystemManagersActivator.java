package com.mercury.topaz.cmdb.server.manage.subsystem;

public abstract interface SubsystemManagersActivator extends SubsystemManagersContainer
{
  public abstract void startup();

  public abstract void shutdown();
}