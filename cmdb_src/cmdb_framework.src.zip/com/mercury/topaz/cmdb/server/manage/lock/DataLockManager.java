package com.mercury.topaz.cmdb.server.manage.lock;

import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;

public abstract interface DataLockManager extends SubsystemManager
{
  public abstract boolean lock(DataForLock paramDataForLock);

  public abstract void release(DataForLock paramDataForLock);

  public abstract boolean switchLock(DataForLock paramDataForLock1, DataForLock paramDataForLock2);

  public abstract boolean isEntireModelLocked();

  public abstract void unlockEntireModel();
}