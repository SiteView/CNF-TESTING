package com.mercury.topaz.cmdb.server.manage.customer.impl;

import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.customer.CustomerQueryManager;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.manage.instance.CmdbInstanceManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractGlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;

public class CustomerQueryManagerImpl extends AbstractGlobalSubsystemManager
  implements CustomerQueryManager, SingleReadSingleWrite
{
  private CmdbInstanceManager _instanceManager;

  public CustomerQueryManagerImpl(GlobalEnvironment globalEnvironment, CmdbInstanceManager instanceManager)
  {
    super(globalEnvironment);
    setInstanceManager(instanceManager);
    Framework.getInstance().setLock(this);
  }

  public void startUp() {
  }

  public void shutdown() {
  }

  public CmdbCustomerIDs getLoadedCustomerIds() {
    return getInstanceManager().getLoadedCustomerIDs();
  }

  public CmdbCustomerIDs getLoadedCustomerIds(String serviceName) {
    return getInstanceManager().getLoadedCustomerIDs(serviceName);
  }

  public boolean isServiceStarted(CmdbCustomerID customerID, String serviceName) {
    return getInstanceManager().hasInstanceForService(customerID, serviceName);
  }

  private CmdbInstanceManager getInstanceManager() {
    return this._instanceManager;
  }

  private void setInstanceManager(CmdbInstanceManager instanceManager) {
    this._instanceManager = instanceManager;
  }

  public String getName() {
    return "Customer Query Management Task";
  }
}