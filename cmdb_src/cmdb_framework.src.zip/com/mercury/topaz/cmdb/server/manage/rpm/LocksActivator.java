package com.mercury.topaz.cmdb.server.manage.rpm;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

class LocksActivator
{
  private List<Locking> registered = new LinkedList();
  private Stack<Locking> succeeded = new Stack();

  void addLock(Locking lock)
  {
    this.registered.add(lock); }

  void lock() throws Exception {
    Iterator i$;
    try {
      for (i$ = this.registered.iterator(); i$.hasNext(); ) { Locking locking = (Locking)i$.next();
        locking.lock();
        this.succeeded.push(locking);
      }
    }
    catch (Exception e) {
      throw e;
    } finally {
      this.registered.clear();
    }
  }

  void unlock() {
    rollbackSuccessful();
  }

  private void rollbackSuccessful() {
    while (!(this.succeeded.empty())) {
      Locking locking = (Locking)this.succeeded.pop();
      try {
        locking.unlock();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  static abstract interface Locking
  {
    public abstract void lock()
      throws Exception;

    public abstract void unlock()
      throws Exception;
  }
}