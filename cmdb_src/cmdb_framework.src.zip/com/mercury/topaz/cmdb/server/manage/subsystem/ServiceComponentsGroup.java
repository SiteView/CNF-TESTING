package com.mercury.topaz.cmdb.server.manage.subsystem;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.server.manage.service.ServiceComponent;
import com.mercury.topaz.cmdb.server.manage.service.config.ServiceDependency;
import com.mercury.topaz.cmdb.server.manage.subsystem.observer.SubsystemManagersObserver;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.util.graphutils.GenericGraph;
import com.mercury.topaz.cmdb.shared.util.graphutils.GenericGraphLink;
import com.mercury.topaz.cmdb.shared.util.graphutils.GenericGraphNode;
import com.mercury.topaz.cmdb.shared.util.graphutils.GraphUtils;
import com.mercury.topaz.cmdb.shared.util.graphutils.impl.GenericGraphNodeImpl;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ServiceComponentsGroup
{
  protected final LocalEnvironment localEnvironment;
  protected List<ServiceComponent> serviceComponents = new ArrayList();
  private final CustomerInstance customerInstance;

  public ServiceComponentsGroup(CustomerInstance customerInstance, List<ServiceComponent> serviceComponents)
  {
    this.customerInstance = customerInstance;
    this.localEnvironment = customerInstance.getLocalEnvironment();
    this.serviceComponents = sortServiceComponentsByDependency(serviceComponents);
  }

  protected List<ServiceComponent> sortServiceComponentsByDependency(List<ServiceComponent> serviceComponents)
  {
    GenericGraph graph = buildServiceComponentsGraph(serviceComponents);

    List sortedGraphNodes = GraphUtils.performTopologicalSort(graph);
    Collections.reverse(sortedGraphNodes);
    return GraphUtils.extractSortedObjectsFromNodes(sortedGraphNodes);
  }

  private GenericGraph buildServiceComponentsGraph(List<ServiceComponent> serviceComponents) {
    ServiceComponent serviceComponent;
    GenericGraphNode graphNode;
    Map componentsMap = new HashMap();
    GenericGraph graph = new GenericGraph();

    for (Iterator i$ = serviceComponents.iterator(); i$.hasNext(); ) { serviceComponent = (ServiceComponent)i$.next();
      graphNode = new GenericGraphNodeImpl(serviceComponent);
      graph.addNode(graphNode);
      componentsMap.put(serviceComponent.getName(), serviceComponent); }

    for (i$ = serviceComponents.iterator(); i$.hasNext(); ) {
      serviceComponent = (ServiceComponent)i$.next();

      graphNode = graph.getNode(new GenericGraphNodeImpl(serviceComponent));
      List serviceDependencies = serviceComponent.getDependencies();
      label230: Iterator i$ = serviceDependencies.iterator();
    }

    return graph;
  }

  protected Collection<SubsystemManagersObserver> createSubsystemManagersObservers() {
    return Collections.emptyList();
  }

  public void startUp() {
    SubsystemManagersObserver observer;
    Collection observers = createSubsystemManagersObservers();

    for (Iterator i$ = observers.iterator(); i$.hasNext(); ) { observer = (SubsystemManagersObserver)i$.next();
      observer.startUp();
    }

    for (i$ = this.serviceComponents.iterator(); i$.hasNext(); ) { ServiceComponent serviceComponent = (ServiceComponent)i$.next();
      serviceComponent.startUp(this.localEnvironment, observers, this.customerInstance);
    }

    for (i$ = observers.iterator(); i$.hasNext(); ) { observer = (SubsystemManagersObserver)i$.next();
      observer.shutdown();
    }
  }

  public void shutdown() {
    for (Iterator i$ = this.serviceComponents.iterator(); i$.hasNext(); ) { ServiceComponent serviceComponent = (ServiceComponent)i$.next();
      serviceComponent.shutdown(this.customerInstance);
    }
  }

  public LocalEnvironment getLocalEnvironment() {
    return this.localEnvironment;
  }

  public CmdbCustomerID getCustomerID() {
    return getLocalEnvironment().getCustomerID();
  }
}