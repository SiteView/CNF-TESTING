package com.mercury.topaz.cmdb.server.manage.semaphore;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;

public class SemaphoreFactory
{
  public static CmdbSemaphore createSemaphore(CommonManager manager, int permits, Log log, BottlenecksHistory bottlenecksHistory)
  {
    if (regulationNeeded(permits))
      return new CmdbReentrantSemaphoreImpl(manager, permits, log, bottlenecksHistory);

    return new VoidSemaphore();
  }

  private static boolean regulationNeeded(int permits)
  {
    return (permits > 0);
  }
}