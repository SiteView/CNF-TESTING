package com.mercury.topaz.cmdb.server.manage.subsystem;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkGlobalOperation;

public abstract interface GlobalSubsystemManager extends CommonManager
{
  public abstract void executeGlobalOperation(FrameworkGlobalOperation paramFrameworkGlobalOperation);
}