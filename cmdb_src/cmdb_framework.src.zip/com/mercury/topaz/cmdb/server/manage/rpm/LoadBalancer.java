package com.mercury.topaz.cmdb.server.manage.rpm;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.manage.semaphore.BottlenecksHistory;
import com.mercury.topaz.cmdb.server.manage.semaphore.CmdbSemaphore;
import com.mercury.topaz.cmdb.server.manage.semaphore.SemaphoreFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.util.HashMap;
import java.util.Map;

public class LoadBalancer
{
  private Log log;
  private final Map<String, CmdbSemaphore> semaphores = new HashMap();
  private final BottlenecksHistory bottlenecksHistory = new BottlenecksHistory();

  public LoadBalancer(Log log)
  {
    this.log = log;
  }

  public void setSemaphore(CommonManager manager) {
    setSemaphore(manager, -1);
  }

  public void setSemaphore(CommonManager manager, int permits) {
    synchronized (this.semaphores) {
      String managerName = manager.getName();
      if (!(this.semaphores.containsKey(managerName)))
        this.semaphores.put(managerName, SemaphoreFactory.createSemaphore(manager, permits, this.log, this.bottlenecksHistory));
    }
  }

  private CmdbSemaphore getSemaphore(CommonManager manager)
  {
    synchronized (this.semaphores) {
      String name = manager.getName();
      CmdbSemaphore semaphore = (CmdbSemaphore)this.semaphores.get(name);
      if (semaphore == null)
        throw new CmdbException("Semaphore for manager (" + name + ") doesn't exist");

      return semaphore;
    }
  }

  public void dumpStats(IndentingDumper dumper) {
    this.bottlenecksHistory.dumpHistory(dumper);
  }

  public void shutdown() {
    this.semaphores.clear();
    this.bottlenecksHistory.clear();
  }

  public void acquire(CommonManager manager, FrameworkOperation operation) throws InterruptedException {
    CmdbSemaphore semaphore = getSemaphore(manager);
    try {
      semaphore.acquire(operation);
    } catch (InterruptedException e) {
      this.log.error("Interrupt occurred while trying to acquire semaphore on manager (" + manager.getName() + ") for operation (" + operation.getOperationName() + ")", e);

      throw e;
    }
  }

  public void release(CommonManager manager, FrameworkOperation operation) {
    getSemaphore(manager).release(operation);
  }

  public BottlenecksHistory getBottleneckHistory() {
    return this.bottlenecksHistory;
  }
}