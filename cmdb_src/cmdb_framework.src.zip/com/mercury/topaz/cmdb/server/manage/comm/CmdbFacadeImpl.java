package com.mercury.topaz.cmdb.server.manage.comm;

import appilog.framework.shared.manage.MamResponse;
import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.shared.manage.CmdbFacade;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.util.Stopper;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class CmdbFacadeImpl extends UnicastRemoteObject
  implements CmdbFacade
{
  public MamResponse handleRequest(CmdbRequest request)
    throws RemoteException, CmdbResponseException
  {
    Stopper stopper = new Stopper();
    stopper.start();
    MamResponse response = Framework.getInstance().handleRequest(request);
    response.setServerRunningTime(stopper.elapsedTime());
    return response; }

  public byte[] handleBinaryRequest(byte[] serializedRequest) throws RemoteException, CmdbResponseException {
    ObjectInputStream objectInputStream;
    try {
      objectInputStream = new ObjectInputStream(new ByteArrayInputStream(serializedRequest));
      CmdbRequest request = (CmdbRequest)objectInputStream.readObject();
      CmdbResponse response = handleRequest(request);
      ByteArrayOutputStream serializedResponse = new ByteArrayOutputStream();
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(serializedResponse);
      objectOutputStream.writeObject(response);
      objectOutputStream.close();
      return serializedResponse.toByteArray();
    } catch (IOException e) {
      throw new MamResponseException(e, "N/A");
    } catch (ClassNotFoundException e) {
      throw new MamResponseException(e, "N/A");
    }
  }
}