package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.db.context.DBContextProviderException;
import com.mercury.infra.db.context.DBContextProviderFactory;
import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.settings.parameters.SettingsReaderFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class ConnectionPoolFactory
{
  public static final String DATA_MODEL_DB_CONTEXT = "cmdb";
  public static final String DATA_MODEL_DB_TYPE = "dal.datamodel.db.type";
  public static final String DATA_MODEL_HOST_NAME = "dal.datamodel.host.name";
  public static final String DATA_MODEL_DB_NAME = "dal.datamodel.db.name";
  public static final String DATA_MODEL_USER_NAME = "dal.datamodel.user.name";
  public static final String DATA_MODEL_PASSWORD = "dal.datamodel.password";
  public static final String DATA_MODEL_SERVER = "dal.datamodel.server";
  public static final String DATA_MODEL_SID = "dal.datamodel.sid";
  public static final String DATA_MODEL_PORT = "dal.datamodel.port";
  public static final String HISTORY_DB_CONTEXT_KEY = "cmdb_history";
  public static final String HISTORY_DB_TYPE = "dal.history.db.type";
  public static final String HISTORY_HOST_NAME = "dal.history.host.name";
  public static final String HISTORY_DB_NAME = "dal.history.db.name";
  public static final String HISTORY_USER_NAME = "dal.history.user.name";
  public static final String HISTORY_PASSWORD = "dal.history.password";
  public static final String HISTORY_SERVER = "dal.history.server";
  public static final String HISTORY_SID = "dal.history.sid";
  public static final String HISTORY_PORT = "dal.history.port";

  public static ConnectionPoolManager createDbContextPool(int customerID, SettingsReader settingsReader, DbContext dbContext)
  {
    return new ConnectionPoolManager(settingsReader, dbContext, customerID);
  }

  public static ConnectionPoolManager createCmdbPool(int customerID, SettingsReader settingsReader)
  {
    if (!(SettingsReaderFactory.fileSettings))
      try {
        dbContext = DBContextProviderFactory.getInstance().getDbContext("cmdb", customerID);
      } catch (DBContextProviderException e) {
        throw new CmdbDalException("Failed to create DB context", e);
      }

    DbContext dbContext = createCmdbDbContext(settingsReader);

    return createDbContextPool(customerID, settingsReader, dbContext);
  }

  public static DbContext createCmdbDbContext(SettingsReader settingsReader)
  {
    return new DbContext(DBType.getDbTypeByName(settingsReader.getString("dal.datamodel.db.type", "")), settingsReader.getString("dal.datamodel.host.name", ""), settingsReader.getString("dal.datamodel.db.name", ""), settingsReader.getString("dal.datamodel.user.name", ""), settingsReader.getString("dal.datamodel.password", ""), settingsReader.getString("dal.datamodel.server", ""), settingsReader.getString("dal.datamodel.sid", ""), settingsReader.getString("dal.datamodel.port", ""));
  }

  public static ConnectionPoolManager createHistoryPool(int customerID, SettingsReader settingsReader)
  {
    if (!(SettingsReaderFactory.fileSettings))
      try {
        dbContext = DBContextProviderFactory.getInstance().getDbContext("cmdb_history", customerID);
      } catch (DBContextProviderException e) {
        throw new CmdbDalException("Failed to create DB context", e);
      }

    DbContext dbContext = createHistoryDbContext(settingsReader);

    return createDbContextPool(customerID, settingsReader, dbContext);
  }

  public static DbContext createHistoryDbContext(SettingsReader settingsReader) {
    return new DbContext(DBType.getDbTypeByName(settingsReader.getString("dal.history.db.type", "")), settingsReader.getString("dal.history.host.name", ""), settingsReader.getString("dal.history.db.name", ""), settingsReader.getString("dal.history.user.name", ""), settingsReader.getString("dal.history.password", ""), settingsReader.getString("dal.history.server", ""), settingsReader.getString("dal.history.sid", ""), settingsReader.getString("dal.history.port", ""));
  }

  public static ConnectionPoolManager createHistoryPool(LocalEnvironment env)
  {
    return createHistoryPool(env.getCustomerID().getID(), env.getSettingsReader());
  }
}