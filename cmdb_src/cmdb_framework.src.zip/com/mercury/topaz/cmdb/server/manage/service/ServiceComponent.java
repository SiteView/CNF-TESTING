package com.mercury.topaz.cmdb.server.manage.service;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.service.config.ServiceDependency;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersContainer;
import com.mercury.topaz.cmdb.server.manage.subsystem.observer.SubsystemManagersObserver;
import java.util.Collection;
import java.util.List;

public abstract interface ServiceComponent
{
  public abstract String getName();

  public abstract List<ServiceDependency> getDependencies();

  public abstract void startUp(LocalEnvironment paramLocalEnvironment, Collection<SubsystemManagersObserver> paramCollection, SubsystemManagersContainer paramSubsystemManagersContainer);

  public abstract void shutdown(SubsystemManagersContainer paramSubsystemManagersContainer);
}