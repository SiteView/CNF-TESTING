package com.mercury.topaz.cmdb.server.manage.service.config.impl;

import com.mercury.topaz.cmdb.server.manage.service.config.ServiceDependency;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

public class ServiceDependencyImpl
  implements ServiceDependency, IUnmarshallable, IMarshallable
{
  private String dependency;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.server.manage.service.config.impl.JiBX_bindingFactory|";

  public ServiceDependencyImpl(String dependency)
  {
    this.dependency = dependency;
  }

  public String getDependencyName() {
    return this.dependency;
  }

  public void setDependency(String dependency) {
    this.dependency = dependency;
  }
}