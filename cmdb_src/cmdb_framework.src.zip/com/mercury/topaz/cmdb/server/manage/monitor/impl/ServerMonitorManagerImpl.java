package com.mercury.topaz.cmdb.server.manage.monitor.impl;

import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.manage.monitor.ServerMonitorManager;
import com.mercury.topaz.cmdb.server.manage.rpm.RequestProcessor;
import com.mercury.topaz.cmdb.server.manage.stats.OperationStatistics;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractGlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.util.stats.TimeBasedStatistics;

public class ServerMonitorManagerImpl extends AbstractGlobalSubsystemManager
  implements ServerMonitorManager, SingleReadSingleWrite
{
  public ServerMonitorManagerImpl(GlobalEnvironment globalEnvironment)
  {
    super(globalEnvironment);
    Framework.getInstance().setLock(this);
  }

  public void startUp()
  {
  }

  public void shutdown()
  {
  }

  public String getServerStatus() {
    return Framework.getInstance().dumpStatus();
  }

  public String getFormattedServerStatus() {
    return Framework.getInstance().getFormattedStatus();
  }

  public void executeRequestTimeoutCallbacks() {
    Framework.getInstance().executeRequestTimeoutCallbacks();
  }

  public void stopOperation(int operationID) {
    Framework.getInstance().stopOperation(operationID);
  }

  public String dumpServerSnapshotToLog(String serverName, String processName) {
    String serverSnapshot = Framework.getInstance().dumpStatus();
    if ((StringUtils.isEmpty(processName)) && (StringUtils.isEmpty(serverName))) {
      CmdbLogFactory.getServerMonitorLog().info(serverSnapshot);
      return serverSnapshot;
    }

    String processDesc = "\nServer snapshot for";
    StringBuffer buf = new StringBuffer(processDesc);
    if (!(StringUtils.isEmpty(processName))) {
      buf.append(" process: ").append(processName);
    }

    if (!(StringUtils.isEmpty(serverName))) {
      buf.append("\thost: ").append(serverName);
    }

    int length = buf.length();
    buf.append("\n");
    for (int i = 0; i < length; ++i)
      buf.append("-");

    buf.append("\n");
    buf.append(serverSnapshot);

    CmdbLogFactory.getServerMonitorLog().info(buf.toString());
    return buf.toString();
  }

  public String dumpOperationStatistics() {
    RequestProcessor processor = Framework.getInstance().getRequestProcessor();
    if (processor == null)
      return "Statistics are not running on this server";

    OperationStatistics operationStatistics = processor.getOperationStatistics();
    TimeBasedStatistics timeBasedStatistics = operationStatistics.getTimeBasedStatistics();
    return timeBasedStatistics.dump();
  }

  public void resetOperationStatistics() {
    RequestProcessor processor = Framework.getInstance().getRequestProcessor();
    if (processor == null)
      return;

    OperationStatistics operationStatistics = processor.getOperationStatistics();
    operationStatistics.dump();
    operationStatistics.reschedule();
    operationStatistics.reset();
  }

  public String getName() {
    return "Server Monitor Task";
  }
}