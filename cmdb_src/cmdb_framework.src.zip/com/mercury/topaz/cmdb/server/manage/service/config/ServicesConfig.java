package com.mercury.topaz.cmdb.server.manage.service.config;

import java.util.List;

public abstract interface ServicesConfig
{
  public abstract List<ServiceConfig> getServicesConfig();

  public abstract void addServiceConfig(ServiceConfig paramServiceConfig);
}