package com.mercury.topaz.cmdb.server.manage.service.config.impl;

import com.mercury.topaz.cmdb.server.manage.service.config.ServiceConfig;
import com.mercury.topaz.cmdb.server.manage.service.config.ServiceDependency;
import com.mercury.topaz.cmdb.server.manage.service.config.ServiceTaskConfig;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

class ServiceConfigImpl
  implements ServiceConfig, IUnmarshallable, IMarshallable
{
  private String _serviceName;
  private String _controllerServiceName;
  private List<ServiceTaskConfig> _serviceTasksConfig;
  private List<ServiceDependency> _dependencies;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.server.manage.service.config.impl.JiBX_bindingFactory|";

  public ServiceConfigImpl()
  {
    setServiceTasksConfig(new ArrayList());
    setDependencies(new ArrayList());
  }

  void setServiceName(String serviceName) {
    if ((serviceName == null) || (serviceName.length() == 0))
      throw new IllegalArgumentException("service name is null or empty !!!");

    this._serviceName = serviceName;
  }

  void setControllerServiceName(String controllerServiceName) {
    if ((controllerServiceName != null) && (controllerServiceName.length() != 0))
      this._controllerServiceName = controllerServiceName;
  }

  void addServiceTaskConfig(Object serviceTaskConfig)
  {
    if ((serviceTaskConfig == null) || (!(serviceTaskConfig instanceof ServiceTaskConfig)))
      throw new IllegalArgumentException("service config is null or not instance of ServiceTaskConfig!!!");

    getServiceTasksConfig().add((ServiceTaskConfig)serviceTaskConfig);
  }

  public String getServiceName() {
    return this._serviceName;
  }

  public String getControllerServiceName() {
    return this._controllerServiceName;
  }

  public List<ServiceTaskConfig> getServiceTasksConfig() {
    return this._serviceTasksConfig;
  }

  private void setServiceTasksConfig(List<ServiceTaskConfig> serviceTasksConfig) {
    this._serviceTasksConfig = serviceTasksConfig;
  }

  protected Iterator<ServiceTaskConfig> getServiceTasksConfigIterator()
  {
    return getServiceTasksConfig().iterator();
  }

  public void addDependency(Object serviceDependency) {
    if ((serviceDependency == null) || (!(serviceDependency instanceof ServiceDependency)))
      throw new IllegalArgumentException("service config is null or not instance of serviceDependency!!!");

    getDependencies().add((ServiceDependency)serviceDependency);
  }

  public List<ServiceDependency> getDependencies() {
    return this._dependencies;
  }

  public void setDependencies(List<ServiceDependency> dependencies) {
    this._dependencies = dependencies;
  }

  protected Iterator<ServiceDependency> getDependenciesIterator()
  {
    return getDependencies().iterator();
  }
}