package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.util.Stopper;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class CmdbDalConnection
{
  private static final String SELECT = "SELECT";
  private static Log _logger = LogFactory.getEasyLog(CmdbDalConnection.class);
  public static CmdbDalConnection DUMMY_CONNECTION = null;
  private final ConnectionPoolManager _connectionPool;
  private DbContext _dbContext = null;
  private boolean _updateExecuted = true;
  private Connection _connection = null;
  private Map<String, CmdbDalPreparedStatement> _updatePreparedStatementsTable = null;
  private Map<String, CmdbDalPreparedStatement> _selectPreparedStatementsTable = null;
  private Set<CmdbDalPreparedStatement> _selectStatementsSet = null;
  private final Map<String, Object> properties = new HashMap();

  public CmdbDalConnection(Connection connection, DbContext dbContext, ConnectionPoolManager connectionPool)
  {
    this._connectionPool = connectionPool;
    init(connection, dbContext);
  }

  private void init(Connection connection, DbContext dbContext)
  {
    if (_logger.isDebugEnabled()) {
      LogUtil.debug(_logger, "Initializing Cmdb DAL connection [" + connection.toString() + "]");
    }

    setConnection(connection);
    setDbContext(dbContext);

    setSelectPreparedStatementsTable(new HashMap());
    setSelectStatementsSet(new HashSet());
    setUpdatePreparedStatementsTable(new HashMap());
  }

  public void commit()
    throws CmdbDalException
  {
    try
    {
      getConnection().commit();
      if (_logger.isDebugEnabled())
        LogUtil.debug(_logger, "Commit connection [" + getConnection().toString() + "]");
    }
    catch (Exception e)
    {
      String errMsg = "Failed on commit connection [" + getConnection().toString() + "], due to exception " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }

  public void rollback()
    throws CmdbDalException
  {
    try
    {
      getConnection().rollback();
      if (_logger.isDebugEnabled())
        LogUtil.debug(_logger, "Rollback connection [" + getConnection().toString() + "]");
    }
    catch (Exception e)
    {
      String errMsg = "Failed on rollback connection [" + getConnection().toString() + "], due to exception " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }

  void close()
  {
    try
    {
      closePreparedStatementsTable(getUpdatePreparedStatementsTable());
      closePreparedStatementsTable(getSelectPreparedStatementsTable());
      closeStatementsTable();
    }
    catch (Exception e) {
      LogUtil.error(_logger, "Error trying to clean connection not closed prepared statements", e);
    }

    if (_logger.isDebugEnabled())
      LogUtil.debug(_logger, "Cmdb dal connection [" + this._connection.toString() + "] is closed");
  }

  private void closePreparedStatementsTable(Map<String, CmdbDalPreparedStatement> statementsTable)
  {
    if (statementsTable != null) {
      for (Iterator i$ = statementsTable.values().iterator(); i$.hasNext(); ) { CmdbDalPreparedStatement statement = (CmdbDalPreparedStatement)i$.next();
        if (statement != null)
          ((CmdbDalPreparedStatementImpl)statement).close(false);
      }

      statementsTable.clear();
    }
  }

  private void closeStatementsTable() {
    if (getSelectStatementsSet() != null) {
      for (Iterator i$ = getSelectStatementsSet().iterator(); i$.hasNext(); ) { CmdbDalPreparedStatement statement = (CmdbDalPreparedStatement)i$.next();
        if (statement != null)
          statement.close();
      }

      getSelectStatementsSet().clear();
    }
  }

  public void release()
  {
    getConnectionPool().releaseConnection(this);
  }

  public CmdbDalPreparedStatement prepareStatement4Update(String sqlQuery)
  {
    setUpdateExecuted(true);
    return prepareStatement(getUpdatePreparedStatementsTable(), sqlQuery);
  }

  public CmdbDalPreparedStatement prepareStatement4Select(String sqlQuery)
  {
    String sqlQuery1 = sqlQuery;
    if (_logger.isDebugEnabled())
      sqlQuery1 = appendDebugInfo(sqlQuery1);

    return prepareStatement(getSelectPreparedStatementsTable(), sqlQuery1);
  }

  public CmdbDalPreparedStatement statement4Select(String sqlQuery)
  {
    if (getConnectionPool().isUsingMSSqlDB()) {
      String errMsg = "Usage of Statement is not allowed when using MSSql DB";
      _logger.error(errMsg);
      throw new CmdbDalException(errMsg);
    }

    if (_logger.isDebugEnabled())
      sqlQuery = appendDebugInfo(sqlQuery);

    return statement(sqlQuery);
  }

  private String appendDebugInfo(String sqlQuery) {
    if (sqlQuery.startsWith("SELECT")) {
      sqlQuery = "SELECT /* customer id [" + getConnectionPool().getCustomerID() + "] */" + sqlQuery.substring("SELECT".length());
    }

    return sqlQuery;
  }

  private CmdbDalPreparedStatement statement(String query)
    throws CmdbDalException
  {
    try
    {
      resetTimeout();

      CmdbDalStatementImpl statement = new CmdbDalStatementImpl(getConnection().createStatement(), query);
      getSelectStatementsSet().add(statement);

      return statement;
    }
    catch (Exception e) {
      String errMsg = "Connection [" + getConnection() + "] failed to create statement for " + query + " due to exception " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }

  private CmdbDalPreparedStatement prepareStatement(Map<String, CmdbDalPreparedStatement> statTable, String query)
    throws CmdbDalException
  {
    try
    {
      resetTimeout();

      CmdbDalPreparedStatement statement = (CmdbDalPreparedStatement)statTable.get(query);

      if (statement == null) {
        statement = new CmdbDalPreparedStatementImpl(getConnection().prepareStatement(query), query, statTable);
        statTable.put(query, statement);
      }

      return statement;
    }
    catch (Exception e) {
      String errMsg = "Connection [" + getConnection() + "] failed to create prepared statement for " + query + " due to exception " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }

  private void resetTimeout()
  {
    try
    {
      getConnectionPool().resetTimeout(this);
    }
    catch (Exception e) {
      LogUtil.error(_logger, "!!! Fail to reset timeout for connection [" + this + "], due to exception: " + e, e);
    }
  }

  public void executeAdhocSql(String sql)
  {
    Statement statement = null;

    resetTimeout();
    try
    {
      Stopper stopper = null;
      if (_logger.isInfoEnabled()) {
        stopper = new Stopper();
        stopper.start();
      }
      statement = getConnection().createStatement();
      statement.execute(sql);

      if (_logger.isInfoEnabled()) {
        long elapsedTime = (stopper != null) ? stopper.elapsedTime() : 0L;
        LogUtil.info(_logger, "Executed adhoc sql [" + sql + "] " + "in connection [" + getConnection().toString() + "]. " + "Total jdbc time: " + elapsedTime + " [ms]");
      }
    }
    catch (Exception e)
    {
    }
    finally
    {
      if (statement != null)
        try {
          statement.close();
        }
        catch (Exception e) {
          LogUtil.error(_logger, "Can't close statement [" + sql + "], due to exception: " + e);
        }
    }
  }

  public void setTransactionIsolation(int level)
  {
    try
    {
      if (getConnectionPool().isUseDirtyRead()) {
        getConnection().setTransactionIsolation(level);
      }

    }
    catch (Exception e)
    {
      LogUtil.error(_logger, "Can't change transaction isolation to level [" + level + "], due to exception: " + e + ". Using original level instead !!!");
    }
  }

  public int getTransactionIsolation()
  {
    try
    {
      return getConnection().getTransactionIsolation();
    }
    catch (Exception e) {
      throw new CmdbDalException(e);
    }
  }

  public void executeCallableStatement(String sql)
  {
    CallableStatement callableStatement = null;
    try
    {
      Stopper stopper = null;
      if (_logger.isInfoEnabled()) {
        stopper = new Stopper();
        stopper.start();
      }

      boolean autoCommit = getConnection().getAutoCommit();
      getConnection().setAutoCommit(true);

      callableStatement = getConnection().prepareCall(sql);
      callableStatement.execute();

      getConnection().setAutoCommit(autoCommit);

      if (_logger.isInfoEnabled()) {
        long elapsedTime = (stopper != null) ? stopper.elapsedTime() : 0L;
        LogUtil.info(_logger, "Executed callable statetment [" + sql + "] " + "in connection [" + getConnection().toString() + "]. " + "Total jdbc time: " + elapsedTime + " [ms]");
      }

    }
    catch (Exception e)
    {
    }
    finally
    {
      if (callableStatement != null)
        try {
          callableStatement.close();
        }
        catch (Exception e) {
          LogUtil.error(_logger, "Can't close callable statement [" + sql + "], due to exception: ", e);
        }
    }
  }

  private Map<String, CmdbDalPreparedStatement> getUpdatePreparedStatementsTable()
  {
    return this._updatePreparedStatementsTable;
  }

  private void setUpdatePreparedStatementsTable(Map<String, CmdbDalPreparedStatement> updatePreparedStatementsTable) {
    this._updatePreparedStatementsTable = updatePreparedStatementsTable;
  }

  private Map<String, CmdbDalPreparedStatement> getSelectPreparedStatementsTable() {
    return this._selectPreparedStatementsTable;
  }

  private void setSelectPreparedStatementsTable(Map<String, CmdbDalPreparedStatement> selectPreparedStatementsTable) {
    this._selectPreparedStatementsTable = selectPreparedStatementsTable;
  }

  private Set<CmdbDalPreparedStatement> getSelectStatementsSet() {
    return this._selectStatementsSet;
  }

  private void setSelectStatementsSet(Set<CmdbDalPreparedStatement> selectStatementsSet) {
    this._selectStatementsSet = selectStatementsSet;
  }

  public boolean isUpdateExecuted() {
    return this._updateExecuted;
  }

  private void setUpdateExecuted(boolean updateExecuted) {
    this._updateExecuted = updateExecuted;
  }

  private void setConnection(Connection connection) {
    this._connection = connection;
  }

  Connection getConnection() {
    return this._connection;
  }

  DbContext getDbContext() {
    return this._dbContext;
  }

  private void setDbContext(DbContext dbContext) {
    this._dbContext = dbContext;
  }

  public ConnectionPoolManager getConnectionPool() {
    return this._connectionPool;
  }

  public DBType getDBType() {
    return getConnectionPool().getDBType();
  }

  public void setProperty(String name, Object value) {
    this.properties.put(name, value);
  }

  public Object getProperty(String name) {
    return this.properties.get(name);
  }

  public String toString()
  {
    return "connection [" + this._connection + "], DB context [" + this._dbContext + "]";
  }
}