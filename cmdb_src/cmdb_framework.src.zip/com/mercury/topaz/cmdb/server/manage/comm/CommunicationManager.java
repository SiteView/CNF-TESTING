package com.mercury.topaz.cmdb.server.manage.comm;

public abstract interface CommunicationManager
{
  public abstract void startUp();

  public abstract void shutdown();

  public abstract void bindService(String paramString);

  public abstract void unbindService(String paramString);
}