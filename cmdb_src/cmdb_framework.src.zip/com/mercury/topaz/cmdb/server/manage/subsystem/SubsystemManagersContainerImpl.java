package com.mercury.topaz.cmdb.server.manage.subsystem;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import java.util.HashMap;
import java.util.Map;

public class SubsystemManagersContainerImpl
  implements SubsystemManagersContainer
{
  private Map<String, CommonManager> managers;
  private final Log log;

  public SubsystemManagersContainerImpl()
  {
    this(CmdbLogFactory.getCMDBInfoLog());
  }

  public SubsystemManagersContainerImpl(Log log)
  {
    this.managers = new HashMap();

    this.log = log;
  }

  public synchronized void addManager(CommonManager manager) {
    if (manager == null) {
      throw new CmdbException("Can not add null subsystem manager");
    }

    String subsystemName = manager.getName();
    if ((subsystemName == null) || (subsystemName.trim().length() == 0)) {
      throw new CmdbException("Can not add subsystem manager (" + manager + ") for empty name");
    }

    this.managers.put(subsystemName, manager);
  }

  public synchronized void removeManager(CommonManager manager) {
    if (manager == null)
      throw new CmdbException("Can not add null subsystem manager");

    this.managers.remove(manager.getName());
  }

  public synchronized CommonManager getManager(String subsystemName) {
    if ((subsystemName == null) || (subsystemName.trim().length() == 0)) {
      throw new CmdbException("Can not get subsystem manager for empty name");
    }

    return ((CommonManager)this.managers.get(subsystemName));
  }

  public void clear() {
    this.managers.clear();
  }
}