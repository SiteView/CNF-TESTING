package com.mercury.topaz.cmdb.server.manage.dal.jdbc_template;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import java.sql.SQLException;

abstract interface PreparedStatementCreator
{
  public abstract CmdbDalPreparedStatement create()
    throws SQLException;
}