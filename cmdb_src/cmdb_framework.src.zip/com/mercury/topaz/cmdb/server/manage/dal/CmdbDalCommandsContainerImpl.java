package com.mercury.topaz.cmdb.server.manage.dal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class CmdbDalCommandsContainerImpl
  implements CmdbDalCommandsContainer
{
  private List<CmdbDalCommand> _commands = null;

  CmdbDalCommandsContainerImpl()
  {
    this._commands = new ArrayList();
  }

  public void addCommand(CmdbDalCommand command) {
    this._commands.add(command);
  }

  public Iterator<CmdbDalCommand> getCommandsIterator() {
    return this._commands.iterator();
  }

  public String toString() {
    return this._commands.toString();
  }
}