package com.mercury.topaz.cmdb.server.manage.subsystem;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbReadWriteLock;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkGlobalOperation;

public abstract class AbstractGlobalSubsystemManager
  implements GlobalSubsystemManager
{
  private SettingsReader _globalSettingsReader;
  private CmdbReadWriteLock lock;

  public AbstractGlobalSubsystemManager(GlobalEnvironment globalEnvironment)
  {
    setGlobalSettingsReader(globalEnvironment.getSettingsReader());
  }

  public SettingsReader getGlobalSettings()
  {
    return this._globalSettingsReader;
  }

  public void setGlobalSettingsReader(SettingsReader globalSettingsReader) {
    this._globalSettingsReader = globalSettingsReader;
  }

  public void executeGlobalOperation(FrameworkGlobalOperation operation) {
    ServerApiFacade.executeGlobalOperation(operation);
  }

  public CmdbReadWriteLock getLock() {
    return this.lock;
  }

  public void setLock(CmdbReadWriteLock lock) {
    this.lock = lock;
  }
}