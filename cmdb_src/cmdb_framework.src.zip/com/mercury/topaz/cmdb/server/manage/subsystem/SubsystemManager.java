package com.mercury.topaz.cmdb.server.manage.subsystem;

import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.manage.operation.util.OperationExecutor;

public abstract interface SubsystemManager
{
  public abstract MamCustomerID getCustomerID();

  public abstract SettingsReader getLocalSettings();

  public abstract LocalEnvironment getLocalEnvironment();
}