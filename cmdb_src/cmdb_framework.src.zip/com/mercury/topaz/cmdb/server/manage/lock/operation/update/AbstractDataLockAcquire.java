package com.mercury.topaz.cmdb.server.manage.lock.operation.update;

import com.mercury.topaz.cmdb.server.manage.lock.DataForLock;
import com.mercury.topaz.cmdb.server.manage.lock.DataLockManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractDataLockAcquire extends AbstractDataLockAction
{
  private static final String KEY_DID_WAIT = "didWait";
  private boolean _didWait;

  public AbstractDataLockAcquire(DataForLock dataForLock)
  {
    super(dataForLock);
  }

  public void executeDataLock(DataLockManager dataLockManager, CmdbResponse response) throws CmdbException {
    boolean didWait = false;
    try {
      didWait = dataLockManager.lock(getDataForLock());
    } finally {
      response.addResult("didWait", Boolean.valueOf(didWait));
    }
  }

  public void updateWithResponse(CmdbResponse response) {
    this._didWait = ((Boolean)response.getResult("didWait")).booleanValue();
  }

  public boolean didWait() {
    return this._didWait;
  }
}