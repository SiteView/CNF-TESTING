package com.mercury.topaz.cmdb.server.manage.semaphore;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.manage.rpm.IndentingDumper;
import com.mercury.topaz.cmdb.server.manage.rpm.LoadConfigurator;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Stack;
import java.util.Vector;
import java.util.concurrent.Semaphore;

public class CmdbReentrantSemaphoreImpl
  implements CmdbSemaphore
{
  private Semaphore semaphore;
  private LoadConfigurator loadConfigurator;
  private Log log;
  private BottlenecksHistory bottlenecksHistory;
  private List<Owner> owners;
  private List<UniqueTimestamp> pendingOperationTimestamps;

  public CmdbReentrantSemaphoreImpl(int permits, Log log)
  {
    this(null, permits, log, null);
  }

  public CmdbReentrantSemaphoreImpl(CommonManager manager, int permits, Log log, BottlenecksHistory bottlenecksHistory)
  {
    this.semaphore = null;

    this.owners = new LinkedList();

    if (manager instanceof LoadConfigurator) {
      this.loadConfigurator = ((LoadConfigurator)manager);
      this.pendingOperationTimestamps = new Vector();
    }

    this.log = log;
    this.bottlenecksHistory = bottlenecksHistory;

    this.semaphore = new Semaphore(permits, true);
  }

  private void logSemaphoreAccess(FrameworkOperation operation, String what) {
    String subsystemName = "unknown";
    String operationName = "unknown";
    if (operation != null) {
      operationName = operation.getOperationName();
      subsystemName = operation.getExecutionTaskQueueName();
    }
    this.log.debug(what + " for operation (" + operationName + "), subsystem (" + subsystemName + ")" + "on semaphore: " + this.semaphore.toString());
  }

  public void acquire(FrameworkOperation operation) throws InterruptedException
  {
    boolean reentry = tryAcquireReentrantly(operation);
    if (reentry) {
      return;
    }

    if (this.semaphore.availablePermits() == 0) {
      recordAccess(operation);
    }

    if (this.loadConfigurator != null) {
      int pendingThreshold = this.loadConfigurator.getPendingRequestsThreshold();

      int pendingCount = this.pendingOperationTimestamps.size();

      if (pendingCount > pendingThreshold) {
        long maxPendingTime = getMaxPendingTime();

        if (maxPendingTime > this.loadConfigurator.getMaxPendingTime()) {
          throw new CmdbException("Operation (" + operation + ") is rejected as" + " 1) number of pending requests (" + pendingCount + ") exceeds maximum (" + pendingThreshold + ")" + " and 2) current max pending time  (" + maxPendingTime + " ms)" + "exceeds threshold (" + this.loadConfigurator.getMaxPendingTime() + " ms) - " + "for manager (" + this.loadConfigurator + ")");
        }

      }

      UniqueTimestamp uniqueTimestamp = new UniqueTimestamp();
      this.pendingOperationTimestamps.add(uniqueTimestamp);
      try {
        this.semaphore.acquire();
      } finally {
        this.pendingOperationTimestamps.remove(uniqueTimestamp);
      }
    } else {
      this.semaphore.acquire();
    }

    addOwner(Thread.currentThread(), operation);
  }

  private long getMaxPendingTime() {
    long max = 0L;
    for (Iterator i$ = this.pendingOperationTimestamps.iterator(); i$.hasNext(); ) { UniqueTimestamp unique = (UniqueTimestamp)i$.next();
      long current = System.currentTimeMillis();
      long time = current - unique.timestamp;
      max = (max > time) ? max : time;
    }
    return max;
  }

  private boolean tryAcquireReentrantly(FrameworkOperation operation) {
    synchronized (this.owners) {
      boolean reentrancy = false;
      for (Iterator i$ = this.owners.iterator(); i$.hasNext(); ) { Owner owner = (Owner)i$.next();
        Thread current = Thread.currentThread();
        if (owner.getThread() == current) {
          logSemaphoreAccess(operation, "Reentrancy: owner = " + current.getName());
          owner.addEntry(operation);
          reentrancy = true;
          break;
        }
      }
      return reentrancy;
    }
  }

  private boolean tryReleaseOwner() {
    boolean deleted = false;
    synchronized (this.owners) {
      Iterator iter = this.owners.iterator();
      while (iter.hasNext()) {
        Owner owner = (Owner)iter.next();
        if (owner.getThread() == Thread.currentThread()) {
          owner.deleteEntry();

          if (owner.hasEntries()) break;
          iter.remove();
          deleted = true;
          break;
        }

      }

    }

    return deleted;
  }

  private void addOwner(Thread thread, FrameworkOperation operation) {
    synchronized (this.owners) {
      this.owners.add(new Owner(thread, operation));
    }
  }

  private void recordAccess(FrameworkOperation operation) {
    if (this.bottlenecksHistory != null)
      this.bottlenecksHistory.recordContention(operation, this);
  }

  public void release(FrameworkOperation operation)
  {
    boolean ownerDeleted = tryReleaseOwner();

    if (ownerDeleted)
      this.semaphore.release();
  }

  public String toString()
  {
    IndentingDumper dumper = new IndentingDumper();
    dumpStatus(dumper);
    return dumper.toString();
  }

  private void dumpStatus(IndentingDumper dumper) {
    dumper.append("Semaphore: " + this.semaphore.toString());
    dumper.increaseIndent();
    dumper.append("Queue length = " + this.semaphore.getQueueLength());
    dumper.append("Permit owners:");
    dumper.increaseIndent();
    synchronized (this.owners) {
      for (Iterator i$ = this.owners.iterator(); i$.hasNext(); ) { Owner owner = (Owner)i$.next();
        dumper.append("Thread: " + owner.getThread());
        dumper.append("Operations:");
        dumper.increaseIndent();
        for (Iterator i$ = owner.getOperations().iterator(); i$.hasNext(); ) { FrameworkOperation operation = (FrameworkOperation)i$.next();
          dumper.append(operation.toString());
        }
        dumper.decreaseIndent();
      }
    }
    dumper.decreaseIndent();
    dumper.decreaseIndent();
  }

  private static class UniqueTimestamp
  {
    private static final Random random = new Random();
    private static final int CEIL = 67108864;
    long timestamp;
    Integer unique;

    UniqueTimestamp()
    {
      this.timestamp = System.currentTimeMillis();
      this.unique = Integer.valueOf(random.nextInt(67108863));
    }

    public int hashCode()
    {
      return this.unique.hashCode();
    }

    public boolean equals(Object obj)
    {
      if (obj == null) {
        return false;
      }

      if (!(obj instanceof UniqueTimestamp)) {
        return false;
      }

      return this.unique.equals(((UniqueTimestamp)obj).unique);
    }
  }

  private static class Owner
  {
    private Thread owningThread;
    private Stack<FrameworkOperation> operations = new Stack();

    Owner(Thread thread, FrameworkOperation operation)
    {
      this.owningThread = thread;
      this.operations.push(operation);
    }

    boolean hasEntries() {
      return (this.operations.size() > 0);
    }

    Thread getThread() {
      return this.owningThread;
    }

    void addEntry(FrameworkOperation operation) {
      this.operations.push(operation);
    }

    void deleteEntry() {
      this.operations.pop();
    }

    Iterable<FrameworkOperation> getOperations() {
      return this.operations;
    }
  }
}