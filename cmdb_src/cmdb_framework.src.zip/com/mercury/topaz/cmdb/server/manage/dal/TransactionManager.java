package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;

public class TransactionManager
{
  private static ThreadLocal<CmdbDalTransaction> tl = new ThreadLocal();
  private static Log logger = LogFactory.getEasyLog(TransactionManager.class);

  private static CmdbDalTransaction get()
  {
    return ((CmdbDalTransaction)tl.get());
  }

  public static void start(ConnectionPoolManager connectionManager) {
    CmdbDalTransaction transaction = get();
    if (transaction == null) {
      CmdbDalConnection connection = connectionManager.getTransactionalConnection();
      transaction = new CmdbDalAbstractTransaction(connection);
      tl.set(transaction);
      logger.info("Opened transaction [" + transaction + "]");
    } else {
      transaction.incrementRefCount();
    }
  }

  public static void commit() {
    CmdbDalTransaction transaction = get();
    if (transaction == null) {
      return;
    }

    if (transaction.decrementRefCount() == 0)
      try {
        transaction.commit();
        logger.info("Committed transaction [" + transaction + "]");
      } finally {
        tl.remove();
      }
  }

  public static CmdbDalConnection getConnection()
  {
    return get().getConnection();
  }

  public static void rollback() {
    CmdbDalTransaction transaction = get();
    if (transaction == null)
      return;

    try
    {
      transaction.rollback();
      logger.info("Rolled back transaction [" + transaction + "]");
    } finally {
      tl.remove();
    }
  }
}