package com.mercury.topaz.cmdb.server.manage.semaphore;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface CmdbSemaphore
{
  public abstract void acquire(FrameworkOperation paramFrameworkOperation)
    throws InterruptedException;

  public abstract void release(FrameworkOperation paramFrameworkOperation);
}