package com.mercury.topaz.cmdb.server.manage.customer;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;

public abstract interface CustomerQueryManager extends GlobalSubsystemManager
{
  public abstract boolean isServiceStarted(CmdbCustomerID paramCmdbCustomerID, String paramString);

  public abstract CmdbCustomerIDs getLoadedCustomerIds();

  public abstract CmdbCustomerIDs getLoadedCustomerIds(String paramString);
}