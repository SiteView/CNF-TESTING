package com.mercury.topaz.cmdb.server.manage.dal;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

public class CmdbDalResultSet
{
  private ResultSet _resultSet = null;

  public CmdbDalResultSet(ResultSet resultSet)
  {
    setResultSet(resultSet);
  }

  public int getRow()
    throws SQLException
  {
    return getResultSet().getRow();
  }

  public boolean next()
    throws SQLException
  {
    return getResultSet().next();
  }

  public boolean wasNull()
    throws SQLException
  {
    return getResultSet().wasNull();
  }

  public Double getDouble(int columnIndex)
    throws SQLException
  {
    double d = getResultSet().getDouble(columnIndex);
    if (wasNull())
      return null;

    return Double.valueOf(d);
  }

  public Float getFloat(int columnIndex)
    throws SQLException
  {
    float f = getResultSet().getFloat(columnIndex);
    if (wasNull())
      return null;

    return Float.valueOf(f);
  }

  public Integer getInt(int columnIndex)
    throws SQLException
  {
    int i = getResultSet().getInt(columnIndex);
    if (wasNull())
      return null;

    return Integer.valueOf(i);
  }

  public Long getLong(int columnIndex)
    throws SQLException
  {
    long l = getResultSet().getLong(columnIndex);
    if (wasNull())
      return null;

    return Long.valueOf(l);
  }

  public Boolean getBoolean(int columnIndex)
    throws SQLException
  {
    boolean b = getResultSet().getBoolean(columnIndex);
    if (wasNull())
      return null;

    return Boolean.valueOf(b);
  }

  public InputStream getBinaryStream(int columnIndex) throws SQLException {
    return getResultSet().getBinaryStream(columnIndex);
  }

  public byte[] getBytes(int columnIndex)
    throws SQLException
  {
    return getResultSet().getBytes(columnIndex);
  }

  public Object getObject(int columnIndex)
    throws SQLException
  {
    return getResultSet().getObject(columnIndex);
  }

  public String getString(int columnIndex)
    throws SQLException
  {
    return getResultSet().getString(columnIndex);
  }

  public Double getDouble(String columnName)
    throws SQLException
  {
    double d = getResultSet().getDouble(columnName);
    if (wasNull())
      return null;

    return Double.valueOf(d);
  }

  public Float getFloat(String columnName)
    throws SQLException
  {
    float f = getResultSet().getFloat(columnName);
    if (wasNull())
      return null;

    return Float.valueOf(f);
  }

  public Integer getInt(String columnName)
    throws SQLException
  {
    int i = getResultSet().getInt(columnName);
    if (wasNull())
      return null;

    return Integer.valueOf(i);
  }

  public Long getLong(String columnName)
    throws SQLException
  {
    long l = getResultSet().getLong(columnName);
    if (wasNull())
      return null;

    return Long.valueOf(l);
  }

  public Boolean getBoolean(String columnName)
    throws SQLException
  {
    boolean b = getResultSet().getBoolean(columnName);
    if (wasNull())
      return null;

    return Boolean.valueOf(b);
  }

  public byte[] getBytes(String columnName)
    throws SQLException
  {
    return getResultSet().getBytes(columnName);
  }

  public byte[] getBlob(int i)
    throws SQLException
  {
    Blob blobValue = getResultSet().getBlob(i);
    return extractBlob(blobValue);
  }

  public String getClob(int i)
    throws SQLException
  {
    Clob res = getResultSet().getClob(i);
    return extractClob(res);
  }

  public Date getDate(int columnIndex)
    throws SQLException
  {
    Long timeMillisec = getLong(columnIndex);
    if (timeMillisec == null)
      return null;

    return new Date(timeMillisec.longValue());
  }

  public Object getObject(int i, Map<String, Class<?>> map)
    throws SQLException
  {
    return getResultSet().getObject(i, map);
  }

  public String getString(String columnName)
    throws SQLException
  {
    return getResultSet().getString(columnName);
  }

  public byte[] getBlob(String colName)
    throws SQLException
  {
    Blob blobValue = getResultSet().getBlob(colName);
    return extractBlob(blobValue);
  }

  private byte[] extractBlob(Blob blobValue) throws SQLException {
    return ((blobValue == null) ? null : blobValue.getBytes(1L, (int)blobValue.length()));
  }

  private String extractClob(Clob clobValue) throws SQLException {
    return ((clobValue == null) ? "" : clobValue.getSubString(1L, (int)clobValue.length()));
  }

  public String getClob(String colName)
    throws SQLException
  {
    Clob res = getResultSet().getClob(colName);
    return extractClob(res);
  }

  public Date getDate(String columnName)
    throws SQLException
  {
    Long timeMillisec = getLong(columnName);
    if (timeMillisec == null)
      return null;

    return new Date(timeMillisec.longValue());
  }

  public Date getDate(int columnIndex, Calendar cal)
    throws SQLException
  {
    return getResultSet().getDate(columnIndex, cal);
  }

  public Object getObject(String colName, Map<String, Class<?>> map)
    throws SQLException
  {
    return getResultSet().getObject(colName, map);
  }

  public void close()
  {
    try
    {
      getResultSet().close();
    }
    catch (Exception e) {
      String errMsg = "Can't close result set [" + getResultSet().toString() + "], due to exception: " + e;

      throw new CmdbDalException(errMsg, e);
    }
  }

  private ResultSet getResultSet() {
    return this._resultSet;
  }

  private void setResultSet(ResultSet resultSet) {
    this._resultSet = resultSet;
  }

  public ResultSetMetaData getMetaData() throws SQLException {
    return getResultSet().getMetaData();
  }
}