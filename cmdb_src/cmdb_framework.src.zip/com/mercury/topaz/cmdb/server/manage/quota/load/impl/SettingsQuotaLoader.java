package com.mercury.topaz.cmdb.server.manage.quota.load.impl;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;

public class SettingsQuotaLoader extends AbstractQuotaLoader
{
  public SettingsQuotaLoader(SettingsReader settingsReader)
  {
    super(settingsReader);
  }

  public int getQuotaValue(String quotaName) {
    return getSettingsReader().getInt(quotaName, 2147483647);
  }
}