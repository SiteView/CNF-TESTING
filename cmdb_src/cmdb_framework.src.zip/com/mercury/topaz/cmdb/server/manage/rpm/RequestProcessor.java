package com.mercury.topaz.cmdb.server.manage.rpm;

import appilog.framework.shared.manage.MamResponse;
import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbLock;
import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbReadWriteLock;
import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbReadWriteLockFactory;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.instance.CmdbInstanceManager;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.server.manage.semaphore.BottlenecksHistory;
import com.mercury.topaz.cmdb.server.manage.stats.OperationStatistics;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersAccessor;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.CmdbContextRepository;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseImpl;
import com.mercury.topaz.cmdb.shared.manage.operation.CustomerAndCategoryOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkGlobalOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.HasExplicitTimeout;
import com.mercury.topaz.cmdb.shared.manage.operation.OpDestinationResolver;
import com.mercury.topaz.cmdb.shared.manage.operation.ServerAndCategoryOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCommonOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;
import com.mercury.topaz.cmdb.shared.util.ThreadUtil;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

public class RequestProcessor
{
  private Log log;
  private static final String DEFAULT_THREAD_POOL_NAME = "Default";
  private Map<String, ThreadPoolExecutor> threadPools = new HashMap();
  private final Map<Thread, Stack<RequestInProgress>> servingThreads = Collections.synchronizedMap(new HashMap());
  private Map<CmdbCustomerID, List<RequestTimeoutCallback>> requestTimeoutCallbacks = new HashMap();
  private DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
  private long defaultSessionTimeout;
  private LoadBalancer loadBalancer;
  private Timer timer;
  private OperationStatistics operationStatistics;
  private static final long TIMEOUT_MONITOR_PERIOD = 60000L;
  private static final String CMDB_INTERNAL_ERROR_PREFIX = "\nCMDB Internal Error: ";
  private static final String INTERRUPTED_ERROR_MESSAGE = "\nCMDB Internal Error: InterruptedException - another thread has interrupted the request thread for request";
  private static final String STOPPED_ERROR_MESSAGE = "\nCMDB Internal Error: StoppedException - stop occurred for the request thread for request";
  private static final String UNKNOWN_ERROR_MESSAGE = "\nCMDB Internal Error: Unknown error while handling request";
  private static final String CMDB_ERROR_MESSAGE = "\nCMDB Internal Error: Error while handling request";

  public RequestProcessor()
  {
    this.log = CmdbLogFactory.getOperationLog();

    initDefaultThreadPool();
    this.loadBalancer = new LoadBalancer(this.log);
    setDefaultTimeout();

    this.timer = new Timer("Request processor timer", true);
    this.timer.schedule(new RequestTimeoutMonitor(this, null), 0L, 60000L);

    this.operationStatistics = new OperationStatistics(this.timer);
  }

  private void initDefaultThreadPool() {
    int threadPoolSize = getThreadPoolSize();

    ThreadPoolExecutor threadPool = ThreadUtil.createTypicalThreadPool("Default", threadPoolSize);
    this.threadPools.put("Default", threadPool);
  }

  private int getThreadPoolSize()
  {
    return 30;
  }

  public MamResponse handleRequest(CmdbRequest request) {
    MamResponse response;
    if (request == null) {
      String message = "Can not process null request";
      this.log.error(message);
      throw new MamResponseException(message, null);
    }

    if (request.isSynchronic()) {
      response = processRequest(request);
    } else {
      submitRequest(request);
      response = new CmdbResponseImpl("Asynchronous Response: OK", request.getID(), request.getContext());
    }

    return response;
  }

  private MamResponse processRequest(CmdbRequest request) {
    registerServedRequest(request);

    CmdbContextRepository.push(request.getContext());
    try {
      FrameworkOperation operation = request.getOperation();

      if (needsResolving(operation)) {
        MamResponse localMamResponse1 = resolveAndExecuteOperation(request);

        return localMamResponse1;
      }
      Framework.getInstance().getQuotaManager().checkQuotas(request);

      CmdbCustomerID customerID = request.getCustomerID();

      CommonManager manager = getSubsystemManager(customerID, operation);

      StopSign.allowToContinue();

      String subsystemName = operation.getExecutionTaskQueueName();
      MamResponse response = createResponse(request, subsystemName);

      LocksActivator locksActivator = lock(manager, operation);
      try {
        operation.execute(manager, response);
      } finally {
        unlock(locksActivator);
      }

      if (response.isRedirected()) {
        response = CmdbApiFactory.createCMDBAPI().executeOperation(response.getRedirectedOperation(), request.getContext());
      }

      MamResponse localMamResponse2 = response;

      return localMamResponse2;
    }
    catch (StoppedException e)
    {
    }
    catch (CmdbException e)
    {
    }
    catch (InterruptedException e)
    {
    }
    catch (Throwable t)
    {
    }
    finally
    {
      CmdbContextRepository.pop();
      deregisterServedRequest();
    }
  }

  private MamResponse resolveAndExecuteOperation(CmdbRequest request) {
    FrameworkOperation operation = request.getOperation();

    if (operation instanceof CustomerAndCategoryOperation) {
      CustomerAndCategoryOperation op = (CustomerAndCategoryOperation)operation;
      op.resolveServiceName();
      return CmdbApiFactory.createCMDBAPI().executeOperation(operation, request.getContext());
    }

    if (operation instanceof ServerAndCategoryOperation) {
      ServerAndCategoryOperation op = (ServerAndCategoryOperation)operation;
      op.resolveServiceName();
      return CmdbApiFactory.createCMDBAPI(CmdbApi.RMI_TYPE).executeOperation(op, request.getContext());
    }

    return null;
  }

  private boolean needsResolving(FrameworkOperation operation) {
    return ((operation instanceof OpDestinationResolver) && (((OpDestinationResolver)operation).needsResolving()));
  }

  private void unlock(LocksActivator locksActivator) {
    locksActivator.unlock();
  }

  private LocksActivator lock(CommonManager manager, FrameworkOperation operation) throws Exception {
    operation.onAcquiringLock();
    CmdbLock lock = getOperationLock(manager, operation);

    LocksActivator locksActivator = new LocksActivator();
    locksActivator.addLock(new LocksActivator.Locking(this, manager, operation)
    {
      public void lock() throws Exception {
        RequestProcessor.access$100(this.this$0).acquire(this.val$manager, this.val$operation);
      }

      public void unlock() throws Exception {
        RequestProcessor.access$100(this.this$0).release(this.val$manager, this.val$operation);
      }

    });
    locksActivator.addLock(new LocksActivator.Locking(this, lock, operation)
    {
      public void lock() throws Exception {
        this.val$lock.lock(this.val$operation);
      }

      public void unlock() throws Exception {
        this.val$lock.unlock();
      }

    });
    locksActivator.lock();
    operation.onLockAcquired();

    return locksActivator;
  }

  public void executeRequestTimeoutCallbacks() {
    synchronized (this.servingThreads) {
      Iterator i$ = this.servingThreads.entrySet().iterator();
      while (true) { Thread thread;
        RequestInProgress requestInProgress;
        while (true) { Stack stack;
          while (true) { do { if (!(i$.hasNext())) break label231; Map.Entry entry = (Map.Entry)i$.next();
              thread = (Thread)entry.getKey();

              stack = (Stack)entry.getValue(); }
            while (stack == null); if (!(stack.empty()))
              break;
          }

          requestInProgress = (RequestInProgress)stack.lastElement();
          if (requestInProgress != null)
            break;
        }

        List callbacks = (List)this.requestTimeoutCallbacks.get(requestInProgress.getRequest().getCustomerID());
        label231: if (callbacks != null)
          for (Iterator i$ = callbacks.iterator(); i$.hasNext(); ) { RequestTimeoutCallback callback = (RequestTimeoutCallback)i$.next();
            try {
              callback.execute(thread, requestInProgress.getRequest().getOperation());
            } catch (Exception e) {
              this.log.error("Error executing callback (" + callback + ") for thread " + thread.getName(), e);
            }
          }
      }
    }
  }

  public BottlenecksHistory getBottleneckHistory()
  {
    return this.loadBalancer.getBottleneckHistory();
  }

  public void stopOperation(int operationID) {
    synchronized (this.servingThreads) { for (Iterator i$ = this.servingThreads.entrySet().iterator(); i$.hasNext(); ) {
        Map.Entry entry = (Map.Entry)i$.next();
        label137: Iterator i$ = ((Stack)entry.getValue()).iterator();
      }
    }
  }

  public void allocateThreadPool(CommonManager manager, int threadPoolSize)
  {
    synchronized (this.threadPools) {
      String threadPoolName = manager.getName();
      ThreadPoolExecutor pool = (ThreadPoolExecutor)this.threadPools.get(threadPoolName);
      if (pool == null) {
        pool = ThreadUtil.createTypicalThreadPool(threadPoolName, threadPoolSize);
        this.threadPools.put(threadPoolName, pool);
      }
    }
  }

  private void deregisterServedRequest()
  {
    Thread current = Thread.currentThread();
    Stack requests = (Stack)this.servingThreads.get(current);
    if (requests != null) {
      RequestInProgress req = (RequestInProgress)requests.pop();
      long time = System.currentTimeMillis();
      this.operationStatistics.gatherOperationTime(req.getRequest(), time - req.getTimestamp(), req.getTimestamp());

      if (requests.empty()) {
        this.servingThreads.remove(current);
        StopSign.clear();
      }
    }
  }

  private void registerServedRequest(CmdbRequest request) {
    Thread current = Thread.currentThread();
    Stack requests = (Stack)this.servingThreads.get(current);
    if (requests == null) {
      requests = new Stack();
      this.servingThreads.put(current, requests);
    }
    requests.push(new RequestInProgress(request));
  }

  private CmdbResponseException createCmdbResponseOnCmdbError(CmdbException e, CmdbRequest request) {
    if (e instanceof MamResponseException) throw e;
    String message = createErrorMessage(request, "\nCMDB Internal Error: Error while handling request", e);
    this.log.error(message, e);
    return new MamResponseException(message, e, request.getID());
  }

  private CmdbResponseException createCmdbResponseOnUnknownError(Throwable e, CmdbRequest request) {
    String message = createErrorMessage(request, "\nCMDB Internal Error: Unknown error while handling request", e);
    this.log.error(message, e);
    return new MamResponseException(message, e, request.getID());
  }

  private CmdbResponseException createCmdbResponseOnInterrupt(InterruptedException e, CmdbRequest request) {
    String message = createErrorMessage(request, "\nCMDB Internal Error: InterruptedException - another thread has interrupted the request thread for request", e);
    this.log.error(message, e);
    return new MamResponseException(message, e, request.getID());
  }

  private CmdbResponseException createCmdbResponseOnStop(StoppedException e, CmdbRequest request) {
    String message = createErrorMessage(request, "\nCMDB Internal Error: StoppedException - stop occurred for the request thread for request", e);
    this.log.error(message, e);
    return new MamResponseException(message, e, request.getID());
  }

  private String createErrorMessage(CmdbRequest request, String prefix, Throwable t) {
    return t.getMessage() + " : " + t.getClass() + " : " + prefix + ": " + request;
  }

  private Future<MamResponse> submitRequest(CmdbRequest request)
  {
    String managerName;
    ThreadPoolExecutor pool;
    CmdbContextRepository.push(request.getContext());
    try
    {
      FrameworkOperation operation = request.getOperation();
      CmdbCustomerID customerID = request.getCustomerID();
      try
      {
        ??? = getSubsystemManager(customerID, operation);
        managerName = ???.getName();
      } catch (CmdbException e) {
        throw createCmdbResponseOnCmdbError(e, request);
      } catch (Throwable t) {
        throw createCmdbResponseOnUnknownError(t, request);
      }
    } finally {
      CmdbContextRepository.pop();
    }

    Callable requestTask = new Callable(this, request) {
      public MamResponse call() throws Exception {
        try {
          return RequestProcessor.access$200(this.this$0, this.val$request);
        } catch (Exception e) {
          RequestProcessor.access$300(this.this$0).error("Async request processing error", e);
          throw e;
        }

      }

    };
    synchronized (this.threadPools) {
      pool = (ThreadPoolExecutor)this.threadPools.get(managerName);
      if (pool == null)
        pool = (ThreadPoolExecutor)this.threadPools.get("Default");

    }

    return pool.submit(requestTask);
  }

  private CmdbLock getOperationLock(CommonManager manager, FrameworkOperation operation) {
    if (operation instanceof CmdbUpdate)
      return manager.getLock().writeLock();

    return manager.getLock().readLock();
  }

  private MamResponse createResponse(CmdbRequest request, String subsystemName)
  {
    MamResponse response = new CmdbResponseImpl("N/A", request.getID(), request.getContext());
    response.setMessage(subsystemName + " Response");
    return response;
  }

  private CommonManager getSubsystemManager(CmdbCustomerID customerID, FrameworkOperation operation) {
    CommonManager manager;
    String subsystemName = operation.getExecutionTaskQueueName();

    if (operation instanceof FrameworkGlobalOperation) {
      manager = Framework.getInstance().getGlobalSubsystemManagers().getManager(subsystemName);
    } else {
      CustomerInstance customerInstance = Framework.getInstance().getInstanceManager().getInstance(customerID);
      manager = customerInstance.getManager(subsystemName);
    }

    if (manager == null) {
      throw new CmdbException("Null subsystem manager for name: " + subsystemName + " [Operation: " + operation + "]");
    }

    return manager;
  }

  private long getTimeout(CmdbRequest request)
  {
    long sessionTimeout;
    FrameworkOperation operation = request.getOperation();
    if (operation instanceof HasExplicitTimeout)
      sessionTimeout = ((HasExplicitTimeout)operation).getTimeout();
    else {
      sessionTimeout = this.defaultSessionTimeout;
    }

    return sessionTimeout;
  }

  private void setDefaultTimeout()
  {
    long timeoutInSec;
    SettingsReader settingsReader = Framework.getInstance().getGlobalSettings();

    if (settingsReader != null) {
      timeoutInSec = settingsReader.getInt("server.sync.session.timeout", 600);
    }
    else {
      CmdbLogFactory.getCMDBInfoLog().info("Unit Testing environment, using default session timeout");
      timeoutInSec = 600L;
    }

    this.defaultSessionTimeout = (timeoutInSec * 1000L);
    CmdbLogFactory.getCMDBInfoLog().info("Session timeout is set to " + timeoutInSec + " seconds");
  }

  private void dumpMemoryStat(IndentingDumper dumper) {
    dumper.append("\n");
    dumper.append("Heap memory:");
    dumper.increaseIndent();
    dumper.append(ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().toString());
    dumper.decreaseIndent();

    dumper.append("Non-Heap memory:");
    dumper.increaseIndent();
    dumper.append(ManagementFactory.getMemoryMXBean().getNonHeapMemoryUsage().toString());
    dumper.decreaseIndent();
  }

  public String getFormattedStatus() {
    return ServerSnapshotFormatter.toHtml(this);
  }

  public String dumpStatus() {
    IndentingDumper dumper = new IndentingDumper();

    dumpThreadPoolsStats(dumper);

    dumpThreads(dumper);

    dumpMemoryStat(dumper);

    this.loadBalancer.dumpStats(dumper);

    return dumper.toString();
  }

  private String dumpShortStatus() {
    IndentingDumper dumper = new IndentingDumper();

    dumpThreadPoolsStats(dumper);

    dumpThreads(dumper);

    dumpMemoryStat(dumper);

    return dumper.toString();
  }

  private void dumpThreadPoolsStats(IndentingDumper dumper) {
    synchronized (this.threadPools) {
      for (Iterator i$ = this.threadPools.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        dumpThreadPoolStats(dumper, (String)entry.getKey(), (ThreadPoolExecutor)entry.getValue());
      }
    }
  }

  private void dumpThreadPoolStats(IndentingDumper dumper, String name, ThreadPoolExecutor executor) {
    dumper.append(name + " thread pool:");
    dumper.increaseIndent();
    dumper.append("Core: " + executor.getCorePoolSize() + ", max: " + executor.getMaximumPoolSize() + ", executing: " + executor.getActiveCount() + ", queued: " + executor.getQueue().size() + ", size: " + executor.getPoolSize());

    dumper.decreaseIndent();
  }

  Map<String, ThreadPoolExecutor> getThreadPools() {
    return this.threadPools;
  }

  Map<Thread, Stack<RequestInProgress>> getServingThreads() {
    return this.servingThreads;
  }

  void dumpThreads(IndentingDumper dumper) {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean();

    dumper.append("\n");
    dumper.append(this.servingThreads.size() + " serving threads");

    long[] deadlocked = bean.findMonitorDeadlockedThreads();
    StringBuilder builder = new StringBuilder();
    if ((deadlocked != null) && (deadlocked.length != 0)) {
      ??? = deadlocked; int len$ = ???.length; for (int i$ = 0; i$ < len$; ++i$) { long id = ???[i$];
        builder.append(id).append(" ");
      }

      dumper.append("Deadlocked threads: " + builder);
    }
    dumper.append("\n");
    dumper.increaseIndent();

    synchronized (this.servingThreads) {
      Iterator i$ = this.servingThreads.entrySet().iterator();
      while (true) { Map.Entry entry;
        Thread thr;
        while (true) { if (!(i$.hasNext())) break label255; entry = (Map.Entry)i$.next();
          thr = (Thread)entry.getKey();

          if (thr != Thread.currentThread())
            break;
        }

        dumpThreadStatus(thr.getId(), dumper);

        dumper.increaseIndent();
        dumpRequests((Stack)entry.getValue(), dumper);
        dumper.decreaseIndent();

        label255: dumper.append("\n");
      }
    }

    dumper.decreaseIndent();
  }

  private void dumpThreadStatus(long threadID, IndentingDumper dumper) {
    ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
    ThreadInfo threadInfo = threadMXBean.getThreadInfo(threadID, 2147483647);

    if (threadInfo == null) {
      dumper.append("No thread info");
      return;
    }

    dumper.append(threadInfo.toString());

    dumper.increaseIndent();
    StackTraceElement[] stackTrace = threadInfo.getStackTrace();
    StackTraceElement[] arr$ = stackTrace; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { StackTraceElement stackTraceElement = arr$[i$];
      dumper.append(stackTraceElement.toString());
    }
    dumper.decreaseIndent();
  }

  void dumpRequests(Stack<RequestInProgress> requests, IndentingDumper dumper) {
    dumper.append("\n");
    dumper.append("Requests:");
    dumper.increaseIndent();
    for (Iterator i$ = requests.iterator(); i$.hasNext(); ) { RequestInProgress requestWrap = (RequestInProgress)i$.next();
      CmdbRequest request = requestWrap.getRequest();
      long startTime = requestWrap.getTimestamp();
      long elapsed = System.currentTimeMillis() - startTime;
      String formattedStartTime = this.dateFormatter.format(new Date(startTime));
      dumper.append("Time: started at " + formattedStartTime + ", elapsed: " + elapsed + " ms");
      dumper.append("Operation: " + request.getOperation());
      dumper.append("Subsystem: " + request.getOperation().getExecutionTaskQueueName());
      dumper.append("Context: " + request.getContext());
      dumper.append("Request (" + ((request.isSynchronic()) ? "sync" : "async") + ") - ID: " + request.getID() + ", message: " + request.getMessage());

      dumper.append("\n");
    }
    dumper.decreaseIndent();
  }

  public void shutdown() {
    this.timer.cancel();
    shutdownThreadPools();
    this.loadBalancer.shutdown();
    this.operationStatistics.shutdown();
  }

  private void shutdownThreadPools() {
    synchronized (this.threadPools) {
      for (Iterator i$ = this.threadPools.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        ((ThreadPoolExecutor)entry.getValue()).shutdown();
      }
    }
  }

  public void setLock(CommonManager manager) {
    this.loadBalancer.setSemaphore(manager);
    CmdbReadWriteLockFactory.setLock(manager);
  }

  public void setLock(CommonManager manager, int permits) {
    this.loadBalancer.setSemaphore(manager, permits);
    CmdbReadWriteLockFactory.setLock(manager);
  }

  public OperationStatistics getOperationStatistics() {
    return this.operationStatistics;
  }

  public void addRequestTimeoutCallback(CmdbCustomerID customerID, RequestTimeoutCallback callback) {
    synchronized (this.requestTimeoutCallbacks) {
      List callbacks = (List)this.requestTimeoutCallbacks.get(customerID);
      if (callbacks == null) {
        callbacks = new ArrayList(5);
        this.requestTimeoutCallbacks.put(customerID, callbacks);
      }
      callbacks.add(callback);
    }
  }

  public void removeRequestTimeoutCallback(CmdbCustomerID customerID, RequestTimeoutCallback callback) {
    synchronized (this.requestTimeoutCallbacks) {
      List callbacks = (List)this.requestTimeoutCallbacks.get(customerID);
      if (callbacks != null) break label30;
      return;

      label30: callbacks.remove(callback);
      if (!(callbacks.isEmpty())) break label60;
      label60: this.requestTimeoutCallbacks.remove(customerID);
    }
  }

  private class RequestTimeoutMonitor extends TimerTask
  {
    public void run()
    {
      boolean statusTaken = false;
      String status = null;

      long current = System.currentTimeMillis();
      synchronized (RequestProcessor.access$400(this.this$0)) {
        for (Iterator i$ = RequestProcessor.access$400(this.this$0).entrySet().iterator(); i$.hasNext(); ) { label38: RequestProcessor.RequestInProgress firstRequest;
          Map.Entry entry = (Map.Entry)i$.next();
          Thread thread = (Thread)entry.getKey();
          Stack requests = (Stack)entry.getValue();
          try
          {
            firstRequest = (RequestProcessor.RequestInProgress)requests.firstElement();
          } catch (Exception e) {
            break label38:
          }

          long start = firstRequest.getTimestamp();

          CmdbRequest request = firstRequest.getRequest();
          long timeout = RequestProcessor.access$500(this.this$0, request);
          if (current - start > timeout) {
            try {
              RequestProcessor.access$300(this.this$0).error("Interrupting thread " + thread.getName() + " due to timeout of " + timeout + " msec for root operation: " + request.getOperation());
              try
              {
                if (!(statusTaken))
                  status = RequestProcessor.access$600(this.this$0);
              }
              catch (Exception e) {
                RequestProcessor.access$300(this.this$0).error("Error dumping status while handling timeout of root operation for thread " + thread.getName(), e);
              }
              finally {
                statusTaken = true;
              }

              List callbacks = (List)RequestProcessor.access$700(this.this$0).get(request.getCustomerID());
              if (callbacks != null)
                for (Iterator i$ = callbacks.iterator(); i$.hasNext(); ) { RequestTimeoutCallback callback = (RequestTimeoutCallback)i$.next();
                  try {
                    callback.execute(thread, ((RequestProcessor.RequestInProgress)((Stack)entry.getValue()).lastElement()).getRequest().getOperation());
                  }
                  catch (Exception e) {
                    RequestProcessor.access$300(this.this$0).error("Error executing callback (" + callback + ") while handling timeout of root operation for thread " + thread.getName(), e);
                  }
                }

            }
            catch (Exception callbacks)
            {
              RequestProcessor.access$300(this.this$0).error("Error while handling timeout of root operation for thread " + thread.getName(), e);
            }

            StopSign.set(thread);
          }
        }

        if (status != null)
          RequestProcessor.access$300(this.this$0).error(status);
      }
    }
  }

  static class RequestInProgress
  {
    private CmdbRequest request;
    private long timestamp;

    RequestInProgress(CmdbRequest request)
    {
      this.request = request;
      this.timestamp = System.currentTimeMillis();
    }

    CmdbRequest getRequest() {
      return this.request;
    }

    long getTimestamp() {
      return this.timestamp;
    }
  }
}