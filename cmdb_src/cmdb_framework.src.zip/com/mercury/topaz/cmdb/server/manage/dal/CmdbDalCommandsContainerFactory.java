package com.mercury.topaz.cmdb.server.manage.dal;

public class CmdbDalCommandsContainerFactory
{
  public static CmdbDalCommandsContainer create()
  {
    return new CmdbDalCommandsContainerImpl();
  }
}