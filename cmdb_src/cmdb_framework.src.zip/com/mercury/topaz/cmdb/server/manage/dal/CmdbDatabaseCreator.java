package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.db.context.AdminDBContextFactory;
import com.mercury.infra.flowmngr.ParamRepository;
import com.mercury.infra.flowmngr.model.SqlTask;
import com.mercury.infra.utils.db.pools.ConnectionManager;
import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.environment.Environment;
import com.mercury.infra.utils.io.FileUtils;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.settings.parameters.SettingsReaderFactory;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class CmdbDatabaseCreator
{
  private static final String DB_TYPE = "dbType";
  private static final String DB_SERVER = "dbServer";
  private static final String DB_SID = "dbSID";
  private static final String DB_TABLESPACE = "dbTablespace";
  private static final String DB_SCHEMA = "dbSchema";
  private static final String DB_ADMIN_PASSWORD = "dbPassword";
  private static final String DEFAULT_DB_TYPE = "oracle";
  private static final String DEFAULT_DB_SERVER = "localhost";
  private static final String DEFAULT_DB_SID = "ucmdb";
  private static final String DEFAULT_DB_TABLESPACE = "CMDBDATA";
  private static final String DEFAULT_DB_SCHEMA = "tests_cmdb";
  private static final String HISTORY_SCHEMA_SUFFIX = "_hist";
  private static final String[] ADDITIONAL_PROPS = { "adminUserName", "adminPassword", "defaultTablespace", "temporaryTablespace" };
  private final Properties additionalProps;
  private final DbContext dbContext;
  private final DbContext historyDbContext;

  public CmdbDatabaseCreator()
    throws Exception
  {
    SettingsReader settingsReader = SettingsReaderFactory.createTestsReader();
    this.dbContext = ConnectionPoolFactory.createCmdbDbContext(settingsReader);
    this.historyDbContext = ConnectionPoolFactory.createHistoryDbContext(settingsReader);
    this.additionalProps = new Properties();
    String[] arr$ = ADDITIONAL_PROPS; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String prop = arr$[i$];
      this.additionalProps.setProperty(prop, settingsReader.getString(prop, ""));
    }
    ParamRepository.getInstance().setParam("db_additional_props", this.additionalProps);
  }

  private void create() throws Exception {
    File dbScriptsDir = new File(System.getProperty("user.dir"), "../cmdb/src/main/static-files/cmdb/dbscripts");

    dropSchemaIfExists(this.dbContext);
    ParamRepository.getInstance().setParam("db_context", this.dbContext);
    createSchema(dbScriptsDir);
    createCmdbTables(dbScriptsDir);
    System.out.println("Created schema " + this.dbContext.getDbName() + " on " + this.dbContext.getDbTypeEnum() + " on " + this.dbContext.getServer());

    dropSchemaIfExists(this.historyDbContext);
    ParamRepository.getInstance().setParam("db_context", this.historyDbContext);
    createSchema(dbScriptsDir);
    createHistoryTables(dbScriptsDir);
    System.out.println("Created history schema " + this.historyDbContext.getDbName() + " on " + this.historyDbContext.getDbTypeEnum() + " on " + this.historyDbContext.getServer());
  }

  private void createSchema(File dbScriptsDir)
    throws IOException
  {
    File scriptFile;
    if (DBType.isOracle(this.dbContext.getDbTypeEnum()))
      scriptFile = new File(dbScriptsDir, "oracle/oracle-db-creation.sql");
    else
      scriptFile = new File(dbScriptsDir, "ms/mssql-db-creation.sql");

    runDBScript(scriptFile, true);
  }

  private void createCmdbTables(File dbScriptsDir) throws IOException
  {
    File scriptFile;
    if (DBType.isOracle(this.dbContext.getDbTypeEnum()))
      scriptFile = new File(dbScriptsDir, "oracle/create_cm_tables_cmdb.sql");
    else
      scriptFile = new File(dbScriptsDir, "ms/create_cm_tables_cmdb_ms.sql");

    runDBScript(scriptFile, false);
  }

  private void createHistoryTables(File dbScriptsDir) throws IOException
  {
    File scriptFile;
    if (DBType.isOracle(this.dbContext.getDbTypeEnum()))
      scriptFile = new File(dbScriptsDir, "oracle/create_history_tables_cmdb.sql");
    else
      scriptFile = new File(dbScriptsDir, "ms/create_cm_tables_cmdb_history_ms.sql");

    runDBScript(scriptFile, false);
  }

  private void runDBScript(File scriptFile, boolean connectAsAdmin) throws IOException {
    SqlTask sqlTask = new SqlTask();
    sqlTask.setShouldConnectAsAdmin(connectAsAdmin);
    String relativeTempFileName = copyFileToMercHome(scriptFile);
    sqlTask.setSqlFileName(relativeTempFileName);
    sqlTask.setDbArgPrefix("");
    sqlTask.execute();
  }

  private static String copyFileToMercHome(File file) throws IOException {
    String mercHome = Environment.getInstance().getEnvironmentHomePath();
    String tempFileName = "script.sql";
    File tempFile = new File(mercHome, tempFileName);
    FileUtils.copyFile(file, tempFile);
    return tempFileName;
  }

  private void dropSchemaIfExists(DbContext dbContext) throws SQLException {
    Connection privateConnection = null;
    PreparedStatement preparedStatement = null;
    try {
      String dropSchemaSql;
      privateConnection = ConnectionManager.getPrivateConnection(AdminDBContextFactory.createAdminDbContext(dbContext, this.additionalProps));

      if (DBType.isOracle(dbContext.getDbTypeEnum())) {
        dropSchemaSql = "drop user " + dbContext.getUserName() + " cascade";
      } else if (DBType.isMsSql(dbContext.getDbTypeEnum())) {
        String disconnectUsers = "ALTER DATABASE " + dbContext.getDbName() + " SET SINGLE_USER WITH ROLLBACK IMMEDIATE";
        preparedStatement = privateConnection.prepareStatement(disconnectUsers);
        preparedStatement.execute();
        dropSchemaSql = "drop database " + dbContext.getDbName();
      } else {
        throw new CmdbException("Unsupported DB Type " + dbContext.getDbTypeEnum());
      }
      preparedStatement = privateConnection.prepareStatement(dropSchemaSql);
      preparedStatement.execute();
    }
    catch (Exception e) {
    }
    finally {
      if (preparedStatement != null)
        preparedStatement.close();

      if (privateConnection != null)
        privateConnection.close();
    }
  }

  private static Properties loadProperties(File settingsFile) throws Exception
  {
    if (!(settingsFile.exists()))
      throw new Exception("File " + settingsFile + " not found");

    Properties settings = new Properties();
    settings.load(new FileInputStream(settingsFile));
    return settings;
  }

  private static Properties createPropertiesForConf(Properties settings) {
    Properties confProps = new Properties();
    String dbTypeString = settings.getProperty("dbType");
    boolean isOracle = dbTypeString.toLowerCase().contains("oracle");
    if (isOracle) {
      confProps.setProperty("dal.datamodel.db.type", DBType.ORACLE.toString());
      confProps.setProperty("dal.datamodel.port", "1521");
      confProps.setProperty("dal.datamodel.sid", settings.getProperty("dbSID"));
      confProps.setProperty("dal.datamodel.user.name", settings.getProperty("dbSchema"));
      confProps.setProperty("dal.datamodel.password", "cmdb");
      confProps.setProperty("adminUserName", "system");
      confProps.setProperty("adminPassword", settings.getProperty("dbPassword"));
      confProps.setProperty("defaultTablespace", settings.getProperty("dbTablespace"));
      confProps.setProperty("temporaryTablespace", "TEMP");
    } else {
      confProps.setProperty("dal.datamodel.db.type", DBType.MS_SQL.toString());
      confProps.setProperty("dal.datamodel.port", "1433");
      confProps.setProperty("dal.datamodel.user.name", "sa");
      confProps.setProperty("dal.datamodel.password", settings.getProperty("dbPassword"));
    }
    confProps.setProperty("dal.datamodel.host.name", settings.getProperty("dbServer"));
    confProps.setProperty("dal.datamodel.server", settings.getProperty("dbServer"));
    confProps.setProperty("dal.datamodel.db.name", settings.getProperty("dbSchema"));

    copyPropertyWithSuffix(confProps, "dal.history.db.name", "dal.datamodel.db.name", "_hist");

    copyProperty(confProps, "dal.history.db.type", "dal.datamodel.db.type");
    copyProperty(confProps, "dal.history.host.name", "dal.datamodel.host.name");
    copyProperty(confProps, "dal.history.password", "dal.datamodel.password");
    copyProperty(confProps, "dal.history.port", "dal.datamodel.port");
    copyProperty(confProps, "dal.history.server", "dal.datamodel.server");
    copyProperty(confProps, "dal.history.sid", "dal.datamodel.sid");
    copyPropertyWithSuffix(confProps, "dal.history.user.name", "dal.datamodel.user.name", (isOracle) ? "_hist" : "");

    return confProps;
  }

  private static void copyProperty(Properties props, String target, String source) {
    String value = props.getProperty(source);
    if (value != null)
      props.setProperty(target, value);
  }

  private static void copyPropertyWithSuffix(Properties props, String target, String source, String suffix)
  {
    String value = props.getProperty(source);
    if (value != null)
      props.setProperty(target, value + suffix);
  }

  private static void storePropertiesFile(Properties properties, File file) throws IOException
  {
    file.getParentFile().mkdirs();
    FileOutputStream stream = new FileOutputStream(file);
    try {
      properties.store(stream, "Auto-generated by CmdbDatabaseCreator");
    } finally {
      stream.close();
    }
  }

  private static Properties getPropertiesFromEnvironment() {
    return System.getProperties();
  }

  private static void validateProperties(Properties props) {
    if (props.getProperty("dbType") == null)
      props.setProperty("dbType", "oracle");

    if (props.getProperty("dbServer") == null)
      props.setProperty("dbServer", "localhost");

    if (props.getProperty("dbSchema") == null)
      props.setProperty("dbSchema", "tests_cmdb");

    if (props.getProperty("dbSID") == null)
      props.setProperty("dbSID", "ucmdb");

    if (props.getProperty("dbTablespace") == null)
      props.setProperty("dbTablespace", "CMDBDATA");

    if (props.getProperty("dbPassword") == null)
      throw new RuntimeException("DB admin password (-DdbPassword=) is not specified");
  }

  private static Properties interrogateUser() throws IOException
  {
    Properties settings = new Properties();
    String dbServer = readInput("Enter the name of the server", "localhost");
    settings.setProperty("dbServer", dbServer);
    String dbType = readInput("Enter the server type (oracle|sql)", "oracle");
    boolean isOracle = dbType.equals("oracle");
    if (isOracle)
      settings.setProperty("dbType", "Oracle");
    else
      settings.setProperty("dbType", "SQL Server");

    if (isOracle) {
      String sid = readInput("Enter the SID of the instance", "ucmdb");
      settings.setProperty("dbSID", sid);
      String tableSpace = readInput("Enter the tablespace to create the schema in", "CMDBDATA");
      settings.setProperty("dbTablespace", tableSpace);
    }
    String password = readInput("Enter the password of the system user", null);
    settings.setProperty("dbPassword", password);
    String dbSchema = readInput("Enter the name of the schema", "tests_cmdb");
    settings.setProperty("dbSchema", dbSchema);
    return settings;
  }

  private static String readInput(String prompt, String defaultValue) throws IOException {
    String value = null;
    while ((value == null) || (value.length() == 0)) {
      if (defaultValue != null)
        System.out.print(prompt + " [" + defaultValue + "]: ");
      else
        System.out.print(prompt + ": ");

      BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
      value = input.readLine();
      if ((value.length() == 0) && (defaultValue != null))
        value = defaultValue;
    }

    return value;
  }

  private static Mode determineMode() {
    String modeName = System.getProperty("mode");
    if ((modeName == null) || (modeName.length() == 0))
      return Mode.INTERACTIVE;

    if (modeName.equals("auto"))
      return Mode.AUTOMATIC;
    if (modeName.equals("conf"))
      return Mode.CREATE_CONF;
    if (modeName.equals("db"))
      return Mode.CREATE_DB;

    throw new RuntimeException("Mode " + modeName + " is unrecognized");
  }

  public static void main(String[] args) throws Exception
  {
    File confDir;
    Properties props;
    Mode mode = determineMode();
    if (mode != Mode.AUTOMATIC)
      System.out.println("Welcome to the interactive CMDB tests setup");

    String confDirName = System.getProperty("confDir");

    if (confDirName != null) {
      confDir = new File(confDirName);
    } else {
      if (mode == Mode.AUTOMATIC)
        throw new RuntimeException("Config directory (-DconfDir=) is not defined");

      confDir = new File(readInput("Enter the directory for configuration files", "C:\\hp\\UCMDB\\Tests"));
    }
    File confFile = new File(confDir, "cmdb.conf");
    System.setProperty("merc.home", confDir.getPath());

    System.setProperty("cmdbConfPath", confFile.getAbsolutePath());
    File propsFile = new File(confDir, "dbConfig.properties");

    switch (1.$SwitchMap$com$mercury$topaz$cmdb$server$manage$dal$CmdbDatabaseCreator$Mode[mode.ordinal()])
    {
    case 1:
      props = getPropertiesFromEnvironment();
      break;
    case 2:
      props = interrogateUser();
      storePropertiesFile(props, propsFile);
      break;
    case 3:
    case 4:
      props = loadProperties(propsFile);
      break;
    default:
      throw new RuntimeException("Mode undefined");
    }
    validateProperties(props);
    Properties confProps = createPropertiesForConf(props);
    storePropertiesFile(confProps, confFile);
    if (mode != Mode.CREATE_CONF)
      new CmdbDatabaseCreator().create();

    if (mode != Mode.AUTOMATIC)
      readInput("Press Enter to finish", "Enter");
  }

  private static enum Mode
  {
    INTERACTIVE, AUTOMATIC, CREATE_CONF, CREATE_DB;

    public static final Mode[] values()
    {
      return ((Mode[])$VALUES.clone());
    }
  }
}