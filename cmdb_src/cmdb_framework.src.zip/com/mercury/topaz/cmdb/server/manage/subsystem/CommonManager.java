package com.mercury.topaz.cmdb.server.manage.subsystem;

import com.mercury.topaz.cmdb.server.base.itc.lock.Lockable;

public abstract interface CommonManager extends Lockable
{
  public abstract void startUp();

  public abstract void shutdown();

  public abstract String getName();
}