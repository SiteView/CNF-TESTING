package com.mercury.topaz.cmdb.server.manage.quota.task;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.base.itc.schedule.PeriodicTaskable;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.API;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl.QuotaUpdateCollectCounts;

public class QuotaPeriodicTask
  implements PeriodicTaskable
{
  private int _interval;
  private CmdbApi _cmdbApi;

  public QuotaPeriodicTask(int intervalInSec)
  {
    setInterval(intervalInSec);
    setCmdbApi(CmdbApiFactory.createCMDBAPI(CmdbApi.LOCAL_TYPE));
  }

  public int getIntervalInSec() {
    return this._interval;
  }

  public void execute() {
    QuotaUpdateCollectCounts quotaUpdateCollectCounts = new QuotaUpdateCollectCounts();

    getCmdbApi().executeCMDBOperation(quotaUpdateCollectCounts, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT, false);
  }

  public Object getTaskId() {
    return "quota periodic task";
  }

  private void setInterval(int interval)
  {
    this._interval = interval;
  }

  private CmdbApi getCmdbApi() {
    return this._cmdbApi;
  }

  private void setCmdbApi(CmdbApi cmdbApi) {
    this._cmdbApi = cmdbApi;
  }
}