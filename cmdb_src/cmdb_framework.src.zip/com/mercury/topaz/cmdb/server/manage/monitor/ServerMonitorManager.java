package com.mercury.topaz.cmdb.server.manage.monitor;

import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;

public abstract interface ServerMonitorManager extends GlobalSubsystemManager
{
  public abstract String getServerStatus();

  public abstract String getFormattedServerStatus();

  public abstract String dumpServerSnapshotToLog(String paramString1, String paramString2);

  public abstract String dumpOperationStatistics();

  public abstract void resetOperationStatistics();

  public abstract void executeRequestTimeoutCallbacks();

  public abstract void stopOperation(int paramInt);
}