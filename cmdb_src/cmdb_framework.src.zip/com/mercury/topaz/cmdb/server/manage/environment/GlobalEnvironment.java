package com.mercury.topaz.cmdb.server.manage.environment;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.settings.parameters.SettingsReaderFactory;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher.JMSPublisher;

public class GlobalEnvironment
{
  private JMSPublisher _jmsPublisher;
  private SettingsReader _settingsReader;

  public GlobalEnvironment()
  {
    setSettingsReader(SettingsReaderFactory.createGlobalReader("server"));
  }

  private void setSettingsReader(SettingsReader settingsReader)
  {
    this._settingsReader = settingsReader;
  }

  public SettingsReader getSettingsReader() {
    return this._settingsReader;
  }

  public JMSPublisher getJmsPublisher() {
    return this._jmsPublisher;
  }

  public void setJmsPublisher(JMSPublisher jmsPublisher) {
    if (jmsPublisher == null)
      throw new IllegalArgumentException("jms publisher is null !!!");

    this._jmsPublisher = jmsPublisher;
  }
}