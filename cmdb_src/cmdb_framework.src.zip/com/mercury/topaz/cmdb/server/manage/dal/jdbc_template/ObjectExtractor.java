package com.mercury.topaz.cmdb.server.manage.dal.jdbc_template;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

class ObjectExtractor
  implements ResultSetExtractor
{
  public Object extractData(CmdbDalResultSet rs)
    throws SQLException
  {
    if (!(rs.next())) {
      throw new CmdbDalException("Query returned zero rows");
    }

    int columnCount = rs.getMetaData().getColumnCount();
    if (columnCount != 1) {
      throw new CmdbDalException("Result set has " + columnCount + " columns, expected 1");
    }

    return rs.getObject(1);
  }
}