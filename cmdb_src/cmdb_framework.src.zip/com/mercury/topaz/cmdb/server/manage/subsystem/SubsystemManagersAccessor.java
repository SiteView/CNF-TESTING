package com.mercury.topaz.cmdb.server.manage.subsystem;

public abstract interface SubsystemManagersAccessor
{
  public abstract CommonManager getManager(String paramString);
}