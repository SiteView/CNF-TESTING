package com.mercury.topaz.cmdb.server.manage.comm;

public class DummyCommunicationManager
  implements CommunicationManager
{
  public void bindService(String serviceName)
  {
  }

  public void shutdown()
  {
  }

  public void startUp()
  {
  }

  public void unbindService(String serviceName)
  {
  }
}