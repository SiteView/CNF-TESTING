package com.mercury.topaz.cmdb.server.manage.service.config.impl;

import com.mercury.topaz.cmdb.server.manage.service.config.ServiceTaskConfig;
import org.jibx.runtime.IMarshallable;
import org.jibx.runtime.IUnmarshallable;

class ServiceTaskConfigImpl
  implements ServiceTaskConfig, IUnmarshallable, IMarshallable
{
  private String _taskFactoryClass;
  private String _taskFactoryMethod = "createTask";
  private String _managerFactoryClass;
  private String _managerFactoryMethod = "createSubsystemManager";
  private int _totalThreadsNum;
  public static final String JiBX_bindingList = "|com.mercury.topaz.cmdb.server.manage.service.config.impl.JiBX_bindingFactory|";

  public String getTaskFactoryClass()
  {
    return this._taskFactoryClass;
  }

  public String getTaskFactoryMethod() {
    return this._taskFactoryMethod;
  }

  public String getManagerFactoryClass() {
    return this._managerFactoryClass;
  }

  public String getManagerFactoryMethod() {
    return this._managerFactoryMethod;
  }

  public int getTotalThreadsNum() {
    return this._totalThreadsNum;
  }

  void setTaskFactoryClass(String taskFactoryClass) {
    if ((taskFactoryClass == null) || (taskFactoryClass.length() == 0))
      throw new IllegalArgumentException("Task Factory Class cannot be null or empty !!!");

    this._taskFactoryClass = taskFactoryClass;
  }

  void setTaskFactoryMethod(String taskFactoryMethod) {
    if ((taskFactoryMethod != null) && (taskFactoryMethod.length() > 0))
      this._taskFactoryMethod = taskFactoryMethod;
  }

  void setManagerFactoryClass(String managerFactoryClass)
  {
    if ((managerFactoryClass == null) || (managerFactoryClass.length() == 0))
      throw new IllegalArgumentException("Manager Factory Class cannot be null or empty !!!");

    this._managerFactoryClass = managerFactoryClass.trim();
  }

  void setManagerFactoryMethod(String managerFactoryMethod) {
    if ((managerFactoryMethod != null) && (managerFactoryMethod.length() != 0))
      this._managerFactoryMethod = managerFactoryMethod.trim();
  }

  void setTotalThreadsNum(int totalThreadsNum)
  {
    if ((totalThreadsNum < 1) || (totalThreadsNum > 100))
      throw new IllegalArgumentException("number of threads must be in range >0 and <100");

    this._totalThreadsNum = totalThreadsNum;
  }
}