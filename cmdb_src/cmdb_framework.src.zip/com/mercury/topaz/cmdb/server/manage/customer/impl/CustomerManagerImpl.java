package com.mercury.topaz.cmdb.server.manage.customer.impl;

import com.mercury.topaz.cmdb.server.base.ha.controller.service.impl.ControllerServiceInstance;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.impl.ControllerServicesFactory;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadMultiWrite;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.customer.CustomerManager;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.manage.instance.CustomerInstance;
import com.mercury.topaz.cmdb.server.manage.instance.InstanceManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractGlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbContextRepository;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;

public class CustomerManagerImpl extends AbstractGlobalSubsystemManager
  implements CustomerManager, MultiReadMultiWrite
{
  private InstanceManager _instanceManager;

  public CustomerManagerImpl(InstanceManager instanceManager, GlobalEnvironment globalEnvironment)
  {
    super(globalEnvironment);
    setInstanceManager(instanceManager);
    Framework.getInstance().setLock(this, 0);
  }

  public void startUp() {
  }

  public void shutdown() {
  }

  public void startupService(CmdbCustomerID customerID, String serviceName) {
    CustomerInstance instance = getInstanceManager().createInstanceForService(customerID, serviceName);
    ControllerServiceInstance serviceInstance = ControllerServicesFactory.getInstance().createServiceInstance(serviceName, instance);

    instance.addServiceInstance(serviceName, serviceInstance);
    CmdbContext localContext = CmdbContextFactory.createCmdbContext(customerID, CmdbContextRepository.get().getCallerApplicationName());
    CmdbContextRepository.push(localContext);
    try {
      serviceInstance.startUp();
    }
    catch (RuntimeException e) {
      throw e;
    } finally {
      CmdbContextRepository.pop();
    }
  }

  public void shutdownService(CmdbCustomerID customerID, String serviceName) {
    getInstanceManager().destroyInstanceForService(customerID, serviceName);
  }

  private InstanceManager getInstanceManager() {
    return this._instanceManager;
  }

  private void setInstanceManager(InstanceManager instanceManager) {
    this._instanceManager = instanceManager;
  }

  public String getName() {
    return "Customer Management Task";
  }
}