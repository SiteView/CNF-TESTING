package com.mercury.topaz.cmdb.server.manage.dal;

public abstract interface CmdbDalCommand<RESULT>
{
  public abstract CmdbDalCommandResult<RESULT> execute();
}