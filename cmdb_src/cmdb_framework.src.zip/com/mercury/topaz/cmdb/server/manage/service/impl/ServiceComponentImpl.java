package com.mercury.topaz.cmdb.server.manage.service.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.service.ServiceComponent;
import com.mercury.topaz.cmdb.server.manage.service.config.ServiceConfig;
import com.mercury.topaz.cmdb.server.manage.service.config.ServiceDependency;
import com.mercury.topaz.cmdb.server.manage.service.config.ServiceTaskConfig;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersContainer;
import com.mercury.topaz.cmdb.server.manage.subsystem.observer.SubsystemManagersObserver;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

public class ServiceComponentImpl
  implements ServiceComponent
{
  private static final Class<?>[] CREATE_SUBSYSTEM_MANAGER_SIGNATURE_PARAMS = { LocalEnvironment.class };
  private final ServiceConfig _serviceConfig;
  private final Stack<SubsystemManager> managers = new Stack();

  public ServiceComponentImpl(ServiceConfig serviceConfig)
  {
    this._serviceConfig = serviceConfig;
  }

  public void startUp(LocalEnvironment localEnvironment, Collection<SubsystemManagersObserver> observers, SubsystemManagersContainer container)
  {
    createSubsystemManagers(localEnvironment, container);
    try
    {
      startupSubsystemManagers(observers);
    }
    catch (RuntimeException re)
    {
      CmdbLogFactory.getStartupLog().error("error occured during startup ,details:", re);
      shutdown(container);
      throw re;
    }
  }

  public void shutdown(SubsystemManagersContainer container) {
    shutdownSubsystemManagers(container);
  }

  private void shutdownSubsystemManagers(SubsystemManagersContainer container) {
    while (!(this.managers.isEmpty())) {
      SubsystemManager manager = (SubsystemManager)this.managers.pop();
      try {
        manager.shutdown();
      } catch (Throwable t) {
        CmdbLogFactory.getStartupLog().error("error occured in manager [" + manager.getName() + "] during shutdown ,details:", t);
      }
      container.removeManager(manager);
    }
  }

  private void startupSubsystemManagers(Collection<SubsystemManagersObserver> observers) {
    for (Iterator i$ = this.managers.iterator(); i$.hasNext(); ) { SubsystemManagersObserver observer;
      SubsystemManager manager = (SubsystemManager)i$.next();
      for (Iterator i$ = observers.iterator(); i$.hasNext(); ) { observer = (SubsystemManagersObserver)i$.next();
        observer.preStartup(manager);
      }

      manager.startUp();

      for (i$ = observers.iterator(); i$.hasNext(); ) { observer = (SubsystemManagersObserver)i$.next();
        observer.postStartup(manager);
      }
    }
  }

  private void createSubsystemManagers(LocalEnvironment localEnvironment, SubsystemManagersContainer container) {
    List configs = this._serviceConfig.getServiceTasksConfig();
    for (Iterator i$ = configs.iterator(); i$.hasNext(); ) { ServiceTaskConfig config = (ServiceTaskConfig)i$.next();
      SubsystemManager subsystemManager = createSubsystemManager(config, localEnvironment);

      int permits = getPermits(config);
      Framework.getInstance().setLock(subsystemManager, permits);

      this.managers.push(subsystemManager);
      container.addManager(subsystemManager);
    }
  }

  private int getPermits(ServiceTaskConfig config) {
    return ((config != null) ? config.getTotalThreadsNum() : 0);
  }

  private SubsystemManager createSubsystemManager(ServiceTaskConfig serviceTaskConfig, LocalEnvironment localEnvironment)
  {
    Class managerFactoryClazz;
    Method managerFactoryMethod;
    String managerFactoryClassName = serviceTaskConfig.getManagerFactoryClass();
    try {
      managerFactoryClazz = loadClassName(managerFactoryClassName);
    } catch (ClassNotFoundException e) {
      throw new CmdbException("Cannot find manager factory class: " + managerFactoryClassName, e);
    }

    String managerFactoryMethodName = serviceTaskConfig.getManagerFactoryMethod();
    try {
      managerFactoryMethod = managerFactoryClazz.getMethod(managerFactoryMethodName, CREATE_SUBSYSTEM_MANAGER_SIGNATURE_PARAMS);
    }
    catch (NoSuchMethodException e) {
      throw new CmdbException("subsystem manager factory class [" + managerFactoryClassName + "] has no method [" + managerFactoryMethodName + "]", e);
    }

    try
    {
      Object factoryInstance = managerFactoryClazz.newInstance();
      return ((SubsystemManager)managerFactoryMethod.invoke(factoryInstance, new Object[] { localEnvironment }));
    } catch (Exception e) {
      throw new CmdbException("cannot create subsystem manager by factory [" + managerFactoryClassName + "] due to error", e);
    }
  }

  private Class<?> loadClassName(String classNameToLoad) throws ClassNotFoundException
  {
    return super.getClass().getClassLoader().loadClass(classNameToLoad);
  }

  public String getName() {
    return getServiceConfig().getServiceName();
  }

  public String getControllerServiceName() {
    return getServiceConfig().getControllerServiceName();
  }

  public List<ServiceDependency> getDependencies()
  {
    return getServiceConfig().getDependencies();
  }

  private ServiceConfig getServiceConfig() {
    return this._serviceConfig;
  }
}