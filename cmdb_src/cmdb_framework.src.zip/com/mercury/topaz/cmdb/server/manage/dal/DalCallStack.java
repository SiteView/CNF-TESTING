package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import java.util.EmptyStackException;
import java.util.Stack;

public class DalCallStack
{
  private static ThreadLocal<Stack<DalCallMetadata>> callStack = new ThreadLocal()
  {
    protected Stack<DalCallMetadata> initialValue() {
      return new Stack();
    }
 } ;
  private static Log logger = LogFactory.getEasyLog(DalCallStack.class);

  public static void push(CmdbDalCommand<?> command) {
    push(new DalCallMetadata(command));
  }

  private static void push(DalCallMetadata metadata) {
    if (logger.isInfoEnabled())
      LogUtil.info(logger, "Executing: " + metadata.toShortString());

    ((Stack)callStack.get()).push(metadata);
  }

  private static DalCallMetadata peek() {
    if (((Stack)callStack.get()).empty()) {
      return null;
    }

    return ((DalCallMetadata)((Stack)callStack.get()).peek());
  }

  public static void logStatement(String statement) {
    if (logger.isInfoEnabled())
      LogUtil.info(logger, "Executing statement " + statement);
  }

  public static DalCallMetadata get()
  {
    try {
      return ((DalCallMetadata)((Stack)callStack.get()).peek());
    } catch (EmptyStackException e) {
      throw new RuntimeException("Coding error. The thread-local DAL call metadata is not initialized.");
    }
  }

  public static void pop(Throwable t) {
    DalCallMetadata metadata = peek();
    if (metadata == null) {
      return;
    }

    metadata = (DalCallMetadata)((Stack)callStack.get()).pop();
    if (t != null) {
      String msg = "Failed to execute " + metadata.toString();
      LogUtil.error(logger, msg, t);
      return;
    }

    if (logger.isInfoEnabled())
      LogUtil.info(logger, "Executed: " + metadata.toString());
  }

  public static int getDepth()
  {
    return ((Stack)callStack.get()).size();
  }
}