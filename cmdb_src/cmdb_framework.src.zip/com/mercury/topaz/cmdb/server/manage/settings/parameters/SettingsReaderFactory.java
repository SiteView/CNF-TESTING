package com.mercury.topaz.cmdb.server.manage.settings.parameters;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.cfg.impl.PropertiesFileSettingsLoader;
import com.mercury.topaz.cmdb.server.manage.settings.ParametersException;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Global;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class SettingsReaderFactory
{
  public static final boolean fileSettings = ("file".equals(System.getProperty("cmdbSettingsType"))) || (System.getProperty("cmdbConfPath") != null);

  public static SettingsReader createGlobalReader(String callerApp)
    throws ParametersException
  {
    return createContextsCustomerReader(FrameworkConstants.Customer.Global.ID.getID());
  }

  public static SettingsReader createCustomerReader(int customerID, String callerApp) throws ParametersException {
    return createContextsCustomerReader(customerID);
  }

  private static SettingsReader createContextsCustomerReader(int customerID) throws ParametersException {
    if (fileSettings)
      return createTestsReader();

    return new SystemParametersReader(customerID);
  }

  public static SettingsReader createTestsReader()
  {
    return new PropertiesFileSettingsLoader().loadSettingsReader();
  }
}