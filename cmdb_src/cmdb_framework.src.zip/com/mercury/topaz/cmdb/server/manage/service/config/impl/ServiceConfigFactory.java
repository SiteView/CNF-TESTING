package com.mercury.topaz.cmdb.server.manage.service.config.impl;

import com.mercury.topaz.cmdb.server.manage.service.config.ServicesConfig;

public class ServiceConfigFactory
{
  public static ServicesConfig createServicesConfig()
  {
    return new ServicesConfigImpl();
  }
}