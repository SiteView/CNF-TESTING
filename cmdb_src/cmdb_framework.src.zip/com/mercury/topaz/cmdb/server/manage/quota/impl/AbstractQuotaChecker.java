package com.mercury.topaz.cmdb.server.manage.quota.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaCheckResponse;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import com.mercury.topaz.cmdb.shared.manage.quota.exception.CmdbQuotaException;
import com.mercury.topaz.cmdb.shared.manage.quota.impl.QuotaFactory;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

abstract class AbstractQuotaChecker
  implements QuotaChecker
{
  private Map<String, QuotaCount> serversQuotasAndCounts;
  private Map<CmdbCustomerID, CustomerQuotasAndCounts> customersQuotasAndCounts;
  private Map<String, String> customerToServerQuotaName;

  public AbstractQuotaChecker()
  {
    setServersQuotasAndCounts(new HashMap());
    setCustomersQuotasAndCounts(new HashMap());
    setCustomerToServerQuotaName(new HashMap());
  }

  protected abstract boolean isQuotaExceeded(QuotaCount paramQuotaCount, int paramInt);

  public Set getExistingCustomerIDs() {
    return getCustomersQuotasAndCounts().keySet();
  }

  public void addCustomerQuotaInfo(CmdbCustomerID customerID, String quotaName, int quota) {
    CustomerQuotasAndCounts customerQuotasAndCounts = (CustomerQuotasAndCounts)getCustomersQuotasAndCounts().get(customerID);
    if (customerQuotasAndCounts == null) {
      customerQuotasAndCounts = QuotaFactory.createCustomerQuotasAndCounts();
      getCustomersQuotasAndCounts().put(customerID, customerQuotasAndCounts);
    }
    customerQuotasAndCounts.addQuota(quotaName, quota);
  }

  public void changeCustomerQuota(CmdbCustomerID customerID, String quotaname, int quota) throws CmdbQuotaException {
    CustomerQuotasAndCounts customerQuotasAndCounts = (CustomerQuotasAndCounts)getCustomersQuotasAndCounts().get(customerID);
    if (customerQuotasAndCounts == null)
      throw new CmdbQuotaException("no quotas defined for customer [" + customerID + "]", ErrorCode.GENERAL_QUOTA_ERROR);
    try
    {
      customerQuotasAndCounts.changeQuota(quotaname, quota);
    } catch (Exception e) {
      throw new CmdbQuotaException("quota [" + quotaname + "] doesn't exist for customer [" + customerID + "]", ErrorCode.GENERAL_QUOTA_ERROR);
    }
  }

  public Map<CmdbCustomerID, CustomerQuotasAndCounts> getCustomersQuotasAndCountsClone() {
    Map customersQuotasAndCountsClone = new HashMap(getCustomersQuotasAndCounts().size());

    Set customerIDs = getCustomersQuotasAndCounts().keySet();
    for (Iterator i$ = customerIDs.iterator(); i$.hasNext(); ) { CmdbCustomerID customerID = (CmdbCustomerID)i$.next();
      CustomerQuotasAndCounts customerQuotasAndCounts = (CustomerQuotasAndCounts)getCustomersQuotasAndCounts().get(customerID);
      customersQuotasAndCountsClone.put(customerID, customerQuotasAndCounts.getClone());
    }
    return customersQuotasAndCountsClone;
  }

  public Map<String, QuotaCount> getServerQuotasAndCountsClone() {
    Map serverQuotasAndCountsClone = new HashMap(getServersQuotasAndCounts().size());
    Set quotaNames = getServersQuotasAndCounts().keySet();
    for (Iterator i$ = quotaNames.iterator(); i$.hasNext(); ) { String quotaName = (String)i$.next();
      QuotaCount quotaCount = getServerQuotaCount(quotaName);
      serverQuotasAndCountsClone.put(quotaName, quotaCount.getClone());
    }
    return serverQuotasAndCountsClone;
  }

  public void addServerQuotaInfo(String quotaname, int quota, String customerQuotaName)
  {
    getServersQuotasAndCounts().put(quotaname, QuotaFactory.createQuotaCount(quota));
    getCustomerToServerQuotaName().put(customerQuotaName, quotaname);
  }

  public void changeServerQuota(String quotaname, int quota) throws CmdbQuotaException {
    QuotaCount quotaCount = (QuotaCount)getServersQuotasAndCounts().get(quotaname);
    if (quotaCount == null)
      throw new CmdbQuotaException("server quota [" + quotaname + "] is not defined, cannot change it", ErrorCode.GENERAL_QUOTA_ERROR);

    int currentCount = quotaCount.getCount();
    QuotaCount newQuotaCount = QuotaFactory.createQuotaCount(quota);
    newQuotaCount.setCount(currentCount);
    getServersQuotasAndCounts().put(quotaname, newQuotaCount);
  }

  public void setCustomerCurrentCount(CmdbCustomerID customerID, String quotaName, int newCount) {
    QuotaCount customerQuotaCount = getCustomerQuotaCount(customerID, quotaName);
    int oldCount = customerQuotaCount.getCount();
    customerQuotaCount.setCount(newCount);
    String serverQuotaName = getRelatedServerQuotaName(quotaName);
    if (serverQuotaName != null) {
      QuotaCount serverQuotaCount = getServerQuotaCount(serverQuotaName);
      int serverCurrentCount = serverQuotaCount.getCount();
      int serverNewCount = serverCurrentCount + newCount - oldCount;
      serverQuotaCount.setCount(serverNewCount);
    }
  }

  private String getRelatedServerQuotaName(String customerQuoatName) {
    return ((String)getCustomerToServerQuotaName().get(customerQuoatName));
  }

  public void resetAllCurrentCounts() {
    Collection customersQuotasAndValues = getCustomersQuotasAndCounts().values();
    for (Iterator i$ = customersQuotasAndValues.iterator(); i$.hasNext(); ) { CustomerQuotasAndCounts customerQuotasAndCounts = (CustomerQuotasAndCounts)i$.next();
      customerQuotasAndCounts.resetAllCounts();
    }

    Collection serverQuotasAndCounts = getServersQuotasAndCounts().values();
    for (Iterator i$ = serverQuotasAndCounts.iterator(); i$.hasNext(); ) { QuotaCount quotaCount = (QuotaCount)i$.next();
      quotaCount.setCount(0);
    }
  }

  public void removeCustomerQuotaAndCounts(CmdbCustomerID customerID) {
    CustomerQuotasAndCounts customerQuotasAndCounts = (CustomerQuotasAndCounts)getCustomersQuotasAndCounts().get(customerID);
    if (customerQuotasAndCounts == null)
      return;

    Set quotaNames = customerQuotasAndCounts.getQuotaNames();
    for (Iterator i$ = quotaNames.iterator(); i$.hasNext(); ) { String quotaName = (String)i$.next();
      int count = customerQuotasAndCounts.getQuotaCount(quotaName).getCount();
      decreaseServerCount(quotaName, count);
    }
    getCustomersQuotasAndCounts().remove(customerID);
  }

  private void decreaseServerCount(String relatedCustomerQuotaName, int count) {
    QuotaCount quotaCount = getRelatedServerQuotaCount(relatedCustomerQuotaName);
    quotaCount.setCount(quotaCount.getCount() - count);
  }

  private QuotaCount getRelatedServerQuotaCount(String relatedCustomerQuotaName) {
    String serverQuotaName = getRelatedServerQuotaName(relatedCustomerQuotaName);
    if (serverQuotaName == null)
      return null;

    return getServerQuotaCount(serverQuotaName);
  }

  public QuotaCheckResponse checkQuota(CmdbCustomerID customerID, String quotaName, int count)
  {
    QuotaCount customerQuotaCount = getCustomerQuotaCount(customerID, quotaName);

    if (isQuotaExceeded(customerQuotaCount, count)) {
      return new QuotaCheckResponseImpl(false, "customer quota is exceeded - cannot increase count by [" + count + "], details: customer [" + customerID + "] , quota [" + quotaName + "] is " + customerQuotaCount.getQuota() + " , current count is " + customerQuotaCount.getCount());
    }

    String serverQuotaName = getRelatedServerQuotaName(quotaName);
    if (hasServerQuotaCount(serverQuotaName)) {
      QuotaCount serverQuotaCount = getServerQuotaCount(serverQuotaName);
      if (isQuotaExceeded(serverQuotaCount, count)) {
        return new QuotaCheckResponseImpl(false, "server quota is exceeded - cannot increase count by [" + count + "], details: customer [" + customerID + "] , quota [" + quotaName + "] is definded for server as " + serverQuotaCount.getQuota() + " , current count is " + serverQuotaCount.getCount());
      }

    }

    return new QuotaCheckResponseImpl(true, null);
  }

  private boolean hasServerQuotaCount(String quotaName) {
    QuotaCount serverQuotaCount = (QuotaCount)getServersQuotasAndCounts().get(quotaName);
    return (serverQuotaCount != null);
  }

  private QuotaCount getServerQuotaCount(String quotaName) {
    QuotaCount serverQuotaCount = (QuotaCount)getServersQuotasAndCounts().get(quotaName);
    if (serverQuotaCount == null)
      throw new CmdbException("quota with name [" + quotaName + "] is not defined for server !!!");

    return serverQuotaCount;
  }

  private QuotaCount getCustomerQuotaCount(CmdbCustomerID customerID, String quotaName)
  {
    CustomerQuotasAndCounts customerQuotasAndCounts = (CustomerQuotasAndCounts)getCustomersQuotasAndCounts().get(customerID);
    if (customerQuotasAndCounts == null)
      throw new CmdbException("customer [" + customerID + "] doesn't exist !!!");

    QuotaCount customerQuotaCount = customerQuotasAndCounts.getQuotaCount(quotaName);
    if (customerQuotaCount == null)
      throw new CmdbException("quota [" + quotaName + "] doesn't exist for customer [" + customerID + "]");

    return customerQuotaCount;
  }

  private Map<String, QuotaCount> getServersQuotasAndCounts()
  {
    return this.serversQuotasAndCounts;
  }

  private void setServersQuotasAndCounts(Map<String, QuotaCount> serversQuotasAndCounts) {
    this.serversQuotasAndCounts = serversQuotasAndCounts;
  }

  private Map<CmdbCustomerID, CustomerQuotasAndCounts> getCustomersQuotasAndCounts() {
    return this.customersQuotasAndCounts;
  }

  private void setCustomersQuotasAndCounts(Map<CmdbCustomerID, CustomerQuotasAndCounts> customersQuotasAndCounts) {
    this.customersQuotasAndCounts = customersQuotasAndCounts;
  }

  private Map<String, String> getCustomerToServerQuotaName() {
    return this.customerToServerQuotaName;
  }

  private void setCustomerToServerQuotaName(Map<String, String> customerToServerQuotaName) {
    this.customerToServerQuotaName = customerToServerQuotaName;
  }
}