package com.mercury.topaz.cmdb.server.manage.subsystem.observer.impl;

import com.mercury.topaz.cmdb.server.manage.subsystem.observer.SubsystemManagersObserver;

public abstract class AbstractSubsystemManagersObserver
  implements SubsystemManagersObserver
{
}