package com.mercury.topaz.cmdb.server.manage.service.config.impl;

import com.mercury.topaz.cmdb.server.manage.service.config.ServiceConfig;
import com.mercury.topaz.cmdb.server.manage.service.config.ServicesConfig;
import java.util.ArrayList;
import java.util.List;

class ServicesConfigImpl
  implements ServicesConfig
{
  private List<ServiceConfig> _servicesConfig;

  public ServicesConfigImpl()
  {
    setServicesConfig(new ArrayList());
  }

  public List<ServiceConfig> getServicesConfig() {
    return this._servicesConfig;
  }

  public void addServiceConfig(ServiceConfig serviceConfig) {
    if (serviceConfig == null)
      throw new IllegalArgumentException("service config is null !!!");

    getServicesConfig().add(serviceConfig);
  }

  private void setServicesConfig(List<ServiceConfig> servicesConfig) {
    this._servicesConfig = servicesConfig;
  }
}