package com.mercury.topaz.cmdb.server.manage.comm;

import appilog.framework.shared.manage.MamResponse;
import com.mercury.topaz.cmdb.shared.manage.CmdbFacade;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import java.lang.reflect.Method;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.UnexpectedException;
import java.rmi.server.RemoteObject;
import java.rmi.server.RemoteRef;
import java.rmi.server.RemoteStub;

public final class CmdbFacadeImpl_Stub extends RemoteStub
  implements CmdbFacade, Remote
{
  private static final long serialVersionUID = 2L;
  private static Method $method_handleBinaryRequest_0;
  private static Method $method_handleRequest_1;
  static Class array$B;

  static
  {
    try
    {
      $method_handleBinaryRequest_0 = tmp17_14.getMethod("handleBinaryRequest", new Class[] { CmdbFacadeImpl_Stub.array$B = class$("[B") });
      $method_handleRequest_1 = tmp74_71.getMethod("handleRequest", new Class[] { CmdbRequest.class });
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      throw new NoSuchMethodError("stub class initialization failed");
    }
  }

  public CmdbFacadeImpl_Stub(RemoteRef paramRemoteRef)
  {
    super(paramRemoteRef);
  }

  public byte[] handleBinaryRequest(byte[] paramArrayOfByte)
    throws CmdbResponseException, RemoteException
  {
    try
    {
      Object localObject = this.ref.invoke(this, $method_handleBinaryRequest_0, new Object[] { paramArrayOfByte }, -176197522L);
      return ((byte[])localObject);
    }
    catch (RuntimeException localRuntimeException)
    {
      throw localRuntimeException;
    }
    catch (RemoteException localRemoteException)
    {
      throw localRemoteException;
    }
    catch (Exception localException)
    {
      throw new UnexpectedException("undeclared checked exception", localException);
    }
  }

  public MamResponse handleRequest(CmdbRequest paramCmdbRequest)
    throws CmdbResponseException, RemoteException
  {
    try
    {
      Object localObject = this.ref.invoke(this, $method_handleRequest_1, new Object[] { paramCmdbRequest }, -1477484066L);
      return ((MamResponse)localObject);
    }
    catch (RuntimeException localRuntimeException)
    {
      throw localRuntimeException;
    }
    catch (RemoteException localRemoteException)
    {
      throw localRemoteException;
    }
    catch (Exception localException)
    {
      throw new UnexpectedException("undeclared checked exception", localException);
    }
  }
}