package com.mercury.topaz.cmdb.server.manage.monitor.task;

public class ServerMonitorTask
{
  public static final String NAME = "Server Monitor Task";
}