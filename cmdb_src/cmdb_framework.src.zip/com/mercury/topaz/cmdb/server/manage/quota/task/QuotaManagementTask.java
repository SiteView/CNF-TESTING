package com.mercury.topaz.cmdb.server.manage.quota.task;

public class QuotaManagementTask
{
  public static final String NAME = "Quota Management Task";
}