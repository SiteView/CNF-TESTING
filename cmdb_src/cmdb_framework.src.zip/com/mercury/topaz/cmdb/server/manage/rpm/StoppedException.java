package com.mercury.topaz.cmdb.server.manage.rpm;

import com.mercury.topaz.cmdb.shared.base.CmdbException;

public class StoppedException extends CmdbException
{
  public StoppedException(String message)
  {
    super(message);
  }
}