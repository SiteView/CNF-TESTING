package com.mercury.topaz.cmdb.server.manage.dal.jdbc_template;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;

public abstract interface ResultSetExtractor<T>
{
  public abstract T extractData(CmdbDalResultSet paramCmdbDalResultSet)
    throws SQLException;
}