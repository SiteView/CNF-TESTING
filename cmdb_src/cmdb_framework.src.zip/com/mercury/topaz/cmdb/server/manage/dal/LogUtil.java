package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.logger.Log;

public class LogUtil
{
  public static String indent()
  {
    String indent = "";
    for (int i = 0; i < DalCallStack.getDepth(); ++i)
      indent = indent + "  ";

    return indent;
  }

  public static void info(Log logger, String msg) {
    logger.info(indent() + msg);
  }

  public static void debug(Log logger, String msg) {
    logger.debug(indent() + msg);
  }

  public static void error(Log logger, String msg, Throwable t) {
    logger.error(indent() + msg, t);
  }

  public static void error(Log logger, String msg) {
    logger.error(indent() + msg);
  }
}