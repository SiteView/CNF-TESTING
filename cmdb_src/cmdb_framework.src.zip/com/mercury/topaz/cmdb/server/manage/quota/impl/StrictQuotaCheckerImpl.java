package com.mercury.topaz.cmdb.server.manage.quota.impl;

import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;

class StrictQuotaCheckerImpl extends AbstractQuotaChecker
{
  protected boolean isQuotaExceeded(QuotaCount quotaCount, int count)
  {
    int newCount = quotaCount.getCount() + count;
    return (newCount > quotaCount.getQuota());
  }
}