package com.mercury.topaz.cmdb.server.manage.service.config.impl;

import com.mercury.topaz.cmdb.server.manage.subsystem.observer.SubsystemManagersObserver;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

public class ObserversConfig
{
  private static final String OBSERVER_TAG = "observer";
  private static final String SERVICE_NAME_ATTRIBUTE = "service-name";
  private static final String XML_FILE = "/services/startup-observers.xml";
  private static final String WILDCARD = "*";
  private final Map<String, Collection<Class<? extends SubsystemManagersObserver>>> observers = new HashMap();

  public ObserversConfig()
  {
    load();
  }

  public Collection<Class<? extends SubsystemManagersObserver>> getObserversOfService(String serviceName) {
    ArrayList ret = new ArrayList();
    Collection wcObs = (Collection)this.observers.get("*");
    if (wcObs != null) ret.addAll(wcObs);
    Collection serObs = (Collection)this.observers.get(serviceName);
    if (serObs != null) ret.addAll(serObs);
    return ret; }

  private void load() {
    InputStream configFileStream;
    try {
      configFileStream = super.getClass().getResourceAsStream("/services/startup-observers.xml");
      if (configFileStream == null)
        throw new CmdbException("Cannot find /services/startup-observers.xml");

      Document document = new SAXBuilder().build(configFileStream);
      configFileStream.close();

      List observersElements = document.getRootElement().getChildren("observer");
      for (Iterator i$ = observersElements.iterator(); i$.hasNext(); ) { Element element = (Element)i$.next();
        String serviceName = element.getAttribute("service-name").getValue();
        Collection observersOfService = (Collection)this.observers.get(serviceName);
        if (observersOfService == null) {
          observersOfService = new ArrayList();
          this.observers.put(serviceName, observersOfService);
        }

        observersOfService.add(Class.forName(element.getText()));
      }
    } catch (JDOMException e) {
      throw new CmdbException(e);
    } catch (IOException e) {
      throw new CmdbException(e);
    } catch (ClassNotFoundException e) {
      throw new CmdbException(e);
    }
  }
}