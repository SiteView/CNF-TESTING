package com.mercury.topaz.cmdb.server.manage.service.config.impl;

import org.jibx.runtime.IMarshaller;
import org.jibx.runtime.IUnmarshaller;

public class JiBX_bindingServiceConfigImpl_access
  implements IUnmarshaller, IMarshaller
{
}