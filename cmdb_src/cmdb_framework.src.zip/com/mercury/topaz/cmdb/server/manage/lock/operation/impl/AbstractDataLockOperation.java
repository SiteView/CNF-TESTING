package com.mercury.topaz.cmdb.server.manage.lock.operation.impl;

import com.mercury.topaz.cmdb.server.manage.lock.DataLockManager;
import com.mercury.topaz.cmdb.server.manage.lock.operation.DataLockOperation;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractFrameworkOperation;

public abstract class AbstractDataLockOperation extends AbstractFrameworkOperation
  implements DataLockOperation
{
  protected final void doExecute(SubsystemManager manager, CmdbResponse response)
    throws CmdbException
  {
    executeDataLock((DataLockManager)manager, response); }

  public String getServiceName() {
    return "CMDBMODELUPDATE";
  }
}