package com.mercury.topaz.cmdb.server.manage.lock;

public abstract interface DataForLock
{
  public abstract String getDataString();
}