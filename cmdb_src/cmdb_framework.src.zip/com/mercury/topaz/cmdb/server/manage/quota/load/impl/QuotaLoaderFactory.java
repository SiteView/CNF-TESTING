package com.mercury.topaz.cmdb.server.manage.quota.load.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.quota.load.QuotaLoader;

public class QuotaLoaderFactory
{
  private static Log _logger = LogFactory.getEasyLog(QuotaLoaderFactory.class);

  public static QuotaLoader createQuotaLoader(SettingsReader settingsReader)
  {
    String loaderName = settingsReader.getString("quota.loader.name", "settings");

    if ("system_console".equals(loaderName)) {
      if (_logger.isDebugEnabled())
        _logger.debug("system console loader is created !!!");

      return new SettingsQuotaLoader(settingsReader);
    }
    if (_logger.isDebugEnabled())
      _logger.debug("settings loader is created !!!");

    return new SettingsQuotaLoader(settingsReader);
  }
}