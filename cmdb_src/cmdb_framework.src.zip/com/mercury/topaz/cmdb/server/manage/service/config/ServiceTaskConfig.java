package com.mercury.topaz.cmdb.server.manage.service.config;

public abstract interface ServiceTaskConfig
{
  public abstract String getTaskFactoryClass();

  public abstract String getTaskFactoryMethod();

  public abstract String getManagerFactoryClass();

  public abstract String getManagerFactoryMethod();

  public abstract int getTotalThreadsNum();
}