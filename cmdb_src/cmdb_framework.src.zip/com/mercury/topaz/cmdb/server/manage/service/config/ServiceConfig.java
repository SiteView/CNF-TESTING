package com.mercury.topaz.cmdb.server.manage.service.config;

import java.util.List;

public abstract interface ServiceConfig
{
  public abstract String getServiceName();

  public abstract String getControllerServiceName();

  public abstract List<ServiceTaskConfig> getServiceTasksConfig();

  public abstract List<ServiceDependency> getDependencies();
}