package com.mercury.topaz.cmdb.server.manage.lock.operation.update;

import com.mercury.topaz.cmdb.server.manage.lock.DataForLock;
import com.mercury.topaz.cmdb.server.manage.lock.operation.impl.AbstractDataLockOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;

abstract class AbstractDataLockAction extends AbstractDataLockOperation
  implements CmdbUpdate
{
  protected DataForLock _dataForLock;

  public AbstractDataLockAction(DataForLock dataForLock)
  {
    setDataForLock(dataForLock);
  }

  public DataForLock getDataForLock() {
    return this._dataForLock;
  }

  private void setDataForLock(DataForLock dataForLock) {
    this._dataForLock = dataForLock;
  }
}