package com.mercury.topaz.cmdb.server.manage.customer.task;

public class CustomerManagementTask
{
  public static final String NAME = "Customer Management Task";
}