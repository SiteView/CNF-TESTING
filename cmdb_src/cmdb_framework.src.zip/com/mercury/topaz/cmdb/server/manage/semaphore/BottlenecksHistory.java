package com.mercury.topaz.cmdb.server.manage.semaphore;

import com.mercury.topaz.cmdb.server.manage.rpm.IndentingDumper;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class BottlenecksHistory
{
  private static final int MAX_RECORDS_COUNT = 100;
  private DateFormat dateFormatter;
  private Map<String, List<ContentionInfo>> history;

  public BottlenecksHistory()
  {
    this.dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    this.history = new HashMap(); }

  public void dumpHistory(IndentingDumper dumper) {
    dumper.append("\n");
    dumper.append("Blocked operation history:");
    dumper.increaseIndent();

    synchronized (this.history) {
      for (Iterator i$ = this.history.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        String subsystemName = (String)entry.getKey();
        dumper.append("Subsystem: " + subsystemName);
        dumper.increaseIndent();

        List infos = (List)entry.getValue();

        for (Iterator i$ = infos.iterator(); i$.hasNext(); ) { ContentionInfo info = (ContentionInfo)i$.next();
          dumper.append("Operation: " + ContentionInfo.access$000(info));
          dumper.append("Time: " + this.dateFormatter.format(new Date(ContentionInfo.access$100(info))));
          dumper.append("Thread: " + ContentionInfo.access$200(info));
          dumper.append(ContentionInfo.access$300(info));
          dumper.append("\n");
        }
        dumper.decreaseIndent();
      }
    }
    dumper.decreaseIndent();
  }

  public void recordContention(FrameworkOperation operation, Object resource) {
    synchronized (this.history) {
      String subsystemName = operation.getExecutionTaskQueueName();
      List infos = (List)this.history.get(subsystemName);
      if (infos == null) {
        infos = new LinkedList();
        this.history.put(subsystemName, infos);
      }

      ContentionInfo info = new ContentionInfo(System.currentTimeMillis(), operation.toString(), resource.toString());

      if (infos.size() == 100)
        infos.remove(0);

      infos.add(info);
    }
  }

  public void clear() {
    this.history.clear();
  }

  private static class ContentionInfo
  {
    private long accessTime;
    private String operationAsString;
    private String resourceAsString;
    private String threadAsString;

    ContentionInfo(long timeOfRequest, String operationAsString, String resourceAsString)
    {
      this.accessTime = timeOfRequest;
      this.operationAsString = operationAsString;
      this.resourceAsString = resourceAsString;
      this.threadAsString = Thread.currentThread().toString();
    }
  }
}