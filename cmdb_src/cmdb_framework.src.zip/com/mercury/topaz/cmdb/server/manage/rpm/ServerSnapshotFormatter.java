package com.mercury.topaz.cmdb.server.manage.rpm;

import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.topaz.cmdb.server.manage.semaphore.BottlenecksHistory;
import com.mercury.topaz.cmdb.shared.util.html.HtmlTable;
import com.mercury.topaz.cmdb.shared.util.html.Outputter;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import org.jdom.Element;

class ServerSnapshotFormatter
{
  private static final int MB_FACTOR = 1048576;
  private static final int MEANINGFUL_STACK_ROWS_COUNT = 10;

  static String toHtml(RequestProcessor requestProcessor)
  {
    String output = "</pre>";
    output = output + "\n" + getControllerScript();
    output = output + "\n" + getThreadsInfo(requestProcessor);
    output = output + "\n" + getThreadPoolsInfo(requestProcessor);
    output = output + "\n" + getMemoryInfo();
    output = output + "\n<pre>" + getBlockedOps(requestProcessor);
    return output;
  }

  private static String getDeadlockedThreadsInfo() {
    ThreadMXBean bean = ManagementFactory.getThreadMXBean();

    long[] deadlocked = bean.findMonitorDeadlockedThreads();
    StringBuilder builder = new StringBuilder();
    if ((deadlocked != null) && (deadlocked.length != 0)) {
      long[] arr$ = deadlocked; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { long id = arr$[i$];
        builder.append(id).append(" ");
      }

      builder.insert(0, "Deadlocked threads: ");
    }

    return builder.toString();
  }

  private static String getThreadsInfo(RequestProcessor requestProcessor) {
    Element parent = new Element("div");

    Map servingThreads = requestProcessor.getServingThreads();

    parent.addContent(servingThreads.size() + " serving thread(s)");
    parent.addContent(new Element("br"));
    String deadlockedThreadsInfo = getDeadlockedThreadsInfo();
    if (StringUtils.isNotEmpty(deadlockedThreadsInfo)) {
      parent.addContent(deadlockedThreadsInfo);
      parent.addContent(new Element("br"));
    }
    parent.addContent(new Element("br"));

    synchronized (servingThreads) {
      Iterator i$ = servingThreads.entrySet().iterator();
      while (true) { Map.Entry entry;
        Thread thr;
        while (true) { if (!(i$.hasNext())) break label201; entry = (Map.Entry)i$.next();
          thr = (Thread)entry.getKey();

          if (thr != Thread.currentThread())
            break;
        }

        parent.addContent(getThreadStack(thr.getId()));

        label201: parent.addContent(getRequests(requestProcessor, (Stack)entry.getValue()));
      }
    }

    return Outputter.toString(parent);
  }

  private static Element getRequests(RequestProcessor requestProcessor, Stack<RequestProcessor.RequestInProgress> requests) {
    IndentingDumper dumper = new IndentingDumper();
    requestProcessor.dumpRequests(requests, dumper);

    Element div = new Element("div");
    Element pre = new Element("pre");
    pre.setText(dumper.toString());
    div.addContent(pre);
    return div;
  }

  private static Element getThreadStack(long threadID) {
    ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
    ThreadInfo threadInfo = threadMXBean.getThreadInfo(threadID, 2147483647);

    Element parent = new Element("div");
    if (threadInfo == null) {
      parent.addContent("No thread info for ID [" + threadID + "]");
      return parent;
    }

    StackTraceElement[] stackTrace = threadInfo.getStackTrace();
    int count = 0;
    StringBuilder visibleBuf = new StringBuilder();
    StringBuilder hideableBuf = new StringBuilder();
    StackTraceElement[] arr$ = stackTrace; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { StackTraceElement stackTraceElement = arr$[i$];
      ++count;
      if (count < 10)
        visibleBuf.append(stackTraceElement.toString()).append("\n");
      else
        hideableBuf.append(stackTraceElement.toString()).append("\n");

    }

    Element visibleStack = new Element("div");
    Element anchor = new Element("a");
    anchor.setAttribute("href", "javascript:toggleElementVisibility('hideableStack" + threadID + "', 'block')");
    anchor.setText(threadInfo.toString());
    visibleStack.addContent(anchor);
    Element pre = new Element("pre");
    pre.addContent(visibleBuf.toString());
    visibleStack.addContent(pre);
    parent.addContent(visibleStack);

    Element hideableStack = new Element("div");
    hideableStack.setAttribute("id", "hideableStack" + threadID);
    hideableStack.setAttribute("style", "display: block");
    pre = new Element("pre");
    pre.addContent(hideableBuf.toString());
    hideableStack.addContent(pre);

    parent.addContent(hideableStack);

    return parent;
  }

  private static String getBlockedOps(RequestProcessor requestProcessor) {
    IndentingDumper dumper = new IndentingDumper();
    requestProcessor.getBottleneckHistory().dumpHistory(dumper);
    return dumper.toString();
  }

  private static String getThreadPoolsInfo(RequestProcessor requestProcessor) {
    Map threadPools = requestProcessor.getThreadPools();
    HtmlTable table = new HtmlTable(new String[] { "Name", "Size", "Executing", "Queued", "Core", "Max" });
    table.setAttribute("id", "thread-pools-info");
    table.setBorder(1);
    table.setAttribute("cellspacing", "2");
    table.setAttribute("cellpadding", "2");
    table.setAttribute("style", "display: block");

    synchronized (threadPools) {
      for (Iterator i$ = threadPools.entrySet().iterator(); i$.hasNext(); ) { Map.Entry entry = (Map.Entry)i$.next();
        ThreadPoolExecutor pool = (ThreadPoolExecutor)entry.getValue();

        table.addRow(new String[] { (String)entry.getKey(), String.valueOf(pool.getPoolSize()), String.valueOf(pool.getActiveCount()), String.valueOf(pool.getQueue().size()), String.valueOf(pool.getCorePoolSize()), String.valueOf(pool.getMaximumPoolSize()) });
      }

    }

    Element controller = new Element("div");
    Element anchor = new Element("a");
    anchor.setAttribute("href", "javascript:toggleElementVisibility('thread-pools-info', 'table')");
    anchor.setText("Thread Pools:");
    anchor.setAttribute("name", "threadpool");
    controller.addContent(anchor);

    controller.addContent(table.asElement());
    return Outputter.toString(controller);
  }

  private static String getMemoryInfo() {
    HtmlTable table = new HtmlTable(new String[] { "Memory", "Init", "Used", "Committed", "Max" });
    table.setAttribute("id", "memoryInfo");
    table.setBorder(1);
    table.setAttribute("cellspacing", "2");
    table.setAttribute("cellpadding", "2");
    table.setAttribute("style", "display: block");

    addMemoryUsage(table, ManagementFactory.getMemoryMXBean().getHeapMemoryUsage(), "Heap");
    addMemoryUsage(table, ManagementFactory.getMemoryMXBean().getNonHeapMemoryUsage(), "Non-Heap");

    Element controller = new Element("div");
    Element anchor = new Element("a");
    anchor.setAttribute("href", "javascript:toggleElementVisibility('memoryInfo', 'table')");
    anchor.setAttribute("name", "memory");
    anchor.setText("Memory:");
    controller.addContent(anchor);

    controller.addContent(table.asElement());

    return Outputter.toString(controller);
  }

  private static void addMemoryUsage(HtmlTable table, MemoryUsage memoryUsage, String type) {
    table.addRow(new String[] { type, String.valueOf(memoryUsage.getInit() / 1048576L), String.valueOf(memoryUsage.getUsed() / 1048576L), String.valueOf(memoryUsage.getCommitted() / 1048576L), String.valueOf(memoryUsage.getMax() / 1048576L) });
  }

  private static String getControllerScript()
  {
    return "<script type=\"text/javascript\">   function toggleElementVisibility(id, style) {       var element = document.getElementById(id);       if (element == null) {           return;       }       if (element.style.display == \"none\") {           if (isIE()) {               element.style.display = \"block\";           } else {               element.style.display = style;           }       } else if (element.style.display == style || element.style.display == \"block\") {           element.style.display = \"none\";       }   }     function isIE() {      return navigator.appName == \"Microsoft Internet Explorer\";    }</script>";
  }
}