package com.mercury.topaz.cmdb.server.manage.subsystem.observer;

import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;

public abstract interface SubsystemManagersObserver
{
  public abstract void startUp();

  public abstract void shutdown();

  public abstract void preStartup(CommonManager paramCommonManager);

  public abstract void postStartup(CommonManager paramCommonManager);
}