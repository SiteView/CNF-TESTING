package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.infra.utils.sql.SQLObjectFactory;
import com.mercury.infra.utils.sql.SimpleBlobImpl;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CmdbDalPreparedStatementImpl
  implements CmdbDalPreparedStatement
{
  public static final int BATCH_SIZE = 1000;
  private static Log _logger = LogFactory.getEasyLog(CmdbDalPreparedStatementImpl.class);
  private int _maxBatchSize = 1000;
  private int _batchCount = 0;
  private PreparedStatement _statement = null;
  private String _query = null;
  private Map _parentStatementsTable = null;
  private int currentIndex = 0;
  private List<Object> values = new ArrayList();
  private static final char[] intToHexChar = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

  public CmdbDalPreparedStatementImpl(PreparedStatement statement, String query, Map parentTable)
  {
    this._statement = statement;
    this._query = query;
    this._parentStatementsTable = parentTable;
  }

  private void setNull(int sqlType)
    throws SQLException
  {
    registerValue(null);
    this._statement.setNull(this.currentIndex, sqlType);
  }

  public void setInt(int value) throws SQLException {
    registerValue(Integer.valueOf(value));
    this._statement.setInt(this.currentIndex, value);
  }

  private void registerValue(Object value)
  {
    this.values.add(value);
    this.currentIndex += 1;
  }

  public void setInt(Integer value) throws SQLException {
    if (value == null)
      setNull(4);
    else
      setInt(value.intValue());
  }

  public void setLong(long value) throws SQLException
  {
    registerValue(Long.valueOf(value));
    this._statement.setLong(this.currentIndex, value);
  }

  public void setLong(Long value) throws SQLException {
    if (value == null)
      setNull(4);
    else
      setLong(value.longValue());
  }

  public void setFloat(float value) throws SQLException
  {
    registerValue(Float.valueOf(value));
    this._statement.setFloat(this.currentIndex, value);
  }

  public void setFloat(Float value) throws SQLException {
    if (value == null)
      setNull(6);
    else
      setFloat(value.floatValue());
  }

  public void setDouble(double value) throws SQLException
  {
    registerValue(Double.valueOf(value));
    this._statement.setDouble(this.currentIndex, value);
  }

  public void setDouble(Double value) throws SQLException {
    if (value == null)
      setNull(8);
    else
      setDouble(value.doubleValue());
  }

  public void setString(String value)
    throws SQLException
  {
    if ((value == null) || (value.length() == 0)) {
      setNull(12);
    } else {
      registerValue(value);
      this._statement.setString(this.currentIndex, value);
    }
  }

  public void setDate(Date value) throws SQLException {
    if (value == null) {
      setNull(4);
    } else {
      long time = value.getTime();
      registerValue(Long.valueOf(time));
      this._statement.setLong(this.currentIndex, time);
    }
  }

  public void setBoolean(boolean value) throws SQLException {
    registerValue(Boolean.valueOf(value));
    this._statement.setBoolean(this.currentIndex, value);
  }

  public void setBoolean(Boolean value) throws SQLException {
    if (value == null)
      setNull(4);
    else
      setBoolean(value.booleanValue());
  }

  public void setBytes(byte[] value) throws SQLException
  {
    if (value == null) {
      setNull(-3);
    } else {
      registerValue(value);
      this._statement.setBytes(this.currentIndex, value);
    }
  }

  private Clob createClob(String str)
  {
    return SQLObjectFactory.createClob(str);
  }

  private Blob createBlob(byte[] byteArray)
  {
    return new SimpleBlobImpl(byteArray);
  }

  public void setBlob(byte[] value) throws SQLException {
    byte[] bytesValue = (value != null) ? value : new byte[0];
    Blob blob = createBlob(bytesValue);
    registerValue(blob);
    this._statement.setBlob(this.currentIndex, blob);
  }

  public void setClob(String value) throws SQLException {
    String clobString = (value == null) ? "" : value;
    Clob clob = createClob(clobString);
    registerValue(clob);
    this._statement.setClob(this.currentIndex, clob);
  }

  public void setObject(Object value) throws SQLException {
    registerValue(value);
    this._statement.setObject(this.currentIndex, value);
  }

  public CmdbDalResultSet executeQuery() throws CmdbDalException {
    try {
      DalCallStack.logStatement(toString());

      ResultSet resultSet = this._statement.executeQuery();

      CmdbDalResultSet localCmdbDalResultSet = new CmdbDalResultSet(resultSet);

      return localCmdbDalResultSet;
    }
    catch (Throwable t)
    {
      String errMsg;
      throw new CmdbDalException(errMsg, t);
    } finally {
      clearValues();
    }
  }

  public int executeUpdate() throws CmdbDalException {
    try {
      DalCallStack.logStatement(toString());

      int i = this._statement.executeUpdate();

      return i;
    }
    catch (Throwable t)
    {
      String errMsg;
      throw new CmdbDalException(errMsg, t);
    } finally {
      clearValues(); }
  }

  public int[] executeBatch() {
    int[] result;
    try {
      result = null;
      if (this._batchCount > 0)
      {
        DalCallStack.logStatement(toString());

        result = this._statement.executeBatch();

        this._batchCount = 0;
      }
      int[] arrayOfInt1 = result;

      return arrayOfInt1;
    }
    catch (Throwable t)
    {
      String errMsg;
      throw new CmdbDalException(errMsg, t);
    } finally {
      clearValues();
    }
  }

  private void addBatch(boolean silently) {
    try {
      if ((_logger.isInfoEnabled()) && (!(silently))) {
        LogUtil.info(_logger, "Add batch to prepared statement [" + toString() + "]");
      }

      this._batchCount += 1;
      this._statement.addBatch();
      if (this._batchCount % this._maxBatchSize == 0)
        executeBatch();
    }
    catch (Throwable t)
    {
      String errMsg;
      throw new CmdbDalException(errMsg, t);
    } finally {
      clearValues();
    }
  }

  public void addBatchSilently() {
    addBatch(true);
  }

  public void addBatch() {
    addBatch(false);
  }

  public void clearBatch() throws SQLException {
    if (_logger.isDebugEnabled()) {
      LogUtil.debug(_logger, "Clear batch of prepared statement [" + this._statement + "]");
    }

    this._batchCount = 0;
    this._statement.clearBatch();
    clearValues();
  }

  private void clearValues() {
    this.values.clear();
    this.currentIndex = 0;
  }

  public void clearParameters() throws SQLException {
    if (_logger.isDebugEnabled())
      LogUtil.debug(_logger, "Clear parameters of prepared statement [" + this._statement + "]");

    this._statement.clearParameters();
    clearValues();
  }

  public void close(boolean removeFromTable) {
    try {
      if ((removeFromTable) && (this._parentStatementsTable != null))
      {
        this._parentStatementsTable.remove(this._query);
      }

      this._statement.close();
    }
    catch (Throwable t) {
      String errMsg;
      throw new CmdbDalException(errMsg, t);
    } finally {
      clearValues();
    }
  }

  private String bytesToString(byte[] bytes) {
    char[] ret = new char[bytes.length * 2];
    for (int i = 0; i < bytes.length; ++i) {
      ret[(2 * i)] = intToHexChar[(bytes[i] >> 4 & 0xF)];
      ret[(2 * i + 1)] = intToHexChar[(bytes[i] & 0xF)];
    }

    return new String(ret);
  }

  public void close()
  {
    close(true);
  }

  public String toString() {
    int index = 0;
    int questionMarkCount = 0;
    while (true) {
      index = this._query.indexOf("?", index);
      if (index == -1)
        break;

      ++questionMarkCount;
      ++index;
    }

    if ((questionMarkCount == 0) || (questionMarkCount != valuesCount())) {
      return toStringAsOriginalStatement();
    }

    return toStringAsFullStatement();
  }

  private int valuesCount() {
    return this.currentIndex;
  }

  private String toStringAsOriginalStatement() {
    StringBuilder buf = new StringBuilder(256);
    buf.append(this._query);

    String parametersAsString = getParametersAsString();
    if ((parametersAsString != null) && (parametersAsString.trim().length() > 0)) {
      buf.append(", Values: ");
      buf.append(parametersAsString);
    }

    return buf.toString();
  }

  private String getParametersAsString() {
    StringBuilder buf = new StringBuilder();
    for (Iterator i$ = this.values.iterator(); i$.hasNext(); ) { Object value = i$.next();
      buf.append(value).append(",");
    }

    if ((buf.length() > 0) && (buf.charAt(buf.length() - 1) == ',')) {
      buf.deleteCharAt(buf.length() - 1);
    }

    return buf.toString();
  }

  public String toStringAsFullStatement() {
    StringBuilder buf = new StringBuilder(this._query);

    int index = 0;

    for (Iterator i$ = this.values.iterator(); i$.hasNext(); ) { String valueAsString;
      Object value = i$.next();
      index = buf.indexOf("?", index);
      if (index == -1) {
        break;
      }

      if (value == null)
        valueAsString = "null";
      else if (value instanceof byte[])
        valueAsString = bytesToString((byte[])(byte[])value);
      else {
        valueAsString = value.toString();
      }

      buf.replace(index, index + 1, valueAsString);
      index += valueAsString.length();
    }

    return buf.toString();
  }

  public int getBatchSize() {
    return this._batchCount;
  }
}