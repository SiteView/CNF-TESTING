package com.mercury.topaz.cmdb.server.manage.environment.subsystem.impl;

import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;

public class ClassModelCmdbSubsystemEnvironment extends AbstractCmdbSubsystemEnvironment
{
  private boolean _upgradeMode = false;

  public ClassModelCmdbSubsystemEnvironment(boolean upgradeMode)
  {
    setUpgradeMode(upgradeMode);
  }

  public FrameworkConstants.Subsystem getSubsystem() {
    return FrameworkConstants.Subsystem.CLASS_MODEL;
  }

  public boolean isUpgradeMode() {
    return this._upgradeMode;
  }

  private void setUpgradeMode(boolean upgradeMode) {
    this._upgradeMode = upgradeMode;
  }
}