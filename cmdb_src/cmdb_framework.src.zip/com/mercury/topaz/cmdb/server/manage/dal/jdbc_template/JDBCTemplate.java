package com.mercury.topaz.cmdb.server.manage.dal.jdbc_template;

import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class JDBCTemplate
{
  private static final Object[] EMPTY_ARGS = new Object[0];
  private final CmdbDalConnection connection;

  private JDBCTemplate(CmdbDalConnection connection)
  {
    this.connection = connection;
  }

  public static JDBCTemplate getInstance(CmdbDalConnection connection) {
    return new JDBCTemplate(connection);
  }

  public void execute(String sql) {
    execute(sql, EMPTY_ARGS);
  }

  public void execute(String sql, Object[] args) {
    execute(new DefaultPreparedStatementCreator(this, sql, args));
  }

  public void execute(String sql, PreparedStatementSetter pss)
  {
    execute(new PreparedStatementCreatorWithSetter(this, sql, pss));
  }

  private void execute(PreparedStatementCreator psc) {
    CmdbDalPreparedStatement ps = null;
    try {
      ps = psc.create();
      ps.executeUpdate();
    }
    catch (Exception e)
    {
      throw new CmdbDalException("SQL error executing statement " + ps, e);
    } finally {
      if (ps != null)
        try {
          ps.close();
        }
        catch (Exception e) {
        }
    }
  }

  public List<?> queryForList(String sql) {
    return queryForList(sql, EMPTY_ARGS);
  }

  public List<?> queryForList(String sql, Object[] args)
  {
    return queryForList(new DefaultPreparedStatementCreator(this, sql, args));
  }

  private List<?> queryForList(PreparedStatementCreator statementCreator) {
    return ((List)executeQuery(statementCreator, new ResultSetExtractor(this) {
      public List<?> extractData() throws SQLException {
        if (rs.getMetaData().getColumnCount() != 1) {
          throw new CmdbDalException("Result set has " + rs.getMetaData().getColumnCount() + " columns, expected 1");
        }

        List result = new ArrayList();
        while (rs.next())
          result.add(rs.getObject(1));

        return result;
      }
    }));
  }

  public Map<String, ?> queryForMap(String sql) {
    return queryForMap(sql, EMPTY_ARGS);
  }

  public Map<String, ?> queryForMap(String sql, Object[] args)
  {
    return ((Map)executeQuery(new DefaultPreparedStatementCreator(this, sql, args), new ResultSetExtractor(this)
    {
      public Map<String, ?> extractData() throws SQLException {
        if (!(rs.next())) {
          return null;
        }

        ResultSetMetaData metaData = rs.getMetaData();
        Map result = new HashMap();
        int count = metaData.getColumnCount();
        for (int i = 1; i <= count; ++i)
          result.put(metaData.getColumnName(i), rs.getObject(i));

        return result;
      }
    }));
  }

  public String queryForString(String sql) {
    return queryForString(sql, EMPTY_ARGS);
  }

  public String queryForString(String sql, Object[] args) {
    return ((String)queryForObject(sql, args));
  }

  public Integer queryForInteger(String sql) {
    return queryForInteger(sql, EMPTY_ARGS);
  }

  public Integer queryForInteger(String sql, Object[] args)
  {
    return ((Integer)queryForObject(sql, args));
  }

  public int queryForInt(String sql) {
    return queryForInt(sql, EMPTY_ARGS);
  }

  public int queryForInt(String sql, Object[] args)
  {
    Object dbObject = queryForObject(sql, args);
    if (dbObject instanceof Integer)
      return ((Integer)dbObject).intValue();
    if (dbObject instanceof Long)
      return ((Long)dbObject).intValue();
    if (dbObject instanceof Short)
      return ((Short)dbObject).intValue();
    if (dbObject instanceof Byte)
      return ((Byte)dbObject).intValue();
    if (dbObject instanceof BigInteger)
      return ((BigInteger)dbObject).intValue();
    if (dbObject instanceof BigDecimal)
      return ((BigDecimal)dbObject).intValue();

    throw new CmdbDalException("Cannot convert " + dbObject.getClass().getName() + " to an integer");
  }

  public Long queryForLong(String sql)
  {
    return queryForLong(sql, EMPTY_ARGS);
  }

  public Long queryForLong(String sql, Object[] args)
  {
    Object dbObject = queryForObject(sql, args);
    if (dbObject == null)
      return null;

    if (dbObject instanceof Integer)
      return Long.valueOf(((Integer)dbObject).intValue());
    if (dbObject instanceof Long)
      return ((Long)dbObject);
    if (dbObject instanceof Short)
      return Long.valueOf(((Short)dbObject).intValue());
    if (dbObject instanceof Byte)
      return Long.valueOf(((Byte)dbObject).intValue());
    if (dbObject instanceof BigInteger)
      return Long.valueOf(((BigInteger)dbObject).longValue());
    if (dbObject instanceof BigDecimal)
      return Long.valueOf(((BigDecimal)dbObject).longValue());

    throw new CmdbDalException("Cannot convert " + dbObject.getClass().getName() + " to a long");
  }

  public Object queryForObject(String sql, Object[] args)
  {
    return executeQuery(new DefaultPreparedStatementCreator(this, sql, args), new ResultSetExtractor(this)
    {
      public Object extractData() throws SQLException {
        if (!(rs.next()))
          return null;

        int columnCount = rs.getMetaData().getColumnCount();
        if (columnCount != 1)
          throw new CmdbDalException("Result set has " + columnCount + " columns, expected 1");

        return rs.getObject(1);
      }
    });
  }

  public void executeQuery(String sql, RowHandler rh)
  {
    executeQuery(sql, new RowIterator(rh));
  }

  public void executeQuery(String sql, RowHandler rh, Object[] args)
  {
    executeQuery(sql, new RowIterator(rh), args);
  }

  public void executeQuery(String sql, PreparedStatementSetter pss, RowHandler rh)
  {
    executeQuery(sql, pss, new RowIterator(rh));
  }

  public <T> T executeQuery(String sql, ResultSetExtractor<T> rse)
  {
    return executeQuery(sql, rse, EMPTY_ARGS);
  }

  public <T> T executeQuery(String sql, ResultSetExtractor<T> rse, Object[] args)
  {
    return executeQuery(new DefaultPreparedStatementCreator(this, sql, args), rse);
  }

  public <T> T executeQuery(String sql, PreparedStatementSetter pss, ResultSetExtractor<T> rse)
  {
    return executeQuery(new PreparedStatementCreatorWithSetter(this, sql, pss), rse);
  }

  public int executeUpdate(String sql)
  {
    return executeUpdate(new DefaultPreparedStatementCreator(this, sql, EMPTY_ARGS));
  }

  public int executeUpdate(String sql, Object[] args)
  {
    return executeUpdate(new DefaultPreparedStatementCreator(this, sql, args));
  }

  private <T> T executeQuery(PreparedStatementCreator psc, ResultSetExtractor<T> rse) {
    CmdbDalPreparedStatement ps = null;
    CmdbDalResultSet rs = null;
    try {
      ps = psc.create();
      rs = ps.executeQuery();
      Object localObject1 = rse.extractData(rs);

      return localObject1;
    }
    catch (SQLException e)
    {
    }
    finally
    {
      if (rs != null)
        try {
          rs.close();
        }
        catch (Exception e) {
        }
      if (ps != null)
        try {
          ps.close();
        }
        catch (Exception e) {
        }
    }
  }

  private int executeUpdate(PreparedStatementCreator psc) {
    CmdbDalPreparedStatement ps = null;
    try {
      ps = psc.create();
      int i = ps.executeUpdate();

      return i;
    }
    catch (Exception e)
    {
      throw new CmdbDalException("SQL error executing statement " + ps, e);
    } finally {
      if (ps != null)
        try {
          ps.close();
        }
        catch (Exception e) {
        }
    }
  }

  public String GUID() {
    return GUID(this.connection.getDBType());
  }

  public static String GUID(DBType type) {
    if (DBType.isMsSql(type))
      return "NEWID()";

    return "SYS_GUID()";
  }

  private class PreparedStatementCreatorWithSetter extends JDBCTemplate.AbstractPreparedStatementCreator
  {
    private final PreparedStatementSetter pss;

    PreparedStatementCreatorWithSetter(, String paramString, PreparedStatementSetter paramPreparedStatementSetter)
    {
      super(paramJDBCTemplate, paramString);
      this.pss = paramPreparedStatementSetter;
    }

    public void setValues() throws SQLException {
      this.pss.setValues(ps);
    }
  }

  private class DefaultPreparedStatementCreator extends JDBCTemplate.AbstractPreparedStatementCreator
  {
    private Object[] args;

    DefaultPreparedStatementCreator(, String paramString, Object[] paramArrayOfObject)
    {
      super(paramJDBCTemplate, paramString);
      this.args = paramArrayOfObject;
    }

    public void setValues() throws SQLException {
      Object[] arr$ = this.args; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { Object arg = arr$[i$];
        ps.setObject(arg);
      }
    }
  }

  private abstract class AbstractPreparedStatementCreator
  implements PreparedStatementCreator, PreparedStatementSetter
  {
    private final String sql;

    protected AbstractPreparedStatementCreator(, String paramString)
    {
      this.sql = sql;
    }

    public CmdbDalPreparedStatement create() throws SQLException {
      CmdbDalPreparedStatement ps = null;
      try {
        ps = JDBCTemplate.access$000(this.this$0).prepareStatement4Select(this.sql);
        setValues(ps);
        return ps;
      } catch (SQLException e) {
        if (ps != null)
          try {
            ps.close();
          }
          catch (Exception e1) {
          }
        throw e;
      } catch (RuntimeException e) {
        if (ps != null)
          try {
            ps.close();
          }
          catch (Exception e1) {
          }
        throw e;
      }
    }
  }
}