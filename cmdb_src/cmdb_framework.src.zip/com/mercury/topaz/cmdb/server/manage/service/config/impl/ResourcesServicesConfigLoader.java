package com.mercury.topaz.cmdb.server.manage.service.config.impl;

import com.mercury.topaz.cmdb.server.manage.service.config.ServiceConfig;
import com.mercury.topaz.cmdb.server.manage.service.config.ServiceDependency;
import com.mercury.topaz.cmdb.server.manage.service.config.ServicesConfig;
import com.mercury.topaz.cmdb.server.manage.service.config.ServicesConfigLoader;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class ResourcesServicesConfigLoader
  implements ServicesConfigLoader
{
  private static final String SERVICES_ROOT_FOLDER = "/services/";
  private final Collection<String> moduleComponents;

  public ResourcesServicesConfigLoader(Collection<String> moduleComponents)
  {
    this.moduleComponents = moduleComponents;
  }

  public ServicesConfig loadServicesConfig() {
    ServicesConfig servicesConfig = ServiceConfigFactory.createServicesConfig();
    Queue componentsToLoad = new LinkedList(this.moduleComponents);
    Set loadedComponents = new HashSet();
    while (true) { String componentName;
      while (true) { if (componentsToLoad.isEmpty()) break label220;
        componentName = (String)componentsToLoad.remove();
        if (!(loadedComponents.contains(componentName)))
          break;
      }
      String resourceName = "/services/" + componentName + "/" + "service-config.xml";
      InputStream resourceStream = super.getClass().getResourceAsStream(resourceName);
      if (resourceStream == null)
        throw new CmdbException("Failed to load service-config.xml for component " + componentName);

      ServiceConfig serviceConfig = (ServiceConfig)XmlUtils.fromXML(resourceStream, ServiceConfigImpl.class);
      loadedComponents.add(componentName);
      servicesConfig.addServiceConfig(serviceConfig);
      for (Iterator i$ = serviceConfig.getDependencies().iterator(); i$.hasNext(); ) { ServiceDependency dependency = (ServiceDependency)i$.next();
        componentsToLoad.offer(dependency.getDependencyName());
      }
    }
    label220: return servicesConfig;
  }
}