package com.mercury.topaz.cmdb.server.manage.lock.operation;

import com.mercury.topaz.cmdb.server.manage.lock.DataLockManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface DataLockOperation extends FrameworkOperation
{
  public abstract void executeDataLock(DataLockManager paramDataLockManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}