package com.mercury.topaz.cmdb.server.manage.instance;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.manage.environment.BasicLocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.ServiceComponentsGroup;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersActivator;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersActivatorImpl;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersContainer;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersContainerImpl;
import com.mercury.topaz.cmdb.server.notification.DeploymentManager;
import com.mercury.topaz.cmdb.server.notification.impl.DeploymentManagerFactory;
import com.mercury.topaz.cmdb.server.notification.task.publish.NotificationPublishManager;
import com.mercury.topaz.cmdb.server.notification.task.publish.PublishTaskUtil;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CustomerInstanceImpl
  implements CustomerInstance
{
  private LocalEnvironment _localEnvironment;
  private final Map<String, ServiceComponentsGroup> _services = new HashMap();
  private SubsystemManagersActivator notificationManagers;
  private SubsystemManagersContainer subsystemManagers = new SubsystemManagersContainerImpl();
  private static final Log log = CmdbLogFactory.getCMDBInfoLog();

  CustomerInstanceImpl(CmdbCustomerID customerID)
  {
    this.notificationManagers = new SubsystemManagersActivatorImpl(log);
    setLocalEnvironment(new BasicLocalEnvironment(customerID));
    createNotificationManagers();
  }

  public void startUp() {
    getLocalEnvironment().startUp();
    notificationStartup();
    log.info("CMDB Instance is started up for customer [id=" + getCustomerID() + "]");
  }

  public void shutdown() {
    notificationShutdown();
    getLocalEnvironment().shutdown();
    log.info("CMDB Instance is shutdown for customer [id=" + getCustomerID() + "]");
  }

  public void addManager(CommonManager subsystemManager) {
    this.subsystemManagers.addManager(subsystemManager);
  }

  public void removeManager(CommonManager subsystemManager) {
    this.subsystemManagers.removeManager(subsystemManager);
  }

  public CommonManager getManager(String subsystemName) {
    return this.subsystemManagers.getManager(subsystemName);
  }

  private void notificationStartup() {
    this.notificationManagers.startup();
  }

  private void createNotificationManagers() {
    PublishTaskUtil publishTaskUtil = new PublishTaskUtil(getLocalEnvironment().getSettingsReader());

    List notificationPublisherManagers = publishTaskUtil.createNotificationPublisherManagers(getLocalEnvironment());
    for (Iterator i$ = notificationPublisherManagers.iterator(); i$.hasNext(); ) { NotificationPublishManager manager = (NotificationPublishManager)i$.next();
      this.notificationManagers.addManager(manager);
      this.subsystemManagers.addManager(manager);
    }
    DeploymentManager manager = DeploymentManagerFactory.createConcurrent(getLocalEnvironment(), publishTaskUtil.createPublishTaskNames());
    this.notificationManagers.addManager(manager);
    this.subsystemManagers.addManager(manager);
  }

  private void notificationShutdown() {
    this.notificationManagers.shutdown();
  }

  public LocalEnvironment getLocalEnvironment() {
    return this._localEnvironment;
  }

  private CmdbCustomerID getCustomerID() {
    return getLocalEnvironment().getCustomerID();
  }

  private void setLocalEnvironment(LocalEnvironment LocalEnvironment) {
    this._localEnvironment = LocalEnvironment;
  }

  public Map<String, ServiceComponentsGroup> getServices() {
    return this._services;
  }

  public void addServiceInstance(String serviceName, ServiceComponentsGroup serviceInstance) {
    getServices().put(serviceName, serviceInstance);
  }

  public void removeServiceInstance(String serviceName) {
    ServiceComponentsGroup serviceInstance = (ServiceComponentsGroup)getServices().remove(serviceName);
    if (serviceInstance != null)
      serviceInstance.shutdown();
  }

  public boolean isServiceInstanceStartedUp(String serviceName)
  {
    return getServices().containsKey(serviceName);
  }
}