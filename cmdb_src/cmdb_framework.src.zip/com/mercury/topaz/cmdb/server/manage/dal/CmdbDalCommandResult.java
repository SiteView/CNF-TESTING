package com.mercury.topaz.cmdb.server.manage.dal;

public class CmdbDalCommandResult<RESULT>
{
  private RESULT _result = null;

  public CmdbDalCommandResult(RESULT result)
  {
    this._result = result;
  }

  public RESULT getResult() {
    return this._result;
  }
}