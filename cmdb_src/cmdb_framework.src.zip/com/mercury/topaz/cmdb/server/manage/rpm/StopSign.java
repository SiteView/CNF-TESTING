package com.mercury.topaz.cmdb.server.manage.rpm;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class StopSign
{
  private static final Set<String> flags = Collections.synchronizedSet(new HashSet(32));

  public static void test()
    throws StoppedException
  {
    Thread thread = Thread.currentThread();
    String name = thread.getName();

    if (Thread.interrupted()) {
      throw new StoppedException("Thread " + name + " interrupted");
    }

    if (flags.contains(name))
      throw new StoppedException("Thread " + name + " stopped");
  }

  public static void set(Thread thread)
  {
    flags.add(thread.getName());
    thread.interrupt();
  }

  public static void clear()
  {
    flags.remove(Thread.currentThread().getName());
    Thread.interrupted();
  }

  public static void allowToContinue()
  {
    Thread.interrupted();
  }
}