package com.mercury.topaz.cmdb.server.manage.settings.parameters;

public abstract interface SystemParametersConsts
{
  public static final String CALLER_APP_SERVER = "server";
  public static final int CORE_CANNOT_READ_SYSTEM_PARAMETERS_XNL_FILE = 53040;
  public static final int CORE_CANNOT_CONNECT_SETTING_MANAGER = 53041;
}