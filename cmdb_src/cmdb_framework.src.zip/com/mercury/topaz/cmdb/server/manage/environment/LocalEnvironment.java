package com.mercury.topaz.cmdb.server.manage.environment;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.schedule.Scheduler;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalDAO;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.manage.environment.subsystem.CmdbSubsystemEnvironment;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public abstract interface LocalEnvironment
{
  public abstract void startUp();

  public abstract void shutdown();

  public abstract SettingsReader getSettingsReader();

  public abstract GlobalEnvironment getGlobalEnvironment();

  public abstract CmdbCustomerID getCustomerID();

  public abstract Scheduler getScheduler();

  public abstract ConnectionPoolManager getConnectionsPoolManager();

  public abstract void setParam(String paramString, Object paramObject);

  public abstract Object getParam(String paramString);

  public abstract int getSystemParameter(String paramString, int paramInt);

  public abstract String getSystemParameter(String paramString1, String paramString2);

  public abstract boolean getSystemParameter(String paramString, boolean paramBoolean);

  public abstract float getSystemParameter(String paramString, float paramFloat);

  public abstract long getSystemParameter(String paramString, long paramLong);

  public abstract void setSystemParameter(String paramString1, String paramString2);

  public abstract CmdbSubsystemEnvironment getSubsystemEnvironment(FrameworkConstants.Subsystem paramSubsystem);

  public abstract void setSubsystemEnvironment(CmdbSubsystemEnvironment paramCmdbSubsystemEnvironment);

  public abstract void reloadSettings();

  public abstract void addShutdownListener(NeedsShutdown paramNeedsShutdown);

  public abstract CmdbDalDAO getDao();
}