package com.mercury.topaz.cmdb.server.manage.settings;

import com.mercury.topaz.cmdb.shared.base.CmdbException;

public class ParametersException extends CmdbException
{
  public static final int ERR_DEFAULT = 0;
  private int errorCode;

  public ParametersException(String message, int errorCode)
  {
    super(message);

    this.errorCode = 0;

    this.errorCode = errorCode;
  }

  public ParametersException(String message, Throwable cause) {
    this(message, cause, 0); }

  public ParametersException(String message, Throwable ex, int errorCode) {
    super(message, ex);

    this.errorCode = 0;

    this.errorCode = errorCode;
  }

  public int getErrorCode() {
    return this.errorCode;
  }
}