package com.mercury.topaz.cmdb.server.manage;

import appilog.framework.shared.manage.MamResponse;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.client.manage.api.impl.AbstractCmdbApi;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.schedule.PeriodicTaskable;
import com.mercury.topaz.cmdb.server.base.itc.schedule.Scheduler;
import com.mercury.topaz.cmdb.server.manage.comm.CommunicationManager;
import com.mercury.topaz.cmdb.server.manage.comm.JndiCommunicationManager;
import com.mercury.topaz.cmdb.server.manage.customer.impl.CustomerManagerImpl;
import com.mercury.topaz.cmdb.server.manage.customer.impl.CustomerQueryManagerImpl;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.manage.instance.CmdbInstanceManager;
import com.mercury.topaz.cmdb.server.manage.monitor.impl.ServerMonitorManagerImpl;
import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.server.manage.quota.impl.QuotaManagerImpl;
import com.mercury.topaz.cmdb.server.manage.quota.task.QuotaPeriodicTask;
import com.mercury.topaz.cmdb.server.manage.rpm.RequestProcessor;
import com.mercury.topaz.cmdb.server.manage.rpm.RequestTimeoutCallback;
import com.mercury.topaz.cmdb.server.manage.service.config.ServicesConfig;
import com.mercury.topaz.cmdb.server.manage.service.config.ServicesConfigLoader;
import com.mercury.topaz.cmdb.server.manage.service.config.impl.FilesServicesConfigLoader;
import com.mercury.topaz.cmdb.server.manage.service.config.impl.ObserversConfig;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersAccessor;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersActivator;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersActivatorImpl;
import com.mercury.topaz.cmdb.server.monitors.MonitorsFactory;
import com.mercury.topaz.cmdb.server.monitors.manager.impl.MonitorsCollectorsManagerFactory;
import com.mercury.topaz.cmdb.server.monitors.manager.impl.MonitorsQueryManagerFactory;
import com.mercury.topaz.cmdb.server.monitors.task.CmdbMonitorsPeriodicTask;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.NotificationQueueFlushPeriodicTask;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher.JMSPublisher;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher.JMSPublisherImpl;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Notification;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.Environment;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.notification.service.util.CmdbNotificationJMSUtil;
import com.mercury.topaz.cmdb.shared.util.FrameworkUtils;
import com.mercury.topaz.cmdb.shared.util.Stopper;
import java.util.ArrayList;
import java.util.List;

public class Framework extends AbstractCmdbApi
{
  private GlobalEnvironment _globalEnvironment;
  private CommunicationManager _commManager;
  private CmdbInstanceManager _instanceManager;
  private Scheduler _scheduler;
  private Scheduler _schedulerForPublisher;
  private static final Framework _theInstance = new Framework();
  private boolean _isStartedUp;
  private RequestProcessor requestProcessor;
  private ServicesConfigLoader servicesConfigLoader;
  private ServicesConfig servicesConfig;
  private ObserversConfig observersConfig;
  private SubsystemManagersActivator globalSubsystemManagers;
  private MonitorsFactory monitorsFactory;
  private QuotaManager quotaManager;

  public static Framework getInstance()
  {
    return _theInstance;
  }

  protected Framework()
  {
    this.globalSubsystemManagers = new SubsystemManagersActivatorImpl(getStartupLog());
  }

  private Log getStartupLog()
  {
    return CmdbLogFactory.getStartupLog();
  }

  public synchronized void startUp()
  {
    if (isStartedUp())
      return;

    logSystemStartup(getStartupLog());
    Stopper stopper = new Stopper().start();

    init();

    getCommManager().startUp();
    this.globalSubsystemManagers.startup();
    if (Environment.USE_JMS) {
      startJMSPublisher();
    }

    launchPeriodicGlobalTasks();

    getStartupLog().info("******* Framework started in " + (stopper.elapsedTime() / 1000L) + " sec *******");
    setStartedUp(true);
  }

  private void init() {
    setGlobalEnvironment(new GlobalEnvironment());

    this.servicesConfig = loadServicesConfig(getGlobalSettings());
    this.observersConfig = new ObserversConfig();
    this.requestProcessor = new RequestProcessor();

    setInstanceManager(new CmdbInstanceManager());
    setScheduler(new Scheduler("UCMDB - global framework scheduler"));
    setSchedulerForPublisher(new Scheduler("UCMDB - global publisher scheduler"));

    initGlobalSubsystemManagers();
  }

  private void initGlobalSubsystemManagers()
  {
    this.globalSubsystemManagers.addManager(new CustomerManagerImpl(getInstanceManager(), getGlobalEnvironment()));

    this.globalSubsystemManagers.addManager(new CustomerQueryManagerImpl(getGlobalEnvironment(), getInstanceManager()));

    this.globalSubsystemManagers.addManager(this.quotaManager = new QuotaManagerImpl(getGlobalEnvironment()));

    this.globalSubsystemManagers.addManager(new ServerMonitorManagerImpl(getGlobalEnvironment()));

    this.globalSubsystemManagers.addManager(MonitorsQueryManagerFactory.create(getGlobalEnvironment()));

    this.globalSubsystemManagers.addManager(MonitorsCollectorsManagerFactory.create(getGlobalEnvironment()));
  }

  private void launchPeriodicGlobalTasks() {
    int quotaCollectCountsInterval = getGlobalSettings().getInt("quota.scheduler.interval.sec", 900);

    QuotaPeriodicTask quotaPeriodicTask = new QuotaPeriodicTask(quotaCollectCountsInterval);
    launchPeriodicTask(quotaPeriodicTask, 900000L);

    int monitorCollectCountsInterval = getGlobalSettings().getInt("monitor.scheduler.timer.time", 900);
    int monitorCollectCountsDelay = getGlobalSettings().getInt("monitor.scheduler.delay.time", 900);
    CmdbMonitorsPeriodicTask monitorsPeriodicTask = new CmdbMonitorsPeriodicTask(monitorCollectCountsInterval);
    launchPeriodicTask(monitorsPeriodicTask, monitorCollectCountsDelay);
  }

  public QuotaManager getQuotaManager()
  {
    return this.quotaManager;
  }

  private void removePeriodicGlobalTasks() {
    getScheduler().shutdown();
  }

  private void startJMSPublisher() {
    int maxQueueSize = getGlobalEnvironment().getSettingsReader().getInt("notification.queue.size.max", FrameworkConstants.Notification.NOTIFICATION_JMS_MAX_QUEUE_SIZE_DEFAULT.intValue());
    JMSPublisher publisher = new JMSPublisherImpl(CmdbNotificationJMSUtil.createJMSEnvironment(maxQueueSize));
    getGlobalEnvironment().setJmsPublisher(publisher);
    if (FrameworkUtils.isJMSListenerAdaptersShouldBeRegistered()) {
      publisher.startUp();
    }

    List publishers = new ArrayList();
    publishers.add(publisher);
    int interval = getGlobalEnvironment().getSettingsReader().getInt("notification.queue.flush.interval", 120);
    NotificationQueueFlushPeriodicTask queueFlushPeriodicTask = new NotificationQueueFlushPeriodicTask(interval, publishers);
    getSchedulerForPublisher().addPeriodicTask(queueFlushPeriodicTask, 120000L);
  }

  private void shutdownJMSPublisher() {
    getSchedulerForPublisher().shutdown();
    if (FrameworkUtils.isJMSListenerAdaptersShouldBeRegistered())
      getGlobalEnvironment().getJmsPublisher().shutdown();
  }

  public void setServicesConfigLoader(ServicesConfigLoader servicesConfigLoader)
  {
    this.servicesConfigLoader = servicesConfigLoader;
  }

  private ServicesConfig loadServicesConfig(SettingsReader settingsReader) {
    if (this.servicesConfigLoader == null)
      this.servicesConfigLoader = new FilesServicesConfigLoader(settingsReader);

    return this.servicesConfigLoader.loadServicesConfig();
  }

  private void launchPeriodicTask(PeriodicTaskable task, long delayInMilli) {
    getScheduler().addPeriodicTask(task, delayInMilli);
  }

  public void shutdown()
  {
    setStartedUp(false);
    removePeriodicGlobalTasks();

    if (Environment.USE_JMS)
      shutdownJMSPublisher();

    getCommManager().shutdown();

    this.globalSubsystemManagers.shutdown();

    this.requestProcessor.shutdown();

    logSystemShutdown(getStartupLog());
  }

  private void logSystemStartup(Log infoLog) {
    infoLog.info("");
    infoLog.info("************************************");
    infoLog.info("*******  Starting Framework  *******");
    infoLog.info("************************************\n");
  }

  private void logSystemShutdown(Log log) {
    log.info("");
    log.info("************************************");
    log.info("*******  Shutdown Framework  *******");
    log.info("************************************\n");
  }

  public MamResponse handleRequest(CmdbRequest request)
    throws CmdbResponseException
  {
    if (!(isStartedUp())) {
      throw new CmdbException("Framework is not started");
    }

    return this.requestProcessor.handleRequest(request);
  }

  public GlobalEnvironment getGlobalEnvironment() {
    return this._globalEnvironment;
  }

  private void setGlobalEnvironment(GlobalEnvironment globalEnvironment) {
    this._globalEnvironment = globalEnvironment;
  }

  public SettingsReader getGlobalSettings() {
    return getGlobalEnvironment().getSettingsReader();
  }

  public CommunicationManager getCommManager() {
    if (this._commManager == null)
      this._commManager = new JndiCommunicationManager();

    return this._commManager;
  }

  public void setCommManager(CommunicationManager commManager) {
    this._commManager = commManager;
  }

  private Scheduler getScheduler() {
    return this._scheduler;
  }

  private void setScheduler(Scheduler scheduler) {
    this._scheduler = scheduler;
  }

  private Scheduler getSchedulerForPublisher() {
    return this._schedulerForPublisher;
  }

  private void setSchedulerForPublisher(Scheduler schedulerForPublisher) {
    this._schedulerForPublisher = schedulerForPublisher;
  }

  public CmdbInstanceManager getInstanceManager() {
    return this._instanceManager;
  }

  private void setInstanceManager(CmdbInstanceManager instanceManager) {
    this._instanceManager = instanceManager;
  }

  public SubsystemManagersAccessor getGlobalSubsystemManagers() {
    return this.globalSubsystemManagers;
  }

  public boolean isStartedUp() {
    return this._isStartedUp;
  }

  private void setStartedUp(boolean startedUp) {
    this._isStartedUp = startedUp;
  }

  public ServicesConfig getServicesConfig() {
    return this.servicesConfig;
  }

  public ObserversConfig getObserversConfig() {
    return this.observersConfig;
  }

  public void allocateThreadPool(CommonManager manager, int threadPoolSize) {
    this.requestProcessor.allocateThreadPool(manager, threadPoolSize);
  }

  public String dumpStatus() {
    return this.requestProcessor.dumpStatus();
  }

  public String getFormattedStatus() {
    return this.requestProcessor.getFormattedStatus();
  }

  public void setLock(CommonManager manager) {
    this.requestProcessor.setLock(manager);
  }

  public void setLock(CommonManager manager, int permits) {
    this.requestProcessor.setLock(manager, permits);
  }

  public void setMonitorsFactory(MonitorsFactory monitorsFactory) {
    this.monitorsFactory = monitorsFactory;
  }

  public MonitorsFactory getMonitorsFactory() {
    return this.monitorsFactory;
  }

  public RequestProcessor getRequestProcessor() {
    return this.requestProcessor;
  }

  public void addRequestTimeoutCallback(CmdbCustomerID customerID, RequestTimeoutCallback callback) {
    this.requestProcessor.addRequestTimeoutCallback(customerID, callback);
  }

  public void removeRequestTimeoutCallback(CmdbCustomerID customerID, RequestTimeoutCallback callback) {
    this.requestProcessor.removeRequestTimeoutCallback(customerID, callback);
  }

  public void executeRequestTimeoutCallbacks() {
    this.requestProcessor.executeRequestTimeoutCallbacks();
  }

  public void stopOperation(int operationID) {
    this.requestProcessor.stopOperation(operationID);
  }
}