package com.mercury.topaz.cmdb.server.manage.dal;

import java.sql.SQLException;
import java.util.Date;

public abstract interface CmdbDalPreparedStatement
{
  public abstract void setInt(int paramInt)
    throws SQLException;

  public abstract void setInt(Integer paramInteger)
    throws SQLException;

  public abstract void setLong(long paramLong)
    throws SQLException;

  public abstract void setLong(Long paramLong)
    throws SQLException;

  public abstract void setFloat(float paramFloat)
    throws SQLException;

  public abstract void setFloat(Float paramFloat)
    throws SQLException;

  public abstract void setDouble(double paramDouble)
    throws SQLException;

  public abstract void setDouble(Double paramDouble)
    throws SQLException;

  public abstract void setString(String paramString)
    throws SQLException;

  public abstract void setDate(Date paramDate)
    throws SQLException;

  public abstract void setBoolean(boolean paramBoolean)
    throws SQLException;

  public abstract void setBoolean(Boolean paramBoolean)
    throws SQLException;

  public abstract void setBytes(byte[] paramArrayOfByte)
    throws SQLException;

  public abstract void setBlob(byte[] paramArrayOfByte)
    throws SQLException;

  public abstract void setClob(String paramString)
    throws SQLException;

  public abstract void setObject(Object paramObject)
    throws SQLException;

  public abstract CmdbDalResultSet executeQuery()
    throws CmdbDalException;

  public abstract int executeUpdate()
    throws CmdbDalException;

  public abstract int[] executeBatch();

  public abstract void addBatch();

  public abstract void addBatchSilently();

  public abstract int getBatchSize();

  public abstract void clearBatch()
    throws SQLException;

  public abstract void clearParameters()
    throws SQLException;

  public abstract void close();
}