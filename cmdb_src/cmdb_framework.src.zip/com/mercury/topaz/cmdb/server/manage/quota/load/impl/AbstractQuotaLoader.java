package com.mercury.topaz.cmdb.server.manage.quota.load.impl;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.quota.load.QuotaLoader;

abstract class AbstractQuotaLoader
  implements QuotaLoader
{
  private SettingsReader _settingsReader;

  public AbstractQuotaLoader(SettingsReader settingsReader)
  {
    setSettingsReader(settingsReader);
  }

  protected SettingsReader getSettingsReader() {
    return this._settingsReader;
  }

  private void setSettingsReader(SettingsReader settingsReader) {
    if (settingsReader == null)
      throw new IllegalArgumentException("setting reader is null !!!");

    this._settingsReader = settingsReader;
  }
}