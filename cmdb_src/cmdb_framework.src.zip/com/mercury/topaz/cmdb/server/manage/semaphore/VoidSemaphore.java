package com.mercury.topaz.cmdb.server.manage.semaphore;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public class VoidSemaphore
  implements CmdbSemaphore
{
  public void acquire(FrameworkOperation operation)
    throws InterruptedException
  {
  }

  public void release(FrameworkOperation operation)
  {
  }
}