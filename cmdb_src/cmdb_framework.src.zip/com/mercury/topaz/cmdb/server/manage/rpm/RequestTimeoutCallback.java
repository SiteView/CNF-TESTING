package com.mercury.topaz.cmdb.server.manage.rpm;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface RequestTimeoutCallback
{
  public abstract void execute(Thread paramThread, FrameworkOperation paramFrameworkOperation);
}