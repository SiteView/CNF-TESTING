package com.mercury.topaz.cmdb.server.manage.dal.jdbc_template;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import java.sql.SQLException;

class RowIterator
  implements ResultSetExtractor<Void>
{
  private final RowHandler rowHandler;

  public RowIterator(RowHandler rowHandler)
  {
    this.rowHandler = rowHandler;
  }

  public Void extractData(CmdbDalResultSet rs) throws SQLException {
    while (rs.next())
      this.rowHandler.processRow(rs);

    return null;
  }
}