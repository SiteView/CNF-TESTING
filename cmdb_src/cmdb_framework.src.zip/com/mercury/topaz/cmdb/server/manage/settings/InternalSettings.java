package com.mercury.topaz.cmdb.server.manage.settings;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.TransactionManager;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.JDBCTemplate;
import com.mercury.topaz.cmdb.server.manage.dal.jdbc_template.ResultSetExtractor;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class InternalSettings
{
  private final LocalEnvironment env;
  private static final String SETTINGS_TABLE = "CCM_SETTINGS";
  private static final String COL_ID = "ID";
  private static final String COL_CUSTOMER_ID = "CUSTOMER_ID";
  private static final String COL_KEY = "NAME";
  private static final String COL_VALUE = "VALUE";
  private static Log log = LogFactory.getEasyLog(InternalSettings.class);

  private InternalSettings(LocalEnvironment le)
  {
    this.env = le;
  }

  public static InternalSettings create(LocalEnvironment le) {
    return new InternalSettings(le);
  }

  public void setSystemParameter(String key, String value) {
    TransactionManager.start(this.env.getConnectionsPoolManager());
    try {
      CmdbDalConnection connection = TransactionManager.getConnection();
      JDBCTemplate template = JDBCTemplate.getInstance(connection);
      try {
        updateOrInsert(template, value, key);
      } catch (CmdbDalException e) {
        log.warn("Failed to update/insert setting, perhaps another process trying to do the same. Retrying", e);

        updateOrInsert(template, value, key);
      }
      TransactionManager.commit();
    } finally {
      TransactionManager.rollback();
    }
  }

  private void updateOrInsert(JDBCTemplate template, String value, String key) {
    int rows = template.executeUpdate("update CCM_SETTINGS set VALUE=? where NAME=? and CUSTOMER_ID= ?", new Object[] { value, key, Integer.valueOf(getIntCustomerId()) });

    if (rows == 0)
      template.executeUpdate("insert into CCM_SETTINGS (ID, NAME, VALUE, CUSTOMER_ID) values (" + template.GUID() + ", ?, ?, ?)", new Object[] { key, value, Integer.valueOf(getIntCustomerId()) });
  }

  public String getSystemParameter(String key, String defaultValue)
  {
    TransactionManager.start(this.env.getConnectionsPoolManager());
    CmdbDalConnection connection = TransactionManager.getConnection();
    try {
      JDBCTemplate template = JDBCTemplate.getInstance(connection);
      String value = null;
      try {
        value = template.queryForString("select VALUE from CCM_SETTINGS where NAME = ? and CUSTOMER_ID = ?", new Object[] { key, Integer.valueOf(getIntCustomerId()) });
      }
      catch (CmdbDalException e) {
        log.warn("Cannot retrieve setting " + key + ", using Settings API instead", e);
      }
      if (value == null)
        value = this.env.getSystemParameter(key, defaultValue);

      e = value;

      return e;
    }
    finally
    {
      TransactionManager.commit();
    }
  }

  public Map<String, String> retreiveSettings() {
    TransactionManager.start(this.env.getConnectionsPoolManager());
    CmdbDalConnection connection = TransactionManager.getConnection();
    try {
      JDBCTemplate template = JDBCTemplate.getInstance(connection);
      Map localMap = (Map)template.executeQuery("select NAME, VALUE from CCM_SETTINGS where CUSTOMER_ID=?", new ResultSetExtractor(this)
      {
        public Map<String, String> extractData() throws SQLException
        {
          Map map = new HashMap();
          while (rs.next())
            map.put(rs.getString(1), rs.getString(2));

          return map;
        }
      }
      , new Object[] { Integer.valueOf(getIntCustomerId()) });

      return localMap;
    }
    finally
    {
      TransactionManager.commit();
    }
  }

  private int getIntCustomerId()
  {
    return this.env.getCustomerID().getID();
  }
}