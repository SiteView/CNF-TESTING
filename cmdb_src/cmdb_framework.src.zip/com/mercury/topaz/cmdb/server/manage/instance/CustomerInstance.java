package com.mercury.topaz.cmdb.server.manage.instance;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.ServiceComponentsGroup;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManagersContainer;

public abstract interface CustomerInstance extends SubsystemManagersContainer
{
  public abstract void startUp();

  public abstract void shutdown();

  public abstract void addServiceInstance(String paramString, ServiceComponentsGroup paramServiceComponentsGroup);

  public abstract void removeServiceInstance(String paramString);

  public abstract LocalEnvironment getLocalEnvironment();

  public abstract boolean isServiceInstanceStartedUp(String paramString);
}