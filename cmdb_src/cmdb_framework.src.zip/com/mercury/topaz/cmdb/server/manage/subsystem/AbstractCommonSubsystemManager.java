package com.mercury.topaz.cmdb.server.manage.subsystem;

import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.topaz.cmdb.client.manage.api.CmdbNotification;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.lock.CmdbReadWriteLock;
import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract class AbstractCommonSubsystemManager
  implements SubsystemManager
{
  private CmdbCustomerID _customerID;
  private LocalEnvironment _localEnvironment;
  private CmdbReadWriteLock lock;

  public AbstractCommonSubsystemManager(LocalEnvironment localEnvironment)
  {
    this(localEnvironment.getCustomerID());
    setLocalEnvironment(localEnvironment);
  }

  public AbstractCommonSubsystemManager(CmdbCustomerID customerID)
  {
    setCustomerID(customerID);
  }

  public LocalEnvironment getLocalEnvironment()
  {
    return this._localEnvironment;
  }

  protected void setLocalEnvironment(LocalEnvironment LocalEnvironment) {
    if (LocalEnvironment == null)
      throw new IllegalArgumentException("Attempt to set 'null' localEnvironment");

    this._localEnvironment = LocalEnvironment;
  }

  public MamCustomerID getCustomerID() {
    return ((MamCustomerID)this._customerID);
  }

  public SettingsReader getLocalSettings() {
    return getLocalEnvironment().getSettingsReader();
  }

  private void setCustomerID(CmdbCustomerID customerID) {
    if (customerID == null)
      throw new IllegalArgumentException("customer id null !!!");

    this._customerID = customerID;
  }

  public void executeAsynchronousOperation(FrameworkOperation operation) throws CmdbResponseException {
    ServerApiFacade.executeOperationAsynchronously(operation);
  }

  public void executeOperation(FrameworkOperation operation) throws CmdbResponseException {
    ServerApiFacade.executeOperation(operation);
  }

  /**
   * @deprecated
   */
  protected MamContext getContext()
  {
    return ((MamContext)CmdbContextFactory.createCmdbContext(getCustomerID(), "CMDB"));
  }

  protected void registerListener(CmdbChangeListenerCorseGrained cmdbChangeListenerCorseGrained) {
    CmdbApiFactory.createNotificationService().register(cmdbChangeListenerCorseGrained, getContext());
  }

  protected void unregisterListener(CmdbChangeListenerCorseGrained cmdbChangeListenerCorseGrained) {
    CmdbApiFactory.createNotificationService().unregister(cmdbChangeListenerCorseGrained, getContext());
  }

  public CmdbReadWriteLock getLock() {
    return this.lock;
  }

  public void setLock(CmdbReadWriteLock lock) {
    this.lock = lock;
  }
}