package com.mercury.topaz.cmdb.server.manage.lock;

public abstract interface DataForLockContainer
{
  public abstract boolean isAccepted(DataForLock paramDataForLock);

  public abstract void add(DataForLock paramDataForLock);

  public abstract void remove(DataForLock paramDataForLock);

  public abstract void removeAll();

  public abstract boolean isEntirelyLocked();

  public abstract DataForLock getLockedData();
}