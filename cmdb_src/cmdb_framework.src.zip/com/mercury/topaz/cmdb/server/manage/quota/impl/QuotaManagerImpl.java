package com.mercury.topaz.cmdb.server.manage.quota.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.environment.GlobalEnvironment;
import com.mercury.topaz.cmdb.server.manage.quota.QuotaCheckResponse;
import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.server.manage.quota.load.QuotaLoader;
import com.mercury.topaz.cmdb.server.manage.quota.load.impl.QuotaLoaderFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractGlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import com.mercury.topaz.cmdb.shared.manage.quota.exception.CmdbQuotaException;
import com.mercury.topaz.cmdb.shared.manage.quota.handler.QuotaCountHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class QuotaManagerImpl extends AbstractGlobalSubsystemManager
  implements QuotaManager, MultiReadSingleWrite
{
  private Map<CmdbCustomerID, List<QuotaCountHandler>> customer2CountHandlers = new HashMap();
  private QuotaChecker quotaChecker;

  public QuotaManagerImpl(GlobalEnvironment globalEnvironment)
  {
    super(globalEnvironment);
    setQuotaChecker(new StrictQuotaCheckerImpl());
    Framework.getInstance().setLock(this);
  }

  public void startUp()
  {
    CmdbLogFactory.getCMDBInfoLog().info("QuotaManager is started up properly !!!");
  }

  public void shutdown()
  {
    CmdbLogFactory.getCMDBInfoLog().info("QuotaManager is shutdown properly !!!");
  }

  public List<QuotaCountHandler> getCountHandlers(CmdbCustomerID customerID)
  {
    return ((List)this.customer2CountHandlers.get(customerID));
  }

  public void addCountHandler(CmdbCustomerID customerID, QuotaCountHandler countHandler) {
    List countHandlersForService = (List)this.customer2CountHandlers.get(customerID);
    if (countHandlersForService == null) {
      countHandlersForService = new ArrayList();
      this.customer2CountHandlers.put(customerID, countHandlersForService);
    }
    countHandlersForService.add(countHandler);

    QuotaLoader quotaLoader = QuotaLoaderFactory.createQuotaLoader(getGlobalSettings());
    String serverQuotaName = countHandler.getServerQuotaName();
    String customerQuotaName = countHandler.getCustomerQuotaName();
    if (serverQuotaName != null) {
      int serverQuota = quotaLoader.getQuotaValue(serverQuotaName);
      addServerQuotaInfo(serverQuotaName, serverQuota, customerQuotaName);
    }
  }

  public Map<CmdbCustomerID, CustomerQuotasAndCounts> getCustomersQuotasAndCounts() {
    return getQuotaChecker().getCustomersQuotasAndCountsClone();
  }

  public Map<String, QuotaCount> getServerQuotasAndCounts() {
    return getQuotaChecker().getServerQuotasAndCountsClone();
  }

  public void addCustomerQuotaInfo(CmdbCustomerID customerID, String quotaName, int quota) {
    getQuotaChecker().addCustomerQuotaInfo(customerID, quotaName, quota);
  }

  public void changeCustomerQuota(CmdbCustomerID customerID, String quotaName, int quota) throws CmdbQuotaException {
    getQuotaChecker().changeCustomerQuota(customerID, quotaName, quota);
  }

  public void addServerQuotaInfo(String quotaname, int quota, String relatedCustomerQuotaName) {
    getQuotaChecker().addServerQuotaInfo(quotaname, quota, relatedCustomerQuotaName);
  }

  public void changeServerQuota(String quotaname, int quota) throws CmdbQuotaException {
    getQuotaChecker().changeServerQuota(quotaname, quota);
  }

  public void setCustomerCurrentCount(CmdbCustomerID customerID, String quotaName, int newCount) {
    getQuotaChecker().setCustomerCurrentCount(customerID, quotaName, newCount);
  }

  public void resetAllCounts() {
    getQuotaChecker().resetAllCurrentCounts();
  }

  public void removeCustomerCounts(CmdbCustomerID customerID) {
    this.customer2CountHandlers.remove(customerID);
    getQuotaChecker().removeCustomerQuotaAndCounts(customerID);
  }

  public QuotaCheckResponse checkQuota(CmdbCustomerID customerID, String quotaName, int count)
  {
    try {
      return getQuotaChecker().checkQuota(customerID, quotaName, count);
    }
    catch (Exception e) {
    }
    return new QuotaCheckResponseImpl(true, "error occured: " + e.getMessage());
  }

  private QuotaChecker getQuotaChecker()
  {
    return this.quotaChecker;
  }

  private void setQuotaChecker(QuotaChecker quotaChecker) {
    this.quotaChecker = quotaChecker;
  }

  public String getName() {
    return "Quota Management Task";
  }

  public void checkQuotas(CmdbRequest request) {
    if (!(shouldCheckQuota())) {
      return;
    }

    if (request.getOperation() instanceof CmdbUpdate) {
      List quotaCountHandlers = (List)this.customer2CountHandlers.get(request.getCustomerID());
      if (quotaCountHandlers == null)
        return;

      for (Iterator i$ = quotaCountHandlers.iterator(); i$.hasNext(); ) { QuotaCountHandler quotaCountHandler = (QuotaCountHandler)i$.next();
        quotaCountHandler.checkQuota(request);
      }
    }
  }

  private boolean shouldCheckQuota() {
    return getGlobalSettings().getBoolean("quota.check.enabled", true);
  }
}