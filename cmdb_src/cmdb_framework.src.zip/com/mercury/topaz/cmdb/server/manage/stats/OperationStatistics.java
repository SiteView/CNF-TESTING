package com.mercury.topaz.cmdb.server.manage.stats;

import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.util.stats.DetailedMessageProvider;
import com.mercury.topaz.cmdb.shared.util.stats.TimeBasedStatistics;
import java.util.Timer;
import java.util.TimerTask;

public class OperationStatistics
{
  private static Log log = CmdbLogFactory.getStatisticsLog();
  private TimeBasedStatistics<String> statistics;
  private Timer timer = null;
  private DumpTask dumpTask = null;
  private int taskDelayMinutes;
  private long taskDelay;
  private int maxWorst;

  protected int getSetting(String name, int def)
  {
    return Framework.getInstance().getGlobalSettings().getInt(name, def);
  }

  public OperationStatistics(Timer timer)
  {
    this.taskDelayMinutes = getSetting("operation.statistics.dump.minutes", 10);
    this.taskDelay = (this.taskDelayMinutes * 1000L * 60L);
    this.maxWorst = getSetting("operation.statistics.worst.num", 5);

    this.timer = timer;
    this.statistics = new TimeBasedStatistics(this.maxWorst);
    init();
  }

  public synchronized void gatherOperationTime(CmdbRequest request, long duration, long invoked)
  {
    if (!(log.isInfoEnabled())) {
      return;
    }

    if (request == null)
      return;

    FrameworkOperation op = request.getOperation();
    if (op == null) {
      return;
    }

    CmdbContext context = request.getContext();
    String appName = context.getCallerApplicationName();
    String customerID = String.valueOf(context.getCustomerID().getID());
    StringBuilder key = new StringBuilder("Class: ");
    key.append(op.getClass().getName()).append(" # CallerApp: ").append(appName).append(" # CustomerID: ").append(customerID);

    this.statistics.gather(key.toString(), duration, invoked, new DetailedMessageProvider(this, request) {
      public String lazyMessageFetch() {
        FrameworkOperation op = this.val$request.getOperation();
        StringBuilder details = new StringBuilder("RequestID: ");
        details.append(this.val$request.getID());
        details.append(" # Name: ").append(op.getOperationName());

        String verbose = op.getMessageIncludingParameters();
        if ((verbose != null) && (!(verbose.startsWith("Short audit message wasn't implemented")))) {
          details.append(" # Verbose: ").append(verbose);
        }

        if (details.length() > 512) {
          details.setLength(509);
          details.append("...");
        }
        return details.toString();
      }
    });
  }

  public synchronized String dump()
  {
    String text = this.statistics.dump();
    log.info(text);
    return text;
  }

  public synchronized void reset() {
    this.statistics.reset();
  }

  private synchronized void init()
  {
    if (this.dumpTask != null)
      throw new RuntimeException("dumpTask != null");

    this.dumpTask = new DumpTask(this, null);
    schedule();
  }

  public synchronized void reschedule()
  {
    this.dumpTask.cancel();
    this.dumpTask = new DumpTask(this, null);
    schedule();
  }

  public synchronized void shutdown()
  {
    if (this.dumpTask != null)
      this.dumpTask.cancel();
    dump();
    this.dumpTask = null;
  }

  public TimeBasedStatistics getTimeBasedStatistics()
  {
    return this.statistics;
  }

  private void schedule() {
    this.timer.schedule(this.dumpTask, this.taskDelay, this.taskDelay);
  }

  private class DumpTask extends TimerTask
  {
    public void run()
    {
      this.this$0.dump();
      this.this$0.reset();
    }
  }
}