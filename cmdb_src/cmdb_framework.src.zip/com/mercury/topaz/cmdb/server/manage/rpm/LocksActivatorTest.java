package com.mercury.topaz.cmdb.server.manage.rpm;

import java.io.PrintStream;

class LocksActivatorTest
{
  public static void main(String[] args)
  {
    iteration();
    System.out.println("Next:\n");
    iteration();
  }

  private static void iteration() {
    allOK();
    failOnStartup();
    failOnShutdown();
    failOnLogic();
  }

  private static void allOK() {
    LocksActivator act = new LocksActivator();
    act.addLock(new LocksActivator.Locking() {
      public void lock() throws Exception {
        System.out.println(LocksActivatorTest.access$000());
      }

      public void unlock() throws Exception {
        System.out.println(LocksActivatorTest.access$100());
      }

    });
    act.addLock(new LocksActivator.Locking() {
      public void lock() throws Exception {
        System.out.println(LocksActivatorTest.access$200());
      }

      public void unlock() throws Exception {
        System.out.println(LocksActivatorTest.access$300());
      }

    });
    runLogic(act); }

  private static void failOnLogic() {
    LocksActivator act = new LocksActivator();
    act.addLock(new LocksActivator.Locking() {
      public void lock() throws Exception {
        System.out.println(LocksActivatorTest.access$000());
      }

      public void unlock() throws Exception {
        System.out.println(LocksActivatorTest.access$100());
      }

    });
    act.addLock(new LocksActivator.Locking() {
      public void lock() throws Exception {
        System.out.println(LocksActivatorTest.access$200());
      }

      public void unlock() throws Exception {
        System.out.println(LocksActivatorTest.access$300());
      }

    });
    failLogic(act); }

  private static String lockMessage1() {
    return "1 locked"; } 
  private static String unlockMessage1() { return "1 unlocked"; } 
  private static String lockMessage2() { return "2 locked"; } 
  private static String unlockMessage2() { return "2 unlocked"; } 
  private static void lockFail2() throws Exception { throw new Exception("2 failed on lock"); } 
  private static void rollbackFail2() throws Exception { throw new Exception("2 failed on unlock"); }

  private static void runLogic(LocksActivator act) {
    System.out.println("\nSTART");
    try {
      act.lock();
      try {
        System.out.println("Logic execution succeeded");
      } finally {
        act.unlock();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    System.out.println("DONE\n");
  }

  private static void failLogic(LocksActivator act) {
    try {
      act.lock();
      try {
        throw new Exception("Logic execution failed");
      } finally {
        act.unlock();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private static void failOnStartup() {
    LocksActivator act = new LocksActivator();
    act.addLock(new LocksActivator.Locking() {
      public void lock() throws Exception {
        System.out.println(LocksActivatorTest.access$000());
      }

      public void unlock() throws Exception {
        System.out.println(LocksActivatorTest.access$100());
      }

    });
    act.addLock(new LocksActivator.Locking() {
      public void lock() throws Exception {
        LocksActivatorTest.access$400();
      }

      public void unlock() throws Exception {
        System.out.println(LocksActivatorTest.access$300());
      }

    });
    runLogic(act);
  }

  private static void failOnShutdown() {
    LocksActivator act = new LocksActivator();
    act.addLock(new LocksActivator.Locking() {
      public void lock() throws Exception {
        System.out.println(LocksActivatorTest.access$000());
      }

      public void unlock() throws Exception {
        System.out.println(LocksActivatorTest.access$100());
      }

    });
    act.addLock(new LocksActivator.Locking() {
      public void lock() throws Exception {
        System.out.println(LocksActivatorTest.access$200());
      }

      public void unlock() throws Exception {
        LocksActivatorTest.access$500();
      }

    });
    runLogic(act);
  }
}