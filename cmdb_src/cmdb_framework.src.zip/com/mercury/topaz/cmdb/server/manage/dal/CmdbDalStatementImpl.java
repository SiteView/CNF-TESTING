package com.mercury.topaz.cmdb.server.manage.dal;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

public class CmdbDalStatementImpl
  implements CmdbDalPreparedStatement
{
  public static final String ORACLE_NULL_VALUE = "null";
  private static final String QUESTION_MARK_DELIMITER = "?";
  private String _query = null;
  private Statement _statement = null;
  private static final char[] intToHexChar = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

  public CmdbDalStatementImpl(Statement statement, String query)
  {
    setStatement(statement);
    setQuery(query);
  }

  private void insertString(String value) {
    int questionMarkLocation = findDelimiterInLocation(1, "?");
    String oldQuery = getQuery();
    String newQuery = oldQuery.substring(0, questionMarkLocation) + value + oldQuery.substring(questionMarkLocation + 1);

    setQuery(newQuery);
  }

  private void setNull() {
    insertString("null");
  }

  public void setInt(Integer value) throws SQLException {
    if (value == null)
      setNull();
    else
      setInt(value.intValue());
  }

  public void setInt(int value) throws SQLException
  {
    insertString(value + "");
  }

  public void setLong(Long value) throws SQLException {
    if (value == null)
      setNull();
    else
      setLong(value.longValue());
  }

  public void setLong(long value) throws SQLException
  {
    insertString(value + "");
  }

  public void setFloat(Float value) throws SQLException {
    if (value == null)
      setNull();
    else
      setFloat(value.floatValue());
  }

  public void setFloat(float value) throws SQLException
  {
    insertString(value + "");
  }

  public void setDouble(Double value) throws SQLException {
    if (value == null)
      setNull();
    else
      setDouble(value.doubleValue());
  }

  public void setDouble(double value) throws SQLException
  {
    insertString(value + "D");
  }

  public void setDate(Date value) throws SQLException {
    if (value == null)
      setNull();
    else
      insertString(value.getTime() + "");
  }

  public void setBoolean(Boolean value) throws SQLException
  {
    if (value == null)
      setNull();
    else
      setBoolean(value.booleanValue());
  }

  public void setBoolean(boolean value)
    throws SQLException
  {
    String boolVal;
    if (value)
      boolVal = "1";
    else
      boolVal = "0";

    insertString(boolVal);
  }

  private String bytesToString(byte[] bytes) {
    char[] ret = new char[bytes.length * 2];
    for (int i = 0; i < bytes.length; ++i) {
      ret[(2 * i)] = intToHexChar[(bytes[i] >> 4 & 0xF)];
      ret[(2 * i + 1)] = intToHexChar[(bytes[i] & 0xF)];
    }

    return new String(ret);
  }

  public void setBytes(byte[] value)
    throws SQLException
  {
    if (value == null) {
      setNull();
    } else {
      String strVal = bytesToString(value).toUpperCase();

      strVal = "hextoraw('" + strVal + "')";
      insertString(strVal);
    }
  }

  public void setBlob(byte[] value) throws SQLException {
    throw new UnsupportedOperationException("This decorator is for select queries only");
  }

  public void setClob(String value) throws SQLException {
    throw new UnsupportedOperationException("This decorator is for select queries only");
  }

  public void setObject(Object value) throws SQLException {
    if (value instanceof String)
      setString((String)value);
    else if (value instanceof Boolean)
      setBoolean((Boolean)value);
    else if (value instanceof Integer)
      setInt((Integer)value);
    else if (value instanceof Long)
      setLong((Long)value);
    else if (value instanceof Float)
      setFloat((Float)value);
    else if (value instanceof Double)
      setDouble((Double)value);
    else if (value instanceof Date)
      setDate((Date)value);
    else if (value instanceof byte[])
      setBytes((byte[])(byte[])value);
    else
      throw new UnsupportedOperationException("Instances of type " + value.getClass().getName() + " are not supported in setObject method");
  }

  public void setString(String value)
    throws SQLException
  {
    if ((value == null) || (value.length() == 0)) {
      setNull();
    } else {
      value = value.replaceAll("'", "''");
      value = "'" + value + "'";
      insertString(value);
    }
  }

  private int findDelimiterInLocation(int index, String delimiter) {
    String query = getQuery();

    int questionMarkLocation = -1;
    for (int i = 0; i < index; ++i) {
      questionMarkLocation = query.indexOf(delimiter, questionMarkLocation + 1);

      if ((query.length() > questionMarkLocation + 1) && (((query.substring(questionMarkLocation - 1, questionMarkLocation + 2).equals("'?'")) || (query.substring(questionMarkLocation, questionMarkLocation + 2).equals("?_")))))
      {
        --i;
      }
    }
    return questionMarkLocation;
  }

  public int executeUpdate() throws CmdbDalException {
    try {
      DalCallStack.logStatement(toString());

      return getStatement().executeUpdate(getQuery());
    } catch (Throwable t) {
      String errMsg = "Can't execute statement [" + toString() + "], due to exception: " + t;
      throw new CmdbDalException(errMsg, t);
    }
  }

  public int[] executeBatch() {
    throw new UnsupportedOperationException("This decorator is for select queries only");
  }

  public int getBatchSize() {
    return 0;
  }

  public void addBatch() {
    throw new UnsupportedOperationException("This decorator is for select queries only");
  }

  public void addBatchSilently() {
    throw new UnsupportedOperationException("This decorator is for select queries only");
  }

  public void clearBatch() throws SQLException {
    throw new UnsupportedOperationException("This decorator is for select queries only");
  }

  public void clearParameters() throws SQLException {
    throw new UnsupportedOperationException("This decorator is for select queries only");
  }

  public CmdbDalResultSet executeQuery()
    throws CmdbDalException
  {
    try
    {
      DalCallStack.logStatement(toString());

      getStatement().execute(getQuery());

      CmdbDalResultSet resultSet = new CmdbDalResultSet(getStatement().getResultSet());
      return resultSet;
    } catch (Throwable t) {
      String errMsg = "Can't execute statement [" + getQuery() + "], due to exception: " + t;
      throw new CmdbDalException(errMsg, t);
    }
  }

  public void close()
  {
    try {
      getStatement().close();
    } catch (Throwable t) {
      String errMsg = "Failed to close statement [" + this._query + "], due to exception: " + t;
      throw new CmdbDalException(errMsg, t);
    }
  }

  public String toString() {
    StringBuffer res = new StringBuffer();
    res.append(super.toString()).append("### query [").append(getQuery()).append("]");
    return res.toString();
  }

  private String getQuery() {
    return this._query;
  }

  private void setQuery(String query) {
    this._query = query;
  }

  private Statement getStatement() {
    return this._statement;
  }

  private void setStatement(Statement statement) {
    this._statement = statement;
  }
}