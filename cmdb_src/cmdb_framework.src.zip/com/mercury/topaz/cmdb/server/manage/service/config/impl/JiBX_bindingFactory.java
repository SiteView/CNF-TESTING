package com.mercury.topaz.cmdb.server.manage.service.config.impl;

import org.jibx.runtime.IBindingFactory;

public class JiBX_bindingFactory
  implements IBindingFactory
{
  private static IBindingFactory m_inst;
}