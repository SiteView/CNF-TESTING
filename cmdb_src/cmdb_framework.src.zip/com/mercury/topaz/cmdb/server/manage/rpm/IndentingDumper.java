package com.mercury.topaz.cmdb.server.manage.rpm;

public class IndentingDumper
{
  private StringBuilder indent;
  private StringBuilder info;

  public IndentingDumper()
  {
    this(new StringBuilder());
  }

  public IndentingDumper(StringBuilder indent) {
    this.indent = indent;
    this.info = new StringBuilder();
  }

  public void increaseIndent() {
    this.indent.append("\t");
  }

  public void decreaseIndent() {
    this.indent.delete(this.indent.lastIndexOf("\t"), this.indent.length());
  }

  public void append(String info) {
    this.info.append(this.indent).append(info).append("\n");
  }

  public String toString() {
    return this.info.toString();
  }
}