package com.mercury.topaz.cmdb.server.manage.dal;

public abstract interface CmdbDalTransaction
{
  public abstract void commit()
    throws CmdbDalException;

  public abstract void rollback()
    throws CmdbDalException;

  public abstract int incrementRefCount();

  public abstract int decrementRefCount();

  public abstract CmdbDalConnection getConnection();
}