package com.mercury.topaz.cmdb.server.manage.quota.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaCheckResponse;

class QuotaCheckResponseImpl
  implements QuotaCheckResponse
{
  private boolean _canBeIncreased;
  private String _checkInfo;

  public QuotaCheckResponseImpl(boolean isIncreased, String checkInfo)
  {
    setCanBeIncreased(isIncreased);
    setCheckInfo(checkInfo);
  }

  public boolean canBeIncreased() {
    return this._canBeIncreased;
  }

  private void setCanBeIncreased(boolean canBeIncreased) {
    this._canBeIncreased = canBeIncreased;
  }

  public String getCheckInfo()
  {
    return this._checkInfo;
  }

  private void setCheckInfo(String checkInfo) {
    this._checkInfo = checkInfo;
  }
}