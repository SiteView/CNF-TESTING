package com.mercury.topaz.cmdb.server.manage.dal;

import com.mercury.infra.utils.db.pools.DbContext;
import java.sql.Connection;

public class CmdbDalConnectionFactory
{
  static CmdbDalConnection create(Connection connection, DbContext dbContext, ConnectionPoolManager connectionPool)
  {
    return new CmdbDalConnection(connection, dbContext, connectionPool);
  }
}