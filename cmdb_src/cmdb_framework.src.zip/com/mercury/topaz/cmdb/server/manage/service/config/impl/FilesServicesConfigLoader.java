package com.mercury.topaz.cmdb.server.manage.service.config.impl;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.service.config.ServiceConfig;
import com.mercury.topaz.cmdb.server.manage.service.config.ServicesConfig;
import com.mercury.topaz.cmdb.server.manage.service.config.ServicesConfigLoader;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.util.XmlUtils;
import com.mercury.topaz.cmdb.shared.util.filesystem.traverse.FilesHandler;
import com.mercury.topaz.cmdb.shared.util.filesystem.traverse.FilesTraverse;
import java.io.File;
import java.io.IOException;

public class FilesServicesConfigLoader
  implements ServicesConfigLoader
{
  private final SettingsReader settingsReader;

  public FilesServicesConfigLoader(SettingsReader settingsReader)
  {
    this.settingsReader = settingsReader;
  }

  public ServicesConfig loadServicesConfig() {
    ServicesConfig servicesConfig = ServiceConfigFactory.createServicesConfig();
    String servicesFolder = this.settingsReader.getTopazHome() + File.separator + "cmdb/services";
    FilesTraverse.traverse(servicesFolder, new ServiceConfigFileHandler(servicesConfig));
    return servicesConfig;
  }

  private static class ServiceConfigFileHandler
  implements FilesHandler {
    private ServicesConfig _servicesConfig;

    public ServiceConfigFileHandler(ServicesConfig servicesConfig) {
      setServicesConfig(servicesConfig);
    }

    public void handleFile(String fileName)
    {
      if (!(fileName.endsWith("service-config.xml")))
        return;
      try
      {
        String serviceConfigXml = XmlUtils.getFileContentAsString(fileName);
        ServiceConfig serviceConfig = (ServiceConfig)XmlUtils.fromXML(serviceConfigXml, ServiceConfigImpl.class);
        getServicesConfig().addServiceConfig(serviceConfig);
      } catch (IOException e) {
        throw new CmdbException("Error while parsing file " + fileName, e);
      }
    }

    public void handleEnterFolder(String folderName) {
    }

    public void handleExitFolder(String folderName) {
    }

    private ServicesConfig getServicesConfig() {
      return this._servicesConfig;
    }

    private void setServicesConfig(ServicesConfig servicesConfig) {
      this._servicesConfig = servicesConfig;
    }
  }
}