package com.mercury.topaz.cmdb.server.monitor.impl;

import com.mercury.topaz.cmdb.server.monitor.CmdbMonitorStatistics;
import com.mercury.topaz.cmdb.shared.monitor.action.MeasuredActionResult;
import com.mercury.topaz.cmdb.shared.monitor.action.impl.MeasuredActionResultFactory;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

class CmdbMonitorStatisticsImpl
  implements CmdbMonitorStatistics
{
  private Map _executionResults = null;
  private boolean _executionTimeout;

  public CmdbMonitorStatisticsImpl()
  {
    setExecutionTimes(new HashMap());
    setExecutionTimeout(false);
  }

  private boolean getTimeoutOccured() {
    return isExecutionTimeout();
  }

  public void addExecutionTimeByAction(String name, String desc, long time) {
    getExecutionResults().put(name, MeasuredActionResultFactory.create(name, desc, time));
  }

  public void setTimeoutOccured(boolean timeoutState) {
    setExecutionTimeout(timeoutState);
  }

  public String toString() {
    StringBuffer buffer = new StringBuffer();
    if (this._executionTimeout)
      buffer.append("Timeout occured. ");
    else
      buffer.append("Timeout didn't occur. ");
    buffer.append("The Last times:");
    Iterator it = getExecutionResults().keySet().iterator();
    while (it.hasNext()) {
      String key = (String)it.next();
      MeasuredActionResult result = (MeasuredActionResult)getExecutionResults().get(key);
      buffer.append(result.getDescription());
      buffer.append(":");
      buffer.append(result.getExecutionTime());
      buffer.append("\t");
    }

    return buffer.toString();
  }

  public Map getExecutionResults() {
    return this._executionResults;
  }

  private void setExecutionTimes(Map executionTimes) {
    this._executionResults = executionTimes;
  }

  private boolean isExecutionTimeout() {
    return this._executionTimeout;
  }

  private void setExecutionTimeout(boolean executionTimeout) {
    this._executionTimeout = executionTimeout;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof CmdbMonitorStatisticsImpl))
      throw new IllegalArgumentException("one of the arguments isn't instance of CmdbMonitorStatisticsImpl");

    CmdbMonitorStatisticsImpl stat1 = (CmdbMonitorStatisticsImpl)obj;

    return ((stat1.getTimeoutOccured() == getTimeoutOccured()) && (stat1.getExecutionResults().equals(getExecutionResults())));
  }

  public int hashCode()
  {
    return getExecutionResults().hashCode();
  }
}