package com.mercury.topaz.cmdb.server.monitor.impl;

import com.mercury.topaz.cmdb.server.monitor.CmdbMonitorStatistics;

public class CmdbMonitorStatisticsFactory
{
  public static CmdbMonitorStatistics create()
  {
    return new CmdbMonitorStatisticsImpl();
  }
}