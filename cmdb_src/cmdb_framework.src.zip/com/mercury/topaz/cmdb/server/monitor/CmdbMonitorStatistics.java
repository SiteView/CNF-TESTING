package com.mercury.topaz.cmdb.server.monitor;

import java.io.Serializable;
import java.util.Map;

public abstract interface CmdbMonitorStatistics extends Serializable
{
  public abstract void addExecutionTimeByAction(String paramString1, String paramString2, long paramLong);

  public abstract void setTimeoutOccured(boolean paramBoolean);

  public abstract Map getExecutionResults();
}