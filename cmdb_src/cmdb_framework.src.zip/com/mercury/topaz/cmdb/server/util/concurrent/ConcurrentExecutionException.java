package com.mercury.topaz.cmdb.server.util.concurrent;

import com.mercury.topaz.cmdb.shared.base.CmdbException;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class ConcurrentExecutionException extends CmdbException
{
  private Collection<Throwable> throwables = new LinkedList();

  public ConcurrentExecutionException()
  {
    super("Exception(s) occurred during concurrent execution");
  }

  public void add(Throwable t) {
    this.throwables.add(t);
  }

  public boolean empty() {
    return this.throwables.isEmpty();
  }

  public void printStackTrace()
  {
    super.printStackTrace();

    for (Iterator i$ = this.throwables.iterator(); i$.hasNext(); ) { Throwable throwable = (Throwable)i$.next();
      throwable.printStackTrace();
    }
  }

  public Collection<Throwable> getThrowables() {
    return this.throwables;
  }
}