package com.mercury.topaz.cmdb.server.util.concurrent;

import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbContextRepository;
import com.mercury.topaz.cmdb.shared.util.ThreadUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @deprecated
 */
public class ConcurrentExecutor
{
  private static final int DEFAULT_CONCURRENCY_LEVEL = 10;
  private ThreadPoolExecutor executor;
  private int concurrencyLevel;
  private long timeout;
  private TimeUnit timeUnit;

  public ConcurrentExecutor()
  {
    this.concurrencyLevel = 10;
  }

  public void setTimeout(long timeout, TimeUnit timeUnit)
  {
    this.timeout = timeout;
    this.timeUnit = timeUnit;
  }

  public void setConcurrencyLevel(int concurrencyLevel) {
    this.concurrencyLevel = ((concurrencyLevel > 0) ? concurrencyLevel : 10);

    if (this.executor != null) {
      this.executor.setCorePoolSize(concurrencyLevel);
      this.executor.setMaximumPoolSize(concurrencyLevel);
    }
  }

  public Collection<Object> execute(Collection<Callable<Object>> executables) {
    if (executables == null) {
      throw new CmdbException("Can not execute null collection of executables");
    }

    ThreadPoolExecutor executor = getExecutor();

    Collection futures = new ArrayList();
    CmdbContext context = CmdbContextRepository.get();
    for (Iterator i$ = executables.iterator(); i$.hasNext(); ) { Callable executable = (Callable)i$.next();

      Callable wrapper = createCallableWrapper(context, executable);

      futures.add(executor.submit(wrapper));
    }

    return waitForCompletion(futures);
  }

  private Callable<Object> createCallableWrapper(CmdbContext context, Callable<Object> executable) {
    return new Callable(this, context, executable)
    {
      public Object call() throws Exception {
        CmdbContextRepository.push(this.val$context);
        try {
          Object localObject1 = this.val$executable.call();

          return localObject1;
        }
        finally
        {
          CmdbContextRepository.pop();
        }
      }
    };
  }

  private Collection<Object> waitForCompletion(Collection<Future<Object>> futures) {
    ConcurrentExecutionException compositeException = new ConcurrentExecutionException();
    Collection results = new LinkedList();
    for (Iterator i$ = futures.iterator(); i$.hasNext(); ) { Future future = (Future)i$.next();
      try {
        if (this.timeout != 0L)
          results.add(future.get(this.timeout, this.timeUnit));
        else
          results.add(future.get());
      }
      catch (Throwable t) {
        compositeException.add(t);
      }
    }

    if (!(compositeException.empty())) {
      throw compositeException;
    }

    return results;
  }

  private ThreadPoolExecutor getExecutor() {
    if (this.executor == null) {
      this.executor = ThreadUtil.createTypicalThreadPool(super.toString(), this.concurrencyLevel);
    }

    return this.executor;
  }
}