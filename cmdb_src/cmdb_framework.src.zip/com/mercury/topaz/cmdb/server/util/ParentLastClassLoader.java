package com.mercury.topaz.cmdb.server.util;

import java.net.URL;
import java.net.URLClassLoader;

public class ParentLastClassLoader extends URLClassLoader
{
  public ParentLastClassLoader(URL[] urls, ClassLoader parent)
  {
    super(urls, parent);
  }

  public Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException
  {
    Class c = findLoadedClass(name);

    if (c == null) {
      try {
        c = findClass(name);

        if (resolve)
          resolveClass(c);
      }
      catch (ClassNotFoundException e) {
        c = super.loadClass(name, resolve);
      }
      return c;
    }

    if (resolve)
      resolveClass(c);

    return c;
  }

  public String toString()
  {
    StringBuilder buf = new StringBuilder("Class loader (" + getClass() + ") for the following URLs:\n");

    URL[] arr$ = getURLs(); int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { URL url = arr$[i$];
      buf.append("\n").append(url);
    }
    buf.append("\n\nwith parent class loader: ").append(getParent());
    return buf.toString();
  }
}