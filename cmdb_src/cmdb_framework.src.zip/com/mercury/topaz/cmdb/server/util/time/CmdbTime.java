package com.mercury.topaz.cmdb.server.util.time;

import com.mercury.infra.utils.time.MTimeManager;
import com.mercury.infra.utils.time.MTimeUtils;
import java.io.Serializable;

public class CmdbTime
  implements Serializable
{
  private static final CmdbTimeInterface _timeImpl = new MTimeCmdbTime(null);

  public static long currentTimeMillis()
  {
    return _timeImpl.currentTimeMillis();
  }

  private static class MTimeCmdbTime
  implements CmdbTime.CmdbTimeInterface
  {
    public long currentTimeMillis()
    {
      return MTimeUtils.secondsToMillis(MTimeManager.getEasyTime());
    }
  }

  private static class LocalCmdbTime
  implements CmdbTime.CmdbTimeInterface
  {
    public long currentTimeMillis()
    {
      return System.currentTimeMillis();
    }
  }

  private static abstract interface CmdbTimeInterface
  {
    public abstract long currentTimeMillis();
  }
}