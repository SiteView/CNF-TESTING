package com.mercury.topaz.cmdb.server.notification.task;

public class DeploymentTask
{
  public static final String NAME = "Deployment Task";
}