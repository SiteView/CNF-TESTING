package com.mercury.topaz.cmdb.server.notification.adapter.jms;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.itc.schedule.PeriodicTaskable;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher.JMSPublisher;
import java.util.Iterator;
import java.util.List;

public class NotificationQueueFlushPeriodicTask
  implements PeriodicTaskable
{
  private static Log _logger = LogFactory.getEasyLog(NotificationQueueFlushPeriodicTask.class);
  private int _interval;
  private List<JMSPublisher> _publishers;

  public NotificationQueueFlushPeriodicTask(int interval, List<JMSPublisher> publishers)
  {
    setInterval(interval);
    setPublishers(publishers);
  }

  public int getIntervalInSec() {
    return this._interval;
  }

  public void execute() {
    for (Iterator i$ = getPublishers().iterator(); i$.hasNext(); ) { JMSPublisher publisher = (JMSPublisher)i$.next();
      long startTime = System.currentTimeMillis();
      publisher.flushQueuedMessages();
      long endTime = System.currentTimeMillis();
      if (_logger.isDebugEnabled())
        _logger.debug("queue was asked to be flushed for publisher [" + publisher + "], flushing time: " + (endTime - startTime));
    }
  }

  public Object getTaskId()
  {
    return "Notification Queue Flush Periodic Task";
  }

  private void setInterval(int interval)
  {
    this._interval = interval;
  }

  private List<JMSPublisher> getPublishers() {
    return this._publishers;
  }

  private void setPublishers(List<JMSPublisher> publishers) {
    if ((publishers == null) || (publishers.size() == 0))
      throw new IllegalArgumentException("publishers list is null or empty !!!");

    this._publishers = publishers;
  }
}