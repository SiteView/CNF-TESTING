package com.mercury.topaz.cmdb.server.notification.task.publish.operation.impl;

import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.server.notification.task.publish.NotificationPublishManager;
import com.mercury.topaz.cmdb.server.notification.task.publish.operation.NotificationPublishOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractFrameworkOperation;

public abstract class AbstractNotificationPublishOperation extends AbstractFrameworkOperation
  implements NotificationPublishOperation
{
  private String _taskName;

  public AbstractNotificationPublishOperation(String taskName)
  {
    setTaskName(taskName);
  }

  protected void doExecute(SubsystemManager manager, CmdbResponse response) throws CmdbException {
    notificationPublishExecute((NotificationPublishManager)manager, response);
  }

  private void setTaskName(String taskName) {
    if ((taskName == null) || (taskName.length() == 0))
      throw new IllegalArgumentException("task name is null or empty !!!");

    this._taskName = taskName;
  }

  public final String getExecutionTaskQueueName() {
    return this._taskName;
  }

  public String getServiceName() {
    return "Framework service";
  }
}