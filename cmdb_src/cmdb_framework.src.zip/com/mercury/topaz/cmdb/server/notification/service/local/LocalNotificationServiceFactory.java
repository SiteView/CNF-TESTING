package com.mercury.topaz.cmdb.server.notification.service.local;

import com.mercury.topaz.cmdb.shared.notification.service.CmdbNotificationService;
import com.mercury.topaz.cmdb.shared.notification.service.ListenersManager;
import java.util.Set;

public class LocalNotificationServiceFactory
{
  public static CmdbNotificationService createConcurrent(Set publishTaskNames)
  {
    ListenersManager listenersManager = LocalListenersManagerFactory.createConcurrent(publishTaskNames);
    return new CmdbLocalNotificationServiceImpl(listenersManager);
  }
}