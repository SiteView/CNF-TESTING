package com.mercury.topaz.cmdb.server.notification.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractCommonSubsystemManager;
import com.mercury.topaz.cmdb.server.notification.DeploymentManager;
import com.mercury.topaz.cmdb.server.notification.service.local.LocalNotificationServiceFactory;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListener;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.change.id.ChangeListenerID;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.notification.filter.CmdbNotificationFilter;
import com.mercury.topaz.cmdb.shared.notification.service.CmdbNotificationService;
import java.util.Set;

class DeploymentManagerImpl extends AbstractCommonSubsystemManager
  implements DeploymentManager, SingleReadSingleWrite
{
  private static final int CONCURRENT_NOTIFICATIONS_LIMIT = 1;
  private CmdbNotificationService _notificationService;
  private static final String NAME = "Deployment Task";

  public DeploymentManagerImpl(LocalEnvironment LocalEnvironment, Set publishTaskNames)
  {
    super(LocalEnvironment);
    CmdbNotificationService cmdbNotificationService = LocalNotificationServiceFactory.createConcurrent(publishTaskNames);
    setNotificationService(cmdbNotificationService);
    Framework.getInstance().setLock(this);
  }

  public void startUp() {
    getNotificationService().startUp();

    Framework.getInstance().allocateThreadPool(this, 1);

    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: DeploymentManager is started up properly !!!");
  }

  public void shutdown() {
    getNotificationService().shutdown();
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: DeploymentManager is shutdown properly !!!");
  }

  public void register(CmdbChangeListenerFineGrained changeListener, CmdbContext context)
  {
    getNotificationService().register(changeListener, context);
  }

  public void register(CmdbNotificationFilter filter, CmdbChangeListenerFineGrained listener, CmdbContext context) {
    getNotificationService().register(filter, listener, context);
  }

  public void register(CmdbChangeListenerCorseGrained changeListener, CmdbContext context)
  {
    getNotificationService().register(changeListener, context);
  }

  public void register(CmdbNotificationFilter filter, CmdbChangeListenerCorseGrained listener, CmdbContext context) {
    getNotificationService().register(filter, listener, context);
  }

  public void unregister(ChangeListenerID changeListenerID, CmdbContext context)
  {
    getNotificationService().unregister(changeListenerID, context);
  }

  public void unregister(CmdbChangeListener listener, CmdbContext context) {
    getNotificationService().unregister(listener, context);
  }

  public void publishChanges(FrameworkConstants.Subsystem subsystem, CmdbChanges changes)
  {
    getNotificationService().onChanges(changes, subsystem);
  }

  private CmdbNotificationService getNotificationService() {
    return this._notificationService;
  }

  private void setNotificationService(CmdbNotificationService notificationService) {
    this._notificationService = notificationService;
  }

  public String getName() {
    return "Deployment Task";
  }
}