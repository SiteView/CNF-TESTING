package com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import java.util.Properties;

public abstract interface JMSPublisher
{
  public abstract void startUp();

  public abstract void shutdown();

  public abstract void publishChanges(CmdbChanges paramCmdbChanges, Properties paramProperties, String paramString, Log paramLog);

  public abstract boolean flushQueuedMessages();
}