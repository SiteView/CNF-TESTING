package com.mercury.topaz.cmdb.server.notification.task.publish;

import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;

public abstract interface NotificationPublishManager extends SubsystemManager
{
  public abstract void publish(CmdbChanges paramCmdbChanges, CmdbChangeListenerFineGrained paramCmdbChangeListenerFineGrained);

  public abstract void publish(CmdbChanges paramCmdbChanges, CmdbChangeListenerCorseGrained paramCmdbChangeListenerCorseGrained);
}