package com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.client.notification.JMSEnvironment;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.notification.service.remote.AbstractJMSPublisher;
import com.mercury.topaz.cmdb.shared.notification.service.remote.AbstractJMSPublisher.AbstractPublishChanges;
import com.mercury.topaz.cmdb.shared.notification.service.remote.JMSChangesMessageImpl;
import java.util.Enumeration;
import java.util.Properties;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

public class JMSPublisherImpl extends AbstractJMSPublisher
  implements JMSPublisher
{
  private static final String NAME = "JMS_Publisher";

  public JMSPublisherImpl(JMSEnvironment jmsEnvironment)
  {
    super(jmsEnvironment, "JMS_Publisher");
  }

  public void publishChanges(CmdbChanges cmdbChanges, Properties properties, String logMessage, Log logger) {
    PublishChangesToAllSubscribers publishChangesToAllSubscribers = new PublishChangesToAllSubscribers(this, cmdbChanges, properties, logMessage, logger);
    executePublishCommand(publishChangesToAllSubscribers);
  }

  public boolean flushQueuedMessages() {
    return performMessagesQueueFlush(); }

  private class PublishChangesToAllSubscribers extends AbstractJMSPublisher.AbstractPublishChanges {
    private final CmdbChanges changes;
    private final Properties jmsProperties;
    private final String logMessage;
    private final Log logger;

    public PublishChangesToAllSubscribers(, CmdbChanges paramCmdbChanges, Properties paramProperties, String paramString, Log paramLog) {
      super(paramJMSPublisherImpl);
      this.changes = paramCmdbChanges;
      this.jmsProperties = paramProperties;
      this.logMessage = paramString;
      this.logger = paramLog;
    }

    protected Message getMessageToSend() throws JMSException {
      ObjectMessage jmsObjectMessage = JMSPublisherImpl.access$000(this.this$0).createObjectMessage(new JMSChangesMessageImpl(this.changes));
      Enumeration propEnum = this.jmsProperties.propertyNames();
      while (propEnum.hasMoreElements()) {
        String propName = (String)propEnum.nextElement();
        jmsObjectMessage.setStringProperty(propName, this.jmsProperties.getProperty(propName));
      }
      return jmsObjectMessage;
    }

    public String getLogMessage() {
      return this.logMessage;
    }

    public Log getLogger() {
      return this.logger;
    }
  }
}