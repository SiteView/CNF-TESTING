package com.mercury.topaz.cmdb.server.notification.task.publish.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractCommonSubsystemManager;
import com.mercury.topaz.cmdb.server.notification.task.publish.NotificationPublishManager;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.notification.service.util.ChangesPublisher;

class NotificationPublishManagerImpl extends AbstractCommonSubsystemManager
  implements NotificationPublishManager, SingleReadSingleWrite
{
  private String name;

  public NotificationPublishManagerImpl(LocalEnvironment LocalEnvironment, String nameOfTheManager)
  {
    super(LocalEnvironment);
    this.name = nameOfTheManager;
    Framework.getInstance().setLock(this);
  }

  public void publish(CmdbChanges changes, CmdbChangeListenerFineGrained fineGrainedListener) {
    ChangesPublisher.publish(fineGrainedListener, changes);
  }

  public void publish(CmdbChanges changes, CmdbChangeListenerCorseGrained corseGrainedListener) {
    ChangesPublisher.publish(corseGrainedListener, changes);
  }

  public void startUp()
  {
    Framework.getInstance().allocateThreadPool(this, 1);
    CmdbLogFactory.getCMDBInfoLog().info("manager of task: " + getName() + " is started up properly !!!");
  }

  public void shutdown() {
    CmdbLogFactory.getCMDBInfoLog().info("manager of task: " + getName() + " is shut down properly !!!");
  }

  public String getName() {
    return this.name;
  }
}