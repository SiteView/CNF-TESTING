package com.mercury.topaz.cmdb.server.notification.adapter.jms;

import com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher.JMSPublisher;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class JMSListenerAdapterFactory
{
  public static CmdbChangeListenerCorseGrained createCmdbAdminListenerAdapter(CmdbCustomerID customerID, JMSPublisher jmsPublisher)
  {
    return new CmdbAdminChangesJMSAdapter(customerID, jmsPublisher);
  }
}