package com.mercury.topaz.cmdb.server.notification.task.publish.operation.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.notification.task.publish.NotificationPublishManager;
import com.mercury.topaz.cmdb.server.notification.task.publish.operation.command.NotificationPublishCommand;
import com.mercury.topaz.cmdb.server.notification.task.publish.operation.impl.AbstractNotificationPublishOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListener;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

abstract class AbstractNotificationPublishCommand extends AbstractNotificationPublishOperation
  implements NotificationPublishCommand
{
  private CmdbChanges _changes;
  private CmdbChangeListener _listener;

  public AbstractNotificationPublishCommand(String taskName, CmdbChanges changes, CmdbChangeListener listener)
  {
    super(taskName);
    setChanges(changes);
    setListenerFineGrained(listener);
  }

  public void notificationPublishExecute(NotificationPublishManager notificationPublishManager, CmdbResponse response) throws CmdbException {
    notificationPublishCommandExecute(notificationPublishManager, response);
    if (getLog().isDebugEnabled())
      getLog().debug("publishing of " + getChanges().size() + " changes was finished successfully in publisher: " + getExecutionTaskQueueName() + " for listener: " + getListener());
  }

  protected abstract Log getLog();

  protected CmdbChanges getChanges()
  {
    return this._changes;
  }

  private void setChanges(CmdbChanges changes) {
    if (changes == null)
      throw new IllegalArgumentException("changes are null !!!");

    this._changes = changes; }

  protected CmdbChangeListener getListener() {
    return this._listener;
  }

  private void setListenerFineGrained(CmdbChangeListener listener) {
    if (listener == null)
      throw new IllegalArgumentException("listener is null !!!");

    this._listener = listener;
  }
}