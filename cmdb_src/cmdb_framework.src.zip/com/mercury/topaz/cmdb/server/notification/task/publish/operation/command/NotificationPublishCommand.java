package com.mercury.topaz.cmdb.server.notification.task.publish.operation.command;

import com.mercury.topaz.cmdb.server.notification.task.publish.NotificationPublishManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.command.CmdbCommand;

public abstract interface NotificationPublishCommand extends CmdbCommand
{
  public abstract void notificationPublishCommandExecute(NotificationPublishManager paramNotificationPublishManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}