package com.mercury.topaz.cmdb.server.notification.task.publish;

import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.notification.task.publish.impl.NotificationPublishManagerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class PublishTaskUtil
{
  private static final String PublishTaskNamePrefix = "notification_publish_task";
  private int _publishTaskNumber;

  public PublishTaskUtil(SettingsReader settingsReader)
  {
    setPublishTaskNumber(settingsReader.getInt("notification.number.of.publish.tasks", 6));
  }

  public int getPublishTaskNumber() {
    return this._publishTaskNumber;
  }

  public List<NotificationPublishManager> createNotificationPublisherManagers(LocalEnvironment localEnvironment) {
    List managers = new ArrayList(getPublishTaskNumber());
    for (int i = 0; i < getPublishTaskNumber(); ++i) {
      String taskName = "notification_publish_task" + i;
      NotificationPublishManager manager = NotificationPublishManagerFactory.create(localEnvironment, taskName);
      managers.add(manager);
    }
    return managers;
  }

  public Set<String> createPublishTaskNames() {
    Set taskNames = new TreeSet();
    for (int i = 0; i < getPublishTaskNumber(); ++i)
      taskNames.add("notification_publish_task" + i);

    return taskNames;
  }

  private void setPublishTaskNumber(int publishTaskNumber)
  {
    this._publishTaskNumber = publishTaskNumber;
  }
}