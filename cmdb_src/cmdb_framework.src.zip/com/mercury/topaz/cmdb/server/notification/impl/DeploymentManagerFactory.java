package com.mercury.topaz.cmdb.server.notification.impl;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.notification.DeploymentManager;
import java.util.Set;

public class DeploymentManagerFactory
{
  public static DeploymentManager createConcurrent(LocalEnvironment LocalEnvironment, Set publishTaskNames)
  {
    return new DeploymentManagerImpl(LocalEnvironment, publishTaskNames);
  }
}