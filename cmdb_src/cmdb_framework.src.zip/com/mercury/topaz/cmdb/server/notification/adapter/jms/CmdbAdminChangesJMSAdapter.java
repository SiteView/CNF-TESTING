package com.mercury.topaz.cmdb.server.notification.adapter.jms;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher.JMSPublisher;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.util.Properties;

public class CmdbAdminChangesJMSAdapter extends AbstractJMSPublisherAdapter
{
  private static Log _logger = LogFactory.getEasyLog(CmdbAdminChangesJMSAdapter.class);

  public CmdbAdminChangesJMSAdapter(CmdbCustomerID customerID, JMSPublisher jmsPublisher)
  {
    super(jmsPublisher, FrameworkConstants.Subsystem.CMDB_ADMIN, customerID);
  }

  protected CmdbChanges addSpecificJMSInfo(CmdbChanges cmdbChanges, Properties jmsProps, StringBuffer logMessage)
  {
    return cmdbChanges;
  }

  protected Log getLogger() {
    return _logger;
  }
}