package com.mercury.topaz.cmdb.server.notification.task.publish.operation.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.notification.task.publish.NotificationPublishManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class NotificationPublishCommandPublishCorseGrained extends AbstractNotificationPublishCommand
{
  private static final Log _logger = LogFactory.getEasyLog(NotificationPublishCommandPublishCorseGrained.class);

  public NotificationPublishCommandPublishCorseGrained(String taskName, CmdbChangeListenerCorseGrained corseGrainedListener, CmdbChanges changes)
  {
    super(taskName, changes, corseGrainedListener);
  }

  public String getOperationName()
  {
    return "Notification Publish Command : publish corse grained listener";
  }

  public void notificationPublishCommandExecute(NotificationPublishManager notificationPublishManager, CmdbResponse response) throws CmdbException {
    notificationPublishManager.publish(getChanges(), (CmdbChangeListenerCorseGrained)getListener());
  }

  protected Log getLog() {
    return _logger;
  }
}