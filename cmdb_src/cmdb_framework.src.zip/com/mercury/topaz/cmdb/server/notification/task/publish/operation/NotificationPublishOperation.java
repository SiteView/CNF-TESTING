package com.mercury.topaz.cmdb.server.notification.task.publish.operation;

import com.mercury.topaz.cmdb.server.notification.task.publish.NotificationPublishManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface NotificationPublishOperation extends FrameworkOperation
{
  public abstract void notificationPublishExecute(NotificationPublishManager paramNotificationPublishManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}