package com.mercury.topaz.cmdb.server.notification;

import com.mercury.topaz.cmdb.client.manage.api.CmdbNotification;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;

public abstract interface DeploymentManager
{
  public abstract void publishChanges(FrameworkConstants.Subsystem paramSubsystem, CmdbChanges paramCmdbChanges);
}