package com.mercury.topaz.cmdb.server.notification.service.local;

import com.mercury.topaz.cmdb.shared.notification.service.ChangesDispatcher;
import com.mercury.topaz.cmdb.shared.notification.service.ListenersManager;
import com.mercury.topaz.cmdb.shared.notification.service.impl.ChangesDispatcherFactory;
import com.mercury.topaz.cmdb.shared.notification.service.listener.ListenersContainer;
import com.mercury.topaz.cmdb.shared.notification.service.listener.impl.ListenersContainerFactory;
import java.util.Set;

public class LocalListenersManagerFactory
{
  public static ListenersManager createConcurrent(Set publishTaskNames)
  {
    ListenersContainer listenersContainer = ListenersContainerFactory.createListenerContainer();
    ChangesDispatcher changesDispatcher = ChangesDispatcherFactory.createConcurrentDispatcher();
    return new ConcurrentLocalListenersManagerImpl(listenersContainer, changesDispatcher, publishTaskNames);
  }
}