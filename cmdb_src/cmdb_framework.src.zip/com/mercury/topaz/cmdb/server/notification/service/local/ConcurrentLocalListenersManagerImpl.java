package com.mercury.topaz.cmdb.server.notification.service.local;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.notification.filter.CmdbNotificationFilter;
import com.mercury.topaz.cmdb.shared.notification.service.ChangesDispatcher;
import com.mercury.topaz.cmdb.shared.notification.service.listener.ListenerData;
import com.mercury.topaz.cmdb.shared.notification.service.listener.ListenerDataCorseGrained;
import com.mercury.topaz.cmdb.shared.notification.service.listener.ListenerDataFineGrained;
import com.mercury.topaz.cmdb.shared.notification.service.listener.ListenersContainer;
import com.mercury.topaz.cmdb.shared.notification.service.listener.impl.ListenersContainerFactory;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

class ConcurrentLocalListenersManagerImpl extends LocalListenersManagerImpl
{
  private static final Log _logger = LogFactory.getEasyLog(ConcurrentLocalListenersManagerImpl.class);
  private Map _publishers = new HashMap();
  private Set _publishersData = new TreeSet();

  public ConcurrentLocalListenersManagerImpl(ListenersContainer listenersContainer, ChangesDispatcher changesDispatcher, Set publishTaskNames)
  {
    super(listenersContainer, changesDispatcher);
    createPublishersData(publishTaskNames);
  }

  protected ListenerDataCorseGrained createListenerDataCorseGrained(CmdbNotificationFilter filter, CmdbChangeListenerCorseGrained listener) {
    return ListenersContainerFactory.createListenerData(filter, listener, assignListenerToPublisher());
  }

  protected ListenerDataFineGrained createListenerDataFineGrained(CmdbNotificationFilter filter, CmdbChangeListenerFineGrained listener)
  {
    return ListenersContainerFactory.createListenerData(filter, listener, assignListenerToPublisher());
  }

  protected void unregister(ListenerData listenerData)
  {
    super.unregister(listenerData);
    if (listenerData == null) {
      return;
    }

    String publisherName = listenerData.getPublisherName();
    PublisherData publisherData = (PublisherData)this._publishers.get(publisherName);
    this._publishersData.remove(publisherData);
    publisherData.removeListener();
    this._publishersData.add(publisherData);
  }

  private void createPublishersData(Set publishTaskNames) {
    for (Iterator itr = publishTaskNames.iterator(); itr.hasNext(); ) {
      String publishTaskName = (String)itr.next();
      PublisherData publisherData = new PublisherData(publishTaskName);
      this._publishers.put(publishTaskName, publisherData);
      this._publishersData.add(publisherData);
    }
  }

  private String assignListenerToPublisher()
  {
    Iterator itr = this._publishersData.iterator();
    PublisherData publisherData = (PublisherData)itr.next();
    itr.remove();
    publisherData.addListener();
    this._publishersData.add(publisherData);
    if ((_logger.isDebugEnabled()) && 
      (PublisherData.access$000(publisherData) > 1)) {
      _logger.debug("publisher task: " + publisherData.getPublisherName() + " is going to publish to " + PublisherData.access$000(publisherData) + " listeners (more than one listener)!!! It's dangerous, please increase parameter " + "notification.number.of.publish.tasks" + " in configuration");
    }

    return publisherData.getPublisherName();
  }

  private static class PublisherData
  implements Comparable {
    private String _publisherName;
    private int _numberOfListeners = 0;

    public PublisherData(String publisherName) {
      setPublisherName(publisherName);
    }

    public void addListener() {
      this._numberOfListeners += 1;
    }

    public void removeListener()
    {
      this._numberOfListeners -= 1;
    }

    public String getPublisherName() {
      return this._publisherName;
    }

    public int compareTo(Object o) {
      PublisherData publisherData = (PublisherData)o;
      int result = getNumberOfListeners() - publisherData.getNumberOfListeners();
      if (result == 0)
      {
        return getPublisherName().compareTo(publisherData.getPublisherName());
      }
      return result;
    }

    public int hashCode()
    {
      return (this._publisherName.hashCode() * 29 + this._numberOfListeners * 19);
    }

    public boolean equals(Object obj) {
      if (obj == null) return false;
      if (obj == this) return true;
      if (!(obj instanceof PublisherData)) return false;
      PublisherData publisherData = (PublisherData)obj;
      return ((getPublisherName().equals(publisherData.getPublisherName())) && (getNumberOfListeners() == publisherData.getNumberOfListeners()));
    }

    private int getNumberOfListeners()
    {
      return this._numberOfListeners;
    }

    private void setPublisherName(String publisherName) {
      if ((publisherName == null) || (publisherName.length() == 0))
        throw new IllegalArgumentException("publisher name is null or empty !!!");

      this._publisherName = publisherName;
    }
  }
}