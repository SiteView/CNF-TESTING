package com.mercury.topaz.cmdb.server.notification.task.publish.impl;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.notification.task.publish.NotificationPublishManager;

public class NotificationPublishManagerFactory
{
  public static NotificationPublishManager create(LocalEnvironment LocalEnvironment, String managerName)
  {
    return new NotificationPublishManagerImpl(LocalEnvironment, managerName);
  }
}