package com.mercury.topaz.cmdb.server.notification.adapter.jms;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.publisher.JMSPublisher;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChange;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.change.impl.AbstractCmdbChangeListener;
import com.mercury.topaz.cmdb.shared.change.impl.CmdbChangeFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.util.iterator.CmdbFilter;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Properties;

public abstract class AbstractJMSPublisherAdapter extends AbstractCmdbChangeListener
  implements CmdbChangeListenerCorseGrained
{
  private JMSPublisher _jmsPublisher;
  private CmdbFilter filter;

  protected AbstractJMSPublisherAdapter(JMSPublisher jmsPublisher, FrameworkConstants.Subsystem subsystem, CmdbCustomerID customerID)
  {
    this(jmsPublisher, null, subsystem, customerID);
  }

  protected AbstractJMSPublisherAdapter(JMSPublisher jmsPublisher, CmdbFilter filter, FrameworkConstants.Subsystem subsystem, CmdbCustomerID customerID)
  {
    super(subsystem, customerID);
    setJmsPublisher(jmsPublisher);
    setFilter(filter);
  }

  private void setFilter(CmdbFilter filter) {
    this.filter = filter;
  }

  public void onChanges(CmdbChanges cmdbChanges)
  {
    if (cmdbChanges == null)
      return;

    cmdbChanges = filterChanges(cmdbChanges);
    if (cmdbChanges.size() == 0)
      return;

    StringBuffer logMessage = new StringBuffer();
    logMessage.append(cmdbChanges.size()).append(" changes from subsystem ").append(getSubsystem());
    logMessage.append(" ");
    Properties jmsProps = new Properties();
    addGeneralJmsProps(jmsProps);
    cmdbChanges = addSpecificJMSInfo(cmdbChanges, jmsProps, logMessage);
    getJmsPublisher().publishChanges(cmdbChanges, jmsProps, logMessage.toString(), getLogger());
  }

  private void addGeneralJmsProps(Properties jmsProps) {
    jmsProps.put("CUSTOMER_ID", Integer.toString(getCustomerID().getID()));

    jmsProps.put("SUBSYSTEM_NAME", getSubsystem().toString());
  }

  protected CmdbChanges filterChanges(CmdbChanges cmdbChanges)
  {
    if (cmdbChanges.size() == 0)
      return cmdbChanges;

    if (getFilter() == null) {
      return cmdbChanges;
    }

    CmdbChanges changes = CmdbChangeFactory.createCmdbChanges(cmdbChanges.getChanger());
    ReadOnlyIterator itr = cmdbChanges.getChangesIterator();
    while (itr.hasNext()) {
      CmdbChange change = (CmdbChange)itr.next();
      if (getFilter().filter(change))
        changes.add(change);
    }

    return changes;
  }

  private CmdbFilter getFilter()
  {
    return this.filter;
  }

  protected abstract CmdbChanges addSpecificJMSInfo(CmdbChanges paramCmdbChanges, Properties paramProperties, StringBuffer paramStringBuffer);

  protected abstract Log getLogger();

  private JMSPublisher getJmsPublisher()
  {
    return this._jmsPublisher;
  }

  private void setJmsPublisher(JMSPublisher jmsPublisher) {
    this._jmsPublisher = jmsPublisher;
  }
}