package com.mercury.topaz.cmdb.server.notification.service.local;

import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.change.id.ChangeListenerID;
import com.mercury.topaz.cmdb.shared.notification.service.CmdbNotificationService;
import com.mercury.topaz.cmdb.shared.notification.service.ListenersManager;
import com.mercury.topaz.cmdb.shared.notification.service.impl.AbstractNotificationService;

public class CmdbLocalNotificationServiceImpl extends AbstractNotificationService
  implements CmdbNotificationService
{
  public CmdbLocalNotificationServiceImpl(ListenersManager listenersManager)
  {
    super(listenersManager);
  }

  public void onChanges(CmdbChanges changes, FrameworkConstants.Subsystem subsystem) {
    getListenersManager().onChanges(changes, subsystem);
  }

  public void onChanges(CmdbChanges changes, ChangeListenerID listenerID) {
    getListenersManager().onChanges(changes, listenerID);
  }
}