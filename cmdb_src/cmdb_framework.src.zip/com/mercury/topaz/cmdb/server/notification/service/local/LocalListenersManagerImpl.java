package com.mercury.topaz.cmdb.server.notification.service.local;

import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.notification.service.ChangesDispatcher;
import com.mercury.topaz.cmdb.shared.notification.service.impl.AbstractListenersManager;
import com.mercury.topaz.cmdb.shared.notification.service.listener.ListenersContainer;

public class LocalListenersManagerImpl extends AbstractListenersManager
{
  public LocalListenersManagerImpl(ListenersContainer listenersContainer, ChangesDispatcher changesDispatcher)
  {
    super(listenersContainer, changesDispatcher);
  }

  protected CmdbContext getContext(CmdbCustomerID customerID) {
    return null;
  }
}