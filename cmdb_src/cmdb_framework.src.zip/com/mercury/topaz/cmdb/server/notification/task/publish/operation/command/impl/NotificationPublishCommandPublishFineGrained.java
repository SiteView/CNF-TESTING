package com.mercury.topaz.cmdb.server.notification.task.publish.operation.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.notification.task.publish.NotificationPublishManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class NotificationPublishCommandPublishFineGrained extends AbstractNotificationPublishCommand
{
  private static final Log _logger = LogFactory.getEasyLog(NotificationPublishCommandPublishFineGrained.class);

  public NotificationPublishCommandPublishFineGrained(String taskName, CmdbChangeListenerFineGrained fineGrainedListener, CmdbChanges changes)
  {
    super(taskName, changes, fineGrainedListener);
  }

  public String getOperationName()
  {
    return "Notification Publish Command : publish fine grained listener";
  }

  public void notificationPublishCommandExecute(NotificationPublishManager notificationPublishManager, CmdbResponse response) throws CmdbException {
    notificationPublishManager.publish(getChanges(), (CmdbChangeListenerFineGrained)getListener());
  }

  protected Log getLog() {
    return _logger;
  }
}