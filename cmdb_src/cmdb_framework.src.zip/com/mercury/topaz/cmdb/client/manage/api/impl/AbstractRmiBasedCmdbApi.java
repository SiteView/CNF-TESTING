package com.mercury.topaz.cmdb.client.manage.api.impl;

import appilog.framework.shared.manage.MamResponse;
import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApiEnvironment;
import com.mercury.topaz.cmdb.client.manage.api.util.CmdbApiUtil;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbFacade;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Hashtable;
import javax.naming.InitialContext;

public abstract class AbstractRmiBasedCmdbApi extends AbstractCmdbApi
{
  static Log _logger = LogFactory.getEasyLog(CmdbApi.class);
  protected final CmdbApiEnvironment _environment;

  public AbstractRmiBasedCmdbApi(CmdbApiEnvironment environment)
  {
    this._environment = environment;
  }

  protected abstract CmdbFacade getCmdbFacade(FrameworkOperation paramFrameworkOperation)
    throws CmdbException;

  private String getLocalHost()
  {
    try
    {
      return "[" + InetAddress.getLocalHost().getHostName() + "]"; } catch (UnknownHostException e) {
    }
    return "";
  }

  public MamResponse handleRequest(CmdbRequest request)
    throws CmdbResponseException
  {
    if (request == null) {
      String err = "Couldn't handle null request";
      _logger.error(err);
      throw new MamResponseException(err, null);
    }
    try
    {
      CmdbFacade cmdbFacade = getCmdbFacade(request.getOperation());
      return cmdbFacade.handleRequest(request);
    } catch (Exception e) {
      String message = "Couldn't handle request [id=" + request.getID() + "] on host " + this._environment.getHostName() + getPossibleCauses() + "\n due to " + e;

      _logger.error(message, e);
      throw new MamResponseException(message, e, request.getID());
    }
  }

  protected String getPossibleCauses() {
    return "\n Possible causes: \n 1) Cmdb server is down.\n 2) Cmdb server doesn't run on the specified host\n 3) This machine and CMDB server machine don't have the same cmdb jars version \n 4) There is no connection between this machine " + getLocalHost() + " and the specified host";
  }

  protected CmdbFacade resolveFacadeByService(String serviceName)
    throws CmdbException
  {
    String jndiName = CmdbApiUtil.getJndiNameOfService(serviceName);
    try {
      InitialContext initialContext = new InitialContext((Hashtable)this._environment);
      return ((CmdbFacade)initialContext.lookup(jndiName));
    } catch (Throwable t) {
      String message = "\n Couldn't obtain reference to CMDB facade (" + jndiName + " on host " + this._environment.getHostName() + getPossibleCauses() + "\n due to exception: " + t;

      _logger.error(message, t);
      throw new CmdbException(message, t);
    }
  }
}