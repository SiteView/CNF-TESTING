package com.mercury.topaz.cmdb.client.manage.api.impl;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApiEnvironment;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbFacade;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public class CmdbApiRmiImpl extends AbstractRmiBasedCmdbApi
{
  public CmdbApiRmiImpl(CmdbApiEnvironment environment)
    throws CmdbException
  {
    super(environment);
  }

  protected CmdbFacade getCmdbFacade(FrameworkOperation operation) throws CmdbException {
    return resolveFacadeByService(operation.getServiceName());
  }
}