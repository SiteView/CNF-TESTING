package com.mercury.topaz.cmdb.client.manage.api.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.CmdbNotification;
import com.mercury.topaz.cmdb.server.notification.adapter.jms.AbstractJMSPublisherAdapter;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListener;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.change.id.ChangeListenerID;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.Environment;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.notification.filter.CmdbNotificationFilter;
import com.mercury.topaz.cmdb.shared.notification.filter.CmdbNotificationJMSFilter;
import com.mercury.topaz.cmdb.shared.notification.filter.JMSWrappersForNotificationFilters;
import com.mercury.topaz.cmdb.shared.notification.operation.command.impl.DeploymentCommandRegisterCorseGrainedListener;
import com.mercury.topaz.cmdb.shared.notification.operation.command.impl.DeploymentCommandRegisterFineGrainedListener;
import com.mercury.topaz.cmdb.shared.notification.operation.command.impl.DeploymentCommandUnregisterListener;
import com.mercury.topaz.cmdb.shared.notification.service.local.LocalNotificationFactory;
import com.mercury.topaz.cmdb.shared.notification.service.remote.RemoteNotificationServiceFactory;
import com.mercury.topaz.cmdb.shared.util.FrameworkUtils;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Vector;

public class CmdbNotificationServiceFactory
{
  private static String LOCAL = "local";
  private static String PROPERTY = "cmdb.notification.factory";

  public static CmdbNotification createNotification()
  {
    String type = System.getProperty(PROPERTY);
    if ((Environment.DISABLE_JMS) || (LOCAL.equalsIgnoreCase(type))) {
      return LocalNotificationFactory.createNotification();
    }

    return new NotificationServiceToggler(null); } 
  private static class NotificationServiceToggler
  implements CmdbNotification { private CmdbNotification remoteNotification;
    private List<FrameworkConstants.Subsystem> registeredJMSTopics;
    private static final Log log = LogFactory.getEasyLog(NotificationServiceToggler.class);

    private NotificationServiceToggler() { this.registeredJMSTopics = new Vector(16);
    }

    public void startUp()
    {
      this.remoteNotification = RemoteNotificationServiceFactory.createJMSNotification();
      this.remoteNotification.startUp();
    }

    public void shutdown() {
      this.remoteNotification.shutdown();
    }

    private CmdbApi getExecutionApi() {
      return CmdbApiFactory.createCMDBAPI();
    }

    private FrameworkOperation createRegisterCommand(CmdbNotificationFilter filter, CmdbChangeListener listener)
    {
      FrameworkOperation command;
      if (listener instanceof CmdbChangeListenerFineGrained) {
        if (filter != null)
          command = new DeploymentCommandRegisterFineGrainedListener((CmdbChangeListenerFineGrained)listener, filter);
        else
          command = new DeploymentCommandRegisterFineGrainedListener((CmdbChangeListenerFineGrained)listener);

      }
      else if (filter != null)
        command = new DeploymentCommandRegisterCorseGrainedListener((CmdbChangeListenerCorseGrained)listener, filter);
      else {
        command = new DeploymentCommandRegisterCorseGrainedListener((CmdbChangeListenerCorseGrained)listener);
      }

      return command;
    }

    private DeploymentCommandUnregisterListener createUnregisterCommand(CmdbChangeListener listener) {
      return createUnregisterCommand(listener.getID());
    }

    private DeploymentCommandUnregisterListener createUnregisterCommand(ChangeListenerID listenerID) {
      return new DeploymentCommandUnregisterListener(listenerID);
    }

    public void register(CmdbNotificationFilter filter, CmdbChangeListenerFineGrained listener, CmdbContext context) {
      if (isLocalSubscription(listener.getSubsystem())) {
        getExecutionApi().executeOperation(createRegisterCommand(filter, listener), context);
        log.info("Local listener (" + listener + ") for subsystem (" + listener.getSubsystem() + ") registered successfully");
      } else {
        if (filter != null) {
          CmdbNotificationFilter filterWrap = wrap(filter);
          this.remoteNotification.register(filterWrap, listener, context);
        } else {
          this.remoteNotification.register(listener, context);
        }

        log.info("Remote listener (" + listener + ") for subsystem (" + listener.getSubsystem() + ") registered successfully");
      }
    }

    public void register(CmdbNotificationFilter filter, CmdbChangeListenerCorseGrained listener, CmdbContext context)
    {
      if (listener instanceof AbstractJMSPublisherAdapter) {
        registerJMSPublisherAdapter(filter, listener, context);
        return;
      }

      if (isLocalSubscription(listener.getSubsystem())) {
        getExecutionApi().executeOperation(createRegisterCommand(filter, listener), context);
        log.info("Local listener (" + listener + ") for subsystem (" + listener.getSubsystem() + ") registered successfully");
      } else {
        if (filter != null) {
          CmdbNotificationFilter filterWrap = wrap(filter);
          this.remoteNotification.register(filterWrap, listener, context);
        } else {
          this.remoteNotification.register(listener, context);
        }

        log.info("Remote listener (" + listener + ") for subsystem (" + listener.getSubsystem() + ") registered successfully");
      }
    }

    public void register(CmdbChangeListenerCorseGrained listener, CmdbContext context)
    {
      register(null, listener, context);
    }

    public void unregister(ChangeListenerID listenerID, CmdbContext context)
    {
      this.remoteNotification.unregister(listenerID, context);
      try {
        getExecutionApi().executeOperation(createUnregisterCommand(listenerID), context);
      } catch (Throwable t) {
        log.warn("Failed to unregister listener of ID [" + listenerID + "] for context [" + context + "]; can be ignored for this method", t);
      }
      log.info("Remote listener of ID (" + listenerID + ") unregistered successfully");
    }

    public void unregister(CmdbChangeListener listener, CmdbContext context) {
      if (listener instanceof AbstractJMSPublisherAdapter) {
        unregisterJMSPublisherAdapter(listener, context);
        return;
      }

      if (isLocalSubscription(listener.getSubsystem())) {
        getExecutionApi().executeOperation(createUnregisterCommand(listener), context);
        log.info("Local listener (" + listener + ") for subsystem (" + listener.getSubsystem() + ") unregistered successfully");
      } else {
        this.remoteNotification.unregister(listener.getID(), context);
        log.info("Remote listener (" + listener + ") for subsystem (" + listener.getSubsystem() + ") unregistered successfully");
      }
    }

    public void register(CmdbChangeListenerFineGrained listener, CmdbContext context)
    {
      register(null, listener, context);
    }

    private void registerJMSPublisherAdapter(CmdbNotificationFilter filter, CmdbChangeListenerCorseGrained listener, CmdbContext context) {
      if (!(FrameworkUtils.isJMSListenerAdaptersShouldBeRegistered())) {
        return;
      }

      getExecutionApi().executeOperation(createRegisterCommand(filter, listener), context);

      this.registeredJMSTopics.add(listener.getSubsystem());

      log.info("Listening JMS adapter for local publisher (" + listener + ") for subsystem (" + listener.getSubsystem() + ") registered successfully");
    }

    private void unregisterJMSPublisherAdapter(CmdbChangeListener listener, CmdbContext context)
    {
      if (!(FrameworkUtils.isJMSListenerAdaptersShouldBeRegistered())) {
        return;
      }

      getExecutionApi().executeOperation(createUnregisterCommand(listener), context);

      this.registeredJMSTopics.remove(listener.getSubsystem());

      log.info("Listening JMS adapter for local publisher (" + listener + ") for subsystem (" + listener.getSubsystem() + ") unregistered successfully");
    }

    private CmdbNotificationFilter wrap(CmdbNotificationFilter filter)
    {
      if (filter instanceof CmdbNotificationJMSFilter) {
        return filter;
      }

      String filterClassName = filter.getClass().getName();
      String wrapperClassName = getJMSWrapper(filterClassName);
      if (wrapperClassName == null)
        throw new CmdbException("Can not wrap notification filter (" + filterClassName + ") in null JMS wrapper");

      try
      {
        Class wrapperClass = Class.forName(wrapperClassName);
        String delegatorClassName = getDelegatorForJMSWrapper(filterClassName);
        Constructor constructor = wrapperClass.getConstructor(new Class[] { Class.forName(delegatorClassName) });
        Object obj = constructor.newInstance(new Object[] { filter });
        return ((CmdbNotificationFilter)obj);
      } catch (ClassNotFoundException e) {
        throw new CmdbException("Cannot load class for class name: " + wrapperClassName, e);
      } catch (NoSuchMethodException e) {
        throw new CmdbException("Cannot load constructor for class name: " + wrapperClassName, e);
      } catch (IllegalAccessException e) {
        throw new CmdbException("Failed to create instance of class: " + wrapperClassName, e);
      } catch (InvocationTargetException e) {
        throw new CmdbException("Failed to create instance of class: " + wrapperClassName, e);
      } catch (InstantiationException e) {
        throw new CmdbException("Failed to create instance of class: " + wrapperClassName, e);
      }
    }

    private boolean isLocalSubscription(FrameworkConstants.Subsystem topic)
    {
      return this.registeredJMSTopics.contains(topic);
    }

    private String getJMSWrapper(String notificationFilter) {
      return JMSWrappersForNotificationFilters.instance().getJMSWrapper(notificationFilter);
    }

    private String getDelegatorForJMSWrapper(String notificationFilter) {
      return JMSWrappersForNotificationFilters.instance().getDelegatorForJMSWrapper(notificationFilter);
    }
  }
}