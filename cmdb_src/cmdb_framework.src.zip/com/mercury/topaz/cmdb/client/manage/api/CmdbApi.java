package com.mercury.topaz.cmdb.client.manage.api;

import appilog.framework.shared.manage.MamResponse;
import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface CmdbApi
{
  public static final TYPE RMI_TYPE = new TYPE("RMI CMDB API");
  public static final TYPE LOCAL_TYPE = new TYPE("LOCAL CMDB API");
  public static final TYPE HTTP_TYPE = new TYPE("BINARY HTTP MAM API");

  public abstract MamResponse executeCMDBOperation(FrameworkOperation paramFrameworkOperation, CmdbContext paramCmdbContext)
    throws CmdbResponseException;

  public abstract MamResponse executeCMDBOperation(FrameworkOperation paramFrameworkOperation, CmdbContext paramCmdbContext, boolean paramBoolean)
    throws CmdbResponseException;

  public abstract MamResponse executeOperation(FrameworkOperation paramFrameworkOperation, CmdbContext paramCmdbContext)
    throws MamResponseException;

  public abstract MamResponse executeOperation(FrameworkOperation paramFrameworkOperation, CmdbContext paramCmdbContext, boolean paramBoolean)
    throws MamResponseException;

  public static class TYPE
  {
    private String _description;

    protected TYPE(String description)
    {
      this._description = description;
    }

    public String toString() {
      return this._description;
    }
  }
}