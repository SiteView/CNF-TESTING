package com.mercury.topaz.cmdb.client.manage.api.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApiEnvironment;
import com.mercury.topaz.cmdb.client.manage.api.util.CmdbApiUtil;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbFacade;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public class CmdbApiServerRmiImpl extends AbstractRmiBasedCmdbApi
{
  private String serverName;
  private String processName;

  public CmdbApiServerRmiImpl(CmdbApiEnvironment environment, String serverName, String processName)
  {
    super(environment);
    this.serverName = serverName;
    this.processName = processName;
  }

  protected CmdbFacade getCmdbFacade(FrameworkOperation operation) throws CmdbException {
    try {
      return resolveFacadeByService(CmdbApiUtil.getJndiNameOfServer(this.processName));
    } catch (Throwable t) {
      String message = "\n Couldn't obtain reference to CMDB facade for process: " + this.processName + ", on host: " + this.serverName + getPossibleCauses() + "\n due to exception: " + t;

      _logger.error(message, t);
      throw new CmdbException(message, t);
    }
  }
}