package com.mercury.topaz.cmdb.client.manage.api.impl;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApiEnvironment;
import java.util.Hashtable;

public class RmiEnvironment extends Hashtable<Object, Object>
  implements CmdbApiEnvironment
{
  private static final int INVALID_PORT = -1;
  private String hostName;
  private int port;

  public RmiEnvironment()
  {
    this("localhost");
  }

  public RmiEnvironment(String hostName) {
    this(hostName, -1);
  }

  public RmiEnvironment(String hostName, int port)
  {
    this.port = -1;

    setHostName(hostName);
    setPort(port);

    put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");
    put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
    put("java.naming.provider.url", getHostName());
  }

  public String getHostName() {
    String url = this.hostName;
    if (this.port != -1)
      url = url + ":" + this.port;

    return url;
  }

  private void setPort(int port) {
    this.port = port;
  }

  private void setHostName(String hostName) {
    if ((hostName == null) || (hostName.equals("")))
      throw new IllegalArgumentException("Attempt to create RmiEnvironment with [" + hostName + "] host name");

    this.hostName = hostName;
  }
}