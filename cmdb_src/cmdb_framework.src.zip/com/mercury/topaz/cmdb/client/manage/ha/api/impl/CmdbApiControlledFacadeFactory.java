package com.mercury.topaz.cmdb.client.manage.ha.api.impl;

import com.mercury.topaz.cmdb.client.manage.api.BinaryCmdbApi;

public class CmdbApiControlledFacadeFactory
{
  public static BinaryCmdbApi create()
  {
    return CmdbApiControlledFacadeImpl.getInstance();
  }
}