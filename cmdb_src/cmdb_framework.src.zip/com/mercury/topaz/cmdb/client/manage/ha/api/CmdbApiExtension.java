package com.mercury.topaz.cmdb.client.manage.ha.api;

import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.am.platform.controller.LocatorJMXFacade;
import com.mercury.am.platform.controller.Service;
import com.mercury.am.platform.controller.ServiceDescriptor;
import com.mercury.am.platform.controller.ServiceLocator;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;

public class CmdbApiExtension
{
  public static boolean isCustomerLoaded(CmdbContext context)
  {
    Service cmdbService = Service.getService("CMDB");
    ServiceDescriptor descriptor = ServiceDescriptor.getDescriptor(cmdbService, context.getCustomerID().getID());
    ServiceLocator locator = LocatorJMXFacade.getFacade();
    return (locator.getActiveLocationOf(descriptor) != null);
  }
}