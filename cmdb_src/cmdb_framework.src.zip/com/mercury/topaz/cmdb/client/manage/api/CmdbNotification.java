package com.mercury.topaz.cmdb.client.manage.api;

import com.mercury.topaz.cmdb.shared.change.CmdbChangeListener;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.change.id.ChangeListenerID;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.notification.filter.CmdbNotificationFilter;

public abstract interface CmdbNotification
{
  public abstract void startUp();

  public abstract void shutdown();

  public abstract void register(CmdbNotificationFilter paramCmdbNotificationFilter, CmdbChangeListenerFineGrained paramCmdbChangeListenerFineGrained, CmdbContext paramCmdbContext);

  public abstract void register(CmdbChangeListenerFineGrained paramCmdbChangeListenerFineGrained, CmdbContext paramCmdbContext);

  public abstract void register(CmdbNotificationFilter paramCmdbNotificationFilter, CmdbChangeListenerCorseGrained paramCmdbChangeListenerCorseGrained, CmdbContext paramCmdbContext);

  public abstract void register(CmdbChangeListenerCorseGrained paramCmdbChangeListenerCorseGrained, CmdbContext paramCmdbContext);

  public abstract void unregister(ChangeListenerID paramChangeListenerID, CmdbContext paramCmdbContext);

  public abstract void unregister(CmdbChangeListener paramCmdbChangeListener, CmdbContext paramCmdbContext);
}