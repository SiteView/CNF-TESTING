package com.mercury.topaz.cmdb.client.manage.api.impl;

import appilog.framework.client.manage.api.MamApi;
import appilog.framework.shared.manage.MamResponse;
import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbReqestImpl;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract class AbstractCmdbApi
  implements MamApi
{
  protected abstract MamResponse handleRequest(CmdbRequest paramCmdbRequest);

  public MamResponse executeCMDBOperation(FrameworkOperation operation, CmdbContext context, boolean isSynchronic)
    throws CmdbResponseException
  {
    CmdbReqestImpl request = new CmdbReqestImpl("General CMDB request", context, operation, isSynchronic);
    MamResponse response = handleRequest(request);
    if (isSynchronic)
      operation.updateWithResponse(response);

    return response;
  }

  public MamResponse executeCMDBOperation(FrameworkOperation operation, CmdbContext context)
    throws CmdbResponseException
  {
    return executeCMDBOperation(operation, context, true);
  }

  public final MamResponse executeOperation(FrameworkOperation operation, CmdbContext context) throws MamResponseException {
    return executeCMDBOperation(operation, context);
  }

  public final MamResponse executeOperation(FrameworkOperation operation, CmdbContext context, boolean isSynchronic) throws MamResponseException {
    return executeCMDBOperation(operation, context, isSynchronic);
  }
}