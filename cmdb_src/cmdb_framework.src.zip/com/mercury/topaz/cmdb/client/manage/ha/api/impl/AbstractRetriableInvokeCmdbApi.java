package com.mercury.topaz.cmdb.client.manage.ha.api.impl;

import com.mercury.am.platform.controller.ServiceNotAvailableException;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.CmdbServiceAccess;
import com.mercury.topaz.cmdb.shared.util.retry.impl.AbstractRetriable;

abstract class AbstractRetriableInvokeCmdbApi<RESULT> extends AbstractRetriable<RESULT>
{
  private static final Class[] EXCEPTIONS = { ServiceNotAvailableException.class };
  private CmdbServiceAccess _cmdbApi;

  public AbstractRetriableInvokeCmdbApi(CmdbServiceAccess cmdbApi)
  {
    setCmdbApi(cmdbApi);
  }

  public Class[] getListOfExceptions() {
    return EXCEPTIONS;
  }

  protected CmdbServiceAccess getCmdbApi() {
    return this._cmdbApi;
  }

  private void setCmdbApi(CmdbServiceAccess cmdbApi) {
    this._cmdbApi = cmdbApi;
  }
}