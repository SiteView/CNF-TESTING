package com.mercury.topaz.cmdb.client.manage.api;

import appilog.framework.client.manage.api.MamApi;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;

public abstract interface BinaryCmdbApi extends MamApi
{
  public abstract byte[] executeBinaryRequest(CmdbContext paramCmdbContext, String paramString, byte[] paramArrayOfByte);
}