package com.mercury.topaz.cmdb.client.manage.api.util;

public class CmdbApiUtil
{
  private static final String PROCESS_JNDI_NAME_POSTFIX = "Process:";

  public static String getJndiNameOfService(String serviceName)
  {
    return "UCMDB:" + serviceName;
  }

  public static String getJndiNameOfServer(String serverName) {
    return "Process:" + serverName;
  }
}