package com.mercury.topaz.cmdb.client.manage.ha.api.impl;

import appilog.framework.shared.manage.MamResponse;
import appilog.framework.shared.manage.customer.id.MamCustomerID;
import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.am.platform.controller.LocatorJMXFacade;
import com.mercury.am.platform.controller.Service;
import com.mercury.am.platform.controller.ServiceDescriptor;
import com.mercury.am.platform.controller.ServiceLocator;
import com.mercury.am.platform.controller.ServiceNotAvailableException;
import com.mercury.am.platform.controller.spi.FactoryRegistryJMXFacade;
import com.mercury.am.platform.controller.spi.ServerCommunicationException;
import com.mercury.am.platform.controller.spi.ServiceAccessFactory;
import com.mercury.topaz.cmdb.client.manage.api.BinaryCmdbApi;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.CmdbServiceAccess;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.impl.CmdServiceAccessFactoryImpl;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbServiceNotAvailableException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.util.retry.Retriable;
import com.mercury.topaz.cmdb.shared.util.retry.RetriableExecutor;
import com.mercury.topaz.cmdb.shared.util.retry.exception.RetryFailException;
import com.mercury.topaz.cmdb.shared.util.retry.exception.RetryFailUnexpectedCheckedException;
import com.mercury.topaz.cmdb.shared.util.retry.impl.RetriableExecutorFactory;
import java.util.HashSet;
import java.util.Set;

class CmdbApiControlledFacadeImpl
  implements BinaryCmdbApi
{
  private static final CmdbApiControlledFacadeImpl instance = new CmdbApiControlledFacadeImpl();
  private final Set<String> _registeredServices = new HashSet();
  private RetriableExecutor _retriableExecutor;

  public static CmdbApiControlledFacadeImpl getInstance()
  {
    return instance;
  }

  private CmdbApiControlledFacadeImpl()
  {
    int retriesNum = 0;
    long interval = 30000L;
    String prop = System.getProperty("cmdbControllRetriesNum");
    try {
      retriesNum = Integer.parseInt(prop);
    } catch (NumberFormatException e) {
    }
    prop = System.getProperty("cmdbControllInterval");
    try {
      interval = Long.parseLong(prop);
    } catch (NumberFormatException e) {
    }
    setRetriableExecutor(RetriableExecutorFactory.create(retriesNum, interval));
  }

  public MamResponse executeCMDBOperation(FrameworkOperation operation, CmdbContext context) throws CmdbResponseException {
    return executeCMDBOperation(operation, context, true);
  }

  public MamResponse executeCMDBOperation(FrameworkOperation operation, CmdbContext context, boolean isSynchronic) throws CmdbResponseException {
    ExecuteCMDBOperationInMode executeCMDBOperation = new ExecuteCMDBOperationInMode(getServiceAccessForCustomer(context, operation.getServiceName()), operation, context, isSynchronic);
    return ((MamResponse)executeRetriable(executeCMDBOperation, "N/A"));
  }

  public MamResponse executeOperation(FrameworkOperation operation, CmdbContext context) throws MamResponseException {
    return executeCMDBOperation(operation, context);
  }

  public MamResponse executeOperation(FrameworkOperation operation, CmdbContext context, boolean isSynchronic) throws MamResponseException {
    return executeCMDBOperation(operation, context, isSynchronic);
  }

  public byte[] executeBinaryRequest(CmdbContext context, String serviceName, byte[] serializedRequest) {
    ExecuteBinaryRequest executeBinaryRequest = new ExecuteBinaryRequest(getServiceAccessForCustomer(context, serviceName), serializedRequest);
    return ((byte[])executeRetriable(executeBinaryRequest, "N/A"));
  }

  private CmdbServiceAccess getServiceAccessForCustomer(CmdbContext context, String serviceName) {
    if (serviceName.equals("Framework service")) {
      return CmdServiceAccessFactoryImpl.getLocalAccess();
    }

    registerServiceAccessFactoryIfNeeded(serviceName);
    Service cmdbService = Service.getService(serviceName);
    ServiceDescriptor descriptor = ServiceDescriptor.getDescriptor(cmdbService, context.getCustomerID().getID());
    ServiceLocator locator = LocatorJMXFacade.getFacade();
    if (locator.isConfiguredLocally(descriptor))
      return CmdServiceAccessFactoryImpl.getLocalAccess();
    try
    {
      return ((CmdbServiceAccess)locator.getServiceAccess(descriptor));
    } catch (Exception e) {
      throw new MamResponseException("cannot access CMDB server due to error: " + e, e, context.toString());
    }
  }

  private synchronized void registerServiceAccessFactoryIfNeeded(String serviceName) {
    if (this._registeredServices.contains(serviceName))
      return;

    ServiceAccessFactory serviceAccessFactory = new CmdServiceAccessFactoryImpl();
    FactoryRegistryJMXFacade.getFacade().registerAccessFactory(Service.getService(serviceName), serviceAccessFactory);
    this._registeredServices.add(serviceName); }

  private <RESULT> RESULT executeRetriable(Retriable<RESULT> retriable, String responseId) throws CmdbResponseException {
    Throwable cause;
    try {
      return getRetriableExecutor().execute(retriable);
    } catch (RetryFailException e) {
      cause = e.getCause();

      if ((cause instanceof ServiceNotAvailableException) && (!(cause instanceof ServerCommunicationException)))
        throw new CmdbServiceNotAvailableException(cause, responseId);

      throw new MamResponseException("failed to invoke CMDB API due to exception: " + cause, cause, responseId);
    } catch (RetryFailUnexpectedCheckedException e) {
      cause = e.getCause();
      throw new MamResponseException("failed to invoke CMDB API due to exception: " + cause, cause, responseId);
    }
  }

  private RetriableExecutor getRetriableExecutor() {
    return this._retriableExecutor;
  }

  private void setRetriableExecutor(RetriableExecutor retriableExecutor) {
    if (retriableExecutor == null)
      throw new IllegalArgumentException("retrieable executor is null !!!");

    this._retriableExecutor = retriableExecutor;
  }
}