package com.mercury.topaz.cmdb.client.manage.ha.api.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.CmdbServiceAccess;

public class ExecuteBinaryRequest extends AbstractRetriableInvokeCmdbApi<byte[]>
{
  private static Log _logger = LogFactory.getEasyLog(ExecuteBinaryRequest.class);
  private final byte[] _serializedRequest;

  public ExecuteBinaryRequest(CmdbServiceAccess cmdbApi, byte[] serializedRequest)
  {
    super(cmdbApi);
    this._serializedRequest = serializedRequest;
  }

  public String getActionDescription() {
    return "Execute binary request";
  }

  public Log getLogger() {
    return _logger;
  }

  public byte[] performAction() throws Throwable {
    return getCmdbApi().executeBinaryRequest(this._serializedRequest);
  }
}