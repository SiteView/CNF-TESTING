package com.mercury.topaz.cmdb.client.manage.api.impl;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi.TYPE;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApiEnvironment;
import com.mercury.topaz.cmdb.client.manage.api.CmdbNotification;
import com.mercury.topaz.cmdb.client.manage.ha.api.impl.CmdbApiControlledFacadeFactory;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.API.RMI;
import com.mercury.topaz.cmdb.shared.manage.Environment;
import com.mercury.topaz.cmdb.shared.manage.operation.ProcessOperation;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;

public class CmdbApiFactory
{
  private static String _cmdbHostName;
  public static final String CMDB_HOST_NAME_PARAMETER = "cmdbHostName";
  public static final String LOCALHOST = "localhost";
  private static CmdbNotification _cmdbNotification;
  private static final String SINGLE_JVM_CONTROLLER_PROCESS_NAME = "mercury_as";

  public static CmdbApi createCMDBAPI(CmdbApi.TYPE type, CmdbApiEnvironment apiEnvironment)
    throws CmdbException
  {
    if (type == CmdbApi.RMI_TYPE)
      return new CmdbApiRmiImpl(apiEnvironment);
    if (type == CmdbApi.LOCAL_TYPE)
      return getFrameworkInstance();

    throw new UnsupportedOperationException("wasn't implemented");
  }

  private static Framework getFrameworkInstance()
  {
    return Framework.getInstance();
  }

  public static CmdbApi createCMDBAPI(CmdbApi.TYPE type)
    throws CmdbException
  {
    return createCMDBAPI(type, FrameworkConstants.API.RMI.DEFAULT_RMI_ENVIRONMENT);
  }

  public static CmdbApi createCMDBAPI()
    throws CmdbException
  {
    if (Environment.USE_CONTROLLER) {
      return CmdbApiControlledFacadeFactory.create();
    }

    String cmdbHostName = getCmdbHostName();
    if (isLocalApi(cmdbHostName))
      return createCMDBAPI(CmdbApi.LOCAL_TYPE);

    return createCMDBAPI(cmdbHostName);
  }

  public static CmdbApi createCMDBAPI(String cmdbHostName)
    throws CmdbException
  {
    if ((Environment.TEST_MODE) && (isLocalApi(cmdbHostName))) {
      return createCMDBAPI(CmdbApi.LOCAL_TYPE);
    }

    RmiEnvironment apiEnvironment = new RmiEnvironment(cmdbHostName);
    return createCMDBAPI(CmdbApi.RMI_TYPE, apiEnvironment);
  }

  public static CmdbNotification createNotificationService()
  {
    synchronized (CmdbApiFactory.class) {
      if (_cmdbNotification == null) {
        CmdbNotification cmdbNotification = CmdbNotificationServiceFactory.createNotification();
        cmdbNotification.startUp();
        _cmdbNotification = cmdbNotification;
      }
      return _cmdbNotification;
    }
  }

  private static boolean isLocalApi(String cmdbHostName) {
    boolean isLocalApi = false;
    boolean isLocalMachine = isLocalMachine(cmdbHostName);
    if (isLocalMachine)
      isLocalApi = getFrameworkInstance().isStartedUp();

    return isLocalApi;
  }

  private static boolean isLocalMachine(String cmdbHostName)
  {
    boolean isLocalMachine;
    if ("localhost".equalsIgnoreCase(cmdbHostName))
      isLocalMachine = true;
    else
      try {
        InetAddress localMachine = InetAddress.getLocalHost();
        InetAddress remoteMachine = InetAddress.getByName(cmdbHostName);
        byte[] loacalAddress = localMachine.getAddress();
        byte[] remoteAddress = remoteMachine.getAddress();
        isLocalMachine = Arrays.equals(loacalAddress, remoteAddress);
      } catch (Throwable t) {
        isLocalMachine = false;
      }

    return isLocalMachine;
  }

  private static String getCmdbHostName() {
    if (_cmdbHostName == null) {
      String hostName = System.getProperty("cmdbHostName");
      if ((hostName == null) || (hostName.length() == 0))
        _cmdbHostName = "localhost";
      else
        _cmdbHostName = hostName;
    }

    return _cmdbHostName;
  }

  public static CmdbApi createCMDBAPI(String serverName, String processName) {
    if (isLocalApi(serverName))
      return getFrameworkInstance();

    RmiEnvironment apiEnvironment = new RmiEnvironment(serverName);
    return new CmdbApiServerRmiImpl(apiEnvironment, serverName, processName);
  }

  public static CmdbApi createCMDBAPI(ProcessOperation operation)
  {
    String hostName = operation.getServerName();
    if (empty(hostName))
      try {
        hostName = InetAddress.getLocalHost().getHostName();
      } catch (UnknownHostException e) {
        throw new CmdbException("Failed to resolve local host actual name", e);
      }


    String processName = operation.getProcessName();
    if (empty(processName)) {
      processName = "mercury_as";
    }

    return createCMDBAPI(hostName, processName);
  }

  private static boolean empty(String str) {
    return ((str == null) || (str.trim().length() == 0));
  }
}