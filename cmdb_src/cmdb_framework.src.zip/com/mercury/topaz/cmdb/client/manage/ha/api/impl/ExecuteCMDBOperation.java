package com.mercury.topaz.cmdb.client.manage.ha.api.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.base.ha.controller.service.CmdbServiceAccess;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

abstract class ExecuteCMDBOperation extends AbstractRetriableInvokeCmdbApi<CmdbResponse>
{
  private static Log _logger = LogFactory.getEasyLog(ExecuteCMDBOperation.class);
  private FrameworkOperation _cmdbOperation;
  private CmdbContext _cmdbContext;

  public ExecuteCMDBOperation(CmdbServiceAccess cmdbApi, FrameworkOperation operation, CmdbContext context)
  {
    super(cmdbApi);
    setCmdbOperation(operation);
    setCmdbContext(context);
  }

  public String getActionDescription() {
    return "execute cmdb operation, operation [" + getCmdbOperation() + "] , context [" + getCmdbContext() + "]";
  }

  public Log getLogger() {
    return _logger;
  }

  protected FrameworkOperation getCmdbOperation() {
    return this._cmdbOperation;
  }

  private void setCmdbOperation(FrameworkOperation cmdbOperation) {
    this._cmdbOperation = cmdbOperation;
  }

  protected CmdbContext getCmdbContext() {
    return this._cmdbContext;
  }

  private void setCmdbContext(CmdbContext cmdbContext) {
    this._cmdbContext = cmdbContext;
  }
}