package com.mercury.topaz.cmdb.client.manage.api;

public abstract interface CmdbApiEnvironment
{
  public abstract String getHostName();
}