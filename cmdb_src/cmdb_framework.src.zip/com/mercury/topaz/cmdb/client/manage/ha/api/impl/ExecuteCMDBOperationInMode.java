package com.mercury.topaz.cmdb.client.manage.ha.api.impl;

import com.mercury.topaz.cmdb.server.base.ha.controller.service.CmdbServiceAccess;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

class ExecuteCMDBOperationInMode extends ExecuteCMDBOperation
{
  private boolean _isSynchronic;

  public ExecuteCMDBOperationInMode(CmdbServiceAccess cmdbApi, FrameworkOperation operation, CmdbContext context, boolean isSynchronic)
  {
    super(cmdbApi, operation, context);
    setSynchronic(isSynchronic);
  }

  public CmdbResponse performAction() throws Throwable {
    return getCmdbApi().executeCMDBOperation(getCmdbOperation(), getCmdbContext(), isSynchronic());
  }

  public String getActionDescription() {
    return super.getActionDescription() + " in " + getModeDescription() + " mode";
  }

  private String getModeDescription() {
    return ((isSynchronic()) ? "synchronous" : "asynchronous");
  }

  private boolean isSynchronic() {
    return this._isSynchronic;
  }

  private void setSynchronic(boolean synchronic) {
    this._isSynchronic = synchronic;
  }
}