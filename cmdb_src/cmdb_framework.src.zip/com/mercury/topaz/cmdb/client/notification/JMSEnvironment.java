package com.mercury.topaz.cmdb.client.notification;

import com.mercury.topaz.cmdb.client.manage.api.impl.RmiEnvironment;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Notification;

public class JMSEnvironment extends RmiEnvironment
{
  private static final String DEFAULT_HOST_NAME = "localhost";
  private static final String DEFAULT_TOPIC_CONNECTION_POOL = "CMDB_JMS_CONNECTION_FACTORY";
  private static final String DEFAULT_TOPIC_NAME = "topic/CMDB_NOTIFICATION";
  private static final Integer DEFAULT_RETRIES_NUMBER = Integer.valueOf(0);
  private static final Long DEFAULT_INTERVAL_BETWEEN_RETRIES = Long.valueOf(30000L);

  public JMSEnvironment()
  {
    this("localhost", "CMDB_JMS_CONNECTION_FACTORY", "topic/CMDB_NOTIFICATION");
  }

  public JMSEnvironment(String hostName) {
    this(hostName, "CMDB_JMS_CONNECTION_FACTORY", "topic/CMDB_NOTIFICATION");
  }

  public JMSEnvironment(String hostName, String connectionFactoryName, String topicName) {
    super(hostName);
    put("notification.jms.connection.factory", connectionFactoryName);
    put("notification.topic.jndi.name", topicName);
    put("notification.retry.number", DEFAULT_RETRIES_NUMBER);
    put("notification.retry.interval.msec", DEFAULT_INTERVAL_BETWEEN_RETRIES);
    put("notification.queue.size.max", FrameworkConstants.Notification.NOTIFICATION_JMS_MAX_QUEUE_SIZE_DEFAULT);
  }
}