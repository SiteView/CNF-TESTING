package com.mercury.topaz.cmdb.shared.change;

public abstract interface CmdbChangeListenerCorseGrained extends CmdbChangeListener
{
  public abstract void onChanges(CmdbChanges paramCmdbChanges);
}