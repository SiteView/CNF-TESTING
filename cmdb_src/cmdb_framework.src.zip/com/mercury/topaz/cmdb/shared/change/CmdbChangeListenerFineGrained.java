package com.mercury.topaz.cmdb.shared.change;

public abstract interface CmdbChangeListenerFineGrained extends CmdbChangeListener
{
  public abstract void onStartDeployment();

  public abstract void onFinishDeployment();
}