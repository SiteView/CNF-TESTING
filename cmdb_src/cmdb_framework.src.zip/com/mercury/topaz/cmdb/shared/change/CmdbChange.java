package com.mercury.topaz.cmdb.shared.change;

import java.io.Serializable;

public abstract interface CmdbChange extends Serializable
{
  public abstract void execute(CmdbChangeListenerFineGrained paramCmdbChangeListenerFineGrained);
}