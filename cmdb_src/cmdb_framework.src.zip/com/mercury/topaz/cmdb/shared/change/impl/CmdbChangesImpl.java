package com.mercury.topaz.cmdb.shared.change.impl;

import com.mercury.topaz.cmdb.server.util.time.CmdbTime;
import com.mercury.topaz.cmdb.shared.change.CmdbChange;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.util.collections.ReadOnlyList;
import com.mercury.topaz.cmdb.shared.util.collections.impl.ListFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class CmdbChangesImpl
  implements CmdbChanges
{
  private List<CmdbChange> _changes;
  private Changer _changer;
  private Date _changesDate;

  public CmdbChangesImpl()
  {
    this(Changer.EMPTY_CHANGER);
  }

  public CmdbChangesImpl(CmdbChange cmdbChange) {
    this(cmdbChange, Changer.EMPTY_CHANGER); }

  public CmdbChangesImpl(Changer changer) {
    setChanges(new ArrayList(20));
    setChanger(changer);
    setChangesDate(new Date(CmdbTime.currentTimeMillis()));
  }

  public CmdbChangesImpl(CmdbChange cmdbChange, Changer changer) {
    setChanges(new ArrayList(1));
    add(cmdbChange);
    setChanger(changer);
    setChangesDate(new Date(CmdbTime.currentTimeMillis()));
  }

  public void add(CmdbChange change)
  {
    if (change == null)
      throw new IllegalArgumentException("Attempt to add 'null' change to CmdbChanges");

    getChanges().add(change);
  }

  public void addAll(CmdbChanges changes)
  {
    if ((changes == null) || (changes.isEmpty()))
      throw new IllegalArgumentException("Attempt to add '" + changes + "' change to CmdbChanges");

    CmdbChangesImpl cmdbChanges = (CmdbChangesImpl)changes;
    getChanges().addAll(cmdbChanges._changes);
  }

  public boolean contains(CmdbChange change)
  {
    return getChanges().contains(change);
  }

  public ReadOnlyIterator<CmdbChange> getChangesIterator()
  {
    return ReadOnlyList.Factory.readOnly(getChanges().iterator());
  }

  public void clear()
  {
    getChanges().clear();
  }

  public boolean isEmpty()
  {
    return getChanges().isEmpty();
  }

  public int size()
  {
    return getChanges().size();
  }

  public Object clone()
    throws CloneNotSupportedException
  {
    CmdbChangesImpl cmdbChangesImpl = (CmdbChangesImpl)super.clone();
    cmdbChangesImpl.setChanges((List)((ArrayList)getChanges()).clone());
    return cmdbChangesImpl;
  }

  private List<CmdbChange> getChanges() {
    return this._changes;
  }

  private void setChanges(List<CmdbChange> changes) {
    this._changes = changes;
  }

  public Changer getChanger() {
    return this._changer;
  }

  private void setChanger(Changer changer) {
    if (changer == null)
      throw new IllegalArgumentException("changer is null");

    this._changer = changer;
  }

  public Date getChangesDate() {
    return this._changesDate;
  }

  private void setChangesDate(Date changesDate) {
    if (changesDate == null)
      throw new IllegalArgumentException("changes date is null");

    this._changesDate = changesDate;
  }

  public String toString() {
    return "Changer: " + getChanger() + ", changes: " + getChanges() + ", changes date: " + getChangesDate();
  }
}