package com.mercury.topaz.cmdb.shared.change;

import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.id.ChangeListenerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.io.Serializable;

public abstract interface CmdbChangeListener extends Serializable
{
  public abstract void startUp();

  public abstract void shutdown();

  public abstract FrameworkConstants.Subsystem getSubsystem();

  public abstract ChangeListenerID getID();

  public abstract CmdbCustomerID getCustomerID();
}