package com.mercury.topaz.cmdb.shared.change.impl;

import com.mercury.topaz.cmdb.shared.bean.AbstractCmdbImmutableBean;
import com.mercury.topaz.cmdb.shared.change.CmdbChange;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;
import java.io.ObjectStreamException;

public abstract class AbstractCMDBChange extends AbstractCmdbImmutableBean
  implements CmdbChange
{
  protected Object doReadResolve()
    throws ObjectStreamException
  {
    return this;
  }

  public CmdbDigest getDigest() {
    throw new UnsupportedOperationException("wasn't implemented");
  }
}