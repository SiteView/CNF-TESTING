package com.mercury.topaz.cmdb.shared.change.id;

import com.mercury.topaz.cmdb.shared.model.id.impl.AbstractCMDBIDFactory;

public abstract interface ChangeListenerID
{
  public static final Factory Factory = new Factory();

  public static final class Factory extends AbstractCMDBIDFactory
  {
    public ChangeListenerID createChangeListenerID()
    {
      return ((ChangeListenerID)super.createRandomID());
    }

    public ChangeListenerID restoreChangeListenerID(long mostSign, long leastSign)
    {
      return ((ChangeListenerID)super.restoreID(mostSign, leastSign));
    }

    public ChangeListenerID restoreChangeListenerID(byte[] digest)
    {
      return ((ChangeListenerID)super.restoreID(digest));
    }
  }
}