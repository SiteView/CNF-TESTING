package com.mercury.topaz.cmdb.shared.change.impl;

import appilog.framework.shared.manage.MamContext;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListener;
import com.mercury.topaz.cmdb.shared.change.id.ChangeListenerID;
import com.mercury.topaz.cmdb.shared.change.id.ChangeListenerID.Factory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.operation.util.AbstractOperationExecutor;

public abstract class AbstractCmdbChangeListener extends AbstractOperationExecutor
  implements CmdbChangeListener
{
  private ChangeListenerID _id;
  private FrameworkConstants.Subsystem _subsystem;

  protected AbstractCmdbChangeListener(FrameworkConstants.Subsystem subsystem, CmdbCustomerID customerID)
  {
    this(subsystem, customerID, ChangeListenerID.Factory.createChangeListenerID());
  }

  protected AbstractCmdbChangeListener(FrameworkConstants.Subsystem subsystem, CmdbCustomerID customerID, ChangeListenerID listenerID) {
    super(customerID);
    setId(listenerID);
    setSubsystem(subsystem);
  }

  public void startUp()
  {
  }

  public void shutdown()
  {
  }

  public CmdbCustomerID getCustomerID() {
    return getContext().getCustomerID();
  }

  public ChangeListenerID getID()
  {
    return this._id;
  }

  private void setId(ChangeListenerID id) {
    this._id = id;
  }

  public FrameworkConstants.Subsystem getSubsystem()
  {
    return this._subsystem;
  }

  private void setSubsystem(FrameworkConstants.Subsystem subsystem) {
    if (subsystem == null)
      throw new IllegalArgumentException("subsystem is null !!!");

    this._subsystem = subsystem;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append("CHANGE LISTENER: listener ID:").append(getID());
    sb.append(" ").append(getSubsystem());
    sb.append(" customer ID: ").append(getCustomerID());
    return sb.toString();
  }

  public boolean equals(Object obj) {
    if ((obj == null) || (!(obj instanceof CmdbChangeListener)))
      return false;

    return getID().equals(((CmdbChangeListener)obj).getID());
  }

  public int hashCode() {
    return getID().hashCode();
  }
}