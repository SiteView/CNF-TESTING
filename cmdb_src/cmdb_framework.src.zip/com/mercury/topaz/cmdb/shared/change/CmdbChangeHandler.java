package com.mercury.topaz.cmdb.shared.change;

public abstract interface CmdbChangeHandler
{
  public abstract CmdbChanges getChanges();

  public abstract void clearChanges();
}