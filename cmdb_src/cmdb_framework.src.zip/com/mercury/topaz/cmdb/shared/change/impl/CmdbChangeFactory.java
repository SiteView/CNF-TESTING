package com.mercury.topaz.cmdb.shared.change.impl;

import com.mercury.topaz.cmdb.shared.change.CmdbChange;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;

public class CmdbChangeFactory
{
  public static CmdbChanges createCmdbChanges()
  {
    return new CmdbChangesImpl();
  }

  public static CmdbChanges createCmdbChangesForOneChange(CmdbChange cmdbChange) {
    return new CmdbChangesImpl(cmdbChange);
  }

  public static CmdbChanges createCmdbChangesForOneChange(CmdbChange cmdbChange, Changer changer) {
    return new CmdbChangesImpl(cmdbChange, changer);
  }

  public static CmdbChanges createCmdbChanges(Changer changer) {
    return new CmdbChangesImpl(changer);
  }
}