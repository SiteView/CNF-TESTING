package com.mercury.topaz.cmdb.shared.change;

import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.Serializable;
import java.util.Date;

public abstract interface CmdbChanges
{
  public abstract void add(CmdbChange paramCmdbChange);

  public abstract void addAll(CmdbChanges paramCmdbChanges);

  public abstract boolean contains(CmdbChange paramCmdbChange);

  public abstract ReadOnlyIterator<CmdbChange> getChangesIterator();

  public abstract void clear();

  public abstract boolean isEmpty();

  public abstract int size();

  public abstract Object clone()
    throws CloneNotSupportedException;

  public abstract Changer getChanger();

  public abstract Date getChangesDate();
}