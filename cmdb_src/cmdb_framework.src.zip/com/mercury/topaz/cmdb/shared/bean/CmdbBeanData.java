package com.mercury.topaz.cmdb.shared.bean;

import com.mercury.topaz.cmdb.shared.model.digest.Digestible;
import java.io.Serializable;

public abstract interface CmdbBeanData
{
}