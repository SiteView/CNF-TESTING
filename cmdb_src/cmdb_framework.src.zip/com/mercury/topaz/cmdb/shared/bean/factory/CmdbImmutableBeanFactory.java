package com.mercury.topaz.cmdb.shared.bean.factory;

import com.mercury.topaz.cmdb.shared.bean.CmdbImmutableBean;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

public class CmdbImmutableBeanFactory<T extends CmdbImmutableBean>
{
  private WeakHashMap _objectCache;

  protected CmdbImmutableBeanFactory()
  {
    initCache();
  }

  private WeakHashMap getObjectCache()
  {
    return this._objectCache;
  }

  private void setObjectCache(WeakHashMap objectCache)
  {
    this._objectCache = objectCache;
  }

  public synchronized T obtainObject(T cmdbImmutableBean)
  {
    WeakReference ref = (WeakReference)getObjectCache().get(cmdbImmutableBean);
    CmdbImmutableBean cached = null;

    if (ref != null)
      cached = (CmdbImmutableBean)ref.get();

    if (cached == null) {
      cmdbImmutableBean.doInternalCache();
      getObjectCache().put(cmdbImmutableBean, new WeakReference(cmdbImmutableBean));
      cached = cmdbImmutableBean;
    }
    return cached;
  }

  public synchronized int getSize()
  {
    return getObjectCache().size();
  }

  protected void initCache() {
    setObjectCache(new WeakHashMap());
  }
}