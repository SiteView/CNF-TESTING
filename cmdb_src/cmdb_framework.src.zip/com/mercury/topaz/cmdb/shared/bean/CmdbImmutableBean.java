package com.mercury.topaz.cmdb.shared.bean;

public abstract interface CmdbImmutableBean extends CmdbBeanData
{
  public abstract void doInternalCache();
}