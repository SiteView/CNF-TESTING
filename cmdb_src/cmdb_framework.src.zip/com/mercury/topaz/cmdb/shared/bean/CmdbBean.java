package com.mercury.topaz.cmdb.shared.bean;

public abstract class CmdbBean
  implements CmdbBeanData
{
}