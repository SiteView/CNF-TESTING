package com.mercury.topaz.cmdb.shared.bean;

import java.io.ObjectStreamException;

public abstract class AbstractCmdbImmutableBean extends CmdbBean
  implements CmdbImmutableBean
{
  protected final Object readResolve()
    throws ObjectStreamException
  {
    return doReadResolve();
  }

  protected abstract Object doReadResolve()
    throws ObjectStreamException;

  public void doInternalCache()
  {
  }
}