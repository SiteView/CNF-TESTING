package com.mercury.topaz.cmdb.shared.bean;

public abstract class CmdbMutableBean extends CmdbBean
{
}