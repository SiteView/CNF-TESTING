package com.mercury.topaz.cmdb.shared.manage.customer.operation.update.impl;

import com.mercury.topaz.cmdb.server.manage.customer.CustomerManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class CmdbCustomerUpdateShutdownService extends AbstractCustomerUpdateOperationCmdb
{
  private final String _controllerServiceName;

  public CmdbCustomerUpdateShutdownService(CmdbCustomerID customerID, String serviceName)
  {
    super(customerID);
    this._controllerServiceName = serviceName;
  }

  public String getOperationName() {
    return "Cmdb customer update: shutdown service [" + getControllerServiceName() + "] of customer id [" + getCustomerID() + "]";
  }

  public void customerUpdateExecute(CustomerManager cmdbCustomerManager, CmdbResponse response) throws CmdbException {
    cmdbCustomerManager.shutdownService(getCustomerID(), getControllerServiceName());
  }

  private String getControllerServiceName() {
    return this._controllerServiceName;
  }

  public String getServiceName() {
    return "Framework service";
  }
}