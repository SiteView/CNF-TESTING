package com.mercury.topaz.cmdb.shared.manage.quota.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaCheckResponse;
import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class QuotaQueryIsQuotaExceeded extends AbstractQuotaQueryOperationCmdb
{
  private static final String IS_QUOTA_EXCEEDED = "IS_QUOTA_EXCEEDED";
  private CmdbCustomerID _cmdbCustomerID;
  private String _quotaName;
  private int _countToIncrease;
  private QuotaCheckResponse _quotaCheckResponse;

  public QuotaQueryIsQuotaExceeded(CmdbCustomerID customerID, String quotaName, int countToIncrease)
  {
    setCmdbCustomerID(customerID);
    setQuotaName(quotaName);
    setCountToIncrease(countToIncrease);
  }

  public String getOperationName() {
    return "quota query: is quota exceeded";
  }

  public void quotaQueryExecute(QuotaManager quotaManager, CmdbResponse response) throws CmdbException {
    QuotaCheckResponse quotaCheckResponse = quotaManager.checkQuota(getCmdbCustomerID(), getQuotaName(), getCountToIncrease());
    response.addResult("IS_QUOTA_EXCEEDED", quotaCheckResponse);
  }

  public void updateWithResponse(CmdbResponse response) {
    QuotaCheckResponse quotaCheckResponse = (QuotaCheckResponse)response.getResult("IS_QUOTA_EXCEEDED");
    setQuotaCheckResponse(quotaCheckResponse);
  }

  private CmdbCustomerID getCmdbCustomerID() {
    return this._cmdbCustomerID;
  }

  private void setCmdbCustomerID(CmdbCustomerID cmdbCustomerID) {
    this._cmdbCustomerID = cmdbCustomerID;
  }

  private String getQuotaName() {
    return this._quotaName;
  }

  private void setQuotaName(String quotaName) {
    this._quotaName = quotaName;
  }

  private int getCountToIncrease() {
    return this._countToIncrease;
  }

  private void setCountToIncrease(int countToIncrease) {
    this._countToIncrease = countToIncrease;
  }

  public QuotaCheckResponse getQuotaCheckResponse() {
    return this._quotaCheckResponse;
  }

  private void setQuotaCheckResponse(QuotaCheckResponse quotaCheckResponse) {
    this._quotaCheckResponse = quotaCheckResponse;
  }

  public String getServiceName() {
    return "Framework service";
  }
}