package com.mercury.topaz.cmdb.shared.manage.quota.operation.query.impl;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.API;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import com.mercury.topaz.cmdb.shared.manage.quota.config.QuotaConfig;
import com.mercury.topaz.cmdb.shared.manage.quota.config.QuotasConfig;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class GetAllQuotas extends AbstractQuotaQueryOperationCmdb
{
  private Map<CmdbCustomerID, CustomerQuotasAndCounts> customerQuotas;
  private Map<String, QuotaCount> serverQuotas;

  public GetAllQuotas()
  {
    this.customerQuotas = null;
    this.serverQuotas = null; }

  public String getOperationName() {
    return "Get all quotas";
  }

  public String getServiceName() {
    return "CMDB";
  }

  public void quotaQueryExecute(QuotaManager quotaManager, CmdbResponse response) throws CmdbException {
    for (Iterator i$ = QuotasConfig.instance().configs().iterator(); i$.hasNext(); ) { QuotaConfig config = (QuotaConfig)i$.next();
      String serviceName = config.getControllerServiceName();
      QuotaQueryGetQuotaAndCountInfo op = new QuotaQueryGetQuotaAndCountInfo(serviceName);
      CmdbApiFactory.createCMDBAPI(CmdbApi.RMI_TYPE).executeOperation(op, FrameworkConstants.API.CMDB_GLOBAL_CONTEXT);

      if (this.customerQuotas == null) {
        this.customerQuotas = op.getQuotaAndCountInfo();
      } else {
        Map quotasPerService = op.getQuotaAndCountInfo();
        for (Iterator i$ = quotasPerService.keySet().iterator(); i$.hasNext(); ) { CmdbCustomerID customerID = (CmdbCustomerID)i$.next();
          CustomerQuotasAndCounts quotasPerCustomer = (CustomerQuotasAndCounts)this.customerQuotas.get(customerID);
          if (quotasPerCustomer == null) {
            this.customerQuotas.put(customerID, quotasPerCustomer);
          } else {
            CustomerQuotasAndCounts quotas = (CustomerQuotasAndCounts)quotasPerService.get(customerID);
            for (Iterator i$ = quotas.getQuotaNames().iterator(); i$.hasNext(); ) { String quotaName = (String)i$.next();
              quotasPerCustomer.addQuotaAndCount(quotaName, quotas.getQuotaCount(quotaName));
            }
          }
        }

      }

      if (this.serverQuotas == null)
        this.serverQuotas = op.getServerQuotasAndCounts();
      else
        this.serverQuotas.putAll(op.getServerQuotasAndCounts());

    }

    response.addResult("CUSTOMERS_COUNT_AND_QUOTAS", (Serializable)this.customerQuotas);
    response.addResult("SERVER_COUNT_AND_QUOTAS", (Serializable)this.serverQuotas);
  }

  public void updateWithResponse(CmdbResponse response) {
    super.updateWithResponse(response);
    this.customerQuotas = ((Map)response.getResult("CUSTOMERS_COUNT_AND_QUOTAS"));
    this.serverQuotas = ((Map)response.getResult("SERVER_COUNT_AND_QUOTAS"));
  }

  public Map<CmdbCustomerID, CustomerQuotasAndCounts> getCustomerQuotas() {
    return this.customerQuotas;
  }

  public Map<String, QuotaCount> getServerQuotas() {
    return this.serverQuotas;
  }
}