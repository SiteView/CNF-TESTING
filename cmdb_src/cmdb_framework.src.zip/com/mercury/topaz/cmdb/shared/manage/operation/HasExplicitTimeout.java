package com.mercury.topaz.cmdb.shared.manage.operation;

public abstract interface HasExplicitTimeout
{
  public abstract long getTimeout();
}