package com.mercury.topaz.cmdb.shared.manage.operation;

import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;

public abstract interface FrameworkOperation
{
  public abstract String getOperationName();

  public abstract boolean isPeriodicOperation();

  public abstract String getExecutionTaskQueueName();

  public abstract void execute(CommonManager paramCommonManager, CmdbResponse paramCmdbResponse)
    throws CmdbResponseException;

  public abstract void updateWithResponse(CmdbResponse paramCmdbResponse);

  public abstract String getServiceName();

  public abstract void onAcquiringLock();

  public abstract void onLockAcquired();

  public abstract String getDetailedAuditMessage();

  public abstract String getShortAuditMessage();

  public abstract String getAdditionalLogMessage();

  public abstract String getMessageIncludingParameters();
}