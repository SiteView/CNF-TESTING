package com.mercury.topaz.cmdb.shared.manage.quota.operation.impl;

import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractFrameworkGlobalOperation;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.QuotaOperation;

public abstract class AbstractQuotaOperationCmdb extends AbstractFrameworkGlobalOperation
  implements QuotaOperation
{
  public String getExecutionTaskQueueName()
  {
    return "Quota Management Task";
  }
}