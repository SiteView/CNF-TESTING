package com.mercury.topaz.cmdb.shared.manage.quota.impl;

import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.DataCount;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;

public class QuotaFactory
{
  public static QuotaCount createQuotaCount(int quota)
  {
    return new QuotaCountImpl(quota); }

  public static DataCount createDataCount(CmdbCustomerID customerID, String quotaName, int newCount) {
    return new DataCountImpl(customerID, quotaName, newCount);
  }

  public static CustomerQuotasAndCounts createCustomerQuotasAndCounts() {
    return new CustomerQuotasAndCountsImpl();
  }
}