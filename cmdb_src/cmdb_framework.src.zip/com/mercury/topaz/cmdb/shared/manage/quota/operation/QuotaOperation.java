package com.mercury.topaz.cmdb.shared.manage.quota.operation;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkGlobalOperation;

public abstract interface QuotaOperation extends FrameworkGlobalOperation
{
}