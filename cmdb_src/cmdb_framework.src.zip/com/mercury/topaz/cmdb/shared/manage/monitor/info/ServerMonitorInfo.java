package com.mercury.topaz.cmdb.shared.manage.monitor.info;

import java.io.Serializable;
import java.util.List;

public abstract interface ServerMonitorInfo extends Serializable
{
  public abstract List getTasksMonitorInfo();

  public abstract String getInfoAsString();
}