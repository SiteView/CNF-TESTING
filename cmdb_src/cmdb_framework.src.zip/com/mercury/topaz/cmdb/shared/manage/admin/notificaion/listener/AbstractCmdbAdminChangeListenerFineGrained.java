package com.mercury.topaz.cmdb.shared.manage.admin.notificaion.listener;

import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public abstract class AbstractCmdbAdminChangeListenerFineGrained extends AbstractCmdbAdminChangeListener
  implements CmdbAdminChangeListenerFineGrained
{
  protected AbstractCmdbAdminChangeListenerFineGrained(CmdbCustomerID customerID)
  {
    super(customerID);
  }
}