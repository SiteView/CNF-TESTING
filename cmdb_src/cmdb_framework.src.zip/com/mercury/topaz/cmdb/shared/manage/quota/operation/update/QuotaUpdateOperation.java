package com.mercury.topaz.cmdb.shared.manage.quota.operation.update;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.QuotaOperation;

public abstract interface QuotaUpdateOperation
{
  public abstract void quotaUpdateExecute(QuotaManager paramQuotaManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}