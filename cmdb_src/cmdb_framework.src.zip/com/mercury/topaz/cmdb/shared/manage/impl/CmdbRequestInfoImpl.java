package com.mercury.topaz.cmdb.shared.manage.impl;

import com.mercury.topaz.cmdb.shared.bean.CmdbBean;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequestInfo;
import com.mercury.topaz.cmdb.shared.manage.OperationStack;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;
import com.mercury.topaz.cmdb.shared.model.digest.impl.CmdbDigestFactory;

public class CmdbRequestInfoImpl extends CmdbBean
  implements CmdbRequestInfo
{
  private String _id;
  private String _message;
  private CmdbContext _context;
  private boolean _isSynchronic;
  private String _operationName;

  public CmdbRequestInfoImpl(CmdbRequestInfo requestInfo)
  {
    this(requestInfo.getMessage(), requestInfo.getContext(), requestInfo.getID(), requestInfo.isSynchronic());
    setOperationName(requestInfo.getOperationName());
  }

  protected CmdbRequestInfoImpl(String message, CmdbContext context, String id, boolean synchronic) {
    setContext(context);
    setId(id);
    setSynchronic(synchronic);
    setMessage(message);
  }

  public CmdbDigest getDigest()
  {
    return CmdbDigestFactory.generateDigest(getID());
  }

  public String getID()
  {
    return getId();
  }

  public String getMessage() {
    return this._message;
  }

  public CmdbCustomerID getCustomerID() {
    return getContext().getCustomerID();
  }

  public CmdbContext getContext()
  {
    return this._context;
  }

  protected void setContext(CmdbContext context) {
    if (context == null)
      throw new IllegalArgumentException("Attempt to set 'null' CmdbContext to request");

    this._context = context;
  }

  private String getId() {
    return this._id;
  }

  protected void setId(String id) {
    if (id == null)
      throw new IllegalArgumentException("Attempt to set 'null' ID to request");

    this._id = id;
  }

  protected void setMessage(String message) {
    this._message = message;
  }

  public boolean isSynchronic()
  {
    return this._isSynchronic;
  }

  protected void setSynchronic(boolean synchronic) {
    this._isSynchronic = synchronic;
  }

  public String getOperationName() {
    return this._operationName;
  }

  private void setOperationName(String operationName) {
    this._operationName = operationName;
  }

  public String toString() {
    return "{request: ID='" + getID() + "' " + "Message='" + getMessage() + "' " + "Operation Stack Trace='" + OperationStack.asString() + "' " + "Context='" + getContext() + "' " + "Customer ID='" + getCustomerID() + "'}";
  }
}