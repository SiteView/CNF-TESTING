package com.mercury.topaz.cmdb.shared.manage.admin.notificaion.change;

import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.change.impl.AbstractCMDBChange;
import com.mercury.topaz.cmdb.shared.manage.admin.notificaion.listener.CmdbAdminChangeListenerFineGrained;

abstract class AbstractCmdbAdminChange extends AbstractCMDBChange
{
  public final void execute(CmdbChangeListenerFineGrained changeListener)
  {
    executeCmdbAdminChange((CmdbAdminChangeListenerFineGrained)changeListener);
  }

  protected abstract void executeCmdbAdminChange(CmdbAdminChangeListenerFineGrained paramCmdbAdminChangeListenerFineGrained);
}