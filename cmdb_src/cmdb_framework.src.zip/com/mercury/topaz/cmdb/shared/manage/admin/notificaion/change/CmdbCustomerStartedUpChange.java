package com.mercury.topaz.cmdb.shared.manage.admin.notificaion.change;

import com.mercury.topaz.cmdb.shared.manage.admin.notificaion.listener.CmdbAdminChangeListenerFineGrained;

class CmdbCustomerStartedUpChange extends AbstractCmdbAdminChange
{
  protected void executeCmdbAdminChange(CmdbAdminChangeListenerFineGrained changeListener)
  {
    changeListener.onCmdbCustomerStartedUp();
  }
}