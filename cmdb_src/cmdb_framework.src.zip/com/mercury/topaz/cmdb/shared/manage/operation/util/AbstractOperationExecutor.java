package com.mercury.topaz.cmdb.shared.manage.operation.util;

import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract class AbstractOperationExecutor
  implements OperationExecutor
{
  private CmdbContext _context;
  private CmdbApi _cmdbApi;

  public AbstractOperationExecutor(CmdbCustomerID customerID)
  {
    setContext(CmdbContextFactory.createCmdbContext(customerID, -1, "CMDB"));
  }

  public AbstractOperationExecutor(CmdbContext context)
  {
    setContext(context);
  }

  public AbstractOperationExecutor(CmdbContext context, CmdbApi cmdbApi) {
    this(context);
    setCmdbApi(cmdbApi);
  }

  public void executeOperation(FrameworkOperation operation)
    throws CmdbResponseException
  {
    executeOperation(operation, true);
  }

  public void executeAsynchronousOperation(FrameworkOperation operation)
    throws CmdbResponseException
  {
    executeOperation(operation, false);
  }

  private void executeOperation(FrameworkOperation operation, boolean isSynchronous) throws CmdbResponseException {
    getCmdbApi().executeCMDBOperation(operation, getContext(), isSynchronous);
  }

  protected MamContext getContext() {
    return ((MamContext)this._context);
  }

  private void setContext(CmdbContext context) {
    if (context == null)
      throw new IllegalArgumentException("cmdb context is null !!!");

    this._context = context;
  }

  protected CmdbApi getCmdbApi() {
    if (this._cmdbApi == null)
      try {
        setCmdbApi(CmdbApiFactory.createCMDBAPI());
      }
      catch (CmdbException e) {
        throw new MamResponseException("Can't createCalculationState local API to CMDB server due to an exception: " + e.getMessage(), e, "");
      }


    return this._cmdbApi;
  }

  private void setCmdbApi(CmdbApi cmdbApi) {
    this._cmdbApi = cmdbApi;
  }
}