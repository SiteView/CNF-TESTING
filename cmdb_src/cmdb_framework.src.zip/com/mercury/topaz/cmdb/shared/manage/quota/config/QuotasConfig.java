package com.mercury.topaz.cmdb.shared.manage.quota.config;

import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.quota.handler.QuotaCountHandler;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class QuotasConfig
{
  private static final String CONFIG_FILE_NAME = "/services/quotas.xml";
  private static QuotasConfig instance = null;
  private static boolean beansLoaded;
  private Map<String, String> quotasConfig = new HashMap(16);
  private List<QuotaConfig> configs = new LinkedList();

  public static QuotasConfig instance()
  {
    synchronized (QuotasConfig.class) {
      if (instance == null)
        instance = new QuotasConfig();

      instance.loadBeans();
    }
    return instance;
  }

  private void loadBeans()
  {
    if (beansLoaded) {
      return;
    }

    AbstractApplicationContext ctxt = new ClassPathXmlApplicationContext("/services/quotas.xml");

    String[] beanNames = ctxt.getBeanNamesForType(QuotaConfig.class);

    String[] arr$ = beanNames; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String beanName = arr$[i$];
      QuotaConfig config = (QuotaConfig)ctxt.getBean(beanName);
      this.quotasConfig.put(config.getQuotaHandler().getCustomerQuotaName(), config.getControllerServiceName());
      this.quotasConfig.put(config.getQuotaHandler().getServerQuotaName(), config.getControllerServiceName());
      this.configs.add(config);
    }

    beansLoaded = true;
  }

  public String getControllerServiceName(String quotaName) {
    if (StringUtils.isEmpty(quotaName)) {
      throw new CmdbException("Can not resolve service name for empty quota name");
    }

    String serviceName = (String)this.quotasConfig.get(quotaName);
    if (StringUtils.isEmpty(serviceName)) {
      throw new CmdbException("Failed to resolve service name for quota name (" + quotaName + ")");
    }

    return serviceName;
  }

  public Iterable<QuotaConfig> configs() {
    return this.configs;
  }

  public static void main(String[] args) {
    for (Iterator i$ = instance().configs().iterator(); i$.hasNext(); ) { QuotaConfig quotaConfig = (QuotaConfig)i$.next();
      System.out.println("CS name = " + quotaConfig.getControllerServiceName());
      System.out.println("Customer quota name = " + quotaConfig.getQuotaHandler().getCustomerQuotaName());
      System.out.println("Server quota name = " + quotaConfig.getQuotaHandler().getServerQuotaName());
      System.out.println("\n");
    }
  }
}