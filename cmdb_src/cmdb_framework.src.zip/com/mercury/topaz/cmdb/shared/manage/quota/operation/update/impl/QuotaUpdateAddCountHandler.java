package com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.quota.handler.QuotaCountHandler;

public class QuotaUpdateAddCountHandler extends AbstractUpdateQuotaOperationCmdb
{
  private QuotaCountHandler countHandler;
  private CmdbCustomerID customerID;

  public QuotaUpdateAddCountHandler(CmdbCustomerID customerID, QuotaCountHandler countHandler)
  {
    this.countHandler = countHandler;
    this.customerID = customerID;
  }

  public String getOperationName() {
    return "quota command: add count handler";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public void quotaUpdateExecute(QuotaManager quotaManager, CmdbResponse response) {
    quotaManager.addCountHandler(this.customerID, this.countHandler);
  }
}