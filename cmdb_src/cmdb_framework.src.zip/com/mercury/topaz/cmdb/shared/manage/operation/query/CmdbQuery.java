package com.mercury.topaz.cmdb.shared.manage.operation.query;

import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface CmdbQuery extends FrameworkOperation
{
  public abstract void updateQueryWithResponse(CmdbResponse paramCmdbResponse);
}