package com.mercury.topaz.cmdb.shared.manage.customer.operation.update.impl;

import com.mercury.topaz.cmdb.server.manage.customer.CustomerManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.operation.HasExplicitTimeout;

public class CmdbCustomerUpdateStartupService extends AbstractCustomerUpdateOperationCmdb
  implements HasExplicitTimeout
{
  private static final int SESSION_TIMEOUT_IN_MSEC = 86400000;
  private final String _controllerServiceName;

  public CmdbCustomerUpdateStartupService(CmdbCustomerID customerID, String serviceName)
  {
    super(customerID);
    this._controllerServiceName = serviceName;
  }

  public String getOperationName() {
    return "Cmdb customer update: startup service [" + getControllerServiceName() + "] for customer id [" + getCustomerID() + "]";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public long getTimeout() {
    return 86400000L;
  }

  public void customerUpdateExecute(CustomerManager cmdbCustomerManager, CmdbResponse response) throws CmdbException {
    cmdbCustomerManager.startupService(getCustomerID(), getControllerServiceName());
  }

  public String getControllerServiceName() {
    return this._controllerServiceName;
  }
}