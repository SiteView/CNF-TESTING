package com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.customer.CustomerQueryManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;

public class CmdbCustomerQueryGetLoadedCustomerIDs extends AbstractCustomerQueryCmdb
{
  private static final String CUSTOMER_IDS = "CUSTOMER_IDS";
  private CmdbCustomerIDs _customerIDs;
  private String _serviceName;
  private boolean serviceNameForResolution;

  public CmdbCustomerQueryGetLoadedCustomerIDs()
  {
    this(null, false);
  }

  public CmdbCustomerQueryGetLoadedCustomerIDs(String _serviceName) {
    this(_serviceName, true);
  }

  public CmdbCustomerQueryGetLoadedCustomerIDs(String serviceName, boolean serviceNameForResolution) {
    this._serviceName = serviceName;
    this.serviceNameForResolution = serviceNameForResolution;
  }

  public String getOperationName() {
    return "Cmdb Customer query: get loaded customer ids";
  }

  public void customerQueryExecute(CustomerQueryManager cmdbCustomerManager, CmdbResponse response) throws CmdbException
  {
    CmdbCustomerIDs cmdbCustomerIDs;
    if ((empty(this._serviceName)) || (this.serviceNameForResolution))
      cmdbCustomerIDs = cmdbCustomerManager.getLoadedCustomerIds();
    else {
      cmdbCustomerIDs = cmdbCustomerManager.getLoadedCustomerIds(this._serviceName);
    }

    response.addResult("CUSTOMER_IDS", cmdbCustomerIDs);
  }

  private boolean empty(String str) {
    return ((str == null) || (str.trim().length() == 0));
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setCustomerIDs((CmdbCustomerIDs)response.getResult("CUSTOMER_IDS"));
  }

  public CmdbCustomerIDs getCustomerIDs() {
    return this._customerIDs;
  }

  private void setCustomerIDs(CmdbCustomerIDs customerIDs) {
    this._customerIDs = customerIDs;
  }

  public String getServiceName() {
    if ((empty(this._serviceName)) || (!(this.serviceNameForResolution)))
      return "Framework service";

    return this._serviceName;
  }
}