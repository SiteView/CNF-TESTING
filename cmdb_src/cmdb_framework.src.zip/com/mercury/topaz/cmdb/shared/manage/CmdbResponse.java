package com.mercury.topaz.cmdb.shared.manage;

import appilog.framework.shared.manage.MamContext;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.io.Serializable;

public abstract interface CmdbResponse extends CmdbContextHolder
{
  public abstract String getID();

  public abstract String getMessage();

  public abstract void setMessage(String paramString);

  public abstract long getServerRunningTime();

  public abstract void setServerRunningTime(long paramLong);

  public abstract Object getResult(String paramString);

  public abstract boolean hasResultKey(String paramString);

  public abstract void addResult(String paramString, Serializable paramSerializable);

  public abstract Iterable<String> iterator();

  public abstract MamContext getContext();

  public abstract void redirectToOperation(FrameworkOperation paramFrameworkOperation);

  public abstract boolean isRedirected();

  public abstract FrameworkOperation getRedirectedOperation();
}