package com.mercury.topaz.cmdb.shared.manage.monitor.info;

import com.mercury.topaz.cmdb.shared.manage.CmdbRequestInfo;
import java.io.Serializable;

public abstract interface CmdbRequestMonitorInfo extends Serializable
{
  public abstract CmdbRequestInfo getCmdbRequestInfo();

  public abstract long getRunningTime();
}