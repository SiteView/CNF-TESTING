package com.mercury.topaz.cmdb.shared.manage.admin.notificaion.listener;

import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;

public abstract interface CmdbAdminChangeListenerFineGrained extends CmdbChangeListenerFineGrained
{
  public abstract void onCmdbCustomerStartedUp();
}