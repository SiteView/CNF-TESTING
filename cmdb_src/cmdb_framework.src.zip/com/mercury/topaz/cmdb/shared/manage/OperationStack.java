package com.mercury.topaz.cmdb.shared.manage;

import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.Stack;

public class OperationStack
{
  private static ThreadLocal<Stack<Integer>> operationStack = new ThreadLocal() {
    protected Stack<Integer> initialValue() {
      return new Stack();
    }
  };

  public static int getID() {
    try {
      return ((Integer)((Stack)operationStack.get()).peek()).intValue();
    } catch (EmptyStackException e) {
      throw new RuntimeException("Coding error. The thread-local operation stack is not initialized.");
    }
  }

  public static void pushID(int operationID) {
    ((Stack)operationStack.get()).push(Integer.valueOf(operationID));
  }

  public static void pop() {
    ((Stack)operationStack.get()).pop();
  }

  public static int getDepth() {
    return ((Stack)operationStack.get()).size();
  }

  private static Stack<Integer> getStack() {
    return ((Stack)operationStack.get());
  }

  public static String asString() {
    int depth = getDepth();
    if (depth == 0)
      return "N/A";

    StringBuffer sb = new StringBuffer();
    for (Iterator i$ = getStack().iterator(); i$.hasNext(); ) { Integer id = (Integer)i$.next();
      sb.append(id).append(" ");
    }

    sb.deleteCharAt(sb.length() - 1);
    return sb.toString();
  }

  public static String lastTwoEntriesAsString() {
    Stack stack = getStack();
    if (stack.size() >= 2)
      return ((Integer)stack.get(stack.size() - 2)).toString() + " " + stack.get(stack.size() - 1);
    if (stack.size() == 1)
      return ((Integer)stack.peek()).toString();

    return "";
  }
}