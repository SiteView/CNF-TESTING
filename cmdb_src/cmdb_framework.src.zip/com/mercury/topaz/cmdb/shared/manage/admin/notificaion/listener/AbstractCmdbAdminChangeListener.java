package com.mercury.topaz.cmdb.shared.manage.admin.notificaion.listener;

import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.impl.AbstractCmdbChangeListener;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

abstract class AbstractCmdbAdminChangeListener extends AbstractCmdbChangeListener
{
  AbstractCmdbAdminChangeListener(CmdbCustomerID customerID)
  {
    super(FrameworkConstants.Subsystem.CMDB_ADMIN, customerID);
  }
}