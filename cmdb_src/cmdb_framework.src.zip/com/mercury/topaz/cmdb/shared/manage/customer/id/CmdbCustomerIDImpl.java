package com.mercury.topaz.cmdb.shared.manage.customer.id;

import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.topaz.cmdb.shared.bean.AbstractCmdbImmutableBean;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;
import java.io.ObjectStreamException;

public class CmdbCustomerIDImpl extends AbstractCmdbImmutableBean
  implements MamCustomerID
{
  int _customerID;
  String _customerName;

  public CmdbCustomerIDImpl(int customerID)
  {
    this._customerID = customerID;
  }

  public CmdbCustomerIDImpl(int customerID, String customerName) {
    this._customerID = customerID;
    this._customerName = customerName;
  }

  public CmdbDigest getDigest() {
    throw new UnsupportedOperationException("wasn't implemented");
  }

  public int getID() {
    return this._customerID;
  }

  public String getIDName() {
    return this._customerName;
  }

  protected Object doReadResolve() throws ObjectStreamException {
    return Factory.createCMDBCustomerID(this._customerID);
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if (!(o instanceof CmdbCustomerIDImpl)) {
      return false;
    }

    CmdbCustomerIDImpl cmdbCustomerID = (CmdbCustomerIDImpl)o;

    return (this._customerID == cmdbCustomerID._customerID);
  }

  public int hashCode()
  {
    return this._customerID;
  }

  public String toString() {
    return ((getIDName() != null) ? String.valueOf(this._customerID) + ", id name: " + getIDName() : String.valueOf(this._customerID));
  }
}