package com.mercury.topaz.cmdb.shared.manage.quota.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import java.io.Serializable;
import java.util.Map;

public class QuotaQueryGetQuotaAndCountInfo extends AbstractQuotaQueryOperationCmdb
{
  private Map<CmdbCustomerID, CustomerQuotasAndCounts> _customerQuotasAndCounts;
  private Map<String, QuotaCount> _serverQuotasAndCounts;
  private String serviceName;

  public QuotaQueryGetQuotaAndCountInfo()
  {
    this(null);
  }

  public QuotaQueryGetQuotaAndCountInfo(String serviceName) {
    this.serviceName = serviceName;
  }

  public String getOperationName() {
    return "quota query: get quota and count info";
  }

  public void quotaQueryExecute(QuotaManager quotaManager, CmdbResponse response) throws CmdbException {
    Map customersCountsAndQuotas = quotaManager.getCustomersQuotasAndCounts();
    Map serversCountsAndQuotas = quotaManager.getServerQuotasAndCounts();

    response.addResult("CUSTOMERS_COUNT_AND_QUOTAS", (Serializable)customersCountsAndQuotas);
    response.addResult("SERVER_COUNT_AND_QUOTAS", (Serializable)serversCountsAndQuotas);
  }

  public void updateWithResponse(CmdbResponse response) {
    super.updateWithResponse(response);
    setCustomerQuotasAndCounts((Map)response.getResult("CUSTOMERS_COUNT_AND_QUOTAS"));
    setServerQuotasAndCounts((Map)response.getResult("SERVER_COUNT_AND_QUOTAS"));
  }

  public Map<CmdbCustomerID, CustomerQuotasAndCounts> getQuotaAndCountInfo() {
    return this._customerQuotasAndCounts;
  }

  private void setCustomerQuotasAndCounts(Map<CmdbCustomerID, CustomerQuotasAndCounts> customerQuotasAndCounts) {
    this._customerQuotasAndCounts = customerQuotasAndCounts;
  }

  public Map<String, QuotaCount> getServerQuotasAndCounts() {
    return this._serverQuotasAndCounts;
  }

  private void setServerQuotasAndCounts(Map<String, QuotaCount> serverQuotasAndCounts) {
    this._serverQuotasAndCounts = serverQuotasAndCounts;
  }

  public String getServiceName() {
    if ((this.serviceName == null) || (this.serviceName.trim().length() == 0))
      return "Framework service";

    return this.serviceName;
  }
}