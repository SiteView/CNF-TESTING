package com.mercury.topaz.cmdb.shared.manage.operation.update;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface CmdbUpdate extends FrameworkOperation
{
}