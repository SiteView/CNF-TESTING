package com.mercury.topaz.cmdb.shared.manage.operation;

public abstract interface ProcessOperation
{
  public abstract String getServerName();

  public abstract String getProcessName();
}