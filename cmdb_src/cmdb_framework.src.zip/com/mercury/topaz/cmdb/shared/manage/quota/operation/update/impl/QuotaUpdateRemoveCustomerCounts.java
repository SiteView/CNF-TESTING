package com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class QuotaUpdateRemoveCustomerCounts extends AbstractUpdateQuotaOperationCmdb
{
  private CmdbCustomerID _cmdbCustomerID;

  public QuotaUpdateRemoveCustomerCounts(CmdbCustomerID cmdbCustomerID)
  {
    setCmdbCustomerID(cmdbCustomerID);
  }

  public String getOperationName() {
    return "quota update: remove customer counts";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public void quotaUpdateExecute(QuotaManager quotaManager, CmdbResponse response) throws CmdbException {
    quotaManager.removeCustomerCounts(getCmdbCustomerID());
  }

  private CmdbCustomerID getCmdbCustomerID() {
    return this._cmdbCustomerID;
  }

  private void setCmdbCustomerID(CmdbCustomerID cmdbCustomerID) {
    this._cmdbCustomerID = cmdbCustomerID;
  }
}