package com.mercury.topaz.cmdb.shared.manage;

import appilog.framework.shared.manage.MamResponse;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import java.rmi.Remote;
import java.rmi.RemoteException;

public abstract interface CmdbFacade extends Remote
{
  public abstract MamResponse handleRequest(CmdbRequest paramCmdbRequest)
    throws RemoteException, CmdbResponseException;

  public abstract byte[] handleBinaryRequest(byte[] paramArrayOfByte)
    throws RemoteException, CmdbResponseException;
}