package com.mercury.topaz.cmdb.shared.manage.impl;

import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.MamResponse;
import com.mercury.topaz.cmdb.shared.bean.CmdbBean;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;
import com.mercury.topaz.cmdb.shared.model.digest.impl.CmdbDigestFactory;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class CmdbResponseImpl extends CmdbBean
  implements MamResponse
{
  private String _id;
  private String _message;
  long _serverRunningTime;
  private Map<String, Serializable> _results;
  private CmdbContext _context;
  private transient FrameworkOperation _redirectOperation;

  public CmdbResponseImpl(String message, String id, CmdbContext context)
  {
    setId(id);
    setMessage(message);
    setContext(context);
  }

  public String toString()
  {
    return "ID: " + getID() + "\nMessage: " + getMessage();
  }

  public long getServerRunningTime()
  {
    return this._serverRunningTime;
  }

  public void setServerRunningTime(long serverRunningTime) {
    this._serverRunningTime = serverRunningTime;
  }

  public boolean hasResultKey(String resultKey) {
    return ((getResults() != null) && (getResults().containsKey(resultKey)));
  }

  public Object getResult(String resultKey) {
    if (!(hasResultKey(resultKey)))
      throw new IllegalArgumentException("Asking for result [resultKey=" + resultKey + "] " + "that doesn't exist in response");

    return getResults().get(resultKey);
  }

  public void addResult(String resultKey, Serializable resultObject) {
    if (getResults() == null) {
      setResults(new HashMap());
    }

    getResults().put(resultKey, resultObject);
  }

  public Iterable<String> iterator()
  {
    return this._results.keySet();
  }

  public String getID() {
    return this._id;
  }

  private void setId(String id) {
    this._id = id;
  }

  public String getMessage() {
    return this._message;
  }

  public void setMessage(String message) {
    this._message = message;
  }

  public CmdbDigest getDigest()
  {
    return CmdbDigestFactory.generateDigest(getID());
  }

  private Map<String, Serializable> getResults() {
    return this._results;
  }

  private void setResults(Map<String, Serializable> results) {
    this._results = results;
  }

  public MamContext getContext() {
    return ((MamContext)this._context);
  }

  private void setContext(CmdbContext context) {
    if (context == null)
      throw new IllegalArgumentException("Can't set null context");

    this._context = context;
  }

  public FrameworkOperation getRedirectedOperation() {
    return this._redirectOperation;
  }

  public boolean isRedirected() {
    return (getRedirectedOperation() != null);
  }

  public void redirectToOperation(FrameworkOperation operation) {
    this._redirectOperation = operation;
  }
}