package com.mercury.topaz.cmdb.shared.manage.quota.operation.query;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.QuotaOperation;

public abstract interface QuotaQueryOperation extends QuotaOperation
{
  public abstract void quotaQueryExecute(QuotaManager paramQuotaManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}