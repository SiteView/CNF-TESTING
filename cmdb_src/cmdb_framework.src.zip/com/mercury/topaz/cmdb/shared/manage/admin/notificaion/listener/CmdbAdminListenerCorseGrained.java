package com.mercury.topaz.cmdb.shared.manage.admin.notificaion.listener;

import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;

public abstract interface CmdbAdminListenerCorseGrained extends CmdbChangeListenerCorseGrained
{
}