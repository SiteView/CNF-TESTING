package com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.AbstractOpDestinationResolver;
import com.mercury.topaz.cmdb.shared.manage.operation.OpDestinationResolver;
import com.mercury.topaz.cmdb.shared.manage.operation.ServerAndCategoryOperation;
import com.mercury.topaz.cmdb.shared.manage.quota.config.QuotasConfig;

public class QuotaUpdateChangeServerQuota extends AbstractQuotaUpdateAddQuotaInfoCmdb
  implements ServerAndCategoryOperation
{
  private static Log _logger = LogFactory.getEasyLog(QuotaUpdateChangeServerQuota.class);
  private OpDestinationResolver destinationResolver;

  public QuotaUpdateChangeServerQuota(String serverQuotaName, int quota)
  {
    super(serverQuotaName, quota);
    this.destinationResolver = new AbstractOpDestinationResolver(this)
    {
      protected String doResolve() {
        return QuotasConfig.instance().getControllerServiceName(this.this$0.getQuotaName());
      }
    };
  }

  public String getOperationName() {
    return "quota update: change server quota";
  }

  public void quotaUpdateExecute(QuotaManager quotaManager, CmdbResponse response) throws CmdbException {
    quotaManager.changeServerQuota(getQuotaName(), getQuota());
    String logMessage = "quota is changed for server , quota name [" + getQuotaName() + "] , quota : " + getQuota();
    _logger.info(logMessage);
    CmdbLogFactory.getCMDBInfoLog().info(logMessage);
  }

  public void resolveServiceName() {
    this.destinationResolver.resolveServiceName();
  }

  public String getServiceName() {
    return this.destinationResolver.getServiceName();
  }

  public boolean needsResolving() {
    return this.destinationResolver.needsResolving();
  }
}