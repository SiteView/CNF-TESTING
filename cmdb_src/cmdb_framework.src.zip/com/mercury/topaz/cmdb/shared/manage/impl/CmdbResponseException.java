package com.mercury.topaz.cmdb.shared.manage.impl;

import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.MamResponse;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.io.Serializable;

public class CmdbResponseException extends CmdbException
  implements MamResponse
{
  private CmdbResponseImpl _response;

  public CmdbResponseException(String id)
  {
    setResponse(new CmdbResponseImpl("N/A", id, CmdbContext.EMPTY));
  }

  public CmdbResponseException(String message, String id) {
    super(message);
    setResponse(new CmdbResponseImpl(message, id, CmdbContext.EMPTY));
  }

  public CmdbResponseException(String message, Throwable cause, String id) {
    super(message, cause);
    setResponse(new CmdbResponseImpl(message, id, CmdbContext.EMPTY));
  }

  public CmdbResponseException(Throwable cause, String id) {
    super(cause);
    setResponse(new CmdbResponseImpl("N/A", id, CmdbContext.EMPTY));
  }

  public CmdbResponseException(Throwable cause, String id, ErrorCode errorCode) {
    super(cause, errorCode);
    setResponse(new CmdbResponseImpl("N/A", id, CmdbContext.EMPTY));
  }

  public CmdbResponseException(String message, Throwable cause, String id, ErrorCode errorCode) {
    super(message, cause, errorCode);
    setResponse(new CmdbResponseImpl(message, id, CmdbContext.EMPTY));
  }

  public String getID()
  {
    return getResponse().getID();
  }

  public void setMessage(String message) {
    getResponse().setMessage(message);
  }

  public long getServerRunningTime() {
    return getResponse().getServerRunningTime();
  }

  public void setServerRunningTime(long serverRunningTime) {
    getResponse().setServerRunningTime(serverRunningTime);
  }

  public Object getResult(String resultKey) {
    return getResponse().getResult(resultKey);
  }

  public void addResult(String resultKey, Serializable resultObject) {
    getResponse().addResult(resultKey, resultObject);
  }

  public Iterable<String> iterator() {
    return getResponse().iterator();
  }

  public MamContext getContext() {
    return getResponse().getContext();
  }

  public boolean hasResultKey(String resultKey) {
    return getResponse().hasResultKey(resultKey);
  }

  public FrameworkOperation getRedirectedOperation() {
    return null;
  }

  public boolean isRedirected() {
    return false;
  }

  public void redirectToOperation(FrameworkOperation operation)
  {
  }

  private CmdbResponseImpl getResponse()
  {
    return this._response;
  }

  private void setResponse(CmdbResponseImpl response) {
    this._response = response;
  }
}