package com.mercury.topaz.cmdb.shared.manage.monitor.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.monitor.ServerMonitorManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.monitor.operation.impl.AbstractServerMonitorOperationCmdb;

public class ServerMonitorQueryGetCmdbStatus extends AbstractServerMonitorOperationCmdb
{
  private final boolean formatted;

  public ServerMonitorQueryGetCmdbStatus()
  {
    this(null, null, false);
  }

  public ServerMonitorQueryGetCmdbStatus(String hostName, String processName, boolean formatted) {
    super(hostName, processName);
    this.formatted = formatted;
  }

  public String getOperationName() {
    return "server monitor query: get framework status";
  }

  public void serverMonitorQueryExecute(ServerMonitorManager serverMonitorManager, CmdbResponse response) throws CmdbException
  {
    String status;
    if (this.formatted)
      status = serverMonitorManager.getFormattedServerStatus();
    else
      status = serverMonitorManager.getServerStatus();

    response.addResult("SERVER_MONITOR_INFO", status);
  }
}