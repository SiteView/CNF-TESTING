package com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.customer.id.impl.CmdbCustomerIDsFactory;

public class UpdateCustomerQuotaCounts extends AbstractUpdateQuotaOperationCmdb
{
  private CmdbCustomerID customerID;

  public UpdateCustomerQuotaCounts(CmdbCustomerID customerID)
  {
    this.customerID = customerID;
  }

  public String getOperationName() {
    return "Update quota counts for customer [" + this.customerID + "]";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public void quotaUpdateExecute(QuotaManager quotaManager, CmdbResponse response) throws CmdbException {
    CmdbCustomerIDs customerIDs = CmdbCustomerIDsFactory.createCustomerIDs();
    customerIDs.addCustomerID(this.customerID);
    QuotaUpdateUtil.updateCustomersQuotaCounts(quotaManager, customerIDs);
  }
}