package com.mercury.topaz.cmdb.shared.manage.quota.impl;

import com.mercury.topaz.cmdb.shared.manage.quota.CustomerQuotasAndCounts;
import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

class CustomerQuotasAndCountsImpl
  implements CustomerQuotasAndCounts
{
  private Map<String, QuotaCount> _quotas;

  public CustomerQuotasAndCountsImpl()
  {
    this(new HashMap());
  }

  private CustomerQuotasAndCountsImpl(Map<String, QuotaCount> quotasAndCounts) {
    setQuotas(quotasAndCounts);
  }

  public QuotaCount getQuotaCount(String quotaName) {
    return ((QuotaCount)getQuotas().get(quotaName));
  }

  public Set<String> getQuotaNames() {
    return getQuotas().keySet();
  }

  public void addQuotaAndCount(String name, QuotaCount quotaAndCount) {
    getQuotas().put(name, quotaAndCount);
  }

  public void addQuota(String quotaName, int quotaValue)
  {
    getQuotas().put(quotaName, QuotaFactory.createQuotaCount(quotaValue));
  }

  public void changeQuota(String quotaName, int quotaValue) {
    QuotaCount quotaCount = (QuotaCount)getQuotas().get(quotaName);
    if (quotaCount == null)
      throw new IllegalArgumentException("quota name doesn't exist");

    QuotaCount newQuotaCount = QuotaFactory.createQuotaCount(quotaValue);
    newQuotaCount.setCount(quotaCount.getCount());
    getQuotas().put(quotaName, newQuotaCount);
  }

  public void resetAllCounts() {
    Collection values = getQuotas().values();
    for (Iterator i$ = values.iterator(); i$.hasNext(); ) { QuotaCount quotaCount = (QuotaCount)i$.next();
      quotaCount.setCount(0);
    }
  }

  public boolean hasQuota(String fuseName) {
    return getQuotas().containsKey(fuseName);
  }

  public CustomerQuotasAndCounts getClone() {
    Map clonedCustomerQuotasAndCounts = new HashMap(getQuotas().size());
    Set quotaNames = getQuotaNames();
    for (Iterator i$ = quotaNames.iterator(); i$.hasNext(); ) { String quotaName = (String)i$.next();
      QuotaCount quotaCount = getQuotaCount(quotaName);
      QuotaCount clonedQuotaCount = quotaCount.getClone();
      clonedCustomerQuotasAndCounts.put(quotaName, clonedQuotaCount);
    }
    return new CustomerQuotasAndCountsImpl(clonedCustomerQuotasAndCounts);
  }

  private Map<String, QuotaCount> getQuotas() {
    return this._quotas;
  }

  private void setQuotas(Map<String, QuotaCount> quotas) {
    this._quotas = quotas;
  }
}