package com.mercury.topaz.cmdb.shared.manage.impl;

import appilog.framework.shared.manage.impl.MamResponseException;

public class CmdbCustomerNotExistException extends MamResponseException
{
  public CmdbCustomerNotExistException(String id)
  {
    super(id);
  }

  public CmdbCustomerNotExistException(String message, String id) {
    super(message, id);
  }

  public CmdbCustomerNotExistException(String message, Throwable cause, String id) {
    super(message, cause, id);
  }

  public CmdbCustomerNotExistException(Throwable cause, String id) {
    super(cause, id);
  }
}