package com.mercury.topaz.cmdb.shared.manage.operation.util;

import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface OperationExecutor
{
  public abstract void executeOperation(FrameworkOperation paramFrameworkOperation)
    throws CmdbResponseException;

  public abstract void executeAsynchronousOperation(FrameworkOperation paramFrameworkOperation)
    throws CmdbResponseException;
}