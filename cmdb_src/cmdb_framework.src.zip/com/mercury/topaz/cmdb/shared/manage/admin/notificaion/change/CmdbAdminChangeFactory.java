package com.mercury.topaz.cmdb.shared.manage.admin.notificaion.change;

import com.mercury.topaz.cmdb.shared.change.CmdbChange;

public class CmdbAdminChangeFactory
{
  public static CmdbChange createCustomerStartedChange()
  {
    return new CmdbCustomerStartedUpChange();
  }
}