package com.mercury.topaz.cmdb.shared.manage.monitor.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.monitor.ServerMonitorManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.monitor.operation.impl.AbstractServerMonitorOperationCmdb;

public class ExecuteRequestTimeoutCallbacks extends AbstractServerMonitorOperationCmdb
{
  public ExecuteRequestTimeoutCallbacks()
  {
    super(null, null);
  }

  public ExecuteRequestTimeoutCallbacks(String hostName, String processName) {
    super(hostName, processName);
  }

  public String getOperationName() {
    return toString();
  }

  public void serverMonitorQueryExecute(ServerMonitorManager serverMonitorManager, CmdbResponse response) throws CmdbException
  {
    serverMonitorManager.executeRequestTimeoutCallbacks();
    response.addResult("SERVER_MONITOR_INFO", "Success");
  }
}