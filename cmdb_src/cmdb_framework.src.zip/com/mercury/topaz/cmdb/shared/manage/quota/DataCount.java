package com.mercury.topaz.cmdb.shared.manage.quota;

import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public abstract interface DataCount
{
  public abstract CmdbCustomerID getCustomerID();

  public abstract String getQuotaName();

  public abstract int getNewCount();
}