package com.mercury.topaz.cmdb.shared.manage;

import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID.Factory;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import java.io.Serializable;

public abstract interface CmdbContext extends Serializable
{
  public static final MamContext EMPTY = new Empty();

  public abstract MamCustomerID getCustomerID();

  public abstract Changer getChanger();

  /**
   * @deprecated
   */
  public abstract String getUserID();

  public abstract int getUserId();

  public abstract String getCallerApplicationName();

  public abstract boolean isUserOperation();

  public static final class Empty
  implements MamContext
  {
    private static final CmdbCustomerID _customerID = CmdbCustomerID.Factory.createCMDBCustomerID(-10);

    public MamCustomerID getCustomerID()
    {
      return ((MamCustomerID)_customerID);
    }

    public String getUserID() {
      return "N/A";
    }

    public int getUserId() {
      return -1;
    }

    public String getCallerApplicationName() {
      return "N/A";
    }

    public boolean isUserOperation() {
      return false;
    }

    public void setUserOperation(boolean userOperation) {
    }

    public Changer getChanger() {
      return Changer.EMPTY_CHANGER;
    }
  }
}