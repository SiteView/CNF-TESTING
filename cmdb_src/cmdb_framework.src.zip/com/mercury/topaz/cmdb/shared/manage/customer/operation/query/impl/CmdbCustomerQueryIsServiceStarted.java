package com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.customer.CustomerQueryManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class CmdbCustomerQueryIsServiceStarted extends AbstractCustomerQueryCmdb
{
  private static final String IS_SERVICE_STARTED = "IS_SERVICE_STARTED_KEY";
  private boolean _isServiceStarted = false;
  private final CmdbCustomerID _customerID;
  private final String _controllerServiceName;

  public CmdbCustomerQueryIsServiceStarted(CmdbCustomerID customerID, String serviceName)
  {
    this._customerID = customerID;
    this._controllerServiceName = serviceName;
  }

  public String getOperationName() {
    return "Cmdb Customer query: is service [" + getControllerServiceName() + "] started";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public void customerQueryExecute(CustomerQueryManager cmdbCustomerManager, CmdbResponse response)
    throws CmdbException
  {
    boolean isServiceStarted = cmdbCustomerManager.isServiceStarted(getCustomerID(), getControllerServiceName());
    response.addResult("IS_SERVICE_STARTED_KEY", Boolean.valueOf(isServiceStarted));
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setServiceStarted(((Boolean)response.getResult("IS_SERVICE_STARTED_KEY")).booleanValue());
  }

  private CmdbCustomerID getCustomerID() {
    return this._customerID;
  }

  public String getControllerServiceName() {
    return this._controllerServiceName;
  }

  public boolean isServiceStarted() {
    return this._isServiceStarted;
  }

  private void setServiceStarted(boolean serviceStarted) {
    this._isServiceStarted = serviceStarted;
  }
}