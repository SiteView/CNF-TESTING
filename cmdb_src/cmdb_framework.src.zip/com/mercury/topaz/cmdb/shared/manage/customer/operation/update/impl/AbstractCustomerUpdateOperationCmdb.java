package com.mercury.topaz.cmdb.shared.manage.customer.operation.update.impl;

import com.mercury.topaz.cmdb.server.manage.customer.CustomerManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.impl.AbstractCustomerOperationCmdb;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.update.CmdbCustomerUpdate;

abstract class AbstractCustomerUpdateOperationCmdb extends AbstractCustomerOperationCmdb
  implements CmdbCustomerUpdate
{
  private CmdbCustomerID _customerID;

  public AbstractCustomerUpdateOperationCmdb(CmdbCustomerID customerID)
  {
    setCustomerID(customerID);
  }

  protected void doExecute(GlobalSubsystemManager manager, CmdbResponse response) throws CmdbException {
    customerUpdateExecute((CustomerManager)manager, response);
  }

  public String getExecutionTaskQueueName() {
    return "Customer Management Task";
  }

  protected CmdbCustomerID getCustomerID() {
    return this._customerID;
  }

  private void setCustomerID(CmdbCustomerID customerID) {
    if (customerID == null)
      throw new IllegalArgumentException("customer id is null !!!");

    this._customerID = customerID;
  }
}