package com.mercury.topaz.cmdb.shared.manage.impl;

import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Global;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.ChangerType;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;

public class CmdbContextFactory
{
  public static CmdbContext createCmdbContext(CmdbCustomerID customerID, int userID, String callerApplicationName)
  {
    return createCmdbContext(customerID, userID, callerApplicationName, ChangerFactory.createChanger(ChangerType.CALLER_APP, callerApplicationName));
  }

  public static CmdbContext createCmdbContext(CmdbCustomerID customerID, int userID, String callerApplicationName, boolean isUserOperation) {
    return new CmdbContextImpl(customerID, userID, ChangerFactory.createChanger(ChangerType.CALLER_APP, callerApplicationName), callerApplicationName, isUserOperation);
  }

  public static CmdbContext createCmdbContext(CmdbCustomerID customerID, int userID, String callerApplicationName, Changer changer) {
    return new CmdbContextImpl(customerID, userID, changer, callerApplicationName);
  }

  public static CmdbContext createCmdbContext(CmdbCustomerID customerID, String callerApplicationName) {
    return createCmdbContext(customerID, 911, callerApplicationName);
  }

  public static CmdbContext createDefaultCmdbContext(String callerApplicationName)
  {
    return new CmdbContextImpl(callerApplicationName);
  }

  public static CmdbContext createGlobalCmdbContext(int userID, String callerApplicationName)
  {
    return new CmdbContextImpl(FrameworkConstants.Customer.Global.ID, userID, callerApplicationName);
  }
}