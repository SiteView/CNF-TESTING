package com.mercury.topaz.cmdb.shared.manage.customer.operation.query;

import com.mercury.topaz.cmdb.server.manage.customer.CustomerQueryManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;

public abstract interface CmdbCustomerQuery extends CmdbQuery
{
  public abstract void customerQueryExecute(CustomerQueryManager paramCustomerQueryManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}