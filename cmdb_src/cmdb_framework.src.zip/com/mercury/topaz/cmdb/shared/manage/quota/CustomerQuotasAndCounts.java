package com.mercury.topaz.cmdb.shared.manage.quota;

import java.io.Serializable;
import java.util.Set;

public abstract interface CustomerQuotasAndCounts extends Serializable
{
  public abstract QuotaCount getQuotaCount(String paramString);

  public abstract void addQuotaAndCount(String paramString, QuotaCount paramQuotaCount);

  public abstract void addQuota(String paramString, int paramInt);

  public abstract void changeQuota(String paramString, int paramInt);

  public abstract boolean hasQuota(String paramString);

  public abstract void resetAllCounts();

  public abstract Set<String> getQuotaNames();

  public abstract CustomerQuotasAndCounts getClone();
}