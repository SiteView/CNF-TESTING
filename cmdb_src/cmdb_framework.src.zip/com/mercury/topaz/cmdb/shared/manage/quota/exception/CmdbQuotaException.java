package com.mercury.topaz.cmdb.shared.manage.quota.exception;

import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;

public class CmdbQuotaException extends CmdbException
{
  public CmdbQuotaException(String message)
  {
    super(message);
  }

  public CmdbQuotaException(String message, ErrorCode errorCode) {
    super(message, errorCode);
  }

  public CmdbQuotaException(String message, Throwable cause) {
    super(message, cause);
  }

  public CmdbQuotaException(String message, Throwable cause, ErrorCode errorCode) {
    super(message, cause, errorCode);
  }

  public CmdbQuotaException(Throwable cause) {
    super(cause);
  }

  public CmdbQuotaException(Throwable cause, ErrorCode errorCode) {
    super(cause, errorCode);
  }
}