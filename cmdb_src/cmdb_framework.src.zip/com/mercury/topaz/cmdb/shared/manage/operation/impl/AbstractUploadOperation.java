package com.mercury.topaz.cmdb.shared.manage.operation.impl;

import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

public abstract class AbstractUploadOperation<CONTEXT extends Serializable> extends AbstractCommonOperation
  implements CmdbQuery
{
  private static final int CHUNK_SIZE = 1048576;
  private static final String CONTEXT_KEY = "Context";
  private transient File clientFile = null;
  private transient InputStream uploadStream;
  private transient CommonManager manager;
  private Mode mode;
  private CONTEXT uploadContext;
  private byte[] chunk;
  private int validBytes;

  protected AbstractUploadOperation(File clientFile)
  {
    this.clientFile = clientFile;
  }

  protected AbstractUploadOperation(InputStream uploadStream) {
    this.uploadStream = uploadStream;
  }

  public final InputStream openUploadStream() throws FileNotFoundException {
    if (this.uploadStream == null)
      this.uploadStream = new BufferedInputStream(new FileInputStream(this.clientFile));

    return this.uploadStream;
  }

  public final void closeUploadStream() {
    if (this.clientFile != null)
      try {
        this.uploadStream.close();
        this.uploadStream = null;
      }
      catch (IOException e)
      {
      }
  }

  public final void setMode(Mode mode) {
    this.mode = mode;
  }

  public final void setNextChunk(byte[] chunk, int validBytes) {
    this.chunk = chunk;
    this.validBytes = validBytes;
  }

  public final File getClientFile() {
    return this.clientFile;
  }

  public int getChunkSize()
  {
    return 1048576;
  }

  public final void setUploadContext(CONTEXT context) {
    this.uploadContext = context;
  }

  public final CONTEXT getUploadContext() {
    return this.uploadContext;
  }

  protected final CommonManager getManager()
  {
    return this.manager;
  }

  protected final void commonExecute(CommonManager manager, CmdbResponse response) throws CmdbException {
    this.manager = manager;
    try {
      switch (1.$SwitchMap$com$mercury$topaz$cmdb$shared$manage$operation$impl$AbstractUploadOperation$Mode[this.mode.ordinal()])
      {
      case 1:
        startUpload();
        break;
      case 2:
        handleChunk(this.chunk, this.validBytes);
        break;
      case 3:
        finishUpload();
      }

      if (this.uploadContext != null)
        response.addResult("Context", this.uploadContext);
    }
    catch (IOException e) {
      throw new CmdbException(e);
    }
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    if (response.hasResultKey("Context"))
    {
      this.uploadContext = ((Serializable)response.getResult("Context"));
    }
  }

  protected void startUpload() throws IOException
  {
  }

  protected abstract void handleChunk(byte[] paramArrayOfByte, int paramInt) throws IOException;

  protected void finishUpload() throws IOException
  {
  }

  public static enum Mode
  {
    START, CHUNK, FINISH;

    public static final Mode[] values() {
      return ((Mode[])$VALUES.clone());
    }
  }
}