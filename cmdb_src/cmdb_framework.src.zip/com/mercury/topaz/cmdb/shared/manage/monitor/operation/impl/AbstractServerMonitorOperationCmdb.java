package com.mercury.topaz.cmdb.shared.manage.monitor.operation.impl;

import com.mercury.topaz.cmdb.server.manage.monitor.ServerMonitorManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.monitor.operation.ServerMonitorOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.ProcessOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractFrameworkGlobalOperation;

public abstract class AbstractServerMonitorOperationCmdb extends AbstractFrameworkGlobalOperation
  implements ServerMonitorOperation, ProcessOperation
{
  protected static final String SERVER_MONITOR_INFO = "SERVER_MONITOR_INFO";
  private String _serverMonitorInfo;
  protected String hostName;
  protected String processName;

  public AbstractServerMonitorOperationCmdb(String hostName, String processName)
  {
    this.hostName = hostName;
    this.processName = processName;
  }

  protected void doExecute(GlobalSubsystemManager manager, CmdbResponse response) throws CmdbException
  {
    serverMonitorQueryExecute((ServerMonitorManager)manager, response);
  }

  public String getExecutionTaskQueueName() {
    return "Server Monitor Task";
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    String serverMonitorInfo = (String)response.getResult("SERVER_MONITOR_INFO");
    setServerMonitorInfo(serverMonitorInfo);
  }

  public String getServerMonitorInfo() {
    return this._serverMonitorInfo;
  }

  private void setServerMonitorInfo(String serverMonitorInfo) {
    this._serverMonitorInfo = serverMonitorInfo;
  }

  public String getServerName() {
    return this.hostName;
  }

  public String getProcessName() {
    return this.processName;
  }

  public String getServiceName() {
    return "Framework service";
  }
}