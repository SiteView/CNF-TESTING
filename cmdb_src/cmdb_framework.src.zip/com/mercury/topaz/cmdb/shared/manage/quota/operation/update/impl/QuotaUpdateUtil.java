package com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.quota.DataCount;
import com.mercury.topaz.cmdb.shared.manage.quota.handler.QuotaCountHandler;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class QuotaUpdateUtil
{
  private static Log logger = LogFactory.getEasyLog(QuotaUpdateUtil.class);

  static void updateCustomersQuotaCounts(QuotaManager quotaManager, CmdbCustomerIDs customerIDs)
    throws CmdbException
  {
    ReadOnlyIterator customerIdsIterator = customerIDs.getCustomerIdsIterator();
    while (true) { List countHandlers;
      while (true) { if (!(customerIdsIterator.hasNext())) return;
        CmdbCustomerID customerID = (CmdbCustomerID)customerIdsIterator.next();
        countHandlers = quotaManager.getCountHandlers(customerID);

        if (countHandlers != null)
          break;
      }

      List allCountDatas = new ArrayList(customerIDs.size() * countHandlers.size());
      for (Iterator i$ = countHandlers.iterator(); i$.hasNext(); ) { QuotaCountHandler quotaCountHandler = (QuotaCountHandler)i$.next();
        List countDatas = quotaCountHandler.handle(customerIDs);
        allCountDatas.addAll(countDatas);
      }

      for (i$ = allCountDatas.iterator(); i$.hasNext(); ) { DataCount dataCount = (DataCount)i$.next();
        quotaManager.setCustomerCurrentCount(dataCount.getCustomerID(), dataCount.getQuotaName(), dataCount.getNewCount());

        if (logger.isDebugEnabled())
          logger.debug("customer id [" + dataCount.getCustomerID() + "] , quota name [" + dataCount.getQuotaName() + "] , new count set to : " + dataCount.getNewCount());
      }
    }
  }
}