package com.mercury.topaz.cmdb.shared.manage.customer.operation.update;

import com.mercury.topaz.cmdb.server.manage.customer.CustomerManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract interface CmdbCustomerUpdate
{
  public abstract void customerUpdateExecute(CustomerManager paramCustomerManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}