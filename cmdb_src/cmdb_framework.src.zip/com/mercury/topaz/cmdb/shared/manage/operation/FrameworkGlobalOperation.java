package com.mercury.topaz.cmdb.shared.manage.operation;

public abstract interface FrameworkGlobalOperation extends FrameworkOperation
{
}