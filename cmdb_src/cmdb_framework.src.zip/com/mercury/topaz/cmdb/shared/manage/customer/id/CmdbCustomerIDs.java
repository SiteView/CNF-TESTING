package com.mercury.topaz.cmdb.shared.manage.customer.id;

import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.Serializable;

public abstract interface CmdbCustomerIDs extends Serializable
{
  public abstract void addCustomerID(CmdbCustomerID paramCmdbCustomerID);

  public abstract boolean removeCustomer(CmdbCustomerID paramCmdbCustomerID);

  public abstract ReadOnlyIterator<CmdbCustomerID> getCustomerIdsIterator();

  public abstract boolean isEmpty();

  public abstract int size();

  public abstract boolean containsCustomer(CmdbCustomerID paramCmdbCustomerID);
}