package com.mercury.topaz.cmdb.shared.manage.quota.impl;

import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.quota.DataCount;

class DataCountImpl
  implements DataCount
{
  private CmdbCustomerID _customerID;
  private String _quotaName;
  private int _newCount;

  public DataCountImpl(CmdbCustomerID customerID, String quotaName, int newCount)
  {
    setCustomerID(customerID);
    setQuotaName(quotaName);
    setNewCount(newCount);
  }

  public CmdbCustomerID getCustomerID() {
    return this._customerID;
  }

  private void setCustomerID(CmdbCustomerID customerID) {
    this._customerID = customerID;
  }

  public String getQuotaName() {
    return this._quotaName;
  }

  private void setQuotaName(String quotaName) {
    this._quotaName = quotaName;
  }

  public int getNewCount() {
    return this._newCount;
  }

  private void setNewCount(int newCount) {
    this._newCount = newCount;
  }
}