package com.mercury.topaz.cmdb.shared.manage.operation;

public abstract interface OpDestinationResolver
{
  public abstract boolean needsResolving();

  public abstract void resolveServiceName();

  public abstract String getServiceName();
}