package com.mercury.topaz.cmdb.shared.manage.impl;

import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;

public class CmdbServiceNotAvailableException extends MamResponseException
{
  public CmdbServiceNotAvailableException(Throwable cause, String id)
  {
    super(cause, id, ErrorCode.SERVICE_NOT_AVAILABLE);
  }
}