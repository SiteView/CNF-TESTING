package com.mercury.topaz.cmdb.shared.manage.quota.impl;

import com.mercury.topaz.cmdb.shared.manage.quota.QuotaCount;

class QuotaCountImpl
  implements QuotaCount
{
  private int _count;
  private int _quota;

  public QuotaCountImpl(int quota)
  {
    setQuota(quota);
    setCount(0);
  }

  private QuotaCountImpl(int quota, int count) {
    setQuota(quota);
    setCount(count);
  }

  public int getCount() {
    return this._count;
  }

  public void setCount(int count) {
    this._count = count;
  }

  public int getQuota() {
    return this._quota;
  }

  public QuotaCount getClone() {
    return new QuotaCountImpl(getQuota(), getCount());
  }

  private void setQuota(int quota) {
    this._quota = quota;
  }
}