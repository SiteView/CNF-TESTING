package com.mercury.topaz.cmdb.shared.manage.impl;

import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Default;
import com.mercury.topaz.cmdb.shared.bean.CmdbBean;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.ChangerType;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;

public class CmdbContextImpl extends CmdbBean
  implements MamContext
{
  private CmdbCustomerID _customerID;
  private int _userId;
  private String _callerApplicationName;
  private static Log _logger = LogFactory.getEasyLog(CmdbContextImpl.class);
  private Changer changer;
  private boolean isUserOperation;

  public CmdbContextImpl(CmdbCustomerID customerID, int userID, String callerApplicationName)
  {
    this.isUserOperation = false;

    setCustomerID(customerID);
    setUserId(userID);
    setCallerApplicationName(callerApplicationName);
  }

  public CmdbContextImpl(CmdbCustomerID customerID, int userID, Changer changer, String callerApplicationName)
  {
    this.isUserOperation = false;

    setCustomerID(customerID);
    this.changer = changer;
    setCallerApplicationName(callerApplicationName);
    setUserId(userID);
  }

  public CmdbContextImpl(CmdbCustomerID customerID, int userID, Changer changer, String callerApplicationName, boolean isUserOperation)
  {
    this.isUserOperation = false;

    setCustomerID(customerID);
    this.changer = changer;
    setCallerApplicationName(callerApplicationName);
    setUserId(userID);
    this.isUserOperation = isUserOperation;
  }

  public CmdbContextImpl(String callerApplicationName)
  {
    this(FrameworkConstants.Customer.Default.ID, 1, callerApplicationName);
  }

  /**
   * @deprecated
   */
  public CmdbContextImpl(CmdbCustomerID customerID, String userID)
  {
    this(customerID, (userID == null) ? 0 : userID.hashCode(), "N/A");
  }

  public String toString()
  {
    return "CMDB Context: Customer id = '" + getCustomerID() + "' , User ID = '" + getUserId() + "' , Caller Application = '" + getCallerApplicationName() + "'";
  }

  public MamCustomerID getCustomerID()
  {
    return ((MamCustomerID)this._customerID);
  }

  /**
   * @deprecated
   */
  public String getUserID() {
    return Integer.toString(getUserId());
  }

  public int getUserId()
  {
    return this._userId;
  }

  private void setCustomerID(CmdbCustomerID customerID) {
    this._customerID = customerID;
  }

  public CmdbDigest getDigest() {
    throw new UnsupportedOperationException("wasn't implemented");
  }

  private void setUserId(int userId) {
    this._userId = userId;
  }

  public Changer getChanger() {
    if (this.changer == null)
      this.changer = ChangerFactory.createChanger(ChangerType.CALLER_APP, getCallerApplicationName());

    return this.changer;
  }

  public String getCallerApplicationName()
  {
    return this._callerApplicationName;
  }

  private void setCallerApplicationName(String callerApplicationName) {
    if (callerApplicationName == null) {
      Exception e = new IllegalArgumentException("caller application name is null");
      _logger.error("", e);
    }

    this._callerApplicationName = callerApplicationName;
  }

  public boolean isUserOperation() {
    return this.isUserOperation;
  }

  public void setUserOperation(boolean userOperation) {
    this.isUserOperation = userOperation;
  }
}