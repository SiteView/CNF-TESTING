package com.mercury.topaz.cmdb.shared.manage.operation.impl;

import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkGlobalOperation;

public abstract class AbstractFrameworkGlobalOperation extends AbstractCommonOperation
  implements FrameworkGlobalOperation
{
  protected void commonExecute(CommonManager manager, CmdbResponse response)
    throws CmdbException
  {
    doExecute((GlobalSubsystemManager)manager, response);
  }

  protected abstract void doExecute(GlobalSubsystemManager paramGlobalSubsystemManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}