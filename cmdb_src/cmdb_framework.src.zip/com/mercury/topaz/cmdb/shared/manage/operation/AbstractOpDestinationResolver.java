package com.mercury.topaz.cmdb.shared.manage.operation;

import java.io.Serializable;

public abstract class AbstractOpDestinationResolver
  implements OpDestinationResolver, Serializable
{
  private boolean needsResolving = true;
  private String serviceName;

  protected AbstractOpDestinationResolver()
  {
    this.serviceName = "CMDB";
  }

  public boolean needsResolving() {
    return this.needsResolving;
  }

  public void resolveServiceName() {
    this.serviceName = doResolve();
    this.needsResolving = false;
  }

  protected abstract String doResolve();

  public String getServiceName() {
    return this.serviceName;
  }
}