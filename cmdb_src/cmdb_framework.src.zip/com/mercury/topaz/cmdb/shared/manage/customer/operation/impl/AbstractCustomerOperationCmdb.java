package com.mercury.topaz.cmdb.shared.manage.customer.operation.impl;

import com.mercury.topaz.cmdb.shared.manage.customer.operation.CmdbCustomerOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractFrameworkGlobalOperation;

public abstract class AbstractCustomerOperationCmdb extends AbstractFrameworkGlobalOperation
  implements CmdbCustomerOperation
{
}