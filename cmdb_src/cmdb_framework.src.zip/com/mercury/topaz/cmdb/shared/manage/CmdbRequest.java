package com.mercury.topaz.cmdb.shared.manage;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface CmdbRequest extends CmdbRequestInfo
{
  public abstract FrameworkOperation getOperation();
}