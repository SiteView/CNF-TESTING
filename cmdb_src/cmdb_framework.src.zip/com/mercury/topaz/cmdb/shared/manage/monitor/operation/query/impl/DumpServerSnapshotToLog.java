package com.mercury.topaz.cmdb.shared.manage.monitor.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.monitor.ServerMonitorManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.monitor.operation.impl.AbstractServerMonitorOperationCmdb;

public class DumpServerSnapshotToLog extends AbstractServerMonitorOperationCmdb
{
  public DumpServerSnapshotToLog()
  {
    super(null, null);
  }

  public DumpServerSnapshotToLog(String hostName, String processName) {
    super(hostName, processName);
  }

  public String getOperationName() {
    return "Dump server snapshot to log";
  }

  public void serverMonitorQueryExecute(ServerMonitorManager serverMonitorManager, CmdbResponse response) throws CmdbException
  {
    response.addResult("SERVER_MONITOR_INFO", serverMonitorManager.dumpServerSnapshotToLog(getServerName(), getProcessName()));
  }
}