package com.mercury.topaz.cmdb.shared.manage.quota.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.impl.AbstractQuotaOperationCmdb;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.query.QuotaQueryOperation;

abstract class AbstractQuotaQueryOperationCmdb extends AbstractQuotaOperationCmdb
  implements QuotaQueryOperation
{
  protected final String CUSTOMERS_COUNT_AND_QUOTAS = "CUSTOMERS_COUNT_AND_QUOTAS";
  protected final String SERVER_COUNT_AND_QUOTAS = "SERVER_COUNT_AND_QUOTAS";

  AbstractQuotaQueryOperationCmdb()
  {
    this.CUSTOMERS_COUNT_AND_QUOTAS = "CUSTOMERS_COUNT_AND_QUOTAS";
    this.SERVER_COUNT_AND_QUOTAS = "SERVER_COUNT_AND_QUOTAS"; }

  protected void doExecute(GlobalSubsystemManager manager, CmdbResponse response) throws CmdbException {
    quotaQueryExecute((QuotaManager)manager, response);
  }
}