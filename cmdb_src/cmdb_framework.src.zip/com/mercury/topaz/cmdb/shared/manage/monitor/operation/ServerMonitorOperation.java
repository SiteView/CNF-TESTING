package com.mercury.topaz.cmdb.shared.manage.monitor.operation;

import com.mercury.topaz.cmdb.server.manage.monitor.ServerMonitorManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;

public abstract interface ServerMonitorOperation extends CmdbQuery
{
  public abstract void serverMonitorQueryExecute(ServerMonitorManager paramServerMonitorManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}