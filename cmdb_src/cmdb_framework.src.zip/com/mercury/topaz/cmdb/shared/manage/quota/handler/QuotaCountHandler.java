package com.mercury.topaz.cmdb.shared.manage.quota.handler;

import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.quota.DataCount;
import com.mercury.topaz.cmdb.shared.manage.quota.exception.CmdbQuotaException;
import java.util.List;

public abstract interface QuotaCountHandler
{
  public abstract String getCustomerQuotaName();

  public abstract String getServerQuotaName();

  public abstract List<DataCount> handle(CmdbCustomerIDs paramCmdbCustomerIDs);

  public abstract void checkQuota(CmdbRequest paramCmdbRequest)
    throws CmdbQuotaException;
}