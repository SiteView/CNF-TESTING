package com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.impl.AbstractQuotaOperationCmdb;
import com.mercury.topaz.cmdb.shared.manage.quota.operation.update.QuotaUpdateOperation;

abstract class AbstractUpdateQuotaOperationCmdb extends AbstractQuotaOperationCmdb
  implements QuotaUpdateOperation
{
  protected void doExecute(GlobalSubsystemManager manager, CmdbResponse response)
    throws CmdbException
  {
    quotaUpdateExecute((QuotaManager)manager, response);
  }
}