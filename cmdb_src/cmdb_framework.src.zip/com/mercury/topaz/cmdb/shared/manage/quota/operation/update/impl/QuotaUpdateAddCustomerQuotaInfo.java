package com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public class QuotaUpdateAddCustomerQuotaInfo extends AbstractQuotaUpdateAddQuotaInfoCmdb
{
  private static Log _logger = LogFactory.getEasyLog(QuotaUpdateAddCustomerQuotaInfo.class);
  private CmdbCustomerID _customerID;

  public QuotaUpdateAddCustomerQuotaInfo(CmdbCustomerID customerID, String quotaName, int quota)
  {
    super(quotaName, quota);
    setCustomerID(customerID);
  }

  public String getOperationName() {
    return "quota update: add customer quota info";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public void quotaUpdateExecute(QuotaManager quotaManager, CmdbResponse response) throws CmdbException {
    quotaManager.addCustomerQuotaInfo(getCustomerID(), getQuotaName(), getQuota());
    String logMessage = "quota is set for customer id [" + getCustomerID() + "] , quota name [" + getQuotaName() + "] , quota : " + getQuota();
    _logger.info(logMessage);
    CmdbLogFactory.getCMDBInfoLog().info(logMessage);
  }

  private CmdbCustomerID getCustomerID() {
    return this._customerID;
  }

  private void setCustomerID(CmdbCustomerID customerID) {
    this._customerID = customerID;
  }
}