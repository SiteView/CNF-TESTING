package com.mercury.topaz.cmdb.shared.manage.monitor.info;

import java.io.Serializable;
import java.util.List;

public abstract interface TaskMonitorInfo extends Serializable
{
  public abstract String getTaskName();

  public abstract int getQueueSize();

  public abstract List getThreadsInfo();
}