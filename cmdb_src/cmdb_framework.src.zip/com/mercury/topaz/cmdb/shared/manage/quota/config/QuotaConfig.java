package com.mercury.topaz.cmdb.shared.manage.quota.config;

import com.mercury.topaz.cmdb.shared.manage.quota.handler.QuotaCountHandler;

public class QuotaConfig
{
  private String controllerServiceName;
  private QuotaCountHandler quotaHandler;

  public String getControllerServiceName()
  {
    return this.controllerServiceName;
  }

  public void setControllerServiceName(String controllerServiceName) {
    this.controllerServiceName = controllerServiceName;
  }

  public void setQuotaHandler(QuotaCountHandler quotaHandler) {
    this.quotaHandler = quotaHandler;
  }

  public QuotaCountHandler getQuotaHandler() {
    return this.quotaHandler;
  }
}