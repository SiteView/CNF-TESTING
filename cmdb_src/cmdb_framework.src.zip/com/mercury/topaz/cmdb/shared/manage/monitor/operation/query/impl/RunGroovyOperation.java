package com.mercury.topaz.cmdb.shared.manage.monitor.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.monitor.ServerMonitorManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.monitor.operation.impl.AbstractServerMonitorOperationCmdb;
import com.mercury.topaz.cmdb.shared.util.GroovyUtil;

public class RunGroovyOperation extends AbstractServerMonitorOperationCmdb
{
  private String code;

  public RunGroovyOperation(String code, String hostName, String processName)
  {
    super(hostName, processName);
    this.code = code;
  }

  public String getOperationName() {
    return "Run Groovy Code";
  }

  public void serverMonitorQueryExecute(ServerMonitorManager serverMonitorManager, CmdbResponse response) throws CmdbException {
    response.addResult("SERVER_MONITOR_INFO", String.valueOf(GroovyUtil.runGroovy(this.code)));
  }
}