package com.mercury.topaz.cmdb.shared.manage.customer.operation;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkGlobalOperation;

public abstract interface CmdbCustomerOperation extends FrameworkGlobalOperation
{
}