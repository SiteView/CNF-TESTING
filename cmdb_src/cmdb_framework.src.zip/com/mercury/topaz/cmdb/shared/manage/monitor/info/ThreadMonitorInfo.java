package com.mercury.topaz.cmdb.shared.manage.monitor.info;

import java.io.Serializable;

public abstract interface ThreadMonitorInfo extends Serializable
{
  public abstract String getThreadName();

  public abstract boolean isExecutingRequest();

  public abstract CmdbRequestMonitorInfo getExecutedRequestMonitorInfo();
}