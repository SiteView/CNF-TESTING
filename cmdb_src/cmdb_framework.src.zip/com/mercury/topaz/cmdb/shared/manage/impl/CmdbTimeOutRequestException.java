package com.mercury.topaz.cmdb.shared.manage.impl;

import appilog.framework.shared.manage.impl.MamResponseException;

public class CmdbTimeOutRequestException extends MamResponseException
{
  public CmdbTimeOutRequestException(String id)
  {
    super(id);
  }

  public CmdbTimeOutRequestException(String message, String id) {
    super(message, id);
  }

  public CmdbTimeOutRequestException(String message, Throwable cause, String id) {
    super(message, cause, id);
  }

  public CmdbTimeOutRequestException(Throwable cause, String id) {
    super(cause, id);
  }
}