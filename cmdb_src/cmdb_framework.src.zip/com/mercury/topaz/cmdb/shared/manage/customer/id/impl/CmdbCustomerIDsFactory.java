package com.mercury.topaz.cmdb.shared.manage.customer.id.impl;

import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;

public class CmdbCustomerIDsFactory
{
  public static CmdbCustomerIDs createCustomerIDs()
  {
    return new CmdbCustomerIDsImpl();
  }
}