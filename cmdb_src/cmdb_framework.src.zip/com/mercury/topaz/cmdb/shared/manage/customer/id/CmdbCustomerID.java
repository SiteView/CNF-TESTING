package com.mercury.topaz.cmdb.shared.manage.customer.id;

import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.topaz.cmdb.shared.bean.factory.CmdbImmutableBeanFactory;

public abstract interface CmdbCustomerID
{
  public static final Factory Factory = new Factory();

  public abstract int getID();

  public abstract String getIDName();

  public static class Factory extends CmdbImmutableBeanFactory<CmdbCustomerIDImpl>
  {
    public CmdbCustomerID createCMDBCustomerID(int customerID)
    {
      return createMamCustomerID(customerID);
    }

    public CmdbCustomerID createCMDBCustomerID(int customerID, String customerName)
    {
      return new CmdbCustomerIDImpl(customerID, customerName);
    }

    public MamCustomerID createMamCustomerID(int customerID) {
      return ((MamCustomerID)obtainObject(new CmdbCustomerIDImpl(customerID)));
    }

    public CmdbCustomerID convert(MamCustomerID mamID)
    {
      return mamID;
    }

    public MamCustomerID convert(CmdbCustomerID cmdbID)
    {
      return ((MamCustomerID)cmdbID);
    }
  }
}