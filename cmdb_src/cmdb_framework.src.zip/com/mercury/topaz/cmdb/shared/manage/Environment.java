package com.mercury.topaz.cmdb.shared.manage;

public class Environment
{
  public static final boolean TEST_MODE = System.getProperty("testMode") != null;
  public static final boolean DISABLE_JMS = (TEST_MODE) || (System.getProperty("disableJMS") != null);
  public static final boolean USE_JMS = !(DISABLE_JMS);
  public static final boolean DISABLE_CONTROLLER = (TEST_MODE) || ("no".equals(System.getProperty("cmdbIsControlled")));
  public static final boolean USE_CONTROLLER = !(DISABLE_CONTROLLER);
}