package com.mercury.topaz.cmdb.shared.manage.quota;

import java.io.Serializable;

public abstract interface QuotaCount extends Serializable
{
  public abstract int getCount();

  public abstract void setCount(int paramInt);

  public abstract int getQuota();

  public abstract QuotaCount getClone();
}