package com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class QuotaUpdateAddServerQuotaInfo extends AbstractQuotaUpdateAddQuotaInfoCmdb
{
  private static Log _logger = LogFactory.getEasyLog(QuotaUpdateAddServerQuotaInfo.class);
  private String _relatedCustomerQuotaName;

  public QuotaUpdateAddServerQuotaInfo(String serverQuotaName, int quota, String relatedCustomerQuoataName)
  {
    super(serverQuotaName, quota);
    setRelatedCustomerQuotaName(relatedCustomerQuoataName);
  }

  public String getOperationName() {
    return "quota update: add server quota info";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public void quotaUpdateExecute(QuotaManager quotaManager, CmdbResponse response) throws CmdbException {
    quotaManager.addServerQuotaInfo(getQuotaName(), getQuota(), getRelatedCustomerQuotaName());
    String logMessage = "quota is set for server , quota name [" + getQuotaName() + "] , quota : " + getQuota() + " related customer quota name [" + getRelatedCustomerQuotaName() + "]";
    _logger.info(logMessage);
    CmdbLogFactory.getCMDBInfoLog().info(logMessage);
  }

  private String getRelatedCustomerQuotaName()
  {
    return this._relatedCustomerQuotaName;
  }

  private void setRelatedCustomerQuotaName(String relatedCustomerQuotaName) {
    this._relatedCustomerQuotaName = relatedCustomerQuotaName;
  }
}