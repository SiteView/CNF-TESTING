package com.mercury.topaz.cmdb.shared.manage.customer.id.impl;

import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.EmptyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.util.ArrayList;
import java.util.Collection;

class CmdbCustomerIDsImpl extends ArrayList<CmdbCustomerID>
  implements CmdbCustomerIDs
{
  public void addCustomerID(CmdbCustomerID customerID)
  {
    if (customerID == null)
      throw new IllegalArgumentException("cannot add null customer id !!!");

    if (!(contains(customerID)))
      add(customerID);
  }

  public boolean removeCustomer(CmdbCustomerID customerID)
  {
    return remove(customerID);
  }

  public ReadOnlyIterator<CmdbCustomerID> getCustomerIdsIterator() {
    if (isEmpty()) {
      return EmptyIterator.getInstance();
    }

    return new ReadOnlyIteratorImpl(iterator());
  }

  public boolean containsCustomer(CmdbCustomerID customerID) {
    return contains(customerID); }

  public boolean equals(Object o) {
    if (!(o instanceof Collection))
      return false;

    Collection collection = (Collection)o;

    if (size() != collection.size()) {
      return false;
    }

    return containsAll(collection);
  }

  public int hashCode() {
    return size();
  }
}