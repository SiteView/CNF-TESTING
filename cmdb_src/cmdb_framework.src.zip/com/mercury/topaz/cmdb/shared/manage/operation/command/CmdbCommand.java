package com.mercury.topaz.cmdb.shared.manage.operation.command;

import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public abstract interface CmdbCommand extends FrameworkOperation
{
}