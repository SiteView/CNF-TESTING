package com.mercury.topaz.cmdb.shared.manage.impl;

import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.model.id.impl.AbstractIDFactory;

public class CmdbReqestImpl extends CmdbRequestInfoImpl
  implements CmdbRequest
{
  private FrameworkOperation _operation;

  public CmdbReqestImpl(CmdbContext context, FrameworkOperation operation)
  {
    this("N/A", context, operation);
  }

  public CmdbReqestImpl(String message, CmdbContext context, FrameworkOperation operation)
  {
    this(message, context, operation, true);
  }

  public CmdbReqestImpl(String message, CmdbContext context, FrameworkOperation operation, boolean isSynchronic)
  {
    super(message, context, AbstractIDFactory.createRandomStringID(), isSynchronic);
    setOperation(operation);
  }

  public String toString()
  {
    return "{request: ID='" + getID() + "' " + "Message='" + getMessage() + "' " + "Operation='" + getOperation() + "' " + "Customer ID='" + getCustomerID() + "' " + "\n" + "Context='" + getContext() + "'}";
  }

  public FrameworkOperation getOperation()
  {
    return this._operation;
  }

  private void setOperation(FrameworkOperation operation) {
    if (operation == null)
      throw new IllegalArgumentException("Attempt to set 'null' operation to request");

    this._operation = operation;
  }

  public String getOperationName()
  {
    return getOperation().getOperationName();
  }
}