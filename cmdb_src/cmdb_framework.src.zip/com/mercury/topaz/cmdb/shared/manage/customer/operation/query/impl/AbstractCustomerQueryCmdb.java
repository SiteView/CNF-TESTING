package com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl;

import com.mercury.topaz.cmdb.server.manage.customer.CustomerQueryManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.impl.AbstractCustomerOperationCmdb;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.query.CmdbCustomerQuery;

public abstract class AbstractCustomerQueryCmdb extends AbstractCustomerOperationCmdb
  implements CmdbCustomerQuery
{
  protected void doExecute(GlobalSubsystemManager manager, CmdbResponse response)
    throws CmdbException
  {
    customerQueryExecute((CustomerQueryManager)manager, response);
  }

  public String getExecutionTaskQueueName() {
    return "Customer Query Management Task";
  }
}