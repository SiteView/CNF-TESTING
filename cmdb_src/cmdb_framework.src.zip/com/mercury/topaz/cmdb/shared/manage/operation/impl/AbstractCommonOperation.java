package com.mercury.topaz.cmdb.shared.manage.operation.impl;

import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.bean.CmdbBean;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbContextRepository;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.OperationStack;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;
import com.mercury.topaz.cmdb.shared.manage.operation.update.CmdbUpdate;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;

public abstract class AbstractCommonOperation extends CmdbBean
  implements FrameworkOperation
{
  private static Log _operationLogger = CmdbLogFactory.getOperationLog();
  private static Log _shortAuditLogger = CmdbLogFactory.getShortAuditLog();
  private static Log _detailedAuditLogger = CmdbLogFactory.getDetailedAuditLog();
  private long onAcquiringLockTimeStamp;
  private long onLockAcquiredTimeStamp;
  private Integer id;

  public final void execute(CommonManager manager, CmdbResponse response)
    throws CmdbResponseException
  {
    if (manager == null)
      throw new IllegalArgumentException("SubsystemManager is null !!!");

    if (response == null) {
      throw new IllegalArgumentException("response is null !!!");
    }

    String operationName = getOperationName();
    long start = System.nanoTime();
    OperationStack.pushID(getID());
    try
    {
      if ((getOperationLogger().isDebugEnabled()) && (!(isPeriodicOperation()))) {
        getOperationLogger().debug(getTabShift() + "--> [" + getStackTraceForLog() + "] " + operationName + "(" + getAdditionalLogMessage() + ")" + "  for customer [" + getCustomerID() + "] , caller application [" + getCallerApplication() + "]");
      }

      commonExecute(manager, response);
      if (response.isRedirected()) {
        if ((getOperationLogger().isDebugEnabled()) && (!(isPeriodicOperation()))) {
          FrameworkOperation redirectOperation = response.getRedirectedOperation();
          long elapsedTime = System.nanoTime() - start;
          getOperationLogger().debug(getTabShift() + "<-- [" + getStackTraceForLog() + "] " + operationName + "(" + getAdditionalLogMessage() + ")" + "\tID:\t" + getID() + "\tshould be redirected to another operation [" + redirectOperation.getOperationName() + "] (" + getTimesDesc(elapsedTime) + " ), customer [" + getCustomerID() + "] , caller application [" + getCallerApplication() + "]");
        }
      }
      else
      {
        updateWithResponse(response);
        long elapsedTime = System.nanoTime() - start;
        if ((getOperationLogger().isDebugEnabled()) && (!(isPeriodicOperation()))) {
          getOperationLogger().debug(getTabShift() + "<-- " + getTimesDesc(elapsedTime) + " [" + getStackTraceForLog() + "] " + operationName + "(" + getAdditionalLogMessage() + ")");
        }

        logAuditMessage(response.getContext().getCallerApplicationName(), response.getContext().getCustomerID(), elapsedTime, start);
      }

    }
    catch (CmdbException e)
    {
      throw new MamResponseException("CMDB Operation Internal Error: " + e.getClass() + " : " + e.getMessage() + " : operation " + operationName, e, response.getID(), e.getError());
    }
    catch (Exception e)
    {
      throw new MamResponseException("CMDB Operation Internal Error: " + e.getClass() + " : " + e.getMessage() + " : operation " + operationName, e, response.getID());
    }
    finally {
      OperationStack.pop();
    }
  }

  private void logError(String operationName, long start, Exception e, CmdbResponse response) {
    long elapsedTime = System.nanoTime() - start;
    getOperationLogger().error("\t!!!\tOperation\t" + operationName + "\tID:\t" + getID() + "\tFAILED (running time:\t" + getTimesDesc(elapsedTime) + "[ms])", e);

    logAuditMessage("!!! FAIL to: ", response.getContext().getCallerApplicationName(), response.getContext().getCustomerID(), elapsedTime, start);
  }

  private String getTimesDesc(long runningTime)
  {
    StringBuffer timesDesc = new StringBuffer();
    runningTime /= 1000000L;
    timesDesc.append(runningTime).append(" ms");

    long lockTime = getLockTime() / 1000000L;
    if (lockTime > 0L)
      timesDesc.append(" (").append(lockTime).append(" ms waiting for lock)");

    return timesDesc.toString();
  }

  public boolean isPeriodicOperation()
  {
    return false;
  }

  protected abstract void commonExecute(CommonManager paramCommonManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;

  protected void logAuditMessage(String callerApplicationName, CmdbCustomerID customerID, long runningTime, long startTime)
  {
    logAuditMessage("", callerApplicationName, customerID, runningTime, startTime);
  }

  protected void logAuditMessage(CmdbCustomerID customerID, long runningTime, long startTime) {
    logAuditMessage("", "CMDB Internal", customerID, runningTime, startTime);
  }

  public String getShortAuditMessage()
  {
    return "Short audit message wasn't implemented for operation: " + getClass().getName();
  }

  public String getDetailedAuditMessage()
  {
    return "Detailed audit message wasn't implemented for operation: " + getClass().getName();
  }

  public String getMessageIncludingParameters()
  {
    return getShortAuditMessage();
  }

  public int getID() {
    if (this.id == null)
      createID();

    return this.id.intValue();
  }

  private void createID() {
    this.id = Integer.valueOf(System.identityHashCode(this));
  }

  protected void logAuditMessage(String messagePrefix, String callerApplicationName, CmdbCustomerID customerID, long runningTime, long startTime)
  {
    if (this instanceof CmdbUpdate) {
      String timesDesc;
      if (getshortAuditLogger().isInfoEnabled()) {
        timesDesc = getTimesDesc(runningTime);
        getshortAuditLogger().info("[ID=" + getID() + "] " + "[Caller Name=" + callerApplicationName + "] " + "[Customer ID=" + customerID + "] " + messagePrefix + getShortAuditMessage() + "[Times=" + timesDesc + "] ");
      }

      if (getdetailedAuditLogger().isDebugEnabled()) {
        timesDesc = getTimesDesc(runningTime);
        getdetailedAuditLogger().debug("[ID=" + getID() + "] " + "[Caller Name=" + callerApplicationName + "] " + "[Customer ID=" + customerID + "] " + messagePrefix + getDetailedAuditMessage() + "[Times=" + timesDesc + "] ");
      }
    }
  }

  public void updateWithResponse(CmdbResponse response)
  {
    if (this instanceof CmdbQuery)
      ((CmdbQuery)this).updateQueryWithResponse(response);
  }

  protected Log getOperationLogger()
  {
    return _operationLogger;
  }

  protected Log getshortAuditLogger() {
    return _shortAuditLogger;
  }

  protected Log getdetailedAuditLogger() {
    return _detailedAuditLogger;
  }

  public CmdbDigest getDigest() {
    throw new UnsupportedOperationException("wasn't implemented");
  }

  public final void onAcquiringLock() {
    this.onAcquiringLockTimeStamp = System.nanoTime();
  }

  public final void onLockAcquired() {
    this.onLockAcquiredTimeStamp = System.nanoTime();
  }

  protected final void redirectOperation(CmdbResponse response, FrameworkOperation frameworkOperation) {
    if (frameworkOperation == null)
      throw new IllegalArgumentException("framework operation for redirection is null !!!");

    response.redirectToOperation(frameworkOperation);
  }

  public String getAdditionalLogMessage() {
    return "";
  }

  private int getNestingLevel() {
    return OperationStack.getDepth();
  }

  private CmdbCustomerID getCustomerID() {
    return getContext().getCustomerID();
  }

  private String getCallerApplication() {
    return getContext().getCallerApplicationName();
  }

  private CmdbContext getContext() {
    return CmdbContextRepository.get();
  }

  private long getLockTime() {
    return (this.onLockAcquiredTimeStamp - this.onAcquiringLockTimeStamp);
  }

  private String getTabShift() {
    String tabShift = "";
    for (int i = 1; i < getNestingLevel(); ++i)
      tabShift = tabShift + "  ";

    return tabShift;
  }

  private String getStackTraceForLog() {
    return OperationStack.lastTwoEntriesAsString();
  }
}