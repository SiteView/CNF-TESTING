package com.mercury.topaz.cmdb.shared.manage.operation.impl;

import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractFrameworkOperation extends AbstractCommonOperation
{
  protected final void commonExecute(CommonManager manager, CmdbResponse response)
    throws CmdbException
  {
    doExecute((SubsystemManager)manager, response);
  }

  protected abstract void doExecute(SubsystemManager paramSubsystemManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}