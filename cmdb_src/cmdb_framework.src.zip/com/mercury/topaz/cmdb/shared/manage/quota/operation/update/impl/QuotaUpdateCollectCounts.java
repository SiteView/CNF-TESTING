package com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl;

import com.mercury.topaz.cmdb.server.manage.quota.QuotaManager;
import com.mercury.topaz.cmdb.server.manage.subsystem.GlobalSubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerIDs;
import com.mercury.topaz.cmdb.shared.manage.customer.operation.query.impl.CmdbCustomerQueryGetLoadedCustomerIDs;

public class QuotaUpdateCollectCounts extends AbstractUpdateQuotaOperationCmdb
{
  private static String _serviceName;

  public QuotaUpdateCollectCounts(String serviceName)
  {
    _serviceName = serviceName;
  }

  public QuotaUpdateCollectCounts() {
    this(null);
  }

  public String getOperationName() {
    return "quota update: collect counts";
  }

  public String getServiceName() {
    return "Framework service";
  }

  public void quotaUpdateExecute(QuotaManager quotaManager, CmdbResponse response) throws CmdbException {
    quotaManager.resetAllCounts();
    QuotaUpdateUtil.updateCustomersQuotaCounts(quotaManager, getLoadedCustomerIDs(quotaManager));
  }

  private CmdbCustomerIDs getLoadedCustomerIDs(GlobalSubsystemManager manager)
  {
    CmdbCustomerQueryGetLoadedCustomerIDs getLoadedCustomerIDs;
    if ((_serviceName == null) || (_serviceName.trim().length() == 0))
      getLoadedCustomerIDs = new CmdbCustomerQueryGetLoadedCustomerIDs();
    else {
      getLoadedCustomerIDs = new CmdbCustomerQueryGetLoadedCustomerIDs(_serviceName, false);
    }

    manager.executeGlobalOperation(getLoadedCustomerIDs);
    return getLoadedCustomerIDs.getCustomerIDs();
  }
}