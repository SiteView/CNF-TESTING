package com.mercury.topaz.cmdb.shared.manage.quota.operation.update.impl;

abstract class AbstractQuotaUpdateAddQuotaInfoCmdb extends AbstractUpdateQuotaOperationCmdb
{
  private String _quotaName;
  private int _quota;

  public AbstractQuotaUpdateAddQuotaInfoCmdb(String serverQuotaName, int quota)
  {
    setQuotaName(serverQuotaName);
    setQuota(quota);
  }

  protected String getQuotaName()
  {
    return this._quotaName;
  }

  private void setQuotaName(String quotaName) {
    this._quotaName = quotaName;
  }

  protected int getQuota() {
    return this._quota;
  }

  private void setQuota(int quota) {
    if (quota < 0)
      throw new IllegalArgumentException("quota cannot be negative !!!");

    this._quota = quota;
  }
}