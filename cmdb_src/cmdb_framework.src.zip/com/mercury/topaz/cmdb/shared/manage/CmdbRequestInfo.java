package com.mercury.topaz.cmdb.shared.manage;

import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public abstract interface CmdbRequestInfo extends CmdbContextHolder
{
  public abstract String getID();

  public abstract String getMessage();

  public abstract CmdbCustomerID getCustomerID();

  public abstract boolean isSynchronic();

  public abstract String getOperationName();
}