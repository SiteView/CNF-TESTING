package com.mercury.topaz.cmdb.shared.manage.operation.util;

import com.mercury.topaz.cmdb.server.manage.ServerApiFacade;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;

public class ServerApiExecutor
  implements OperationExecutor
{
  public void executeAsynchronousOperation(FrameworkOperation operation)
    throws CmdbResponseException
  {
    ServerApiFacade.executeOperationAsynchronously(operation);
  }

  public void executeOperation(FrameworkOperation operation) throws CmdbResponseException {
    ServerApiFacade.executeOperation(operation);
  }
}