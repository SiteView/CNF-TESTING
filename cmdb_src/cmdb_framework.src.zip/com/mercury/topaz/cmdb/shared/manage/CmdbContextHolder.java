package com.mercury.topaz.cmdb.shared.manage;

public abstract interface CmdbContextHolder
{
  public abstract CmdbContext getContext();
}