package com.mercury.topaz.cmdb.shared.manage;

import java.util.EmptyStackException;
import java.util.Stack;

public class CmdbContextRepository
{
  private static ThreadLocal<Stack<CmdbContext>> repository = new ThreadLocal() {
    protected Stack<CmdbContext> initialValue() {
      return new Stack();
    }
  };

  public static CmdbContext get() {
    try {
      return ((CmdbContext)((Stack)repository.get()).peek());
    } catch (EmptyStackException e) {
      throw new RuntimeException("Coding error. The thread-local context is not initialized.");
    }
  }

  public static CmdbContext peek() {
    if (!(((Stack)repository.get()).isEmpty()))
      return ((CmdbContext)((Stack)repository.get()).peek());

    return null;
  }

  public static void push(CmdbContext context) {
    ((Stack)repository.get()).push(context);
  }

  public static void pop() {
    ((Stack)repository.get()).pop();
  }
}