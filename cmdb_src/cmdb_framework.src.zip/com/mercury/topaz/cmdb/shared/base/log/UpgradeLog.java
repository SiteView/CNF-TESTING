package com.mercury.topaz.cmdb.shared.base.log;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;

public class UpgradeLog
  implements Log
{
  private static Log shortLog = LogFactory.getEasyLog("cmdb.upgrade.short");
  private static Log reportLog = LogFactory.getEasyLog("cmdb.upgrade.report");

  public boolean isDebugEnabled()
  {
    return shortLog.isDebugEnabled();
  }

  public boolean isErrorEnabled() {
    return shortLog.isErrorEnabled();
  }

  public boolean isFatalEnabled() {
    return shortLog.isFatalEnabled();
  }

  public boolean isInfoEnabled() {
    return shortLog.isInfoEnabled();
  }

  public boolean isTraceEnabled() {
    return shortLog.isTraceEnabled();
  }

  public boolean isWarnEnabled() {
    return shortLog.isWarnEnabled();
  }

  public void trace(Object o) {
    shortLog.trace(o);
    reportLog.trace(o);
  }

  public void trace(Object o, Throwable throwable) {
    shortLog.trace(o, throwable);
    reportLog.trace(o);
  }

  public void debug(Object o) {
    shortLog.debug(o);
    reportLog.debug(o);
  }

  public void debug(Object o, Throwable throwable) {
    shortLog.debug(o, throwable);
    reportLog.debug(o);
  }

  public void info(Object o) {
    shortLog.info(o);
    reportLog.info(o);
  }

  public void info(Object o, Throwable throwable) {
    shortLog.info(o, throwable);
    reportLog.info(o);
  }

  public void warn(Object o) {
    shortLog.warn(o);
    reportLog.warn(o);
  }

  public void warn(Object o, Throwable throwable) {
    shortLog.warn(o, throwable);
    reportLog.warn(o);
  }

  public void error(Object o) {
    shortLog.error(o);
    reportLog.error(o);
  }

  public void error(Object o, Throwable throwable) {
    shortLog.error(o, throwable);
    reportLog.error(o);
  }

  public void fatal(Object o) {
    shortLog.fatal(o);
    reportLog.fatal(o);
  }

  public void fatal(Object o, Throwable throwable) {
    shortLog.fatal(o, throwable);
    reportLog.fatal(o);
  }
}