package com.mercury.topaz.cmdb.shared.base;

import com.mercury.topaz.cmdb.client.manage.api.impl.RmiEnvironment;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID.Factory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;

public class FrameworkConstants
{
  public static enum Subsystem
  {
    CLASS_MODEL, MODEL, MODEL_NOTIFICATION, PQL_RESULT, PQL_ADMIN, DAL, HISTORY, RECONCILIATION, CMDB_ADMIN;

    public static final Subsystem[] values()
    {
      return ((Subsystem[])$VALUES.clone());
    }
  }

  public static final class Customer
  {
    public static final class Global
    {
      public static final CmdbCustomerID ID = CmdbCustomerID.Factory.createCMDBCustomerID(-2147483648);
    }

    public static final class Default
    {
      public static final CmdbCustomerID ID = CmdbCustomerID.Factory.createCMDBCustomerID(1, "Default Client");
    }
  }

  public static final class ConfigSettings
  {
    public static final String CMDB_CONTEXT_NAME = "cmdb";
    public static final String TQL_SETTINGS = "cmdb_tql.conf";
  }

  public static final class Services
  {
    public static final String SERVICES_HOME_FOLDER = "cmdb/services";
    public static final String SERVICE_CONFIG_FILE_NAME = "service-config.xml";
  }

  public static final class Quota
  {
    public static final int PARAM_QUOTA_COUNT_INTERVAL_DEFAULT = 900;
    public static final long PARAM_QUOTA_COUNT_DELAY_DEFAULT = 900000L;

    public static final class Name
    {
      public static final String QUOTA_NAME_CUSTOMER_MODEL_OBJECTS = "quota.name.customer.model.objects";
      public static final String QUOTA_NAME_SERVER_MODEL_OBJECTS = "quota.name.server.model.objects";
      public static final String QUOTA_NAME_CUSTOMER_TQL_ACTIVE = "quota.name.customer.tql.active";
      public static final String QUOTA_NAME_SERVER_TQL_ACTIVE = "quota.name.server.tql.active";
    }

    public static final class SettingNames
    {
      public static final String PARAM_QUOTA_COUNT_INTERVAL_SEC = "quota.scheduler.interval.sec";
      public static final String PARAM_QUOTA_IS_CHECK_ENABLED = "quota.check.enabled";
      public static final String PARAM_QUOTA_LOADER = "quota.loader.name";
    }

    public static final class LoaderNames
    {
      public static final String QUOTA_LOADER_SYSTEM_CONSOLE = "system_console";
      public static final String QUOTA_LOADER_SETTINGS_READER = "settings";
    }
  }

  public static class Monitor
  {
    public static final String PARAM_SCHEDULER_TIMER_TIME = "monitor.scheduler.timer.time";
    public static final String PARAM_SCHEDULER_DELAY_TIME = "monitor.scheduler.delay.time";
    public static final String PARAM_ACTIVATE_SCHEDULER_FOR_CUSTOMER = "monitor.scheduler.load.customer.number";
  }

  public static final class Notification
  {
    public static final String NUMBER_OF_PUBLISH_TASKS = "notification.number.of.publish.tasks";
    public static final String NOTIFICATION_JMS_CONNECTION_FACTORY = "notification.jms.connection.factory";
    public static final String NOTIFICATION_TOPIC_JNDI_NAME = "notification.topic.jndi.name";
    public static final String RETRIES_NUMBER = "notification.retry.number";
    public static final String INTERVAL_BETWEEN_RETRIES_MSEC = "notification.retry.interval.msec";
    public static final String NOTIFICATION_JMS_SESSIONS_APPLICATIONS = "notification.sessions.applications";
    public static final String NOTIFICATION_JMS_MAX_QUEUE_SIZE = "notification.queue.size.max";
    public static final Integer NOTIFICATION_JMS_MAX_QUEUE_SIZE_DEFAULT = Integer.valueOf(100);
    public static final String NOTIFICATION_QUEUE_FLUSH_INTERVAL = "notification.queue.flush.interval";
    public static final String NOTIFICATION_QUEUE_FLUSH_DELAY = "notification.queue.flush.delay";
    public static final String IS_SUBSCRIBERS_DURABLE = "cmdbIsSubscribersDurable";
    public static final int NOTIFICATION_QUEUE_FLUSH_INTERVAL_DEFAULT = 120;
    public static final long NOTIFICATION_QUEUE_FLUSH_DELAY_DEFAULT = 120000L;

    public static final class JMSPropertyNames
    {
      public static final String CUSTOMER_ID = "CUSTOMER_ID";
      public static final String SUBSYSTEM_NAME = "SUBSYSTEM_NAME";
      public static final String MESSAGE_ID = "CMDB_MESSAGE_ID";

      public static final class Model
      {
        public static final String MODEL_NOTIFICATION_NAME = "MODEL_NOTIFICATION_NAME";
      }

      public static final class TQL
      {
        public static final String PATTERN_GROUP_ID = "PATTERN_GROUP_ID";
        public static final String PATTERN_NAME = "PATTERN_NAME";
      }
    }
  }

  public static final class HA
  {
    public static final String CMDB_CLASS_MODEL_SERVICE_NAME = "CMDBCLASSMODEL";
    public static final String CMDB_SERVICE_NAME = "CMDB";
    public static final String CMDB_MODEL_UPDATE_SERVICE_NAME = "CMDBMODELUPDATE";
    public static final String CMDB_RESULT_UTILS_SERVICE_NAME = "CMDB_RES_UTILS";
    public static final String CMDB_SYSTEM_TQLS_SERVICE_NAME = "CMDB_SYS_TQLS";
    public static final String CMDB_MOD_NOT_SERVICE_NAME = "CMDB_MOD_NOT";
    public static final String CMDB_RECONCILIATION_SERVICE_NAME = "CMDB_RECONCILE";
    public static final String FRAMEWORK_SERVICE_NAME = "Framework service";
    public static final String FEDERATION_SERVICE_NAME = "FCMDB";

    public static final class PropertyNames
    {
      public static final String CMDB_CONTROL_RETRIES_NUMBER = "cmdbControllRetriesNum";
      public static final String CMDB_CONTROL_RETRIES_INTERVAL = "cmdbControllInterval";
    }
  }

  public static final class API
  {
    public static final String BIND_NAME_PREFIX = "UCMDB:";
    public static final int CMDB_SYSTEM_USER = -1;
    public static final int BAC_SYSTEM_USER = -2;
    public static final String CMDB_CALLER_APP_NAME = "CMDB";
    public static final CmdbContext CMDB_GLOBAL_CONTEXT = CmdbContextFactory.createGlobalCmdbContext(-1, "CMDB");

    public static final class RMI
    {
      public static final RmiEnvironment DEFAULT_RMI_ENVIRONMENT = new RmiEnvironment();
    }
  }

  public static final class CmdbServer
  {
    public static final String PARAM_SESSION_TIMEOUT = "server.sync.session.timeout";
    public static final String PARAM_DB_CONNECTION_POOL_TIMEOUT = "db.connection.pool.timeout";
  }
}