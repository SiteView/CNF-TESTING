package com.mercury.topaz.cmdb.shared.base.profile;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.util.MemoryUtil;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ClassCreationProfiler
{
  private static Log _logger = LogFactory.getEasyLog(ClassCreationProfiler.class);
  private static Log _profilingLog = CmdbLogFactory.getProfilingLog();
  private static ClassCreationProfiler _theInstance;
  private Map _objectsInfoRepository;
  public static final String TAB = "\t";

  public static ClassCreationProfiler getInstance()
  {
    if (_theInstance == null)
      synchronized (ClassCreationProfiler.class) {
        if (_theInstance == null)
          _theInstance = new ClassCreationProfiler();
      }


    return _theInstance;
  }

  private ClassCreationProfiler()
  {
    this._objectsInfoRepository = new HashMap();
  }

  public synchronized void addIntance(String className)
  {
    Counter classInstancesCounter = (Counter)this._objectsInfoRepository.get(className);

    if (classInstancesCounter == null) {
      classInstancesCounter = new Counter();
      this._objectsInfoRepository.put(className, classInstancesCounter);
    }

    classInstancesCounter.increment();
  }

  public synchronized void freeIntance(String className)
  {
    Counter classInstancesCounter = (Counter)this._objectsInfoRepository.get(className);

    if (classInstancesCounter == null) {
      throw new IllegalArgumentException("Attempt free intance from that doesn't exist in table");
    }

    classInstancesCounter.decrement();
  }

  public synchronized void clear() {
    this._objectsInfoRepository.clear();
  }

  public synchronized String toString() {
    DecimalFormat decimalFormat = new DecimalFormat();
    StringBuffer sb = new StringBuffer("\n");
    sb.append("\n*****************************************************************************");
    sb.append("\n***                    CMDB Classes Creation Profiling Report              ***");
    sb.append("\n*****************************************************************************");
    sb.append("\nTotal Memory:    " + decimalFormat.format(Runtime.getRuntime().totalMemory() / 1024L)).append("[KB]");
    sb.append("\nFree Memory:     " + decimalFormat.format(MemoryUtil.getFreeMemory() / 1024L)).append("[KB]");
    sb.append("\nUsage Memory:    " + decimalFormat.format(MemoryUtil.getUsedMemoryInKB())).append("[KB]");
    sb.append("\nTotal Classes:   " + decimalFormat.format(this._objectsInfoRepository.size()));
    sb.append("\n******************************************************************************\n\n");
    sb.append(getRecordsString());

    return sb.toString();
  }

  private StringBuffer getRecordsString()
  {
    String interval = "\t|";
    StringBuffer sb = new StringBuffer();
    int maxClassName = getMaxClassName();
    DecimalFormat decimalFormat = new DecimalFormat();

    sb.append(resize("               Class Name", maxClassName));
    sb.append(interval).append("     Usage");
    sb.append(interval).append("     Created");
    sb.append(interval).append("Garbage Collected");

    int lineLengh = sb.length() + interval.length() * 8;
    addNewLine(lineLengh, sb);
    interval = interval + "\t";

    Iterator classesName = this._objectsInfoRepository.keySet().iterator();
    while (classesName.hasNext()) {
      String orgClassName = (String)classesName.next();
      String className = resize(orgClassName, maxClassName);

      Counter classInstancesCounter = (Counter)this._objectsInfoRepository.get(orgClassName);

      sb.append('\n');
      sb.append(className);
      sb.append(interval).append(decimalFormat.format(classInstancesCounter.getInstancesCounter()));
      sb.append(interval).append(decimalFormat.format(classInstancesCounter.getAddInstancesCounter()));
      sb.append(interval).append(decimalFormat.format(classInstancesCounter.getRemoveInstancesCounter()));
    }
    addNewLine(lineLengh, sb);
    return sb;
  }

  private void addNewLine(int lineLengh, StringBuffer sb) {
    sb.append('\n');
    for (int i = 0; i < lineLengh; ++i)
      sb.append('-');
  }

  private String resize(String className, int maxClassName)
  {
    StringBuffer sb = new StringBuffer(className);
    int additionSpaces = maxClassName - className.length();
    for (int i = 0; i < additionSpaces; ++i)
      sb.append(' ');

    return sb.toString();
  }

  private int getMaxClassName() {
    int maxClassName = 0;
    Iterator classesName = this._objectsInfoRepository.keySet().iterator();
    while (classesName.hasNext()) {
      String className = (String)classesName.next();
      if (maxClassName < className.length())
        maxClassName = className.length();
    }

    return maxClassName;
  }

  public synchronized String toHTML() {
    StringBuffer sb = new StringBuffer("<HTML><HEAD><title>CMDB Classes Creation Profiling Report</title></HEAD><table border><tr><th>Class</th><th>Total Iterations</th><th>Created Iterations</th><th>Garbage Collected Iterations</th></tr> ");

    sb.append(getRecordsHtml());
    sb.append("</table></HTML>");
    return sb.toString();
  }

  private StringBuffer getRecordsHtml() {
    StringBuffer sb = new StringBuffer();
    Iterator classesName = this._objectsInfoRepository.keySet().iterator();
    while (classesName.hasNext()) {
      String className = (String)classesName.next();
      Counter classInstancesCounter = (Counter)this._objectsInfoRepository.get(className);
      sb.append("<tr>");
      sb.append("<td>").append(className).append("</td>");
      sb.append("<td>").append(classInstancesCounter.getInstancesCounter()).append("</td>");
      sb.append("<td>").append(classInstancesCounter.getAddInstancesCounter()).append("</td>");
      sb.append("<td>").append(classInstancesCounter.getRemoveInstancesCounter()).append("</td>");
      sb.append("</tr>");
    }
    return sb;
  }

  public static void saveToFile(String fileName, String data)
    throws IOException
  {
    File outputFile = new File(fileName);

    String parentDir = outputFile.getParent();
    File parentDirFile = new File(parentDir);
    parentDirFile.mkdirs();

    FileOutputStream fileOutputStream = new FileOutputStream(outputFile);
    OutputStreamWriter out = new OutputStreamWriter(fileOutputStream, "UTF-8");

    out.write(data);
    out.close();
  }

  public void saveToHtml(String fileName) {
    try {
      saveToFile(fileName, toHTML());
    }
    catch (IOException e) {
      _logger.error("Can't save profiling report to file", e);
    }
  }

  public void saveToLog()
  {
    if (_profilingLog.isInfoEnabled())
      _profilingLog.info(toString());
  }

  protected void finalize() throws Throwable
  {
    saveToLog();
  }
}