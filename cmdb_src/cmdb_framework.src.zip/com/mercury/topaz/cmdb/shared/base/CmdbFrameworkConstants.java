package com.mercury.topaz.cmdb.shared.base;

public final class CmdbFrameworkConstants extends FrameworkConstants
{
  public static final class Parameters
  {
    public static final int DEFAULT_SESSION_TIMEOUT_IN_SEC = 600;
  }
}