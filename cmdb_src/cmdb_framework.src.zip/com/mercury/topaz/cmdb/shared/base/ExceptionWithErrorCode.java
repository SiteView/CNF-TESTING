package com.mercury.topaz.cmdb.shared.base;

public abstract interface ExceptionWithErrorCode
{
  public abstract String getMessage();

  public abstract ErrorCode getError();

  public abstract int getErrorCode();
}