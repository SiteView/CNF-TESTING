package com.mercury.topaz.cmdb.shared.base.profile;

class Counter
{
  private int _addInstancesCounter;
  private int _removeInstancesCounter;

  public Counter()
  {
    this._addInstancesCounter = 0;
  }

  public synchronized void increment()
  {
    this._addInstancesCounter += 1;
  }

  public synchronized void decrement()
  {
    this._removeInstancesCounter += 1;
  }

  protected int getAddInstancesCounter() {
    return this._addInstancesCounter;
  }

  protected int getRemoveInstancesCounter() {
    return this._removeInstancesCounter;
  }

  protected int getInstancesCounter() {
    return (this._addInstancesCounter - this._removeInstancesCounter);
  }
}