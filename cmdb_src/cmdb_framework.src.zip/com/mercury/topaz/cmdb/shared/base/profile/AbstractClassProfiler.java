package com.mercury.topaz.cmdb.shared.base.profile;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import java.io.ObjectStreamException;

public abstract class AbstractClassProfiler
{
  private static Log _profilingLog = CmdbLogFactory.getProfilingLog();

  public AbstractClassProfiler()
  {
    if (_profilingLog.isInfoEnabled())
      ClassCreationProfiler.getInstance().addIntance(super.getClass().getName());
  }

  protected void finalize()
    throws Throwable
  {
    if (_profilingLog.isInfoEnabled())
      ClassCreationProfiler.getInstance().freeIntance(super.getClass().getName());
  }

  protected final Object readResolve()
    throws ObjectStreamException
  {
    if (_profilingLog.isInfoEnabled()) {
      ClassCreationProfiler.getInstance().addIntance(super.getClass().getName());
    }

    return doReadResolve();
  }

  protected Object doReadResolve() throws ObjectStreamException
  {
    return this;
  }
}