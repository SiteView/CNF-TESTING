package com.mercury.topaz.cmdb.shared.base;

import java.io.Serializable;

public class ParameterizedErrorCode extends ErrorCode
{
  private final ErrorCodeProperty[] _properties;
  private final String[] _values;

  public ParameterizedErrorCode(ErrorCode errorCode, ErrorCodeProperty[] properties)
  {
    super(errorCode.getCode(), errorCode.getDescription());
    this._properties = properties;
    this._values = createValues(properties);
  }

  private String[] createValues(ErrorCodeProperty[] errorCodeProperties) {
    String[] ans = new String[errorCodeProperties.length];
    for (int i = 0; i < errorCodeProperties.length; ++i)
      ans[i] = errorCodeProperties[i].getValue();
    return ans;
  }

  public ErrorCodeProperty[] getProperties() {
    return this._properties;
  }

  public boolean isParameterizedErrorCode() {
    return true;
  }

  public String[] getValues() {
    return this._values;
  }

  public String toString() {
    StringBuilder sb = new StringBuilder(super.toString());
    sb.append("{");
    String[] values = getValues();
    if (values.length > 0)
      sb.append(values[0]);
    for (int i = 1; i < values.length; ++i)
      sb.append(", ").append(values[i]);
    sb.append("}");
    return sb.toString();
  }

  public static class ErrorCodeProperty
  implements Serializable
  {
    private String _description;
    private String _value;

    public ErrorCodeProperty(String description, String value)
    {
      setDescription(description);
      setValue(value); }

    public String getDescription() {
      return this._description; } 
    public String getValue() { return this._value; }

    public void setDescription(String description) {
      if (description == null)
        throw new IllegalArgumentException("<description> cannot be null!");
      this._description = description;
    }

    public void setValue(String value) {
      if (value == null)
        throw new IllegalArgumentException("<value> cannot be null!");
      this._value = value;
    }

    public boolean equals(Object other) {
      return ((other instanceof ErrorCodeProperty) && (getDescription().equals(((ErrorCodeProperty)other).getDescription())) && (getValue().equals(((ErrorCodeProperty)other).getValue())));
    }
  }
}