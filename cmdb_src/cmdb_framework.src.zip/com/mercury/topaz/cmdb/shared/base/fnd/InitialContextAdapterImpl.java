package com.mercury.topaz.cmdb.shared.base.fnd;

import com.mercury.infra.adapter.InitialContextProvider;
import com.mercury.topaz.cmdb.client.manage.api.impl.RmiEnvironment;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class InitialContextAdapterImpl
  implements InitialContextProvider
{
  public InitialContext getInitialContext()
    throws NamingException
  {
    return new InitialContext(new RmiEnvironment());
  }

  public InitialContext getInitialContext(String hostName) throws NamingException {
    return new InitialContext(new RmiEnvironment(hostName));
  }
}