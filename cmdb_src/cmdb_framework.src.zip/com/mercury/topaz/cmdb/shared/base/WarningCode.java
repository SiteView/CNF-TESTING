package com.mercury.topaz.cmdb.shared.base;

import java.io.Serializable;

public class WarningCode
  implements Serializable
{
  private int _code;
  String _description;
  public static final WarningCode NO_WARNINIG = new WarningCode(0, "no warning");
  public static final WarningCode WILD_CHAR_WARNING = new WarningCode(101, "A condition starting with wild chars slows the system");
  public static final WarningCode MISSING_INDEX_WARNING = new WarningCode(102, "A condition on a property which doesn't have an index slows the system");
  public static final WarningCode WRONG_ENRICHMENT_PRIORITY_WARNING = new WarningCode(201, "The priority of pattern's enrichment can be medium at the maximum");

  private WarningCode(int code, String codeDescription)
  {
    this._code = code;
    this._description = codeDescription;
  }

  public int getCode()
  {
    return this._code;
  }

  public String getDescription() {
    return this._description;
  }

  public int hashCode() {
    return this._code;
  }

  public boolean equals(Object obj) {
    if (obj == this) return true;
    if (!(obj instanceof WarningCode)) return false;
    return (this._code == ((WarningCode)obj)._code);
  }
}