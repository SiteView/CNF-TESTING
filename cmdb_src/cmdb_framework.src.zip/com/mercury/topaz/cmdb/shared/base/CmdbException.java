package com.mercury.topaz.cmdb.shared.base;

public class CmdbException extends RuntimeException
  implements ExceptionWithErrorCode
{
  private ErrorCode _errorCode = ErrorCode.UNDEFINED_ERROR_CODE;

  public CmdbException(String message)
  {
    super(message);
  }

  public CmdbException(String message, ErrorCode errorCode) {
    super(message);
    setErrorCode(errorCode);
  }

  public CmdbException(String message, Throwable cause) {
    super(message, cause);
    analyzeCause(cause);
  }

  public CmdbException(String message, Throwable cause, ErrorCode errorCode) {
    super(message, cause);
    setErrorCode(errorCode);
  }

  public CmdbException(Throwable cause) {
    super(cause);
    analyzeCause(cause);
  }

  public CmdbException(Throwable cause, ErrorCode errorCode) {
    super(cause);
    setErrorCode(errorCode);
  }

  public ErrorCode getError() {
    return this._errorCode;
  }

  public int getErrorCode() {
    return getError().getCode();
  }

  protected void setErrorCode(ErrorCode errorCode) {
    this._errorCode = errorCode;
  }

  private void analyzeCause(Throwable cause) {
    if (cause instanceof ExceptionWithErrorCode)
      setErrorCode(((ExceptionWithErrorCode)cause).getError());
  }
}