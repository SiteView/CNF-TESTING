package com.mercury.topaz.cmdb.shared.base.log;

import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggerFactory;

public class SystemPropertiesSettingLoggerFactory
  implements LoggerFactory
{
  public Logger makeNewLoggerInstance(String name)
  {
    return new MyLogger(name);
  }

  public void setTqlIdsPrinting(String tqlIdsPrinting)
  {
    System.setProperty("tqlIdsPrinting", tqlIdsPrinting);
  }

  private static class MyLogger extends Logger
  {
    public MyLogger(String name)
    {
      super(name);
    }
  }
}