package com.mercury.topaz.cmdb.shared.base.log;

import com.mercury.infra.utils.lang.SystemUtils;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;

public class CmdbLogFactory
{
  private static boolean isFirstTime = true;
  private static UpgradeLog upgradeLog = new UpgradeLog();

  public static Log getCMDBInfoLog()
  {
    return getStartupLog();
  }

  public static Log getStartupLog() {
    if (isFirstTime) {
      dumpLogHeader();
      isFirstTime = false;
    }
    return LogFactory.getEasyLog("cmdb.startup");
  }

  public static Log getProfilingLog() {
    return LogFactory.getEasyLog("cmdb.profile");
  }

  public static Log getQueryShortLog() {
    return LogFactory.getEasyLog("cmdb.query.short");
  }

  public static Log getQueryDetailedLog() {
    return LogFactory.getEasyLog("cmdb.query.detailed");
  }

  public static Log getShortAuditLog() {
    return LogFactory.getEasyLog("cmdb.audit.short");
  }

  public static Log getDetailedAuditLog() {
    return LogFactory.getEasyLog("cmdb.audit.detailed");
  }

  public static Log getClassModelShortAuditLog() {
    return LogFactory.getEasyLog("cmdb.classmodel.audit.short");
  }

  public static Log getClassModelDetailedAuditLog() {
    return LogFactory.getEasyLog("cmdb.classmodel.audit.detailed");
  }

  public static Log getModelShortAuditLog() {
    return LogFactory.getEasyLog("cmdb.model.audit.short");
  }

  public static Log getModelDetailedAuditLog() {
    return LogFactory.getEasyLog("cmdb.model.audit.detailed");
  }

  public static Log getModelCacheLog() {
    return LogFactory.getEasyLog("cmdb.model.cache");
  }

  public static Log getModelTopologyLog() {
    return LogFactory.getEasyLog("cmdb.model.topology");
  }

  public static Log getMonitorLog() {
    return LogFactory.getEasyLog("cmdb.monitor");
  }

  public static Log getModelAgingLog() {
    return LogFactory.getEasyLog("cmdb.model.aging");
  }

  public static Log getModelNotificationLog() {
    return LogFactory.getEasyLog("cmdb.model.notification");
  }

  public static Log getModelNotificationDetailsLog() {
    return LogFactory.getEasyLog("cmdb.model.notification.detailed");
  }

  public static Log getServerMonitorLog() {
    return LogFactory.getEasyLog("cmdb.server.monitor");
  }

  public static Log getOperationLog() {
    return LogFactory.getEasyLog("cmdb.operation");
  }

  public static Log getIncrementalStatisticsLog() {
    return LogFactory.getEasyLog("cmdb.incremental.statistics");
  }

  public static Log getIncrementalDetailedLog() {
    return LogFactory.getEasyLog("cmdb.incremental.detailed");
  }

  public static Log getIncrementalSplitterLog() {
    return LogFactory.getEasyLog("cmdb.incremental.splitter");
  }

  public static Log getPatternStatisticsLog() {
    return LogFactory.getEasyLog("cmdb.pattern.statistics");
  }

  public static Log getUpgraderLog() {
    return upgradeLog;
  }

  public static Log getUpgraderDetailedLog() {
    return LogFactory.getEasyLog("cmdb.upgrade.detailed");
  }

  public static Log getSystemTqlEventsProcessorLog() {
    return LogFactory.getEasyLog("cmdb.systemtql.eventsprocessor");
  }

  public static Log getSystemTqlResultCacheLog() {
    return LogFactory.getEasyLog("cmdb.systemtql.result.cache");
  }

  public static Log getSystemTqlGeneralLog() {
    return LogFactory.getEasyLog("cmdb.systemtql.general");
  }

  public static Log getStatisticsLog() {
    return LogFactory.getEasyLog("cmdb.statistics");
  }

  public static Log getOptimizerLog() {
    return LogFactory.getEasyLog("cmdb.tql.optimizer");
  }

  private static void dumpLogHeader() {
    String logHeader = "\n****************************************************************\n***              CMDB Server start working  \n****************************************************************\n***  Java Version: " + SystemUtils.JAVA_VERSION + SystemUtils.LINE_SEPARATOR + "***  CMDB Version:  " + getCMDBBuildNumber() + SystemUtils.LINE_SEPARATOR + "***  Java Home:    " + SystemUtils.JAVA_HOME + SystemUtils.LINE_SEPARATOR + "***  OS Name:      " + SystemUtils.OS_NAME + " " + SystemUtils.OS_VERSION + SystemUtils.LINE_SEPARATOR + "****************************************************************\n";

    LogFactory.getEasyLog("cmdb.info").info(logHeader);
  }

  private static String getCMDBBuildNumber()
  {
    Package cmdbPackage = Package.getPackage("com.mercury.topaz.cmdb.shared.base.log");
    if ((cmdbPackage == null) || (cmdbPackage.getImplementationVersion() == null)) {
      return "N/A";
    }

    return "CMDB build #" + cmdbPackage.getImplementationVersion();
  }

  public static void main(String[] args) {
    getCMDBBuildNumber();
  }
}