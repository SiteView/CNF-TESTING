package com.mercury.topaz.cmdb.shared.base;

public class ModelException extends CmdbException
{
  public ModelException(String message)
  {
    super(message);
  }

  public ModelException(String message, Throwable cause) {
    super(message, cause);
  }

  public ModelException(Throwable cause) {
    super(cause);
  }

  public ModelException(String message, ErrorCode errorCode) {
    super(message, errorCode);
  }
}