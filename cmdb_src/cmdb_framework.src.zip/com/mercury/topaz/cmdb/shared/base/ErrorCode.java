package com.mercury.topaz.cmdb.shared.base;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ErrorCode
  implements Serializable
{
  private int _code;
  String _description;
  private static Map<Integer, ErrorCode> errorCodes;
  public static final ErrorCode UNDEFINED_ERROR_CODE = new ErrorCode(-2147483648, "undefined error code", true);
  public static final ErrorCode SERVICE_NOT_AVAILABLE = new ErrorCode(1, "Service is not available", true);
  public static final ErrorCode DATABASE_NOT_AVAILABLE = new ErrorCode(2, "Couldn't connect to database", true);
  public static final ErrorCode CLASS_NOT_IN_CLASS_MODEL = new ErrorCode(101, "class not in class model", true);
  public static final ErrorCode CLASS_QULIFIER_NOT_IN_CLASSES = new ErrorCode(102, "there is no class with the defined qualifier", true);
  public static final ErrorCode CLASS_DOSNT_CONTAIN_PROPERTY = new ErrorCode(103, "condition on property that is not in chosen class", true);
  public static final ErrorCode NAME_OF_OTHER_PROPERTY_MUST_BE_STRING = new ErrorCode(104, "type of other property name in two properties condition must be string", true);
  public static final ErrorCode CLASS_INHERIT_FROM_UNKNOWN_CLASS = new ErrorCode(106, "class inherit from unknown class", true);
  public static final ErrorCode CLASS_ALREADY_EXISTS = new ErrorCode(107, "class already exists", true);
  public static final ErrorCode SUPERCLASS_DOESNT_EXIST = new ErrorCode(108, "superclass doesn't exist", true);
  public static final ErrorCode ROOT_CLASS_DOESNT_EXIST = new ErrorCode(109, "root class doesn't exist", true);
  public static final ErrorCode CLASS_MODEL_VALIDATION_ERROR = new ErrorCode(110, "class model validation error", true);
  public static final ErrorCode VALUE_TYPE_MISMATCH = new ErrorCode(111, "the value is not of given type", true);
  public static final ErrorCode DUPLICATE_ATTRIBUTE_DEFINITION = new ErrorCode(112, "class has duplicate attribute definition", true);
  public static final ErrorCode ATTRIBUTE_TYPE_IS_NOT_DEFINED = new ErrorCode(113, "attribute type is not defined in class model", true);
  public static final ErrorCode ATTRIBUTE_CANT_BE_OVERRIDEN = new ErrorCode(114, "attribute can't be overriden", true);
  public static final ErrorCode ABSTRACT_CLASS_INSTANCE_CREATE_ERROR = new ErrorCode(115, "create an instance from an abstract class", true);
  public static final ErrorCode ATTRIBUTE_TYPE_MISMATCH = new ErrorCode(116, "attribute type mismatch", true);
  public static final ErrorCode ATTRIBUTE_SIZE_LIMIT = new ErrorCode(117, "property's value has exceeded the size limit of the attribute", true);
  public static final ErrorCode UPDATE_STATIC_ATTRIBUTE = new ErrorCode(118, "update the attribute which has STATIC_ATTRIBUTE qualifier", true);
  public static final ErrorCode UPDATE_ID_ATTRIBUTE = new ErrorCode(119, "update the attribute which has ID_ATTRIBUTE qualifier", true);
  public static final ErrorCode CALC_ACTIVE_NOT_PERSISTENT = new ErrorCode(120, "failed to calculate active & not-persistent pattern", true);
  public static final ErrorCode REQUIRED_NODE_DOESNT_EXIST = new ErrorCode(121, "Each connected component in the query graph must contain at least one CONTACT node", true);
  public static final ErrorCode TYPEDEF_DOESNT_EXIST = new ErrorCode(130, "typedef doesn't exist", true);
  public static final ErrorCode TYPEDEF_ALREADY_EXISTS = new ErrorCode(131, "typedef already exists", true);
  public static final ErrorCode TYPEDEF_UPDATE_USER_BY_FACTORY = new ErrorCode(132, "cannot update type definition of user by factory type definition", true);
  public static final ErrorCode VALIDLINK_DOESNT_EXIST = new ErrorCode(140, "validlink doesn't exist", true);
  public static final ErrorCode VALIDLINK_ALREADY_EXISTS = new ErrorCode(141, "validlink already exists", true);
  public static final ErrorCode INVALID_CONDITION_OPERATOR_FOR_ACTIVE_TQL = new ErrorCode(142, "Change during and unchange during condition operators are not valid for active tql", true);
  public static final ErrorCode INVALID_OPERATOR_FOR_TYPE = new ErrorCode(151, "invalid operator for type", true);
  public static final ErrorCode EMPTY_VALUE_FOR_OPERATOR = new ErrorCode(152, "the selected operator must have at least one value", true);
  public static final ErrorCode INCOMPETABLE_TYPES = new ErrorCode(153, "type of property and type of value don't match", true);
  public static final ErrorCode OPERATOR_INVALID_FOR_TYPE = new ErrorCode(154, "invalid operator for type", true);
  public static final ErrorCode INVALID_NODELINKS_CONDITION = new ErrorCode(155, "inalid node links condition", true);
  public static final ErrorCode SUBGRAPH_INVALID_ELEMENT_NUMBER = new ErrorCode(156, "element number in subgraph definition is already in use", true);
  public static final ErrorCode EMPTY_NODES = new ErrorCode(160, "no nodes in pattern graph");
  public static final ErrorCode CONTAIN_CIRCLES = new ErrorCode(161, "pattern graph contains circles which are not allowed in the selected pattern group", true);
  public static final ErrorCode CONTAIN_SEPERATE_GRAPHS = new ErrorCode(162, "pattern graph contains seperate graphs which are not allowed in the selected pattern group", true);
  public static final ErrorCode CONTAIN_NOT_REQ_LINKS = new ErrorCode(163, "pattern graph contains NOT Required links which are not allowed in the selected pattern group", true);
  public static final ErrorCode INVLID_JOINF_PARAMETER = new ErrorCode(164, "property is not part of end class", true);
  public static final ErrorCode INVALID_PROPERTY_IN_LAYOUT = new ErrorCode(165, "one of layout properties is not part of class", true);
  public static final ErrorCode INVALID_TYPE_LAYOUT_NODE_LEAF = new ErrorCode(166, "Type layout is not valid for node that doesn't allow inhertence", true);
  public static final ErrorCode INVALID_TYPE_LAYOUT_TYPE_NOT_DERIVED = new ErrorCode(167, "Type layout is inalid - defined type is not descened from element class", true);
  public static final ErrorCode INVALID_ELEMENT_IN_LAYOUT = new ErrorCode(168, "layout contains element layout which is not part of pattern definition", true);
  public static final ErrorCode CONTAIN_SUB_GRAPH = new ErrorCode(169, "pattern graph contains sub graph which are not allowed in the selected pattern group", true);
  public static final ErrorCode LINK_END_NOT_IN_GRAPH = new ErrorCode(170, "Link end is not in pattern graph", true);
  public static final ErrorCode LINK_NOT_IN_NODELINKS_CONDITION = new ErrorCode(171, "Link is not in one of its ends node links condition", true);
  public static final ErrorCode NO_VISIBLE_NODE = new ErrorCode(172, "There is no visible node in the pattern", true);
  public static final ErrorCode SUBGRAPH_NOT_POSITIVE_DEPTH = new ErrorCode(173, "Wrong depth in sub graph parameter", true);
  public static final ErrorCode SUBGRAPH_NO_TRIPLETS = new ErrorCode(174, "No triplets were defined on sub graph parameter", true);
  public static final ErrorCode UNSUPPORTED_OPERATION_OVER_ATTRIBUTE = new ErrorCode(175, "Attribute does not support the required operation", true);
  public static final ErrorCode OBJECT_NOT_IN_MODEL = new ErrorCode(176, "The object doesn't exist in the model", true);
  public static final ErrorCode NUMBER_OF_OBJECTS_VISITED_DURING_MODEL_SEARCH_EXCEEDS_LIMIT = new ErrorCode(177, "The number of objects visited during a single model search exceeds limit, try to refine your TQL", true);
  public static final ErrorCode NO_VISIBLE_ELEMENT = new ErrorCode(178, "There is no visible element in the pattern", true);
  public static final ErrorCode CORRELATION_GRAPH_NODE_AMOUNT_LESS_THAN_REQUIRED = new ErrorCode(179, "Pattern graph for correlation group should contain at least 2 nodes", true);
  public static final ErrorCode TIME_OUT_FOR_TQL_MODEL_SEARCHING = new ErrorCode(185, "Time out for tql model searching", true);
  public static final ErrorCode TOO_MANY_RESULTS_FOR_NON_CHUNKABLE_TQL = new ErrorCode(186, "There are more than 100,000 results in the search query. Please refine your query.", true);
  public static final ErrorCode TOO_MANY_INITIALIZED_PATTERNS = new ErrorCode(190, "Could not initialize pattern since the limit of maximum initialized pattern has been exceeded!!!", true);
  public static final ErrorCode TOO_MANY_OBJECTS_IN_RESULT_REPOSITORY_CACHE = new ErrorCode(191, "There are too many objects in tql result repository cache! please deactive several patterns", true);
  public static final ErrorCode ACTIVE_TQL_NUMBER_EXCEEDS_THRESHOLD = new ErrorCode(192, "Could not create or activate the requested pattern since limit for the number of active TQLs has been exceeded!!!", true);
  public static final ErrorCode TOO_MANY_START_OBJECTS_FOR_COMPOUND_LINK_CALCULATION = new ErrorCode(193, "The number of start objects for compound link calculation exceeds limit, try to refine your TQL", true);
  public static final ErrorCode TQL_ALL_CALCULATION_STRATEGIES_FAILED = new ErrorCode(196, "All calculation strategies were tried and failed for tql", true);
  public static final ErrorCode ADAPTER_NEEDS_RECONCILIATION_DATA = new ErrorCode(197, "Adapter cannot handle query without reconciliation data!", true);
  public static final ErrorCode MISSING_PATTERN = new ErrorCode(200, "The TQL query for this enrichment rule is missing", true);
  public static final ErrorCode ALREADY_EXIST_ENRICHMENT = new ErrorCode(201, "This enrichment rule already exists", true);
  public static final ErrorCode MISSING_ENRICHMENT = new ErrorCode(202, "This enrichment rule does not exist", true);
  public static final ErrorCode MISSING_ACTIONS = new ErrorCode(203, "At least one action must be defined for this enrichment rule", true);
  public static final ErrorCode INVALID_ELEMENT_NUMBER = new ErrorCode(204, "Element number in enrichment definition is already in used", true);
  public static final ErrorCode UNSUPPORTED_ACTION = new ErrorCode(205, "Action is unsupported, supported actions are: CREATE ACTION, REMOVE ACTION and UPDATE ACTION", true);
  public static final ErrorCode UNREQUIRED_ELEMENT_NUMBER = new ErrorCode(206, "Node or relationship which palys a role in an enrichment is either not part of its TQL definition of contained as non required", true);
  public static final ErrorCode ATTRIBUTE_NOT_IN_CLASS_MODEL = new ErrorCode(207, "The following attribute is not part of the following class in the class model", true);
  public static final ErrorCode INTERDEPENDENT_ACTIONS = new ErrorCode(208, "Enrichment rule's definition contains interdependent actions", true);
  public static final ErrorCode UNRELATED_ENRICHMENT = new ErrorCode(209, "Enrichment rule's definition is not linked to the TQL query", true);
  public static final ErrorCode MISSING_MUST_ATTRIBUTE = new ErrorCode(210, "Required attribute has not been defined", true);
  public static final ErrorCode EXIST_READ_ONLY_ATTRIBUTE = new ErrorCode(211, "This is a read-only attribute. It cannot be edited", true);
  public static final ErrorCode MISSING_CONTAINER_ELEMENT = new ErrorCode(212, "Missing container object", true);
  public static final ErrorCode WRONG_GROUP_ID = new ErrorCode(213, "Enrichment definition is related to a TQL with a wrong group id", true);
  public static final ErrorCode ATTRIBUTE_POINT_TO_ITSELF = new ErrorCode(214, "Attribute value is the attribute itself", true);
  public static final ErrorCode MISSING_NODE_LINK = new ErrorCode(215, "Enrichment definition's expression uses Node/Relationship that doesn't exist in the graph", true);
  public static final ErrorCode ABSTRACT_CLASS = new ErrorCode(216, "Enrichment definition consist of create abstract class action", true);
  public static final ErrorCode VIRTUAL_LINK = new ErrorCode(217, "Enrichment definition relationship is virtual", true);
  public static final ErrorCode MISMATCH_TYPE = new ErrorCode(218, "Enrichment definition has attribute value with mismatch type", true);
  public static final ErrorCode NO_VALID_LINK = new ErrorCode(219, "Enrichment definition has create relationship that is not part of the valid relationships", true);
  public static final ErrorCode MULTI_ACTIONS = new ErrorCode(220, "Enrichment definition has more than one action per node", true);
  public static final ErrorCode INVALID_LINK = new ErrorCode(221, "Enrichment definition has link with with ID attributes or with required attributes", true);
  public static final ErrorCode INVALID_PATTERN = new ErrorCode(222, "Pattern is not valid with respect to current operation", true);
  public static final ErrorCode PARAMETERIZED_PATTERN_ABUSE = new ErrorCode(223, "Illegal use of parameterized pattern", true);
  public static final ErrorCode INVALID_CARDINALITY = new ErrorCode(224, "Enrichment definition node with invalid cardinality", true);
  public static final ErrorCode GENERAL_QUOTA_ERROR = new ErrorCode(300, "General Quota Error", true);
  public static final ErrorCode MODEL_OBJECTS_QUOTA_EXCEEDED = new ErrorCode(310, "Model objects quota is exceeded", true);
  public static final ErrorCode ACTIVE_TQL_QUOTA_EXCEEDED = new ErrorCode(320, "Active TQL quota is exceeded", true);
  public static final ErrorCode FTQL_INTERNAL_QUOTA_EXCEEDED = new ErrorCode(330, "too many objects received in source result", true);
  public static final ErrorCode FTQL_EXTERNAL_QUOTA_EXCEEDED = new ErrorCode(340, "too many objects received in target result", true);
  public static final ErrorCode ENUM_IS_IN_USE_CANT_REMOVE = new ErrorCode(400, "Enumeration is in use; Therefore it can't be removed", true);
  public static final ErrorCode ENUM_IS_IN_USE_CANT_UPDATE = new ErrorCode(401, "Enumeration is in use; Therefore enum entries can't be removed", true);
  public static final ErrorCode ATTRIBUTE_ALREADY_EXISTS_IS_SUPER_CLASS = new ErrorCode(402, "Attribute with this name already exists in super class", true);
  public static final ErrorCode OBJECT_ALREADY_EXISTS = new ErrorCode(500, "Object Already Exists", true);
  public static final ErrorCode LINK_ALREADY_EXISTS = new ErrorCode(501, "Link Already Exists", true);
  public static final ErrorCode MAX_REMOVED_CIS_EXCEEDED = new ErrorCode(502, "Maximum number of CIs allowed to be removed exceeded", true);
  public static final ErrorCode CAN_NOT_ADD_FUNCTION_LINK = new ErrorCode(502, "Can not add function link to model", true);
  public static final ErrorCode ACTION_NOT_DEFINED = new ErrorCode(600, "Action is not defined", true);
  public static final ErrorCode ACTION_NOT_ALLOWED = new ErrorCode(601, "Action is not allowed, like user trying to remove a factory class", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_NOT_VALID_NAME = new ErrorCode(602, "Action is not allowed, wrong class or attribute name", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_NOT_VALID_ATTRIBUTE_SIZE = new ErrorCode(603, "Action is not allowed, wrong size for attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_XML_TYPE_ATTR_CANT_BE_KEY_ATTR = new ErrorCode(604, "Action is not allowed, can't add KEY_ATTRIBUTE qualifier to attribute's xml type", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_ADD_STATIC_QUALIFIER = new ErrorCode(605, "Action is not allowed, can't add STATIC_ATTRIBUTE qualifier to an attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_ADD_TO_LOWER_OR_UPPER_QUALIFIER_TO_NON_STRING_ATTR = new ErrorCode(606, "Action is not allowed, can't add TO_LOWER or TO_UPPER qualifier to a non string attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_ATTRIBUTE_CANT_HAVE_BOTH_QUALIFIERS_TO_LOWER_AND_TO_UPPER = new ErrorCode(607, "Action is not allowed, attribute can't have both TO_LOWER and TO_UPPER qualifiers together", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_ADD_UNIQUE_INDEXED_QUALIFIER_TO_OVERRIDE_ATTRIBUTE = new ErrorCode(608, "Action is not allowed, can't add UNIQUE_INDEXED_ATTRIBUTE qualifier to an override attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_ADD_INDEXED_QUALIFIER_TO_OVERRIDE_ATTRIBUTE = new ErrorCode(609, "Action is not allowed, can't add INDEXED_ATTRIBUTE qualifier to an override attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_REMOVE_STATIC_QUALIFIER = new ErrorCode(610, "Action is not allowed, can't remove STATIC_ATTRIBUTE qualifier from an attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_CHANGE_CLASS_NAME = new ErrorCode(611, "Action is not allowed, can't change class name", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_CHANGE_CLASS_TYPE = new ErrorCode(612, "Action is not allowed, can't change class type", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_CHANGE_CLASS_HIERARCHY = new ErrorCode(613, "Action is not allowed, can't change class hierarchy", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_CHANGE_ATTRIBUTE_NAME = new ErrorCode(614, "Action is not allowed, can't change attribute name", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_CHANGE_ATTRIBUTE_TYPE = new ErrorCode(615, "Action is not allowed, can't change attribute type", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_CHANGE_METHOD_NAME = new ErrorCode(616, "Action is not allowed, can't change method name", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_DEFAULT_VALUE_SIZE_GREATER_THAN_ATTRIBUTE_SIZE = new ErrorCode(617, "Action is not allowed, can't add attribute with default value length greater than attribute size", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_ADD_OVERRIDE_ATTRIBUTE_NOT_IN_PARENT = new ErrorCode(618, "Action is not allowed, can't add attribute override which does not defined in parent class", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_DECREASE_ATTRIBUTE_SIZE = new ErrorCode(619, "Action is not allowed, can't decrease attribute size", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_SET_ATTRIBUTE_SIZE_TO_VALUE_LESS_THAN_1 = new ErrorCode(620, "Action is not allowed, can't set attribute size to less than 1", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_SET_BYTES_ATTRIBUTE_SIZE_GREATER_THAN_MAXIMUM = new ErrorCode(621, "Action is not allowed, can't set bytes' attribute size to greater than the maximum allowed", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CLASS_DOESNT_HAVE_UNIQUENESS_DEFINER = new ErrorCode(622, "Action is not allowed, Can't add class with no id attribute, no abstract class qualifier and no random generate id qualifier", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_REMOVE_USER_ATTRIBUTE = new ErrorCode(623, "Action is not allowed, factory can't remove user's attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_REMOVE_USER_OVERRIDE_ATTRIBUTE = new ErrorCode(624, "Action is not allowed, factory can't remove user's override attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_REMOVE_USER_PARTIALLY_OVERRIDE_ATTRIBUTE = new ErrorCode(625, "Action is not allowed, factory can't remove user's partially override attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_DEFAULT_USER_ATTRIBUTE_VALUE = new ErrorCode(626, "Action is not allowed, factory can't update default value to user attribute override", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_DEFAULT_USER_MODIFIED_ATTRIBUTE_VALUE = new ErrorCode(627, "Action is not allowed, factory can't update default value to modified by user attribute override", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_CLASS_DISPLAY_NAME = new ErrorCode(628, "Action is not allowed, factory can't update user class display name", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_CLASS_DISPLAY_NAME_FOR_CLASS_CHANGED_BY_USER = new ErrorCode(629, "Action is not allowed, factory can't update class display name for class that was modified by the user", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_CLASS_DESCRIPTION = new ErrorCode(630, "Action is not allowed, factory can't update user class description", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_CLASS_DESCRIPTION_FOR_CLASS_CHANGED_BY_USER = new ErrorCode(631, "Action is not allowed, factory can't update class description for class that was modified by the user", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_ATTRIBUTE_DISPLAY_NAME = new ErrorCode(632, "Action is not allowed, factory can't update user attribute display name", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_ATTRIBUTE_DISPLAY_NAME_FOR_ATTRIBUTE_CHANGED_BY_USER = new ErrorCode(633, "Action is not allowed, factory can't update attribute display name for attribute that was modified by the user", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_ATTRIBUTE_DESCRIPTION = new ErrorCode(634, "Action is not allowed, factory can't update user attribute description", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_ATTRIBUTE_DESCRIPTION_FOR_ATTRIBUTE_CHANGED_BY_USER = new ErrorCode(635, "Action is not allowed, factory can't update attribute description for attribute that was modified by the user", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_DEFAULT_VALUE = new ErrorCode(636, "Action is not allowed, factory can't update default value to user attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_DEFAULT_VALUE_FOR_ATTRIBUTE_CHANGED_BY_USER = new ErrorCode(637, "Action is not allowed, factory can't update default value to modified by user attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_ATTRIBUTE_SIZE = new ErrorCode(638, "Action is not allowed, factory can't update attribute size to user attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_ATTRIBUTE_SIZE_FOR_ATTRIBUTE_CHANGED_BY_USER = new ErrorCode(639, "Action is not allowed, factory can't update attribute size to modified by user attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_METHOD_DISPLAY_NAME = new ErrorCode(640, "Action is not allowed, factory can't update user cmdbMethod display name", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_METHOD_DISPLAY_NAME_FOR_METHOD_CHANGED_BY_USER = new ErrorCode(641, "Action is not allowed, factory can't update cmdbMethod display name for cmdbMethod that was modified by the user", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_METHOD_DESCRIPTION = new ErrorCode(642, "Action is not allowed, factory can't update user cmdbMethod description", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_METHOD_DESCRIPTION_FOR_METHOD_CHANGED_BY_USER = new ErrorCode(643, "Action is not allowed, factory can't update cmdbMethod description for cmdbMethod that was modified by the user", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_METHOD_TYPE = new ErrorCode(644, "Action is not allowed, factory can't update user cmdbMethod type", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_METHOD_TYPE_FOR_METHOD_CHANGED_BY_USER = new ErrorCode(645, "Action is not allowed, factory can't update cmdbMethod type for cmdbMethod that was modified by the user", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_METHOD_PARAMS = new ErrorCode(646, "Action is not allowed, factory can't update user cmdbMethod params", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_METHOD_PARAMS_FOR_METHOD_CHANGED_BY_USER = new ErrorCode(647, "Action is not allowed, factory can't update cmdbMethod params for cmdbMethod that was modified by the user", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_METHOD_COMMAND = new ErrorCode(648, "Action is not allowed, factory can't update user cmdbMethod command", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_METHOD_COMMAND_FOR_METHOD_CHANGED_BY_USER = new ErrorCode(649, "Action is not allowed, factory can't update cmdbMethod command for cmdbMethod that was modified by the user", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_REMOVE_USER_METHOD = new ErrorCode(650, "Action is not allowed, factory can't remove user method", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_ENUM = new ErrorCode(651, "Action is not allowed, factory can't update user cmdb cmdbenum", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_LIST = new ErrorCode(652, "Action is not allowed, factory can't update user cmdb list", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_TYPEDEF = new ErrorCode(653, "Action is not allowed, factory can't remove user typedef", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_TYPEDEF_DISPLAY_NAME = new ErrorCode(654, "Action is not allowed, factory can't update user typedef display name", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_TYPEDEF_DESCRIPTION = new ErrorCode(655, "Action is not allowed, factory can't update user typedef description", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_USER_CANT_REMOVE_FACTORY_ATTRIBUTE = new ErrorCode(656, "Action is not allowed, user can't remove factory attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_USER_CANT_REMOVE_FACTORY_ATTRIBUTE_OVERRIDE = new ErrorCode(657, "Action is not allowed, user can't remove factory attribute override", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_USER_CANT_REMOVE_FACTORY_METHOD = new ErrorCode(658, "Action is not allowed, user can't remove factory method", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_USER_CANT_UPDATE_FACTORY_TYPEDEF_DISPLAY_NAME = new ErrorCode(659, "Action is not allowed, user can't update factory typedef display name", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_USER_CANT_UPDATE_FACTORY_TYPEDEF_DESCRIPTION = new ErrorCode(660, "Action is not allowed, user can't update factory typedef dsecription", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_USER_CANT_REMOVE_FACTORY_ENUM_ENTRY = new ErrorCode(661, "Action is not allowed, user can't remove factory cmdbenum entry", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_USER_CANT_REMOVE_FACTORY_LIST_ENTRY = new ErrorCode(662, "Action is not allowed, user can't remove factory list entry", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_UPDATE_USER_CLASS = new ErrorCode(663, "Action is not allowed, cannot update anything in class created by user but updated by factory", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_REMOVE_USER_CLASS = new ErrorCode(664, "Action is not allowed, factory can't remove user class", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_REMOVE_ATTRIBUTE_FROM_USER_CLASS = new ErrorCode(665, "Action is not allowed, factory can't remove attribute from a user class", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_REMOVE_ATTRIBUTE_OVERRIDE_FROM_USER_CLASS = new ErrorCode(666, "Action is not allowed, factory can't remove attribute override from a user class", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_FACTORY_CANT_REMOVE_ATTRIBUTE_PARTIALLY_OVERRIDE_FROM_USER_CLASS = new ErrorCode(667, "Action is not allowed, factory can't remove attribute partially override from a user class", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_USER_CANT_ADD_FACTORY_METHOD_QUALIFIER = new ErrorCode(668, "Action is not allowed, user can't add factory method qualifier", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CANT_ADD_ID_QUALIFIER_TO_OVERRIDE_ATTRIBUTE_WITH_NO_INDEX = new ErrorCode(669, "Action is not allowed, can't add ID_ATTRIBUTE qualifier to override attribute with no INDEXED_ATTRIBUTE qualifier", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_INSTANCES_EXIST = new ErrorCode(700, "Action is not allowed because there are instances from this item", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_PATTERNS_EXIST = new ErrorCode(701, "Action is not allowed because there are patterns from this item", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_ENRICHMENTS_EXIST = new ErrorCode(702, "Action is not allowed because there are enrichments from this item", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_DESCENDANTS_EXIST = new ErrorCode(703, "Action is not allowed because this class has descendants", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_PATTERNS_CONTAIN_ATTRIBUTE = new ErrorCode(704, "Action is not allowed because patterns contain attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_ENRICHMENTS_CONTAIN_ATTRIBUTE = new ErrorCode(705, "Action is not allowed because enrichments contain attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_ATTRIBUTES_CONTAIN_TYPEDEF = new ErrorCode(706, "Action is not allowed because there are attributes that use this typedef", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_DEFAULT_VALUE_SIZE_GREATER_THAN_ATTR_SIZE = new ErrorCode(707, "Action is not allowed because default value size is greater than attribute size", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_LOWER_UPPER_IS_STRING_TYPE = new ErrorCode(708, "Action is not allowed because LOWER/UPPER qulifiers defined on attribute other than String type", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_LOWER_OR_UPPER = new ErrorCode(709, "Action is not allowed because use both LOWER and UPPER qulifiers together", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_MODEL_NOTIFICATIONS_EXIST = new ErrorCode(710, "Action is not allowed because there are model notifications from this item", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_MODEL_NOTIFICATION_CONTAIN_ATTRIBUTE = new ErrorCode(711, "Action is not allowed because model notifications contain attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_XML_ATTR_CANT_BE_KEY = new ErrorCode(712, "Action is not allowed because xml attribute can't be a key attribute", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_EXTENDED_ATTRIBUTE = new ErrorCode(713, "Action is not allowed because extended attribute qualifier can't be removed", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_SUPPORTED_OR_UNSUPPORTED_SUB_SET_CONDITION = new ErrorCode(714, "Action is not allowed because use both SUPPORTED_SUB_SET_OPERATION_CONDITION and UNSUPPORTED_SUB_SET_OPERATION_CONDITION qulifiers together", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_DESCENDENT_KEY_AND_INSTANCES_EXIST = new ErrorCode(715, "Action is not allowed because the attribute is a key and there are instances from this descendent's item", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_CLASS_WITH_NO_ID_ATTRIBUTE = new ErrorCode(716, "Action is not allowed because class remain without ID_ATTRIBUTE neither RANDOM_GENERATE_ID nor ABSTRACT_CLASS", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_DESCENDENT_WITH_NO_ID_ATTRIBUTE = new ErrorCode(717, "Action is not allowed because descendent class remain without ID_ATTRIBUTE neither RANDOM_GENERATE_ID nor ABSTRACT_CLASS", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_DESCENDENT_CONSIST_OF_ATTRIBUTE = new ErrorCode(718, "Action is not allowed because descendent class consist of the attribute to add", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_CONCRETE_INSTANCES_EXIST = new ErrorCode(719, "Action is not allowed because there are instances from this item (concrete type)", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_PATTERNS_CONTAIN_VALIDLINK = new ErrorCode(720, "Action is not allowed because patterns contain valid link", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_ENRICHMENTS_CONTAIN_VALIDLINK = new ErrorCode(721, "Action is not allowed because enrichments contain valid link", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_VALID_LINK_CLASSES_DONT_EXIST = new ErrorCode(722, "Action is not allowed because the link class or one of the end's class don't exist", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_CALCULATED_LINK_TRIPLETS_CLASSES_DONT_EXIST = new ErrorCode(723, "Action is not allowed because the triplets link class or one of the end's class don't exist", true);
  public static final ErrorCode ACTION_NOT_ALLOWED_IF_CALCULATED_LINK_HAS_TRIPLETS = new ErrorCode(724, "Action is not allowed because calculated link has triplets left", true);
  public static final ErrorCode MISSING_SUPER_CLASS = new ErrorCode(750, "Super class is missing", true);
  public static final ErrorCode FCMDB_GENERAL_ERROR = new ErrorCode(801, "General federation Error", true);
  public static final ErrorCode DATA_STORE_GENERAL_ERROR = new ErrorCode(802, "General data store Error", true);
  public static final ErrorCode DATA_STORE_COMMUNICATION_ERROR = new ErrorCode(800, "Couldn't connect to dataStore", true);
  public static final ErrorCode DATA_STORE_REMOTE_TIMEOUT = new ErrorCode(810, "Remote TimeOut Occured", true);
  public static final ErrorCode DATA_STORE_QUOTA_ERROR = new ErrorCode(820, "too many results received from dataStore", true);
  public static final ErrorCode DATA_STORE_DOESNT_EXIST = new ErrorCode(830, "dataStore doesn't exist", true);
  public static final ErrorCode DATA_STORE_ONE_NODE_TQL_NOT_ALLOWED = new ErrorCode(840, "One node Tql is not allowed using specific dataStore!", true);
  public static final ErrorCode DATA_STORE_CAN_NOT_START = new ErrorCode(850, "dataStore cannot start", true);
  public static final ErrorCode SYNCH_ERROR = new ErrorCode(860, "Error occurred while running synchronization. See statistics for more information", true);
  public static final ErrorCode DATA_STORE_CANNOT_REMOVE_DATA_STORE = new ErrorCode(870, "Operation is not allowed since synchronization is defined to use dataStore.", true);
  public static final ErrorCode DATA_STORE_CANNOT_REMOVE_ADAPTER = new ErrorCode(880, "Operation is not allowed since there is a dataStore using the adapter.", true);
  public static final ErrorCode DATA_STORE_CANNOT_UPDATE_DATA_STORE = new ErrorCode(890, "Operation is not allowed since synchronization is defined to use removed queries from the dataStore.", true);
  public static final ErrorCode DATA_STORE_CLASS_NOT_IN_CLASS_MODEL = new ErrorCode(895, "supported class not in class model", true);
  public static final ErrorCode DATA_STORE_CLASS_ATTRIBUTE_NOT_IN_CLASS = new ErrorCode(896, "supported attribute is not defined  in class model", true);
  public static final ErrorCode DATA_STORE_CONFIGURATION_ERROR = new ErrorCode(897, "The dataStore has problem with configuration", true);
  public static final ErrorCode FCONFIG_VALIDATION_ERROR_NO_ADAPTER_FOUND = new ErrorCode(900, "Operation is not allowed since the requested adapter not found", true);
  public static final ErrorCode FCONFIG_VALIDATION_ERROR_NO_ADAPTER_FOUND_FOR_DATASTORE = new ErrorCode(910, "Operation is not allowed since since the adapter for given data store not found", true);
  public static final ErrorCode FCONFIG_VALIDATION_ERROR_NO_DATASTORE_FOUND_FOR_SYNCH = new ErrorCode(920, "Operation is not allowed since since the data store for given synch id not found", true);
  public static final ErrorCode FCONFIG_VALIDATION_ERROR_PARTIAL_ATTRIBUTES_NOT_SUPPORTED = new ErrorCode(930, "The partial attributes on the class is not supported since it is external class", true);
  public static final ErrorCode FCONFIG_VALIDATION_ERROR_EXTERNAL_CLASS_NOT_SUPPORTED = new ErrorCode(940, "The external class on the class is not supported since it has external attribute", true);
  public static final ErrorCode FTQL_NO_VALID_LINK_ERROR = new ErrorCode(950, "No valid link for calculation FTQL", true);
  public static final ErrorCode FTQL_NO_MAPPING_ENGINE_ERROR = new ErrorCode(960, "No mapping engine class was found", true);
  public static final ErrorCode CANNOT_UPDATE_TEMPLATE_FROM_PACKAGE = new ErrorCode(30187, "Cannot update template from package due to possible data loss", true);
  public static final ErrorCode CANNOT_UPDATE_TQL = new ErrorCode(55033, "Cannot update TQL", true);
  public static final ErrorCode TQL_DOESNT_EXIST = new ErrorCode(55034, "TQL doesn't exist", true);
  public static final ErrorCode PACKAGE_RESOURCE_DEPLOY_ERROR = new ErrorCode(100001, "Package resource deploy error", true);
  public static final ErrorCode PACKAGE_RESOURCE_UNDEPLOY_ERROR = new ErrorCode(100002, "Package resource undeploy error", true);
  public static final ErrorCode PACKAGE_RESOURCE_DOESNT_EXIST = new ErrorCode(100003, "Package resource doesn't exist", true);
  public static final ErrorCode PACKAGE_EXPORT_ERROR = new ErrorCode(100004, "Package export error", true);
  public static final ErrorCode PACKAGE_SAVE_ERROR = new ErrorCode(100005, "Package save error", true);
  public static final ErrorCode PACKAGE_IS_NOT_VALID = new ErrorCode(100006, "Package is not valid", true);
  public static final ErrorCode PACKAGE_UNINSTALL_WAS_INCOMPLETE = new ErrorCode(100040, "Package uninstall was incomplete", true);
  public static final ErrorCode PACKAGE_RESOURCE_TYPE_IS_NOT_SUPPORTED = new ErrorCode(100180, "Resource type is not supported", true);
  public static final ErrorCode PACKAGE_OPERATION_HAS_FAILED = new ErrorCode(100181, "Package operation has failed", true);
  public static final ErrorCode PACKAGE_CONTAINS_DUPLICATED_RESOURCES = new ErrorCode(100182, "Package contains duplicated resources", true);
  public static final ErrorCode PACKAGE_FEDERATION_ADAPTER_DOESNT_EXIST = new ErrorCode(102001, "Error in deploying package: Adapter doesn't exist", true);

  public ErrorCode(int code, String codeDescription)
  {
    this(code, codeDescription, false);
  }

  public ErrorCode(int code, String codeDescription, boolean register) {
    this._code = code;
    this._description = codeDescription;
    if (register)
      registerErrorCode(code, this);
  }

  private static synchronized void registerErrorCode(int code, ErrorCode errorCode)
  {
    if (errorCodes == null) {
      errorCodes = new HashMap();
    }

    errorCodes.put(Integer.valueOf(code), errorCode);
  }

  public static ErrorCode getErrorCode(int code) {
    return ((ErrorCode)errorCodes.get(Integer.valueOf(code)));
  }

  public int getCode()
  {
    return this._code;
  }

  public String getDescription() {
    return this._description;
  }

  public boolean isParameterizedErrorCode() {
    return false;
  }

  public int hashCode() {
    return this._code;
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if ((o == null) || (!(o instanceof ErrorCode))) return false;
    ErrorCode errorCode = (ErrorCode)o;
    return (this._code == errorCode._code);
  }

  public String toString() {
    return "[" + this._code + "] " + this._description;
  }
}