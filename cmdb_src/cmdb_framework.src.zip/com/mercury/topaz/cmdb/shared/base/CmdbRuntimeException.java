package com.mercury.topaz.cmdb.shared.base;

public class CmdbRuntimeException extends CmdbException
{
  public CmdbRuntimeException(String message)
  {
    super(message);
  }

  public CmdbRuntimeException(String message, ErrorCode errorCode) {
    super(message, errorCode);
  }

  public CmdbRuntimeException(String message, Throwable cause) {
    super(message, cause);
  }

  public CmdbRuntimeException(String message, Throwable cause, ErrorCode errorCode) {
    super(message, cause, errorCode);
  }

  public CmdbRuntimeException(Throwable cause) {
    super(cause);
  }

  public CmdbRuntimeException(Throwable cause, ErrorCode errorCode) {
    super(cause, errorCode);
  }
}