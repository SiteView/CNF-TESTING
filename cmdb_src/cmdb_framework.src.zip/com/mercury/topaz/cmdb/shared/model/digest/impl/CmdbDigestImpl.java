package com.mercury.topaz.cmdb.shared.model.digest.impl;

import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.ObjectStreamException;

class CmdbDigestImpl extends AbstractCMDBDigest
{
  CmdbDigestImpl(String idDataStr)
  {
    super(idDataStr);
  }

  CmdbDigestImpl(long mostSign, long leastSign) {
    super(mostSign, leastSign);
  }

  public CmdbDigestImpl(ReadOnlyIterator digests, int size) {
    super(digests, size);
  }

  protected Object doReadResolve() throws ObjectStreamException {
    return CmdbDigestFactory.obtainDigest(this);
  }
}