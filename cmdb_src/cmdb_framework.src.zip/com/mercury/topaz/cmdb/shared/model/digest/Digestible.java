package com.mercury.topaz.cmdb.shared.model.digest;

public abstract interface Digestible
{
  public abstract CmdbDigest getDigest();
}