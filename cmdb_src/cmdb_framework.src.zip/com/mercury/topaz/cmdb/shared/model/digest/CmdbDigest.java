package com.mercury.topaz.cmdb.shared.model.digest;

public abstract interface CmdbDigest
{
  public abstract long getMostSign();

  public abstract long getLeastSign();
}