package com.mercury.topaz.cmdb.shared.model.digest.impl;

import com.mercury.topaz.cmdb.shared.bean.factory.CmdbImmutableBeanFactory;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class CmdbDigestFactory extends CmdbImmutableBeanFactory
{
  public static CmdbDigest generateDigest(String idDataStr)
  {
    return new CmdbDigestImpl(idDataStr);
  }

  public static CmdbDigest generateDigest(ReadOnlyIterator digests, int size)
  {
    return new CmdbDigestImpl(digests, size);
  }

  public static CmdbDigest restoreDigest(long mostSign, long leastSign)
  {
    return new CmdbDigestImpl(mostSign, leastSign);
  }

  public static CmdbDigest restoreDigest(byte[] digest)
  {
    if (digest == null)
      throw new IllegalArgumentException("Can't restore digest from null byte array");

    CmdbDigestImpl ret = new CmdbDigestImpl();
    ret.setFromDigest(digest);
    return ret;
  }

  public static CmdbDigest restoreDigest(String toStringData)
  {
    return restoreDigest(AbstractCMDBDigest.fromToStringDataToBytes(toStringData));
  }

  public static CmdbDigest obtainDigest(CmdbDigest digest)
  {
    return digest;
  }
}