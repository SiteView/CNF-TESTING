package com.mercury.topaz.cmdb.shared.model.changer.impl;

import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.ChangerType;

public class ChangerFactory
{
  public static final String UCMDB_DATASTORE = "UCMDB";

  @Deprecated
  public static Changer createChanger(ChangerType changerType, String changerInfo)
  {
    return new ChangerImpl(changerType.getType(), changerInfo); }

  public static Changer createChanger(String datastoreOrigin, String changerInfo) {
    return new ChangerImpl(datastoreOrigin, changerInfo);
  }
}