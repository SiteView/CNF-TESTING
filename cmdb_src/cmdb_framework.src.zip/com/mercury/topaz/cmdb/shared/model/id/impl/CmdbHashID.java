package com.mercury.topaz.cmdb.shared.model.id.impl;

import com.mercury.topaz.cmdb.shared.change.id.ChangeListenerID;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.ObjectStreamException;

public class CmdbHashID extends AbstractCMDBDigest
  implements ChangeListenerID, FrameworkID
{
  public CmdbHashID(CmdbDigest other)
  {
    super(other);
  }

  protected CmdbHashID(String idDataStr)
  {
    super(idDataStr);
  }

  protected CmdbHashID(byte[] idDataBytes)
  {
    super(idDataBytes);
  }

  protected CmdbHashID(long mostSign, long leastSign) {
    super(mostSign, leastSign);
  }

  protected CmdbHashID(ReadOnlyIterator digests, int size) {
    super(digests, size);
  }

  protected CmdbHashID(ReadOnlyIterator digests, int size, boolean needToSortIterator) {
    super(digests, size, needToSortIterator);
  }

  public boolean isObjectID() {
    throw new UnsupportedOperationException("idObject isn't implemented");
  }

  protected void setFromDigest(byte[] digest)
  {
    super.setFromDigest(digest);
  }

  protected Object doReadResolve() throws ObjectStreamException {
    return FrameworkID.Factory.restoreObjectID(getMostSign(), getLeastSign());
  }
}