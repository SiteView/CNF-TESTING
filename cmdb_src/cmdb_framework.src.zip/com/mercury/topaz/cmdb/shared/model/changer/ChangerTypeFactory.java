package com.mercury.topaz.cmdb.shared.model.changer;

public class ChangerTypeFactory
{
  public static ChangerType createChangerType(String type)
  {
    return new ChangerType(type);
  }
}