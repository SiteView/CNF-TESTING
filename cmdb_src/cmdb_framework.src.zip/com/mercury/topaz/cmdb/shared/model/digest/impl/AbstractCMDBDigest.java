package com.mercury.topaz.cmdb.shared.model.digest.impl;

import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.bean.AbstractCmdbImmutableBean;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;
import com.mercury.topaz.cmdb.shared.model.digest.Digestible;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public abstract class AbstractCMDBDigest extends AbstractCmdbImmutableBean
  implements CmdbDigest, Comparable
{
  private static final char[] intToHexChar = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
  private static final String CHARSET_ENCODING = "UTF-8";
  private static transient MessageDigest md;
  private long _mostSign;
  private long _leastSign;

  protected AbstractCMDBDigest(CmdbDigest other)
  {
    this._mostSign = other.getMostSign();
    this._leastSign = other.getLeastSign();
  }

  protected AbstractCMDBDigest(String digestRawData)
  {
    byte[] idDataBytes = null;
    try {
      idDataBytes = (digestRawData == null) ? "empty".getBytes("UTF-8") : digestRawData.getBytes("UTF-8");
    } catch (UnsupportedEncodingException e) {
      throw new CmdbException("cannot create bytes from string due to error ", e);
    }

    byte[] digest = createDigest(idDataBytes);

    setFromDigest(digest);
  }

  protected AbstractCMDBDigest(byte[] digestAsBytes)
  {
    setFromDigest(digestAsBytes);
  }

  public static byte[] createDigest(byte[] idDataBytes)
  {
    byte[] digest;
    synchronized (md) {
      md.reset();
      md.update(idDataBytes);
      digest = md.digest();
    }
    return digest;
  }

  public AbstractCMDBDigest(ReadOnlyIterator digestsIterator, int size, boolean needToSortIterator)
  {
    if ((digestsIterator == null) || (size < 0)) {
      throw new IllegalArgumentException("can't creats digest: got negative size [size=" + size + "] or null digestsIterator ");
    }

    AbstractCMDBDigest[] digests = new AbstractCMDBDigest[size];

    int i = 0;
    for (; (digestsIterator.hasNext()) && (i < digests.length); ++i) {
      Digestible digestible = (Digestible)digestsIterator.next();
      digests[i] = ((AbstractCMDBDigest)digestible.getDigest());
    }

    if (i < size) {
      throw new IllegalArgumentException("can't creats digest: got invalid size [size=" + size + "] expexted [" + i + "]");
    }

    if (digestsIterator.hasNext()) {
      int count = 0;
      while (digestsIterator.hasNext()) {
        digestsIterator.next();
        ++count;
      }
      throw new IllegalArgumentException("can't creats digest: got invalid size [size=" + size + "] expexted [" + (count + i) + "]");
    }

    if (needToSortIterator) {
      Arrays.sort(digests);
    }

    synchronized (md) {
      md.reset();

      for (i = 0; i < digests.length; ++i) {
        md.update(toBytes(digests[i]));
      }

      digest = md.digest();
    }

    setFromDigest(digest);
  }

  public AbstractCMDBDigest(ReadOnlyIterator digestsIterator, int size) {
    this(digestsIterator, size, true);
  }

  public static byte[] toBytes(AbstractCMDBDigest digest)
  {
    byte[] bytes = new byte[16];
    getBytesFromLong(digest._mostSign, bytes, 0);
    getBytesFromLong(digest._leastSign, bytes, 8);
    return bytes;
  }

  protected AbstractCMDBDigest(long mostSign, long leastSign)
  {
    this._mostSign = mostSign;
    this._leastSign = leastSign;
  }

  protected void setFromDigest(byte[] digest) {
    this._mostSign = getLongFromBytes(digest, 0);
    this._leastSign = getLongFromBytes(digest, 8);
  }

  public boolean equals(Object obj)
  {
    if ((obj == null) || (!(obj instanceof AbstractCMDBDigest))) {
      return false;
    }

    AbstractCMDBDigest otherID = (AbstractCMDBDigest)obj;

    return ((this == obj) || ((this._mostSign == otherID._mostSign) && (this._leastSign == otherID._leastSign)));
  }

  public String toString()
  {
    byte[] bytes = toBytes(this);
    char[] ret = new char[32];
    for (int i = 0; i < bytes.length; ++i) {
      ret[(2 * i)] = intToHexChar[(bytes[i] >> 4 & 0xF)];
      ret[(2 * i + 1)] = intToHexChar[(bytes[i] & 0xF)];
    }

    return new String(ret);
  }

  public int hashCode()
  {
    long tmp = this._mostSign ^ this._leastSign;
    return (int)(tmp ^ tmp >>> 32);
  }

  private static long getLongFromBytes(byte[] src, int offset)
  {
    return (((src[(offset + 0)] & 0xFF) << 56) + ((src[(offset + 1)] & 0xFF) << 48) + ((src[(offset + 2)] & 0xFF) << 40) + ((src[(offset + 3)] & 0xFF) << 32) + ((src[(offset + 4)] & 0xFF) << 24) + ((src[(offset + 5)] & 0xFF) << 16) + ((src[(offset + 6)] & 0xFF) << 8) + (src[(offset + 7)] & 0xFF));
  }

  private static void getBytesFromLong(long src, byte[] dst, int offset)
  {
    dst[(offset + 0)] = (byte)(int)(src >> 56 & 0xFF);
    dst[(offset + 1)] = (byte)(int)(src >> 48 & 0xFF);
    dst[(offset + 2)] = (byte)(int)(src >> 40 & 0xFF);
    dst[(offset + 3)] = (byte)(int)(src >> 32 & 0xFF);
    dst[(offset + 4)] = (byte)(int)(src >> 24 & 0xFF);
    dst[(offset + 5)] = (byte)(int)(src >> 16 & 0xFF);
    dst[(offset + 6)] = (byte)(int)(src >> 8 & 0xFF);
    dst[(offset + 7)] = (byte)(int)(src & 0xFF);
  }

  public static byte[] fromToStringDataToBytes(String toStringData)
  {
    if ((toStringData == null) || (toStringData.length() != 32)) {
      throw new IllegalArgumentException("The input data is not a toString result of the AbstractCMDBDigest: " + toStringData);
    }

    byte[] digest = new byte[16];
    try
    {
      for (int i = 0; i < digest.length; ++i)
      {
        char c = toStringData.charAt(i << 1);
        digest[i] = (byte)(hexCharToInt(c) << 4);
        c = toStringData.charAt((i << 1) + 1);
        digest[i] = (byte)(digest[i] + hexCharToInt(c));
      }
    }
    catch (IllegalArgumentException exc) {
      throw new IllegalArgumentException("The input data is not a toString result of the AbstractCMDBDigest: " + toStringData);
    }
    return digest;
  }

  private static int hexCharToInt(char c) {
    if ((c <= '9') && (c >= '0'))
      return (c - '0');

    if ((c >= 'a') && (c <= 'f')) {
      return (c - 'a' + 10);
    }

    throw new IllegalArgumentException("Not a Hex character: " + c);
  }

  public CmdbDigest getDigest()
  {
    return this;
  }

  public int compareTo(Object o) {
    if (!(o instanceof AbstractCMDBDigest)) {
      return 1;
    }

    AbstractCMDBDigest other = (AbstractCMDBDigest)o;

    int most = compareLongs(this._mostSign, other._mostSign);
    return ((most != 0) ? most : compareLongs(this._leastSign, other._leastSign));
  }

  private static int compareLongs(long thisVal, long otherVal) {
    return ((thisVal == otherVal) ? 0 : (thisVal < otherVal) ? -1 : 1);
  }

  public long getMostSign() {
    return this._mostSign;
  }

  public long getLeastSign() {
    return this._leastSign;
  }

  static
  {
    try
    {
      md = MessageDigest.getInstance("MD5");
    }
    catch (NoSuchAlgorithmException e)
    {
    }
  }
}