package com.mercury.topaz.cmdb.shared.model.id.impl;

import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class AbstractCMDBIDFactory extends AbstractIDFactory<CmdbHashID>
{
  protected CmdbHashID createCmdbID(String idDataStr)
  {
    return new CmdbHashID(idDataStr);
  }

  protected CmdbHashID createCmdbID(ReadOnlyIterator ids, int size, boolean needToSortIterator)
  {
    return new CmdbHashID(ids, size, needToSortIterator);
  }

  protected CmdbHashID createCmdbID(long mostSign, long leastSign)
  {
    return new CmdbHashID(mostSign, leastSign);
  }

  protected CmdbHashID createCmdbID(byte[] digest) {
    return new CmdbHashID(digest);
  }

  protected CmdbHashID createCmdbID() {
    return new CmdbHashID();
  }
}