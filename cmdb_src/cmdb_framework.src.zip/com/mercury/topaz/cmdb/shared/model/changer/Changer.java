package com.mercury.topaz.cmdb.shared.model.changer;

import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import java.io.Serializable;

public abstract interface Changer extends Serializable
{
  public static final Changer EMPTY_CHANGER = ChangerFactory.createChanger(ChangerType.EMPTY.getType(), "Unknown");

  public abstract String getChangerInfo();

  @Deprecated
  public abstract ChangerType getChangerType();

  public abstract String getDataStoreOrigin();
}