package com.mercury.topaz.cmdb.shared.model.id.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.util.Random;

public class CmdbRandomID extends CmdbHashID
{
  private static final Random _rand;
  private static String _localHost;

  public CmdbRandomID()
  {
    super(getRandomString());
  }

  public CmdbRandomID(String idDataStr)
  {
    super(getRandomString() + idDataStr);
  }

  public static String getRandomString()
  {
    StringBuffer valueBeforeMD5 = new StringBuffer();
    long time = System.currentTimeMillis();

    long rand = nextRandomLong();

    valueBeforeMD5.append(_localHost);
    valueBeforeMD5.append(":");
    valueBeforeMD5.append(Long.toString(time));
    valueBeforeMD5.append(":");
    valueBeforeMD5.append(Long.toString(rand));

    return valueBeforeMD5.toString();
  }

  private static long nextRandomLong()
  {
    long nextLong;
    synchronized (_rand) {
      nextLong = _rand.nextLong();
    }
    return nextLong;
  }

  static
  {
    SecureRandom _secureRand = new SecureRandom();
    long secureInitializer = _secureRand.nextLong();
    _rand = new Random(secureInitializer);
    try {
      _localHost = InetAddress.getLocalHost().toString();
    }
    catch (UnknownHostException e)
    {
      _localHost = "localhost";
    }
  }
}