package com.mercury.topaz.cmdb.shared.model.changer;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ChangerType
  implements Serializable
{
  public static Map _instances = new HashMap();
  public static final ChangerType EMPTY = new ChangerType("Unknown");
  public static final ChangerType USER = new ChangerType("User");
  public static final ChangerType DISCOVERY = new ChangerType("Discovery");
  public static final ChangerType ENRICHMENT = new ChangerType("Enrichment");
  public static final ChangerType ADAPTER = new ChangerType("Adapter");
  public static final ChangerType EXTERNAL_ENRICHMENT = new ChangerType("ExternalEnrichment");
  public static final ChangerType INITIALIZATION = new ChangerType("Initialization");
  public static final ChangerType CMDB = new ChangerType("CMDB");
  public static final ChangerType CMDB_OPEN_API = new ChangerType("CMDB Open API");
  public static final ChangerType CALLER_APP = new ChangerType("CallerApplication");
  public static final ChangerType CMDB_UPGRADE = new ChangerType("CmdbUpgrade");
  private String _changerType;

  protected ChangerType(String changerType)
  {
    setChangerType(changerType);
    _instances.put(getChangerType(), this);
  }

  protected Object doReadResolve() throws ObjectStreamException {
    return _instances.get(getChangerType());
  }

  private String getChangerType() {
    return this._changerType;
  }

  private void setChangerType(String changerType) {
    if (changerType == null)
      throw new IllegalArgumentException("changer type is null!!!");

    this._changerType = changerType;
  }

  public String toString() {
    return getChangerType().toString();
  }

  public String getType() {
    return getChangerType();
  }

  public static ChangerType getChangerTypeByString(String type) {
    return ((ChangerType)_instances.get(type));
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if (!(o instanceof ChangerType)) {
      return false;
    }

    ChangerType changerType = (ChangerType)o;

    if (this._changerType != null) if (this._changerType.equals(changerType._changerType)) break label54;
    label54: return (changerType._changerType == null);
  }

  public int hashCode()
  {
    return ((this._changerType != null) ? this._changerType.hashCode() : 0);
  }
}