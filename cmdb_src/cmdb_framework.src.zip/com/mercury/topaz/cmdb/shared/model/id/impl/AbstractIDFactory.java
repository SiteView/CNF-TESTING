package com.mercury.topaz.cmdb.shared.model.id.impl;

import com.mercury.topaz.cmdb.shared.bean.CmdbImmutableBean;
import com.mercury.topaz.cmdb.shared.bean.factory.CmdbImmutableBeanFactory;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public abstract class AbstractIDFactory<T extends CmdbImmutableBean> extends CmdbImmutableBeanFactory<T>
{
  protected abstract T createCmdbID(String paramString);

  protected abstract T createCmdbID(ReadOnlyIterator paramReadOnlyIterator, int paramInt, boolean paramBoolean);

  protected abstract T createCmdbID(long paramLong1, long paramLong2);

  protected abstract T createCmdbID(byte[] paramArrayOfByte);

  protected abstract T createCmdbID();

  protected CmdbImmutableBean createCmdbRandomID()
  {
    return new CmdbRandomID();
  }

  protected T createHashID(String idDataStr)
  {
    return createHashID(idDataStr, true);
  }

  protected T createHashID(String idDataStr, boolean useCaching)
  {
    CmdbImmutableBean newID = createCmdbID(idDataStr);
    if (useCaching)
      return obtainObject(newID);

    return newID;
  }

  protected T createHashID(ReadOnlyIterator ids, int size)
  {
    return createHashID(ids, size, true);
  }

  protected T createHashID(ReadOnlyIterator ids, int size, boolean useCache) {
    return createID(ids, size, true, useCache);
  }

  protected CmdbImmutableBean createHashIDWithSortedIterator(ReadOnlyIterator ids, int size) {
    return createHashIDWithSortedIterator(ids, size, true);
  }

  protected CmdbImmutableBean createHashIDWithSortedIterator(ReadOnlyIterator ids, int size, boolean useCache) {
    return createID(ids, size, false, useCache);
  }

  private T createID(ReadOnlyIterator ids, int size, boolean needToSortIterator, boolean useCache) {
    CmdbImmutableBean createdID = createID(ids, size, needToSortIterator);
    if (useCache)
      createdID = obtainObject(createdID);

    return createdID;
  }

  private T createID(ReadOnlyIterator ids, int size, boolean needToSortIterator) {
    return createCmdbID(ids, size, needToSortIterator);
  }

  protected CmdbImmutableBean createRandomID()
  {
    return createCmdbRandomID();
  }

  protected CmdbImmutableBean createRandomID(String seed)
  {
    return new CmdbRandomID(seed);
  }

  protected CmdbImmutableBean restoreID(long mostSign, long leastSign)
  {
    return obtainObject(createCmdbID(mostSign, leastSign));
  }

  protected CmdbImmutableBean restoreID(byte[] digest)
  {
    return restoreID(digest, true);
  }

  protected T restoreID(byte[] digest, boolean useCache) {
    CmdbImmutableBean restoredID = restoreIDWithoutCache(digest);
    if (useCache)
      restoredID = obtainObject(restoredID);

    return restoredID;
  }

  private T restoreIDWithoutCache(byte[] digest) {
    return createCmdbID(digest);
  }

  protected CmdbImmutableBean restoreID(String toStringData)
  {
    return restoreID(toStringData, true);
  }

  protected CmdbImmutableBean restoreID(String toStringData, boolean useCaching)
  {
    CmdbImmutableBean id = createCmdbID(AbstractCMDBDigest.fromToStringDataToBytes(toStringData));

    if (useCaching)
      return obtainObject(id);

    return id;
  }

  protected T obtainID(T id)
  {
    if (!(id instanceof CmdbHashID))
      throw new IllegalArgumentException("Attenpt to obtain ID [class=" + id.getClass() + "]that isn't instance of CmdbHashID.");

    return obtainObject(id);
  }

  protected int getTotalIDs()
  {
    return getSize();
  }

  public static String createRandomStringID()
  {
    return new CmdbRandomID().toString();
  }
}