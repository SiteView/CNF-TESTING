package com.mercury.topaz.cmdb.shared.model.changer.impl;

import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.ChangerType;
import com.mercury.topaz.cmdb.shared.model.changer.ChangerTypeFactory;

class ChangerImpl
  implements Changer
{
  private String _changerInfo;
  private ChangerType _changerType;
  private String _datastoreOrigin;

  ChangerImpl(String datastore, String changerInfo)
  {
    setChangerInfo(changerInfo);
    setChangerType(ChangerTypeFactory.createChangerType(datastore));
    setDatastoreOrigin(datastore);
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if (!(o instanceof ChangerImpl)) {
      return false;
    }

    ChangerImpl changer = (ChangerImpl)o;

    if (this._changerInfo != null) if (this._changerInfo.equals(changer._changerInfo)) break label54; 
    else if (changer._changerInfo == null) break label54;
    return false;

    if (this._changerType != null) label54: if (this._changerType.equals(changer._changerType)) break label87; 
    else if (changer._changerType == null) break label87;
    return false;

    if (this._datastoreOrigin != null) label87: if (this._datastoreOrigin.equals(changer._datastoreOrigin)) break label120;
    label120: return (changer._datastoreOrigin == null);
  }

  public int hashCode()
  {
    int result = (this._changerInfo != null) ? this._changerInfo.hashCode() : 0;
    result = 29 * result + ((this._datastoreOrigin != null) ? this._datastoreOrigin.hashCode() : 0);
    result = 29 * result + ((this._changerType != null) ? this._changerType.hashCode() : 0);
    return result;
  }

  public String getChangerInfo() {
    return this._changerInfo;
  }

  public ChangerType getChangerType() {
    return this._changerType;
  }

  public String getDataStoreOrigin() {
    return this._datastoreOrigin;
  }

  private void setChangerInfo(String changerInfo) {
    if (changerInfo == null)
      throw new IllegalArgumentException("changer info is null");

    this._changerInfo = changerInfo;
  }

  private void setChangerType(ChangerType changerType) {
    if (changerType == null)
      throw new IllegalArgumentException("changer type is null");

    this._changerType = changerType;
  }

  private void setDatastoreOrigin(String datastore) {
    if (datastore == null)
      throw new IllegalArgumentException("datastore origin is null");

    this._datastoreOrigin = datastore;
  }

  public String toString() {
    return getDataStoreOrigin() + ": " + getChangerInfo();
  }
}