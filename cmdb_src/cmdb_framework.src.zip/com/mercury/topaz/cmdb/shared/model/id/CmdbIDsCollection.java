package com.mercury.topaz.cmdb.shared.model.id;

import com.mercury.topaz.cmdb.shared.util.CmdbCollection;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public abstract interface CmdbIDsCollection<T> extends CmdbCollection<T>
{
  public abstract ReadOnlyIterator<T> getIdsIterator();
}