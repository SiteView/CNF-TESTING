package appilog.framework.client.manage.api;

public abstract interface MamHttpApi extends MamApi
{
  public abstract void init(String paramString1, String paramString2);

  public abstract void initClientByUrl(String paramString1, String paramString2, String paramString3);

  public abstract void initHttps(String paramString1, String paramString2);

  public abstract void initHttps(String paramString1, String paramString2, String paramString3);

  public abstract void init(String paramString1, String paramString2, String paramString3);
}