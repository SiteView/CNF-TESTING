package appilog.framework.client.manage.api.impl;

import appilog.framework.client.manage.api.MamApi;
import appilog.framework.client.manage.api.MamHttpApi;
import appilog.framework.client.manage.api.http.MamHttpApiImpl;
import appilog.framework.shared.base.MamException;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi.TYPE;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApiEnvironment;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiRmiImpl;
import com.mercury.topaz.cmdb.client.manage.api.impl.RmiEnvironment;

public class MamApiFactory
{
  public static MamApi createAPI(CmdbApi.TYPE type, CmdbApiEnvironment apiEnvironment)
    throws MamException
  {
    return ((MamApi)CmdbApiFactory.createCMDBAPI(type, apiEnvironment));
  }

  public static MamApi createAPI(CmdbApi.TYPE type)
    throws MamException
  {
    if (type == CmdbApi.HTTP_TYPE)
      return new MamHttpApiImpl();
    if (type == CmdbApi.RMI_TYPE)
      return createNotControlledAPI();

    return ((MamApi)CmdbApiFactory.createCMDBAPI(type));
  }

  public static MamApi createAPI()
    throws MamException
  {
    return ((MamApi)CmdbApiFactory.createCMDBAPI());
  }

  public static MamHttpApi createHttpAPI() throws MamException {
    return ((MamHttpApi)createAPI(CmdbApi.HTTP_TYPE));
  }

  public static MamApi createNotControlledAPI()
    throws MamException
  {
    String hostName = System.getProperty("MamURL");
    CmdbApiEnvironment apiEnvironment = new RmiEnvironment(hostName);

    return new CmdbApiRmiImpl(apiEnvironment);
  }
}