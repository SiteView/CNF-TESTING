package appilog.framework.client.manage.api.http;

import appilog.framework.client.manage.api.MamHttpApi;
import appilog.framework.shared.base.MamException;
import appilog.framework.shared.clients.MamOperationClient;
import appilog.framework.shared.manage.MamResponse;
import appilog.framework.shared.manage.impl.MamHttpRequestImpl;
import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.topaz.cmdb.client.manage.api.impl.AbstractCmdbApi;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MamHttpApiImpl extends AbstractCmdbApi
  implements MamHttpApi
{
  private MamOperationClient client;
  private static Pattern pattern = Pattern.compile("([a-z0-9-\\._^:]+)(:)([0-9]+)");
  private String userName;
  private String password;

  public MamHttpApiImpl()
  {
    this.userName = null;
    this.password = null; }

  public void init(String userName, String password) {
    initClient(userName, password, "http");
  }

  private void initClient(String userName, String password, String protocol) {
    String serverAddressPort = System.getProperty("MamHttpURL");
    initClient(userName, password, serverAddressPort, protocol);
  }

  public void init(String userName, String password, String serverAddressPort) {
    initClient(userName, password, serverAddressPort, "http");
  }

  private void initClient(String userName, String password, String serverAddressPort, String protocol) {
    this.userName = userName;
    this.password = password;
    if (serverAddressPort == null)
      throw new MamException("server address is null", -1);

    if (!(pattern.matcher(serverAddressPort).matches()))
      throw new MamException("malformed server address, the server address should be obey the pattern: <server>:<port>", -1);

    this.client = new MamOperationClient(protocol + "://" + serverAddressPort + "/mam");
  }

  public void initClientByUrl(String userName, String password, String url) {
    this.userName = userName;
    this.password = password;
    this.client = new MamOperationClient(url);
  }

  public void initHttps(String userName, String password) {
    initClient(userName, password, "https");
  }

  public void initHttps(String userName, String password, String serverAddressPort) {
    initClient(userName, password, serverAddressPort, "https");
  }

  protected MamResponse handleRequest(CmdbRequest request) throws MamResponseException {
    return this.client.executeOperation(new MamHttpRequestImpl(request, this.userName, this.password));
  }
}