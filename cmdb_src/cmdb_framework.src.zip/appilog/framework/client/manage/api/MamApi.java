package appilog.framework.client.manage.api;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;

public abstract interface MamApi extends CmdbApi
{
}