package appilog.framework.shared.manage.customer.id;

import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public abstract interface MamCustomerID extends CmdbCustomerID
{
}