package appilog.framework.shared.manage;

import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;

public abstract interface MamHttpRequest extends CmdbRequest
{
  public abstract String getUserName();

  public abstract String getPassword();
}