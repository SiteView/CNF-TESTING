package appilog.framework.shared.manage.impl;

import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;

public class MamResponseException extends CmdbResponseException
{
  private static final long serialVersionUID = -399486630L;

  public MamResponseException(Throwable cause, String id)
  {
    super(cause, id);
  }

  public MamResponseException(Throwable cause, String id, ErrorCode errorCode) {
    super(cause, id, errorCode);
  }

  public MamResponseException(String id) {
    super(id);
  }

  public MamResponseException(String message, Throwable cause, String id) {
    super(message, cause, id);
  }

  public MamResponseException(String message, String id) {
    super(message, id);
  }

  public MamResponseException(String message, Throwable cause, String id, ErrorCode errorCode) {
    super(message, cause, id, errorCode);
  }
}