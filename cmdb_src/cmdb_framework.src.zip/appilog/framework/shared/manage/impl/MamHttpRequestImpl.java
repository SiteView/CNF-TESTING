package appilog.framework.shared.manage.impl;

import appilog.framework.shared.manage.MamHttpRequest;
import com.mercury.topaz.cmdb.shared.manage.CmdbRequest;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbReqestImpl;

public class MamHttpRequestImpl extends CmdbReqestImpl
  implements MamHttpRequest
{
  private String password;
  private String userName;

  public MamHttpRequestImpl(CmdbRequest impl)
  {
    this(impl, null, null); }

  public MamHttpRequestImpl(CmdbRequest impl, String userName, String password) {
    super(impl.getMessage(), impl.getContext(), impl.getOperation(), impl.isSynchronic());
    this.userName = userName;
    this.password = password;
  }

  public String getUserName() {
    return this.userName; }

  public String getPassword() {
    return this.password;
  }
}