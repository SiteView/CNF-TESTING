package appilog.framework.shared.manage.impl;

import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.MamHttpResponse;
import appilog.framework.shared.manage.MamResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID.Factory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseImpl;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.io.Serializable;

public class MamHttpResponseImpl
  implements MamHttpResponse
{
  private MamResponseException exception;
  private MamResponse response;
  private byte[] binaryResponse;

  public MamHttpResponseImpl(MamResponseException exception)
  {
    this.exception = exception;
  }

  public MamHttpResponseImpl(MamResponse response) {
    this.response = response;
  }

  public MamHttpResponseImpl(byte[] binaryResponse) {
    this.binaryResponse = binaryResponse;
  }

  public String getID() {
    return getResponse().getID();
  }

  public void setMessage(String message) {
    getResponse().setMessage(message);
  }

  public long getServerRunningTime() {
    return getResponse().getServerRunningTime();
  }

  public void setServerRunningTime(long serverRunningTime) {
    getResponse().setServerRunningTime(serverRunningTime);
  }

  public Object getResult(String resultKey) {
    return getResponse().getResult(resultKey);
  }

  public void addResult(String resultKey, Serializable resultObject) {
    getResponse().addResult(resultKey, resultObject);
  }

  public MamContext getContext() {
    return getResponse().getContext();
  }

  private MamResponse getResponse()
  {
    rethrow();
    return this.response;
  }

  public void rethrow()
    throws MamResponseException
  {
    if (this.exception != null)
      throw this.exception;
  }

  public void setException(MamResponseException exception)
  {
    this.exception = exception;
  }

  public String getMessage()
  {
    return getResponse().getMessage();
  }

  public boolean hasResultKey(String resultKey) {
    return getResponse().hasResultKey(resultKey);
  }

  public Iterable<String> iterator() {
    return getResponse().iterator();
  }

  public FrameworkOperation getRedirectedOperation() {
    return null;
  }

  public boolean isRedirected() {
    return false;
  }

  public void redirectToOperation(FrameworkOperation operation) {
  }

  private void writeObject(ObjectOutputStream stream) throws IOException {
    stream.writeObject(this.exception);
    stream.writeObject(this.response);
    if (this.binaryResponse != null) {
      stream.writeInt(this.binaryResponse.length);
      stream.write(this.binaryResponse);
    } else {
      stream.writeInt(0);
    }
  }

  private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
    this.exception = ((MamResponseException)stream.readObject());
    this.response = ((MamResponse)stream.readObject());
    int responseLength = stream.readInt();
    if (responseLength > 0)
    {
      this.response = ((MamResponse)new ObjectInputStream(stream).readObject());
    }
  }

  private static void testSerialization(MamResponse response, MamResponseException ex) throws IOException, ClassNotFoundException {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    ObjectOutputStream oos = new ObjectOutputStream(baos);
    oos.writeObject(response);
    oos.close();
    MamHttpResponseImpl mamHttpResponse = new MamHttpResponseImpl(baos.toByteArray());
    mamHttpResponse.setException(ex);
    ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
    ObjectOutputStream oos2 = new ObjectOutputStream(baos2);
    oos2.writeObject(mamHttpResponse);
    oos2.close();
    ByteArrayInputStream bais = new ByteArrayInputStream(baos2.toByteArray());
    ObjectInputStream ois = new ObjectInputStream(bais);
    MamHttpResponse result = (MamHttpResponse)ois.readObject();
    result.rethrow();
    System.out.println("result = " + result);
  }

  public static void main(String[] args) throws IOException, ClassNotFoundException {
    CmdbResponseImpl response = new CmdbResponseImpl("N/A", "id", CmdbContextFactory.createCmdbContext(CmdbCustomerID.Factory.createCMDBCustomerID(1), "caller"));
    testSerialization(response, null);
    MamResponseException ex = new MamResponseException("booo");
    testSerialization(ex, ex);
  }
}