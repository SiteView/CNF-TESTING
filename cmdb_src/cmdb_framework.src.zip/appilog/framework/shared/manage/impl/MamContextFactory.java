package appilog.framework.shared.manage.impl;

import appilog.framework.shared.manage.MamContext;
import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;

public class MamContextFactory
{
  public static MamContext create(CmdbCustomerID customerID, int userID, String callerApplicationName)
  {
    return ((MamContext)CmdbContextFactory.createCmdbContext(customerID, userID, callerApplicationName));
  }

  public static MamContext create(MamCustomerID customerID) {
    return ((MamContext)CmdbContextFactory.createCmdbContext(customerID, 911, "MAM_"));
  }

  public static MamContext createUserContext(CmdbCustomerID customerID, int userID, String callerApplicationName) {
    return ((MamContext)CmdbContextFactory.createCmdbContext(customerID, userID, callerApplicationName, true));
  }

  public static MamContext createUserContext(MamCustomerID customerID) {
    return ((MamContext)CmdbContextFactory.createCmdbContext(customerID, 911, "MAM_", true));
  }

  public static MamContext convert(CmdbContext context) {
    return ((MamContext)context);
  }

  public static CmdbContext convert(MamContext context) {
    return context;
  }
}