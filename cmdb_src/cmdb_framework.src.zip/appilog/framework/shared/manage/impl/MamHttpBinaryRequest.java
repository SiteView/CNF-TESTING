package appilog.framework.shared.manage.impl;

import appilog.framework.shared.manage.MamHttpRequest;
import com.mercury.topaz.cmdb.server.manage.subsystem.CommonManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID.Factory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbReqestImpl;
import com.mercury.topaz.cmdb.shared.manage.operation.FrameworkOperation;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCommonOperation;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.io.Serializable;

public class MamHttpBinaryRequest
  implements Serializable
{
  private CmdbContext context;
  private String serviceName;
  private String operationName;
  private byte[] binaryRequest;
  private final MamHttpRequest request;

  public MamHttpBinaryRequest(MamHttpRequest request)
  {
    this.request = request;
  }

  public CmdbContext getContext() {
    return this.context;
  }

  public String getServiceName() {
    return this.serviceName;
  }

  public String getOperationName() {
    return this.operationName;
  }

  public byte[] getBinaryRequest() {
    return this.binaryRequest;
  }

  private void writeObject(ObjectOutputStream stream) throws IOException {
    stream.writeObject(this.request.getContext());
    stream.writeUTF(this.request.getOperation().getServiceName());
    stream.writeUTF(this.request.getOperationName());
    ByteArrayOutputStream requestBinaryForm = new ByteArrayOutputStream();
    ObjectOutputStream requestOutputStream = new ObjectOutputStream(requestBinaryForm);
    requestOutputStream.writeObject(this.request);
    requestOutputStream.close();
    stream.writeObject(requestBinaryForm.toByteArray());
  }

  private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
    this.context = ((CmdbContext)stream.readObject());
    this.serviceName = stream.readUTF();
    this.operationName = stream.readUTF();
    this.binaryRequest = ((byte[])(byte[])stream.readObject());
  }

  private static void testSerialization(MamHttpRequest request) throws IOException, ClassNotFoundException {
    MamHttpBinaryRequest httpBinaryRequest = new MamHttpBinaryRequest(request);
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    ObjectOutputStream oos = new ObjectOutputStream(baos);
    oos.writeObject(httpBinaryRequest);
    oos.close();
    ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
    ObjectInputStream ois = new ObjectInputStream(bais);
    MamHttpBinaryRequest httpBinaryRequest2 = (MamHttpBinaryRequest)ois.readObject();
    ByteArrayInputStream bais2 = new ByteArrayInputStream(httpBinaryRequest2.getBinaryRequest());
    ObjectInputStream ois2 = new ObjectInputStream(bais2);
    MamHttpRequest request2 = (MamHttpRequest)ois2.readObject();
    System.out.println("result = " + request2);
  }

  public static void main(String[] args) throws IOException, ClassNotFoundException {
    CmdbContext context = CmdbContextFactory.createCmdbContext(CmdbCustomerID.Factory.createCMDBCustomerID(1), "caller");
    CmdbReqestImpl request = new CmdbReqestImpl(context, new TestOperation(null));
    MamHttpRequestImpl httpRequest = new MamHttpRequestImpl(request, "user", "password");
    testSerialization(httpRequest);
  }

  private static class TestOperation extends AbstractCommonOperation {
    protected void commonExecute(CommonManager manager, CmdbResponse response) throws CmdbException {
    }

    public String getOperationName() {
      return "Test Operation";
    }

    public String getExecutionTaskQueueName() {
      return "N/A";
    }

    public String getServiceName() {
      return "Test Service";
    }
  }
}