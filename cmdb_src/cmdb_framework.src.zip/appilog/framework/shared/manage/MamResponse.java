package appilog.framework.shared.manage;

import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract interface MamResponse extends CmdbResponse
{
}