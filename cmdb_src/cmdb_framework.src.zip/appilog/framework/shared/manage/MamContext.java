package appilog.framework.shared.manage;

import com.mercury.topaz.cmdb.shared.manage.CmdbContext;

public abstract interface MamContext extends CmdbContext
{
}