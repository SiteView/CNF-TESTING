package appilog.framework.shared.manage;

import appilog.framework.shared.manage.impl.MamResponseException;
import java.io.Serializable;

public abstract interface MamHttpResponse
{
  public abstract void rethrow()
    throws MamResponseException;

  public abstract void setException(MamResponseException paramMamResponseException);
}