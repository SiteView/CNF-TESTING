package appilog.framework.shared.clients;

import appilog.framework.shared.manage.MamHttpRequest;
import appilog.framework.shared.manage.MamHttpResponse;
import appilog.framework.shared.manage.MamResponse;
import appilog.framework.shared.manage.impl.MamHttpBinaryRequest;
import appilog.framework.shared.manage.impl.MamResponseException;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractUploadOperation;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MamOperationClient
{
  private String serverAddress;
  private String sessionId;

  public MamOperationClient(String serverAddress)
  {
    this.serverAddress = serverAddress;
  }

  public MamResponse executeOperation(MamHttpRequest request) {
    return doPost(request); }

  private MamResponse doPost(MamHttpRequest request) throws MamResponseException {
    String urlSuffix;
    try {
      ObjectOutputStream out;
      urlSuffix = "/operation";
      AbstractUploadOperation uploadOper = null;
      if (request.getOperation() instanceof AbstractUploadOperation) {
        urlSuffix = "/upload";
        uploadOper = (AbstractUploadOperation)request.getOperation();
      }
      HttpURLConnection connection = openConnection(urlSuffix);
      if (uploadOper != null)
      {
        connection.setChunkedStreamingMode(-1);
        out = new ObjectOutputStream(connection.getOutputStream());
        out.writeObject(request);
        InputStream in = uploadOper.openUploadStream();
        copyInputToOutput(in, out);
        uploadOper.closeUploadStream();
        out.close();
      } else {
        out = new ObjectOutputStream(connection.getOutputStream());
        out.writeObject(new MamHttpBinaryRequest(request));
        out.close();
      }
      if (this.sessionId == null)
        setSession(connection.getHeaderField("Set-Cookie"));

      MamHttpResponse response = readResponse(connection);
      response.rethrow();
      return response;
    }
    catch (MalformedURLException ex) {
      throw new MamResponseException(ex, request.getID());
    } catch (IOException ex) {
      throw new MamResponseException(ex, request.getID());
    } catch (ClassNotFoundException ex) {
      throw new MamResponseException(ex, request.getID());
    }
  }

  private HttpURLConnection openConnection(String urlSuffix) throws IOException {
    URL url = new URL(this.serverAddress + urlSuffix);
    HttpURLConnection connection = (HttpURLConnection)url.openConnection();
    if (this.sessionId != null)
      connection.setRequestProperty("Cookie", this.sessionId);

    connection.setUseCaches(false);
    connection.setDoOutput(true);
    connection.setRequestMethod("POST");
    return connection;
  }

  public void setSession(String session) {
    if (session != null) {
      int indexOf = session.indexOf(";");
      if (indexOf >= 0)
        session = session.substring(0, indexOf);

      this.sessionId = session;
    }
  }

  private MamHttpResponse readResponse(HttpURLConnection connection) throws IOException, ClassNotFoundException {
    InputStream is = connection.getInputStream();
    ObjectInputStream ois = new ObjectInputStream(is);
    return ((MamHttpResponse)ois.readObject());
  }

  private void copyInputToOutput(InputStream in, OutputStream out) throws IOException {
    byte[] buffer = new byte[10240];

    while ((bytesRead = in.read(buffer)) > 0) {
      int bytesRead;
      out.write(buffer, 0, bytesRead);
    }
  }
}