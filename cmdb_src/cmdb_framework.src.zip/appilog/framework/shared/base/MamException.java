package appilog.framework.shared.base;

import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.base.ExceptionWithErrorCode;

public class MamException extends RuntimeException
  implements ExceptionWithErrorCode
{
  private ErrorCode _error;
  private int _errorCode;
  public static final int DEFAULT_ERR_CODE = -1;

  /**
   * @deprecated
   */
  public MamException()
  {
    this(-1);
  }

  /**
   * @deprecated
   */
  public MamException(String message)
  {
    this(message, -1);
  }

  /**
   * @deprecated
   */
  public MamException(String message, Throwable cause)
  {
    this(message, cause, -1);
  }

  /**
   * @deprecated
   */
  public MamException(Throwable cause)
  {
    this(cause, -1);
    if (cause instanceof MamCheckedException)
      setErrorCode(((MamCheckedException)cause).getErrorCode());
    else if (cause instanceof CmdbException)
      setError(((CmdbException)cause).getError());
  }

  public MamException(MamCheckedException cause) {
    this(cause, cause.getErrorCode());
  }

  public MamException(int errorCode)
  {
    this._error = null;

    setErrorCode(errorCode);
  }

  public MamException(String message, int errorCode) {
    super(message);

    this._error = null;

    setErrorCode(errorCode);
  }

  public MamException(Throwable cause, int errorCode) {
    super(cause);

    this._error = null;

    setErrorCode(errorCode);
  }

  public MamException(String message, Throwable cause, int errorCode) {
    super(message, cause);

    this._error = null;

    setErrorCode(errorCode);
  }

  private void setError(ErrorCode error) {
    this._error = error; }

  public ErrorCode getError() {
    if (this._error == null)
    {
      this._error = new ErrorCode(this._errorCode, getMessage());
    }
    return this._error;
  }

  private void setErrorCode(int errorCode) {
    this._errorCode = errorCode;
  }

  public int getErrorCode() {
    return getError().getCode();
  }
}