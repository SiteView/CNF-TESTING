package appilog.framework.shared.base;

import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID.Factory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;

public final class MamConstants
{
  public static final int mamDefaultUserId = 911;
  public static final int mamDefaultCustomerId = 1;
  public static final String CallerAplicationName = "MAM_";
  public static final String NAMESPACE = "";

  public static class Monitor
  {
    public static class Names
    {
      public static final String VIEW_QUOTA_MONITOR_NAME = "Views Quota and Count";
      public static final String VIEW_QUOTA_MONITOR_DESC = "Compares the Views current count with the views quota.";
      public static final String SYMBOLS_QUOTA_MONITOR_NAME = "All Symbols Quota and Count";
      public static final String SYMBOLS_QUOTA_MONITOR_DESC = "Compares all symbols current count with all symbols quota.";
      public static final String VIEW_RESULT_SIZE_MONITOR_NAME = "Oversized Views";
      public static final String VIEW_RESULT_SIZE_MONITOR_DESC = "Finds views that are oversized. If find at least one oversized view the monitor fails.";
    }
  }

  public static final class Customer
  {
    public static final class Global
    {
      public static final MamCustomerID ID = MamCustomerID.Factory.createMamCustomerID(-2147483648);
    }

    public static final class Default
    {
      public static MamCustomerID ID = MamCustomerID.Factory.createMamCustomerID(1);
      public static CmdbContext CONTEXT = CmdbContextFactory.createCmdbContext(MamCustomerID.Factory.convert(ID), 911, "MAM_");

      public static void resetDefaultCustomerID(int mamDefaultCustomer)
      {
        ID = MamCustomerID.Factory.createMamCustomerID(mamDefaultCustomer);
        CONTEXT = CmdbContextFactory.createCmdbContext(MamCustomerID.Factory.convert(ID), 911, "MAM_");
      }
    }
  }

  public static final class HA
  {
    public static final String MAM_VIEW_SYS_SERVICE_NAME = "MAMVIEWSYS";
    public static final String MAM_PACKAGER_SERVICE_NAME = "MAMPACKAGER";
    public static final String MAM_BASIC_SERVICE_NAME = "MAMBASIC";
    public static final String MAM_CONFIG_SERVICE_NAME = "MAMCONFIG";
    public static final String MAM_IMPACT_SERVICE_NAME = "MAMIMPACT";
    public static final String MAM_REPORT_SERVICE_NAME = "MAMREPORT";
    public static final String MAM_DISCOVERY_SERVICE_NAME = "MAMDISCOVERY";

    public static final class Retry
    {
      public static final String MAM_CONTROL_RETRIES_NUMBER = "mamControllRetriesNum";
      public static final String MAM_CONTROL_RETRIES_INTERVAL = "mamControllInterval";
    }
  }

  public static final class DISPATCHER
  {
    public static final class Log
    {
      public static String LOGGER_COMMANDS = "mam.dispatcher.command";
    }
  }

  public static final class CONF
  {
    public static final String MAM_STANDALONE_PARAMTER = "MamStandAlone";
    public static final String MAM_URL_PARAMETER = "MamURL";
    public static final String MAM_HTTP_URL_PARAMETER = "MamHttpURL";
  }
}