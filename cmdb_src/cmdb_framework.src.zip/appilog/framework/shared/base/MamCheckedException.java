package appilog.framework.shared.base;

import com.mercury.topaz.cmdb.shared.base.ErrorCode;
import com.mercury.topaz.cmdb.shared.base.ExceptionWithErrorCode;

public class MamCheckedException extends Exception
  implements ExceptionWithErrorCode
{
  public static final int ERR_DEFAULT = 0;
  private ErrorCode _error = null;
  private int _errorCode = 0;

  public MamCheckedException(String message, int errorCode)
  {
    super(message);
    this._error = ErrorCode.getErrorCode(errorCode);
    this._errorCode = errorCode;
  }

  public MamCheckedException(String message, ErrorCode error) {
    super(message);
    this._error = error;
    this._errorCode = error.getCode();
  }

  public MamCheckedException(String message, Throwable cause) {
    super(message, cause);
    analyzeCause(cause);
  }

  public MamCheckedException(String message, Throwable ex, int errorCode) {
    super(message, ex);
    this._error = ErrorCode.getErrorCode(errorCode);
    this._errorCode = errorCode;
  }

  public MamCheckedException(String message, Throwable ex, ErrorCode error) {
    super(message, ex);
    this._error = error;
    this._errorCode = error.getCode();
  }

  private void analyzeCause(Throwable cause) {
    if (cause instanceof ExceptionWithErrorCode) {
      this._error = ((ExceptionWithErrorCode)cause).getError();
      this._errorCode = this._error.getCode();
    }
  }

  public ErrorCode getError() {
    if (this._error == null)
    {
      this._error = new ErrorCode(this._errorCode, getMessage());
    }
    return this._error;
  }

  public int getErrorCode()
  {
    return getError().getCode();
  }
}