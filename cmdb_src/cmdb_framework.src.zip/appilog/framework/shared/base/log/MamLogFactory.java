package appilog.framework.shared.base.log;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;

public class MamLogFactory
{
  static boolean isFirstTime = true;
  private static Log mamProfile = LogFactory.getEasyLog("mam.profile");
  private static Log mamAuditShort = LogFactory.getEasyLog("mam.audit.short");
  private static Log mamAuditDetailed = LogFactory.getEasyLog("mam.audit.detailed");
  private static Log mamModelCache = LogFactory.getEasyLog("mam.model.cache");
  private static Log mamModelTopology = LogFactory.getEasyLog("mam.model.topology");
  private static Log mamOperation = LogFactory.getEasyLog("mam.operation");
  private static Log mamNotification = LogFactory.getEasyLog("mam.notification");
  private static Log mamRebuild = LogFactory.getEasyLog("mam.rebuild");
  private static Log mamPqlevent = LogFactory.getEasyLog("mam.pqlevent");
  private static Log mamServerMonitor = LogFactory.getEasyLog("mam.server.monitor");
  private static Log mamServerFuse = LogFactory.getEasyLog("mam.server.fuse");
  private static Log mamServerTasks = LogFactory.getEasyLog("mam.server.tasks");
  private static Log mamServerFacade = LogFactory.getEasyLog("mam.server.facade");
  private static Log mamViewLifecycle = LogFactory.getEasyLog("mam.view.lifecycle");
  private static Log mamViewWorkers = LogFactory.getEasyLog("mam.view.workers");
  private static Log mamStatistics = LogFactory.getEasyLog("mam.statistics");
  private static Log mamScheduler = LogFactory.getEasyLog("mam.scheduler");
  private static Log mamSnapshots = LogFactory.getEasyLog("mam.snapshots");
  private static Log mamPerformance = LogFactory.getEasyLog("mam.performance");
  private static Log mamGuiGateway = LogFactory.getEasyLog("mam.guiGateway");
  private static Log mamAutodiscoveryResultsStat = LogFactory.getEasyLog("mam.autodiscovery.results.stat");
  private static Log mamImpact = LogFactory.getEasyLog("mam.impact");
  private static Log mamExternalRootCause = LogFactory.getEasyLog("mam.rootcause");
  private static Log mamPackaging = LogFactory.getEasyLog("mam.packaging");

  public static Log getImpactLog()
  {
    return mamImpact;
  }

  public static Log getRootCauseLog() {
    return mamExternalRootCause;
  }

  public static Log getGuiGatewayLog() {
    return mamGuiGateway;
  }

  public static Log getLog(Class clazz) {
    return LogFactory.getEasyLog(clazz);
  }

  public static Log getLog(String logName) {
    return LogFactory.getEasyLog(logName);
  }

  public static Log getMamInfoLog() {
    return getStartupLog();
  }

  public static Log getStartupLog() {
    return CmdbLogFactory.getStartupLog();
  }

  public static Log getProfilingLog() {
    return mamProfile;
  }

  public static Log getNotificationLog() {
    return mamNotification;
  }

  public static Log getRebuildLog() {
    return mamRebuild;
  }

  public static Log getPqlEventLog() {
    return mamPqlevent;
  }

  public static Log getServerMonitorLog() {
    return mamServerMonitor;
  }

  public static Log getServerFuseLog() {
    return mamServerFuse;
  }

  public static Log getServerTasksLog() {
    return mamServerTasks;
  }

  public static Log getServerFacadeLog() {
    return mamServerFacade;
  }

  public static Log getViewLifecycleLog() {
    return mamViewLifecycle;
  }

  public static Log getViewWorkersLog() {
    return mamViewWorkers;
  }

  public static Log getStatisticsLog() {
    return mamStatistics;
  }

  public static Log getSchedulerLog() {
    return mamScheduler;
  }

  public static Log getSnapshotLog() {
    return mamSnapshots;
  }

  public static Log getPerformanceLog() {
    return mamPerformance;
  }

  public static Log getAutodiscoveryResultsStat() {
    return mamAutodiscoveryResultsStat;
  }

  public static Log getPackagingLog() {
    return mamPackaging;
  }
}