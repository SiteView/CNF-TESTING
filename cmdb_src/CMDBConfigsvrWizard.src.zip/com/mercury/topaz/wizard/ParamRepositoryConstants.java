package com.mercury.topaz.wizard;

public class ParamRepositoryConstants
{
  public static final String RUN_DB_UPGRADE = "runDBUpgrade";
  public static final String IS_DB_UPGRADE_CANCELED = "isDBUpgradeCanceled";
  public static final String TASKS_FILE_NAME = "tasksFileName";
  public static final String DB_PREFIX = "prefix";
  public static final String IS_DB_CREDENTIALS_REUIRED = "isCredentialsRequired";
  public static final String DB_UPGRADE_CREDENTIALS = "DBUpgradeCredentials";
  public static final String ORACLE_SCHEMAS = "oracle_schemas";
}