package com.mercury.topaz.wizard;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.infra.wizard.TextFactory;
import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class DBUpgradeFinishPanel
{
  static final Log _log = LogFactory.getEasyLog(DBUpgradeFinishPanel.class);
  public JPanel contentPane;
  private JTextArea textArea;

  public DBUpgradeFinishPanel(boolean isDBUpgradeSuccess)
  {
    initUI();
    this.textArea.setBackground(this.contentPane.getBackground());
    this.textArea.setFont(UIManager.getFont("Label.font"));
    this.textArea.setFocusable(false);
    if (isDBUpgradeSuccess)
      this.textArea.setText(TextFactory.getText("config.server.panel.dbUpgrade.success.description"));
    else
      this.textArea.setText(TextFactory.getText("config.server.panel.dbUpgrade.failure.description"));
  }

  public JPanel getContentPane()
  {
    return this.contentPane;
  }

  private void initUI() {
    JPanel jpanel = new JPanel();
    this.contentPane = jpanel;
    jpanel.setLayout(new GridLayout(1, 2));
    JPanel jpanel1 = new JPanel();
    jpanel1.setLayout(new GridLayout(1, 1));
    jpanel.add(jpanel1);
    JTextArea jtextarea = new JTextArea();
    this.textArea = jtextarea;
    jpanel1.add(jtextarea);

    jtextarea.setEnabled(true);
    jtextarea.setEditable(false);
    jtextarea.setColumns(0);
    jtextarea.setWrapStyleWord(true);
    jtextarea.setLineWrap(true);
    jtextarea.setRows(1);
  }
}