package com.mercury.topaz.wizard;

import com.mercury.infra.wizard.Wizard;
import com.mercury.infra.wizard.WizardPanelDescriptor;

public class DBUpgradeSuccessPanelDescriptor extends WizardPanelDescriptor
{
  public static final String IDENTIFIER = "DB_UPGRADE_SUCCESS_PANEL";
  public static final String TITLE = "DB Upgrade";
  private DBUpgradeFinishPanel panel;

  public DBUpgradeSuccessPanelDescriptor(String title, String stepName, Wizard wizard)
  {
    super("DB_UPGRADE_SUCCESS_PANEL", title, stepName);
    this.panel = new DBUpgradeFinishPanel(true);
    setPanelComponent(this.panel.getContentPane());
  }

  public Object getPanelID() {
    return "DB_UPGRADE_SUCCESS_PANEL";
  }

  public void updateRepository() {
  }

  public String getNextPanelCondition() {
    return null;
  }
}