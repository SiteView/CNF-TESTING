package com.mercury.topaz.wizard;

import com.mercury.infra.wizard.Wizard;
import com.mercury.infra.wizard.WizardPanelDescriptor;

public class DBUpgradePanelDescriptor extends WizardPanelDescriptor
{
  public static final String IDENTIFIER = "DB_UPGRADE_PANEL";
  public static final String TITLE = "DB Upgrade";
  private DBUpgradePanel panel;

  public DBUpgradePanelDescriptor(String title, String stepName, Wizard wizard)
  {
    super("DB_UPGRADE_PANEL", title, stepName);
    this.panel = new DBUpgradePanel();
    setPanelComponent(this.panel.getContentPane());
  }

  public Object getPanelID() {
    return "DB_UPGRADE_PANEL";
  }

  public void updateRepository() {
  }

  public String getNextPanelCondition() {
    return null;
  }
}