package com.mercury.topaz.wizard;

import com.mercury.infra.flowmngr.ParamRepository;
import com.mercury.infra.wizard.WizardPanelDescriptor;

public class OracleDBUpgradeCredentialsPanelDescriptor extends WizardPanelDescriptor
{
  public static final String IDENTIFIER = "ORACLE_DB_UPGRADE_CREDENTIALS_PANEL";
  public static final String TITLE = "Oracle Settings";
  private OracleDBUpgradeCredentialsPanel panel;

  public OracleDBUpgradeCredentialsPanelDescriptor(String title, String stepName)
  {
    super("ORACLE_DB_UPGRADE_CREDENTIALS_PANEL", title, stepName);
    this.panel = new OracleDBUpgradeCredentialsPanel();
    setPanelComponent(this.panel.getContentPane());
  }

  public Object getPanelID() {
    return "ORACLE_DB_UPGRADE_CREDENTIALS_PANEL";
  }

  public void updateRepository()
  {
    ParamRepository rep = ParamRepository.getInstance();
    String dbupgradeCredentialsKey = "DBUpgradeCredentials";
    OracleDBUpgradeCredentials oracleDBUpgradeCredentials = new OracleDBUpgradeCredentials(this.panel.getUser(), this.panel.getPassword());
    rep.setParam(dbupgradeCredentialsKey, oracleDBUpgradeCredentials);
  }

  public boolean validate() {
    return this.panel.validate();
  }
}