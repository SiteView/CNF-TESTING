package com.mercury.topaz.wizard;

import com.mercury.infra.wizard.Wizard;
import com.mercury.infra.wizard.WizardPanelDescriptor;

public class DBUpgradeFailurePanelDescriptor extends WizardPanelDescriptor
{
  public static final String IDENTIFIER = "DB_UPGRADE_FAILURE_PANEL";
  public static final String TITLE = "DB Upgrade";
  private DBUpgradeFinishPanel panel;

  public DBUpgradeFailurePanelDescriptor(String title, String stepName, Wizard wizard)
  {
    super("DB_UPGRADE_FAILURE_PANEL", title, stepName);
    this.panel = new DBUpgradeFinishPanel(false);
    setPanelComponent(this.panel.getContentPane());
  }

  public Object getPanelID() {
    return "DB_UPGRADE_FAILURE_PANEL";
  }

  public void updateRepository() {
  }

  public String getNextPanelCondition() {
    return null;
  }
}