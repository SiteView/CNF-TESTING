package com.mercury.topaz.wizard;

public class OracleDBUpgradeCredentials
{
  private String m_user;
  private String m_password;

  public OracleDBUpgradeCredentials(String user, String password)
  {
    this.m_user = user;
    this.m_password = password;
  }

  public String getUser() {
    return this.m_user;
  }

  public String getPassword() {
    return this.m_password;
  }
}