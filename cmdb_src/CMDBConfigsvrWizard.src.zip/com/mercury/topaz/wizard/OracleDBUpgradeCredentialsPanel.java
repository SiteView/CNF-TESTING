package com.mercury.topaz.wizard;

import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;
import com.intellij.uiDesigner.core.Spacer;
import com.mercury.infra.wizard.TextFactory;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;

public class OracleDBUpgradeCredentialsPanel
{
  private JPanel m_contentPane;
  private JTextField m_user;
  private JPasswordField m_password;
  private JTextArea m_textArea;
  private JLabel adminUserLabel;
  private JLabel adminPasswordLabel;

  public OracleDBUpgradeCredentialsPanel()
  {
    this.m_contentPane = new JPanel();
    this.adminUserLabel = new JLabel(TextFactory.getText("config.server.panel.oracle.admin.user.name"));
    this.adminPasswordLabel = new JLabel(TextFactory.getText("config.server.panel.oracle.admin.password"));
    this.m_user = new JTextField();
    this.m_password = new JPasswordField();
    this.m_textArea = new JTextArea();

    this.m_textArea.setText("");
    this.m_textArea.setBackground(Color.WHITE);
    this.m_textArea.setFont(UIManager.getFont("Label.font"));
    this.m_textArea.setText(TextFactory.getText("config.server.panel.oracle.create.title"));
    this.m_textArea.setFocusable(false);
    this.m_textArea.setEnabled(true);
    this.m_textArea.setEditable(false);
    this.m_textArea.setColumns(0);
    this.m_textArea.setWrapStyleWord(true);
    this.m_textArea.setLineWrap(true);
    this.m_textArea.setRows(1);

    Font userFont = this.m_user.getFont();
    this.m_password.setFont(userFont);
    initUI();
  }

  private void initUI() {
    JPanel mainPanel = getContentPane();
    mainPanel.setLayout(new GridLayoutManager(3, 1, new Insets(0, 0, 0, 0), -1, -1, false, false));

    JPanel titleTextAreaPanel = new JPanel();
    titleTextAreaPanel.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1, false, false));
    titleTextAreaPanel.add(this.m_textArea, new GridConstraints(0, 0, 1, 1, 0, 3, 6, 6, null, null, null));
    mainPanel.add(titleTextAreaPanel, new GridConstraints(0, 0, 1, 1, 0, 3, 3, 3, null, null, null));

    JPanel credentialsPanel = new JPanel();
    credentialsPanel.setLayout(new GridLayoutManager(2, 3, new Insets(0, 0, 0, 0), -1, -1, false, false));
    mainPanel.add(credentialsPanel, new GridConstraints(1, 0, 1, 1, 0, 3, 3, 3, null, null, null));

    credentialsPanel.add(this.adminUserLabel, new GridConstraints(0, 0, 1, 1, 8, 0, 0, 0, null, null, null));
    credentialsPanel.add(this.m_user, new GridConstraints(0, 1, 1, 1, 8, 1, 6, 0, null, new Dimension(150, -1), null));

    credentialsPanel.add(this.adminPasswordLabel, new GridConstraints(1, 0, 1, 1, 8, 0, 0, 0, null, null, null));
    credentialsPanel.add(this.m_password, new GridConstraints(1, 1, 1, 1, 8, 1, 6, 0, null, new Dimension(150, -1), null));

    Spacer spacer = new Spacer();
    mainPanel.add(spacer, new GridConstraints(2, 0, 1, 1, 0, 2, 1, 6, null, null, null));
    Spacer spacer1 = new Spacer();
    credentialsPanel.add(spacer1, new GridConstraints(0, 2, 1, 1, 0, 1, 6, 1, null, null, null));
    Spacer spacer2 = new Spacer();
    credentialsPanel.add(spacer2, new GridConstraints(1, 2, 1, 1, 0, 1, 6, 1, null, null, null));
  }

  public JPanel getContentPane() {
    return this.m_contentPane;
  }

  public String getUser() {
    return this.m_user.getText();
  }

  public String getPassword() {
    return new String(this.m_password.getPassword());
  }

  public void setUser(String user) {
    this.m_user.setText(user);
  }

  public void setPassword(String password) {
    this.m_password.setText(password); }

  public void reset() {
    setUser("");
    setPassword("");
  }

  public boolean validate()
  {
    boolean valid = (!(isFieldEmpty(this.m_user))) && (!(isFieldEmpty(this.m_password)));

    if (!(valid)) {
      String title = TextFactory.getText("config.server.input.validation.failure.title");
      String message = TextFactory.getText("config.server.input.validation.general.failure");
      JOptionPane.showMessageDialog(this.m_contentPane, message, title, 0);
    }
    return valid;
  }

  public boolean isFieldEmpty(JTextField field) {
    return "".equals(field.getText());
  }
}