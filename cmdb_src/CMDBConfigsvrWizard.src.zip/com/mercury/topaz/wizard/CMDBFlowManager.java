package com.mercury.topaz.wizard;

import com.hp.acm.swing.utils.ACMSwingUtils;
import com.mercury.infra.flowmngr.FlowManager;
import com.mercury.infra.flowmngr.ParamRepository;
import com.mercury.infra.flowmngr.StepIDTranslator;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.infra.wizard.TextFactory;
import com.mercury.infra.wizard.Wizard;
import com.mercury.infra.wizard.WizardPanelDescriptor;
import com.mercury.topaz.wizard.dbconnect.DBConnectResultPanelDescriptor;
import com.mercury.topaz.wizard.dbconnect.DBSchemaSettingsPanelDescriptor;
import com.mercury.topaz.wizard.dbconnect.DBTypePanelDescriptor;
import com.mercury.topaz.wizard.dbconnect.ExternalUCMDBPanellDescriptor;
import com.mercury.topaz.wizard.dbconnect.ExternalUcmdbManager;
import com.mercury.topaz.wizard.dbconnect.IntroductionPanelDescriptor;
import com.mercury.topaz.wizard.dbconnect.OracleConnectCredentialsPanelDescriptor;
import com.mercury.topaz.wizard.dbconnect.OracleCredentialsPanelDescriptor;
import com.mercury.topaz.wizard.dbconnect.OracleSchemaSettingsPanelDescriptor;
import com.mercury.topaz.wizard.dbconnect.SQLCredentialsPanelDescriptor;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.swing.JFrame;

public class CMDBFlowManager extends Wizard
{
  public static final String STEP_SCHEMA_CONCIFUGRATION = "Schema Configuration";
  public static final String DEFAULT_FM_HOME = "./fm/dbconnect";
  public static final String DEFAULT_FM_TRANSLATOR_FILE = "./fm/dbconnect/dbconnect.translator.xml";
  public static final String PROP_FM_HOME = "fm.home";
  public static final String PROP_FM_TRANSLATOR_FILE = "fm.translator.file";
  public static final String FIRST_PANEL = "introduction";
  private static CMDBFlowManager m_cmdbFlowManagerInstance = null;
  static final Log _log = LogFactory.getEasyLog(CMDBFlowManager.class);

  public static CMDBFlowManager getInstance()
  {
    if (m_cmdbFlowManagerInstance == null)
      m_cmdbFlowManagerInstance = new CMDBFlowManager();

    return m_cmdbFlowManagerInstance;
  }

  public void enableButtons(Object panelID)
  {
    ParamRepository rep = ParamRepository.getInstance();
    String schemaType = (String)rep.getParam("schemaType");

    setBackButtonEnable((!("INTRODUCTION_PANEL".equals(panelID))) && (!("DB_UPGRADE_PANEL".equals(panelID))) && (!("DB_UPGRADE_SUCCESS_PANEL".equals(panelID))));

    boolean isFinish = isFinish(schemaType, panelID, rep);
    if ((!(isFinish)) && 
      ("cmdb".equals(schemaType)) && ("RESULT_PANEL".equals(panelID))) {
      ExternalUcmdbManager externalUcmdbManager = new ExternalUcmdbManager();
      isFinish = externalUcmdbManager.isFinish();
    }

    setNextButtonEnable(!(isFinish));
    setCancelButtonEnable(!(isFinish));
    setFinishButtonEnable(isFinish);
  }

  private boolean isFinish(String schemaType, Object panelID, ParamRepository rep) {
    return ((isFinishedWithoutDBUpgrade(schemaType, panelID, rep)) || (isFinishedWithDBUpgrade(schemaType, panelID, rep)));
  }

  private boolean isFinishedWithDBUpgrade(String schemaType, Object panelID, ParamRepository rep)
  {
    return (("DB_UPGRADE_SUCCESS_PANEL".equals(panelID)) || ("DB_UPGRADE_FAILURE_PANEL".equals(panelID)));
  }

  private boolean isFinishedWithoutDBUpgrade(String schemaType, Object panelID, ParamRepository rep)
  {
    return (("cmdb_history".equals(schemaType)) && ("RESULT_PANEL".equals(panelID)) && (((!(isDBUpgradeRequired(rep))) || (isDBUpgradeCanceled(rep)))));
  }

  private boolean isDBUpgradeRequired(ParamRepository rep)
  {
    String isDBUpgradeRequired = (String)rep.getParam("runDBUpgrade");
    return "true".equals(isDBUpgradeRequired);
  }

  private boolean isDBUpgradeCanceled(ParamRepository rep) {
    String isDBUpgradeCanceled = (String)rep.getParam("isDBUpgradeCanceled");
    return "true".equals(isDBUpgradeCanceled);
  }

  protected boolean initLookAndFeel()
  {
    ACMSwingUtils.initLookAndFeel();
    return true;
  }

  private CMDBFlowManager()
  {
    _log.info("Will use " + Locale.getDefault() + " Locale");
    System.out.println("Will use " + Locale.getDefault() + " Locale");
  }

  private void init()
  {
    String title = TextFactory.getText("config.server.title");
    setTitle(title);
    initFM();
    initPages();
  }

  private void initFM()
  {
    String fmHome = System.getProperty("fm.home", "./fm/dbconnect");
    String fmTranslatorFile = System.getProperty("fm.translator.file", "./fm/dbconnect/dbconnect.translator.xml");

    FlowManager fm = new FlowManager(fmHome, "init");
    fm.run();
    setFlowManager(fm);
    StepIDTranslator translator = new StepIDTranslator(new File(fmTranslatorFile));
    setIDTranslator(translator);
  }

  private void initPages()
  {
    WizardPanelDescriptor introduction = new IntroductionPanelDescriptor(TextFactory.getText("wizard.introduction"), TextFactory.getText("step.introduction"), this);

    registerWizardPanel("INTRODUCTION_PANEL", introduction);

    List stepNames = new ArrayList();
    List databases = (List)ParamRepository.getInstance().getParam("databases");
    for (Iterator i$ = databases.iterator(); i$.hasNext(); ) { String databaseName = (String)i$.next();

      stepNames.add(TextFactory.getText("step." + databaseName));
    }
    WizardPanelDescriptor dbSchema = new DBSchemaSettingsPanelDescriptor(TextFactory.getText("Schema Settings"), stepNames);

    registerWizardPanel("DB_SCHEMA_PANEL", dbSchema, true);

    WizardPanelDescriptor dbType = new DBTypePanelDescriptor(TextFactory.getText("Database Type"), stepNames);

    registerWizardPanel("DB_TYPE_PANEL", dbType);

    OracleCredentialsPanelDescriptor oracleCredentials = new OracleCredentialsPanelDescriptor(TextFactory.getText("Oracle Settings"), stepNames);

    oracleCredentials.setUseLastDbDetails(true);
    registerWizardPanel("ORACLE_CREDENTIALS_PANEL", oracleCredentials);

    OracleConnectCredentialsPanelDescriptor oracleConnectCredentials = new OracleConnectCredentialsPanelDescriptor(TextFactory.getText("Oracle Settings"), stepNames);

    oracleConnectCredentials.setUseLastDbDetails(true);
    registerWizardPanel("ORACLE_CONNECT_CREDENTIALS_PANEL", oracleConnectCredentials);

    OracleSchemaSettingsPanelDescriptor oracleSchemaSettings = new OracleSchemaSettingsPanelDescriptor(TextFactory.getText("Oracle Schema Settings"), stepNames);

    oracleSchemaSettings.setUseLastDbDetails(true);
    registerWizardPanel("ORACLE_SCHEMA_SETTINGS_PANEL", oracleSchemaSettings);

    SQLCredentialsPanelDescriptor sqlCredentials = new SQLCredentialsPanelDescriptor(TextFactory.getText("MS SQL Settings"), stepNames);

    sqlCredentials.setUseLastDbDetails(true);
    registerWizardPanel("SQL_CREDENTIALS_PANEL", sqlCredentials);

    WizardPanelDescriptor result = new DBConnectResultPanelDescriptor(TextFactory.getText("Summary"), stepNames);

    registerWizardPanel("RESULT_PANEL", result);

    ExternalUcmdbManager externalUcmdbManager = new ExternalUcmdbManager();
    if (externalUcmdbManager.isEnabled()) {
      ExternalUCMDBPanellDescriptor externalUCMDBPanellDescriptor = new ExternalUCMDBPanellDescriptor(TextFactory.getText("CMDB Schema"), TextFactory.getText("step.cmdb"));

      registerWizardPanel("EXTERNAL_UCMDB_PANEL", externalUCMDBPanellDescriptor);
    }

    WizardPanelDescriptor dbUpgrade = new DBUpgradePanelDescriptor(TextFactory.getText("wizard.dbUpgrade"), TextFactory.getText("step.dbUpgrade"), this);

    registerWizardPanel("DB_UPGRADE_PANEL", dbUpgrade);

    WizardPanelDescriptor dbUpgradeSuccess = new DBUpgradeSuccessPanelDescriptor(TextFactory.getText("wizard.dbUpgrade"), TextFactory.getText("step.dbUpgrade"), this);

    registerWizardPanel("DB_UPGRADE_SUCCESS_PANEL", dbUpgradeSuccess);

    WizardPanelDescriptor dbUpgradeFailure = new DBUpgradeFailurePanelDescriptor(TextFactory.getText("wizard.dbUpgrade"), TextFactory.getText("step.dbUpgrade"), this);

    registerWizardPanel("DB_UPGRADE_FAILURE_PANEL", dbUpgradeFailure);

    OracleDBUpgradeCredentialsPanelDescriptor oracleDBUpgradeCredentials = new OracleDBUpgradeCredentialsPanelDescriptor(TextFactory.getText("Oracle Settings"), TextFactory.getText("step.dbUpgrade"));

    oracleCredentials.setUseLastDbDetails(true);
    registerWizardPanel("ORACLE_DB_UPGRADE_CREDENTIALS_PANEL", oracleDBUpgradeCredentials);

    setCurrentPanel("INTRODUCTION_PANEL");
  }

  public static void main(String[] args) {
    CMDBFlowManager wizard = getInstance();
    wizard.init();
    wizard.show();

    wizard.getFrame().toFront();
    wizard.getFrame().requestFocus();
  }
}