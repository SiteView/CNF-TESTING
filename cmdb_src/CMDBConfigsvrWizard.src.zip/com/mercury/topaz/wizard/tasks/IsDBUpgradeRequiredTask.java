package com.mercury.topaz.wizard.tasks;

import com.mercury.infra.flowmngr.IJavaTask;
import com.mercury.infra.flowmngr.ParamRepository;
import com.mercury.topaz.cmdb.server.manage.environment.BasicLocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.settings.InternalSettings;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Default;
import com.mercury.topaz.wizard.CMDBFlowManager;
import java.util.Map;
import javax.swing.JOptionPane;

public class IsDBUpgradeRequiredTask
  implements IJavaTask
{
  public String execute(Map<String, Object> args)
    throws Exception
  {
    ParamRepository rep = ParamRepository.getInstance();
    rep.setParam("isDBUpgradeCanceled", "false");

    if (isDBUpgradeRequired(rep))
    {
      String description = "";
      try {
        BasicLocalEnvironment localEnv = new BasicLocalEnvironment(FrameworkConstants.Customer.Default.ID);
        InternalSettings internalSettings = InternalSettings.create(localEnv);
        String cmdbSourceVersion = internalSettings.getSystemParameter("upgrader.cmdb", "");
        if (!("".equals(cmdbSourceVersion)))
          description = "You have connected to CMDB schema with version: " + cmdbSourceVersion + ".\n";
        else
          description = "You have connected to CMDB schema with older version.\n";
      }
      catch (Exception e)
      {
        description = "You have connected to CMDB schema with older version.\n";
      }

      CMDBFlowManager wizard = CMDBFlowManager.getInstance();
      int answer = JOptionPane.showConfirmDialog(wizard.getFrame(), description + "Would you like to run the DB upgrade task now?\n" + "If you do not run the task now, you can run it later.", "DB Upgrade task", 0);

      if (answer != 0) {
        rep.setParam("isDBUpgradeCanceled", "true");
        return "no";
      }
      return "yes";
    }
    return "no";
  }

  private boolean isDBUpgradeRequired(ParamRepository rep) {
    return "true".equals(rep.getParam("runDBUpgrade"));
  }
}