package com.mercury.topaz.wizard.tasks;

import com.mercury.infra.flowmngr.IJavaTask;
import com.mercury.infra.flowmngr.ParamRepository;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SetRequireOracleCredentialTask
  implements IJavaTask
{
  public String execute(Map<String, Object> args)
    throws Exception
  {
    List isCredentialsRequiredArr = (List)args.get("isCredentialsRequired");
    String isCredentialsRequired = (String)isCredentialsRequiredArr.get(0);

    ParamRepository rep = ParamRepository.getInstance();

    String schemaType = (String)rep.getParam("schemaType");

    Set oracleSchemas = (Set)rep.getParam("oracle_schemas");
    if (oracleSchemas == null) {
      oracleSchemas = new HashSet();
      rep.setParam("oracle_schemas", oracleSchemas);
    }

    if ("true".equals(isCredentialsRequired))
      oracleSchemas.add(schemaType);
    else {
      oracleSchemas.remove(schemaType);
    }

    if (oracleSchemas.size() == 0)
      rep.setParam("isCredentialsRequired", "false");
    else
      rep.setParam("isCredentialsRequired", "true");

    return "success";
  }
}