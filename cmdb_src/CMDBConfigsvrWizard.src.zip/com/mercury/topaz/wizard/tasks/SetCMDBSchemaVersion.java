package com.mercury.topaz.wizard.tasks;

import com.mercury.infra.flowmngr.IJavaTask;
import com.mercury.infra.flowmngr.ParamRepository;
import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.ServerVersion;
import com.mercury.topaz.cmdb.server.manage.environment.BasicLocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.settings.InternalSettings;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Default;
import java.io.IOException;
import java.util.Map;

public class SetCMDBSchemaVersion
  implements IJavaTask
{
  private static Log log = LogFactory.getEasyLog(SetCMDBSchemaVersion.class);

  public String execute(Map<String, Object> args)
    throws Exception
  {
    log.info("Start SetCMDBSchemaVersion");
    DbContext dbContext = (DbContext)ParamRepository.getInstance().getParam("cmdb_db_context");
    BasicLocalEnvironment ble = new BasicLocalEnvironment(FrameworkConstants.Customer.Default.ID, dbContext);
    InternalSettings internalSettings = InternalSettings.create(ble);
    setCMDBVersion(internalSettings);
    setCMDBBuildNumber(internalSettings);
    log.info("Finish SetCMDBSchemaVersion with result : success");
    return "success";
  }

  private void setCMDBVersion(InternalSettings internalSettings)
  {
    internalSettings.setSystemParameter("upgrader.cmdb", "8.0.0.0");
  }

  private void setCMDBBuildNumber(InternalSettings internalSettings)
    throws IOException
  {
    internalSettings.setSystemParameter("cmdb.buildNumber", ServerVersion.getCmdbBuild());
  }
}