package com.mercury.topaz.wizard.tasks;

import com.mercury.infra.flowmngr.IJavaTask;
import com.mercury.infra.flowmngr.ParamRepository;
import com.mercury.infra.utils.db.pools.ConnectionManager;
import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.exceptions.MNoSuchElementException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.server.ServerVersion;
import com.mercury.topaz.cmdb.server.manage.environment.BasicLocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.settings.InternalSettings;
import com.mercury.topaz.cmdb.shared.base.CmdbConstants.Upgrade;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Default;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

public class SetUseUpgradeDBTask
  implements IJavaTask
{
  private static final String TABLE_NAME = "CCM_SETTINGS";
  private static final String VALUE_COLUMN = "VALUE";
  private static final String NAME_COLUMN = "NAME";
  private static final String VERSION_FIELD = "upgrader.cmdb";
  private static final String CMDB_LATEST_VERSION = "8.0.0.0";
  private static Log log = LogFactory.getEasyLog(SetUseUpgradeDBTask.class);

  public String execute(Map<String, Object> args)
    throws Exception
  {
    log.info("Start SetUseUpgradeDBTask");
    ParamRepository rep = ParamRepository.getInstance();
    ArrayList isRequiredArr = (ArrayList)args.get("isRequired");
    boolean isRequired = false;
    if (!(validateArg(isRequiredArr)))
      return "failure";

    isRequired = Boolean.parseBoolean((String)isRequiredArr.get(0));

    if ((isRequired) && (isVersionNeedUpgrade()))
      rep.setParam("runDBUpgrade", "true");
    else {
      rep.setParam("runDBUpgrade", "false");
    }

    log.info("Finish SetUseUpgradeDBTask with result : success");
    return "success";
  }

  private boolean validateArg(ArrayList<String> argArr) {
    if ((argArr == null) || (argArr.get(0) == null)) {
      log.error("Illegal argument: " + argArr);
      log.info("Finish SetUseUpgradeDBTask with result : failure");
      return false;
    }
    return true;
  }

  private boolean isVersionNeedUpgrade()
  {
    try
    {
      if (isLatestVersion()) {
        log.info("The CMDB schema source version is: 8.0.0.0. DB upgrade is not needed.");
        return false;
      }
    }
    catch (Exception e)
    {
      log.error("The CMDB schema source version is unknown. Fix the problem and run DB upgrade manually if needed.", e);
      return false;
    }

    String sourceVersion = "";
    try {
      sourceVersion = getCmdbDbVersion();
    } catch (Exception e) {
      log.info(e.getMessage());
      log.info("The CMDB schema source version is unknown. Fix the problem and run DB upgrade manually if needed.");
      return false;
    }

    if (sourceVersion.length() == 3) {
      sourceVersion = sourceVersion + ".0.0";
    }

    if ("".equals(sourceVersion)) {
      log.info("The CMDB schema source version is unknown. Run DB upgrade manually if needed. NOTE: This situation can happen when you use new foundation database with old CMDB database.(E.g: fnd 8 and cmdb 7)");

      return false; }
    if (isUpgradeSupportedForVersion(sourceVersion))
      return true;

    log.error("Upgrade for " + sourceVersion + " source database version is not supported");
    return false;
  }

  private boolean isUpgradeSupportedForVersion(String sourceVersion)
  {
    for (int i = 0; i < CmdbConstants.Upgrade.UPGRADE_SUPPORTED_VERSIONS.length; ++i)
      if (CmdbConstants.Upgrade.UPGRADE_SUPPORTED_VERSIONS[i].equals(sourceVersion))
        return true;


    return false;
  }

  private boolean isLatestVersion() throws MNoSuchElementException, SQLException {
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;

    DbContext dbContext = (DbContext)ParamRepository.getInstance().getParam("cmdb_db_context");
    try {
      conn = ConnectionManager.getPrivateConnection(dbContext);
      stmt = conn.createStatement();
      if (isVersionBelow8(stmt)) {
        int i = 0;

        return i;
      }
      String currentVersion = "";
      rs = stmt.executeQuery("SELECT VALUE FROM CCM_SETTINGS WHERE NAME='upgrader.cmdb'");
      if (rs.next()) {
        currentVersion = rs.getString("VALUE");
      }

      e = "8.0.0.0".equals(currentVersion);

      return e;
    }
    finally
    {
      if (rs != null)
        try {
          rs.close();
        }
        catch (SQLException e)
        {
        }
      if (stmt != null)
        try {
          stmt.close();
        }
        catch (SQLException e)
        {
        }
      ConnectionManager.releasePrivateConnection(conn);
    }
  }

  private boolean isVersionBelow8(Statement stmt) {
    try {
      stmt.executeQuery("SELECT * FROM CCM_SETTINGS WHERE 1=1");
    }
    catch (SQLException e) {
      return true;
    }
    return false;
  }

  private String getCmdbDbVersion()
  {
    BasicLocalEnvironment localEnv = new BasicLocalEnvironment(FrameworkConstants.Customer.Default.ID);
    InternalSettings internalSettings = InternalSettings.create(localEnv);
    return ServerVersion.getCmdbDbVersion(internalSettings);
  }
}