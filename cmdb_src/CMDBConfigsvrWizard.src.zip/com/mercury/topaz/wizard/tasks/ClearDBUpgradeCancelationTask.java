package com.mercury.topaz.wizard.tasks;

import com.mercury.infra.flowmngr.IJavaTask;
import com.mercury.infra.flowmngr.ParamRepository;
import java.util.Map;

public class ClearDBUpgradeCancelationTask
  implements IJavaTask
{
  public String execute(Map<String, Object> args)
    throws Exception
  {
    ParamRepository rep = ParamRepository.getInstance();
    rep.setParam("isDBUpgradeCanceled", "false");
    return "success";
  }
}