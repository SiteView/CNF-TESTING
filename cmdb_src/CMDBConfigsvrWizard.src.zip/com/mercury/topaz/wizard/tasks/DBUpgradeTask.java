package com.mercury.topaz.wizard.tasks;

import com.mercury.dbverify.DBVEnvironmentException;
import com.mercury.dbverify.GenericFlowContext;
import com.mercury.infra.flowmngr.IJavaTask;
import com.mercury.infra.flowmngr.ParamRepository;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.dbverify.CmdbFlowManager;
import com.mercury.topaz.wizard.CMDBFlowManager;
import com.mercury.topaz.wizard.OracleDBUpgradeCredentials;
import java.io.File;
import java.io.PrintStream;
import java.util.Map;
import javax.swing.JOptionPane;

public class DBUpgradeTask
  implements IJavaTask
{
  private static final Log dbUpgradeLog = LogFactory.getEasyLog(DBUpgradeTask.class);
  public static final int SCHEMA_CHECK_TASK_DECISION_EXIT = 100;
  private static final String CONFIG_SERVER_LOG_DIR = System.getProperty("topaz.home") + File.separator + "log" + File.separator + "configserver";
  private static final String CONFIG_SERVER_DBVERIFY_RESULT_DIR = System.getProperty("topaz.home") + File.separator + "tools" + File.separator + "ConfigServer";

  public String execute(Map<String, Object> args)
    throws Exception
  {
    String[] credentialsArgs;
    ParamRepository rep = ParamRepository.getInstance();
    if ("true".equals(rep.getParam("isCredentialsRequired"))) {
      credentialsArgs = new String[2];
      OracleDBUpgradeCredentials credentials = (OracleDBUpgradeCredentials)rep.getParam("DBUpgradeCredentials");
      credentialsArgs[0] = credentials.getUser();
      credentialsArgs[1] = credentials.getPassword();
    } else {
      credentialsArgs = new String[0];
    }

    CmdbFlowManager cmdbFlowManager = new CmdbFlowManager(credentialsArgs);
    try
    {
      cmdbFlowManager.init();
      printInfoToLogAndConsole("DBUpgrade is successfully connected to the DB");

      int runAllRet = cmdbFlowManager.runAll();
      if (runAllRet == 0) {
        printInfoToLogAndConsole("Cmdb Flow Manager succeed.");
        return "success";
      }

      printInfoToLogAndConsole("Cmdb Flow Manager failed!");
      if (runAllRet == 100) {
        String tempDir = CONFIG_SERVER_DBVERIFY_RESULT_DIR + File.separator + cmdbFlowManager.getFlowContext().getProperty("log.temp_dir");
        printInfoToLogAndConsole("Please find the differences in files located under the following directory: " + tempDir);
      }
      showUpgradeError();
      return "failure";
    }
    catch (DBVEnvironmentException ex)
    {
      printErrorToLogAndConsole("The credentials are probably not valid.");
      printErrorToLogAndConsole(ex.getMessage());
      showUpgradeError();
      return "failure";
    }
    catch (Exception ex)
    {
      printErrorToLogAndConsole("CmdbFlowManager failed", ex);
      showUpgradeError(); }
    return "failure";
  }

  private void showUpgradeError()
  {
    CMDBFlowManager wizard = CMDBFlowManager.getInstance();
    JOptionPane.showMessageDialog(wizard.getFrame(), "The DB Upgrade task failed.\nFor details, see the log file on: " + CONFIG_SERVER_LOG_DIR + File.separator + "configserver_all.log", "DB Upgrade Error", 0);
  }

  public static void printInfoToLogAndConsole(String message)
  {
    dbUpgradeLog.info(message);
    System.out.println(message);
  }

  public static void printErrorToLogAndConsole(String message) {
    printErrorToLogAndConsole(message, null);
  }

  public static void printErrorToLogAndConsole(String message, Exception ex) {
    if (ex == null) {
      dbUpgradeLog.error(message);
      System.out.println(message);
    } else {
      dbUpgradeLog.error(message, ex);
      System.out.println(message + "\n" + ex.getMessage());
    }
  }
}