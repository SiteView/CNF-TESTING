package com.mercury.topaz.wizard;

import com.mercury.infra.configserver.fm.tasks.AutoUpgradeTask;
import com.mercury.infra.configserver.fm.tasks.RegisterDbContextTask;
import com.mercury.infra.flowmngr.ParamRepository;
import com.mercury.infra.utils.db.pools.DBType;
import com.mercury.infra.utils.db.pools.DbContext;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RunFNDAutoUpgraders
{
  protected static final String FOUNDATION_PREFIX = "foundation_";
  protected static final String DB_CONTEXT_KEY = "db_context";
  protected static final String AUTO_UPGRADES_KEY = "AutoUpgrades";
  protected static final String DB_INFO_CLASS_KEY = "dbInfoClass";
  protected static final String DB_INFO_CLASS = "com.mercury.infra.configserver.FoundationsDBInfoImpl";
  public static final String NEW_LINE = System.getProperty("line.separator");
  private static final int NUM_OF_ARGS = 7;

  public static void main(String[] args)
  {
    try
    {
      if (args.length == 0) {
        printUsage();
        return;
      }
      if (args.length != 7) {
        System.out.println("Error! Wrong number of parameters.");
        printUsage();
        return;
      }

      DbContext dbContext = getDbContext(args);
      ParamRepository.getInstance().setParam("foundation_db_context", dbContext);

      Map map = createRegisterDbContextTaskMap();
      RegisterDbContextTask registerDbContextTask = new RegisterDbContextTask();
      registerDbContextTask.execute(map);

      map = createAutoUpgradeTaskMap();
      AutoUpgradeTask autoUpgradeTask = new AutoUpgradeTask();
      autoUpgradeTask.execute(map);
    } catch (Exception e) {
      System.out.println("ERROR: " + e.getMessage() + ". Possible cause: " + e.getCause());
      e.printStackTrace();
    }
  }

  private static Map<String, Object> createRegisterDbContextTaskMap() {
    Map map = new HashMap();

    List prefixLst = new ArrayList();
    prefixLst.add("foundation_");
    map.put("prefix", prefixLst);

    List dbInfoClassLst = new ArrayList();
    dbInfoClassLst.add("com.mercury.infra.configserver.FoundationsDBInfoImpl");
    map.put("dbInfoClass", dbInfoClassLst);
    return map;
  }

  private static Map<String, Object> createAutoUpgradeTaskMap() {
    Map map = new HashMap();

    List prefixLst = new ArrayList();
    prefixLst.add("foundation_");
    map.put("prefix", prefixLst);

    List autoUpgradesLst = new ArrayList();
    autoUpgradesLst.add("HAUcmdbServiceControllerUpgrade.xml");
    autoUpgradesLst.add("QZGW_LOCKS.xml");
    map.put("AutoUpgrades", autoUpgradesLst);
    return map;
  }

  private static void printUsage() {
    StringBuffer usage = new StringBuffer();
    usage.append("After creating the foundation schema manually, you need to initialize the schema as follows:").append(NEW_LINE).append("Oracle foundation schema: init_foundation_schema Oracle schemaName schemaPassword hostName port serverName sid").append(NEW_LINE).append("SQL foundation schema: init_foundation_schema SQL userName password hostName port serverName schmeaName").append(NEW_LINE).append(NEW_LINE).append("Oracle example: init_foundation_schema Oracle FND_Schema1 FND_Schema1 oracleDBMachine 1521 oracleDBMachine ucmdb").append(NEW_LINE).append("SQL example: init_foundation_schema SQL admin pw123 sqlDBMachine 1433 sqlDBMachine FND_Schema1").append(NEW_LINE).append(NEW_LINE).append("After executing this script, start the UCMDB Server Configuration Wizard, connect to the manually created foundation schema").append(NEW_LINE).append("and continue with the wizard as usual.");

    System.out.println(usage.toString());
  }

  private static DbContext getDbContext(String[] args) {
    String dbTypeAsString = args[0].toUpperCase() + " Server";
    String userName = args[1];
    String password = args[2];
    String hostName = args[3];
    String port = args[4];
    String server = args[5];
    String sid = "";
    String dbName = "";
    if ("ORACLE Server".equalsIgnoreCase(dbTypeAsString)) {
      sid = args[6].toLowerCase();
    }
    else {
      dbName = args[6];
    }

    DBType dbType = DBType.getDbTypeByName(dbTypeAsString);
    return new DbContext(dbType, hostName, dbName, userName, password, server, sid, port);
  }
}