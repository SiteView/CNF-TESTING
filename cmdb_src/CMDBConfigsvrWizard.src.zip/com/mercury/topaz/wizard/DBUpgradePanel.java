package com.mercury.topaz.wizard;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.infra.wizard.TextFactory;
import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class DBUpgradePanel
{
  static final Log _log = LogFactory.getEasyLog(DBUpgradePanel.class);
  public JPanel contentPane;
  private JTextArea textArea;

  public DBUpgradePanel()
  {
    this.contentPane = new JPanel();
    this.contentPane.setLayout(new GridLayout(1, 2));
    JPanel jpanel1 = new JPanel();
    jpanel1.setLayout(new GridLayout(1, 1));
    this.contentPane.add(jpanel1);
    this.textArea = new JTextArea();
    jpanel1.add(this.textArea);

    this.textArea.setText("");
    this.textArea.setEnabled(true);
    this.textArea.setEditable(false);
    this.textArea.setColumns(0);
    this.textArea.setWrapStyleWord(true);
    this.textArea.setLineWrap(true);
    this.textArea.setRows(1);
    this.textArea.setBackground(this.contentPane.getBackground());
    this.textArea.setFont(UIManager.getFont("Label.font"));
    this.textArea.setFocusable(false);
    this.textArea.setText(TextFactory.getText("config.server.panel.dbUpgrade.description"));
  }

  public JPanel getContentPane()
  {
    return this.contentPane;
  }
}