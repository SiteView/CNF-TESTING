package com.mercury.topaz.cmdb.history.shared.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.history.shared.base.HistoryConstants;
import com.mercury.topaz.cmdb.history.shared.base.HistoryConstants.ATTRIBUTES;
import com.mercury.topaz.cmdb.history.shared.operation.update.HistoryUpdate;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.change.manage.AbstractModelChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.notification.service.util.ChangesPublisher;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class HistoryUpdateAddCmdbChanges extends AbstractHistoryUpdateAddHistoryChanges
  implements HistoryUpdate
{
  public HistoryUpdateAddCmdbChanges(CmdbChanges changes)
  {
    super(changes.getChanger(), changes);
  }

  public String getOperationName() {
    return "history update: add cmdb changes";
  }

  protected void initializeCollections() {
    CmdbChangeListenerFineGrained listener = new HistoryDBModelChangeListenerFineGrained(this, getHistoryUpdateManager().getCustomerID());
    ChangesPublisher.publish(listener, getChanges());
  }

  protected void filterCollections()
  {
    CmdbProperties props;
    CmdbLink link;
    CmdbObject object;
    CmdbLinks addedLinks = CmdbLinkFactory.createLinks();
    CmdbObjects addedObjects = CmdbObjectFactory.createObjects();
    CmdbLinks updatedLinks = CmdbLinkFactory.createLinks();
    CmdbObjects updatedObjects = CmdbObjectFactory.createObjects();
    CmdbLinks removedLinks = CmdbLinkFactory.createLinks();
    CmdbObjects removedObjects = CmdbObjectFactory.createObjects();

    ReadOnlyIterator it = getAddedLinks().getLinksIterator();
    while (it.hasNext()) {
      link = (CmdbLink)it.next();
      if (linkShouldBeSaved(link)) {
        props = getPropsForAdd(link);
        addedLinks.add(getUpdatedLink(link, props));
      }
    }
    setAddedLinks(addedLinks);

    it = getAddedObjects().getObjectsIterator();
    while (it.hasNext()) {
      object = (CmdbObject)it.next();
      props = getPropsForAdd(object);
      if (props.size() > 0)
        addedObjects.add(getUpdatedObject(object, props));
    }

    setAddedObjects(addedObjects);

    it = getUpdatedLinks().getLinksIterator();
    while (it.hasNext()) {
      object = (CmdbLink)it.next();
      if (linkShouldBeSaved(object)) {
        props = getOnlyNeedToBeSavedProps(object);
        if (props.size() > 0)
          updatedLinks.add(getUpdatedLink(object, props));
      }
    }

    setUpdatedLinks(updatedLinks);

    it = getUpdatedObjects().getObjectsIterator();
    while (it.hasNext()) {
      object = (CmdbObject)it.next();
      props = getOnlyNeedToBeSavedProps(object);
      if (props.size() > 0)
        updatedObjects.add(getUpdatedObject(object, props));
    }

    setUpdatedObjects(updatedObjects);

    it = getRemovedLinks().getLinksIterator();
    while (it.hasNext()) {
      object = (CmdbLink)it.next();
      if (linkShouldBeSaved(object))
        removedLinks.add(object);
    }

    setRemovedLinks(removedLinks);

    it = getRemovedObjects().getObjectsIterator();
    while (it.hasNext()) {
      object = (CmdbObject)it.next();
      if (dataHasHistoryQualifier(object))
        removedObjects.add(object);
    }

    setRemovedObjects(removedObjects);
  }

  private CmdbLink getUpdatedLink(CmdbLink link, CmdbProperties newProperties)
  {
    return CmdbLinkFactory.createLink((CmdbLinkID)link.getID(), link.getEnd1(), link.getEnd2(), link.getType(), newProperties);
  }

  private CmdbObject getUpdatedObject(CmdbObject object, CmdbProperties newProperties)
  {
    return CmdbObjectFactory.createObject((CmdbObjectID)object.getID(), object.getType(), newProperties);
  }

  private CmdbProperties getPropsForAdd(CmdbData data) {
    CmdbProperties properties = getOnlyNeedToBeSavedProps(data);

    CmdbClass cmdbClass = getClassModel().getClass(data.getType());
    if (cmdbClass == null) {
      _logger.error("Trying to save data from type " + data.getType() + " that doesn't exist in the class model");
      return properties;
    }
    String[] arr$ = HistoryConstants.HISTORY_QUALIFIERS; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String aHISTORY_QUALIFIERS = arr$[i$];
      CmdbAttributes attrs = cmdbClass.getAttributesByQualifier(aHISTORY_QUALIFIERS);
      ReadOnlyIterator it = attrs.getIterator();
      while (it.hasNext()) {
        CmdbAttribute attr = (CmdbAttribute)it.next();
        if (!(properties.contains(attr.getName()))) {
          CmdbProperty prop = CmdbPropertyFactory.createEmptyProperty(attr.getName(), attr.getResolvedType());
          properties.add(prop);
        }
      }
    }
    if ((!(properties.contains(HistoryConstants.ATTRIBUTES.DISPLAY_LABEL))) && (cmdbClass.isDescendantOf("it_world")))
    {
      CmdbProperty prop = CmdbPropertyFactory.createEmptyProperty(HistoryConstants.ATTRIBUTES.DISPLAY_LABEL, CmdbSimpleTypes.CmdbString);
      properties.add(prop);
    }
    return properties;
  }

  protected boolean dataHasHistoryQualifier(CmdbData data)
  {
    CmdbClass cmdbClass = getClassModel().getClass(data.getType());
    if (cmdbClass == null) {
      _logger.error("Trying to save data from type " + data.getType() + " that doesn't exist in the class model");
      return false;
    }
    CmdbAttributes classAttributes = cmdbClass.getAllAttributes();
    if ((classAttributes.hasAttribute(HistoryConstants.ATTRIBUTES.DISPLAY_LABEL)) && (cmdbClass.isDescendantOf("it_world")))
    {
      return true;
    }
    String[] arr$ = HistoryConstants.HISTORY_QUALIFIERS; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String aHISTORY_QUALIFIERS = arr$[i$];
      CmdbAttributes attrs = cmdbClass.getAttributesByQualifier(aHISTORY_QUALIFIERS);
      if (attrs.getSize() > 0)
        return true;
    }

    return false;
  }

  protected boolean linkShouldBeSaved(CmdbLink link) {
    CmdbClass cmdbClass = getClassModel().getClass(link.getType());
    if (cmdbClass == null) {
      _logger.error("Trying to save data from type " + link.getType() + " that doesn't exist in the class model");
      return false;
    }
    return cmdbClass.hasQualifier(CmdbClassQualifierDefs.TRACK_LINK_CHANGES.getName());
  }

  protected CmdbProperties getOnlyNeedToBeSavedProps(CmdbData data)
  {
    ReadOnlyIterator propsIt = data.getPropertiesIterator();
    CmdbProperties properties = CmdbPropertyFactory.createProperties();
    while (propsIt.hasNext()) {
      CmdbProperty curProp = (CmdbProperty)propsIt.next();
      if (doesPropNeedToBeSaved(data.getType(), curProp.getKey()))
        properties.add(curProp);
    }

    return properties;
  }

  private boolean doesPropNeedToBeSaved(String className, String attrID)
  {
    boolean shouldSave = false;
    CmdbClass cmdbClass = getClassModel().getClass(className);
    if (cmdbClass == null) {
      _logger.error("Trying to save data from type " + className + " that doesn't exist in the class model");
      return false;
    }
    CmdbAttribute attr = cmdbClass.getAttributeByName(attrID);
    if (attr != null)
    {
      if ((attr.getName().equals(HistoryConstants.ATTRIBUTES.DISPLAY_LABEL)) && (cmdbClass.isDescendantOf("it_world")))
      {
        return true;
      }

      String[] arr$ = HistoryConstants.HISTORY_QUALIFIERS; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String aHISTORY_QUALIFIERS = arr$[i$];
        if (attr.hasQualifier(aHISTORY_QUALIFIERS)) {
          shouldSave = true;
          break;
        }
      }
    }
    return shouldSave;
  }

  class HistoryDBModelChangeListenerFineGrained extends AbstractModelChangeListenerFineGrained
  {
    public HistoryDBModelChangeListenerFineGrained(, CmdbCustomerID paramCmdbCustomerID) {
      super(customerID);
    }

    public void onAddLinks() {
      if (this.this$0.getAddedLinks() == null) {
        this.this$0.setAddedLinks(addedLinks);
      } else {
        ReadOnlyIterator it = addedLinks.getLinksIterator();
        while (it.hasNext())
          this.this$0.getAddedLinks().add((CmdbLink)it.next());
      }
    }

    public void onAddObjects()
    {
      if (this.this$0.getAddedObjects() == null) {
        this.this$0.setAddedObjects(addedObjects);
      } else {
        ReadOnlyIterator it = addedObjects.getObjectsIterator();
        while (it.hasNext())
          this.this$0.getAddedObjects().add((CmdbObject)it.next());
      }
    }

    public void onRemoveLinks()
    {
      if (this.this$0.getRemovedLinks() == null) {
        this.this$0.setRemovedLinks(removedLinks);
      } else {
        ReadOnlyIterator it = removedLinks.getLinksIterator();
        while (it.hasNext())
          this.this$0.getRemovedLinks().add((CmdbLink)it.next());
      }
    }

    public void onRemoveObjects()
    {
      if (this.this$0.getRemovedObjects() == null) {
        this.this$0.setRemovedObjects(objectsToRemove);
      } else {
        ReadOnlyIterator it = objectsToRemove.getObjectsIterator();
        while (it.hasNext())
          this.this$0.getRemovedObjects().add((CmdbObject)it.next());
      }
    }

    public void onUpdateLinks()
    {
      if (this.this$0.getUpdatedLinks() == null) {
        this.this$0.setUpdatedLinks(updatedLinks);
      } else {
        ReadOnlyIterator it = updatedLinks.getLinksIterator();
        while (it.hasNext())
          this.this$0.getUpdatedLinks().add((CmdbLink)it.next());
      }
    }

    public void onUpdateObjects()
    {
      if (this.this$0.getUpdatedObjects() == null) {
        this.this$0.setUpdatedObjects(updatedObjects);
      } else {
        ReadOnlyIterator it = updatedObjects.getObjectsIterator();
        while (it.hasNext())
          this.this$0.getUpdatedObjects().add((CmdbObject)it.next());
      }
    }

    public void onFinishDeployment()
    {
    }

    public void onStartDeployment()
    {
    }
  }
}