package com.mercury.topaz.cmdb.history.server.base.jmx;

import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.operation.command.impl.HistoryCommandDisableHistory;
import com.mercury.topaz.cmdb.history.server.operation.command.impl.HistoryCommandEnableHistory;
import com.mercury.topaz.cmdb.history.server.operation.command.impl.HistoryCommandIsHistoryEnabled;
import com.mercury.topaz.cmdb.history.shared.base.HistoryConstants;
import com.mercury.topaz.cmdb.history.shared.base.HistoryLogFactory;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.filter.impl.HistoryFilterFactory;
import com.mercury.topaz.cmdb.history.shared.operation.query.impl.HistoryQueryGetExtendedNumberOfChanges;
import com.mercury.topaz.cmdb.history.shared.operation.query.impl.HistoryQueryGetHistoryDbContext;
import com.mercury.topaz.cmdb.history.shared.operation.query.impl.HistoryQueryGetNumberOfChangesByType;
import com.mercury.topaz.cmdb.history.shared.operation.query.impl.HistoryQueryGetRemovedData;
import com.mercury.topaz.cmdb.history.shared.operation.update.impl.HistoryUpdateAddCmdbChanges;
import com.mercury.topaz.cmdb.history.shared.operation.update.impl.HistoryUpdateCleanHistoryTables;
import com.mercury.topaz.cmdb.history.shared.operation.update.impl.HistoryUpdateOptimizeStorage;
import com.mercury.topaz.cmdb.history.shared.operation.update.impl.HistoryUpdatePurgeHistoryTables;
import com.mercury.topaz.cmdb.server.base.jmx.AbstractCmdbJmx;
import com.mercury.topaz.cmdb.shared.change.CmdbChange;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.change.impl.CmdbChangeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClasses;
import com.mercury.topaz.cmdb.shared.classmodel.operation.query.impl.ClassModelQueryGetWholeClassModel;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.model.change.impl.ModelChangesFactory;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.ChangerType;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.link.impl.InternalExCmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="Topaz:service=CMDB History DB Services", description="CMDB History DB Services")
public class HistoryDBToolsJMX extends AbstractCmdbJmx
  implements HistoryDBToolsJMXInterface
{
  private static final Log _logger = HistoryLogFactory.getHistoryLog();
  private static final Changer CHANGER = ChangerFactory.createChanger(ChangerType.INITIALIZATION, "CMDB");
  private static final SimpleDateFormat DATE_FORMAT1 = new SimpleDateFormat("dd/MM/yyyy");
  private static final SimpleDateFormat DATE_FORMAT2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
  private static final String BAD_DATE = "Date format error! Date must be supplied as <b>long</b> or in one of the formats <b>dd/MM/yyyy</b> or <b>dd/MM/yyyy HH:mm:ss</b> in server's timezone.<br/><br/>For reference see <a href=\"http://java.sun.com/j2se/1.5.0/docs/api/java/text/SimpleDateFormat.html\">SimpleDateFormat</a>";

  @ManagedOperation(description="Initialize the history DB with the current data in the model")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String initializeHistoryDBFromModel(Integer customerID)
  {
    if (_logger.isInfoEnabled()) {
      _logger.info("Starting initialization of History DB");
    }

    CmdbContext context = createContext(customerID);

    if (_logger.isInfoEnabled())
      _logger.info("Cleaning History DB tables");

    cleanHistoryTables(context);

    if (_logger.isInfoEnabled())
      _logger.info("Adding objects/links as AddObject/AddLink changes to History DB");

    ElementSimpleLayout simpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    for (int i = 0; i < HistoryConstants.HISTORY_QUALIFIERS.length; ++i) {
      simpleLayout.addPropertiesQulifiers(HistoryConstants.HISTORY_QUALIFIERS[i]);
    }

    ClassModelQueryGetWholeClassModel getClassModel = new ClassModelQueryGetWholeClassModel();
    invokeOperation(getClassModel, context);

    CmdbClasses classes = getClassModel.getClassModel().getAllClasses();
    ReadOnlyIterator it = classes.getIterator();
    while (it.hasNext()) {
      CmdbClass curClass = (CmdbClass)it.next();
      insertToHistoryByClass(context, curClass.isTypeOfObject(), curClass.getName(), simpleLayout);
    }
    if (_logger.isInfoEnabled())
      _logger.info("History DB initialization was finished.");

    return "Initialization was finished. Please view history log file for details";
  }

  private void insertToHistoryByClass(CmdbContext context, boolean isObject, String className, ElementSimpleLayout simpleLayout)
  {
    ModifiablePatternGraph patternGraph;
    try {
      patternGraph = PatternGraphFactory.createModifiableGraph();
      PatternElementNumber number = PatternElementNumberFactory.createElementNumber(1);
      ElementCondition classCondition = PatternConditionFactory.createElementCondition(className, false);
      PatternLayout patternLayout = PatternLayoutFactory.createLayout();
      patternLayout.setElementLayout(number, simpleLayout);
      CmdbChange curChange = null;

      if (isObject) {
        PatternNode node = PatternGraphFactory.createPatternNode(number, classCondition, true, null);
        patternGraph.addNode(node);
        Pattern pattern = PatternDefinitionFactory.createPattern("", "historyDB", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

        TqlQueryGetAdHocMap getResult = new TqlQueryGetAdHocMap(pattern, patternLayout);
        invokeOperation(getResult, context);

        TqlResultMap result = getResult.getResultMap();
        if (result.containsElementNumber(number)) {
          CmdbObjects objects = result.getObjects(number);
          curChange = ModelChangesFactory.createAddObjectsChange(objects);
          if (_logger.isDebugEnabled())
            _logger.debug("found " + objects.size() + " instances of class " + className + ".");
        }
      }
      else {
        PatternElementNumber end1 = PatternElementNumberFactory.createElementNumber(3);
        PatternElementNumber end2 = PatternElementNumberFactory.createElementNumber(2);
        ModifiableNodeLinksCondition linkCond = PatternConditionFactory.createNodeLinksCondition();
        linkCond.addLinkCardinality(PatternConditionFactory.createLinkCardinality(number.getNumber(), 1, -1));
        ElementCondition endCondition = PatternConditionFactory.createElementCondition("object", true);
        PatternNode end1Node = PatternGraphFactory.createPatternNode(end1, endCondition, true, linkCond);
        PatternNode end2Node = PatternGraphFactory.createPatternNode(end2, endCondition, true, linkCond);
        PatternLink link = PatternGraphFactory.createPatternLink(number, end1, end2, classCondition, true);
        patternGraph.addNode(end1Node);
        patternGraph.addNode(end2Node);
        patternGraph.addLink(link);
        Pattern pattern = PatternDefinitionFactory.createPattern("", "historyDB", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);
        TqlQueryGetAdHocMap getResult = new TqlQueryGetAdHocMap(pattern, patternLayout);
        invokeOperation(getResult, context);

        TqlResultMap result = getResult.getResultMap();
        if (result.containsElementNumber(number)) {
          CmdbLinks links = CmdbLinkFactory.createLinks();
          for (Iterator i$ = result.getLinks(number).iterator(); i$.hasNext(); ) { CmdbLink cmdbLink = (CmdbLink)i$.next();
            String end1Type = ((CmdbObject)result.getObjects(end1).get(cmdbLink.getEnd1())).getType();
            String end2Type = ((CmdbObject)result.getObjects(end2).get(cmdbLink.getEnd2())).getType();
            links.add(InternalExCmdbLinkFactory.createInternalExCmdbLink(cmdbLink, end1Type, end2Type));
          }
          curChange = ModelChangesFactory.createAddLinksChange(links, null);
          if (_logger.isDebugEnabled())
            _logger.debug("found " + links.size() + " instances of class " + className + ".");
        }
      }

      if (curChange != null) {
        CmdbChanges changes = CmdbChangeFactory.createCmdbChangesForOneChange(curChange, CHANGER);
        HistoryUpdateAddCmdbChanges addChanges = new HistoryUpdateAddCmdbChanges(changes);
        invokeOperation(addChanges, context);
      }
    }
    catch (Exception e) {
      _logger.error("Error while trying to initialize History with instances from type: " + className + ". " + e);
    }
  }

  private void cleanHistoryTables(CmdbContext context) {
    HistoryUpdateCleanHistoryTables cleanTables = new HistoryUpdateCleanHistoryTables();
    invokeOperation(cleanTables, context);
  }

  @ManagedOperation(description="Delete the data from the history DB")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String clearHistoryDB(Integer customerID)
  {
    cleanHistoryTables(createContext(customerID));
    return "History DB was cleaned";
  }

  @ManagedOperation(description="Purge the history DB according to the settings")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String purgeHistoryDB(Integer customerID)
  {
    HistoryUpdatePurgeHistoryTables purge = new HistoryUpdatePurgeHistoryTables();
    return executePurging(customerID, purge);
  }

  @ManagedOperation(description="Purge the history DB according to the input of how many days to save")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="daysToSaveBack", description="Days To Save Back In The History")})
  public String purgeHistoryDB(Integer customerID, int daysToSaveBack)
  {
    HistoryUpdatePurgeHistoryTables purge = new HistoryUpdatePurgeHistoryTables(daysToSaveBack);
    return executePurging(customerID, purge);
  }

  private String executePurging(Integer customerID, HistoryUpdatePurgeHistoryTables purge) {
    invokeOperation(purge, createContext(customerID));
    return "History DB was purged";
  }

  @ManagedOperation(description="Start the history DB for saving and publishing changes")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String startHistoryDB(Integer customerID)
  {
    HistoryCommandEnableHistory history = new HistoryCommandEnableHistory();
    invokeOperation(history, createContext(customerID));
    return "History DB was started";
  }

  @ManagedOperation(description="Stop the history DB from saving and publishing changes")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String stopHistoryDB(Integer customerID)
  {
    HistoryCommandDisableHistory history = new HistoryCommandDisableHistory();
    invokeOperation(history, createContext(customerID));
    return "History DB was stopped";
  }

  @ManagedOperation(description="Run statistics on the history DB")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String runStatistics(Integer customerID)
  {
    HistoryUpdateOptimizeStorage optimize = new HistoryUpdateOptimizeStorage();
    invokeOperation(optimize, createContext(customerID));
    return "Finished To Run Statistics";
  }

  @ManagedOperation(description="Get number of changes according to id and time (including relations)")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="objectID", description="Object ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="fromDate", description="Date as long or in one of the formats: dd/MM/yyyy or dd/MM/yyyy HH:mm:ss"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="toDate", description="Date as long or in one of the formats: dd/MM/yyyy or dd/MM/yyyy HH:mm:ss")})
  public String getHistoryChangesExtendedCounter(Integer customerID, String objectID, String fromDate, String toDate)
  {
    Date from = parseDate(fromDate);
    Date to = parseDate(toDate);
    if ((from == null) || (to == null)) return "Date format error! Date must be supplied as <b>long</b> or in one of the formats <b>dd/MM/yyyy</b> or <b>dd/MM/yyyy HH:mm:ss</b> in server's timezone.<br/><br/>For reference see <a href=\"http://java.sun.com/j2se/1.5.0/docs/api/java/text/SimpleDateFormat.html\">SimpleDateFormat</a>";
    HistoryFilter historyFilter = HistoryFilterFactory.create(from, to);
    CmdbObjectID id = CmdbObjectID.Factory.restoreObjectID(objectID.toLowerCase());
    CmdbDataIDs ids = CmdbDataIdsFactory.create();
    ids.add(id);
    HistoryQueryGetExtendedNumberOfChanges getNumOfChanges = new HistoryQueryGetExtendedNumberOfChanges(ids, historyFilter);
    invokeOperation(getNumOfChanges, createContext(customerID));
    return getNumOfChanges.getHistoryChangesCounter().toString();
  }

  @ManagedOperation(description="Get number of changes according to class type and time")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="ciType", description="CI Type"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="fromDate", description="Date as long or in one of the formats: dd/MM/yyyy or dd/MM/yyyy HH:mm:ss"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="toDate", description="Date as long or in one of the formats: dd/MM/yyyy or dd/MM/yyyy HH:mm:ss")})
  public String getHistoryChangesCounterByType(Integer customerID, String ciType, String fromDate, String toDate)
  {
    Date from = parseDate(fromDate);
    Date to = parseDate(toDate);
    if ((from == null) || (to == null)) return "Date format error! Date must be supplied as <b>long</b> or in one of the formats <b>dd/MM/yyyy</b> or <b>dd/MM/yyyy HH:mm:ss</b> in server's timezone.<br/><br/>For reference see <a href=\"http://java.sun.com/j2se/1.5.0/docs/api/java/text/SimpleDateFormat.html\">SimpleDateFormat</a>";
    String[] classTypes = { ciType };
    HistoryFilter historyFilter = HistoryFilterFactory.create(from, to, classTypes);
    HistoryQueryGetNumberOfChangesByType getNumOfChanges = new HistoryQueryGetNumberOfChangesByType(historyFilter);
    invokeOperation(getNumOfChanges, createContext(customerID));
    return getNumOfChanges.getCountersByType().toString();
  }

  @ManagedOperation(description="Get data that was removed according to the time")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="fromDate", description="Date as long or in one of the formats: dd/MM/yyyy or dd/MM/yyyy HH:mm:ss"), @org.springframework.jmx.export.annotation.ManagedOperationParameter(name="toDate", description="Date as long or in one of the formats: dd/MM/yyyy or dd/MM/yyyy HH:mm:ss")})
  public String getRemovedData(Integer customerID, String fromDate, String toDate)
  {
    Date from = parseDate(fromDate);
    Date to = parseDate(toDate);
    if ((from == null) || (to == null)) return "Date format error! Date must be supplied as <b>long</b> or in one of the formats <b>dd/MM/yyyy</b> or <b>dd/MM/yyyy HH:mm:ss</b> in server's timezone.<br/><br/>For reference see <a href=\"http://java.sun.com/j2se/1.5.0/docs/api/java/text/SimpleDateFormat.html\">SimpleDateFormat</a>";
    HistoryFilter historyFilter = HistoryFilterFactory.create(from, to);
    HistoryQueryGetRemovedData getRemovedData = new HistoryQueryGetRemovedData(historyFilter);
    invokeOperation(getRemovedData, createContext(customerID));
    CmdbDatas datas = getRemovedData.getDatas();
    StringBuilder removedDataStr = new StringBuilder("The Data that was removed between ").append(fromDate).append(" to ").append(toDate).append(":\n");

    if (datas != null) {
      ReadOnlyIterator it = datas.getDatasIterator();
      while (it.hasNext())
        removedDataStr.append(it.next().toString()).append("\n");
    }

    return removedDataStr.toString();
  }

  @ManagedOperation(description="Returns true if history is enabled")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String isHistoryEnabled(Integer customerID)
  {
    HistoryCommandIsHistoryEnabled isEnabled = new HistoryCommandIsHistoryEnabled();
    invokeOperation(isEnabled, createContext(customerID));
    return isEnabled.isHistoryDBEnabled().toString();
  }

  @ManagedOperation(description="Get history DB context")
  @ManagedOperationParameters({@org.springframework.jmx.export.annotation.ManagedOperationParameter(name="customerID", description="Customer ID")})
  public String getHistoryDBContext(Integer customerID)
  {
    HistoryQueryGetHistoryDbContext getContext = new HistoryQueryGetHistoryDbContext();
    invokeOperation(getContext, createContext(customerID));
    return getContext.getDbContext().toString(); }

  private Date parseDate(String s) {
    long l;
    try {
      l = Long.parseLong(s);
      return new Date(l);
    }
    catch (NumberFormatException e1)
    {
      try {
        return DATE_FORMAT2.parse(s);
      }
      catch (ParseException e1)
      {
        try {
          return DATE_FORMAT1.parse(s); } catch (ParseException e1) {
        }
      }
    }
    return null;
  }
}