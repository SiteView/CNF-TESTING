package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.impl.CmdbDatasFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class HistoryDalGetDataLayoutWithoutPropsCommand extends AbstractHistoryDalQueryCommand<CmdbDatas<CmdbDataID, CmdbData<?>>>
{
  private CmdbIDsCollection<CmdbDataID> _cmdbDataIDs;
  private Date _layoutDate;
  private String[] _classTypesFilter;

  public HistoryDalGetDataLayoutWithoutPropsCommand(CmdbIDsCollection<CmdbDataID> cmdbDataIDs, Date layoutDate, String[] classTypesFilter)
  {
    setCmdbDataIDs(cmdbDataIDs);
    setLayoutDate(layoutDate);
    this._classTypesFilter = classTypesFilter;
  }

  protected CmdbDatas<CmdbDataID, CmdbData<?>> perform() throws Exception {
    return queryTables();
  }

  protected void validateInput() {
  }

  protected CmdbDatas<CmdbDataID, CmdbData<?>> queryTables() throws SQLException {
    CmdbDatas datas = CmdbDatasFactory.create();
    if (useTempTable(getCmdbDataIDs().size()))
      runSelectInTempTable(datas);

    runSelectInChunks(datas);
    return datas;
  }

  protected void runSelectInChunks(CmdbDatas<CmdbDataID, CmdbData<?>> datas) throws SQLException {
    CmdbIDsCollection idsLeft = getCmdbDataIDs();
    int maxIDsInChunk = getMaxPossibleSizeForInChunk();
    int numOfChunks = calcNumOfInChunks(idsLeft.size());
    for (int chunkNum = 0; chunkNum < numOfChunks; ++chunkNum) {
      int numOfIDs = (idsLeft.size() > maxIDsInChunk) ? maxIDsInChunk : idsLeft.size();
      runSelectForIDs(datas, createInSqlString(numOfIDs, "e", HISTORY_CHANGES_CI_ID_COLUMN_NAME), idsLeft, numOfIDs);
      if (idsLeft.size() - numOfIDs > 0)
        idsLeft = removeIDsFromCollection(idsLeft, numOfIDs);
    }
  }

  protected void runSelectInTempTable(CmdbDatas<CmdbDataID, CmdbData<?>> datas) throws SQLException
  {
    createCmdbIDTempTable(getConnection(), elementsToIDsAsBytes(getCmdbDataIDs()));
    runSelectForIDs(datas, createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", "e", HISTORY_CHANGES_CI_ID_COLUMN_NAME), null, getCmdbDataIDs().size());
  }

  protected StringBuilder getSelectSql() {
    return new StringBuilder("select e.").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_END1_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_END2_COLUMN_NAME);
  }

  protected StringBuilder getFromSql()
  {
    return new StringBuilder(" from ").append(HISTORY_CHANGES_TABLE_NAME).append(" e ");
  }

  protected StringBuilder getWhereSql(StringBuilder idsInCondition, int numOfIDs) {
    StringBuilder whereQuery = new StringBuilder(" where e.").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?");
    if (numOfIDs > 0) {
      whereQuery.append(" and ").append(idsInCondition);
    }

    whereQuery.append(" and e.").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<=?");

    if ((this._classTypesFilter != null) && (this._classTypesFilter.length > 0))
      whereQuery.append(" and ").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(createInSqlString(this._classTypesFilter.length));

    return whereQuery;
  }

  protected CmdbDatas<CmdbDataID, CmdbData<?>> runSelectForIDs(CmdbDatas<CmdbDataID, CmdbData<?>> datas, StringBuilder idsInCondition, CmdbIDsCollection<CmdbDataID> idsLeft, int numOfIDs)
    throws SQLException
  {
    StringBuilder sqlQuery = new StringBuilder().append(getSelectSql()).append(getFromSql()).append(getWhereSql(idsInCondition, numOfIDs));
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlQuery.toString());

    preparedStatement.setInt(getCustomerID().getID());

    if ((numOfIDs > 0) && (idsLeft != null) && (!(idsLeft.isEmpty()))) {
      List variables = new ArrayList(numOfIDs);
      addCmdbIdsToInList(idsLeft, variables, numOfIDs);
      for (Iterator i$ = variables.iterator(); i$.hasNext(); ) { Object variable = i$.next();
        preparedStatement.setBytes((byte[])(byte[])variable);
      }

    }

    preparedStatement.setDate(getLayoutDate());

    if ((this._classTypesFilter != null) && (this._classTypesFilter.length > 0)) {
      String[] arr$ = this._classTypesFilter; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String a_classTypesFilter = arr$[i$];
        preparedStatement.setString(a_classTypesFilter);
      }

    }

    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    analyzeResults(datas, resultSet);
    preparedStatement.close();
    return datas;
  }

  protected void analyzeResults(CmdbDatas<CmdbDataID, CmdbData<?>> datas, CmdbDalResultSet resultSet) throws SQLException {
    while (resultSet.next()) {
      Boolean isObject = resultSet.getBoolean(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME);
      byte[] idAsBytes = resultSet.getBytes(HISTORY_CHANGES_CI_ID_COLUMN_NAME);
      String type = resultSet.getString(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME);

      if (isObject.booleanValue()) {
        CmdbObjectID id = CmdbObjectID.Factory.restoreObjectID(idAsBytes);
        datas.add(CmdbObjectFactory.createObject(id, type));
      }
      else {
        CmdbLinkID id = CmdbLinkID.Factory.restoreLinkID(idAsBytes);
        byte[] end1IdAsBytes = resultSet.getBytes(HISTORY_CHANGES_END1_COLUMN_NAME);
        byte[] end2IdAsBytes = resultSet.getBytes(HISTORY_CHANGES_END2_COLUMN_NAME);
        CmdbObjectID end1ID = CmdbObjectID.Factory.restoreObjectID(end1IdAsBytes);
        CmdbObjectID end2ID = CmdbObjectID.Factory.restoreObjectID(end2IdAsBytes);
        datas.add(CmdbLinkFactory.createLink(id, end1ID, end2ID, type));
      }
    }
    resultSet.close();
  }

  protected CmdbIDsCollection<CmdbDataID> getCmdbDataIDs() {
    return this._cmdbDataIDs;
  }

  private void setCmdbDataIDs(CmdbIDsCollection<CmdbDataID> cmdbDataIDs) {
    this._cmdbDataIDs = cmdbDataIDs;
  }

  public Date getLayoutDate() {
    return this._layoutDate;
  }

  public void setLayoutDate(Date layoutDate) {
    this._layoutDate = layoutDate;
  }
}