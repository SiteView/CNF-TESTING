package com.mercury.topaz.cmdb.history.shared.change.manage.impl;

import com.mercury.topaz.cmdb.history.client.change.manage.HistoryChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.impl.AbstractCmdbChangeListener;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public abstract class AbstractHistoryChangeListenerCorseGrained extends AbstractCmdbChangeListener
  implements HistoryChangeListenerCorseGrained
{
  public AbstractHistoryChangeListenerCorseGrained(CmdbCustomerID customerID)
  {
    super(FrameworkConstants.Subsystem.HISTORY, customerID);
  }
}