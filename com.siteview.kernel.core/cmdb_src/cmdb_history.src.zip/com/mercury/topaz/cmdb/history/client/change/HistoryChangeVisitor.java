package com.mercury.topaz.cmdb.history.client.change;

import com.mercury.topaz.cmdb.history.client.change.info.HistoryChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryLinkChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;

public abstract interface HistoryChangeVisitor
{
  public abstract void addObjectChange(HistoryObjectChangeInfo paramHistoryObjectChangeInfo);

  public abstract void updateObjectChange(HistoryObjectChangeInfo paramHistoryObjectChangeInfo);

  public abstract void removeObjectChange(HistoryObjectChangeInfo paramHistoryObjectChangeInfo);

  public abstract void addLinkChange(HistoryLinkChangeInfo paramHistoryLinkChangeInfo);

  public abstract void updateLinkChange(HistoryLinkChangeInfo paramHistoryLinkChangeInfo);

  public abstract void removeLinkChange(HistoryLinkChangeInfo paramHistoryLinkChangeInfo);

  public abstract void addRelationChange(HistoryObjectChangeInfo paramHistoryObjectChangeInfo);

  public abstract void removeRelationChange(HistoryObjectChangeInfo paramHistoryObjectChangeInfo);

  public abstract void addDataChange(HistoryChangeInfo paramHistoryChangeInfo);

  public abstract void updateDataChange(HistoryChangeInfo paramHistoryChangeInfo);

  public abstract void removeDataChange(HistoryChangeInfo paramHistoryChangeInfo);
}