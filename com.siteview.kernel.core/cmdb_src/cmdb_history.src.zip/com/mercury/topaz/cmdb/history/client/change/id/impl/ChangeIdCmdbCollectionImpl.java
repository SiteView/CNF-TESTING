package com.mercury.topaz.cmdb.history.client.change.id.impl;

import com.mercury.topaz.cmdb.history.client.change.id.ChangeIdCmdbCollection;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class ChangeIdCmdbCollectionImpl
  implements ChangeIdCmdbCollection
{
  private List<Long> idsList;

  public ChangeIdCmdbCollectionImpl()
  {
    this.idsList = new ArrayList();
  }

  public ChangeIdCmdbCollectionImpl(List<Long> ids) {
    this.idsList = new ArrayList(ids);
  }

  public int size() {
    return this.idsList.size();
  }

  public boolean isEmpty() {
    return this.idsList.isEmpty();
  }

  public ReadOnlyIterator<Long> getReadOnlyIterator() {
    return new ReadOnlyIteratorImpl(iterator());
  }

  public Iterator<Long> iterator() {
    return this.idsList.iterator();
  }

  public void clear() {
    this.idsList.clear();
  }

  public void addChangeId(Long id) {
    this.idsList.add(id);
  }

  public List<Long> getChangeIds() {
    return this.idsList;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    ChangeIdCmdbCollectionImpl that = (ChangeIdCmdbCollectionImpl)o;
    if ((this.idsList == null) && (that.idsList == null))
      return true;

    if ((this.idsList == null) || (that.idsList == null))
      return false;

    Set idsSet = new HashSet(this.idsList);
    Set idsSet1 = new HashSet(that.idsList);

    return idsSet.equals(idsSet1);
  }

  public int hashCode() {
    return ((this.idsList != null) ? this.idsList.hashCode() : 0);
  }

  public boolean contains(Long e) {
    return this.idsList.contains(e);
  }
}