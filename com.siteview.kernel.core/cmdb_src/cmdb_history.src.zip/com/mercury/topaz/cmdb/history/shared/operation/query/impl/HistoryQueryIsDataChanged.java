package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.filter.impl.HistoryFilterFactory;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import java.util.Date;

public class HistoryQueryIsDataChanged extends AbstractHistoryQueryOperation
{
  private static final String IS_DATA_CHANGED = "IS_DATA_CHANGED";
  private CmdbIDsCollection _cmdbDataIDs;
  private Date _dateAfterChanged;
  private CmdbDataIDs _changedDataIds;
  private HistoryFilter _historyFilter;

  public HistoryQueryIsDataChanged(CmdbIDsCollection cmdbDataIDs, Date dateAfterChanged)
  {
    this(cmdbDataIDs, dateAfterChanged, HistoryFilterFactory.EMPTY_FILTER);
  }

  public HistoryQueryIsDataChanged(CmdbIDsCollection cmdbDataIDs, Date dateAfterChanged, HistoryFilter historyFilter) {
    setCmdbDataIDs(cmdbDataIDs);
    setHistoryFilter(historyFilter);
    setDateAfterChanged(dateAfterChanged);
  }

  public HistoryQueryIsDataChanged(CmdbIDsCollection cmdbDataIDs, HistoryFilter historyFilter) {
    setCmdbDataIDs(cmdbDataIDs);
    setHistoryFilter(historyFilter);
    setDateAfterChanged(null);
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException {
    CmdbDataIDs changedDataIDs = historyQueryManager.checkIfDataWasChanged(getCmdbDataIDs(), getDateAfterChanged(), getHistoryFilter());
    response.addResult("IS_DATA_CHANGED", changedDataIDs);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setChangedDataIds((CmdbDataIDs)response.getResult("IS_DATA_CHANGED"));
  }

  public boolean isAnyDataChanged()
  {
    return (getChangedDataIds().size() != 0);
  }

  public CmdbDataIDs getChangedDataIds()
  {
    return this._changedDataIds;
  }

  public String getOperationName() {
    return "history query: is data changed ";
  }

  private CmdbIDsCollection getCmdbDataIDs() {
    return this._cmdbDataIDs;
  }

  private void setCmdbDataIDs(CmdbIDsCollection cmdbDataIDs) {
    if ((cmdbDataIDs == null) || (cmdbDataIDs.isEmpty()))
      throw new IllegalArgumentException("data ids is null or empty");

    this._cmdbDataIDs = cmdbDataIDs;
  }

  private Date getDateAfterChanged() {
    return this._dateAfterChanged;
  }

  private void setDateAfterChanged(Date dateAfterChanged) {
    if ((dateAfterChanged == null) && ((
      (getHistoryFilter().getToDate() == null) || (getHistoryFilter().getFromDate() == null)))) {
      throw new IllegalArgumentException("date is null, you must set date after changed or fill history filter with both to and from dates.");
    }

    this._dateAfterChanged = dateAfterChanged;
  }

  private void setChangedDataIds(CmdbDataIDs changedDataIds) {
    if (changedDataIds == null)
      throw new IllegalArgumentException("changed data ids is  null");

    this._changedDataIds = changedDataIds;
  }

  private HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    if (historyFilter == null)
      throw new IllegalArgumentException("history filter is  null");

    this._historyFilter = historyFilter;
  }
}