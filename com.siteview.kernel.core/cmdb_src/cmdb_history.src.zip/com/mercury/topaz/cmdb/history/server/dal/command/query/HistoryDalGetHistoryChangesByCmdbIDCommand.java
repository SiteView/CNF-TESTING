package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.util.CmdbCollection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

public class HistoryDalGetHistoryChangesByCmdbIDCommand extends AbstractHistoryDalGetHistoryChanges
{
  private CmdbIDsCollection<CmdbDataID> _cmdbDataIDs;

  public HistoryDalGetHistoryChangesByCmdbIDCommand(CmdbIDsCollection<CmdbDataID> dataIDs, HistoryFilter historyFilter, DataLayout layout)
  {
    super(historyFilter, layout);
    setCmdbDataID(dataIDs);
  }

  protected CmdbIDsCollection<CmdbDataID> getCmdbDataIDs() {
    return this._cmdbDataIDs;
  }

  private void setCmdbDataID(CmdbIDsCollection<CmdbDataID> cmdbDataIDs) {
    if (cmdbDataIDs == null)
      throw new IllegalArgumentException("cmdb data ids is null");

    this._cmdbDataIDs = cmdbDataIDs;
  }

  protected void createIDTempTable() throws SQLException
  {
    List ids = elementsToIDsAsBytes(getCmdbDataIDs());
    createCmdbIDTempTable(getConnection(), ids);
  }

  protected StringBuilder createInSqlStringForIdTempTable() {
    return createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", "e", HISTORY_CHANGES_CI_ID_COLUMN_NAME);
  }

  protected StringBuilder createInSqlStringForEnd1IdTempTable() {
    return createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", "e", HISTORY_CHANGES_END1_COLUMN_NAME);
  }

  protected void addIdsToInList(CmdbCollection<CmdbDataID> dataIDs, List<Object> variables, int numOfIDs) {
    addCmdbIdsToInList((CmdbIDsCollection)dataIDs, variables, numOfIDs);
  }

  protected void fillPreparedStatementWithIDs(CmdbDalPreparedStatement preparedStatement, List variables) throws SQLException {
    for (Iterator i$ = variables.iterator(); i$.hasNext(); ) { Object variable = i$.next();
      preparedStatement.setBytes((byte[])(byte[])variable);
    }
  }

  protected CmdbCollection getFilterIDs() {
    return getCmdbDataIDs();
  }

  protected CmdbCollection copyIDs(CmdbCollection ids, int startFromIndex) {
    return removeIDsFromCollection((CmdbIDsCollection)ids, startFromIndex);
  }

  protected StringBuilder createInSqlStringForIdColumn(StringBuilder inSql) {
    return createInSqlString("e", HISTORY_CHANGES_CI_ID_COLUMN_NAME, inSql);
  }

  protected StringBuilder createInSqlStringForEnd1IdColumn(StringBuilder inSql) {
    return createInSqlString("e", HISTORY_CHANGES_END1_COLUMN_NAME, inSql);
  }

  protected boolean useUnion() {
    return isRelationInFilter();
  }
}