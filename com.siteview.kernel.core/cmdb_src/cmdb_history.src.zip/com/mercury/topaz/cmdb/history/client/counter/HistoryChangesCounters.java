package com.mercury.topaz.cmdb.history.client.counter;

import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.Serializable;

public abstract interface HistoryChangesCounters extends Serializable
{
  public abstract int size();

  public abstract ReadOnlyIterator getCountersIterator();
}