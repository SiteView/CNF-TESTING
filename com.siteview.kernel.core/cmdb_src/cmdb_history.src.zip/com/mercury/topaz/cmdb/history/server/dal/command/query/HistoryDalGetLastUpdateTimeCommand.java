package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class HistoryDalGetLastUpdateTimeCommand extends AbstractHistoryDalQueryCommand<Map<CmdbDataID, Date>>
{
  private CmdbIDsCollection _dataIDs;

  public HistoryDalGetLastUpdateTimeCommand(CmdbIDsCollection ids)
  {
    setDataIDs(ids);
  }

  protected Map<CmdbDataID, Date> perform() throws Exception {
    if (useTempTable(getDataIDs().size()))
      return runSelectInTempTable();

    return runSelectInChunks();
  }

  private void analyzeResults(Map<CmdbDataID, Date> results, CmdbDalResultSet resultSet) throws SQLException {
    while (resultSet.next()) {
      CmdbDataID id;
      Boolean isObject = resultSet.getBoolean(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME);
      Date changeDate = resultSet.getDate(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME);

      if (isObject.booleanValue()) {
        byte[] idAsBytes = resultSet.getBytes(HISTORY_CHANGES_CI_ID_COLUMN_NAME);
        id = CmdbObjectID.Factory.restoreObjectID(idAsBytes);
      } else {
        byte[] end1 = resultSet.getBytes(HISTORY_CHANGES_END1_COLUMN_NAME);
        id = CmdbObjectID.Factory.restoreObjectID(end1);
      }
      if (results.containsKey(id)) {
        Date changeDateInMap = (Date)results.get(id);
        if (changeDateInMap.before(changeDate))
          results.put(id, changeDate);
      }
      else {
        results.put(id, changeDate);
      }
    }
    resultSet.close();
  }

  private Map<CmdbDataID, Date> runSelectInChunks() throws SQLException {
    Map results = new HashMap();
    CmdbIDsCollection idsLeft = getDataIDs();
    int maxIDsInChunk = getMaxPossibleSizeForInChunk();
    int numOfChunks = calcNumOfInChunks(idsLeft.size());
    for (int chunkNum = 0; chunkNum < numOfChunks; ++chunkNum) {
      int numOfIDs = (idsLeft.size() > maxIDsInChunk) ? maxIDsInChunk : idsLeft.size();
      StringBuilder inSql = createInSqlString(numOfIDs);
      runSelectForIDs(results, createInSqlString(null, HISTORY_CHANGES_CI_ID_COLUMN_NAME, inSql), createInSqlString(null, HISTORY_CHANGES_END1_COLUMN_NAME, inSql), idsLeft, numOfIDs);
      if (idsLeft.size() - numOfIDs > 0)
        idsLeft = removeIDsFromCollection(idsLeft, numOfIDs);
    }

    return results;
  }

  private Map<CmdbDataID, Date> runSelectInTempTable() throws SQLException {
    Map results = new HashMap();
    createCmdbIDTempTable(getConnection(), elementsToIDsAsBytes(getDataIDs()));
    runSelectForIDs(results, createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", null, HISTORY_CHANGES_CI_ID_COLUMN_NAME), createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", null, HISTORY_CHANGES_END1_COLUMN_NAME), getDataIDs(), 0);
    return results;
  }

  private void runSelectForIDs(Map<CmdbDataID, Date> results, StringBuilder idsInCondition, StringBuilder end1IdsInCondition, CmdbIDsCollection idsLeft, int numOfIDs) throws SQLException
  {
    StringBuilder query = new StringBuilder("select ").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME).append(",max(").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(") ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(",").append(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME).append(",").append(HISTORY_CHANGES_END1_COLUMN_NAME).append(" from (");

    query.append(getQueryPart1(idsInCondition)).append(" union ").append(getQueryPart2(end1IdsInCondition));
    query.append(") tmp group by ").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME).append(",").append(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME).append(",").append(HISTORY_CHANGES_END1_COLUMN_NAME);

    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(query.toString());
    List variables = new ArrayList(numOfIDs);
    addCmdbIdsToInList(idsLeft, variables, numOfIDs);

    fillPreparedStatementPart1(preparedStatement, numOfIDs, variables);
    fillPreparedStatementPart2(preparedStatement, numOfIDs, variables);

    CmdbDalResultSet resultSet = preparedStatement.executeQuery();
    analyzeResults(results, resultSet);
    preparedStatement.close();
  }

  private StringBuilder getSelectAndFromQuery() {
    StringBuilder query = new StringBuilder("select ").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME).append(",").append(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME).append(",").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(",").append(HISTORY_CHANGES_END1_COLUMN_NAME);

    query.append(" from ").append(HISTORY_CHANGES_TABLE_NAME);
    return query;
  }

  private StringBuilder getQueryPart1(StringBuilder idsInCondition) {
    StringBuilder query = getSelectAndFromQuery();
    query.append(" where ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=? and ").append(idsInCondition);

    return query;
  }

  private StringBuilder getQueryPart2(StringBuilder idsInCondition) {
    StringBuilder query = getSelectAndFromQuery();
    query.append(" where ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=? and ").append(idsInCondition).append(" and (").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append("=? or ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append("=?)");

    return query;
  }

  private void fillPreparedStatementBothParts(CmdbDalPreparedStatement preparedStatement, int numOfIDs, List<Object> variables)
    throws SQLException
  {
    preparedStatement.setInt(getCustomerID().getID());

    if (numOfIDs > 0)
      for (Iterator i$ = variables.iterator(); i$.hasNext(); ) { Object variable = i$.next();
        preparedStatement.setBytes((byte[])(byte[])variable);
      }
  }

  private void fillPreparedStatementPart1(CmdbDalPreparedStatement preparedStatement, int numOfIDs, List<Object> variables) throws SQLException
  {
    fillPreparedStatementBothParts(preparedStatement, numOfIDs, variables);
  }

  private void fillPreparedStatementPart2(CmdbDalPreparedStatement preparedStatement, int numOfIDs, List<Object> variables) throws SQLException {
    fillPreparedStatementBothParts(preparedStatement, numOfIDs, variables);

    preparedStatement.setString(ChangeConstants.CHANGE_TYPES.ADD_LINK);
    preparedStatement.setString(ChangeConstants.CHANGE_TYPES.REMOVE_LINK);
  }

  protected void validateInput() {
  }

  private CmdbIDsCollection getDataIDs() {
    return this._dataIDs;
  }

  private void setDataIDs(CmdbIDsCollection dataIDs) {
    this._dataIDs = dataIDs;
  }
}