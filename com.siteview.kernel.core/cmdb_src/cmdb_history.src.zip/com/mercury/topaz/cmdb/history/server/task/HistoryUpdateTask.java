package com.mercury.topaz.cmdb.history.server.task;

public class HistoryUpdateTask
{
  public static final String NAME = "History Update Task";
}