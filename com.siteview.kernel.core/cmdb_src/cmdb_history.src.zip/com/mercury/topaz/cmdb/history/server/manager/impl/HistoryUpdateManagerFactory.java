package com.mercury.topaz.cmdb.history.server.manager.impl;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.AbstractSubsystemManagerFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public class HistoryUpdateManagerFactory extends AbstractSubsystemManagerFactory
{
  public CmdbSubsystemManager createCmdbSubsystemManager(LocalEnvironment localEnvironment)
  {
    return new HistoryUpdateManagerImpl(localEnvironment);
  }
}