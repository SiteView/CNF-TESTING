package com.mercury.topaz.cmdb.history.server.task;

public class HistoryQueryTask
{
  public static final String NAME = "History Query Task";
}