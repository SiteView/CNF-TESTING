package com.mercury.topaz.cmdb.history.client.change.link;

import com.mercury.topaz.cmdb.history.client.change.HistoryChangeVisitor;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryLinkChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.manage.HistoryChangeListenerFineGrained;

public class HistoryChangeUpdateLink extends AbstractLinkHistoryChange
{
  HistoryChangeUpdateLink(HistoryLinkChangeInfo historyLinkChangeInfo)
  {
    super(historyLinkChangeInfo);
  }

  public void accept(HistoryChangeVisitor historyChangeVisitor) {
    historyChangeVisitor.updateDataChange(getHistoryLinkChangeInfo());
    historyChangeVisitor.updateLinkChange(getHistoryLinkChangeInfo());
  }

  public void execute(HistoryChangeListenerFineGrained changeListener) {
    changeListener.onUpdateLink(getHistoryLinkChangeInfo());
  }

  public String toString() {
    return ChangeConstants.CHANGE_TYPES.UPDATE_LINK + ": " + super.toString();
  }
}