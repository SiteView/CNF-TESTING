package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounter;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounters;
import com.mercury.topaz.cmdb.history.client.counter.impl.HistoryChangesTypedCounterFactory;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.sql.SQLException;

public class HistoryDalGetNumberOfChangesByType extends AbstractHistoryDalQueryCommand<HistoryChangesTypedCounters>
{
  private HistoryFilter _historyFilter;

  public HistoryDalGetNumberOfChangesByType(HistoryFilter historyFilter)
  {
    setHistoryFilter(historyFilter);
  }

  protected HistoryChangesTypedCounters perform()
    throws Exception
  {
    String query = getQuery();

    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(query);

    preparedStatement = fillPreparedStatement(preparedStatement);
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    HistoryChangesTypedCounters result = analyzeResultSet(resultSet);

    resultSet.close();
    preparedStatement.close();
    return result;
  }

  private String getQuery() {
    StringBuilder query = new StringBuilder("select ").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(", ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append(", count(*)");

    query.append(" from ").append(HISTORY_CHANGES_TABLE_NAME);
    query.append(" where ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?");

    if (getHistoryFilter().getFromDate() != null)
      query.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(">?");

    if (getHistoryFilter().getToDate() != null)
      query.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<=?");

    if ((getHistoryFilter().getClassTypes() != null) && (getHistoryFilter().getClassTypes().length > 0)) {
      query.append(" and ").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(createInSqlString(getHistoryFilter().getClassTypes().length));
    }

    query.append(" group by ").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(",").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME);
    return query.toString();
  }

  private CmdbDalPreparedStatement fillPreparedStatement(CmdbDalPreparedStatement preparedStatement) throws SQLException
  {
    preparedStatement.setInt(getCustomerID().getID());

    if (getHistoryFilter().getFromDate() != null)
      preparedStatement.setDate(getHistoryFilter().getFromDate());

    if (getHistoryFilter().getToDate() != null)
      preparedStatement.setDate(getHistoryFilter().getToDate());

    if ((getHistoryFilter().getClassTypes() != null) && (getHistoryFilter().getClassTypes().length > 0))
      for (int i = 0; i < getHistoryFilter().getClassTypes().length; ++i)
        preparedStatement.setString(getHistoryFilter().getClassTypes()[i]);


    return preparedStatement;
  }

  private HistoryChangesTypedCounters analyzeResultSet(CmdbDalResultSet resultSet) throws SQLException {
    HistoryChangesTypedCounters historyChangesTypedCounters = HistoryChangesTypedCounterFactory.createHistoryChangesTypedCounters();

    while (resultSet.next()) {
      String classType = resultSet.getString(1);
      String changeType = resultSet.getString(2);
      Integer changesCount = resultSet.getInt(3);
      HistoryChangesTypedCounter curCount = historyChangesTypedCounters.getTypedCounter(classType);
      if (curCount == null) {
        curCount = HistoryChangesTypedCounterFactory.createHistoryChangesTypedCounter(classType);
        historyChangesTypedCounters.add(curCount);
      }
      if ((ChangeConstants.CHANGE_TYPES.ADD_OBJECT.equals(changeType)) || (ChangeConstants.CHANGE_TYPES.ADD_LINK.equals(changeType))) {
        curCount.setAddedCount(changesCount.intValue());
      }
      else if ((ChangeConstants.CHANGE_TYPES.UPDATE_OBJECT.equals(changeType)) || (ChangeConstants.CHANGE_TYPES.UPDATE_LINK.equals(changeType))) {
        curCount.setUpdatedCount(changesCount.intValue());
      }
      else if ((ChangeConstants.CHANGE_TYPES.REMOVE_OBJECT.equals(changeType)) || (ChangeConstants.CHANGE_TYPES.REMOVE_LINK.equals(changeType)))
        curCount.setRemovedCount(changesCount.intValue());
    }

    return historyChangesTypedCounters;
  }

  protected void validateInput() {
  }

  private HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    this._historyFilter = historyFilter;
  }
}