package com.mercury.topaz.cmdb.history.server.dal.dao;

import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.client.change.id.ChangeIdCmdbCollection;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesExtendedCounter;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounters;
import com.mercury.topaz.cmdb.history.server.dal.command.query.AbstractHistoryDalGetHistoryChanges;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalGetDataLayoutInTheSameDateCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalGetExtendedNumberOfChanges;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalGetHistoryChangesByCmdbIDCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalGetHistoryChangesCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalGetHistoryChangesCommandByChangeIds;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalGetIDsByHistoryFilterCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalGetLastChangeByCmdbIDCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalGetLastUpdateTimeCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalGetNumberOfChangesByType;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalGetRemovedData;
import com.mercury.topaz.cmdb.history.server.dal.command.query.HistoryDalIsDataChangedCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.update.HistoryDalCleanTablesCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.update.HistoryDalPurgeHistoryTablesCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.update.link.HistoryDalAddLinksChangeCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.update.link.HistoryDalRemoveLinksChangeCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.update.link.HistoryDalUpdateLinksChangeCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.update.object.HistoryDalAddObjectsChangeCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.update.object.HistoryDalRemoveObjectsChangeCommand;
import com.mercury.topaz.cmdb.history.server.dal.command.update.object.HistoryDalUpdateObjectsChangeCommand;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandsContainer;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandsContainerFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalDAO;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalJdbcDAO;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolFactory;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import java.util.Date;
import java.util.Map;

public class CmdbDalJdbcHistoryDAO
  implements CmdbDalHistoryDAO
{
  private CmdbDalCommandsContainer container;
  private final CmdbDalDAO dao;

  public CmdbDalJdbcHistoryDAO(LocalEnvironment localEnvironment)
  {
    this.dao = new CmdbDalJdbcDAO(ConnectionPoolFactory.createHistoryPool(localEnvironment.getCustomerID().getID(), localEnvironment.getSettingsReader()));
  }

  public <T> CmdbDalCommandResult<T> executeQuery(CmdbDalCommand<T> command)
  {
    return this.dao.executeQuery(command);
  }

  public void execute(CmdbDalCommand<Void> command) {
    this.dao.execute(command);
  }

  private CmdbDalCommandsContainer getContainer() {
    if (this.container == null)
      this.container = CmdbDalCommandsContainerFactory.create();

    return this.container;
  }

  public void linksWereAdded(Changer changer, Date changeDate, CmdbLinks links) {
    HistoryDalAddLinksChangeCommand addedLinks = new HistoryDalAddLinksChangeCommand(changer, changeDate, links);
    getContainer().addCommand(addedLinks);
  }

  public void linksWereRemoved(Changer changer, Date changeDate, CmdbLinks links) {
    HistoryDalRemoveLinksChangeCommand removedLinks = new HistoryDalRemoveLinksChangeCommand(changer, changeDate, links);
    getContainer().addCommand(removedLinks);
  }

  public void linksWereUpdated(Changer changer, Date changeDate, CmdbLinks links) {
    HistoryDalUpdateLinksChangeCommand updatedLinks = new HistoryDalUpdateLinksChangeCommand(changer, changeDate, links);
    getContainer().addCommand(updatedLinks);
  }

  public void objectsWereAdded(Changer changer, Date changeDate, CmdbObjects objects) {
    HistoryDalAddObjectsChangeCommand addedObjects = new HistoryDalAddObjectsChangeCommand(changer, changeDate, objects);
    getContainer().addCommand(addedObjects);
  }

  public void objectsWereRemoved(Changer changer, Date changeDate, CmdbObjects objects) {
    HistoryDalRemoveObjectsChangeCommand removedObjects = new HistoryDalRemoveObjectsChangeCommand(changer, changeDate, objects);
    getContainer().addCommand(removedObjects);
  }

  public void objectsWereUpdated(Changer changer, Date changeDate, CmdbObjects objects) {
    HistoryDalUpdateObjectsChangeCommand updatedObjects = new HistoryDalUpdateObjectsChangeCommand(changer, changeDate, objects);
    getContainer().addCommand(updatedObjects);
  }

  public HistoryDatas getDataChanges(CmdbIDsCollection<CmdbDataID> cmdbDataIDs, HistoryFilter historyFilter, DataLayout dataLayout)
  {
    AbstractHistoryDalGetHistoryChanges getChanges;
    if ((cmdbDataIDs == null) || (cmdbDataIDs.isEmpty()))
      getChanges = new HistoryDalGetHistoryChangesCommand(historyFilter, dataLayout);
    else
      getChanges = new HistoryDalGetHistoryChangesByCmdbIDCommand(cmdbDataIDs, historyFilter, dataLayout);

    CmdbDalCommandResult result = executeQuery(getChanges);
    return ((HistoryDatas)result.getResult());
  }

  public HistoryDatas getDataChangesByChangeIds(ChangeIdCmdbCollection changeIds, DataLayout dataLayout, HistoryFilter historyFilter) {
    HistoryDalGetHistoryChangesCommandByChangeIds getChanges = new HistoryDalGetHistoryChangesCommandByChangeIds(changeIds, historyFilter, dataLayout);
    CmdbDalCommandResult result = executeQuery(getChanges);
    return ((HistoryDatas)result.getResult());
  }

  public HistoryDatas getDataLastChange(CmdbIDsCollection cmdbDataIDs, HistoryFilter historyFilter) {
    HistoryDalGetLastChangeByCmdbIDCommand getChanges = new HistoryDalGetLastChangeByCmdbIDCommand(cmdbDataIDs, historyFilter);
    CmdbDalCommandResult result = executeQuery(getChanges);
    return ((HistoryDatas)result.getResult());
  }

  public CmdbDatas getLayout(CmdbIDsCollection dataIDs, Date layoutDate, DataLayout dataLayout) {
    HistoryDalGetDataLayoutInTheSameDateCommand getData = new HistoryDalGetDataLayoutInTheSameDateCommand(dataIDs, layoutDate, dataLayout);
    CmdbDalCommandResult result = executeQuery(getData);
    return ((CmdbDatas)result.getResult());
  }

  public Map<CmdbDataID, Date> getLastUpdateTime(CmdbIDsCollection dataIDs) {
    HistoryDalGetLastUpdateTimeCommand getLastTime = new HistoryDalGetLastUpdateTimeCommand(dataIDs);
    CmdbDalCommandResult result = executeQuery(getLastTime);
    return ((Map)result.getResult());
  }

  public CmdbDataIDs checkIfDataWasChanged(CmdbIDsCollection<CmdbDataID> dataIDs, Date dateAfterChanged, HistoryFilter historyFilter) {
    HistoryDalIsDataChangedCommand isChanged = new HistoryDalIsDataChangedCommand(dataIDs, dateAfterChanged, historyFilter);
    CmdbDalCommandResult result = executeQuery(isChanged);
    return ((CmdbDataIDs)result.getResult());
  }

  public HistoryChangesTypedCounters getNumberOfChangesByType(HistoryFilter historyFilter) {
    HistoryDalGetNumberOfChangesByType getNumOfChanges = new HistoryDalGetNumberOfChangesByType(historyFilter);
    CmdbDalCommandResult result = executeQuery(getNumOfChanges);
    return ((HistoryChangesTypedCounters)result.getResult());
  }

  public HistoryChangesExtendedCounter getExtendedNumberOfChanges(CmdbIDsCollection<CmdbDataID> dataIDs, HistoryFilter historyFilter) {
    HistoryDalGetExtendedNumberOfChanges getExtendedNumberOfChanges = new HistoryDalGetExtendedNumberOfChanges(dataIDs, historyFilter);
    CmdbDalCommandResult result = executeQuery(getExtendedNumberOfChanges);
    return ((HistoryChangesExtendedCounter)result.getResult());
  }

  public CmdbDatas<CmdbDataID, CmdbData> getRemovedData(HistoryFilter historyFilter) {
    HistoryDalGetRemovedData getRemovedData = new HistoryDalGetRemovedData(historyFilter);
    CmdbDalCommandResult result = executeQuery(getRemovedData);
    return ((CmdbDatas)result.getResult());
  }

  public void executeBulk() {
    this.dao.execute(getContainer());
    this.container = null;
  }

  public void cleanAllHistoryTables() {
    HistoryDalCleanTablesCommand clean = new HistoryDalCleanTablesCommand();
    execute(clean);
  }

  public void purgeHistoryTables(Date lastDateToSave) {
    HistoryDalPurgeHistoryTablesCommand purging = new HistoryDalPurgeHistoryTablesCommand(lastDateToSave);
    execute(purging);
  }

  public void optimizeStorage() {
    execute(CmdbDalCommandFactory.createRunStatisticsComplexCommand());
  }

  public DbContext getDbContext() {
    return this.dao.getConnectionsPoolManager().getDbContext();
  }

  public CmdbIDsCollection getIDsByHistoryFilter(HistoryFilter historyFilter) {
    HistoryDalGetIDsByHistoryFilterCommand getIDs = new HistoryDalGetIDsByHistoryFilterCommand(historyFilter);
    CmdbDalCommandResult result = executeQuery(getIDs);
    return ((CmdbIDsCollection)result.getResult());
  }
}