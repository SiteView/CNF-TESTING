package com.mercury.topaz.cmdb.history.shared.filter.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeType;
import com.mercury.topaz.cmdb.history.server.dal.command.AbstractHistoryDalCommand;
import com.mercury.topaz.cmdb.history.shared.base.HistoryLogFactory;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import java.util.Arrays;
import java.util.Date;

class HistoryFilterImpl
  implements HistoryFilter
{
  private static Log _logger = HistoryLogFactory.getHistoryLog();
  private Date _fromDate = null;
  private Date _toDate = null;
  private Changer _changer = null;
  private ChangeType[] _changeTypes = null;
  private String[] _classTypes = null;
  private String[] _end2ClassTypes = null;

  HistoryFilterImpl(Date fromDate, Date toDate)
  {
    setFromDate(fromDate);
    setToDate(toDate);
  }

  HistoryFilterImpl(Date fromDate, Date toDate, Changer changer) {
    setFromDate(fromDate);
    setToDate(toDate);
    setChanger(changer);
  }

  HistoryFilterImpl(Date fromDate, Date toDate, ChangeType[] changeTypes) {
    setFromDate(fromDate);
    setToDate(toDate);
    setChangeTypes(changeTypes);
  }

  HistoryFilterImpl(Date fromDate, Date toDate, Changer changer, ChangeType[] changeTypes) {
    setFromDate(fromDate);
    setToDate(toDate);
    setChanger(changer);
    setChangeTypes(changeTypes);
  }

  HistoryFilterImpl(Date fromDate, Date toDate, Changer changer, ChangeType[] changeTypes, String[] classTypes) {
    setFromDate(fromDate);
    setToDate(toDate);
    setChanger(changer);
    setChangeTypes(changeTypes);
    setClassTypes(classTypes);
  }

  HistoryFilterImpl(Date fromDate, Date toDate, Changer changer, ChangeType[] changeTypes, String[] classTypes, String[] end2ClassTypes) {
    setFromDate(fromDate);
    setToDate(toDate);
    setChanger(changer);
    setChangeTypes(changeTypes);
    setClassTypes(classTypes);
    setEnd2ClassTypes(end2ClassTypes);
  }

  HistoryFilterImpl(Changer changer, ChangeType[] changeTypes) {
    setChanger(changer);
    setChangeTypes(changeTypes);
  }

  HistoryFilterImpl(ChangeType[] changeTypes) {
    setChangeTypes(changeTypes);
  }

  HistoryFilterImpl(Changer changer) {
    setChanger(changer);
  }

  HistoryFilterImpl(Date fromDate, Date toDate, String[] classTypes) {
    setFromDate(fromDate);
    setToDate(toDate);
    setClassTypes(classTypes);
  }

  HistoryFilterImpl(String[] classTypes) {
    setClassTypes(classTypes);
  }

  public Changer getChanger() {
    return this._changer;
  }

  private void setChanger(Changer changer)
  {
    if ((changer != null) && (changer.getDataStoreOrigin().length() > AbstractHistoryDalCommand.MAX_CHANGER_TYPE_SIZE.intValue()))
      this._changer = ChangerFactory.createChanger(changer.getDataStoreOrigin().substring(0, AbstractHistoryDalCommand.MAX_CHANGER_TYPE_SIZE.intValue()), changer.getChangerInfo());
    else
      this._changer = changer;
  }

  public Date getFromDate()
  {
    return this._fromDate;
  }

  private void setFromDate(Date fromDate) {
    this._fromDate = fromDate;
  }

  public Date getToDate() {
    return this._toDate;
  }

  public void setToDate(Date toDate) {
    this._toDate = toDate;
  }

  public ChangeType[] getChangeTypes() {
    return this._changeTypes;
  }

  private void setChangeTypes(ChangeType[] changeTypes) {
    if (changeTypes != null)
    {
      int size = changeTypes.length;
      for (int i = 0; i < changeTypes.length; ++i)
        if ((changeTypes[i].equals(ChangeType.ADD_LINK)) || (changeTypes[i].equals(ChangeType.REMOVE_LINK)) || (changeTypes[i].equals(ChangeType.UPDATE_LINK)))
          --size;


      ChangeType[] newChangeTypes = new ChangeType[size];
      int index = 0;
      for (int i = 0; i < changeTypes.length; ++i)
        if ((!(changeTypes[i].equals(ChangeType.ADD_LINK))) && (!(changeTypes[i].equals(ChangeType.REMOVE_LINK))) && (!(changeTypes[i].equals(ChangeType.UPDATE_LINK)))) {
          newChangeTypes[index] = changeTypes[i];
          ++index;
        }
        else if (_logger.isDebugEnabled()) {
          _logger.debug("Change Type " + changeTypes[i].getType() + " wasn't included in the filter");
        }


      this._changeTypes = newChangeTypes;
    }
  }

  public String[] getClassTypes() {
    return this._classTypes;
  }

  public boolean isRelationInFilter() {
    boolean isRelationInFilter = false;
    if ((getChangeTypes() != null) && (getChangeTypes().length > 0))
      for (int i = 0; i < getChangeTypes().length; ++i)
        if ((getChangeTypes()[i].equals(ChangeType.ADD_RELATION)) || (getChangeTypes()[i].equals(ChangeType.REMOVE_RELATION)))
        {
          isRelationInFilter = true;
          break;
        }


    else
      isRelationInFilter = true;

    return isRelationInFilter;
  }

  public boolean isChangeTypeInFilter(ChangeType changeType) {
    if ((getChangeTypes() != null) && (getChangeTypes().length > 0)) {
      for (int i = 0; i < getChangeTypes().length; ++i)
        if (getChangeTypes()[i].equals(changeType))
          return true;


    }
    else
      return true;

    return false;
  }

  private void setClassTypes(String[] classTypes) {
    this._classTypes = classTypes;
  }

  public String[] getEnd2ClassTypes() {
    return this._end2ClassTypes;
  }

  private void setEnd2ClassTypes(String[] end2ClassTypes) {
    this._end2ClassTypes = end2ClassTypes;
  }

  public String toString() {
    StringBuilder desc = new StringBuilder("HistoryFilter includes: ");
    desc.append("Changer-").append(getChanger()).append(" FromDate-").append(getFromDate()).append(" ToDate-").append(getToDate()).append(" ChangeTypes-").append(getChangeTypes());

    return desc.toString();
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    HistoryFilterImpl that = (HistoryFilterImpl)o;

    if (!(Arrays.equals(this._changeTypes, that._changeTypes)))
      return false;

    if (this._changer != null) if (this._changer.equals(that._changer)) break label78; 
    else if (that._changer == null) break label78;
    return false;

    if (!(Arrays.equals(this._classTypes, that._classTypes)))
      label78: return false;

    if (!(Arrays.equals(this._end2ClassTypes, that._end2ClassTypes)))
      return false;

    if (this._fromDate != null) if (this._fromDate.equals(that._fromDate)) break label143; 
    else if (that._fromDate == null) break label143;
    return false;

    if (this._toDate != null) label143: if (this._toDate.equals(that._toDate)) break label176;
    label176: return (that._toDate == null);
  }

  public int hashCode()
  {
    int result = (this._fromDate != null) ? this._fromDate.hashCode() : 0;
    result = 29 * result + ((this._toDate != null) ? this._toDate.hashCode() : 0);
    result = 29 * result + ((this._changer != null) ? this._changer.hashCode() : 0);
    return result;
  }
}