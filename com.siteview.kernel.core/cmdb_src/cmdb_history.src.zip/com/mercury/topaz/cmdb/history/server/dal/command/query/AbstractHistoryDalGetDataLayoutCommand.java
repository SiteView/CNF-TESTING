package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayoutVisitor;
import com.mercury.topaz.cmdb.history.shared.layout.SimpleDataLayout;
import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreator;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreatorFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.impl.CmdbDatasFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class AbstractHistoryDalGetDataLayoutCommand extends AbstractHistoryDalQueryCommand<CmdbDatas<CmdbDataID, CmdbData<?>>>
{
  private DataLayout _dataLayout;
  private PropertyCreator _propCreator;
  private CmdbIDsCollection<CmdbDataID> _cmdbDataIDs;

  public AbstractHistoryDalGetDataLayoutCommand(CmdbIDsCollection<CmdbDataID> dataIDs, DataLayout dataLayout)
  {
    setDataLayout(dataLayout);
    setCmdbDataIDs(dataIDs);
    setPropCreator(PropertyCreatorFactory.create());
  }

  protected CmdbDatas<CmdbDataID, CmdbData<?>> perform() {
    QueryTablesByLayoutVisitor queryVisitor = new QueryTablesByLayoutVisitor(this, null);
    getDataLayout().accept(queryVisitor);
    return queryVisitor.getDatas();
  }

  protected void validateInput() {
  }

  protected Map<DataChangesKey, DataChanges> queryTables(SimpleDataLayout simpleDataLayout) throws SQLException {
    if (useTempTable(getCmdbDataIDs().size()))
      return runSelectInTempTable(simpleDataLayout);

    return runSelectInChunks(simpleDataLayout);
  }

  protected Map<DataChangesKey, DataChanges> runSelectInChunks(SimpleDataLayout simpleDataLayout) throws SQLException {
    Map dataIDChanges = new HashMap();
    CmdbIDsCollection idsLeft = getCmdbDataIDs();

    List attrFilter = getAttrListForFilter(simpleDataLayout);

    int maxIDsInChunk = getMaxPossibleSizeForInChunk();
    int numOfChunks = calcNumOfInChunks(idsLeft.size());
    for (int chunkNum = 0; chunkNum < numOfChunks; ++chunkNum) {
      int numOfIDs = (idsLeft.size() > maxIDsInChunk) ? maxIDsInChunk : idsLeft.size();
      runSelectForIDs(dataIDChanges, createInSqlString(numOfIDs, "e", HISTORY_CHANGES_CI_ID_COLUMN_NAME), idsLeft, numOfIDs, attrFilter);
      if (idsLeft.size() - numOfIDs > 0)
        idsLeft = removeIDsFromCollection(idsLeft, numOfIDs);
    }

    return dataIDChanges;
  }

  protected Map<DataChangesKey, DataChanges> runSelectInTempTable(SimpleDataLayout simpleDataLayout) throws SQLException {
    createCmdbIDTempTable(getConnection(), elementsToIDsAsBytes(getCmdbDataIDs()));
    Map dataIDChanges = new HashMap();

    List attrFilter = getAttrListForFilter(simpleDataLayout);
    runSelectForIDs(dataIDChanges, createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", "e", HISTORY_CHANGES_CI_ID_COLUMN_NAME), null, getCmdbDataIDs().size(), attrFilter);
    return dataIDChanges;
  }

  protected StringBuilder getSelectSql()
  {
    return new StringBuilder("select e.").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_END1_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_END2_COLUMN_NAME).append(",i.").append(HISTORY_INFO_ATTR_ID_COLUMN_NAME).append(",i.").append(HISTORY_INFO_ATTR_VALUE_COLUMN_NAME).append(getDateForSelect());
  }

  protected abstract String getDateForSelect();

  protected StringBuilder getFromSql(String tableName)
  {
    return new StringBuilder(" from ").append(HISTORY_CHANGES_TABLE_NAME).append(" e,").append(tableName).append(" i");
  }

  protected StringBuilder getWhereSql(List attrFilter, StringBuilder idsInCondition, int numOfIDs)
  {
    StringBuilder whereQuery = new StringBuilder(" where e.").append(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME).append("=i.").append(HISTORY_INFO_CHANGE_ID_COLUMN_NAME).append(" and e.").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?");

    if (numOfIDs > 0) {
      whereQuery.append(" and ").append(idsInCondition);
    }

    if (attrFilter.size() > 0) {
      whereQuery.append(" and ").append(HISTORY_INFO_ATTR_ID_COLUMN_NAME).append(createInSqlString(attrFilter.size()));
    }

    whereQuery.append(" and e.").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<=").append(getDateStringForWhereQuery()).append(" and i.").append(HISTORY_INFO_END_TIME_COLUMN_NAME).append(">").append(getDateStringForWhereQuery());

    return whereQuery;
  }

  protected abstract String getDateStringForWhereQuery();

  protected abstract CmdbDalPreparedStatement addLayoutDateToPreparedStatement(CmdbDalPreparedStatement paramCmdbDalPreparedStatement) throws SQLException;

  protected abstract CmdbDalPreparedStatement addAdditionalDataToPreparedStatement(CmdbDalPreparedStatement paramCmdbDalPreparedStatement) throws SQLException;

  protected void runSelectForIDs(Map<DataChangesKey, DataChanges> dataIDChanges, StringBuilder idsInCondition, CmdbIDsCollection<CmdbDataID> idsLeft, int numOfIDs, List attrFilter) throws SQLException {
    for (Iterator i$ = CMDB_TYPE_TO_HISTORY_INFO.keySet().iterator(); i$.hasNext(); ) { CmdbType cmdbType = (CmdbType)i$.next();
      String tableName = (String)CMDB_TYPE_TO_HISTORY_INFO.get(cmdbType);

      StringBuilder selectQuery = getSelectSql();
      StringBuilder fromQuery = getFromSql(tableName);
      StringBuilder whereQuery = getWhereSql(attrFilter, idsInCondition, numOfIDs);
      StringBuilder sqlQuery = new StringBuilder().append(selectQuery).append(fromQuery).append(whereQuery);

      CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlQuery.toString());

      preparedStatement.setInt(getCustomerID().getID());

      if ((numOfIDs > 0) && (idsLeft != null) && (idsLeft.size() > 0)) {
        List variables = new ArrayList(numOfIDs);
        addCmdbIdsToInList(idsLeft, variables, numOfIDs);
        for (Iterator i$ = variables.iterator(); i$.hasNext(); ) { Object variable = i$.next();
          preparedStatement.setBytes((byte[])(byte[])variable);
        }

      }

      for (Iterator i$ = attrFilter.iterator(); i$.hasNext(); ) { Object anAttrFilter = i$.next();
        preparedStatement.setString((String)anAttrFilter);
      }

      preparedStatement = addLayoutDateToPreparedStatement(preparedStatement);
      preparedStatement = addAdditionalDataToPreparedStatement(preparedStatement);

      CmdbDalResultSet resultSet = preparedStatement.executeQuery();

      analyzeResults(dataIDChanges, resultSet, cmdbType);
      preparedStatement.close();
    }
  }

  protected void analyzeResults(Map<DataChangesKey, DataChanges> dataIDChanges, CmdbDalResultSet resultSet, CmdbType cmdbType) throws SQLException {
    while (resultSet.next()) {
      CmdbDataID id;
      DataChanges dataChanges;
      Boolean isObject = resultSet.getBoolean(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME);
      byte[] idAsBytes = resultSet.getBytes(HISTORY_CHANGES_CI_ID_COLUMN_NAME);
      String attrName = resultSet.getString(HISTORY_INFO_ATTR_ID_COLUMN_NAME);
      Object attrValue = DalTypeUtil.getObject(resultSet, HISTORY_INFO_ATTR_VALUE_COLUMN_NAME, cmdbType, MAX_BYTES_SIZE);
      Date timeOfLayout = getDateValue(resultSet);

      if (isObject.booleanValue())
        id = CmdbObjectID.Factory.restoreObjectID(idAsBytes);
      else
        id = CmdbLinkID.Factory.restoreLinkID(idAsBytes);

      DataChangesKey key = new DataChangesKey(this, id, timeOfLayout);

      if (dataIDChanges.containsKey(key)) {
        dataChanges = (DataChanges)dataIDChanges.get(key);
      } else {
        String type = resultSet.getString(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME);
        byte[] end1IdAsBytes = resultSet.getBytes(HISTORY_CHANGES_END1_COLUMN_NAME);
        byte[] end2IdAsBytes = resultSet.getBytes(HISTORY_CHANGES_END2_COLUMN_NAME);
        dataChanges = new DataChanges(this, end1IdAsBytes, end2IdAsBytes, idAsBytes, isObject, type);
        dataIDChanges.put(key, dataChanges);
      }

      CmdbProperty prop = getPropCreator().createProperty(cmdbType, attrName, attrValue);
      dataChanges.addProperty(prop);
    }
    resultSet.close();
  }

  protected abstract Date getDateValue(CmdbDalResultSet paramCmdbDalResultSet) throws SQLException;

  protected DataLayout getDataLayout() {
    return this._dataLayout;
  }

  private void setDataLayout(DataLayout dataLayout) {
    this._dataLayout = dataLayout;
  }

  protected PropertyCreator getPropCreator() {
    return this._propCreator;
  }

  private void setPropCreator(PropertyCreator propCreator) {
    if (propCreator == null)
      throw new IllegalArgumentException("property creator is null");

    this._propCreator = propCreator;
  }

  protected CmdbIDsCollection<CmdbDataID> getCmdbDataIDs() {
    return this._cmdbDataIDs;
  }

  private void setCmdbDataIDs(CmdbIDsCollection<CmdbDataID> cmdbDataIDs) {
    this._cmdbDataIDs = cmdbDataIDs;
  }

  private class QueryTablesByLayoutVisitor
  implements DataLayoutVisitor
  {
    private CmdbDatas<CmdbDataID, CmdbData<?>> _datas;

    private QueryTablesByLayoutVisitor()
    {
      this._datas = null; }

    public void visitSimpleLayout() {
      Map dataIDChanges = new HashMap();
      try {
        dataIDChanges = this.this$0.queryTables(simpleDataLayout);
      }
      catch (SQLException e) {
        AbstractHistoryDalGetDataLayoutCommand.access$100().error("Error while trying to get data layout: " + e);
      }
      CmdbDatas datas = CmdbDatasFactory.create();

      for (Iterator i$ = dataIDChanges.values().iterator(); i$.hasNext(); ) { Object o = i$.next();
        AbstractHistoryDalGetDataLayoutCommand.DataChanges dataChanges = (AbstractHistoryDalGetDataLayoutCommand.DataChanges)o;
        datas.add(dataChanges.createDataFromChanges());
      }
      setDatas(datas);
    }

    public CmdbDatas<CmdbDataID, CmdbData<?>> getDatas() {
      return this._datas;
    }

    private void setDatas() {
      this._datas = datas;
    }
  }

  protected class DataChanges
  {
    byte[] _idAsBytes;
    boolean _isObject;
    String _type;
    byte[] _end1IdAsBytes;
    byte[] _end2IdAsBytes;
    CmdbProperties _properties;

    public DataChanges(, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, Boolean paramBoolean, String paramString)
    {
      setEnd1IdAsBytes(paramArrayOfByte1);
      setEnd2IdAsBytes(paramArrayOfByte2);
      setIdAsBytes(idAsBytes);
      setIsObject(paramBoolean.booleanValue());
      setType(paramString);
    }

    public CmdbData<?> createDataFromChanges()
    {
      CmdbData data;
      if (isObject()) {
        CmdbObjectID id = CmdbObjectID.Factory.restoreObjectID(getIdAsBytes());

        data = CmdbObjectFactory.createObject(id, getType(), getProperties());
      } else {
        CmdbLinkID id = CmdbLinkID.Factory.restoreLinkID(getIdAsBytes());
        CmdbObjectID end1 = CmdbObjectID.Factory.restoreObjectID(getEnd1IdAsBytes());
        CmdbObjectID end2 = CmdbObjectID.Factory.restoreObjectID(getEnd2IdAsBytes());

        data = CmdbLinkFactory.createLink(id, end1, end2, getType(), getProperties());
      }
      return data;
    }

    public void addProperty() {
      if (getProperties() == null)
        setProperties(CmdbPropertyFactory.createProperties());

      getProperties().add(prop);
    }

    public CmdbProperties getProperties() {
      return this._properties;
    }

    private void setProperties() {
      this._properties = properties;
    }

    private byte[] getEnd1IdAsBytes() {
      return this._end1IdAsBytes;
    }

    private void setEnd1IdAsBytes() {
      this._end1IdAsBytes = end1IdAsBytes;
    }

    private byte[] getEnd2IdAsBytes() {
      return this._end2IdAsBytes;
    }

    private void setEnd2IdAsBytes() {
      this._end2IdAsBytes = end2IdAsBytes;
    }

    private byte[] getIdAsBytes() {
      return this._idAsBytes;
    }

    private void setIdAsBytes() {
      this._idAsBytes = idAsBytes;
    }

    private boolean isObject() {
      return this._isObject;
    }

    private void setIsObject() {
      this._isObject = object;
    }

    private String getType() {
      return this._type;
    }

    private void setType() {
      this._type = type;
    }
  }

  protected class DataChangesKey
  {
    private CmdbDataID _dataID;
    private Date _timeOfLayout;

    public DataChangesKey(, CmdbDataID paramCmdbDataID, Date paramDate)
    {
      this._dataID = paramCmdbDataID;
      this._timeOfLayout = paramDate;
    }

    public boolean equals() {
      if (this == o)
        return true;

      if (!(o instanceof DataChangesKey)) {
        return false;
      }

      DataChangesKey dataChangesKey = (DataChangesKey)o;

      if (this._dataID != null) if (this._dataID.equals(dataChangesKey._dataID)) break label54; 
      else if (dataChangesKey._dataID == null) break label54;
      return false;

      if (this._timeOfLayout != null) label54: if (this._timeOfLayout.equals(dataChangesKey._timeOfLayout)) break label85; 
      label85: return (dataChangesKey._timeOfLayout == null);
    }

    public int hashCode()
    {
      int result = (this._dataID != null) ? this._dataID.hashCode() : 0;
      result = 29 * result + ((this._timeOfLayout != null) ? this._timeOfLayout.hashCode() : 0);
      return result;
    }
  }
}