package com.mercury.topaz.cmdb.history.server.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.client.change.id.ChangeIdCmdbCollection;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesExtendedCounter;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounters;
import com.mercury.topaz.cmdb.history.server.dal.dao.CmdbDalHistoryDAO;
import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.server.base.itc.lock.MultiReadMultiWrite;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import java.util.Date;
import java.util.Map;

class HistoryQueryManagerImpl extends AbstractHistoryManager
  implements HistoryQueryManager, MultiReadMultiWrite
{
  public HistoryQueryManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public CmdbDataIDs checkIfDataWasChanged(CmdbIDsCollection<CmdbDataID> dataIDs, Date dateAfterChanged, HistoryFilter historyFilter) {
    return getHistoryDAO().checkIfDataWasChanged(dataIDs, dateAfterChanged, historyFilter);
  }

  public HistoryDatas getDataChanges(CmdbIDsCollection<CmdbDataID> cmdbDataIDs, HistoryFilter historyFilter, DataLayout dataLayout) {
    return getHistoryDAO().getDataChanges(cmdbDataIDs, historyFilter, dataLayout);
  }

  public HistoryDatas getDataChangesByChangeIds(ChangeIdCmdbCollection changeIds, DataLayout dataLayout, HistoryFilter historyFilter) {
    return getHistoryDAO().getDataChangesByChangeIds(changeIds, dataLayout, historyFilter);
  }

  public HistoryDatas getDataLastChange(CmdbIDsCollection cmdbDataIDs, HistoryFilter historyFilter) {
    return getHistoryDAO().getDataLastChange(cmdbDataIDs, historyFilter);
  }

  public Map getLastUpdateTime(CmdbIDsCollection dataIDs) {
    return getHistoryDAO().getLastUpdateTime(dataIDs);
  }

  public CmdbDatas getLayout(CmdbIDsCollection dataIDs, Date layoutDate, DataLayout dataLayout) {
    return getHistoryDAO().getLayout(dataIDs, layoutDate, dataLayout);
  }

  public HistoryChangesTypedCounters getNumberOfChangesByType(HistoryFilter historyFilter) {
    return getHistoryDAO().getNumberOfChangesByType(historyFilter);
  }

  public HistoryChangesExtendedCounter getExtendedNumberOfChanges(CmdbIDsCollection<CmdbDataID> dataIDs, HistoryFilter historyFilter) {
    return getHistoryDAO().getExtendedNumberOfChanges(dataIDs, historyFilter);
  }

  public CmdbDatas getRemovedData(HistoryFilter historyFilter) {
    return getHistoryDAO().getRemovedData(historyFilter);
  }

  public CmdbIDsCollection getIDsByHistoryFilter(HistoryFilter historyFilter) {
    return getHistoryDAO().getIDsByHistoryFilter(historyFilter);
  }

  public void shutdown() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: HistoryQueryManager is shutdown properly !!!");
  }

  public void startUp() {
    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: HistoryQueryManager is started up properly !!!");
  }

  public String getName() {
    return "History Query Task";
  }
}