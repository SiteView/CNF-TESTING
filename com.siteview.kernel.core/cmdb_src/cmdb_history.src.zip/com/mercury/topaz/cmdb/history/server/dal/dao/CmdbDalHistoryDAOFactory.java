package com.mercury.topaz.cmdb.history.server.dal.dao;

import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;

public class CmdbDalHistoryDAOFactory
{
  public static CmdbDalHistoryDAO create(LocalEnvironment localEnvironment)
  {
    return new CmdbDalJdbcHistoryDAO(localEnvironment);
  }
}