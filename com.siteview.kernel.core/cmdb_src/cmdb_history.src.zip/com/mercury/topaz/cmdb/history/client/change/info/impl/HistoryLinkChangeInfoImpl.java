package com.mercury.topaz.cmdb.history.client.change.info.impl;

import com.mercury.topaz.cmdb.history.client.change.info.HistoryLinkChangeInfo;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Date;

class HistoryLinkChangeInfoImpl extends AbstractHistoryChangeInfo
  implements HistoryLinkChangeInfo
{
  private CmdbLink _cmdbLink;

  protected HistoryLinkChangeInfoImpl(Long changeId, CmdbLink cmdbLink)
  {
    setChangeId(changeId);
    setCmdbLink(cmdbLink);
  }

  protected HistoryLinkChangeInfoImpl(CmdbLink cmdbLink, Date changeTime, Changer changer, CmdbProperties layoutProperties, CmdbProperties previousValues) {
    super(changeTime, changer, layoutProperties, previousValues);
    setCmdbLink(cmdbLink);
  }

  public CmdbData getData() {
    return getCmdbLink();
  }

  public CmdbLink getCmdbLink() {
    return this._cmdbLink;
  }

  private void setCmdbLink(CmdbLink cmdbLink) {
    this._cmdbLink = cmdbLink;
  }

  public ReadOnlyIterator getPropertiesIterator() {
    return getCmdbLink().getPropertiesIterator();
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (getClass() != o.getClass()))
      return false;

    if (!(super.equals(o))) {
      return false;
    }

    HistoryLinkChangeInfoImpl that = (HistoryLinkChangeInfoImpl)o;

    if (this._cmdbLink != null) if (this._cmdbLink.equals(that._cmdbLink)) break label72;
    label72: return (that._cmdbLink == null);
  }

  public int hashCode()
  {
    int result = super.hashCode();
    result = 29 * result + ((this._cmdbLink != null) ? this._cmdbLink.hashCode() : 0);
    return result;
  }
}