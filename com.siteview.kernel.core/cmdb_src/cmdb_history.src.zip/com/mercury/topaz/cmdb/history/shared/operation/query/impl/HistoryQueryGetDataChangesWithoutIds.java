package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class HistoryQueryGetDataChangesWithoutIds extends AbstractHistoryQueryOperation
{
  protected static final String HISTORY_DATAS = "HISTORY_DATAS";
  private HistoryDatas _historyDatas;
  private HistoryFilter _historyFilter;
  private DataLayout _dataLayout;

  public HistoryQueryGetDataChangesWithoutIds(HistoryFilter historyFilter, DataLayout layout)
  {
    setHistoryFilter(historyFilter);
    setDataLayout(layout);
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException {
    HistoryDatas historyChanges = historyQueryManager.getDataChanges(null, getHistoryFilter(), getDataLayout());
    response.addResult("HISTORY_DATAS", historyChanges);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setHistoryDatas((HistoryDatas)response.getResult("HISTORY_DATAS"));
  }

  public HistoryDatas getHistoryDatas()
  {
    return this._historyDatas;
  }

  private void setHistoryDatas(HistoryDatas historyChanges) {
    this._historyDatas = historyChanges;
  }

  public String getOperationName() {
    return "history query: get data changes";
  }

  public HistoryFilter getHistoryFilter()
  {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    if (historyFilter == null)
      throw new IllegalArgumentException("history filter is null");

    this._historyFilter = historyFilter;
  }

  private DataLayout getDataLayout() {
    return this._dataLayout;
  }

  private void setDataLayout(DataLayout dataLayout) {
    if (dataLayout == null)
      throw new IllegalArgumentException("data layout is null");

    this._dataLayout = dataLayout;
  }
}