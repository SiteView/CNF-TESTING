package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeType;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import java.sql.SQLException;

public class HistoryDalGetIDsByHistoryFilterCommand extends AbstractHistoryDalQueryCommand<CmdbIDsCollection>
{
  private HistoryFilter _historyFilter;

  public HistoryDalGetIDsByHistoryFilterCommand(HistoryFilter historyFilter)
  {
    setHistoryFilter(historyFilter);
  }

  protected CmdbIDsCollection perform()
    throws Exception
  {
    String query = getQuery();

    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(query);

    preparedStatement = fillPreparedStatement(preparedStatement);
    CmdbDalResultSet resultSet = preparedStatement.executeQuery();

    CmdbIDsCollection result = analyzeResultSet(resultSet);

    resultSet.close();
    preparedStatement.close();
    return result;
  }

  private String getQuery() {
    StringBuilder query = new StringBuilder("select distinct ").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME).append(",").append(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME);

    query.append(" from ").append(HISTORY_CHANGES_TABLE_NAME).append(" where ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?").append(getCustomWhere());

    return query.toString();
  }

  private StringBuilder getCustomWhere() {
    StringBuilder whereQuery = new StringBuilder();
    if ((getHistoryFilter().getClassTypes() != null) && (getHistoryFilter().getClassTypes().length > 0))
      whereQuery.append(" and ").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(createInSqlString(getHistoryFilter().getClassTypes().length));

    if ((getHistoryFilter().getChangeTypes() != null) && (getHistoryFilter().getChangeTypes().length > 0))
      whereQuery.append(" and ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append(createInSqlString(getHistoryFilter().getChangeTypes().length));

    if (getHistoryFilter().getFromDate() != null)
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(">?");

    if (getHistoryFilter().getToDate() != null)
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<=?");

    if (getHistoryFilter().getChanger() != null) {
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGER_INFO_COLUMN_NAME).append("=?");
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGER_TYPE_COLUMN_NAME).append("=?");
    }
    return whereQuery;
  }

  private CmdbDalPreparedStatement fillPreparedStatement(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    preparedStatement.setInt(getCustomerID().getID());
    return fillCustomPreparedStatement(preparedStatement);
  }

  private CmdbDalPreparedStatement fillCustomPreparedStatement(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    int i;
    if ((getHistoryFilter().getClassTypes() != null) && (getHistoryFilter().getClassTypes().length > 0))
      for (i = 0; i < getHistoryFilter().getClassTypes().length; ++i)
        preparedStatement.setString(getHistoryFilter().getClassTypes()[i]);


    if ((getHistoryFilter().getChangeTypes() != null) && (getHistoryFilter().getChangeTypes().length > 0))
      for (i = 0; i < getHistoryFilter().getChangeTypes().length; ++i)
        preparedStatement.setString(getHistoryFilter().getChangeTypes()[i].getType());


    if (getHistoryFilter().getFromDate() != null)
      preparedStatement.setDate(getHistoryFilter().getFromDate());

    if (getHistoryFilter().getToDate() != null)
      preparedStatement.setDate(getHistoryFilter().getToDate());

    if (getHistoryFilter().getChanger() != null) {
      preparedStatement.setString(getHistoryFilter().getChanger().getChangerInfo());
      preparedStatement.setString(getHistoryFilter().getChanger().getDataStoreOrigin());
    }
    return preparedStatement;
  }

  private CmdbIDsCollection analyzeResultSet(CmdbDalResultSet resultSet) throws SQLException {
    CmdbDataIDs ids = CmdbDataIdsFactory.create();
    while (resultSet.next()) {
      CmdbDataID dataID;
      byte[] id = resultSet.getBytes(HISTORY_CHANGES_CI_ID_COLUMN_NAME);
      boolean isObject = resultSet.getBoolean(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME).booleanValue();

      if (isObject) {
        dataID = CmdbObjectID.Factory.restoreObjectID(id);
      }
      else
        dataID = CmdbLinkID.Factory.restoreLinkID(id);

      ids.add(dataID);
    }
    return ids;
  }

  protected void validateInput()
  {
  }

  private HistoryFilter getHistoryFilter()
  {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    this._historyFilter = historyFilter;
  }
}