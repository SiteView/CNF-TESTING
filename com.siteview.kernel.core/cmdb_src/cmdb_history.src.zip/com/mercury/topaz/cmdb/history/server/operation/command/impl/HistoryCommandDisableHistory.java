package com.mercury.topaz.cmdb.history.server.operation.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;

public class HistoryCommandDisableHistory extends AbstractHistoryCommandEnableDisableHistory
{
  public String getOperationName()
  {
    return "history command: disable history DB";
  }

  protected void enableDisableHistory(HistoryUpdateManager historyUpdateManager) {
    historyUpdateManager.disableHistoryDB();
  }

  protected void writeLogMessage() {
    if (_logger.isInfoEnabled())
      _logger.info("History was disabled");
  }
}