package com.mercury.topaz.cmdb.history.server.manager.impl;

import com.mercury.topaz.cmdb.history.server.dal.dao.CmdbDalHistoryDAO;
import com.mercury.topaz.cmdb.history.server.dal.dao.CmdbDalHistoryDAOFactory;
import com.mercury.topaz.cmdb.history.server.manager.HistoryManager;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManagerImpl;

abstract class AbstractHistoryManager extends CmdbSubsystemManagerImpl
  implements HistoryManager
{
  private CmdbDalHistoryDAO _historyDAO;

  protected AbstractHistoryManager(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
    setHistoryDAO(CmdbDalHistoryDAOFactory.create(localEnvironment));
  }

  public CmdbDalHistoryDAO getHistoryDAO() {
    return this._historyDAO;
  }

  private void setHistoryDAO(CmdbDalHistoryDAO historyDAO) {
    this._historyDAO = historyDAO;
  }
}