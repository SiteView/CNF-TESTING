package com.mercury.topaz.cmdb.history.server.manager;

import com.mercury.topaz.cmdb.history.server.dal.dao.CmdbDalHistoryDAO;
import com.mercury.topaz.cmdb.server.manage.subsystem.CmdbSubsystemManager;

public abstract interface HistoryManager extends CmdbSubsystemManager
{
  public abstract CmdbDalHistoryDAO getHistoryDAO();
}