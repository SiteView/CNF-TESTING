package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;

public class HistoryQueryGetRemovedData extends AbstractHistoryQueryOperation
{
  public static final String DATAS_RESULT_KEY = "datasResultKey";
  private HistoryFilter _historyFilter;
  private CmdbDatas _datas;

  public HistoryQueryGetRemovedData(HistoryFilter historyFilter)
  {
    setHistoryFilter(historyFilter);
  }

  public String getOperationName() {
    return "History Query: Get Removed Data";
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException {
    CmdbDatas datas = historyQueryManager.getRemovedData(getHistoryFilter());
    response.addResult("datasResultKey", datas);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setDatas((CmdbDatas)response.getResult("datasResultKey"));
  }

  private HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    if (historyFilter == null)
      throw new IllegalArgumentException("history filter is null");

    this._historyFilter = historyFilter;
  }

  public CmdbDatas getDatas() {
    return this._datas;
  }

  private void setDatas(CmdbDatas datas) {
    if (datas == null)
      throw new IllegalArgumentException("datas is null");

    this._datas = datas;
  }
}