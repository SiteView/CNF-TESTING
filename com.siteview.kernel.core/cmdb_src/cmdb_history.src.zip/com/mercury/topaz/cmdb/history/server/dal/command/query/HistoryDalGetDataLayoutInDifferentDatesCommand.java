package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.server.dal.command.update.HistoryDalCreateOrTruncateTempTableComplexCommand;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.history.shared.layout.SimpleDataLayout;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.collections.MultiMap;

public class HistoryDalGetDataLayoutInDifferentDatesCommand extends AbstractHistoryDalGetDataLayoutCommand
{
  private MultiMap _idsToDatesMap;

  public HistoryDalGetDataLayoutInDifferentDatesCommand(MultiMap idsToDatesMap, CmdbDataIDs dataIDs, DataLayout dataLayout)
  {
    super(dataIDs, dataLayout);
    setIdsToDatesMap(idsToDatesMap);
  }

  protected int getIDsSize() {
    return getIdsToDatesMap().size();
  }

  protected String getDateStringForWhereQuery() {
    return "tmp." + IDS_TO_DATES_DATE_COLUMN_NAME;
  }

  protected Map<AbstractHistoryDalGetDataLayoutCommand.DataChangesKey, AbstractHistoryDalGetDataLayoutCommand.DataChanges> queryTables(SimpleDataLayout simpleDataLayout) throws SQLException {
    createIDsToDatesTempTable();
    Map dataIDChanges = new HashMap();

    List attrFilter = getAttrListForFilter(simpleDataLayout);
    runSelectForIDs(dataIDChanges, new StringBuilder(), getCmdbDataIDs(), 0, attrFilter);
    return dataIDChanges;
  }

  private void createIDsToDatesTempTable() throws SQLException {
    truncateIDsToDatesTempTable();
    fillIDsToDatesTempTable();
  }

  private void truncateIDsToDatesTempTable() {
    List columnsData = new ArrayList();
    if (getConnectionPool().isUsingOracleDB()) {
      columnsData.add("CMDB_ID RAW(16)");
      columnsData.add(IDS_TO_DATES_DATE_COLUMN_NAME + " NUMBER(" + 22 + ")");
      columnsData.add("T_VALUES_INDEX NUMBER");
    }
    else {
      columnsData.add("CMDB_ID Varbinary(16)");
      columnsData.add(IDS_TO_DATES_DATE_COLUMN_NAME + " numeric(" + 22 + ")");
      columnsData.add("T_VALUES_INDEX numeric");
    }

    HistoryDalCreateOrTruncateTempTableComplexCommand tempTable = new HistoryDalCreateOrTruncateTempTableComplexCommand(IDS_TO_DATES_TEMP_TABLE_NAME, columnsData, "CMDB_ID");
    tempTable.execute();
  }

  private void fillIDsToDatesTempTable() throws SQLException {
    fillCmdbIDsToDatesTempTable(getConnection());
  }

  private void fillCmdbIDsToDatesTempTable(CmdbDalConnection connection) throws SQLException {
    if (!(getCmdbDataIDs().isEmpty()))
    {
      String sqlString;
      if (getConnectionPool().isUsingOracleDB()) {
        sqlString = "insert into " + IDS_TO_DATES_TEMP_TABLE_NAME + " values(?,?,?)";
      }
      else if (getConnectionPool().isUsingMSSqlDB()) {
        sqlString = "insert into #" + IDS_TO_DATES_TEMP_TABLE_NAME + " values(?,?,?)";
      }
      else {
        throw new CmdbDalException("Unknown db type !!!");
      }

      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);

      for (Iterator i$ = getIdsToDatesMap().keySet().iterator(); i$.hasNext(); ) { Object o = i$.next();
        CmdbDataID curID = (CmdbDataID)o;
        byte[] idAsBytes = getBytesFromDataID(curID);

        Collection dates = (Collection)getIdsToDatesMap().get(curID);
        if (dates != null)
          for (Iterator i$ = dates.iterator(); i$.hasNext(); ) { Object date = i$.next();
            Date curDate = (Date)date;
            preparedStatement.setBytes(idAsBytes);
            preparedStatement.setDate(curDate);
            preparedStatement.setInt(0);
            preparedStatement.addBatch();
          }

      }

      preparedStatement.executeBatch();
      preparedStatement.close();
    }
  }

  protected String getDateForSelect() {
    return ",tmp." + IDS_TO_DATES_DATE_COLUMN_NAME;
  }

  protected Date getDateValue(CmdbDalResultSet resultSet) throws SQLException {
    return resultSet.getDate(IDS_TO_DATES_DATE_COLUMN_NAME);
  }

  protected StringBuilder getFromSql(String tableName) {
    StringBuilder fromSql = super.getFromSql(tableName);
    String tempTableName = IDS_TO_DATES_TEMP_TABLE_NAME;
    if (getConnectionPool().isUsingMSSqlDB())
      tempTableName = "#" + tempTableName;

    fromSql.append(", ").append(tempTableName).append(" tmp");
    return fromSql;
  }

  protected StringBuilder getWhereSql(List attrFilter, StringBuilder idsInCondition, int numOfIDs) {
    StringBuilder whereSql = super.getWhereSql(attrFilter, idsInCondition, numOfIDs);
    whereSql.append(" and tmp.").append("CMDB_ID").append("=e.").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME);
    return whereSql;
  }

  protected CmdbDalPreparedStatement addLayoutDateToPreparedStatement(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    return preparedStatement;
  }

  protected CmdbDalPreparedStatement addAdditionalDataToPreparedStatement(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    return preparedStatement;
  }

  private MultiMap getIdsToDatesMap() {
    return this._idsToDatesMap;
  }

  private void setIdsToDatesMap(MultiMap idsToDatesMap) {
    if (idsToDatesMap == null)
      throw new IllegalArgumentException("ids to dates map is null");

    this._idsToDatesMap = idsToDatesMap;
  }
}