package com.mercury.topaz.cmdb.history.server.dal.command.update;

import com.mercury.topaz.cmdb.history.server.dal.command.AbstractHistoryDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public class AbstractHistoryDalDeleteHistoryTablesCommand extends AbstractHistoryDalCommand<Void>
{
  protected Void perform()
    throws Exception
  {
    int customerID = getCustomerID().getID();

    for (Iterator i$ = CMDB_TYPE_TO_HISTORY_INFO.values().iterator(); i$.hasNext(); ) { String tableName = (String)i$.next();
      deleteTable = getConnection().prepareStatement4Update(getSqlForDeleteInfoTable(tableName));
      deleteTable.setInt(customerID);
      deleteTable = setCustomPreparedStatementForInfoTables(deleteTable);
      deleteTable.executeUpdate();
    }

    CmdbDalPreparedStatement deleteTable = getConnection().prepareStatement4Update(getSqlForDeleteEventsTable());
    deleteTable.setInt(customerID);
    deleteTable = setCustomPreparedStatementForEventsTable(deleteTable);
    deleteTable.executeUpdate();

    return null;
  }

  protected void validateInput() {
  }

  protected String getSqlForDeleteEventsTable() {
    StringBuilder sql = new StringBuilder("delete ").append(HISTORY_CHANGES_TABLE_NAME).append(" where ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?");

    return sql.toString();
  }

  protected String getSqlForDeleteInfoTable(String tableName) {
    StringBuilder sql = new StringBuilder("delete ").append(tableName);
    sql.append(" where exists (select 1 from ").append(HISTORY_CHANGES_TABLE_NAME).append(" e").append(" where e.").append(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME).append("=").append(tableName).append(".").append(HISTORY_INFO_CHANGE_ID_COLUMN_NAME).append(" and e.").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?)");

    return sql.toString();
  }

  protected CmdbDalPreparedStatement setCustomPreparedStatementForEventsTable(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    return preparedStatement;
  }

  protected CmdbDalPreparedStatement setCustomPreparedStatementForInfoTables(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    return preparedStatement;
  }
}