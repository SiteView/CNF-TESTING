package com.mercury.topaz.cmdb.history.shared.layout.impl;

import com.mercury.topaz.cmdb.history.shared.layout.SimpleDataLayout;
import java.util.List;

public class DataLayoutFactory
{
  public static SimpleDataLayout createFullDataLayout()
  {
    return new SimpleDataLayoutImpl(true);
  }

  public static SimpleDataLayout createSimpleDataLayout(List keys)
  {
    return new SimpleDataLayoutImpl(keys);
  }

  public static SimpleDataLayout createEmptyDataLayout()
  {
    return new SimpleDataLayoutImpl(false);
  }
}