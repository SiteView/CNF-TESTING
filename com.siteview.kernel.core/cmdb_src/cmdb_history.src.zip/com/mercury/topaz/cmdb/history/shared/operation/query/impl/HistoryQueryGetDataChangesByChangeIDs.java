package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.client.change.id.ChangeIdCmdbCollection;
import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.filter.impl.HistoryFilterFactory;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class HistoryQueryGetDataChangesByChangeIDs extends AbstractHistoryQueryOperation
{
  protected static final String HISTORY_DATAS = "HISTORY_DATAS";
  private HistoryDatas _historyDatas;
  private ChangeIdCmdbCollection _changeIds;
  private DataLayout _dataLayout;
  private HistoryFilter _historyFilter;

  public HistoryQueryGetDataChangesByChangeIDs(ChangeIdCmdbCollection changeIds, DataLayout dataLayout)
  {
    setChangeIds(changeIds);
    setDataLayout(dataLayout);
    setHistoryFilter(HistoryFilterFactory.create());
  }

  public HistoryQueryGetDataChangesByChangeIDs(ChangeIdCmdbCollection changeIds, DataLayout dataLayout, HistoryFilter historyFilter) {
    setChangeIds(changeIds);
    setDataLayout(dataLayout);
    setHistoryFilter(historyFilter);
  }

  public ChangeIdCmdbCollection getChangeIds() {
    return this._changeIds;
  }

  private void setChangeIds(ChangeIdCmdbCollection changeIds) {
    this._changeIds = changeIds;
  }

  public DataLayout getDataLayout() {
    return this._dataLayout;
  }

  private void setDataLayout(DataLayout dataLayout) {
    this._dataLayout = dataLayout;
  }

  public HistoryFilter geHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    this._historyFilter = historyFilter;
  }

  public String getOperationName() {
    return "history query: get data changes by changes ids";
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException {
    HistoryDatas historyChanges = historyQueryManager.getDataChangesByChangeIds(getChangeIds(), getDataLayout(), geHistoryFilter());
    response.addResult("HISTORY_DATAS", historyChanges);
    updateWithResponse(response);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setHistoryDatas((HistoryDatas)response.getResult("HISTORY_DATAS"));
  }

  public HistoryDatas getHistoryDatas()
  {
    return this._historyDatas;
  }

  private void setHistoryDatas(HistoryDatas historyChanges) {
    this._historyDatas = historyChanges;
  }
}