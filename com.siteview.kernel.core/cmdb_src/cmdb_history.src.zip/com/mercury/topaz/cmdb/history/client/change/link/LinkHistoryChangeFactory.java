package com.mercury.topaz.cmdb.history.client.change.link;

import com.mercury.topaz.cmdb.history.client.change.HistoryChange;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryLinkChangeInfo;

public class LinkHistoryChangeFactory
{
  public static HistoryChange createHistoryChangeAddLink(HistoryLinkChangeInfo historyLinkChangeInfo)
  {
    return new HistoryChangeAddLink(historyLinkChangeInfo); }

  public static HistoryChange createHistoryChangeRemoveLink(HistoryLinkChangeInfo historyLinkChangeInfo) {
    return new HistoryChangeRemoveLink(historyLinkChangeInfo); }

  public static HistoryChange createHistoryChangeUpdateLink(HistoryLinkChangeInfo historyLinkChangeInfo) {
    return new HistoryChangeUpdateLink(historyLinkChangeInfo);
  }

  public static HistoryChange createLinkHistoryChange(HistoryLinkChangeInfo historyLinkChangeInfo, String changeType) {
    if (ChangeConstants.CHANGE_TYPES.ADD_LINK.equals(changeType))
      return createHistoryChangeAddLink(historyLinkChangeInfo);

    if (ChangeConstants.CHANGE_TYPES.UPDATE_LINK.equals(changeType))
      return createHistoryChangeUpdateLink(historyLinkChangeInfo);

    if (ChangeConstants.CHANGE_TYPES.REMOVE_LINK.equals(changeType)) {
      return createHistoryChangeRemoveLink(historyLinkChangeInfo);
    }

    throw new IllegalArgumentException("change type is illegal");
  }
}