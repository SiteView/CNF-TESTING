package com.mercury.topaz.cmdb.history.server.dal.command.update;

public class HistoryDalCleanTablesCommand extends AbstractHistoryDalDeleteHistoryTablesCommand
{
}