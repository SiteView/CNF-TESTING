package com.mercury.topaz.cmdb.history.client.change.object;

import com.mercury.topaz.cmdb.history.client.change.HistoryChangeVisitor;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.manage.HistoryChangeListenerFineGrained;

public class HistoryChangeRemoveRelation extends AbstractObjectHistoryChange
{
  HistoryChangeRemoveRelation(HistoryObjectChangeInfo historyObjectChangeInfo)
  {
    super(historyObjectChangeInfo);
  }

  public void execute(HistoryChangeListenerFineGrained changeListener)
  {
  }

  public void accept(HistoryChangeVisitor historyChangeVisitor) {
    historyChangeVisitor.removeRelationChange(getHistoryObjectChangeInfo());
  }

  public String toString() {
    return ChangeConstants.CHANGE_TYPES.REMOVE_RELATION + ": " + super.toString();
  }
}