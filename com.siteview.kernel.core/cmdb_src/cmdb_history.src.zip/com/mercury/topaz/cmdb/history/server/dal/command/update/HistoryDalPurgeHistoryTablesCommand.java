package com.mercury.topaz.cmdb.history.server.dal.command.update;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

public class HistoryDalPurgeHistoryTablesCommand extends AbstractHistoryDalDeleteHistoryTablesCommand
{
  private Date _lastDateToSave;

  public HistoryDalPurgeHistoryTablesCommand(Date lastDateToSave)
  {
    setLastDateToSave(lastDateToSave);
  }

  protected String getSqlForDeleteEventsTable()
  {
    StringBuilder sql = new StringBuilder(super.getSqlForDeleteEventsTable());

    sql.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<?");

    sql.append(" and ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append(" not in (?,?)");

    for (Iterator i$ = CMDB_TYPE_TO_HISTORY_INFO.values().iterator(); i$.hasNext(); ) { String tableName = (String)i$.next();
      sql.append(getInnerSqlForInfoTable(tableName));
    }
    return sql.toString();
  }

  private String getInnerSqlForInfoTable(String tableName) {
    StringBuilder sql = new StringBuilder(" and not exists (select 1").append(" from ").append(tableName).append(" ").append(tableName).append(" where ").append(HISTORY_CHANGES_TABLE_NAME).append(".").append(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME).append("=").append(tableName).append(".").append(HISTORY_INFO_CHANGE_ID_COLUMN_NAME).append(")");

    return sql.toString();
  }

  protected String getSqlForDeleteInfoTable(String tableName)
  {
    StringBuilder sql = new StringBuilder(super.getSqlForDeleteInfoTable(tableName));
    sql.append(" and ").append(HISTORY_INFO_END_TIME_COLUMN_NAME).append("<?");
    return sql.toString();
  }

  protected CmdbDalPreparedStatement setCustomPreparedStatementForEventsTable(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    preparedStatement.setDate(getLastDateToSave());
    preparedStatement.setString(ChangeConstants.CHANGE_TYPES.REMOVE_OBJECT);
    preparedStatement.setString(ChangeConstants.CHANGE_TYPES.REMOVE_LINK);
    return preparedStatement;
  }

  protected CmdbDalPreparedStatement setCustomPreparedStatementForInfoTables(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    preparedStatement.setDate(getLastDateToSave());
    return preparedStatement;
  }

  private Date getLastDateToSave() {
    return this._lastDateToSave;
  }

  private void setLastDateToSave(Date lastDateToSave) {
    if (lastDateToSave == null)
      throw new IllegalArgumentException("last saved date is null");

    this._lastDateToSave = lastDateToSave;
  }
}