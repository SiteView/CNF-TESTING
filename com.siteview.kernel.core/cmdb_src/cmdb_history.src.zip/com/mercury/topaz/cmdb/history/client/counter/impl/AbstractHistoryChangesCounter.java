package com.mercury.topaz.cmdb.history.client.counter.impl;

import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesCounter;

abstract class AbstractHistoryChangesCounter
  implements HistoryChangesCounter
{
  private int _addedCount;
  private int _removedCount;
  private int _updatedCount;

  protected AbstractHistoryChangesCounter(int addedCount, int updatedCount, int removedCount)
  {
    setAddedCount(addedCount);
    setUpdatedCount(updatedCount);
    setRemovedCount(removedCount);
  }

  protected AbstractHistoryChangesCounter() {
    setAddedCount(0);
    setUpdatedCount(0);
    setRemovedCount(0);
  }

  public int getAddedCount() {
    return this._addedCount;
  }

  public void setAddedCount(int addedCount) {
    this._addedCount = addedCount;
  }

  public int getRemovedCount() {
    return this._removedCount;
  }

  public void setRemovedCount(int removedCount) {
    this._removedCount = removedCount;
  }

  public int getUpdatedCount() {
    return this._updatedCount;
  }

  public void setUpdatedCount(int updatedCount) {
    this._updatedCount = updatedCount;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if (!(o instanceof AbstractHistoryChangesCounter)) {
      return false;
    }

    AbstractHistoryChangesCounter abstractHistoryChangesCounter = (AbstractHistoryChangesCounter)o;

    if (this._addedCount != abstractHistoryChangesCounter._addedCount)
      return false;

    if (this._removedCount != abstractHistoryChangesCounter._removedCount) {
      return false;
    }

    return (this._updatedCount == abstractHistoryChangesCounter._updatedCount);
  }

  public int hashCode()
  {
    int result = this._addedCount;
    result = 29 * result + this._removedCount;
    result = 29 * result + this._updatedCount;
    return result;
  }

  public String toString() {
    StringBuilder desc = new StringBuilder("Added:").append(getAddedCount()).append(" Updated:").append(getUpdatedCount()).append(" Removed:").append(getRemovedCount());

    return desc.toString();
  }
}