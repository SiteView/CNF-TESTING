package com.mercury.topaz.cmdb.history.server.dal.dao;

import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.client.change.id.ChangeIdCmdbCollection;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesExtendedCounter;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounters;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import java.util.Date;
import java.util.Map;

public abstract interface CmdbDalHistoryDAO
{
  public abstract void objectsWereAdded(Changer paramChanger, Date paramDate, CmdbObjects paramCmdbObjects);

  public abstract void objectsWereUpdated(Changer paramChanger, Date paramDate, CmdbObjects paramCmdbObjects);

  public abstract void objectsWereRemoved(Changer paramChanger, Date paramDate, CmdbObjects paramCmdbObjects);

  public abstract void linksWereAdded(Changer paramChanger, Date paramDate, CmdbLinks paramCmdbLinks);

  public abstract void linksWereUpdated(Changer paramChanger, Date paramDate, CmdbLinks paramCmdbLinks);

  public abstract void linksWereRemoved(Changer paramChanger, Date paramDate, CmdbLinks paramCmdbLinks);

  public abstract void executeBulk();

  public abstract HistoryDatas getDataChanges(CmdbIDsCollection<CmdbDataID> paramCmdbIDsCollection, HistoryFilter paramHistoryFilter, DataLayout paramDataLayout);

  public abstract HistoryDatas getDataChangesByChangeIds(ChangeIdCmdbCollection paramChangeIdCmdbCollection, DataLayout paramDataLayout, HistoryFilter paramHistoryFilter);

  public abstract HistoryDatas getDataLastChange(CmdbIDsCollection paramCmdbIDsCollection, HistoryFilter paramHistoryFilter);

  public abstract CmdbDatas getLayout(CmdbIDsCollection paramCmdbIDsCollection, Date paramDate, DataLayout paramDataLayout);

  public abstract Map<CmdbDataID, Date> getLastUpdateTime(CmdbIDsCollection paramCmdbIDsCollection);

  public abstract CmdbDataIDs checkIfDataWasChanged(CmdbIDsCollection<CmdbDataID> paramCmdbIDsCollection, Date paramDate, HistoryFilter paramHistoryFilter);

  public abstract HistoryChangesTypedCounters getNumberOfChangesByType(HistoryFilter paramHistoryFilter);

  public abstract HistoryChangesExtendedCounter getExtendedNumberOfChanges(CmdbIDsCollection<CmdbDataID> paramCmdbIDsCollection, HistoryFilter paramHistoryFilter);

  public abstract CmdbDatas<CmdbDataID, CmdbData> getRemovedData(HistoryFilter paramHistoryFilter);

  public abstract void cleanAllHistoryTables();

  public abstract void purgeHistoryTables(Date paramDate);

  public abstract void optimizeStorage();

  public abstract DbContext getDbContext();

  public abstract CmdbIDsCollection getIDsByHistoryFilter(HistoryFilter paramHistoryFilter);
}