package com.mercury.topaz.cmdb.history.shared.pattern;

import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;

public class PatternObjectIDFactory
{
  private static final String PATTERN_ID_PREFIX = "History_";

  public static CmdbObjectID createObjectIDFromPatternID(CmdbPatternID patternID)
  {
    return createObjectIDFromPatternID(patternID.getPatternName());
  }

  public static CmdbObjectID createObjectIDFromPatternID(String patternName) {
    CmdbObjectID tqlObjectID = CmdbObjectID.Factory.createObjectID("History_" + patternName);
    return tqlObjectID;
  }
}