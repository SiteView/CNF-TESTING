package com.mercury.topaz.cmdb.history.server.dal.command.update;

import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import java.util.Iterator;
import java.util.List;

public class HistoryDalCreateOrTruncateTempTableComplexCommand extends CmdbDalAbstractCommand<Void>
{
  private String _tableName = null;
  private List<String> _columnsData = null;
  private String _indexColumnName = null;

  public HistoryDalCreateOrTruncateTempTableComplexCommand(String tableName, List<String> columnsData, String indexColumnName)
  {
    setTableName(tableName);
    setColumnsData(columnsData);
    setIndexColumnName(indexColumnName);
  }

  protected Void perform() throws Exception {
    if (isOracle())
      truncateTable();
    else if (isMsSql())
      truncateMssqlTempTable();
    else
      throw new CmdbDalException("Unknown db type [" + getDbType() + "] !!!");

    return null;
  }

  private void truncateMssqlTempTable() {
    if (checkTableExistence("tempdb.dbo.#" + getTableName()))
      truncateTable();
    else
      createTempTable();
  }

  private void createTempTable()
  {
    StringBuilder sqlString = new StringBuilder();

    sqlString.append("CREATE TABLE #").append(getTableName());
    sqlString.append(" (");

    Iterator columnsDataIter = getColumnsData().iterator();
    while (columnsDataIter.hasNext()) {
      String columnData = (String)columnsDataIter.next();
      sqlString.append(columnData);
      if (columnsDataIter.hasNext())
        sqlString.append(", ");
    }

    sqlString.append(")");
    getConnection().executeAdhocSql(sqlString.toString());

    createIndex(getConnection(), getTableName(), getIndexColumnName());
  }

  private void truncateTable() {
    CmdbDalCommand truncateTableCommand = CmdbDalCommandFactory.createTruncateTableSimpleCommand(getTableName());
    truncateTableCommand.execute();
  }

  private void createIndex(CmdbDalConnection connection, String tableName, String columnName) {
    StringBuilder sqlString = new StringBuilder();

    sqlString.append("CREATE INDEX ").append("IX1_");
    sqlString.append(tableName);

    sqlString.append(" ON ").append("#").append(tableName).append(" (").append(columnName);
    sqlString.append(")");

    connection.executeAdhocSql(sqlString.toString());
  }

  protected void validateInput() {
  }

  private String getTableName() {
    return this._tableName;
  }

  private void setTableName(String tableName) {
    if (tableName == null)
      throw new IllegalArgumentException("table name is null");

    this._tableName = tableName;
  }

  private List<String> getColumnsData() {
    return this._columnsData;
  }

  private void setColumnsData(List<String> columnsData) {
    if (columnsData == null)
      throw new IllegalArgumentException("columns data is null");

    this._columnsData = columnsData;
  }

  private String getIndexColumnName() {
    return this._indexColumnName;
  }

  private void setIndexColumnName(String indexColumnName) {
    if (indexColumnName == null)
      throw new IllegalArgumentException("index column name is null");

    this._indexColumnName = indexColumnName;
  }
}