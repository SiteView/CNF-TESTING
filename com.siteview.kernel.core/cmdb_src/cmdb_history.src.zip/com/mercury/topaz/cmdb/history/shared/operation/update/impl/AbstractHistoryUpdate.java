package com.mercury.topaz.cmdb.history.shared.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.manager.HistoryManager;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.history.shared.base.HistoryLogFactory;
import com.mercury.topaz.cmdb.history.shared.operation.impl.AbstractHistoryOperation;
import com.mercury.topaz.cmdb.history.shared.operation.update.HistoryUpdate;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractHistoryUpdate extends AbstractHistoryOperation
  implements HistoryUpdate
{
  protected static Log _logger = HistoryLogFactory.getHistoryLog();

  public final void historyExecute(HistoryManager historyManager, CmdbResponse response)
    throws CmdbException
  {
    historyUpdateExecute((HistoryUpdateManager)historyManager, response);
  }

  public String getExecutionTaskQueueName() {
    return "History Update Task";
  }
}