package com.mercury.topaz.cmdb.history.shared.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.client.change.HistoryChange;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryLinkChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.info.impl.HistoryChangeInfoFactory;
import com.mercury.topaz.cmdb.history.client.change.link.LinkHistoryChangeFactory;
import com.mercury.topaz.cmdb.history.client.change.object.ObjectHistoryChangeFactory;
import com.mercury.topaz.cmdb.history.server.dal.dao.CmdbDalHistoryDAO;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.history.shared.base.HistoryConstants.ATTRIBUTES;
import com.mercury.topaz.cmdb.history.shared.base.HistoryLogFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.change.impl.CmdbChangeFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.notification.operation.command.impl.DeploymentCommandPublishChanges;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetResultMapChunk;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.chunk.ChunkRequest;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.HashMap;
import java.util.Map;

public abstract class AbstractHistoryUpdateAddHistoryChanges extends AbstractHistoryUpdate
{
  protected static Log _logger = HistoryLogFactory.getHistoryLog();
  private CmdbObjects _addedObjects;
  private CmdbObjects _updatedObjects;
  private CmdbObjects _removedObjects;
  private CmdbLinks _addedLinks;
  private CmdbLinks _updatedLinks;
  private CmdbLinks _removedLinks;
  private Changer _changer;
  private CmdbClassModel _classModel;
  private CmdbChanges _changes;
  private HistoryUpdateManager _historyUpdateManager;

  protected AbstractHistoryUpdateAddHistoryChanges(Changer changer, CmdbChanges changes)
  {
    setChanger(changer);
    setChanges(changes);
  }

  public void historyUpdateExecute(HistoryUpdateManager historyUpdateManager, CmdbResponse response)
    throws CmdbException
  {
    if (!(historyUpdateManager.isHistoryDBEnabled())) {
      return;
    }

    setHistoryUpdateManager(historyUpdateManager);
    setClassModel(historyUpdateManager.getSynchronizedClassModel());

    initializeCollections();

    filterCollections();

    sendChangesToDB(historyUpdateManager.getHistoryDAO());
  }

  protected abstract void initializeCollections();

  protected abstract void filterCollections();

  protected void sendChangesToDB(CmdbDalHistoryDAO historyDAO)
  {
    if (getAddedLinks().size() > 0)
      historyDAO.linksWereAdded(getChanger(), getChanges().getChangesDate(), getAddedLinks());

    if (getAddedObjects().size() > 0)
      historyDAO.objectsWereAdded(getChanger(), getChanges().getChangesDate(), getAddedObjects());

    if (getUpdatedLinks().size() > 0)
      historyDAO.linksWereUpdated(getChanger(), getChanges().getChangesDate(), getUpdatedLinks());

    if (getUpdatedObjects().size() > 0)
      historyDAO.objectsWereUpdated(getChanger(), getChanges().getChangesDate(), getUpdatedObjects());

    if (getRemovedLinks().size() > 0)
      historyDAO.linksWereRemoved(getChanger(), getChanges().getChangesDate(), getRemovedLinks());

    if (getRemovedObjects().size() > 0)
      historyDAO.objectsWereRemoved(getChanger(), getChanges().getChangesDate(), getRemovedObjects());

    historyDAO.executeBulk();
  }

  protected void sendNotifications(SubsystemManager subsystemManager) {
    CmdbLink curLink;
    CmdbObject curObject;
    HistoryChange change;
    CmdbChanges changes = CmdbChangeFactory.createCmdbChanges(getChanger());

    ElementSimpleLayout simpleLayout = PatternLayoutFactory.createElementSimpleLayout();
    simpleLayout.addKey(HistoryConstants.ATTRIBUTES.DISPLAY_LABEL);
    Map objectIDsToPropsMap = getObjectsLayoutPropertiesMap(simpleLayout);
    Map linkIDsToPropsMap = getLinksLayoutPropertiesMap(simpleLayout);

    ReadOnlyIterator it = getAddedLinks().getLinksIterator();
    while (it.hasNext()) {
      curLink = (CmdbLink)it.next();
      change = LinkHistoryChangeFactory.createHistoryChangeAddLink(getChangeInfo(curLink, getDataLayoutProperties(linkIDsToPropsMap, (CmdbDataID)curLink.getID())));
      changes.add(change);
    }

    it = getAddedObjects().getObjectsIterator();
    while (it.hasNext()) {
      curObject = (CmdbObject)it.next();
      change = ObjectHistoryChangeFactory.createHistoryChangeAddObject(getChangeInfo(curObject, getDataLayoutProperties(objectIDsToPropsMap, (CmdbDataID)curObject.getID())));
      changes.add(change);
    }

    it = getUpdatedLinks().getLinksIterator();
    while (it.hasNext()) {
      curObject = (CmdbLink)it.next();
      change = LinkHistoryChangeFactory.createHistoryChangeUpdateLink(getChangeInfo(curObject, getDataLayoutProperties(linkIDsToPropsMap, (CmdbDataID)curObject.getID())));
      changes.add(change);
    }

    it = getUpdatedObjects().getObjectsIterator();
    while (it.hasNext()) {
      curObject = (CmdbObject)it.next();
      change = ObjectHistoryChangeFactory.createHistoryChangeUpdateObject(getChangeInfo(curObject, getDataLayoutProperties(objectIDsToPropsMap, (CmdbDataID)curObject.getID())));
      changes.add(change);
    }

    it = getRemovedLinks().getLinksIterator();
    while (it.hasNext()) {
      curObject = (CmdbLink)it.next();
      change = LinkHistoryChangeFactory.createHistoryChangeRemoveLink(getChangeInfo(curObject));
      changes.add(change);
    }

    it = getRemovedObjects().getObjectsIterator();
    while (it.hasNext()) {
      curObject = (CmdbObject)it.next();
      change = ObjectHistoryChangeFactory.createHistoryChangeRemoveObject(getChangeInfo(curObject));
      changes.add(change);
    }

    if (changes.size() > 0) {
      DeploymentCommandPublishChanges publishChanges = new DeploymentCommandPublishChanges(FrameworkConstants.Subsystem.HISTORY, changes);
      subsystemManager.executeAsynchronousOperation(publishChanges);
    }
  }

  private CmdbProperties getDataLayoutProperties(Map<CmdbDataID, CmdbProperties> dataIDToProps, CmdbDataID dataID) {
    CmdbProperties layoutProps = (CmdbProperties)dataIDToProps.get(dataID);
    if (layoutProps == null) {
      if (_logger.isDebugEnabled())
        _logger.debug("Couldn't get the layout properties for the following id: " + dataID + ". The id doesn't exist in the topology");

      layoutProps = CmdbPropertyFactory.createProperties();
      layoutProps.add(CmdbPropertyFactory.createEmptyProperty(HistoryConstants.ATTRIBUTES.DISPLAY_LABEL, CmdbSimpleTypes.CmdbString));
    }
    return layoutProps;
  }

  private void buildIDsToLayoutPropsMap(CmdbObjectIds ids, TqlResultMap result, PatternElementNumber number, Map<CmdbDataID, CmdbProperties> propsByID) {
    CmdbObjects objects;
    try {
      objects = result.getObjects(number);
    }
    catch (Exception e) {
      if (_logger.isDebugEnabled())
        _logger.debug("Couldn't get the layout properties for the following ids: " + ids + " due to " + e);

      objects = CmdbObjectFactory.createObjects();
    }
    ReadOnlyIterator it = objects.getObjectsIterator();
    while (it.hasNext()) {
      CmdbObject curObject = (CmdbObject)it.next();
      propsByID.put(curObject.getID(), getDataProperties(curObject));
    }
  }

  private Map<CmdbDataID, CmdbProperties> getObjectsLayoutPropertiesMap(ElementSimpleLayout simpleLayout)
  {
    Map propsByID = new HashMap();

    CmdbObjectIds objectIDs = CmdbObjectIdsFactory.create();
    ReadOnlyIterator objectsIt = getAddedObjects().getObjectsIterator();
    while (objectsIt.hasNext())
      objectIDs.add((CmdbObjectID)((CmdbObject)objectsIt.next()).getID());

    objectsIt = getUpdatedObjects().getObjectsIterator();
    while (objectsIt.hasNext()) {
      objectIDs.add((CmdbObjectID)((CmdbObject)objectsIt.next()).getID());
    }

    if (objectIDs.size() > 0)
    {
      PatternElementNumber number = PatternElementNumberFactory.createElementNumber(1);
      PatternLayout patternLayout = PatternLayoutFactory.createLayout();
      patternLayout.setElementLayout(number, simpleLayout);

      ElementClassCondition elementClassCondition = PatternConditionFactory.createElementClassCondition("object", true);
      ElementCondition condition = PatternConditionFactory.createElementCondition(elementClassCondition, null, objectIDs);
      PatternNode node = PatternGraphFactory.createPatternNode(number, condition, true, null);
      ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
      patternGraph.addNode(node);
      Pattern pattern = PatternDefinitionFactory.createPattern("", "historyDBFindLayout", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);

      TqlQueryGetAdHocMap getResult = new TqlQueryGetAdHocMap(pattern, patternLayout);
      getHistoryUpdateManager().executeOperation(getResult);
      if (getResult.isDividedToChunks()) {
        int chunksCount = 0;
        ChunkRequest chunkRequest = getResult.getChunkRequest();
        while (chunkRequest.hasNext()) {
          if (chunksCount != 0)
            chunkRequest = chunkRequest.next();

          TqlQueryGetResultMapChunk getChunk = new TqlQueryGetResultMapChunk(chunkRequest, patternLayout);
          getHistoryUpdateManager().executeOperation(getChunk);
          TqlResultMap result = getChunk.getResultMap();
          buildIDsToLayoutPropsMap(objectIDs, result, number, propsByID);
          ++chunksCount;
        }
      } else {
        TqlResultMap result = getResult.getResultMap();
        buildIDsToLayoutPropsMap(objectIDs, result, number, propsByID);
      }
    }
    return propsByID;
  }

  private void buildIDsToLayoutPropsMap(CmdbLink link, TqlResultMap result, PatternElementNumber number, Map<CmdbDataID, CmdbProperties> propsByID) {
    CmdbLinks links;
    try {
      links = result.getLinks(number);
    }
    catch (Exception e) {
      if (_logger.isDebugEnabled())
        _logger.debug("Couldn't get the layout properties for the following id: " + link.getID() + " due to " + e);

      links = CmdbLinkFactory.createLinks();
    }

    ReadOnlyIterator linksIt = links.getLinksIterator();
    while (linksIt.hasNext()) {
      CmdbLink curLink = (CmdbLink)linksIt.next();
      propsByID.put(curLink.getID(), getDataProperties(curLink));
    }
  }

  private Map<CmdbDataID, CmdbProperties> getLinksLayoutPropertiesMap(ElementSimpleLayout simpleLayout)
  {
    Map propsByID = new HashMap();

    ReadOnlyIterator linksIt = getAddedLinks().getLinksIterator();
    while (linksIt.hasNext())
      addLinkLayoutPropertiesIterator((CmdbLink)linksIt.next(), propsByID, simpleLayout);

    linksIt = getUpdatedLinks().getLinksIterator();
    while (linksIt.hasNext()) {
      addLinkLayoutPropertiesIterator((CmdbLink)linksIt.next(), propsByID, simpleLayout);
    }

    return propsByID;
  }

  private void addLinkLayoutPropertiesIterator(CmdbLink link, Map<CmdbDataID, CmdbProperties> propsByID, ElementSimpleLayout simpleLayout)
  {
    PatternElementNumber number = PatternElementNumberFactory.createElementNumber(1);
    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    patternLayout.setElementLayout(number, simpleLayout);
    ModifiableNodeLinksCondition linkCond = PatternConditionFactory.createNodeLinksCondition();
    linkCond.addLinkCardinality(PatternConditionFactory.createLinkCardinality(number.getNumber(), 1, -1));

    ElementClassCondition elementEndClassCondition = PatternConditionFactory.createElementClassCondition("object", true);

    PatternElementNumber end1Number = PatternElementNumberFactory.createElementNumber(3);
    CmdbObjectIds end1Ids = CmdbObjectIdsFactory.create();
    end1Ids.add(link.getEnd1());
    ElementCondition end1Condition = PatternConditionFactory.createElementCondition(elementEndClassCondition, null, end1Ids);
    PatternNode end1Node = PatternGraphFactory.createPatternNode(end1Number, end1Condition, false, linkCond);

    PatternElementNumber end2Number = PatternElementNumberFactory.createElementNumber(2);
    CmdbObjectIds end2Ids = CmdbObjectIdsFactory.create();
    end2Ids.add(link.getEnd2());
    ElementCondition end2Condition = PatternConditionFactory.createElementCondition(elementEndClassCondition, null, end2Ids);
    PatternNode end2Node = PatternGraphFactory.createPatternNode(end2Number, end2Condition, false, linkCond);

    ElementCondition classCondition = PatternConditionFactory.createElementCondition(link.getType(), false);
    PatternLink patternLink = PatternGraphFactory.createPatternLink(number, end1Number, end2Number, classCondition, true);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(end1Node);
    patternGraph.addNode(end2Node);
    patternGraph.addLink(patternLink);

    Pattern pattern = PatternDefinitionFactory.createPattern("", "historyDBFindLayout", PatternGroupId.PATTERN_GROUP_ALL, patternGraph);
    TqlQueryGetAdHocMap getResult = new TqlQueryGetAdHocMap(pattern, patternLayout);
    getHistoryUpdateManager().executeOperation(getResult);
    TqlResultMap result = getResult.getResultMap();
    buildIDsToLayoutPropsMap(link, result, number, propsByID);
  }

  private CmdbProperties getDataProperties(CmdbData<?> data) {
    CmdbProperties props = CmdbPropertyFactory.createProperties();
    if (data == null) {
      _logger.error("layout data is null. couldn't find the layout for the data " + data);
    } else {
      ReadOnlyIterator it = data.getPropertiesIterator();
      while (it.hasNext()) {
        CmdbProperty curProp = (CmdbProperty)it.next();
        props.add(curProp);
      }
    }
    return props;
  }

  private HistoryObjectChangeInfo getChangeInfo(CmdbObject object, CmdbProperties properties) {
    return HistoryChangeInfoFactory.createObjectChangeInfoWithLayoutProperties(object, getChanges().getChangesDate(), getChanger(), properties);
  }

  private HistoryLinkChangeInfo getChangeInfo(CmdbLink link, CmdbProperties properties) {
    return HistoryChangeInfoFactory.createLinkChangeInfoWithLayoutProperties(link, getChanges().getChangesDate(), getChanger(), properties);
  }

  private HistoryObjectChangeInfo getChangeInfo(CmdbObject object) {
    return HistoryChangeInfoFactory.createObjectChangeInfo(object, getChanges().getChangesDate(), getChanger());
  }

  private HistoryLinkChangeInfo getChangeInfo(CmdbLink link) {
    return HistoryChangeInfoFactory.createLinkChangeInfo(link, getChanges().getChangesDate(), getChanger());
  }

  protected CmdbLinks getAddedLinks() {
    if (this._addedLinks == null)
      setAddedLinks(CmdbLinkFactory.createLinks());

    return this._addedLinks;
  }

  protected void setAddedLinks(CmdbLinks addedLinks) {
    if (addedLinks == null)
      throw new IllegalArgumentException("added links is null");

    this._addedLinks = addedLinks;
  }

  protected CmdbObjects getAddedObjects() {
    if (this._addedObjects == null)
      setAddedObjects(CmdbObjectFactory.createObjects());

    return this._addedObjects;
  }

  protected void setAddedObjects(CmdbObjects addedObjects) {
    if (addedObjects == null)
      throw new IllegalArgumentException("added objects is null");

    this._addedObjects = addedObjects;
  }

  protected CmdbLinks getRemovedLinks() {
    if (this._removedLinks == null)
      setRemovedLinks(CmdbLinkFactory.createLinks());

    return this._removedLinks;
  }

  protected void setRemovedLinks(CmdbLinks removedLinks) {
    if (removedLinks == null)
      throw new IllegalArgumentException("removed links is null");

    this._removedLinks = removedLinks;
  }

  protected CmdbObjects getRemovedObjects() {
    if (this._removedObjects == null)
      setRemovedObjects(CmdbObjectFactory.createObjects());

    return this._removedObjects;
  }

  protected void setRemovedObjects(CmdbObjects removedObjects) {
    if (removedObjects == null)
      throw new IllegalArgumentException("removed objects is null");

    this._removedObjects = removedObjects;
  }

  protected CmdbLinks getUpdatedLinks() {
    if (this._updatedLinks == null)
      setUpdatedLinks(CmdbLinkFactory.createLinks());

    return this._updatedLinks;
  }

  protected void setUpdatedLinks(CmdbLinks updatedLinks) {
    if (updatedLinks == null)
      throw new IllegalArgumentException("updated links is null");

    this._updatedLinks = updatedLinks;
  }

  protected CmdbObjects getUpdatedObjects() {
    if (this._updatedObjects == null)
      setUpdatedObjects(CmdbObjectFactory.createObjects());

    return this._updatedObjects;
  }

  protected void setUpdatedObjects(CmdbObjects updatedObjects) {
    if (updatedObjects == null)
      throw new IllegalArgumentException("updated objects is null");

    this._updatedObjects = updatedObjects;
  }

  private Changer getChanger() {
    return this._changer;
  }

  protected void setChanger(Changer changer) {
    if (changer == null)
      throw new IllegalArgumentException("changer is null");

    this._changer = changer;
  }

  protected CmdbClassModel getClassModel() {
    return this._classModel;
  }

  private void setClassModel(CmdbClassModel classModel) {
    if (classModel == null)
      throw new IllegalArgumentException("class model is null");

    this._classModel = classModel;
  }

  protected CmdbChanges getChanges() {
    return this._changes;
  }

  private void setChanges(CmdbChanges changes) {
    if (changes == null)
      throw new IllegalArgumentException("changes is null");

    this._changes = changes;
  }

  protected HistoryUpdateManager getHistoryUpdateManager() {
    return this._historyUpdateManager;
  }

  private void setHistoryUpdateManager(HistoryUpdateManager historyUpdateManager) {
    this._historyUpdateManager = historyUpdateManager;
  }
}