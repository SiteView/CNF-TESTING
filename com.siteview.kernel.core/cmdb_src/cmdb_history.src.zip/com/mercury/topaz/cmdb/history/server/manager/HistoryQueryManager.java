package com.mercury.topaz.cmdb.history.server.manager;

import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.client.change.id.ChangeIdCmdbCollection;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesExtendedCounter;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounters;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import java.util.Date;
import java.util.Map;

public abstract interface HistoryQueryManager extends HistoryManager
{
  public abstract CmdbDataIDs checkIfDataWasChanged(CmdbIDsCollection<CmdbDataID> paramCmdbIDsCollection, Date paramDate, HistoryFilter paramHistoryFilter);

  public abstract HistoryDatas getDataChanges(CmdbIDsCollection<CmdbDataID> paramCmdbIDsCollection, HistoryFilter paramHistoryFilter, DataLayout paramDataLayout);

  public abstract HistoryDatas getDataChangesByChangeIds(ChangeIdCmdbCollection paramChangeIdCmdbCollection, DataLayout paramDataLayout, HistoryFilter paramHistoryFilter);

  public abstract HistoryDatas getDataLastChange(CmdbIDsCollection paramCmdbIDsCollection, HistoryFilter paramHistoryFilter);

  public abstract Map getLastUpdateTime(CmdbIDsCollection paramCmdbIDsCollection);

  public abstract CmdbDatas getLayout(CmdbIDsCollection paramCmdbIDsCollection, Date paramDate, DataLayout paramDataLayout);

  public abstract HistoryChangesTypedCounters getNumberOfChangesByType(HistoryFilter paramHistoryFilter);

  public abstract HistoryChangesExtendedCounter getExtendedNumberOfChanges(CmdbIDsCollection<CmdbDataID> paramCmdbIDsCollection, HistoryFilter paramHistoryFilter);

  public abstract CmdbDatas getRemovedData(HistoryFilter paramHistoryFilter);

  public abstract CmdbIDsCollection getIDsByHistoryFilter(HistoryFilter paramHistoryFilter);
}