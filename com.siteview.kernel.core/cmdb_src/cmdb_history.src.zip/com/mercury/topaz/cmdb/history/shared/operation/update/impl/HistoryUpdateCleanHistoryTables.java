package com.mercury.topaz.cmdb.history.shared.operation.update.impl;

import com.mercury.topaz.cmdb.history.server.dal.dao.CmdbDalHistoryDAO;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class HistoryUpdateCleanHistoryTables extends AbstractHistoryUpdate
{
  public String getOperationName()
  {
    return "History Update: Clean All History Tables";
  }

  public void historyUpdateExecute(HistoryUpdateManager historyUpdateManager, CmdbResponse response) throws CmdbException {
    historyUpdateManager.getHistoryDAO().cleanAllHistoryTables();
  }
}