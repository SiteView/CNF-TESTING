package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import java.io.Serializable;
import java.util.Map;

public class HistoryQueryGetLastUpdateTime extends AbstractHistoryQueryOperation
{
  private static final String LAST_UPDATE_TIME = "LAST_UPDATE_TIME";
  private Map _lastUpdateTime;
  private CmdbIDsCollection _cmdbDataIDs;

  public HistoryQueryGetLastUpdateTime(CmdbIDsCollection cmdbDataIDs)
  {
    setCmdbDataIDs(cmdbDataIDs);
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException
  {
    Map lastUpdateTime = historyQueryManager.getLastUpdateTime(getCmdbDataIDs());
    response.addResult("LAST_UPDATE_TIME", (Serializable)lastUpdateTime);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setLastUpdateTime((Map)response.getResult("LAST_UPDATE_TIME"));
  }

  public Map getLastUpdateTime() {
    return this._lastUpdateTime;
  }

  private void setLastUpdateTime(Map lastUpdateTime) {
    this._lastUpdateTime = lastUpdateTime;
  }

  public String getOperationName() {
    return "history query: get last update time ";
  }

  private CmdbIDsCollection getCmdbDataIDs() {
    return this._cmdbDataIDs;
  }

  private void setCmdbDataIDs(CmdbIDsCollection cmdbDataIDs) {
    if ((cmdbDataIDs == null) || (cmdbDataIDs.isEmpty()))
      throw new IllegalArgumentException("data ids is null or empty");

    this._cmdbDataIDs = cmdbDataIDs;
  }
}