package com.mercury.topaz.cmdb.history.client.counter.impl;

import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounter;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounters;

public class HistoryChangesTypedCounterFactory
{
  public static HistoryChangesTypedCounter createHistoryChangesTypedCounter(String classType, int addedCount, int updatedCount, int removedCount)
  {
    return new HistoryChangesTypedCounterImpl(classType, addedCount, updatedCount, removedCount);
  }

  public static HistoryChangesTypedCounter createHistoryChangesTypedCounter(String classType) {
    return new HistoryChangesTypedCounterImpl(classType);
  }

  public static HistoryChangesTypedCounters createHistoryChangesTypedCounters() {
    return new HistoryChangesTypedCountersImpl();
  }
}