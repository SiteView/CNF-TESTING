package com.mercury.topaz.cmdb.history.server.dal.command;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.shared.base.HistoryConstants;
import com.mercury.topaz.cmdb.history.shared.base.HistoryConstants.DAL;
import com.mercury.topaz.cmdb.history.shared.base.HistoryLogFactory;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalAbstractCommand;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public abstract class AbstractHistoryDalCommand<RESULT> extends CmdbDalAbstractCommand<RESULT>
{
  protected static Log _logger = HistoryLogFactory.getHistoryLog();
  protected static final Integer MAX_BYTES_SIZE = Integer.valueOf(2010);
  protected static Date MAX_END_DATE = new Date(HistoryConstants.MAX_END_DATE_NUMBER);
  protected static String HISTORY_CHANGES_TABLE_NAME = HistoryConstants.DAL.HISTORY_CHANGES_TABLE_NAME;
  protected static String HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME = "ID";
  protected static String HISTORY_CHANGES_CI_ID_COLUMN_NAME = "OBJECT_ID";
  protected static String HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME = "EVENT_ID";
  protected static String HISTORY_CHANGES_CHANGER_TYPE_COLUMN_NAME = "CHANGER_TYPE";
  protected static String HISTORY_CHANGES_CHANGER_INFO_COLUMN_NAME = "CHANGER_INFO";
  protected static String HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME = "EVENT_TIME";
  protected static String HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME = "OBJECT_CLASS";
  protected static String HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME = "IS_OBJECT";
  protected static String HISTORY_CHANGES_END1_COLUMN_NAME = "END1_ID";
  protected static String HISTORY_CHANGES_END2_COLUMN_NAME = "END2_ID";
  protected static String HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME = "CUSTOMER_ID";
  protected static String[] HISTORY_EVENTS_COLUMNS = { HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME, HISTORY_CHANGES_CI_ID_COLUMN_NAME, HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME, HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME, HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME, HISTORY_CHANGES_CHANGER_INFO_COLUMN_NAME, HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME, HISTORY_CHANGES_END1_COLUMN_NAME, HISTORY_CHANGES_END2_COLUMN_NAME, HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME, HISTORY_CHANGES_CHANGER_TYPE_COLUMN_NAME };
  protected static String HISTORY_INFO_STRING_TABLE_NAME = "HIST_INF_STR";
  protected static String HISTORY_INFO_BOOLEAN_TABLE_NAME = "HIST_INF_BOOL";
  protected static String HISTORY_INFO_BYTES_TABLE_NAME = "HIST_INF_BYTE";
  protected static String HISTORY_INFO_DATE_TABLE_NAME = "HIST_INF_DATE";
  protected static String HISTORY_INFO_DOUBLE_TABLE_NAME = "HIST_INF_DBL";
  protected static String HISTORY_INFO_INTEGER_TABLE_NAME = "HIST_INF_INT";
  protected static String HISTORY_INFO_LONG_TABLE_NAME = "HIST_INF_LONG";
  protected static String HISTORY_INFO_XML_TABLE_NAME = "HIST_INF_XML";
  protected static String HISTORY_INFO_FLOAT_TABLE_NAME = "HIST_INF_FLT";
  protected static String HISTORY_INFO_CHANGE_ID_COLUMN_NAME = "ID";
  protected static String HISTORY_INFO_CI_ID_COLUMN_NAME = "OBJECT_ID";
  protected static String HISTORY_INFO_ATTR_ID_COLUMN_NAME = "ATTR_ID";
  protected static String HISTORY_INFO_ATTR_VALUE_COLUMN_NAME = "ATTR_VALUE";
  protected static String HISTORY_INFO_END_TIME_COLUMN_NAME = "END_TIME";
  protected static String HISTORY_INFO_CUSTOMER_ID_COLUMN_NAME = "CUSTOMER_ID";
  protected static String[] HISTORY_INFO_COLUMNS = { HISTORY_INFO_CHANGE_ID_COLUMN_NAME, HISTORY_INFO_CI_ID_COLUMN_NAME, HISTORY_INFO_ATTR_ID_COLUMN_NAME, HISTORY_INFO_ATTR_VALUE_COLUMN_NAME, HISTORY_INFO_END_TIME_COLUMN_NAME, HISTORY_INFO_CUSTOMER_ID_COLUMN_NAME };
  protected static Map<CmdbType, String> CMDB_TYPE_TO_HISTORY_INFO = new HashMap();
  protected static String CHANGE_ID_TEMP_TABLE_NAME;
  protected static String IDS_TO_DATES_TEMP_TABLE_NAME;
  protected static String IDS_TO_DATES_DATE_COLUMN_NAME;
  public static final Integer MAX_CHANGER_TYPE_SIZE;

  protected static byte[] getBytesFromDataID(CmdbDataID dataID)
  {
    if (dataID == null)
      return null;

    return AbstractCMDBDigest.toBytes((AbstractCMDBDigest)dataID);
  }

  protected boolean shouldRunUpgradeAddIndex(String tableName, String indexName) {
    return (!(isIndexExists(tableName, indexName)));
  }

  protected boolean isIndexExists(String tableName, String indexName) {
    CmdbDalCommand checkIndexExistenceCommand = CmdbDalCommandFactory.createCheckIndexExistenceSimpleCommand(tableName, indexName);
    CmdbDalCommandResult result = checkIndexExistenceCommand.execute();
    return ((Boolean)result.getResult()).booleanValue();
  }

  protected void addObjectClassIndex(String tableName, String indexName, String[] colNames) {
    if (colNames.length < 1) {
      if (_logger.isInfoEnabled())
        _logger.info("Don't add index '" + indexName + "' to table '" + tableName + "' since colNames are empty");

      return;
    }

    StringBuilder addIndex = new StringBuilder().append(getCreateIndexPrefix()).append(indexName).append(" on ").append(tableName).append(" (").append(colNames[0]);

    for (int index = 1; index < colNames.length; ++index)
      addIndex.append(",").append(colNames[index]);

    addIndex.append(")").append(getCreateIndexSuffix());
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Update(addIndex.toString());
    preparedStatement.executeUpdate();
    preparedStatement.close();
  }

  private StringBuilder getCreateIndexPrefix() {
    return new StringBuilder("create index ");
  }

  private StringBuilder getCreateIndexSuffix() {
    StringBuilder suffix = new StringBuilder();
    if (getConnectionPool().isUsingOracleDB())
      suffix.append(" tablespace ").append(getConnectionPool().getIndexTableSpaceName());

    return suffix;
  }

  static
  {
    CMDB_TYPE_TO_HISTORY_INFO.put(CmdbSimpleTypes.CmdbString, HISTORY_INFO_STRING_TABLE_NAME);
    CMDB_TYPE_TO_HISTORY_INFO.put(CmdbSimpleTypes.CmdbBoolean, HISTORY_INFO_BOOLEAN_TABLE_NAME);
    CMDB_TYPE_TO_HISTORY_INFO.put(CmdbSimpleTypes.CmdbBytes, HISTORY_INFO_BYTES_TABLE_NAME);
    CMDB_TYPE_TO_HISTORY_INFO.put(CmdbSimpleTypes.CmdbDate, HISTORY_INFO_DATE_TABLE_NAME);
    CMDB_TYPE_TO_HISTORY_INFO.put(CmdbSimpleTypes.CmdbDouble, HISTORY_INFO_DOUBLE_TABLE_NAME);
    CMDB_TYPE_TO_HISTORY_INFO.put(CmdbSimpleTypes.CmdbFloat, HISTORY_INFO_FLOAT_TABLE_NAME);
    CMDB_TYPE_TO_HISTORY_INFO.put(CmdbSimpleTypes.CmdbInteger, HISTORY_INFO_INTEGER_TABLE_NAME);

    CMDB_TYPE_TO_HISTORY_INFO.put(CmdbSimpleTypes.CmdbLong, HISTORY_INFO_LONG_TABLE_NAME);

    CMDB_TYPE_TO_HISTORY_INFO.put(CmdbSimpleTypes.CmdbXml, HISTORY_INFO_XML_TABLE_NAME);

    CHANGE_ID_TEMP_TABLE_NAME = "CHANGE_ID_TMP";
    IDS_TO_DATES_TEMP_TABLE_NAME = "IDS_TO_DATES_TMP";
    IDS_TO_DATES_DATE_COLUMN_NAME = "DATA_DATE";

    MAX_CHANGER_TYPE_SIZE = Integer.valueOf(20);
  }
}