package com.mercury.topaz.cmdb.history.client.change.info.impl;

import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Date;

class HistoryObjectChangeInfoImpl extends AbstractHistoryChangeInfo
  implements HistoryObjectChangeInfo
{
  private CmdbObject _cmdbObject;

  protected HistoryObjectChangeInfoImpl(Long changeId, CmdbObject cmdbObject)
  {
    setChangeId(changeId);
    setCmdbObject(cmdbObject);
  }

  protected HistoryObjectChangeInfoImpl(CmdbObject cmdbObject, Date changeTime, Changer changer, CmdbProperties layoutProperties, CmdbProperties previousValues) {
    super(changeTime, changer, layoutProperties, previousValues);
    setCmdbObject(cmdbObject);
  }

  protected HistoryObjectChangeInfoImpl(CmdbObject cmdbObject, Date changeTime, Changer changer, CmdbProperties layoutProperties, CmdbProperties previousValues, Long changeId) {
    super(changeTime, changer, layoutProperties, previousValues, changeId);
    setCmdbObject(cmdbObject);
  }

  public CmdbData getData() {
    return getCmdbObject();
  }

  public CmdbObject getCmdbObject() {
    return this._cmdbObject;
  }

  private void setCmdbObject(CmdbObject cmdbObject) {
    this._cmdbObject = cmdbObject;
  }

  public ReadOnlyIterator getPropertiesIterator() {
    return getCmdbObject().getPropertiesIterator();
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (getClass() != o.getClass()))
      return false;

    if (!(super.equals(o))) {
      return false;
    }

    HistoryObjectChangeInfoImpl that = (HistoryObjectChangeInfoImpl)o;

    if (this._cmdbObject != null) if (this._cmdbObject.equals(that._cmdbObject)) break label72;
    label72: return (that._cmdbObject == null);
  }

  public int hashCode()
  {
    int result = super.hashCode();
    result = 29 * result + ((this._cmdbObject != null) ? this._cmdbObject.hashCode() : 0);
    return result;
  }
}