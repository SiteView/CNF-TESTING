package com.mercury.topaz.cmdb.history.client.change.object;

import com.mercury.topaz.cmdb.history.client.change.impl.AbstractHistoryChange;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;

public abstract class AbstractObjectHistoryChange extends AbstractHistoryChange
{
  private HistoryObjectChangeInfo _historyObjectChangeInfo;

  public AbstractObjectHistoryChange(HistoryObjectChangeInfo historyObjectChangeInfo)
  {
    setHistoryObjectChangeInfo(historyObjectChangeInfo);
  }

  protected HistoryObjectChangeInfo getHistoryObjectChangeInfo() {
    return this._historyObjectChangeInfo;
  }

  private void setHistoryObjectChangeInfo(HistoryObjectChangeInfo historyObjectChangeInfo) {
    this._historyObjectChangeInfo = historyObjectChangeInfo;
  }

  public HistoryChangeInfo getChangeInfo() {
    return getHistoryObjectChangeInfo();
  }

  public CmdbDataID getCiID() {
    return ((CmdbDataID)getHistoryObjectChangeInfo().getCmdbObject().getID());
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (getClass() != o.getClass())) {
      return false;
    }

    AbstractObjectHistoryChange that = (AbstractObjectHistoryChange)o;

    if (this._historyObjectChangeInfo != null) if (this._historyObjectChangeInfo.equals(that._historyObjectChangeInfo))
        break label62;
    label62: return (that._historyObjectChangeInfo == null);
  }

  public int hashCode()
  {
    return ((this._historyObjectChangeInfo != null) ? this._historyObjectChangeInfo.hashCode() : 0);
  }
}