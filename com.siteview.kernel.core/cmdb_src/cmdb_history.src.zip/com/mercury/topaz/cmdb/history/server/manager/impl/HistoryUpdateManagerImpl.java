package com.mercury.topaz.cmdb.history.server.manager.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.history.server.periodic.PurgingPeriodicTask;
import com.mercury.topaz.cmdb.history.shared.listener.HistoryDBModelChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.history.shared.listener.HistoryDBTqlChangeListenerCorseGrained;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.base.itc.lock.SingleReadSingleWrite;
import com.mercury.topaz.cmdb.server.base.itc.schedule.Scheduler;
import com.mercury.topaz.cmdb.server.manage.Framework;
import com.mercury.topaz.cmdb.server.manage.environment.LocalEnvironment;
import com.mercury.topaz.cmdb.server.util.time.CmdbTime;
import com.mercury.topaz.cmdb.shared.base.log.CmdbLogFactory;
import com.mercury.topaz.cmdb.shared.notification.operation.command.impl.DeploymentCommandRegisterCorseGrainedListener;
import com.mercury.topaz.cmdb.shared.tql.change.filter.impl.TqlNotificationFilterFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import java.util.Calendar;

class HistoryUpdateManagerImpl extends AbstractHistoryManager
  implements HistoryUpdateManager, SingleReadSingleWrite
{
  private static final String KEY_PURGING_TASK = "keyPurgingTask";
  private static final long DEFAULT_DELAY = 2000L;
  private PurgingPeriodicTask _purgingTask;
  private boolean _isHistoryDBEnabled;
  private static final int CONCURRENT_UPDATES_LIMIT = 1;

  HistoryUpdateManagerImpl(LocalEnvironment localEnvironment)
  {
    super(localEnvironment);
  }

  public void shutdown() {
    if (getPurgingTask() != null)
      getLocalEnvironment().getScheduler().removePeriodicTask(getPurgingTask());

    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: HistoryUpdateManager is shutdown properly !!!");
  }

  public void startUp() {
    Framework.getInstance().allocateThreadPool(this, 1);

    HistoryDBModelChangeListenerCorseGrained listener = new HistoryDBModelChangeListenerCorseGrained(getCustomerID());
    DeploymentCommandRegisterCorseGrainedListener register = new DeploymentCommandRegisterCorseGrainedListener(listener);
    executeOperation(register);

    HistoryDBTqlChangeListenerCorseGrained tqlListener = new HistoryDBTqlChangeListenerCorseGrained(getCustomerID());
    register = new DeploymentCommandRegisterCorseGrainedListener(tqlListener, TqlNotificationFilterFactory.createFilter(PatternGroupId.PATTERN_GROUP_VIEW));
    executeOperation(register);

    setPurgingTask(new PurgingPeriodicTask("keyPurgingTask", getIntervalInMilliSeconds(), getContext()));
    getLocalEnvironment().getScheduler().addPeriodicTask(getPurgingTask(), getDelayInMilliSeconds());

    setHistoryDBEnabled(true);

    CmdbLogFactory.getCMDBInfoLog().info("Customer [" + getCustomerID() + "]: HistoryUpdateManager is started up properly !!!");
  }

  private long getIntervalInMilliSeconds() {
    SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();
    long intervalInHours = settingsReader.getLong("history.purging.scheduler.interval.in.hours", 24L);
    return (intervalInHours * 60L * 60L * 1000L); }

  private long getDelayInMilliSeconds() {
    SettingsReader settingsReader = getLocalEnvironment().getSettingsReader();
    int hourOfFirstRun = settingsReader.getInt("history.purging.scheduler.hour.of.first.run", 1);
    Calendar currentCallendar = Calendar.getInstance();
    long currentTimeInMilli = CmdbTime.currentTimeMillis();
    currentCallendar.setTimeInMillis(currentTimeInMilli);
    int hours = currentCallendar.get(11);
    int hoursUntil24 = 24 - hours;
    int diff = (hoursUntil24 + hourOfFirstRun) % 24;
    currentCallendar.add(11, diff);
    currentCallendar.set(12, 0);
    currentCallendar.set(13, 0);
    currentCallendar.set(14, 0);
    long delay = currentCallendar.getTimeInMillis() - currentTimeInMilli;
    if (delay <= 0L)
      return 2000L;

    return delay;
  }

  private PurgingPeriodicTask getPurgingTask() {
    return this._purgingTask;
  }

  private void setPurgingTask(PurgingPeriodicTask purgingTask) {
    if (purgingTask == null)
      throw new IllegalArgumentException("purging task is null");

    this._purgingTask = purgingTask;
  }

  public boolean isHistoryDBEnabled() {
    return this._isHistoryDBEnabled;
  }

  private void setHistoryDBEnabled(boolean historyDBEnabled) {
    this._isHistoryDBEnabled = historyDBEnabled;
  }

  public void enableHistoryDB() {
    setHistoryDBEnabled(true);
  }

  public void disableHistoryDB() {
    setHistoryDBEnabled(false);
  }

  public String getName() {
    return "History Update Task";
  }
}