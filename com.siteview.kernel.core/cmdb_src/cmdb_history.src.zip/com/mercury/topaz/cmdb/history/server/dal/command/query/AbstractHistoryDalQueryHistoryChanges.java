package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.client.change.HistoryChange;
import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeType;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.info.impl.HistoryChangeInfoFactory;
import com.mercury.topaz.cmdb.history.client.change.object.ObjectHistoryChangeFactory;
import com.mercury.topaz.cmdb.history.server.dal.command.update.HistoryDalCreateOrTruncateTempTableComplexCommand;
import com.mercury.topaz.cmdb.history.shared.base.HistoryConstants.ATTRIBUTES;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.history.shared.layout.SimpleDataLayout;
import com.mercury.topaz.cmdb.history.shared.layout.impl.DataLayoutFactory;
import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.util.time.CmdbTime;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreator;
import com.mercury.topaz.cmdb.shared.classmodel.util.property.PropertyCreatorFactory;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.util.CmdbCollection;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class AbstractHistoryDalQueryHistoryChanges<RESULT> extends AbstractHistoryDalQueryCommand<RESULT>
{
  private HistoryFilter _historyFilter;
  private boolean _isRelationInFilter;
  private Map<CmdbDataID, CmdbData<?>> _end1IDsToLayout;
  private Map<CmdbDataID, CmdbData<?>> _end2IDsToLayout;
  private CmdbDataIDs _end1IDs;
  private CmdbDataIDs _end2IDs;

  public AbstractHistoryDalQueryHistoryChanges(HistoryFilter historyFilter)
  {
    setHistoryFilter(historyFilter);
    initilizeIsRelationInFilter();
    setEnd1IDs(CmdbDataIdsFactory.create());
    setEnd2IDs(CmdbDataIdsFactory.create());
  }

  protected void initilizeIsRelationInFilter() {
    setRelationInFilter(getHistoryFilter().isRelationInFilter());
  }

  public boolean isRelationInFilter() {
    return this._isRelationInFilter;
  }

  private void setRelationInFilter(boolean relationInFilter) {
    this._isRelationInFilter = relationInFilter;
  }

  protected HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    if (historyFilter == null)
      throw new IllegalArgumentException("history filter is null");

    this._historyFilter = historyFilter;
  }

  private Map<CmdbDataID, CmdbData<?>> getEnd1IDsToLayout() {
    return this._end1IDsToLayout;
  }

  private void setEnd1IDsToLayout(Map<CmdbDataID, CmdbData<?>> endIDsToLayout) {
    this._end1IDsToLayout = endIDsToLayout;
  }

  private Map<CmdbDataID, CmdbData<?>> getEnd2IDsToLayout() {
    return this._end2IDsToLayout;
  }

  private void setEnd2IDsToLayout(Map<CmdbDataID, CmdbData<?>> endIDsToLayout) {
    this._end2IDsToLayout = endIDsToLayout;
  }

  private CmdbDataIDs getEnd1IDs() {
    return this._end1IDs;
  }

  private void setEnd1IDs(CmdbDataIDs end1IDs) {
    this._end1IDs = end1IDs;
  }

  private CmdbDataIDs getEnd2IDs() {
    return this._end2IDs;
  }

  private void setEnd2IDs(CmdbDataIDs end2IDs) {
    this._end2IDs = end2IDs;
  }

  protected HistoryDatas queryTables(SimpleDataLayout simpleDataLayout) throws SQLException
  {
    if (useTempTable(getFilterIDs().size()))
      return runSelectInTempTable(simpleDataLayout);

    return runSelectInChunks(simpleDataLayout); }

  private HistoryDatas runSelectInChunks(SimpleDataLayout simpleDataLayout) throws SQLException {
    Map changeIDChanges = new HashMap();
    List changeIDsOrderByDate = new ArrayList();
    CmdbCollection idsLeft = getFilterIDs();
    int maxIDsInChunk = getMaxPossibleSizeForInChunk();
    int numOfChunks = calcNumOfInChunks(idsLeft.size());
    for (int chunkNum = 0; chunkNum < numOfChunks; ++chunkNum) {
      int numOfIDs = (idsLeft.size() > maxIDsInChunk) ? maxIDsInChunk : idsLeft.size();
      StringBuilder inSql = createInSqlString(numOfIDs);
      runSelectForIDs(changeIDsOrderByDate, changeIDChanges, createInSqlStringForIdColumn(inSql), createInSqlStringForEnd1IdColumn(inSql), idsLeft, numOfIDs, simpleDataLayout);
      if (idsLeft.size() - numOfIDs > 0)
        idsLeft = copyIDs(idsLeft, numOfIDs);
    }

    return buildHistoryChanges(changeIDChanges, changeIDsOrderByDate, simpleDataLayout);
  }

  private HistoryDatas runSelectInTempTable(SimpleDataLayout simpleDataLayout) throws SQLException
  {
    createIDTempTable();
    Map changeIDChanges = new HashMap();
    List changeIDsOrderByDate = new ArrayList();
    runSelectForIDs(changeIDsOrderByDate, changeIDChanges, createInSqlStringForIdTempTable(), createInSqlStringForEnd1IdTempTable(), getFilterIDs(), 0, simpleDataLayout);
    return buildHistoryChanges(changeIDChanges, changeIDsOrderByDate, simpleDataLayout);
  }

  private HistoryDatas buildHistoryChanges(Map<Long, AbstractHistoryDalQueryHistoryChanges<RESULT>.DataChanges> changeIDChanges, List<Long> changeIDsOrderByDate, SimpleDataLayout simpleDataLayout)
  {
    Date layoutDate;
    CmdbDatas datas = null;
    if ((shouldGetEnd2Info()) && (!(getEnd2IDs().isEmpty()))) {
      layoutDate = getHistoryFilter().getToDate();
      if (layoutDate == null)
        layoutDate = new Date(CmdbTime.currentTimeMillis());

      List layoutAttributes = new ArrayList(1);
      layoutAttributes.add(HistoryConstants.ATTRIBUTES.DISPLAY_LABEL);
      DataLayout dataLayout = DataLayoutFactory.createSimpleDataLayout(layoutAttributes);
      HistoryDalGetDataLayoutInTheSameDateCommand getEndsLayout = new HistoryDalGetDataLayoutInTheSameDateCommand(getEnd2IDs(), layoutDate, dataLayout, getHistoryFilter().getEnd2ClassTypes());
      CmdbDalCommandResult result = getEndsLayout.execute();
      datas = (CmdbDatas)result.getResult();

      if (datas != null) {
        Map endIDsToLayout = new HashMap(datas.size());
        ReadOnlyIterator datasIt = datas.getDatasIterator();
        while (datasIt.hasNext()) {
          CmdbData curData = (CmdbData)datasIt.next();
          endIDsToLayout.put(curData.getDataID(), curData);
        }
        setEnd2IDsToLayout(endIDsToLayout);
      }

    }

    if (!(getEnd1IDs().isEmpty())) {
      layoutDate = new Date(CmdbTime.currentTimeMillis());
      HistoryDalGetDataLayoutWithoutPropsCommand getEnd1Data = new HistoryDalGetDataLayoutWithoutPropsCommand(getEnd1IDs(), layoutDate, getHistoryFilter().getClassTypes());
      CmdbDalCommandResult result = getEnd1Data.execute();
      datas = (CmdbDatas)result.getResult();
      if (datas != null) {
        Map endIDsToLayout = new HashMap(datas.size());
        ReadOnlyIterator datasIt = datas.getDatasIterator();
        while (datasIt.hasNext()) {
          CmdbData curData = (CmdbData)datasIt.next();
          endIDsToLayout.put(curData.getDataID(), curData);
        }
        setEnd1IDsToLayout(endIDsToLayout);
      }
    }
    return createHistoryChangesFromMap(changeIDChanges, changeIDsOrderByDate, simpleDataLayout);
  }

  private void runSelectForIDs(List<Long> changeIDsOrderByDate, Map<Long, AbstractHistoryDalQueryHistoryChanges<RESULT>.DataChanges> changeIDChanges, StringBuilder idsInCondition, StringBuilder end1IdsInCondition, CmdbCollection idsLeft, int numOfIDs, SimpleDataLayout simpleDataLayout)
    throws SQLException
  {
    runQueryForEventsTable(changeIDsOrderByDate, changeIDChanges, idsInCondition, end1IdsInCondition, idsLeft, numOfIDs);

    if ((((simpleDataLayout.isAllKeys()) || (simpleDataLayout.size() > 0))) && (!(changeIDChanges.isEmpty())))
    {
      List attrFilter = getAttrListForFilter(simpleDataLayout);
      if (useTempTable(changeIDsOrderByDate.size())) {
        createAndFillChangeIDTempTable(changeIDsOrderByDate);
        runQueryForInfoTable(changeIDsOrderByDate, changeIDChanges, attrFilter, createInSqlStringForTempTable(CHANGE_ID_TEMP_TABLE_NAME, HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME, "i", HISTORY_INFO_CHANGE_ID_COLUMN_NAME), 0, 0);
      }
      else {
        int startIndex = 0;
        int maxIDsInChunk = getMaxPossibleSizeForInChunk();
        int numOfChunks = calcNumOfInChunks(changeIDsOrderByDate.size());
        for (int chunkNum = 0; chunkNum < numOfChunks; ++chunkNum) {
          int changeIDsLeftSize = changeIDsOrderByDate.size() - startIndex;
          int numOfChangeIDs = (changeIDsLeftSize > maxIDsInChunk) ? maxIDsInChunk : changeIDsLeftSize;
          runQueryForInfoTable(changeIDsOrderByDate, changeIDChanges, attrFilter, createInSqlString(numOfChangeIDs, "i", HISTORY_INFO_CHANGE_ID_COLUMN_NAME), startIndex, numOfChangeIDs);
          startIndex += numOfChangeIDs;
        }
      }
    }
  }

  private void runQueryForInfoTable(List<Long> changeIDsOrderByDate, Map<Long, AbstractHistoryDalQueryHistoryChanges<RESULT>.DataChanges> changeIDChanges, List<String> attrFilter, StringBuilder changeIDsInCondition, int startIndex, int numOfChangeIDs) throws SQLException
  {
    for (Iterator i$ = CMDB_TYPE_TO_HISTORY_INFO.keySet().iterator(); i$.hasNext(); ) { Object o = (CmdbType)i$.next();
      CmdbType cmdbType = (CmdbType)o;
      String tableName = (String)CMDB_TYPE_TO_HISTORY_INFO.get(cmdbType);

      StringBuilder selectQuery = new StringBuilder("select i.").append(HISTORY_INFO_CHANGE_ID_COLUMN_NAME).append(",i.").append(HISTORY_INFO_ATTR_ID_COLUMN_NAME).append(",i.").append(HISTORY_INFO_ATTR_VALUE_COLUMN_NAME);

      StringBuilder fromQuery = new StringBuilder(" from ").append(tableName).append(" i");
      StringBuilder whereQuery = new StringBuilder(" where ").append(changeIDsInCondition).append(getCustomizeWhereClauseForInfoQuery(attrFilter));

      StringBuilder sqlQuery = new StringBuilder().append(selectQuery).append(fromQuery).append(whereQuery);
      CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(sqlQuery.toString());

      if (numOfChangeIDs > 0)
        for (int i = startIndex; i < numOfChangeIDs; ++i)
          preparedStatement.setLong((Long)changeIDsOrderByDate.get(i));


      fillCustomPreparedStatementForInfoQuery(preparedStatement, attrFilter);

      CmdbDalResultSet resultSet = preparedStatement.executeQuery();
      analyzeInfoQueryResultSet(resultSet, changeIDChanges, cmdbType);
      resultSet.close();
      preparedStatement.close();
    }
  }

  private void analyzeInfoQueryResultSet(CmdbDalResultSet resultSet, Map<Long, AbstractHistoryDalQueryHistoryChanges<RESULT>.DataChanges> changeIDChanges, CmdbType cmdbType) throws SQLException {
    PropertyCreator propCreator = PropertyCreatorFactory.create();
    while (resultSet.next()) {
      Long changeID = resultSet.getLong(HISTORY_INFO_CHANGE_ID_COLUMN_NAME);
      String attrName = resultSet.getString(HISTORY_INFO_ATTR_ID_COLUMN_NAME);
      Object attrValue = DalTypeUtil.getObject(resultSet, HISTORY_INFO_ATTR_VALUE_COLUMN_NAME, cmdbType, MAX_BYTES_SIZE);
      DataChanges dataChanges = (DataChanges)changeIDChanges.get(changeID);
      if (dataChanges != null) {
        CmdbProperty prop = propCreator.createProperty(cmdbType, attrName, attrValue);
        dataChanges.addProperty(prop);
      }
    }
  }

  private void fillCustomPreparedStatementForInfoQuery(CmdbDalPreparedStatement preparedStatement, List<String> attrFilter)
    throws SQLException
  {
    for (Iterator i$ = attrFilter.iterator(); i$.hasNext(); ) { String anAttrFilter = (String)i$.next();
      preparedStatement.setString(anAttrFilter);
    }
  }

  protected StringBuilder getCustomizeWhereClauseForInfoQuery(List<String> attrFilter)
  {
    StringBuilder whereQuery = new StringBuilder();
    if (!(attrFilter.isEmpty()))
      whereQuery.append(" and ").append(HISTORY_INFO_ATTR_ID_COLUMN_NAME).append(createInSqlString(attrFilter.size()));

    return whereQuery; }

  protected void createAndFillChangeIDTempTable(List<Long> changeIDs) throws SQLException {
    createChangeIDTempTable();
    fillChangeIDTempTable(getConnection(), changeIDs);
  }

  private void createChangeIDTempTable() {
    List columnsData = new ArrayList();
    if (getConnectionPool().isUsingOracleDB()) {
      columnsData.add(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME + " NUMBER(22, 0)");
      columnsData.add("T_VALUES_INDEX NUMBER");
    }
    else {
      columnsData.add(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME + " NUMERIC(22, 0)");
      columnsData.add("T_VALUES_INDEX numeric");
    }

    HistoryDalCreateOrTruncateTempTableComplexCommand tempTable = new HistoryDalCreateOrTruncateTempTableComplexCommand(CHANGE_ID_TEMP_TABLE_NAME, columnsData, HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME);
    tempTable.execute();
  }

  private void fillChangeIDTempTable(CmdbDalConnection connection, List<Long> changeIDs) throws SQLException {
    if (changeIDs.size() > 0)
    {
      String sqlString;
      if (getConnectionPool().isUsingOracleDB()) {
        sqlString = "insert into " + CHANGE_ID_TEMP_TABLE_NAME + " values(?,?)";
      }
      else if (getConnectionPool().isUsingMSSqlDB()) {
        sqlString = "insert into #" + CHANGE_ID_TEMP_TABLE_NAME + " values(?,?)";
      }
      else {
        throw new CmdbDalException("Unknown db type !!!");
      }

      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);
      for (Iterator i$ = changeIDs.iterator(); i$.hasNext(); ) { Long changeID = (Long)i$.next();
        preparedStatement.setLong(changeID);
        preparedStatement.setInt(0);
        preparedStatement.addBatch();
      }
      preparedStatement.executeBatch();
      preparedStatement.close();
    }
  }

  private void runQueryForEventsTable(List<Long> changeIDsOrderByDate, Map<Long, AbstractHistoryDalQueryHistoryChanges<RESULT>.DataChanges> changeIDChanges, StringBuilder idsInCondition, StringBuilder end1IdsInCondition, CmdbCollection idsLeft, int numOfIDs)
    throws SQLException
  {
    StringBuilder queryHistEvents = getQueryForEventsTablePart1(idsInCondition);
    if (useUnion())
      queryHistEvents.append(" union ").append(getQueryForEventsTablePart2(end1IdsInCondition));

    queryHistEvents.append(" order by 2");

    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(queryHistEvents.toString());

    List variables = new ArrayList(numOfIDs);
    addIdsToInList(idsLeft, variables, numOfIDs);
    fillPreparedStatementForEventsTablePart1(preparedStatement, numOfIDs, variables);
    if (useUnion()) {
      fillPreparedStatementForEventsTablePart2(preparedStatement, numOfIDs, variables);
    }

    CmdbDalResultSet resultSet = preparedStatement.executeQuery();
    analyzeEventsQueryResultSet(resultSet, changeIDChanges, changeIDsOrderByDate);
    resultSet.close();
    preparedStatement.close();
  }

  private void analyzeEventsQueryResultSet(CmdbDalResultSet resultSet, Map<Long, AbstractHistoryDalQueryHistoryChanges<RESULT>.DataChanges> changeIDChanges, List<Long> changeIDsOrderByDate)
    throws SQLException
  {
    while (resultSet.next()) {
      Long changeID = resultSet.getLong(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME);

      Date changeTime = null;
      String changerInfo = null;
      String changerType = null;
      Boolean isObject = resultSet.getBoolean(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME);
      byte[] idAsBytes = resultSet.getBytes(HISTORY_CHANGES_CI_ID_COLUMN_NAME);
      if (shouldGetChangeDate())
        changeTime = resultSet.getDate(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME);

      String changeType = resultSet.getString(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME);
      if (shouldGetChanger()) {
        changerInfo = resultSet.getString(HISTORY_CHANGES_CHANGER_INFO_COLUMN_NAME);
        changerType = resultSet.getString(HISTORY_CHANGES_CHANGER_TYPE_COLUMN_NAME);
      }
      String type = resultSet.getString(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME);
      byte[] end1IdAsBytes = resultSet.getBytes(HISTORY_CHANGES_END1_COLUMN_NAME);
      byte[] end2IdAsBytes = resultSet.getBytes(HISTORY_CHANGES_END2_COLUMN_NAME);
      CmdbObjectID end1ID = null;
      CmdbObjectID end2ID = null;
      byte[] linkID = null;
      if (!(isObject.booleanValue())) {
        end1ID = CmdbObjectID.Factory.restoreObjectID(end1IdAsBytes);
        end2ID = CmdbObjectID.Factory.restoreObjectID(end2IdAsBytes);
        getEnd1IDs().add(end1ID);
        getEnd2IDs().add(end2ID);
        linkID = idAsBytes;
        idAsBytes = end1IdAsBytes;
      }
      DataChanges dataChanges = new DataChanges(this, end1ID, end2ID, linkID, idAsBytes, isObject, type, changeType, changerInfo, changerType, changeTime, changeID);
      changeIDChanges.put(changeID, dataChanges);
      changeIDsOrderByDate.add(changeID);
    }
  }

  private StringBuilder getQueryForEventsTablePart1(StringBuilder idsInCondition)
  {
    StringBuilder queryHistEvents = getSelectAndFromForEventsTable();
    queryHistEvents.append(" where e.").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?");
    if ((idsInCondition != null) && (idsInCondition.length() > 0))
      queryHistEvents.append(" and ").append(idsInCondition);

    queryHistEvents.append(getCustomizeWhereClauseForEventsQueryPart1());
    return queryHistEvents;
  }

  private StringBuilder getSelectAndFromForEventsTable()
  {
    StringBuilder queryHistEvents = new StringBuilder("select e.").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_END1_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_END2_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME);

    if (shouldGetChangeDate())
      queryHistEvents.append(",e.").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME);

    if (shouldGetChanger()) {
      queryHistEvents.append(",e.").append(HISTORY_CHANGES_CHANGER_INFO_COLUMN_NAME).append(",e.").append(HISTORY_CHANGES_CHANGER_TYPE_COLUMN_NAME);
    }

    queryHistEvents.append(" from ").append(HISTORY_CHANGES_TABLE_NAME).append(" e");
    return queryHistEvents;
  }

  protected StringBuilder getCustomizeWhereClauseForEventsQueryPart1()
  {
    StringBuilder whereQuery = new StringBuilder();
    if (getHistoryFilter().getChanger() != null) {
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGER_INFO_COLUMN_NAME).append("=?");
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGER_TYPE_COLUMN_NAME).append("=?");
    }
    if (getHistoryFilter().getFromDate() != null)
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(">?");

    if (getHistoryFilter().getToDate() != null)
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<=?");

    if ((getHistoryFilter().getChangeTypes() != null) && (getHistoryFilter().getChangeTypes().length > 0))
      whereQuery.append(" and ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append(createInSqlString(getHistoryFilter().getChangeTypes().length));

    return whereQuery;
  }

  private StringBuilder getQueryForEventsTablePart2(StringBuilder idsInCondition)
  {
    StringBuilder queryHistEvents = getSelectAndFromForEventsTable();
    queryHistEvents.append(" where e.").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?");
    if ((idsInCondition != null) && (idsInCondition.length() > 0))
      queryHistEvents.append(" and ").append(idsInCondition);

    queryHistEvents.append(getCustomizeWhereClauseForEventsQueryPart2());
    return queryHistEvents;
  }

  protected StringBuilder getCustomizeWhereClauseForEventsQueryPart2()
  {
    StringBuilder whereQuery = new StringBuilder(" and (").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append("=? or ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append("=?)");

    if (getHistoryFilter().getChanger() != null) {
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGER_INFO_COLUMN_NAME).append("=?");
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGER_TYPE_COLUMN_NAME).append("=?");
    }
    if (getHistoryFilter().getFromDate() != null)
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(">?");

    if (getHistoryFilter().getToDate() != null)
      whereQuery.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<=?");

    return whereQuery;
  }

  private void fillPreparedStatementForEventsTablePart1(CmdbDalPreparedStatement preparedStatement, int numOfIDs, List variables)
    throws SQLException
  {
    preparedStatement.setInt(getCustomerID().getID());

    if (numOfIDs > 0) {
      fillPreparedStatementWithIDs(preparedStatement, variables);
    }

    fillCustomPreparedStatementForEventsQueryPart1(preparedStatement);
  }

  private void fillPreparedStatementForEventsTablePart2(CmdbDalPreparedStatement preparedStatement, int numOfIDs, List variables)
    throws SQLException
  {
    preparedStatement.setInt(getCustomerID().getID());

    if (numOfIDs > 0) {
      fillPreparedStatementWithIDs(preparedStatement, variables);
    }

    preparedStatement.setString(ChangeType.ADD_LINK.getType());
    preparedStatement.setString(ChangeType.REMOVE_LINK.getType());
    fillCustomPreparedStatementForEventsQueryPart2(preparedStatement);
  }

  protected void fillCustomPreparedStatementForEventsQueryPart1(CmdbDalPreparedStatement preparedStatement)
    throws SQLException
  {
    if (getHistoryFilter().getChanger() != null) {
      preparedStatement.setString(getHistoryFilter().getChanger().getChangerInfo());
      preparedStatement.setString(getHistoryFilter().getChanger().getDataStoreOrigin());
    }

    if (getHistoryFilter().getFromDate() != null) {
      preparedStatement.setDate(getHistoryFilter().getFromDate());
    }

    if (getHistoryFilter().getToDate() != null) {
      preparedStatement.setDate(getHistoryFilter().getToDate());
    }

    if ((getHistoryFilter().getChangeTypes() != null) && (getHistoryFilter().getChangeTypes().length > 0))
      for (int i = 0; i < getHistoryFilter().getChangeTypes().length; ++i)
        preparedStatement.setString(getHistoryFilter().getChangeTypes()[i].getType());
  }

  protected void fillCustomPreparedStatementForEventsQueryPart2(CmdbDalPreparedStatement preparedStatement)
    throws SQLException
  {
    if (getHistoryFilter().getChanger() != null) {
      preparedStatement.setString(getHistoryFilter().getChanger().getChangerInfo());
      preparedStatement.setString(getHistoryFilter().getChanger().getDataStoreOrigin());
    }
    if (getHistoryFilter().getFromDate() != null)
      preparedStatement.setDate(getHistoryFilter().getFromDate());

    if (getHistoryFilter().getToDate() != null)
      preparedStatement.setDate(getHistoryFilter().getToDate());  } 
  protected abstract void createIDTempTable() throws SQLException;

  protected abstract StringBuilder createInSqlStringForIdTempTable();

  protected abstract StringBuilder createInSqlStringForEnd1IdTempTable();

  protected abstract CmdbCollection getFilterIDs();

  protected abstract void addIdsToInList(CmdbCollection<CmdbDataID> paramCmdbCollection, List<Object> paramList, int paramInt);

  protected abstract void fillPreparedStatementWithIDs(CmdbDalPreparedStatement paramCmdbDalPreparedStatement, List paramList) throws SQLException;

  protected abstract HistoryDatas createHistoryChangesFromMap(Map<Long, AbstractHistoryDalQueryHistoryChanges<RESULT>.DataChanges> paramMap, List<Long> paramList, SimpleDataLayout paramSimpleDataLayout);

  protected abstract CmdbCollection<CmdbDataID> copyIDs(CmdbCollection<CmdbDataID> paramCmdbCollection, int paramInt);

  protected abstract StringBuilder createInSqlStringForIdColumn(StringBuilder paramStringBuilder);

  protected abstract StringBuilder createInSqlStringForEnd1IdColumn(StringBuilder paramStringBuilder);

  protected abstract boolean useUnion();

  protected abstract boolean shouldGetChanger();

  protected abstract boolean shouldGetChangeDate();

  protected abstract boolean shouldGetEnd2Info();

  protected abstract boolean shouldGetPrevValue();

  protected class DataChanges { String _changeType;
    String _changerInfo;
    String _changerType;
    byte[] _idAsBytes;
    boolean _isObject;
    String _type;
    byte[] _linkID;
    CmdbObjectID _end1Id;
    CmdbObjectID _end2Id;
    CmdbProperties _properties;
    Date _changeDate;
    Long _changeId;

    public DataChanges(, CmdbObjectID paramCmdbObjectID1, CmdbObjectID paramCmdbObjectID2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, Boolean paramBoolean, String paramString1, String paramString2, String paramString3, String paramString4, Date paramDate, Long paramLong) { setEnd1Id(paramCmdbObjectID1);
      setEnd2Id(paramCmdbObjectID2);
      setIdAsBytes(paramArrayOfByte2);
      setIsObject(paramBoolean.booleanValue());
      setType(type);
      setChangeType(paramString2);
      setChangerInfo(paramString3);
      setChangeDate(paramDate);
      setChangerType(paramString4);
      setChangeId(paramLong);
      setLinkID(paramArrayOfByte1);
    }

    public Long getChangeId() {
      return this._changeId;
    }

    public void setChangeId() {
      this._changeId = changeId;
    }

    public CmdbDataID getDataID() {
      return CmdbObjectID.Factory.restoreObjectID(getIdAsBytes());
    }

    public HistoryChange createHistoryChangeFromChanges() {
      CmdbObject object;
      Changer changer = null;
      HistoryChange historyChange = null;

      if (this.this$0.shouldGetChanger()) {
        changer = ChangerFactory.createChanger(getChangerType(), getChangerInfo());
      }

      if (isObject()) {
        CmdbProperties previousValues = null;
        if (this.this$0.shouldGetPrevValue()) {
          ReadOnlyIterator it;
          CmdbProperty curProp;
          previousValues = CmdbPropertyFactory.createProperties();

          if (getProperties() != null) {
            it = getProperties().getPropertiesIterator();
            while (it.hasNext()) {
              curProp = (CmdbProperty)it.next();
              if (oldProperties.contains(curProp.getKey()))
                previousValues.add(oldProperties.get(curProp.getKey()));

              oldProperties.add(curProp);
            }
          }
          else {
            it = oldProperties.getPropertiesIterator();
            while (it.hasNext()) {
              curProp = (CmdbProperty)it.next();
              previousValues.add(curProp);
            }
          }
        }

        if (getChangeType().equals(ChangeConstants.CHANGE_TYPES.REMOVE_OBJECT)) {
          setProperties(CmdbPropertyFactory.createProperties());
          getProperties().add(CmdbPropertyFactory.createEmptyProperty(HistoryConstants.ATTRIBUTES.REMOVED, CmdbSimpleTypes.CmdbString));
        }

        CmdbObjectID id = CmdbObjectID.Factory.restoreObjectID(getIdAsBytes());
        object = CmdbObjectFactory.createObject(id, getType(), getProperties());

        HistoryObjectChangeInfo info = HistoryChangeInfoFactory.createObjectChangeInfo(getChangeId(), object);
        if (this.this$0.shouldGetChangeDate())
          info.setChangeTime(getChangeDate());

        if (this.this$0.shouldGetChanger())
          info.setChanger(changer);

        if (this.this$0.shouldGetPrevValue())
          info.setPreviousValues(previousValues);

        historyChange = ObjectHistoryChangeFactory.createObjectHistoryChange(info, getChangeType());
      }
      else {
        CmdbData end1Data = (AbstractHistoryDalQueryHistoryChanges.access$000(this.this$0) != null) ? (CmdbData)AbstractHistoryDalQueryHistoryChanges.access$000(this.this$0).get(getEnd1Id()) : null;
        CmdbData end2Data = (AbstractHistoryDalQueryHistoryChanges.access$100(this.this$0) != null) ? (CmdbData)AbstractHistoryDalQueryHistoryChanges.access$100(this.this$0).get(getEnd2Id()) : null;
        object = null;
        CmdbProperties layoutProps = null;

        if ((this.this$0.shouldGetEnd2Info()) && (end1Data != null) && (end2Data != null))
        {
          StringBuilder attrValue = new StringBuilder();
          String end2DisplayLabel = "";
          CmdbProperty displayLabel = end2Data.getProperty(HistoryConstants.ATTRIBUTES.DISPLAY_LABEL);
          if ((displayLabel != null) && (displayLabel.getValue() != null) && (!(displayLabel.isValueEmpty()))) {
            end2DisplayLabel = (String)displayLabel.getValue();
            attrValue.append(end2DisplayLabel);
          }
          attrValue.append("(").append(end2Data.getType()).append(")");

          String propName = "";
          if (getChangeType().equals(ChangeConstants.CHANGE_TYPES.ADD_LINK)) {
            propName = HistoryConstants.ATTRIBUTES.ADDED_CI;
          }
          else if (getChangeType().equals(ChangeConstants.CHANGE_TYPES.REMOVE_LINK))
            propName = HistoryConstants.ATTRIBUTES.REMOVED_CI;

          CmdbProperty prop = CmdbPropertyFactory.createProperty(propName, attrValue.toString());
          CmdbProperties props = CmdbPropertyFactory.createProperties();
          props.add(prop);

          object = CmdbObjectFactory.createObject(getEnd1Id(), end1Data.getType(), props);

          layoutProps = CmdbPropertyFactory.createProperties();
          layoutProps.add(CmdbPropertyFactory.createProperty(HistoryConstants.ATTRIBUTES.END2_ID, AbstractHistoryDalQueryHistoryChanges.access$200(getEnd2Id())));
          layoutProps.add(CmdbPropertyFactory.createProperty(HistoryConstants.ATTRIBUTES.LINK_TYPE, getType()));
          layoutProps.add(CmdbPropertyFactory.createProperty(HistoryConstants.ATTRIBUTES.LINK_ID, getLinkID()));
          layoutProps.add(CmdbPropertyFactory.createProperty(HistoryConstants.ATTRIBUTES.END2_DISPLAY_LABEL, end2DisplayLabel));
          layoutProps.add(CmdbPropertyFactory.createProperty(HistoryConstants.ATTRIBUTES.END2_TYPE, end2Data.getType()));
        }
        else if ((!(this.this$0.shouldGetEnd2Info())) && (end1Data != null))
        {
          object = CmdbObjectFactory.createObject(getEnd1Id(), end1Data.getType());
        }
        else if (AbstractHistoryDalQueryHistoryChanges.access$300().isDebugEnabled()) {
          AbstractHistoryDalQueryHistoryChanges.access$400().debug("didn't create a history relation change because one of the link's ends is missing in the History DB or is filtered by end2 type filter. end1ID:" + getEnd1Id() + " end2ID:" + getEnd2Id());
        }

        if (object != null)
        {
          HistoryObjectChangeInfo info = HistoryChangeInfoFactory.createObjectChangeInfo(getChangeId(), object);
          if (this.this$0.shouldGetChangeDate())
            info.setChangeTime(getChangeDate());

          if (this.this$0.shouldGetChanger())
            info.setChanger(changer);

          if (layoutProps != null) {
            info.setLayoutProperties(layoutProps);
          }

          if (getChangeType().equals(ChangeConstants.CHANGE_TYPES.ADD_LINK)) {
            historyChange = ObjectHistoryChangeFactory.createHistoryChangeAddRelation(info);
          }
          else if (getChangeType().equals(ChangeConstants.CHANGE_TYPES.REMOVE_LINK))
            historyChange = ObjectHistoryChangeFactory.createHistoryChangeRemoveRelation(info);
        }
      }

      return historyChange;
    }

    public void addProperty() {
      if (getProperties() == null)
        setProperties(CmdbPropertyFactory.createProperties());

      getProperties().add(prop);
    }

    protected Date getChangeDate() {
      return this._changeDate;
    }

    private void setChangeDate() {
      this._changeDate = changeDate;
    }

    private String getChangerInfo() {
      return this._changerInfo;
    }

    private void setChangerInfo() {
      this._changerInfo = changerInfo;
    }

    protected String getChangeType() {
      return this._changeType;
    }

    private void setChangeType() {
      this._changeType = changeType;
    }

    protected CmdbProperties getProperties() {
      return this._properties;
    }

    private void setProperties() {
      this._properties = properties;
    }

    private CmdbObjectID getEnd1Id() {
      return this._end1Id;
    }

    private void setEnd1Id() {
      this._end1Id = end1Id;
    }

    private CmdbObjectID getEnd2Id() {
      return this._end2Id;
    }

    private void setEnd2Id() {
      this._end2Id = end2Id;
    }

    private byte[] getIdAsBytes() {
      return this._idAsBytes;
    }

    private void setIdAsBytes() {
      this._idAsBytes = idAsBytes;
    }

    private byte[] getLinkID() {
      return this._linkID;
    }

    private void setLinkID() {
      this._linkID = linkID;
    }

    private boolean isObject() {
      return this._isObject;
    }

    private void setIsObject() {
      this._isObject = object;
    }

    private String getType() {
      return this._type;
    }

    private void setType() {
      this._type = type;
    }

    private String getChangerType() {
      return this._changerType;
    }

    private void setChangerType() {
      this._changerType = changerType;
    }
  }
}