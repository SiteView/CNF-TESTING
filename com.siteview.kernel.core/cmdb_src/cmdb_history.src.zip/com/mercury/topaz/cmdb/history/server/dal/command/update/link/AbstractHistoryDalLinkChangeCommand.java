package com.mercury.topaz.cmdb.history.server.dal.command.update.link;

import com.mercury.topaz.cmdb.history.server.dal.command.update.AbstractHistoryDalAddChangeCommand;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Date;

public abstract class AbstractHistoryDalLinkChangeCommand extends AbstractHistoryDalAddChangeCommand<CmdbLink>
{
  private CmdbLinks _links;

  public AbstractHistoryDalLinkChangeCommand(Changer changer, Date changeDate, CmdbLinks links)
  {
    super(changer, changeDate);
    setLinks(links);
  }

  public AbstractHistoryDalLinkChangeCommand(Changer changer, Date changeDate, CmdbLink link) {
    super(changer, changeDate);
    CmdbLinks links = CmdbLinkFactory.createLinks();
    links.add(link);
    setLinks(links);
  }

  protected CmdbLinks getLinks() {
    return this._links;
  }

  private void setLinks(CmdbLinks links) {
    this._links = links;
  }

  protected CmdbDataID getEnd1(CmdbLink data) {
    return data.getEnd1();
  }

  protected CmdbDataID getEnd2(CmdbLink data) {
    return data.getEnd2();
  }

  protected boolean isObject() {
    return false;
  }

  protected ReadOnlyIterator<CmdbLink> getDatasIterator() {
    return getLinks().getLinksIterator();
  }
}