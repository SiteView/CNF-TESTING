package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;

public class HistoryQueryGetIdsByHistoryFilter extends AbstractHistoryQueryOperation
{
  private transient CmdbIDsCollection result;
  private HistoryFilter filter;

  public HistoryQueryGetIdsByHistoryFilter(HistoryFilter filter)
  {
    this.filter = filter;
  }

  public String getOperationName() {
    return "History Query: Get Ids by History Filter";
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException {
    this.result = historyQueryManager.getIDsByHistoryFilter(this.filter);
    response.addResult(getClass().getName(), this.result);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    this.result = ((CmdbIDsCollection)response.getResult(getClass().getName()));
  }

  public CmdbIDsCollection getResult() {
    return this.result;
  }
}