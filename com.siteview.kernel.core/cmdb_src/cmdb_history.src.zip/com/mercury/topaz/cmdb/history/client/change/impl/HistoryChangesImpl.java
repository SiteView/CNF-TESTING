package com.mercury.topaz.cmdb.history.client.change.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryChange;
import com.mercury.topaz.cmdb.history.client.change.HistoryChanges;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.EmptyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.util.ArrayList;

public class HistoryChangesImpl extends ArrayList
  implements HistoryChanges
{
  public ReadOnlyIterator getChangesIterator()
  {
    if (isEmpty())
      return EmptyIterator.getInstance();

    return new ReadOnlyIteratorImpl(iterator());
  }

  public void add(HistoryChange historyChange)
  {
    if (historyChange == null)
      throw new IllegalArgumentException("Attempt to append null historyChange ");

    super.add(historyChange);
  }
}