package com.mercury.topaz.cmdb.history.client.change.link;

import com.mercury.topaz.cmdb.history.client.change.impl.AbstractHistoryChange;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryLinkChangeInfo;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;

public abstract class AbstractLinkHistoryChange extends AbstractHistoryChange
{
  private HistoryLinkChangeInfo _historyLinkChangeInfo;

  public AbstractLinkHistoryChange(HistoryLinkChangeInfo historyLinkChangeInfo)
  {
    setHistoryLinkChangeInfo(historyLinkChangeInfo);
  }

  protected HistoryLinkChangeInfo getHistoryLinkChangeInfo() {
    return this._historyLinkChangeInfo;
  }

  private void setHistoryLinkChangeInfo(HistoryLinkChangeInfo historyLinkChangeInfo) {
    this._historyLinkChangeInfo = historyLinkChangeInfo;
  }

  public HistoryChangeInfo getChangeInfo() {
    return getHistoryLinkChangeInfo();
  }

  public CmdbDataID getCiID() {
    return ((CmdbDataID)getHistoryLinkChangeInfo().getCmdbLink().getID());
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (getClass() != o.getClass())) {
      return false;
    }

    AbstractLinkHistoryChange that = (AbstractLinkHistoryChange)o;

    if (this._historyLinkChangeInfo != null) if (this._historyLinkChangeInfo.equals(that._historyLinkChangeInfo))
        break label62;
    label62: return (that._historyLinkChangeInfo == null);
  }

  public int hashCode()
  {
    return ((this._historyLinkChangeInfo != null) ? this._historyLinkChangeInfo.hashCode() : 0);
  }
}