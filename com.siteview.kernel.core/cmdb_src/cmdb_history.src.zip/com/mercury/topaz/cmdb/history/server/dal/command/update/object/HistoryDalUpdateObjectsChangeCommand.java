package com.mercury.topaz.cmdb.history.server.dal.command.update.object;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import java.util.Date;

public class HistoryDalUpdateObjectsChangeCommand extends AbstractHistoryDalObjectChangeCommand
{
  private static String EVENT_TYPE = ChangeConstants.CHANGE_TYPES.UPDATE_OBJECT;

  public HistoryDalUpdateObjectsChangeCommand(Changer changer, Date changeDate, CmdbObject object)
  {
    super(changer, changeDate, object);
  }

  public HistoryDalUpdateObjectsChangeCommand(Changer changer, Date changeDate, CmdbObjects objects) {
    super(changer, changeDate, objects);
  }

  protected String getEventType() {
    return EVENT_TYPE;
  }

  protected boolean shouldSaveChange() {
    return false;
  }
}