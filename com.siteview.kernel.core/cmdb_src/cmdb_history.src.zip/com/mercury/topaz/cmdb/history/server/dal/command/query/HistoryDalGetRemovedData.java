package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeType;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.impl.DataLayoutFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.data.impl.CmdbDatasFactory;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID.Factory;
import com.mercury.topaz.cmdb.shared.model.link.impl.CmdbLinkFactory;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import org.apache.commons.collections.MultiHashMap;
import org.apache.commons.collections.MultiMap;

public class HistoryDalGetRemovedData extends AbstractHistoryDalQueryCommand<CmdbDatas<CmdbDataID, CmdbData>>
{
  private HistoryFilter _historyFilter;

  public HistoryDalGetRemovedData(HistoryFilter historyFilter)
  {
    setHistoryFilter(historyFilter);
  }

  protected CmdbDatas<CmdbDataID, CmdbData> perform() throws Exception
  {
    CmdbDatas datas;
    MultiMap idsToDatesMap = new MultiHashMap();
    CmdbDataIDs dataIDs = CmdbDataIdsFactory.create();

    CmdbDatas foundDatas = runEventsQuery(dataIDs, idsToDatesMap);
    if (dataIDs.size() > 0)
    {
      HistoryDalGetDataLayoutInDifferentDatesCommand getLayout = new HistoryDalGetDataLayoutInDifferentDatesCommand(idsToDatesMap, dataIDs, DataLayoutFactory.createFullDataLayout());
      CmdbDalCommandResult result = getLayout.execute();
      datas = (CmdbDatas)result.getResult();

      if ((datas != null) && (datas.size() > 0))
      {
        Set tempDataIDs = new HashSet(datas.size());
        ReadOnlyIterator it = datas.getDatasIterator();
        while (it.hasNext()) {
          CmdbData curData = (CmdbData)it.next();
          tempDataIDs.add(curData.getDataID());
        }

        ReadOnlyIterator foundDatasIt = foundDatas.getDatasIterator();
        while (foundDatasIt.hasNext()) {
          CmdbData curData = (CmdbData)foundDatasIt.next();
          if (!(tempDataIDs.contains(curData.getDataID())))
            datas.add(curData);
        }
      }
      else {
        datas = foundDatas;
      }
    } else {
      datas = foundDatas;
    }
    return datas;
  }

  protected void validateInput()
  {
  }

  private CmdbDatas runEventsQuery(CmdbDataIDs dataIDs, MultiMap idsToDates) throws SQLException
  {
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(getEventsQuery());

    preparedStatement = fillEventsPreparedStatement(preparedStatement);

    CmdbDalResultSet resultSet = preparedStatement.executeQuery();
    return analyzeEventsResultSet(resultSet, idsToDates, dataIDs);
  }

  private String getEventsQuery() {
    StringBuilder query = new StringBuilder("select ").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME).append(",").append(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME).append(",").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(",").append(HISTORY_CHANGES_END1_COLUMN_NAME).append(",").append(HISTORY_CHANGES_END2_COLUMN_NAME).append(",").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(" from ").append(HISTORY_CHANGES_TABLE_NAME).append(" where ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=? and ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append(" in (?,?)");

    if (getHistoryFilter().getFromDate() != null)
      query.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(">?");

    if (getHistoryFilter().getToDate() != null)
      query.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<=?");

    if ((getHistoryFilter().getClassTypes() != null) && (getHistoryFilter().getClassTypes().length > 0))
      query.append(" and ").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(createInSqlString(getHistoryFilter().getClassTypes().length));

    return query.toString();
  }

  private CmdbDalPreparedStatement fillEventsPreparedStatement(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    preparedStatement.setInt(getCustomerID().getID());

    preparedStatement.setString(ChangeType.REMOVE_OBJECT.getType());
    preparedStatement.setString(ChangeType.REMOVE_LINK.getType());

    if (getHistoryFilter().getFromDate() != null)
      preparedStatement.setDate(getHistoryFilter().getFromDate());

    if (getHistoryFilter().getToDate() != null)
      preparedStatement.setDate(getHistoryFilter().getToDate());

    if ((getHistoryFilter().getClassTypes() != null) && (getHistoryFilter().getClassTypes().length > 0))
      for (int i = 0; i < getHistoryFilter().getClassTypes().length; ++i)
        preparedStatement.setString(getHistoryFilter().getClassTypes()[i]);


    return preparedStatement;
  }

  private CmdbDatas analyzeEventsResultSet(CmdbDalResultSet resultSet, MultiMap idsToDates, CmdbDataIDs dataIDs) throws SQLException {
    CmdbDatas datas = CmdbDatasFactory.create();
    while (resultSet.next()) {
      CmdbDataID id;
      Boolean isObject = resultSet.getBoolean(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME);
      byte[] idAsBytes = resultSet.getBytes(HISTORY_CHANGES_CI_ID_COLUMN_NAME);
      Date removeTime = resultSet.getDate(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME);

      if (isObject.booleanValue()) {
        id = CmdbObjectID.Factory.restoreObjectID(idAsBytes);
      } else {
        id = CmdbLinkID.Factory.restoreLinkID(idAsBytes);

        String type = resultSet.getString(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME);
        byte[] end1IdAsBytes = resultSet.getBytes(HISTORY_CHANGES_END1_COLUMN_NAME);
        byte[] end2IdAsBytes = resultSet.getBytes(HISTORY_CHANGES_END2_COLUMN_NAME);
        CmdbLink curLink = createCmdbLink((CmdbLinkID)id, end1IdAsBytes, end2IdAsBytes, type);
        datas.add(curLink);
      }
      dataIDs.add(id);
      idsToDates.put(id, removeTime);
    }
    resultSet.close();
    return datas;
  }

  private CmdbLink createCmdbLink(CmdbLinkID id, byte[] end1IdAsBytes, byte[] end2IdAsBytes, String type) {
    return CmdbLinkFactory.createLink(id, CmdbObjectID.Factory.restoreObjectID(end1IdAsBytes), CmdbObjectID.Factory.restoreObjectID(end2IdAsBytes), type);
  }

  private HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    this._historyFilter = historyFilter;
  }
}