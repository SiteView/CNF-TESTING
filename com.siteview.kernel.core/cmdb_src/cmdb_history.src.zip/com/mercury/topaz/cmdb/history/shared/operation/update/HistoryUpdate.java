package com.mercury.topaz.cmdb.history.shared.operation.update;

import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.history.shared.operation.HistoryOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract interface HistoryUpdate extends HistoryOperation
{
  public abstract void historyUpdateExecute(HistoryUpdateManager paramHistoryUpdateManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}