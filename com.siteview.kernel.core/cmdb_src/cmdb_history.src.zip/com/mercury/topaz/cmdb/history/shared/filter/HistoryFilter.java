package com.mercury.topaz.cmdb.history.shared.filter;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeType;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import java.io.Serializable;
import java.util.Date;

public abstract interface HistoryFilter extends Serializable
{
  public abstract Date getFromDate();

  public abstract Date getToDate();

  public abstract Changer getChanger();

  public abstract ChangeType[] getChangeTypes();

  public abstract String[] getClassTypes();

  public abstract boolean isRelationInFilter();

  public abstract boolean isChangeTypeInFilter(ChangeType paramChangeType);

  public abstract String[] getEnd2ClassTypes();
}