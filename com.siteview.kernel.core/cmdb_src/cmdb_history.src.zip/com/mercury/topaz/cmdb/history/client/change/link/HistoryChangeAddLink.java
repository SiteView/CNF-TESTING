package com.mercury.topaz.cmdb.history.client.change.link;

import com.mercury.topaz.cmdb.history.client.change.HistoryChangeVisitor;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryLinkChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.manage.HistoryChangeListenerFineGrained;

public class HistoryChangeAddLink extends AbstractLinkHistoryChange
{
  HistoryChangeAddLink(HistoryLinkChangeInfo historyLinkChangeInfo)
  {
    super(historyLinkChangeInfo);
  }

  public void accept(HistoryChangeVisitor historyChangeVisitor) {
    historyChangeVisitor.addDataChange(getHistoryLinkChangeInfo());
    historyChangeVisitor.addLinkChange(getHistoryLinkChangeInfo());
  }

  public void execute(HistoryChangeListenerFineGrained changeListener) {
    changeListener.onAddLink(getHistoryLinkChangeInfo());
  }

  public String toString() {
    return ChangeConstants.CHANGE_TYPES.ADD_LINK + ": " + super.toString();
  }
}