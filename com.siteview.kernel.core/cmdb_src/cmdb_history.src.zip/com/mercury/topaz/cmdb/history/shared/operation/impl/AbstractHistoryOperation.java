package com.mercury.topaz.cmdb.history.shared.operation.impl;

import com.mercury.topaz.cmdb.history.server.manager.HistoryManager;
import com.mercury.topaz.cmdb.history.shared.operation.HistoryOperation;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.impl.AbstractCmdbOperation;

public abstract class AbstractHistoryOperation extends AbstractCmdbOperation
  implements HistoryOperation
{
  protected final void doExecute(SubsystemManager manager, CmdbResponse response)
    throws CmdbException
  {
    historyExecute((HistoryManager)manager, response);
  }
}