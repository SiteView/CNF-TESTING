package com.mercury.topaz.cmdb.history.shared.listener;

import com.mercury.topaz.cmdb.history.shared.operation.update.impl.HistoryUpdateAddCmdbChanges;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.change.impl.AbstractCmdbChangeListener;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.change.manage.CmdbModelChangeListenerCorseGrained;

public class HistoryDBModelChangeListenerCorseGrained extends AbstractCmdbChangeListener
  implements CmdbModelChangeListenerCorseGrained
{
  public HistoryDBModelChangeListenerCorseGrained(CmdbCustomerID customerID)
  {
    super(FrameworkConstants.Subsystem.MODEL, customerID);
  }

  public void onChanges(CmdbChanges cmdbChanges) {
    HistoryUpdateAddCmdbChanges addChanges = new HistoryUpdateAddCmdbChanges(cmdbChanges);
    executeAsynchronousOperation(addChanges);
  }
}