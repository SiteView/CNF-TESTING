package com.mercury.topaz.cmdb.history.client.counter.impl;

import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesExtendedCounter;

public class HistoryChangesExtendedCounterFactory
{
  public static HistoryChangesExtendedCounter createHistoryChangesExtendedCounter()
  {
    return new HistoryChangesExtendedCounterImpl();
  }

  public static HistoryChangesExtendedCounter createHistoryChangesExtendedCounter(int addedCount, int updatedCount, int removedCount, int addedRelationCount, int removedRelationCount) {
    return new HistoryChangesExtendedCounterImpl(addedCount, updatedCount, removedCount, addedRelationCount, removedRelationCount);
  }
}