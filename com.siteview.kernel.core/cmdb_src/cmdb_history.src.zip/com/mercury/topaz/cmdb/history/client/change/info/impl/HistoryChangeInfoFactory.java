package com.mercury.topaz.cmdb.history.client.change.info.impl;

import com.mercury.topaz.cmdb.history.client.change.info.HistoryLinkChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import java.util.Date;

public class HistoryChangeInfoFactory
{
  public static HistoryObjectChangeInfo createObjectChangeInfo(Long changeId, CmdbObject cmdbObject)
  {
    return new HistoryObjectChangeInfoImpl(changeId, cmdbObject);
  }

  public static HistoryObjectChangeInfo createObjectChangeInfo(CmdbObject cmdbObject, Date changeTime, Changer changer) {
    return new HistoryObjectChangeInfoImpl(cmdbObject, changeTime, changer, CmdbPropertyFactory.createProperties(), CmdbPropertyFactory.createProperties());
  }

  public static HistoryObjectChangeInfo createObjectChangeInfo(CmdbObject cmdbObject, Date changeTime, Changer changer, CmdbProperties previousValues) {
    return new HistoryObjectChangeInfoImpl(cmdbObject, changeTime, changer, CmdbPropertyFactory.createProperties(), previousValues);
  }

  public static HistoryObjectChangeInfo createObjectChangeInfo(CmdbObject cmdbObject, Date changeTime, Changer changer, CmdbProperties previousValues, Long changeId) {
    return new HistoryObjectChangeInfoImpl(cmdbObject, changeTime, changer, CmdbPropertyFactory.createProperties(), previousValues, changeId);
  }

  public static HistoryObjectChangeInfo createObjectChangeInfoWithLayoutProperties(CmdbObject cmdbObject, Date changeTime, Changer changer, CmdbProperties layoutProperties) {
    return new HistoryObjectChangeInfoImpl(cmdbObject, changeTime, changer, layoutProperties, CmdbPropertyFactory.createProperties());
  }

  public static HistoryObjectChangeInfo createObjectChangeInfoWithLayoutProperties(CmdbObject cmdbObject, Date changeTime, Changer changer, CmdbProperties layoutProperties, Long changeId) {
    return new HistoryObjectChangeInfoImpl(cmdbObject, changeTime, changer, layoutProperties, CmdbPropertyFactory.createProperties(), changeId);
  }

  public static HistoryObjectChangeInfo createObjectChangeInfoWithLayoutProperties(CmdbObject cmdbObject, Date changeTime, Changer changer, CmdbProperties layoutProperties, CmdbProperties previousValues) {
    return new HistoryObjectChangeInfoImpl(cmdbObject, changeTime, changer, layoutProperties, previousValues);
  }

  public static HistoryObjectChangeInfo createObjectChangeInfoWithLayoutProperties(CmdbObject cmdbObject, Date changeTime, Changer changer, CmdbProperties layoutProperties, CmdbProperties previousValues, Long changeId) {
    return new HistoryObjectChangeInfoImpl(cmdbObject, changeTime, changer, layoutProperties, previousValues, changeId);
  }

  public static HistoryLinkChangeInfo createLinkChangeInfo(Long changeId, CmdbLink cmdbLink) {
    return new HistoryLinkChangeInfoImpl(changeId, cmdbLink);
  }

  public static HistoryLinkChangeInfo createLinkChangeInfo(CmdbLink cmdbLink, Date changeTime, Changer changer) {
    return new HistoryLinkChangeInfoImpl(cmdbLink, changeTime, changer, CmdbPropertyFactory.createProperties(), CmdbPropertyFactory.createProperties());
  }

  public static HistoryLinkChangeInfo createLinkChangeInfo(CmdbLink cmdbLink, Date changeTime, Changer changer, CmdbProperties previousValues) {
    return new HistoryLinkChangeInfoImpl(cmdbLink, changeTime, changer, CmdbPropertyFactory.createProperties(), previousValues);
  }

  public static HistoryLinkChangeInfo createLinkChangeInfoWithLayoutProperties(CmdbLink cmdbLink, Date changeTime, Changer changer, CmdbProperties layoutProperties) {
    return new HistoryLinkChangeInfoImpl(cmdbLink, changeTime, changer, layoutProperties, CmdbPropertyFactory.createProperties());
  }

  public static HistoryLinkChangeInfo createLinkChangeInfoWithLayoutProperties(CmdbLink cmdbLink, Date changeTime, Changer changer, CmdbProperties layoutProperties, CmdbProperties previousValues) {
    return new HistoryLinkChangeInfoImpl(cmdbLink, changeTime, changer, layoutProperties, previousValues);
  }
}