package com.mercury.topaz.cmdb.history.shared.layout;

public abstract interface DataLayoutVisitor
{
  public abstract void visitSimpleLayout(SimpleDataLayout paramSimpleDataLayout);
}