package com.mercury.topaz.cmdb.history.shared.listener;

import com.mercury.topaz.cmdb.history.shared.operation.update.impl.HistoryUpdateAddTqlResultChanges;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.tql.change.manage.AbstractTqlChangeListenerCorseGrained;

public class HistoryDBTqlChangeListenerCorseGrained extends AbstractTqlChangeListenerCorseGrained
{
  public HistoryDBTqlChangeListenerCorseGrained(CmdbCustomerID customerID)
  {
    super(customerID);
  }

  public void onChanges(CmdbChanges cmdbChanges) {
    HistoryUpdateAddTqlResultChanges addChanges = new HistoryUpdateAddTqlResultChanges(cmdbChanges);
    executeAsynchronousOperation(addChanges);
  }
}