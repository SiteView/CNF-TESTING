package com.mercury.topaz.cmdb.history.server.base.jmx;

public abstract interface HistoryDBToolsJMXInterface
{
  public abstract String initializeHistoryDBFromModel(Integer paramInteger);

  public abstract String clearHistoryDB(Integer paramInteger);

  public abstract String purgeHistoryDB(Integer paramInteger);

  public abstract String purgeHistoryDB(Integer paramInteger, int paramInt);

  public abstract String stopHistoryDB(Integer paramInteger);

  public abstract String startHistoryDB(Integer paramInteger);

  public abstract String runStatistics(Integer paramInteger);

  public abstract String getHistoryDBContext(Integer paramInteger);

  public abstract String getHistoryChangesExtendedCounter(Integer paramInteger, String paramString1, String paramString2, String paramString3);

  public abstract String getHistoryChangesCounterByType(Integer paramInteger, String paramString1, String paramString2, String paramString3);

  public abstract String getRemovedData(Integer paramInteger, String paramString1, String paramString2);

  public abstract String isHistoryEnabled(Integer paramInteger);
}