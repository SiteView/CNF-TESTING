package com.mercury.topaz.cmdb.history.client.change;

import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.Serializable;

public abstract interface HistoryDatas extends Serializable
{
  public abstract void addHistoryData(HistoryData paramHistoryData);

  public abstract HistoryData getHistoryDataByID(CmdbDataID paramCmdbDataID);

  public abstract ReadOnlyIterator getHistoryDatasIterator();

  public abstract int size();
}