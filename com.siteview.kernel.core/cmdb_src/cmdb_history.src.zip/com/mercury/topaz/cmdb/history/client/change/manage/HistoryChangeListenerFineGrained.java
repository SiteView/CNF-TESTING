package com.mercury.topaz.cmdb.history.client.change.manage;

import com.mercury.topaz.cmdb.history.client.change.info.HistoryLinkChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;

public abstract interface HistoryChangeListenerFineGrained extends CmdbChangeListenerFineGrained
{
  public abstract void onAddLink(HistoryLinkChangeInfo paramHistoryLinkChangeInfo);

  public abstract void onAddObject(HistoryObjectChangeInfo paramHistoryObjectChangeInfo);

  public abstract void onRemoveLink(HistoryLinkChangeInfo paramHistoryLinkChangeInfo);

  public abstract void onRemoveObject(HistoryObjectChangeInfo paramHistoryObjectChangeInfo);

  public abstract void onUpdateLink(HistoryLinkChangeInfo paramHistoryLinkChangeInfo);

  public abstract void onUpdateObject(HistoryObjectChangeInfo paramHistoryObjectChangeInfo);
}