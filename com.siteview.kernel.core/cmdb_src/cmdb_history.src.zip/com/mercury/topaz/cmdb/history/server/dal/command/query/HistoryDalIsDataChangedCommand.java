package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeType;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID.Factory;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class HistoryDalIsDataChangedCommand extends AbstractHistoryDalQueryCommand<CmdbDataIDs>
{
  private CmdbIDsCollection<CmdbDataID> _dataIDs;
  private Date _dateAfterChanged;
  private HistoryFilter _historyFilter;

  public HistoryDalIsDataChangedCommand(CmdbIDsCollection<CmdbDataID> dataIDs, Date dateAfterChanged, HistoryFilter historyFilter)
  {
    setDataIDs(dataIDs);
    setDateAfterChanged(dateAfterChanged);
    setHistoryFilter(historyFilter);
  }

  protected CmdbDataIDs perform() throws Exception {
    if (useTempTable(getDataIDs().size()))
      return runSelectInTempTable();

    return runSelectInChunks();
  }

  private CmdbDataIDs runSelectInChunks() throws SQLException {
    CmdbDataIDs dataIDs = CmdbDataIdsFactory.create();
    CmdbIDsCollection idsLeft = getDataIDs();

    int maxIDsInChunk = getMaxPossibleSizeForInChunk();
    int numOfChunks = calcNumOfInChunks(idsLeft.size());
    for (int chunkNum = 0; chunkNum < numOfChunks; ++chunkNum) {
      int numOfIDs = (idsLeft.size() > maxIDsInChunk) ? maxIDsInChunk : idsLeft.size();
      StringBuilder inSql = createInSqlString(numOfIDs);
      runSelectForIDs(dataIDs, createInSqlString(null, HISTORY_CHANGES_CI_ID_COLUMN_NAME, inSql), createInSqlString(null, HISTORY_CHANGES_END1_COLUMN_NAME, inSql), idsLeft, numOfIDs);
      if (idsLeft.size() - numOfIDs > 0)
        idsLeft = removeIDsFromCollection(idsLeft, numOfIDs);
    }

    return dataIDs;
  }

  private CmdbDataIDs runSelectInTempTable() throws SQLException {
    createCmdbIDTempTable(getConnection(), elementsToIDsAsBytes(getDataIDs()));
    CmdbDataIDs dataIDs = CmdbDataIdsFactory.create();
    runSelectForIDs(dataIDs, createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", null, HISTORY_CHANGES_CI_ID_COLUMN_NAME), createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", null, HISTORY_CHANGES_END1_COLUMN_NAME), getDataIDs(), 0);
    return dataIDs;
  }

  private void runSelectForIDs(CmdbDataIDs dataIDs, StringBuilder idsInCondition, StringBuilder end1IdsInCondition, CmdbIDsCollection<CmdbDataID> idsLeft, int numOfIDs) throws SQLException {
    boolean useUnion = getHistoryFilter().isRelationInFilter();
    StringBuilder query = getQueryPart1(idsInCondition);
    if (useUnion) {
      query.append(" union ").append(getQueryPart2(end1IdsInCondition));
    }

    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(query.toString());

    List variables = new ArrayList(numOfIDs);
    addCmdbIdsToInList(idsLeft, variables, numOfIDs);

    fillPreparedStatementPart1(preparedStatement, numOfIDs, variables);
    if (useUnion) {
      fillPreparedStatementPart2(preparedStatement, numOfIDs, variables);
    }

    CmdbDalResultSet resultSet = preparedStatement.executeQuery();
    analyzeResults(dataIDs, resultSet);
    preparedStatement.close();
  }

  private StringBuilder getQueryPart1(StringBuilder idsInCondition) {
    StringBuilder query = getSelectAndFromQuery();
    query.append(" where ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?").append(" and ").append(idsInCondition).append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(">=?");

    if (getDateAfterChanged() == null) {
      query.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<=?");
    }

    if (getHistoryFilter().getChanger() != null) {
      query.append(" and ").append(HISTORY_CHANGES_CHANGER_INFO_COLUMN_NAME).append("=?");
      query.append(" and ").append(HISTORY_CHANGES_CHANGER_TYPE_COLUMN_NAME).append("=?");
    }
    if ((getHistoryFilter().getChangeTypes() != null) && (getHistoryFilter().getChangeTypes().length > 0))
      query.append(" and ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append(createInSqlString(getHistoryFilter().getChangeTypes().length));

    return query;
  }

  private StringBuilder getQueryPart2(StringBuilder idsInCondition) {
    StringBuilder query = getSelectAndFromQuery();
    query.append(" where ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?").append(" and ").append(idsInCondition).append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(">=?");

    if (getDateAfterChanged() == null)
      query.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<=?");

    boolean isAddRelationIn = getHistoryFilter().isChangeTypeInFilter(ChangeType.ADD_RELATION);
    boolean isRemoveRelationIn = getHistoryFilter().isChangeTypeInFilter(ChangeType.REMOVE_RELATION);
    if ((isAddRelationIn) && (isRemoveRelationIn)) {
      query.append(" and (").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append("=?").append(" or ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append("=?)");
    }
    else if ((isAddRelationIn) || (isRemoveRelationIn)) {
      query.append(" and (").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append("=?)");
    }

    if (getHistoryFilter().getChanger() != null) {
      query.append(" and ").append(HISTORY_CHANGES_CHANGER_INFO_COLUMN_NAME).append("=?");
      query.append(" and ").append(HISTORY_CHANGES_CHANGER_TYPE_COLUMN_NAME).append("=?");
    }
    return query;
  }

  private StringBuilder getSelectAndFromQuery() {
    return new StringBuilder("select distinct ").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME).append(",").append(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME).append(",").append(HISTORY_CHANGES_END1_COLUMN_NAME).append(" from ").append(HISTORY_CHANGES_TABLE_NAME);
  }

  private void fillPreparedStatementBothParts(CmdbDalPreparedStatement preparedStatement, int numOfIDs, List variables)
    throws SQLException
  {
    preparedStatement.setInt(getCustomerID().getID());

    if (numOfIDs > 0) {
      for (Iterator i$ = variables.iterator(); i$.hasNext(); ) { Object variable = i$.next();
        preparedStatement.setBytes((byte[])(byte[])variable);
      }

    }

    if (getDateAfterChanged() == null) {
      preparedStatement.setDate(getHistoryFilter().getFromDate());
      preparedStatement.setDate(getHistoryFilter().getToDate());
    } else {
      preparedStatement.setDate(getDateAfterChanged());
    }
  }

  private void fillPreparedStatementPart1(CmdbDalPreparedStatement preparedStatement, int numOfIDs, List variables) throws SQLException
  {
    fillPreparedStatementBothParts(preparedStatement, numOfIDs, variables);

    if (getHistoryFilter().getChanger() != null) {
      preparedStatement.setString(getHistoryFilter().getChanger().getChangerInfo());
      preparedStatement.setString(getHistoryFilter().getChanger().getDataStoreOrigin());
    }
    if ((getHistoryFilter().getChangeTypes() != null) && (getHistoryFilter().getChangeTypes().length > 0))
      for (int i = 0; i < getHistoryFilter().getChangeTypes().length; ++i)
        preparedStatement.setString(getHistoryFilter().getChangeTypes()[i].getType());
  }

  private void fillPreparedStatementPart2(CmdbDalPreparedStatement preparedStatement, int numOfIDs, List variables)
    throws SQLException
  {
    fillPreparedStatementBothParts(preparedStatement, numOfIDs, variables);

    boolean isAddRelationIn = getHistoryFilter().isChangeTypeInFilter(ChangeType.ADD_RELATION);
    boolean isRemoveRelationIn = getHistoryFilter().isChangeTypeInFilter(ChangeType.REMOVE_RELATION);
    if ((isAddRelationIn) && (isRemoveRelationIn)) {
      preparedStatement.setString(ChangeConstants.CHANGE_TYPES.ADD_LINK);
      preparedStatement.setString(ChangeConstants.CHANGE_TYPES.REMOVE_LINK);
    } else if (isAddRelationIn) {
      preparedStatement.setString(ChangeConstants.CHANGE_TYPES.ADD_LINK);
    } else if (isRemoveRelationIn) {
      preparedStatement.setString(ChangeConstants.CHANGE_TYPES.REMOVE_LINK);
    }

    if (getHistoryFilter().getChanger() != null) {
      preparedStatement.setString(getHistoryFilter().getChanger().getChangerInfo());
      preparedStatement.setString(getHistoryFilter().getChanger().getDataStoreOrigin());
    }
  }

  private void analyzeResults(CmdbDataIDs dataIDs, CmdbDalResultSet resultSet) throws SQLException {
    while (resultSet.next()) {
      CmdbDataID id;
      Boolean isObject = resultSet.getBoolean(HISTORY_CHANGES_IS_OBJECT_COLUMN_NAME);

      if (isObject.booleanValue()) {
        byte[] idAsBytes = resultSet.getBytes(HISTORY_CHANGES_CI_ID_COLUMN_NAME);
        id = CmdbObjectID.Factory.restoreObjectID(idAsBytes);
      } else {
        byte[] end1 = resultSet.getBytes(HISTORY_CHANGES_END1_COLUMN_NAME);
        id = CmdbObjectID.Factory.restoreObjectID(end1);
      }
      dataIDs.add(id);
    }
    resultSet.close();
  }

  protected void validateInput() {
  }

  private CmdbIDsCollection<CmdbDataID> getDataIDs() {
    return this._dataIDs;
  }

  private void setDataIDs(CmdbIDsCollection<CmdbDataID> dataIDs) {
    this._dataIDs = dataIDs;
  }

  private Date getDateAfterChanged() {
    return this._dateAfterChanged;
  }

  private void setDateAfterChanged(Date dateAfterChanged) {
    this._dateAfterChanged = dateAfterChanged;
  }

  private HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    if (historyFilter == null)
      throw new IllegalArgumentException("history filter is null");

    this._historyFilter = historyFilter;
  }
}