package com.mercury.topaz.cmdb.history.server.dal.command.update;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.dal.command.AbstractHistoryDalCommand;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.dal.util.DalTypeUtil;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.digest.impl.AbstractCMDBDigest;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public abstract class AbstractHistoryDalAddChangeCommand<DATA extends CmdbData<?>> extends AbstractHistoryDalCommand<Void>
{
  protected static String HISTORY_EVENTS_INSERT_SQL = createInsertOfChangeSql();
  public static final String ID_GENERATOR_NAME = "HistoryDB";
  private Changer _changer;
  private Date _changeDate;
  private Map<CmdbType, CmdbDalPreparedStatement> _cmdbTypeToPreparedStatementsMap = null;
  private Map<CmdbType, CmdbDalPreparedStatement> _cmdbTypeToPreparedStatementsForUpdateMap = null;

  public AbstractHistoryDalAddChangeCommand(Changer changer, Date changeDate)
  {
    setChanger(changer);
    setChangeDate(changeDate);
  }

  private Map<CmdbType, CmdbDalPreparedStatement> getCmdbTypeToPreparedStatementsMap() {
    if (this._cmdbTypeToPreparedStatementsMap == null)
      setCmdbTypeToPreparedStatementsMap(new HashMap());

    return this._cmdbTypeToPreparedStatementsMap;
  }

  private void setCmdbTypeToPreparedStatementsMap(Map<CmdbType, CmdbDalPreparedStatement> cmdbTypeToPreparedStatementsMap) {
    this._cmdbTypeToPreparedStatementsMap = cmdbTypeToPreparedStatementsMap;
  }

  private Map<CmdbType, CmdbDalPreparedStatement> getCmdbTypeToPreparedStatementsForUpdateMap() {
    if (this._cmdbTypeToPreparedStatementsForUpdateMap == null)
      setCmdbTypeToPreparedStatementsForUpdateMap(new HashMap());

    return this._cmdbTypeToPreparedStatementsForUpdateMap;
  }

  private void setCmdbTypeToPreparedStatementsForUpdateMap(Map<CmdbType, CmdbDalPreparedStatement> cmdbTypeToPreparedStatementsForUpdateMap) {
    this._cmdbTypeToPreparedStatementsForUpdateMap = cmdbTypeToPreparedStatementsForUpdateMap;
  }

  protected Changer getChanger() {
    return this._changer;
  }

  private void setChanger(Changer changer)
  {
    if (changer.getDataStoreOrigin().length() > AbstractHistoryDalCommand.MAX_CHANGER_TYPE_SIZE.intValue())
      this._changer = ChangerFactory.createChanger(changer.getDataStoreOrigin().substring(0, AbstractHistoryDalCommand.MAX_CHANGER_TYPE_SIZE.intValue()), changer.getChangerInfo());
    else
      this._changer = changer;
  }

  protected Date getChangeDate()
  {
    return this._changeDate;
  }

  private void setChangeDate(Date changeDate) {
    this._changeDate = changeDate;
  }

  protected void executePropertiesBatch() {
    CmdbDalPreparedStatement curPreparedStatement;
    for (Iterator i$ = getCmdbTypeToPreparedStatementsForUpdateMap().values().iterator(); i$.hasNext(); ) { Object o = (CmdbDalPreparedStatement)i$.next();
      curPreparedStatement = (CmdbDalPreparedStatement)o;
      curPreparedStatement.executeBatch();
      curPreparedStatement.close();
    }
    for (i$ = getCmdbTypeToPreparedStatementsMap().values().iterator(); i$.hasNext(); ) { Object o1 = (CmdbDalPreparedStatement)i$.next();
      curPreparedStatement = (CmdbDalPreparedStatement)o1;
      curPreparedStatement.executeBatch();
      curPreparedStatement.close();
    }
  }

  protected abstract String getEventType();

  protected abstract ReadOnlyIterator<DATA> getDatasIterator();

  protected abstract CmdbDataID getEnd1(DATA paramDATA);

  protected abstract CmdbDataID getEnd2(DATA paramDATA);

  protected abstract boolean isObject();

  protected Void perform() throws Exception {
    ReadOnlyIterator it = getDatasIterator();
    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Update(HISTORY_EVENTS_INSERT_SQL);

    while (it.hasNext()) {
      CmdbData data = (CmdbData)it.next();

      Long changeID = createChangeID();
      preparedStatement.setLong(changeID);
      preparedStatement.setBytes(getBytesFromDataID(data.getDataID()));
      preparedStatement.setString(data.getType());
      preparedStatement.setString(getEventType());
      preparedStatement.setDate(getChangeDate());
      preparedStatement.setString(getChanger().getChangerInfo());
      preparedStatement.setBoolean(isObject());
      preparedStatement.setBytes(getBytesFromDataID(getEnd1(data)));
      preparedStatement.setBytes(getBytesFromDataID(getEnd2(data)));
      preparedStatement.setInt(getCustomerID().getID());
      preparedStatement.setString(getChanger().getDataStoreOrigin());

      preparedStatement.addBatch();
      preparedStatement.executeBatch();
      addPropertiesInfoToBatch(data.getPropertiesIterator(), changeID, data.getDataID());

      if (_logger.isDebugEnabled())
        _logger.debug("saving change of " + getEventType() + " to history: Date(" + getChangeDate() + ") Changer(" + getChanger() + ") Info(" + data + ")");
    }

    if (preparedStatement != null) {
      preparedStatement.close();
      executePropertiesBatch();
    }
    return null;
  }

  protected void addPropertiesInfoToBatch(ReadOnlyIterator<CmdbProperty> propIt, Long changeID, CmdbDataID dataID)
    throws SQLException
  {
    while (propIt.hasNext()) {
      CmdbProperty prop = (CmdbProperty)propIt.next();

      CmdbType propType = prop.getType();
      if (propType instanceof CmdbEnum) {
        propType = CmdbSimpleTypes.CmdbInteger;
      }

      boolean shouldWorkWithBatch = (!(propType.equals(CmdbSimpleTypes.CmdbBytes))) && (!(propType.equals(CmdbSimpleTypes.CmdbXml)));
      try
      {
        if (!(propType instanceof CmdbSimpleList)) {
          CmdbDalPreparedStatement curPreparedStatement;
          if (getCmdbTypeToPreparedStatementsMap().containsKey(propType)) {
            curPreparedStatement = (CmdbDalPreparedStatement)getCmdbTypeToPreparedStatementsMap().get(propType);
          } else {
            curPreparedStatement = getConnection().prepareStatement4Update(createInsertOfInfoSql((String)CMDB_TYPE_TO_HISTORY_INFO.get(propType)));
            if (shouldWorkWithBatch)
              getCmdbTypeToPreparedStatementsMap().put(propType, curPreparedStatement);

          }

          curPreparedStatement.setLong(changeID);
          curPreparedStatement.setBytes(AbstractCMDBDigest.toBytes((AbstractCMDBDigest)dataID));
          curPreparedStatement.setString(prop.getKey());
          Object value = prop.getValue();
          if (prop.isValueEmpty())
            value = null;

          DalTypeUtil.setObject(curPreparedStatement, value, propType, MAX_BYTES_SIZE);

          curPreparedStatement.setDate(MAX_END_DATE);
          curPreparedStatement.setInt(getCustomerID().getID());
          if (shouldWorkWithBatch) {
            curPreparedStatement.addBatch();
          } else {
            curPreparedStatement.executeUpdate();
            curPreparedStatement.close();
          }

          updateEndTime(getChangeDate(), dataID, propType, prop.getKey(), changeID);
        }
      }
      catch (Exception e) {
        _logger.error("Error while trying to add/update property to info " + prop.getKey() + ". type is " + propType + ". ==>>> " + e);
      }
    }
  }

  protected void updateEndTime(Date changeDate, CmdbDataID dataID, CmdbType propType, String key, Long changeID)
    throws SQLException
  {
    CmdbDalPreparedStatement curPreparedStatementForUpdate;
    if (getCmdbTypeToPreparedStatementsForUpdateMap().containsKey(propType)) {
      curPreparedStatementForUpdate = (CmdbDalPreparedStatement)getCmdbTypeToPreparedStatementsForUpdateMap().get(propType);
    } else {
      curPreparedStatementForUpdate = getConnection().prepareStatement4Update(createUpdateOfOldInfoInInfoSql((String)CMDB_TYPE_TO_HISTORY_INFO.get(propType), key));
      getCmdbTypeToPreparedStatementsForUpdateMap().put(propType, curPreparedStatementForUpdate);
    }
    curPreparedStatementForUpdate.setDate(getChangeDate());
    curPreparedStatementForUpdate.setInt(getCustomerID().getID());
    curPreparedStatementForUpdate.setBytes(AbstractCMDBDigest.toBytes((AbstractCMDBDigest)dataID));
    curPreparedStatementForUpdate.setDate(MAX_END_DATE);
    curPreparedStatementForUpdate.setLong(changeID);
    if (key != null)
      curPreparedStatementForUpdate.setString(key);

    curPreparedStatementForUpdate.addBatch();
  }

  protected void validateInput() {
  }

  private static String createUpdateOfOldInfoInInfoSql(String tableName, String attrID) {
    StringBuilder update = new StringBuilder("update ").append(tableName).append(" set ").append(HISTORY_INFO_END_TIME_COLUMN_NAME).append("=?").append(" where ").append(HISTORY_INFO_CUSTOMER_ID_COLUMN_NAME).append("=?").append(" and ").append(HISTORY_INFO_CI_ID_COLUMN_NAME).append("=?").append(" and ").append(HISTORY_INFO_END_TIME_COLUMN_NAME).append(">=?").append(" and ").append(HISTORY_INFO_CHANGE_ID_COLUMN_NAME).append("!=?");

    if (attrID != null)
      update.append(" and ").append(HISTORY_INFO_ATTR_ID_COLUMN_NAME).append("=?");

    return update.toString();
  }

  private static String createInsertOfChangeSql() {
    return createInsertSql(HISTORY_CHANGES_TABLE_NAME, HISTORY_EVENTS_COLUMNS);
  }

  private static String createInsertOfInfoSql(String tableName) {
    return createInsertSql(tableName, HISTORY_INFO_COLUMNS);
  }

  private static String createInsertSql(String tableName, String[] columns) {
    int numOfColumns = columns.length;
    StringBuilder sqlString = new StringBuilder();

    sqlString.append("INSERT INTO ").append(tableName).append("(");
    for (int i = 0; i < numOfColumns; ++i) {
      if (i != 0)
        sqlString.append(",");

      sqlString.append(columns[i]);
    }
    sqlString.append(") values (");
    for (i = 0; i < numOfColumns; ++i) {
      if (i != 0)
        sqlString.append(",");

      sqlString.append("?");
    }
    sqlString.append(")");

    return sqlString.toString();
  }

  private Long createChangeID() {
    CmdbDalCommand generateID = CmdbDalCommandFactory.createGenerateSequenceIDComplexCommand("HistoryDB");
    CmdbDalCommandResult result = generateID.execute();
    return ((Long)result.getResult());
  }
}