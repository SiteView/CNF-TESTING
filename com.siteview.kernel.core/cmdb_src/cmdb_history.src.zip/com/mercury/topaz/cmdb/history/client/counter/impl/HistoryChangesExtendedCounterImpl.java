package com.mercury.topaz.cmdb.history.client.counter.impl;

import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesExtendedCounter;

class HistoryChangesExtendedCounterImpl extends AbstractHistoryChangesCounter
  implements HistoryChangesExtendedCounter
{
  private int _addedRelationCount;
  private int _removedRelationCount;

  HistoryChangesExtendedCounterImpl()
  {
    setAddedRelationCount(0);
    setRemovedRelationCount(0);
  }

  HistoryChangesExtendedCounterImpl(int addedCount, int updatedCount, int removedCount, int addedRelationCount, int removedRelationCount) {
    super(addedCount, updatedCount, removedCount);
    setAddedRelationCount(addedRelationCount);
    setRemovedRelationCount(removedRelationCount);
  }

  public int getAddedRelationCount() {
    return this._addedRelationCount;
  }

  public void setAddedRelationCount(int count) {
    this._addedRelationCount = count;
  }

  public int getRemovedRelationCount() {
    return this._removedRelationCount;
  }

  public void setRemovedRelationCount(int count) {
    this._removedRelationCount = count;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if (!(o instanceof HistoryChangesExtendedCounterImpl))
      return false;

    if (!(super.equals(o))) {
      return false;
    }

    HistoryChangesExtendedCounterImpl historyChangesWithRelationCounter = (HistoryChangesExtendedCounterImpl)o;

    if (this._addedRelationCount != historyChangesWithRelationCounter._addedRelationCount) {
      return false;
    }

    return (this._removedRelationCount == historyChangesWithRelationCounter._removedRelationCount);
  }

  public int hashCode()
  {
    int result = super.hashCode();
    result = 29 * result + this._addedRelationCount;
    result = 29 * result + this._removedRelationCount;
    return result;
  }

  public String toString() {
    StringBuilder desc = new StringBuilder("Counter with relation (").append(super.toString()).append(" Added Relation:").append(getAddedRelationCount()).append(" Removed Relation:").append(getRemovedRelationCount()).append(")");

    return desc.toString();
  }
}