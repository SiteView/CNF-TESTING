package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesExtendedCounter;
import com.mercury.topaz.cmdb.history.client.counter.impl.HistoryChangesExtendedCounterFactory;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class HistoryDalGetExtendedNumberOfChanges extends AbstractHistoryDalQueryCommand<HistoryChangesExtendedCounter>
{
  private CmdbIDsCollection<CmdbDataID> _cmdbDataIDs;
  private HistoryFilter _historyFilter;
  private HistoryChangesExtendedCounter _counter = HistoryChangesExtendedCounterFactory.createHistoryChangesExtendedCounter();

  public HistoryDalGetExtendedNumberOfChanges(CmdbIDsCollection<CmdbDataID> cmdbDataIDs, HistoryFilter historyFilter)
  {
    setCmdbDataIDs(cmdbDataIDs);
    setHistoryFilter(historyFilter);
    setCounter(HistoryChangesExtendedCounterFactory.createHistoryChangesExtendedCounter());
  }

  protected HistoryChangesExtendedCounter perform() throws Exception {
    if (useTempTable(getCmdbDataIDs().size()))
      runSelectInTempTable();
    else
      runSelectInChunks();

    return getCounter();
  }

  private void runSelectInChunks() throws SQLException {
    CmdbIDsCollection idsLeft = getCmdbDataIDs();

    int maxIDsInChunk = getMaxPossibleSizeForInChunk();
    int numOfChunks = calcNumOfInChunks(idsLeft.size());
    for (int chunkNum = 0; chunkNum < numOfChunks; ++chunkNum) {
      int numOfIDs = (idsLeft.size() > maxIDsInChunk) ? maxIDsInChunk : idsLeft.size();
      StringBuilder inSql = createInSqlString(numOfIDs);
      runSelectForIDs(createInSqlString(null, HISTORY_CHANGES_CI_ID_COLUMN_NAME, inSql), createInSqlString(null, HISTORY_CHANGES_END1_COLUMN_NAME, inSql), idsLeft, numOfIDs);

      if (idsLeft.size() - numOfIDs > 0)
        idsLeft = removeIDsFromCollection(idsLeft, numOfIDs);
    }
  }

  private void runSelectInTempTable() throws SQLException
  {
    createCmdbIDTempTable(getConnection(), elementsToIDsAsBytes(getCmdbDataIDs()));
    runSelectForIDs(createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", "", HISTORY_CHANGES_CI_ID_COLUMN_NAME), createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", null, HISTORY_CHANGES_END1_COLUMN_NAME), getCmdbDataIDs(), 0);
  }

  private void runSelectForIDs(StringBuilder idsInCondition, StringBuilder end1IdsInCondition, CmdbIDsCollection<CmdbDataID> idsLeft, int numOfIDs) throws SQLException {
    StringBuilder query = getQueryPart(idsInCondition);
    query.append(" union ").append(getQueryPart(end1IdsInCondition));

    CmdbDalPreparedStatement preparedStatement = getConnection().prepareStatement4Select(query.toString());

    List variables = new ArrayList(numOfIDs);
    addCmdbIdsToInList(idsLeft, variables, numOfIDs);

    fillPreparedStatementPart(preparedStatement, numOfIDs, variables);
    fillPreparedStatementPart(preparedStatement, numOfIDs, variables);

    CmdbDalResultSet resultSet = preparedStatement.executeQuery();
    analyzeResultSet(resultSet);
    preparedStatement.close();
  }

  private StringBuilder getQueryPart(StringBuilder idsInCondition) {
    StringBuilder query = new StringBuilder("select ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME).append(",").append("count(*)");

    query.append(" from ").append(HISTORY_CHANGES_TABLE_NAME);
    query.append(" where ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=? and ").append(idsInCondition);

    if (getHistoryFilter().getFromDate() != null)
      query.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append(">?");

    if (getHistoryFilter().getToDate() != null) {
      query.append(" and ").append(HISTORY_CHANGES_CHANGE_DATE_COLUMN_NAME).append("<=?");
    }

    query.append(" group by ").append(HISTORY_CHANGES_EVENT_TYPE_COLUMN_NAME);

    return query;
  }

  private void fillPreparedStatementPart(CmdbDalPreparedStatement preparedStatement, int numOfIDs, List variables)
    throws SQLException
  {
    preparedStatement.setInt(getCustomerID().getID());

    if (numOfIDs > 0) {
      for (Iterator i$ = variables.iterator(); i$.hasNext(); ) { Object variable = i$.next();
        preparedStatement.setBytes((byte[])(byte[])variable);
      }

    }

    if (getHistoryFilter().getFromDate() != null)
      preparedStatement.setDate(getHistoryFilter().getFromDate());

    if (getHistoryFilter().getToDate() != null)
      preparedStatement.setDate(getHistoryFilter().getToDate());
  }

  private void analyzeResultSet(CmdbDalResultSet resultSet)
    throws SQLException
  {
    while (resultSet.next()) {
      String changeType = resultSet.getString(1);
      Integer changesCount = resultSet.getInt(2);

      if (ChangeConstants.CHANGE_TYPES.ADD_OBJECT.equals(changeType))
        getCounter().setAddedCount(getCounter().getAddedCount() + changesCount.intValue());
      else if (ChangeConstants.CHANGE_TYPES.UPDATE_OBJECT.equals(changeType))
        getCounter().setUpdatedCount(getCounter().getUpdatedCount() + changesCount.intValue());
      else if (ChangeConstants.CHANGE_TYPES.REMOVE_OBJECT.equals(changeType))
        getCounter().setRemovedCount(getCounter().getRemovedCount() + changesCount.intValue());
      else if (ChangeConstants.CHANGE_TYPES.ADD_LINK.equals(changeType))
        getCounter().setAddedRelationCount(getCounter().getAddedRelationCount() + changesCount.intValue());
      else if (ChangeConstants.CHANGE_TYPES.REMOVE_LINK.equals(changeType))
        getCounter().setRemovedRelationCount(getCounter().getRemovedRelationCount() + changesCount.intValue());
    }
  }

  protected void validateInput()
  {
  }

  private CmdbIDsCollection<CmdbDataID> getCmdbDataIDs()
  {
    return this._cmdbDataIDs;
  }

  private void setCmdbDataIDs(CmdbIDsCollection<CmdbDataID> cmdbDataIDs) {
    this._cmdbDataIDs = cmdbDataIDs;
  }

  private HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    this._historyFilter = historyFilter;
  }

  private HistoryChangesExtendedCounter getCounter() {
    return this._counter;
  }

  private void setCounter(HistoryChangesExtendedCounter counter) {
    this._counter = counter;
  }
}