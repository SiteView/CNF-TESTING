package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.server.dal.command.AbstractHistoryDalCommand;
import com.mercury.topaz.cmdb.history.shared.layout.SimpleDataLayout;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalCommandFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalException;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class AbstractHistoryDalQueryCommand<RESULT> extends AbstractHistoryDalCommand<RESULT>
{
  protected static final int CMDB_ID_TEMP_TABLE_INIT_VAL = 0;

  protected StringBuilder createInSqlStringForTempTable(String tableName, String columnName, String joinTableName, String joinColumnName)
  {
    if (getConnectionPool().isUsingMSSqlDB())
      tableName = "#" + tableName;

    if (joinTableName == null) {
      joinTableName = "";
    }
    else if (!(joinTableName.equals("")))
      joinTableName = joinTableName + ".";

    return new StringBuilder(" exists (select ").append(columnName).append(" from ").append(tableName).append(" t where t.").append(columnName).append("=").append(joinTableName).append(joinColumnName).append(")");
  }

  protected StringBuilder createInSqlString(String joinTableName, String joinColumnName, CharSequence inSql)
  {
    if (joinTableName == null) {
      joinTableName = "";
    }
    else if (!(joinTableName.equals("")))
      joinTableName = joinTableName + ".";

    return new StringBuilder(joinTableName).append(joinColumnName).append(" ").append(inSql);
  }

  protected StringBuilder createInSqlString(int size, String joinTableName, String joinColumnName) {
    if ((joinTableName != null) && (!(joinTableName.equals(""))))
      joinTableName = joinTableName + ".";

    return new StringBuilder(joinTableName).append(joinColumnName).append(createInSqlString(size));
  }

  protected StringBuilder createInSqlString(int size) {
    StringBuilder sqlString = new StringBuilder();
    if (size > 0) {
      sqlString.append(" IN (? ");
      for (int i = 0; i < size - 1; ++i)
        sqlString.append(",? ");

      sqlString.append(")");
    }
    else {
      sqlString.append(" IN ()");
    }
    return sqlString;
  }

  protected static void addCmdbIdsToInList(CmdbIDsCollection<CmdbDataID> dataIDs, List<Object> bindVariables, int numOfIDs) {
    ReadOnlyIterator idsIter = dataIDs.getIdsIterator();
    while ((idsIter.hasNext()) && (numOfIDs > 0)) {
      CmdbDataID dataID = (CmdbDataID)idsIter.next();
      byte[] idAsBytes = getBytesFromDataID(dataID);
      bindVariables.add(idAsBytes);
      --numOfIDs;
    }
  }

  protected CmdbDataIDs removeIDsFromCollection(CmdbIDsCollection<CmdbDataID> dataIDs, int startFromIndex) {
    ReadOnlyIterator idsIter = dataIDs.getIdsIterator();
    while ((idsIter.hasNext()) && (startFromIndex > 0)) {
      idsIter.next();
      --startFromIndex;
    }

    CmdbDataIDs newDataIDs = CmdbDataIdsFactory.create();
    while (idsIter.hasNext()) {
      CmdbDataID dataID = (CmdbDataID)idsIter.next();
      newDataIDs.add(dataID);
    }
    return newDataIDs;
  }

  protected int calcNumOfInChunks(int fullSize) {
    if (fullSize == 0)
      return 1;

    return (int)Math.ceil(fullSize / getMaxPossibleSizeForInChunk());
  }

  protected List<String> getAttrListForFilter(SimpleDataLayout dataLayout)
  {
    List attrFilter = new ArrayList();
    if ((!(dataLayout.isAllLayer())) && (dataLayout.size() > 0)) {
      ReadOnlyIterator it = dataLayout.getKeysIterator();
      while (it.hasNext()) {
        String key = (String)it.next();
        attrFilter.add(key);
      }
    }
    return attrFilter;
  }

  protected List<Object> elementsToIDsAsBytes(CmdbIDsCollection<CmdbDataID> dataIDs) {
    List ids = new ArrayList();

    ReadOnlyIterator idsIter = dataIDs.getIdsIterator();

    while (idsIter.hasNext()) {
      CmdbDataID id = (CmdbDataID)idsIter.next();
      byte[] idAsBytes = getBytesFromDataID(id);
      ids.add(idAsBytes);
    }
    return ids;
  }

  protected boolean useTempTable(int size) {
    return isCmdbIDTempTableMustUsingChunksMechanism(size);
  }

  private boolean isCmdbIDTempTableMustUsingChunksMechanism(int numOfCmdbIDs) {
    return (getMaxPossibleSizeForInChunk() * getMaxNumOfInChunks() < numOfCmdbIDs);
  }

  protected void truncateCmdbIDTempTable() throws SQLException {
    truncateTempTable("CDM_TMP_OBJID");
  }

  protected void truncateTempTable(String tableName) {
    CmdbDalCommand truncateTableCommand = CmdbDalCommandFactory.createTruncateTempTableComplexCommand(tableName);
    truncateTableCommand.execute();
  }

  protected void createCmdbIDTempTable(CmdbDalConnection connection, List<Object> ids) throws SQLException {
    truncateCmdbIDTempTable();
    if ((ids != null) && (ids.size() > 0))
      fillCmdbIDTempTable(connection, ids);
  }

  private void fillCmdbIDTempTable(CmdbDalConnection connection, List<Object> ids) throws SQLException
  {
    fillCmdbIDTempTable(connection, ids, 0);
  }

  private void fillCmdbIDTempTable(CmdbDalConnection connection, List<Object> ids, int index) throws SQLException {
    if (ids.size() > 0)
    {
      String sqlString;
      if (getConnectionPool().isUsingOracleDB()) {
        sqlString = "insert into CDM_TMP_OBJID values(?, ?)";
      }
      else if (getConnectionPool().isUsingMSSqlDB()) {
        sqlString = "insert into #CDM_TMP_OBJID values(?, ?)";
      }
      else {
        throw new CmdbDalException("Unknown db type !!!");
      }

      CmdbDalPreparedStatement preparedStatement = connection.prepareStatement4Update(sqlString);
      Iterator idsIter = ids.iterator();

      while (idsIter.hasNext()) {
        byte[] id = (byte[])(byte[])idsIter.next();

        preparedStatement.setBytes(id);
        preparedStatement.setInt(index);
        preparedStatement.addBatchSilently();
      }

      preparedStatement.executeBatch();
      preparedStatement.close();
    }
  }
}