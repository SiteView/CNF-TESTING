package com.mercury.topaz.cmdb.history.client.change.object;

import com.mercury.topaz.cmdb.history.client.change.HistoryChange;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;

public class ObjectHistoryChangeFactory
{
  public static HistoryChange createHistoryChangeAddObject(HistoryObjectChangeInfo historyObjectChangeInfo)
  {
    return new HistoryChangeAddObject(historyObjectChangeInfo); }

  public static HistoryChange createHistoryChangeRemoveObject(HistoryObjectChangeInfo historyObjectChangeInfo) {
    return new HistoryChangeRemoveObject(historyObjectChangeInfo); }

  public static HistoryChange createHistoryChangeUpdateObject(HistoryObjectChangeInfo historyObjectChangeInfo) {
    return new HistoryChangeUpdateObject(historyObjectChangeInfo); }

  public static HistoryChange createHistoryChangeAddRelation(HistoryObjectChangeInfo historyObjectChangeInfo) {
    return new HistoryChangeAddRelation(historyObjectChangeInfo); }

  public static HistoryChange createHistoryChangeRemoveRelation(HistoryObjectChangeInfo historyObjectChangeInfo) {
    return new HistoryChangeRemoveRelation(historyObjectChangeInfo);
  }

  public static HistoryChange createObjectHistoryChange(HistoryObjectChangeInfo historyObjectChangeInfo, String changeType) {
    if (ChangeConstants.CHANGE_TYPES.ADD_OBJECT.equals(changeType))
      return createHistoryChangeAddObject(historyObjectChangeInfo);

    if (ChangeConstants.CHANGE_TYPES.UPDATE_OBJECT.equals(changeType))
      return createHistoryChangeUpdateObject(historyObjectChangeInfo);

    if (ChangeConstants.CHANGE_TYPES.REMOVE_OBJECT.equals(changeType))
      return createHistoryChangeRemoveObject(historyObjectChangeInfo);

    if (ChangeConstants.CHANGE_TYPES.ADD_RELATION.equals(changeType))
      return createHistoryChangeAddRelation(historyObjectChangeInfo);

    if (ChangeConstants.CHANGE_TYPES.REMOVE_RELATION.equals(changeType)) {
      return createHistoryChangeRemoveRelation(historyObjectChangeInfo);
    }

    throw new IllegalArgumentException("change type is illegal");
  }
}