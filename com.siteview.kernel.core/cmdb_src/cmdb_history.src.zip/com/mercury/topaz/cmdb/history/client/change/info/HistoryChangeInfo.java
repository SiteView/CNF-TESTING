package com.mercury.topaz.cmdb.history.client.change.info;

import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Date;

public abstract interface HistoryChangeInfo
{
  public abstract Long getChangeId();

  public abstract CmdbData getData();

  public abstract Date getChangeTime();

  public abstract Changer getChanger();

  public abstract Object getPropertyPreviousValue(String paramString);

  public abstract ReadOnlyIterator getLayoutPropertiesIterator();

  public abstract int getLayoutPropertiesSize();

  public abstract CmdbProperty getLayoutProperty(String paramString);

  public abstract boolean hasLayoutProperty(String paramString);

  public abstract void setChangeTime(Date paramDate);

  public abstract void setChanger(Changer paramChanger);

  public abstract void setPreviousValues(CmdbProperties paramCmdbProperties);

  public abstract void setLayoutProperties(CmdbProperties paramCmdbProperties);
}