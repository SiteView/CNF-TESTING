package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounters;
import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class HistoryQueryGetNumberOfChangesByType extends AbstractHistoryQueryOperation
{
  private HistoryFilter _historyFilter;
  private HistoryChangesTypedCounters _countersByType;
  public static String COUNTERS_BY_TYPE_RESULT_KEY = "countersByTypeKey";

  public HistoryQueryGetNumberOfChangesByType(HistoryFilter historyFilter)
  {
    setHistoryFilter(historyFilter);
  }

  public String getOperationName() {
    return "History Query: Get Number Of Changes By Type";
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException {
    HistoryChangesTypedCounters numOfChanges = historyQueryManager.getNumberOfChangesByType(getHistoryFilter());
    response.addResult(COUNTERS_BY_TYPE_RESULT_KEY, numOfChanges);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setCountersByType((HistoryChangesTypedCounters)response.getResult(COUNTERS_BY_TYPE_RESULT_KEY));
  }

  private HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    if (historyFilter == null)
      throw new IllegalArgumentException("history filter is null");

    if ((historyFilter.getClassTypes() == null) || (historyFilter.getClassTypes().length == 0))
      throw new IllegalArgumentException("class types in history filter is null or empty");

    this._historyFilter = historyFilter;
  }

  public HistoryChangesTypedCounters getCountersByType() {
    return this._countersByType;
  }

  private void setCountersByType(HistoryChangesTypedCounters countersByType) {
    this._countersByType = countersByType;
  }
}