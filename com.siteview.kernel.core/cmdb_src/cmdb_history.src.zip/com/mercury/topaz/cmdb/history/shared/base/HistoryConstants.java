package com.mercury.topaz.cmdb.history.shared.base;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.ATTRIBUTES;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;

public class HistoryConstants
{
  public static String[] HISTORY_QUALIFIERS = { CmdbAttributeQualifierDefs.COMPARABLE_ATTRIBUTE.getName(), CmdbAttributeQualifierDefs.CHANGE_NOTIFICATION_ATTRIBUTE.getName() };
  public static long MAX_END_DATE_NUMBER = -639696128L;

  public static final class ATTRIBUTES
  {
    public static String DISPLAY_LABEL = ChangeConstants.ATTRIBUTES.DISPLAY_LABEL;
    public static String LINK_TYPE = ChangeConstants.ATTRIBUTES.LINK_TYPE;
    public static String LINK_ID = ChangeConstants.ATTRIBUTES.LINK_ID;
    public static String END2_TYPE = ChangeConstants.ATTRIBUTES.END2_TYPE;
    public static String END2_DISPLAY_LABEL = ChangeConstants.ATTRIBUTES.END2_DISPLAY_LABEL;
    public static String END2_ID = ChangeConstants.ATTRIBUTES.END2_ID;
    public static String ADDED_CI = ChangeConstants.ATTRIBUTES.ADDED_CI;
    public static String REMOVED_CI = ChangeConstants.ATTRIBUTES.REMOVED_CI;
    public static String REMOVED = ChangeConstants.ATTRIBUTES.REMOVED;
  }

  public static final class PURGING
  {
    public static final String DAYS_TO_SAVE_BACK = "history.purging.days.to.save.back";
    public static final String SCHEDULER_INTERVAL_IN_HOURS = "history.purging.scheduler.interval.in.hours";
    public static final String SCHEDULER_HOUR_OF_FIRST_RUN = "history.purging.scheduler.hour.of.first.run";
  }

  public static final class TQL_RESULT
  {
    public static final String OBJECT_TYPE = "tql_result";
    public static final String PATTERN_NAME_ATTR_NAME = "pattern_name";
    public static String ADDED_OBJECTS_COUNTER_PROPERTY_NAME = "added_objects";
    public static String REMOVED_OBJECTS_COUNTER_PROPERTY_NAME = "removed_objects";
    public static String ADDED_LINKS_COUNTER_PROPERTY_NAME = "added_links";
    public static String REMOVED_LINKS_COUNTER_PROPERTY_NAME = "removed_links";
  }

  public static final class DAL
  {
    public static String HISTORY_CHANGES_TABLE_NAME = "HIST_EVENTS";
  }

  public static final class TASK
  {
    public static final class SettingsNames
    {
      public static final String PARAM_THREADS_POOL_SIZE_RAW_EVENT = "task.threads.pool.size.raw.event";
    }
  }
}