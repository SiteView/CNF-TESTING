package com.mercury.topaz.cmdb.history.shared.layout.impl;

import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import java.io.Serializable;

abstract class AbstractDataLayout
  implements DataLayout, Serializable
{
  protected boolean _isAllLayer;
  protected boolean _isIncludePrevValue;
  protected boolean _isIncludeChangeDate;
  protected boolean _isIncludeChanger;
  protected boolean _isIncludeChangerId;
  protected boolean _isIncludeEnd2Info;

  AbstractDataLayout(boolean isFullLayout)
  {
    setAllLayer(isFullLayout);
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    AbstractDataLayout that = (AbstractDataLayout)o;

    if (this._isAllLayer != that._isAllLayer)
      return false;

    if (this._isIncludeEnd2Info != that._isIncludeEnd2Info)
      return false;

    if (this._isIncludeChangeDate != that._isIncludeChangeDate)
      return false;

    if (this._isIncludeChanger != that._isIncludeChanger)
      return false;

    if (this._isIncludeChangerId != that._isIncludeChangerId) {
      return false;
    }

    return (this._isIncludePrevValue == that._isIncludePrevValue);
  }

  public int hashCode()
  {
    int result = (this._isAllLayer) ? 1 : 0;
    result = 29 * result + ((this._isIncludePrevValue) ? 1 : 0);
    result = 29 * result + ((this._isIncludeChangeDate) ? 1 : 0);
    result = 29 * result + ((this._isIncludeChanger) ? 1 : 0);
    result = 29 * result + ((this._isIncludeChangerId) ? 1 : 0);
    result = 29 * result + ((this._isIncludeEnd2Info) ? 1 : 0);
    return result;
  }

  public boolean isAllLayer() {
    return this._isAllLayer;
  }

  public void setAllLayer(boolean allLayer) {
    this._isAllLayer = allLayer;
  }

  public boolean isIncludePrevValue() {
    return this._isIncludePrevValue;
  }

  public void setIncludePrevValue(boolean includePrevValue) {
    if ((!(includePrevValue)) && (isAllLayer()))
      throw new IllegalArgumentException("The mode 'all layer' doesn't allow removing history values from layout");

    this._isIncludePrevValue = includePrevValue;
  }

  public boolean isIncludeChangeDate() {
    return this._isIncludeChangeDate;
  }

  public void setIncludeChangeDate(boolean includeChangeDate) {
    if ((!(includeChangeDate)) && (isAllLayer()))
      throw new IllegalArgumentException("The mode 'all layer' doesn't allow removing history values from layout");

    this._isIncludeChangeDate = includeChangeDate;
  }

  public boolean isIncludeChanger() {
    return this._isIncludeChanger;
  }

  public void setIncludeChanger(boolean includeChanger) {
    if ((!(includeChanger)) && (isAllLayer()))
      throw new IllegalArgumentException("The mode 'all layer' doesn't allow removing history values from layout");

    this._isIncludeChanger = includeChanger;
  }

  public boolean isIncludeChangerId() {
    return this._isIncludeChangerId;
  }

  public void setIncludeChangerId(boolean includeChangerId) {
    if ((!(includeChangerId)) && (isAllLayer()))
      throw new IllegalArgumentException("The mode 'all layer' doesn't allow removing history values from layout");

    this._isIncludeChangerId = includeChangerId;
  }

  public boolean isIncludeEnd2Info() {
    return this._isIncludeEnd2Info;
  }

  public void setIncludeEnd2Info(boolean includeEnd2Info) {
    if ((!(includeEnd2Info)) && (isAllLayer()))
      throw new IllegalArgumentException("The mode 'all layer' doesn't allow removing history values from layout");

    this._isIncludeEnd2Info = includeEnd2Info;
  }
}