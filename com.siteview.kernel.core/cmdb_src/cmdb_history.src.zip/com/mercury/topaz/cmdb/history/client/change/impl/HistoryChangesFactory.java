package com.mercury.topaz.cmdb.history.client.change.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryChanges;

public class HistoryChangesFactory
{
  public static HistoryChanges createHistoryChanges()
  {
    return new HistoryChangesImpl();
  }
}