package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.client.change.id.ChangeIdCmdbCollection;
import com.mercury.topaz.cmdb.history.client.change.id.impl.ChangeIdCmdbCollectionFactory;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.util.CmdbCollection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HistoryDalGetHistoryChangesCommandByChangeIds extends AbstractHistoryDalGetHistoryChanges
{
  private ChangeIdCmdbCollection _changeIds;

  public HistoryDalGetHistoryChangesCommandByChangeIds(ChangeIdCmdbCollection changeIds, HistoryFilter historyFilter, DataLayout dataLayout)
  {
    super(historyFilter, dataLayout);
    setChangeIds(changeIds);
  }

  public ChangeIdCmdbCollection getChangeIds() {
    return this._changeIds;
  }

  public void setChangeIds(ChangeIdCmdbCollection changeIds) {
    this._changeIds = changeIds;
  }

  protected void createIDTempTable() throws SQLException {
    createAndFillChangeIDTempTable(getChangeIds().getChangeIds());
  }

  protected StringBuilder createInSqlStringForIdTempTable() {
    return createInSqlStringForTempTable(CHANGE_ID_TEMP_TABLE_NAME, HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME, "e", HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME);
  }

  protected StringBuilder createInSqlStringForEnd1IdTempTable()
  {
    return null;
  }

  protected CmdbCollection getFilterIDs() {
    return getChangeIds();
  }

  protected void addIdsToInList(CmdbCollection dataIDs, List variables, int numOfIDs) {
    List idsList = ((ChangeIdCmdbCollection)dataIDs).getChangeIds();
    for (int i = 0; (i < numOfIDs) && (i < idsList.size()); ++i) {
      Long dataID = (Long)idsList.get(i);
      variables.add(dataID);
    }
  }

  protected void fillPreparedStatementWithIDs(CmdbDalPreparedStatement preparedStatement, List variables) throws SQLException {
    for (int i = 0; i < variables.size(); ++i)
      preparedStatement.setLong((Long)variables.get(i));
  }

  protected CmdbCollection copyIDs(CmdbCollection ids, int startFromIndex)
  {
    List idsList = ((ChangeIdCmdbCollection)ids).getChangeIds();
    List newIdsList = new ArrayList(idsList.size() - startFromIndex + 1);
    for (int i = startFromIndex; i < idsList.size(); ++i)
      newIdsList.add(idsList.get(i));

    return ChangeIdCmdbCollectionFactory.createChangeIdCmdbCollection(newIdsList);
  }

  protected StringBuilder createInSqlStringForIdColumn(StringBuilder inSql) {
    return createInSqlString("e", HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME, inSql);
  }

  protected StringBuilder createInSqlStringForEnd1IdColumn(StringBuilder inSql)
  {
    return null;
  }

  protected boolean useUnion() {
    return false;
  }
}