package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class HistoryDalGetDataLayoutInTheSameDateCommand extends AbstractHistoryDalGetDataLayoutCommand
{
  private Date _layoutDate;
  private String[] _classTypesFilter;

  public HistoryDalGetDataLayoutInTheSameDateCommand(CmdbIDsCollection dataIDs, Date layoutDate, DataLayout dataLayout)
  {
    super(dataIDs, dataLayout);
    setLayoutDate(layoutDate);
  }

  public HistoryDalGetDataLayoutInTheSameDateCommand(CmdbIDsCollection dataIDs, Date layoutDate, DataLayout dataLayout, String[] classTypesFilter) {
    super(dataIDs, dataLayout);
    setLayoutDate(layoutDate);
    this._classTypesFilter = classTypesFilter;
  }

  protected String getDateStringForWhereQuery() {
    return "?";
  }

  protected CmdbDalPreparedStatement addLayoutDateToPreparedStatement(CmdbDalPreparedStatement preparedStatement)
    throws SQLException
  {
    preparedStatement.setDate(getLayoutDate());

    preparedStatement.setDate(getLayoutDate());
    return preparedStatement;
  }

  protected CmdbDalPreparedStatement addAdditionalDataToPreparedStatement(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    if ((this._classTypesFilter != null) && (this._classTypesFilter.length > 0)) {
      String[] arr$ = this._classTypesFilter; int len$ = arr$.length; for (int i$ = 0; i$ < len$; ++i$) { String a_classTypesFilter = arr$[i$];
        preparedStatement.setString(a_classTypesFilter);
      }
    }
    return preparedStatement;
  }

  protected String getDateForSelect() {
    return "";
  }

  protected Date getDateValue(CmdbDalResultSet resultSet) {
    return null;
  }

  protected StringBuilder getWhereSql(List attrFilter, StringBuilder idsInCondition, int numOfIDs) {
    StringBuilder whereSql = super.getWhereSql(attrFilter, idsInCondition, numOfIDs);
    if ((this._classTypesFilter != null) && (this._classTypesFilter.length > 0)) {
      whereSql.append(" and ").append(HISTORY_CHANGES_CLASS_NAME_COLUMN_NAME).append(" in (");
      for (int i = 0; i < this._classTypesFilter.length; ++i) {
        if (i > 0)
          whereSql.append(",");

        whereSql.append("?");
      }
      whereSql.append(")");
    }
    return whereSql;
  }

  private Date getLayoutDate() {
    return this._layoutDate;
  }

  private void setLayoutDate(Date layoutDate) {
    this._layoutDate = layoutDate;
  }
}