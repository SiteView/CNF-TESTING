package com.mercury.topaz.cmdb.history.client.change.manage;

import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerCorseGrained;

public abstract interface HistoryChangeListenerCorseGrained extends CmdbChangeListenerCorseGrained
{
}