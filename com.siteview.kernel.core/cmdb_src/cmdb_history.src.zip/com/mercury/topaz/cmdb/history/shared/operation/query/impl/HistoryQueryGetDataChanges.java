package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;

public class HistoryQueryGetDataChanges extends AbstractHistoryQueryOperation
{
  protected static final String HISTORY_DATAS = "HISTORY_DATAS";
  private HistoryDatas _historyDatas;
  private CmdbIDsCollection _cmdbDataIDs;
  private HistoryFilter _historyFilter;
  private DataLayout _dataLayout;

  public HistoryQueryGetDataChanges(CmdbDataID cmdbDataID, HistoryFilter historyFilter, DataLayout layout)
  {
    CmdbDataIDs dataIds = CmdbDataIdsFactory.create();
    dataIds.add(cmdbDataID);
    setCmdbDataIDs(dataIds);
    setHistoryFilter(historyFilter);
    setDataLayout(layout);
  }

  public HistoryQueryGetDataChanges(CmdbIDsCollection cmdbDataIDs, HistoryFilter historyFilter, DataLayout layout) {
    setCmdbDataIDs(cmdbDataIDs);
    setHistoryFilter(historyFilter);
    setDataLayout(layout);
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException {
    HistoryDatas historyChanges = historyQueryManager.getDataChanges(getCmdbDataIDs(), getHistoryFilter(), getDataLayout());
    response.addResult("HISTORY_DATAS", historyChanges);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setHistoryDatas((HistoryDatas)response.getResult("HISTORY_DATAS"));
  }

  public HistoryDatas getHistoryDatas()
  {
    return this._historyDatas;
  }

  private void setHistoryDatas(HistoryDatas historyChanges) {
    this._historyDatas = historyChanges;
  }

  public String getOperationName() {
    return "history query: get data changes";
  }

  public CmdbIDsCollection getCmdbDataIDs() {
    return this._cmdbDataIDs;
  }

  private void setCmdbDataIDs(CmdbIDsCollection cmdbDataIDs) {
    if (cmdbDataIDs == null)
      throw new IllegalArgumentException("cmdb data ids is null");

    this._cmdbDataIDs = cmdbDataIDs;
  }

  public HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    if (historyFilter == null)
      throw new IllegalArgumentException("history filter is null");

    this._historyFilter = historyFilter;
  }

  public DataLayout getDataLayout() {
    return this._dataLayout;
  }

  private void setDataLayout(DataLayout dataLayout) {
    if (dataLayout == null)
      throw new IllegalArgumentException("data layout is null");

    this._dataLayout = dataLayout;
  }
}