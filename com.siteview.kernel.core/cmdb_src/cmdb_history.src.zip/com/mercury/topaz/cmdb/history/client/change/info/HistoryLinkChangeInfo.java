package com.mercury.topaz.cmdb.history.client.change.info;

import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;

public abstract interface HistoryLinkChangeInfo extends HistoryChangeInfo
{
  public abstract CmdbLink getCmdbLink();
}