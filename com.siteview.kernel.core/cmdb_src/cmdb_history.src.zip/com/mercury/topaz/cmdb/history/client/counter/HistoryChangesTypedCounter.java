package com.mercury.topaz.cmdb.history.client.counter;

public abstract interface HistoryChangesTypedCounter extends HistoryChangesCounter
{
  public abstract String getClassType();
}