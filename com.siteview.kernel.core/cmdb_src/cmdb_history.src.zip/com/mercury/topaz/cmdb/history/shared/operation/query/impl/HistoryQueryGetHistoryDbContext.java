package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.infra.utils.db.pools.DbContext;
import com.mercury.topaz.cmdb.history.server.dal.dao.CmdbDalHistoryDAO;
import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class HistoryQueryGetHistoryDbContext extends AbstractHistoryQueryOperation
{
  public static final String DB_CONTEXT = "DB_CONTEXT";
  private DbContext _dbContext = null;

  public String getOperationName()
  {
    return "History Query: get db context";
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException {
    DbContext dbContext = historyQueryManager.getHistoryDAO().getDbContext();
    response.addResult("DB_CONTEXT", dbContext);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setDbContext((DbContext)response.getResult("DB_CONTEXT"));
  }

  public DbContext getDbContext() {
    return this._dbContext;
  }

  private void setDbContext(DbContext dbContext) {
    this._dbContext = dbContext;
  }
}