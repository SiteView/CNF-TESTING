package com.mercury.topaz.cmdb.history.client.counter.impl;

import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounter;
import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounters;
import java.util.Map;

class HistoryChangesTypedCountersImpl extends AbstractHistoryChangesCounters
  implements HistoryChangesTypedCounters
{
  public void add(HistoryChangesTypedCounter typedCounter)
  {
    getCounters().put(typedCounter.getClassType(), typedCounter);
  }

  public HistoryChangesTypedCounter getTypedCounter(String classType) {
    return ((HistoryChangesTypedCounter)getCounters().get(classType));
  }
}