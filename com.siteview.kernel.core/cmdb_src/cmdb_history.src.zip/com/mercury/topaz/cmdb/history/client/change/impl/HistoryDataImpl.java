package com.mercury.topaz.cmdb.history.client.change.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryChanges;
import com.mercury.topaz.cmdb.history.client.change.HistoryData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;

class HistoryDataImpl
  implements HistoryData
{
  private CmdbDataID _id;
  private HistoryChanges _historyChanges;
  private CmdbData _initialData;

  public HistoryDataImpl(CmdbDataID id, CmdbData initialData, HistoryChanges historyChanges)
  {
    setHistoryChanges(historyChanges);
    setId(id);
    setInitialData(initialData);
  }

  public CmdbData getInitialData() {
    return this._initialData;
  }

  public boolean hasInitialData()
  {
    return (getInitialData() != null);
  }

  private void setInitialData(CmdbData initialData)
  {
    this._initialData = initialData;
  }

  public HistoryChanges getHistoryChanges() {
    return this._historyChanges;
  }

  private void setHistoryChanges(HistoryChanges historyChanges) {
    if (historyChanges == null)
      throw new IllegalArgumentException("history changes is null");

    this._historyChanges = historyChanges;
  }

  public CmdbDataID getId() {
    return this._id;
  }

  private void setId(CmdbDataID id) {
    if (id == null)
      throw new IllegalArgumentException("id is null");

    this._id = id;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    HistoryDataImpl that = (HistoryDataImpl)o;

    if (this._historyChanges != null) if (this._historyChanges.equals(that._historyChanges)) break label62; 
    else if (that._historyChanges == null) break label62;
    return false;

    if (this._id != null) label62: if (this._id.equals(that._id)) break label95; 
    else if (that._id == null) break label95;
    return false;

    if (this._initialData != null) label95: if (this._initialData.equals(that._initialData)) break label128;
    label128: return (that._initialData == null);
  }

  public int hashCode()
  {
    int result = (this._id != null) ? this._id.hashCode() : 0;
    result = 29 * result + ((this._historyChanges != null) ? this._historyChanges.hashCode() : 0);
    result = 29 * result + ((this._initialData != null) ? this._initialData.hashCode() : 0);
    return result;
  }
}