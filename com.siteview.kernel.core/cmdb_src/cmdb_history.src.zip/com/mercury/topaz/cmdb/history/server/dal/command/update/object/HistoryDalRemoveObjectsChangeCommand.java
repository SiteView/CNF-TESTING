package com.mercury.topaz.cmdb.history.server.dal.command.update.object;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.Date;

public class HistoryDalRemoveObjectsChangeCommand extends AbstractHistoryDalObjectChangeCommand
{
  private static String EVENT_TYPE = ChangeConstants.CHANGE_TYPES.REMOVE_OBJECT;

  public HistoryDalRemoveObjectsChangeCommand(Changer changer, Date changeDate, CmdbObject object)
  {
    super(changer, changeDate, object);
  }

  public HistoryDalRemoveObjectsChangeCommand(Changer changer, Date changeDate, CmdbObjects objects) {
    super(changer, changeDate, objects);
  }

  protected String getEventType() {
    return EVENT_TYPE;
  }

  protected void addPropertiesInfoToBatch(ReadOnlyIterator<CmdbProperty> propIt, Long changeID, CmdbDataID dataID)
    throws SQLException
  {
  }
}