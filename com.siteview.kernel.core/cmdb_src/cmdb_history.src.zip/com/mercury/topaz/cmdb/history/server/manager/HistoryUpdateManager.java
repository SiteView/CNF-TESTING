package com.mercury.topaz.cmdb.history.server.manager;

public abstract interface HistoryUpdateManager extends HistoryManager
{
  public abstract void enableHistoryDB();

  public abstract void disableHistoryDB();

  public abstract boolean isHistoryDBEnabled();
}