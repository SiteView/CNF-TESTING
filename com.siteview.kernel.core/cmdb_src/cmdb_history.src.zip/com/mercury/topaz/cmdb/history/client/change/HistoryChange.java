package com.mercury.topaz.cmdb.history.client.change;

import com.mercury.topaz.cmdb.history.client.change.info.HistoryChangeInfo;
import com.mercury.topaz.cmdb.shared.change.CmdbChange;

public abstract interface HistoryChange extends CmdbChange
{
  public abstract void accept(HistoryChangeVisitor paramHistoryChangeVisitor);

  public abstract HistoryChangeInfo getChangeInfo();
}