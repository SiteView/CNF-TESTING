package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesExtendedCounter;
import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;

public class HistoryQueryGetExtendedNumberOfChanges extends AbstractHistoryQueryOperation
{
  private CmdbIDsCollection _dataIDs;
  private HistoryFilter _historyFilter;
  private HistoryChangesExtendedCounter _historyChangesCounter;
  public static String HISTORY_CHANGES_COUNTER_RESULT_KEY = "extendedCounterKey";

  public HistoryQueryGetExtendedNumberOfChanges(CmdbIDsCollection dataIDs, HistoryFilter historyFilter)
  {
    setDataIDs(dataIDs);
    setHistoryFilter(historyFilter);
  }

  public HistoryQueryGetExtendedNumberOfChanges(CmdbDataID dataID, HistoryFilter historyFilter) {
    CmdbDataIDs dataIDs = CmdbDataIdsFactory.create();
    dataIDs.add(dataID);
    setDataIDs(dataIDs);
    setHistoryFilter(historyFilter);
  }

  public String getOperationName() {
    return "History Query: Get Extended Number Of Changes";
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException {
    HistoryChangesExtendedCounter numOfChanges = historyQueryManager.getExtendedNumberOfChanges(getDataIDs(), getHistoryFilter());
    response.addResult(HISTORY_CHANGES_COUNTER_RESULT_KEY, numOfChanges);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setHistoryChangesCounter((HistoryChangesExtendedCounter)response.getResult(HISTORY_CHANGES_COUNTER_RESULT_KEY));
  }

  private CmdbIDsCollection getDataIDs() {
    return this._dataIDs;
  }

  private void setDataIDs(CmdbIDsCollection dataIDs) {
    if ((dataIDs == null) || (dataIDs.size() == 0))
      throw new IllegalArgumentException("data IDs is null or empty");

    this._dataIDs = dataIDs;
  }

  private HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    if (historyFilter == null)
      throw new IllegalArgumentException("history filter is null");

    this._historyFilter = historyFilter;
  }

  public HistoryChangesExtendedCounter getHistoryChangesCounter() {
    return this._historyChangesCounter;
  }

  private void setHistoryChangesCounter(HistoryChangesExtendedCounter historyChangesCounter) {
    this._historyChangesCounter = historyChangesCounter;
  }
}