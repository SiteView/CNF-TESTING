package com.mercury.topaz.cmdb.history.client.counter.impl;

import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesCounters;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

abstract class AbstractHistoryChangesCounters
  implements HistoryChangesCounters
{
  private Map _counters;

  protected AbstractHistoryChangesCounters()
  {
    setCounters(new HashMap());
  }

  public ReadOnlyIterator getCountersIterator() {
    return new ReadOnlyIteratorImpl(getCounters().values().iterator());
  }

  public int size() {
    return getCounters().size();
  }

  protected Map getCounters() {
    return this._counters;
  }

  private void setCounters(Map counters) {
    this._counters = counters;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if (!(o instanceof AbstractHistoryChangesCounters)) {
      return false;
    }

    AbstractHistoryChangesCounters abstractHistoryChangesCounters = (AbstractHistoryChangesCounters)o;

    if (this._counters != null) if (this._counters.equals(abstractHistoryChangesCounters._counters)) break label54;
    label54: return (abstractHistoryChangesCounters._counters == null);
  }

  public int hashCode()
  {
    return ((this._counters != null) ? this._counters.hashCode() : 0);
  }

  public String toString() {
    return getCounters().values().toString();
  }
}