package com.mercury.topaz.cmdb.history.client.change.info;

import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;

public abstract interface HistoryObjectChangeInfo extends HistoryChangeInfo
{
  public abstract CmdbObject getCmdbObject();
}