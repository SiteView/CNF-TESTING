package com.mercury.topaz.cmdb.history.shared.operation;

import com.mercury.topaz.cmdb.history.server.manager.HistoryManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.CmdbOperation;

public abstract interface HistoryOperation extends CmdbOperation
{
  public abstract void historyExecute(HistoryManager paramHistoryManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}