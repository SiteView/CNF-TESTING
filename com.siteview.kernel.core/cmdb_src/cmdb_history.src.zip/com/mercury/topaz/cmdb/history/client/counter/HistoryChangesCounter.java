package com.mercury.topaz.cmdb.history.client.counter;

import java.io.Serializable;

public abstract interface HistoryChangesCounter extends Serializable
{
  public abstract int getAddedCount();

  public abstract int getUpdatedCount();

  public abstract int getRemovedCount();

  public abstract void setAddedCount(int paramInt);

  public abstract void setUpdatedCount(int paramInt);

  public abstract void setRemovedCount(int paramInt);
}