package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.client.change.impl.HistoryDatasFactory;
import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;

public class HistoryQueryGetLastDataChange extends AbstractHistoryQueryOperation
{
  protected static final String HISTORY_DATAS = "HISTORY_DATAS";
  private HistoryDatas _historyDatas;
  private CmdbIDsCollection _cmdbDataIDs;
  private HistoryFilter _historyFilter;

  public HistoryQueryGetLastDataChange(CmdbDataID cmdbDataID, HistoryFilter historyFilter)
  {
    CmdbDataIDs dataIds = CmdbDataIdsFactory.create();
    dataIds.add(cmdbDataID);
    setCmdbDataIDs(dataIds);
    setHistoryFilter(historyFilter);
  }

  public HistoryQueryGetLastDataChange(CmdbIDsCollection cmdbDataIDs, HistoryFilter historyFilter) {
    setCmdbDataIDs(cmdbDataIDs);
    setHistoryFilter(historyFilter);
  }

  public HistoryQueryGetLastDataChange(HistoryFilter historyFilter) {
    setHistoryFilter(historyFilter);
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException
  {
    HistoryDatas historyDatas = null;

    if (getCmdbDataIDs() == null) {
      CmdbIDsCollection foundIDs = historyQueryManager.getIDsByHistoryFilter(getHistoryFilter());
      if ((foundIDs != null) && (foundIDs.size() > 0)) {
        historyDatas = historyQueryManager.getDataLastChange(foundIDs, getHistoryFilter());
      }
      else
        historyDatas = HistoryDatasFactory.create();
    }
    else
    {
      historyDatas = historyQueryManager.getDataLastChange(getCmdbDataIDs(), getHistoryFilter());
    }
    response.addResult("HISTORY_DATAS", historyDatas);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setHistoryDatas((HistoryDatas)response.getResult("HISTORY_DATAS"));
  }

  public HistoryDatas getHistoryDatas()
  {
    return this._historyDatas;
  }

  private void setHistoryDatas(HistoryDatas historyChanges) {
    this._historyDatas = historyChanges;
  }

  public String getOperationName() {
    return "history query: get data last change";
  }

  private CmdbIDsCollection getCmdbDataIDs() {
    return this._cmdbDataIDs;
  }

  private void setCmdbDataIDs(CmdbIDsCollection cmdbDataIDs) {
    if ((cmdbDataIDs == null) || (cmdbDataIDs.size() == 0))
      throw new IllegalArgumentException("cmdb data ids is null or empty");

    this._cmdbDataIDs = cmdbDataIDs;
  }

  private HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    if (historyFilter == null)
      throw new IllegalArgumentException("history filter is null");

    this._historyFilter = historyFilter;
  }
}