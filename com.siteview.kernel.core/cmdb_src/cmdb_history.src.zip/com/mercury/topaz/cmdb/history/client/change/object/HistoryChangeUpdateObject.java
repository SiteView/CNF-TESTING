package com.mercury.topaz.cmdb.history.client.change.object;

import com.mercury.topaz.cmdb.history.client.change.HistoryChangeVisitor;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.manage.HistoryChangeListenerFineGrained;

public class HistoryChangeUpdateObject extends AbstractObjectHistoryChange
{
  HistoryChangeUpdateObject(HistoryObjectChangeInfo historyObjectChangeInfo)
  {
    super(historyObjectChangeInfo);
  }

  public void accept(HistoryChangeVisitor historyChangeVisitor) {
    historyChangeVisitor.updateDataChange(getHistoryObjectChangeInfo());
    historyChangeVisitor.updateObjectChange(getHistoryObjectChangeInfo());
  }

  public void execute(HistoryChangeListenerFineGrained changeListener) {
    changeListener.onUpdateObject(getHistoryObjectChangeInfo());
  }

  public String toString() {
    return ChangeConstants.CHANGE_TYPES.UPDATE_OBJECT + ": " + super.toString();
  }
}