package com.mercury.topaz.cmdb.history.client.change.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryChange;
import com.mercury.topaz.cmdb.history.client.change.manage.HistoryChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.bean.AbstractCmdbImmutableBean;
import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;
import java.io.ObjectStreamException;

public abstract class AbstractHistoryChange extends AbstractCmdbImmutableBean
  implements HistoryChange
{
  protected Object doReadResolve()
    throws ObjectStreamException
  {
    return this;
  }

  public CmdbDigest getDigest() {
    throw new UnsupportedOperationException("wasn't implemented");
  }

  public void execute(CmdbChangeListenerFineGrained changeListener) {
    execute((HistoryChangeListenerFineGrained)changeListener);
  }

  public abstract void execute(HistoryChangeListenerFineGrained paramHistoryChangeListenerFineGrained);

  public String toString() {
    return getChangeInfo().toString();
  }
}