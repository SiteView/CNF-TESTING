package com.mercury.topaz.cmdb.history.server.operation.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.history.shared.base.HistoryLogFactory;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

abstract class AbstractHistoryCommandEnableDisableHistory extends AbstractHistoryCommand
{
  protected static Log _logger = HistoryLogFactory.getHistoryLog();

  public void historyCommandExecute(HistoryUpdateManager historyUpdateManager, CmdbResponse response)
    throws CmdbException
  {
    enableDisableHistory(historyUpdateManager);
    writeLogMessage();
  }

  protected abstract void enableDisableHistory(HistoryUpdateManager paramHistoryUpdateManager);

  protected abstract void writeLogMessage();
}