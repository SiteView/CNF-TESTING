package com.mercury.topaz.cmdb.history.client.change.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;

public class HistoryDatasFactory
{
  public static HistoryDatas create()
  {
    return new HistoryDatasImpl();
  }
}