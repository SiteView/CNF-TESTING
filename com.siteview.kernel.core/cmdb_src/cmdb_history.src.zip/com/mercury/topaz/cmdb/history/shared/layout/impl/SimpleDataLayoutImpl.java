package com.mercury.topaz.cmdb.history.shared.layout.impl;

import com.mercury.topaz.cmdb.history.shared.layout.DataLayoutVisitor;
import com.mercury.topaz.cmdb.history.shared.layout.SimpleDataLayout;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.EmptyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class SimpleDataLayoutImpl extends AbstractDataLayout
  implements SimpleDataLayout, Serializable
{
  protected List<String> _keys;
  protected boolean _isAllKeys;

  SimpleDataLayoutImpl(boolean isFullLayout)
  {
    super(isFullLayout);
    setAllKeys(isFullLayout);
  }

  SimpleDataLayoutImpl(List<String> keys) {
    super(false);
    if ((keys == null) || (keys.isEmpty())) {
      throw new IllegalArgumentException("the keys list is null or empty");
    }

    super.setIncludeEnd2Info(true);
    super.setIncludeChangeDate(true);
    super.setIncludeChanger(true);
    super.setIncludePrevValue(true);
    setKeys(new ArrayList());
    getKeys().addAll(keys);
  }

  public void addKey(String key) {
    if (getKeys() == null)
      setKeys(new ArrayList());

    if (!(contains(key)))
      getKeys().add(key);
  }

  public boolean contains(String key)
  {
    if (getKeys() == null)
      return false;

    return getKeys().contains(key);
  }

  public int size() {
    if (getKeys() == null)
      return 0;

    return getKeys().size();
  }

  public ReadOnlyIterator<String> getKeysIterator() {
    if (getKeys() == null)
      return EmptyIterator.getInstance();

    return new ReadOnlyIteratorImpl(getKeys().iterator());
  }

  public void accept(DataLayoutVisitor dataLayoutVisitor)
  {
    dataLayoutVisitor.visitSimpleLayout(this);
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (getClass() != o.getClass()))
      return false;

    if (!(super.equals(o))) {
      return false;
    }

    SimpleDataLayoutImpl that = (SimpleDataLayoutImpl)o;

    if (this._isAllKeys != that._isAllKeys)
      return false;

    if (this._keys != null) if (this._keys.equals(that._keys)) break label83; 
    label83: return (that._keys == null);
  }

  public int hashCode() {
    int result = super.hashCode();
    result = 29 * result + ((this._keys != null) ? this._keys.hashCode() : 0);
    result = 29 * result + ((this._isAllKeys) ? 1 : 0);
    return result;
  }

  public List<String> getKeys() {
    return this._keys;
  }

  private void setKeys(List<String> keys) {
    this._keys = keys;
  }

  public void setAllLayer(boolean allLayer) {
    super.setAllLayer(allLayer);
    if (!(isAllLayer()))
      setKeys(new ArrayList());
    else
      setKeys(null);
  }

  public boolean isAllKeys()
  {
    return this._isAllKeys;
  }

  public void setAllKeys(boolean allKeys) {
    if ((!(allKeys)) && (isAllLayer()))
      throw new IllegalArgumentException("The mode 'all layer' doesn't allow not full layout");

    this._isAllKeys = allKeys;
  }
}