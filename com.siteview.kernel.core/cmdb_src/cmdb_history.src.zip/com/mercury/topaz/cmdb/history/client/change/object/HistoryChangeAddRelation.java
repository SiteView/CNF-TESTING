package com.mercury.topaz.cmdb.history.client.change.object;

import com.mercury.topaz.cmdb.history.client.change.HistoryChangeVisitor;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryObjectChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.manage.HistoryChangeListenerFineGrained;

public class HistoryChangeAddRelation extends AbstractObjectHistoryChange
{
  HistoryChangeAddRelation(HistoryObjectChangeInfo historyObjectChangeInfo)
  {
    super(historyObjectChangeInfo);
  }

  public void execute(HistoryChangeListenerFineGrained changeListener)
  {
  }

  public void accept(HistoryChangeVisitor historyChangeVisitor) {
    historyChangeVisitor.addRelationChange(getHistoryObjectChangeInfo());
  }

  public String toString() {
    return ChangeConstants.CHANGE_TYPES.ADD_RELATION + ": " + super.toString();
  }
}