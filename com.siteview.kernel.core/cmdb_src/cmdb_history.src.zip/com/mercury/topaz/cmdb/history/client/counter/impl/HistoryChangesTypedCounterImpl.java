package com.mercury.topaz.cmdb.history.client.counter.impl;

import com.mercury.topaz.cmdb.history.client.counter.HistoryChangesTypedCounter;

class HistoryChangesTypedCounterImpl extends AbstractHistoryChangesCounter
  implements HistoryChangesTypedCounter
{
  private String _classType;

  public HistoryChangesTypedCounterImpl(String classType, int addedCount, int updatedCount, int removedCount)
  {
    super(addedCount, updatedCount, removedCount);
    setClassType(classType);
  }

  public HistoryChangesTypedCounterImpl(String classType)
  {
    setClassType(classType);
  }

  public String getClassType() {
    return this._classType;
  }

  private void setClassType(String classType) {
    this._classType = classType;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if (!(o instanceof HistoryChangesTypedCounterImpl))
      return false;

    if (!(super.equals(o))) {
      return false;
    }

    HistoryChangesTypedCounterImpl historyChangesCountByType = (HistoryChangesTypedCounterImpl)o;

    if (this._classType != null) if (this._classType.equals(historyChangesCountByType._classType)) break label64;
    label64: return (historyChangesCountByType._classType == null);
  }

  public int hashCode()
  {
    int result = super.hashCode();
    result = 29 * result + ((this._classType != null) ? this._classType.hashCode() : 0);
    return result;
  }

  public String toString() {
    StringBuilder desc = new StringBuilder("Counter of type ").append(getClassType()).append("(").append(super.toString()).append(")");
    return desc.toString();
  }
}