package com.mercury.topaz.cmdb.history.server.dal.command.update.link;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.Date;

public class HistoryDalRemoveLinksChangeCommand extends AbstractHistoryDalLinkChangeCommand
{
  private static String EVENT_TYPE = ChangeConstants.CHANGE_TYPES.REMOVE_LINK;

  public HistoryDalRemoveLinksChangeCommand(Changer changer, Date changeDate, CmdbLink link)
  {
    super(changer, changeDate, link);
  }

  public HistoryDalRemoveLinksChangeCommand(Changer changer, Date changeDate, CmdbLinks links) {
    super(changer, changeDate, links);
  }

  protected String getEventType() {
    return EVENT_TYPE;
  }

  protected void addPropertiesInfoToBatch(ReadOnlyIterator<CmdbProperty> propIt, Long changeID, CmdbDataID dataID)
    throws SQLException
  {
  }
}