package com.mercury.topaz.cmdb.history.client.change;

import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import java.io.Serializable;

public abstract interface HistoryData extends Serializable
{
  public abstract CmdbDataID getId();

  public abstract HistoryChanges getHistoryChanges();

  public abstract CmdbData getInitialData();

  public abstract boolean hasInitialData();
}