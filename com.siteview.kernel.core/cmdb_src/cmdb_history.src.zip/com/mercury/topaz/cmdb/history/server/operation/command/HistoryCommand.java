package com.mercury.topaz.cmdb.history.server.operation.command;

import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.history.shared.operation.HistoryOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract interface HistoryCommand extends HistoryOperation
{
  public abstract void historyCommandExecute(HistoryUpdateManager paramHistoryUpdateManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}