package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.server.manager.HistoryManager;
import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.operation.impl.AbstractHistoryOperation;
import com.mercury.topaz.cmdb.history.shared.operation.query.HistoryQuery;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

abstract class AbstractHistoryQueryOperation extends AbstractHistoryOperation
  implements HistoryQuery
{
  public final void historyExecute(HistoryManager historyManager, CmdbResponse response)
    throws CmdbException
  {
    historyQueryExecute((HistoryQueryManager)historyManager, response);
  }

  public String getExecutionTaskQueueName() {
    return "History Query Task";
  }
}