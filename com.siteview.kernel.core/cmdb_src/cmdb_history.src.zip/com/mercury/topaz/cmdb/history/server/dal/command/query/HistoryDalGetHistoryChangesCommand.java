package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.util.CmdbCollection;
import java.sql.SQLException;
import java.util.List;

public class HistoryDalGetHistoryChangesCommand extends AbstractHistoryDalGetHistoryChanges
{
  public HistoryDalGetHistoryChangesCommand(HistoryFilter historyFilter, DataLayout layout)
  {
    super(historyFilter, layout);
  }

  protected void createIDTempTable() throws SQLException {
    throw new IllegalStateException("Can't create temp table  - no id filter ");
  }

  protected StringBuilder createInSqlStringForIdTempTable() {
    throw new IllegalStateException("Can't create temp table  - no id filter ");
  }

  protected StringBuilder createInSqlStringForEnd1IdTempTable() {
    throw new IllegalStateException("Can't create temp table  - no id filter ");
  }

  protected void addIdsToInList(CmdbCollection dataIDs, List variables, int numOfIDs)
  {
  }

  protected void fillPreparedStatementWithIDs(CmdbDalPreparedStatement preparedStatement, List variables) throws SQLException
  {
  }

  protected CmdbCollection getFilterIDs() {
    return CmdbObjectIdsFactory.createIdsList();
  }

  protected CmdbCollection<CmdbDataID> copyIDs(CmdbCollection<CmdbDataID> ids, int startFromIndex) {
    throw new IllegalStateException("you should not run copy ids - chunk size is always 1 ");
  }

  protected StringBuilder createInSqlStringForIdColumn(StringBuilder inSql) {
    return null;
  }

  protected StringBuilder createInSqlStringForEnd1IdColumn(StringBuilder inSql) {
    return null;
  }

  protected boolean useUnion() {
    return isRelationInFilter();
  }
}