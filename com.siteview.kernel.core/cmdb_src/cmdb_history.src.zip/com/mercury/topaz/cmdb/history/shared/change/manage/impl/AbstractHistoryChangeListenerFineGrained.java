package com.mercury.topaz.cmdb.history.shared.change.manage.impl;

import com.mercury.topaz.cmdb.history.client.change.manage.HistoryChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Subsystem;
import com.mercury.topaz.cmdb.shared.change.impl.AbstractCmdbChangeListener;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;

public abstract class AbstractHistoryChangeListenerFineGrained extends AbstractCmdbChangeListener
  implements HistoryChangeListenerFineGrained
{
  public AbstractHistoryChangeListenerFineGrained(CmdbCustomerID customerID)
  {
    super(FrameworkConstants.Subsystem.HISTORY, customerID);
  }
}