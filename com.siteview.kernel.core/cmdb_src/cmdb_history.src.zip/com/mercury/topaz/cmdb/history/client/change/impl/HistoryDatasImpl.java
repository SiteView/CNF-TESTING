package com.mercury.topaz.cmdb.history.client.change.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryData;
import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.cmdb.shared.util.iterator.impl.ReadOnlyIteratorImpl;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

class HistoryDatasImpl
  implements HistoryDatas
{
  private Map _historyDatas;

  public HistoryDatasImpl()
  {
    setHistoryDatas(new HashMap());
  }

  public void addHistoryData(HistoryData historyData) {
    getHistoryDatas().put(historyData.getId(), historyData);
  }

  public HistoryData getHistoryDataByID(CmdbDataID id) {
    return ((HistoryData)getHistoryDatas().get(id));
  }

  public ReadOnlyIterator getHistoryDatasIterator() {
    return new ReadOnlyIteratorImpl(getHistoryDatas().values().iterator());
  }

  public int size() {
    return getHistoryDatas().size();
  }

  private Map getHistoryDatas() {
    return this._historyDatas;
  }

  private void setHistoryDatas(Map historyDatas) {
    this._historyDatas = historyDatas;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (super.getClass() != o.getClass())) {
      return false;
    }

    HistoryDatasImpl that = (HistoryDatasImpl)o;

    if (this._historyDatas != null) if (this._historyDatas.equals(that._historyDatas)) break label62;
    label62: return (that._historyDatas == null);
  }

  public int hashCode()
  {
    return ((this._historyDatas != null) ? this._historyDatas.hashCode() : 0);
  }
}