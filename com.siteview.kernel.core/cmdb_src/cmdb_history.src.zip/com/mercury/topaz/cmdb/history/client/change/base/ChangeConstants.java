package com.mercury.topaz.cmdb.history.client.change.base;

public class ChangeConstants
{
  public static final class ATTRIBUTES
  {
    public static String DISPLAY_LABEL = "display_label";
    public static String LINK_TYPE = "link_type";
    public static String LINK_ID = "link_id";
    public static String END2_TYPE = "end2_type";
    public static String END2_DISPLAY_LABEL = "end2_display_label";
    public static String END2_ID = "end2_id";
    public static String ADDED_CI = "Add Related CI";
    public static String REMOVED_CI = "Remove Related CI";
    public static String REMOVED = "Removed";
  }

  public static final class CHANGE_TYPES
  {
    private static final String OBJECT_SUFFIX = "Object";
    private static final String LINK_SUFFIX = "Link";
    private static final String RELATION_SUFFIX = "Relation";
    public static String ADD_OBJECT = "AddObject";
    public static String UPDATE_OBJECT = "UpdateObject";
    public static String REMOVE_OBJECT = "RemoveObject";
    public static String ADD_LINK = "AddLink";
    public static String UPDATE_LINK = "UpdateLink";
    public static String REMOVE_LINK = "RemoveLink";
    public static String REMOVE_RELATION = "RemoveRelation";
    public static String ADD_RELATION = "AddRelation";
  }
}