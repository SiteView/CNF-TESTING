package com.mercury.topaz.cmdb.history.client.change.link;

import com.mercury.topaz.cmdb.history.client.change.HistoryChangeVisitor;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.history.client.change.info.HistoryLinkChangeInfo;
import com.mercury.topaz.cmdb.history.client.change.manage.HistoryChangeListenerFineGrained;

public class HistoryChangeRemoveLink extends AbstractLinkHistoryChange
{
  HistoryChangeRemoveLink(HistoryLinkChangeInfo historyLinkChangeInfo)
  {
    super(historyLinkChangeInfo);
  }

  public void accept(HistoryChangeVisitor historyChangeVisitor) {
    historyChangeVisitor.removeDataChange(getHistoryLinkChangeInfo());
    historyChangeVisitor.removeLinkChange(getHistoryLinkChangeInfo());
  }

  public void execute(HistoryChangeListenerFineGrained changeListener) {
    changeListener.onRemoveLink(getHistoryLinkChangeInfo());
  }

  public String toString() {
    return ChangeConstants.CHANGE_TYPES.REMOVE_LINK + ": " + super.toString();
  }
}