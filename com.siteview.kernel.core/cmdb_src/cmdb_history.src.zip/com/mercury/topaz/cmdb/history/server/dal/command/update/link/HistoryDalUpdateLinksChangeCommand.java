package com.mercury.topaz.cmdb.history.server.dal.command.update.link;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeConstants.CHANGE_TYPES;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import java.util.Date;

public class HistoryDalUpdateLinksChangeCommand extends AbstractHistoryDalLinkChangeCommand
{
  private static String EVENT_TYPE = ChangeConstants.CHANGE_TYPES.UPDATE_LINK;

  public HistoryDalUpdateLinksChangeCommand(Changer changer, Date changeDate, CmdbLink link)
  {
    super(changer, changeDate, link);
  }

  public HistoryDalUpdateLinksChangeCommand(Changer changer, Date changeDate, CmdbLinks links) {
    super(changer, changeDate, links);
  }

  protected String getEventType() {
    return EVENT_TYPE;
  }

  protected boolean shouldSaveChange() {
    return false;
  }
}