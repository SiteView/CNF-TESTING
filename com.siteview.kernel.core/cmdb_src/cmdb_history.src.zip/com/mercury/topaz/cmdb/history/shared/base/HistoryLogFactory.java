package com.mercury.topaz.cmdb.history.shared.base;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;

public class HistoryLogFactory
{
  public static Log getHistoryLog()
  {
    return LogFactory.getEasyLog("cmdb.history");
  }
}