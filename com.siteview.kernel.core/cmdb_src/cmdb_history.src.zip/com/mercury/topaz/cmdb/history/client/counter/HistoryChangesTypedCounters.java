package com.mercury.topaz.cmdb.history.client.counter;

public abstract interface HistoryChangesTypedCounters extends HistoryChangesCounters
{
  public abstract void add(HistoryChangesTypedCounter paramHistoryChangesTypedCounter);

  public abstract HistoryChangesTypedCounter getTypedCounter(String paramString);
}