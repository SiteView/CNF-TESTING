package com.mercury.topaz.cmdb.history.shared.layout;

import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.List;

public abstract interface SimpleDataLayout extends DataLayout
{
  public abstract void addKey(String paramString);

  public abstract ReadOnlyIterator<String> getKeysIterator();

  public abstract boolean contains(String paramString);

  public abstract int size();

  public abstract List<String> getKeys();

  public abstract boolean isAllKeys();

  public abstract void setAllKeys(boolean paramBoolean);
}