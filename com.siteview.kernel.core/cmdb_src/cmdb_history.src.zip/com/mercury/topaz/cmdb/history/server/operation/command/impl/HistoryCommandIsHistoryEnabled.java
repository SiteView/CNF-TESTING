package com.mercury.topaz.cmdb.history.server.operation.command.impl;

import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public class HistoryCommandIsHistoryEnabled extends AbstractHistoryCommand
{
  public static final String IS_HISTORY_ENABLED_KEY = "isHistoryDBEnabledKey";
  private Boolean _isHistoryDBEnabled;

  public String getOperationName()
  {
    return "History Command: Is History Enabled";
  }

  public void historyCommandExecute(HistoryUpdateManager historyUpdateManager, CmdbResponse response) throws CmdbException {
    boolean result = historyUpdateManager.isHistoryDBEnabled();
    response.addResult("isHistoryDBEnabledKey", Boolean.valueOf(result));
  }

  public void updateWithResponse(CmdbResponse response) {
    setHistoryDBEnabled((Boolean)response.getResult("isHistoryDBEnabledKey"));
  }

  public Boolean isHistoryDBEnabled() {
    return this._isHistoryDBEnabled;
  }

  private void setHistoryDBEnabled(Boolean historyDBEnabled) {
    this._isHistoryDBEnabled = historyDBEnabled;
  }
}