package com.mercury.topaz.cmdb.history.shared.filter.impl;

import com.mercury.topaz.cmdb.history.client.change.base.ChangeType;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import java.util.Date;

public class HistoryFilterFactory
{
  public static final HistoryFilter EMPTY_FILTER = new HistoryFilterImpl();

  public static HistoryFilter create()
  {
    return EMPTY_FILTER; }

  public static HistoryFilter create(Date fromDate, Date toDate, Changer changer) {
    return new HistoryFilterImpl(fromDate, toDate, changer);
  }

  public static HistoryFilter create(Date fromDate, Date toDate) {
    return new HistoryFilterImpl(fromDate, toDate);
  }

  public static HistoryFilter create(Date fromDate, Date toDate, Changer changer, ChangeType[] changeTypes) {
    return new HistoryFilterImpl(fromDate, toDate, changer, changeTypes);
  }

  public static HistoryFilter create(Date fromDate, Date toDate, Changer changer, ChangeType[] changeTypes, String[] classTypes) {
    return new HistoryFilterImpl(fromDate, toDate, changer, changeTypes, classTypes);
  }

  public static HistoryFilter create(Date fromDate, Date toDate, Changer changer, ChangeType[] changeTypes, String[] classTypes, String[] end2ClassTypes) {
    return new HistoryFilterImpl(fromDate, toDate, changer, changeTypes, classTypes, end2ClassTypes);
  }

  public static HistoryFilter create(Date fromDate, Date toDate, ChangeType[] changeTypes) {
    return new HistoryFilterImpl(fromDate, toDate, changeTypes);
  }

  public static HistoryFilter create(Changer changer, ChangeType[] changeTypes) {
    return new HistoryFilterImpl(changer, changeTypes);
  }

  public static HistoryFilter create(Changer changer) {
    return new HistoryFilterImpl(changer);
  }

  public static HistoryFilter create(ChangeType[] changeTypes) {
    return new HistoryFilterImpl(changeTypes);
  }

  public static HistoryFilter create(Date fromDate, Date toDate, String[] classTypes) {
    return new HistoryFilterImpl(fromDate, toDate, classTypes);
  }

  public static HistoryFilter create(String[] classTypes) {
    return new HistoryFilterImpl(classTypes);
  }
}