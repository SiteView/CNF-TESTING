package com.mercury.topaz.cmdb.history.client.counter;

public abstract interface HistoryChangesExtendedCounter extends HistoryChangesCounter
{
  public abstract int getAddedRelationCount();

  public abstract int getRemovedRelationCount();

  public abstract void setAddedRelationCount(int paramInt);

  public abstract void setRemovedRelationCount(int paramInt);
}