package com.mercury.topaz.cmdb.history.shared.operation.query.impl;

import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.base.HistoryConstants;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.impl.CmdbDatasFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import java.util.Date;

public class HistoryQueryGetDataLayout extends AbstractHistoryQueryOperation
{
  private static final String DATA_LAYOUT = "DATA_LAYOUT";
  private static final Date CURRENT_LAYOUT_DATE = new Date(HistoryConstants.MAX_END_DATE_NUMBER - 1L);
  private CmdbDatas _datasLayout;
  private CmdbIDsCollection _cmdbDataIDs;
  private Date _layoutDate;
  private DataLayout _dataLayout;
  private HistoryFilter _historyFilter;

  public HistoryQueryGetDataLayout(CmdbIDsCollection cmdbDataIDs, Date layoutDate, DataLayout dataLayout)
  {
    setCmdbDataIDs(cmdbDataIDs);
    setLayoutDate(layoutDate);
    setDataLayout(dataLayout);
  }

  public HistoryQueryGetDataLayout(HistoryFilter historyFilter, Date layoutDate, DataLayout dataLayout) {
    setHistoryFilter(historyFilter);
    setLayoutDate(layoutDate);
    setDataLayout(dataLayout);
  }

  public HistoryQueryGetDataLayout(CmdbIDsCollection cmdbDataIDs, DataLayout dataLayout) {
    this(cmdbDataIDs, CURRENT_LAYOUT_DATE, dataLayout);
  }

  public void historyQueryExecute(HistoryQueryManager historyQueryManager, CmdbResponse response) throws CmdbException
  {
    CmdbDatas cmdbDatas = null;

    if (getHistoryFilter() != null) {
      CmdbIDsCollection foundIDs = historyQueryManager.getIDsByHistoryFilter(getHistoryFilter());
      if ((foundIDs != null) && (foundIDs.size() > 0)) {
        cmdbDatas = historyQueryManager.getLayout(foundIDs, getLayoutDate(), getDataLayout());
      }
      else
        cmdbDatas = CmdbDatasFactory.create();
    }
    else
    {
      cmdbDatas = historyQueryManager.getLayout(getCmdbDataIDs(), getLayoutDate(), getDataLayout());
    }
    response.addResult("DATA_LAYOUT", cmdbDatas);
  }

  public void updateQueryWithResponse(CmdbResponse response) {
    setDatasLayout((CmdbDatas)response.getResult("DATA_LAYOUT"));
  }

  public CmdbDatas getDatasLayout() {
    return this._datasLayout;
  }

  private void setDatasLayout(CmdbDatas datasLayout) {
    this._datasLayout = datasLayout;
  }

  public String getOperationName() {
    return "history query: get data layout ";
  }

  private CmdbIDsCollection getCmdbDataIDs() {
    return this._cmdbDataIDs;
  }

  private void setCmdbDataIDs(CmdbIDsCollection cmdbDataIDs) {
    if ((cmdbDataIDs == null) || (cmdbDataIDs.isEmpty()))
      throw new IllegalArgumentException("data ids is null or empty");

    this._cmdbDataIDs = cmdbDataIDs;
  }

  private Date getLayoutDate() {
    return this._layoutDate;
  }

  private void setLayoutDate(Date layoutDate) {
    if (layoutDate == null)
      throw new IllegalArgumentException("layout date is null !!!");

    this._layoutDate = layoutDate;
  }

  private DataLayout getDataLayout() {
    return this._dataLayout;
  }

  private void setDataLayout(DataLayout dataLayout) {
    if (dataLayout == null)
      throw new IllegalArgumentException("data layout is null !!!");

    this._dataLayout = dataLayout;
  }

  private HistoryFilter getHistoryFilter() {
    return this._historyFilter;
  }

  private void setHistoryFilter(HistoryFilter historyFilter) {
    if (historyFilter == null)
      throw new IllegalArgumentException("history filter is null !!!");

    this._historyFilter = historyFilter;
  }
}