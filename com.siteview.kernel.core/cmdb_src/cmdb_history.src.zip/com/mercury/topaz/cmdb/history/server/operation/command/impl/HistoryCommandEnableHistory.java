package com.mercury.topaz.cmdb.history.server.operation.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;

public class HistoryCommandEnableHistory extends AbstractHistoryCommandEnableDisableHistory
{
  public String getOperationName()
  {
    return "history command: enable history DB";
  }

  protected void enableDisableHistory(HistoryUpdateManager historyUpdateManager) {
    historyUpdateManager.enableHistoryDB();
  }

  protected void writeLogMessage() {
    if (_logger.isInfoEnabled())
      _logger.info("History was enabled");
  }
}