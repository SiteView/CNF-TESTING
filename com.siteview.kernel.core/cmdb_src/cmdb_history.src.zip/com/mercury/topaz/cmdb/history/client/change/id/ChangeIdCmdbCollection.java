package com.mercury.topaz.cmdb.history.client.change.id;

import com.mercury.topaz.cmdb.shared.util.CmdbCollection;
import java.util.List;

public abstract interface ChangeIdCmdbCollection extends CmdbCollection<Long>
{
  public abstract void addChangeId(Long paramLong);

  public abstract List<Long> getChangeIds();
}