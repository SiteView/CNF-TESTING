package com.mercury.topaz.cmdb.history.server.upgrade;

import com.mercury.infra.config.idgen.IDGen;
import com.mercury.infra.config.idgen.IDGenManager;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.server.dal.command.impl.CmdbDalGenerateSequenceIDSimpleCommand;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalConnection;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalResultSet;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolFactory;
import com.mercury.topaz.cmdb.server.manage.dal.ConnectionPoolManager;
import com.mercury.topaz.cmdb.server.upgrade.impl.AbstractSubsystemManagerUpgrader;

public class HistoryIDGenUpgrader extends AbstractSubsystemManagerUpgrader
{
  public HistoryIDGenUpgrader(String fromVersion, String toVersion)
  {
    super(fromVersion, toVersion); }

  protected String getUpgraderName() {
    return "HistoryIDGenUpgrader";
  }

  protected String getSubsystemName() {
    return "HistoryUpdateManager";
  }

  public void preStartup() {
    IDGen idGen;
    ConnectionPoolManager historyConnectionManager = ConnectionPoolFactory.createHistoryPool(getLocalEnvironment());
    CmdbDalConnection connection = historyConnectionManager.getConnection();
    CmdbDalPreparedStatement selectStatement = null;
    CmdbDalPreparedStatement updateStatement = null;
    CmdbDalResultSet resultSet = null;
    try
    {
      String sqlQuery = "select max(ID)  from hist_events ";

      selectStatement = connection.prepareStatement4Select(sqlQuery);

      resultSet = selectStatement.executeQuery();

      int maxId = 1000000;
      if ((resultSet.next()) && (resultSet.getInt(1) != null)) {
        maxId = resultSet.getInt(1).intValue() + 1;
      }

      getLog().info("update history IDGen value to start with " + maxId);
      idGen = IDGenManager.init(CmdbDalGenerateSequenceIDSimpleCommand.GENERATOR_NAME_SPACE, "HistoryDB", maxId, false);
    }
    catch (Exception e)
    {
    }
    finally {
      if (resultSet != null)
        resultSet.close();

      if (selectStatement != null)
        selectStatement.close();

      if (updateStatement != null)
        updateStatement.close();
    }
  }

  public void postStartup()
  {
  }
}