package com.mercury.topaz.cmdb.history.shared.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.history.shared.base.HistoryConstants.TQL_RESULT;
import com.mercury.topaz.cmdb.history.shared.operation.query.impl.HistoryQueryGetLastUpdateTime;
import com.mercury.topaz.cmdb.history.shared.pattern.PatternObjectIDFactory;
import com.mercury.topaz.cmdb.server.manage.subsystem.SubsystemManager;
import com.mercury.topaz.cmdb.shared.change.CmdbChanges;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.changer.impl.ChangerFactory;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.notification.service.util.ChangesPublisher;
import com.mercury.topaz.cmdb.shared.tql.change.TqlNotificationData;
import com.mercury.topaz.cmdb.shared.tql.change.manage.AbstractTqlChangeListenerFineGrained;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.id.CmdbPatternID;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.tql.result.version.CmdbResultVersion;
import com.mercury.topaz.cmdb.shared.tql.result.version.CmdbVersion;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HistoryUpdateAddTqlResultChanges extends AbstractHistoryUpdateAddHistoryChanges
{
  private static final int TQL_RESULT_INITIAL_SIZE = -1;
  private static final Changer TQL_RESULT_CHANGER = ChangerFactory.createChanger("UCMDB", "Tql Calculation");
  private Map<CmdbPatternID, ChangeCounters> _changesCounters;

  public HistoryUpdateAddTqlResultChanges(CmdbChanges changes)
  {
    super(changes.getChanger(), changes);
    setChangesCounters(new HashMap());
    setChanger(TQL_RESULT_CHANGER);
  }

  public String getOperationName() {
    return "history update: add tql result changes";
  }

  protected void initializeCollections()
  {
    HistoryTqlChangeFineGrainedListener listener = new HistoryTqlChangeFineGrainedListener(this, getHistoryUpdateManager().getCustomerID());
    ChangesPublisher.publish(listener, getChanges());

    CmdbObjects changedTqls = CmdbObjectFactory.createObjects();
    CmdbObjects createdTqls = CmdbObjectFactory.createObjects();
    CmdbObjects tempTqls = CmdbObjectFactory.createObjects();
    CmdbDataIDs tempIds = CmdbDataIdsFactory.create();
    for (Iterator i$ = getChangesCounters().keySet().iterator(); i$.hasNext(); ) { CmdbPatternID patternId = (CmdbPatternID)i$.next();
      ChangeCounters counters = (ChangeCounters)getChangesCounters().get(patternId);

      CmdbProperties props = ChangeCounters.access$000(counters);
      if (counters.getAddedObjectsCount() != 0)
        props.add(createPropertyForCounter(HistoryConstants.TQL_RESULT.ADDED_OBJECTS_COUNTER_PROPERTY_NAME, counters.getAddedObjectsCount()));

      if (counters.getRemovedObjectsCount() != 0)
        props.add(createPropertyForCounter(HistoryConstants.TQL_RESULT.REMOVED_OBJECTS_COUNTER_PROPERTY_NAME, counters.getRemovedObjectsCount()));

      if (counters.getAddedLinksCount() != 0)
        props.add(createPropertyForCounter(HistoryConstants.TQL_RESULT.ADDED_LINKS_COUNTER_PROPERTY_NAME, counters.getAddedLinksCount()));

      if (counters.getRemovedLinksCount() != 0) {
        props.add(createPropertyForCounter(HistoryConstants.TQL_RESULT.REMOVED_LINKS_COUNTER_PROPERTY_NAME, counters.getRemovedLinksCount()));
      }

      if (props.size() > 0) {
        CmdbObjectID tqlObjectID = PatternObjectIDFactory.createObjectIDFromPatternID(patternId);

        CmdbObject tqlObject = CmdbObjectFactory.createObject(tqlObjectID, "tql_result", props);

        CmdbVersion version = counters.getVersion();

        if (version.getResultVersion().getVersionNumber() != 1L) {
          changedTqls.add(tqlObject);
        }
        else {
          tempTqls.add(tqlObject);
          tempIds.add((CmdbDataID)tqlObject.getID());
        }
      }

    }

    if (tempIds.size() > 0) {
      HistoryQueryGetLastUpdateTime getLastTime = new HistoryQueryGetLastUpdateTime(tempIds);
      getHistoryUpdateManager().executeOperation(getLastTime);
      Map results = getLastTime.getLastUpdateTime();

      ReadOnlyIterator tempIt = tempTqls.getObjectsIterator();
      while (tempIt.hasNext()) {
        CmdbObject curTql = (CmdbObject)tempIt.next();
        if (!(results.containsKey(curTql.getID())))
          createdTqls.add(curTql);
      }
    }

    setUpdatedObjects(changedTqls);
    setAddedObjects(createdTqls);

    if (_logger.isDebugEnabled()) {
      _logger.debug("The following tqls will be saved to history db as update: " + changedTqls);
      _logger.debug("The following tqls will be saved to history db as add: " + createdTqls);
    }
  }

  private CmdbProperty createPropertyForCounter(String propName, int value) {
    return CmdbPropertyFactory.createProperty(propName, Integer.valueOf(value));
  }

  protected void filterCollections()
  {
  }

  private ChangeCounters getChangeCountersByPattern(Pattern pattern, CmdbVersion version) {
    CmdbPatternID patternId = pattern.getID();
    ChangeCounters counters = (ChangeCounters)getChangesCounters().get(patternId);
    if (counters == null) {
      counters = new ChangeCounters(this, version);
      getChangesCounters().put(patternId, counters);
    }
    return counters;
  }

  private void addPropertyToPatternCounters(Pattern pattern, CmdbVersion version, CmdbProperty prop) {
    ChangeCounters counters = getChangeCountersByPattern(pattern, version);
    counters.addAdditionalProp(prop);
  }

  private void increasePatternAddedObjectsCount(Pattern pattern, CmdbVersion version, int count) {
    ChangeCounters counters = getChangeCountersByPattern(pattern, version);
    ChangeCounters.access$100(counters, counters.getAddedObjectsCount() + count);
  }

  private void increasePatternRemovedObjectsCount(Pattern pattern, CmdbVersion version, int count) {
    ChangeCounters counters = getChangeCountersByPattern(pattern, version);
    ChangeCounters.access$200(counters, counters.getRemovedObjectsCount() + count);
  }

  private void increasePatternAddedLinksCount(Pattern pattern, CmdbVersion version, int count) {
    ChangeCounters counters = getChangeCountersByPattern(pattern, version);
    ChangeCounters.access$300(counters, counters.getAddedLinksCount() + count);
  }

  private void increasePatternRemovedLinksCount(Pattern pattern, CmdbVersion version, int count) {
    ChangeCounters counters = getChangeCountersByPattern(pattern, version);
    ChangeCounters.access$400(counters, counters.getRemovedLinksCount() + count);
  }

  protected void sendNotifications(SubsystemManager subsystemManager)
  {
  }

  private Map<CmdbPatternID, ChangeCounters> getChangesCounters() {
    return this._changesCounters;
  }

  private void setChangesCounters(Map<CmdbPatternID, ChangeCounters> changesCounters) {
    if (changesCounters == null)
      throw new IllegalArgumentException("changes counters is null");

    this._changesCounters = changesCounters;
  }

  private class HistoryTqlChangeFineGrainedListener extends AbstractTqlChangeListenerFineGrained
  {
    public HistoryTqlChangeFineGrainedListener(, CmdbCustomerID paramCmdbCustomerID)
    {
      super(customerID);
    }

    public void onChunkedNotification(, Pattern pattern) {
      HistoryUpdateAddTqlResultChanges.access$500(this.this$0, pattern, cmdbVersion, -1);
      HistoryUpdateAddTqlResultChanges.access$600(this.this$0, pattern, cmdbVersion, -1);
      HistoryUpdateAddTqlResultChanges.access$700(this.this$0, pattern, cmdbVersion, -1);
      HistoryUpdateAddTqlResultChanges.access$800(this.this$0, pattern, cmdbVersion, -1);
      HistoryUpdateAddTqlResultChanges.access$900(this.this$0, pattern, cmdbVersion, CmdbPropertyFactory.createProperty("pattern_name", pattern.getID().getPatternName()));
    }

    public void onAdd()
    {
      int objectsSize = change.getChanges().objectsSize();
      if (objectsSize > 0) {
        HistoryUpdateAddTqlResultChanges.access$500(this.this$0, change.getPattern(), change.getVersion(), objectsSize);
      }

      int linksSize = change.getChanges().linksSize();
      if (linksSize > 0)
        HistoryUpdateAddTqlResultChanges.access$600(this.this$0, change.getPattern(), change.getVersion(), linksSize);
    }

    public void onRemove()
    {
      int objectsSize = change.getChanges().objectsSize();
      if (objectsSize > 0) {
        HistoryUpdateAddTqlResultChanges.access$700(this.this$0, change.getPattern(), change.getVersion(), objectsSize);
      }

      int linksSize = change.getChanges().linksSize();
      if (linksSize > 0)
        HistoryUpdateAddTqlResultChanges.access$800(this.this$0, change.getPattern(), change.getVersion(), linksSize);
    }

    public void onUpdate()
    {
    }

    public void onFinishDeployment()
    {
    }

    public void onStartDeployment()
    {
    }
  }

  private class ChangeCounters
  {
    private int _addedObjectsCount;
    private int _removedObjectsCount;
    private int _addedLinksCount;
    private int _removedLinksCount;
    private CmdbProperties _additionalProps;
    private CmdbVersion _version;

    public ChangeCounters(, CmdbVersion paramCmdbVersion)
    {
      setVersion(version);
      setRemovedObjectsCount(0);
      setAddedObjectsCount(0);
      setAddedLinksCount(0);
      setRemovedLinksCount(0);
      setAdditionalProps(CmdbPropertyFactory.createProperties());
    }

    public int getAddedObjectsCount() {
      return this._addedObjectsCount;
    }

    private void setAddedObjectsCount() {
      this._addedObjectsCount = addedObjectsCount;
    }

    public int getRemovedObjectsCount() {
      return this._removedObjectsCount;
    }

    private void setRemovedObjectsCount() {
      this._removedObjectsCount = removedObjectsCount;
    }

    public int getAddedLinksCount() {
      return this._addedLinksCount;
    }

    private void setAddedLinksCount() {
      this._addedLinksCount = addedLinksCount;
    }

    public int getRemovedLinksCount() {
      return this._removedLinksCount;
    }

    private void setRemovedLinksCount() {
      this._removedLinksCount = removedLinksCount;
    }

    public CmdbVersion getVersion() {
      return this._version;
    }

    private void setVersion() {
      this._version = version;
    }

    public void addAdditionalProp() {
      getAdditionalProps().add(prop);
    }

    private CmdbProperties getAdditionalProps() {
      return this._additionalProps;
    }

    private void setAdditionalProps() {
      this._additionalProps = additionalProps;
    }
  }
}