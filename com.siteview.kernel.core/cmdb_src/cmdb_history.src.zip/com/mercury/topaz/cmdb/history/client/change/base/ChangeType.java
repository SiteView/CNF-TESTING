package com.mercury.topaz.cmdb.history.client.change.base;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ChangeType
  implements Serializable
{
  public static Map _instances = new HashMap();
  public static final ChangeType ADD_OBJECT = new ChangeType(ChangeConstants.CHANGE_TYPES.ADD_OBJECT);
  public static final ChangeType UPDATE_OBJECT = new ChangeType(ChangeConstants.CHANGE_TYPES.UPDATE_OBJECT);
  public static final ChangeType REMOVE_OBJECT = new ChangeType(ChangeConstants.CHANGE_TYPES.REMOVE_OBJECT);
  public static final ChangeType ADD_LINK = new ChangeType(ChangeConstants.CHANGE_TYPES.ADD_LINK);
  public static final ChangeType UPDATE_LINK = new ChangeType(ChangeConstants.CHANGE_TYPES.UPDATE_LINK);
  public static final ChangeType REMOVE_LINK = new ChangeType(ChangeConstants.CHANGE_TYPES.REMOVE_LINK);
  public static final ChangeType ADD_RELATION = new ChangeType(ChangeConstants.CHANGE_TYPES.ADD_RELATION);
  public static final ChangeType REMOVE_RELATION = new ChangeType(ChangeConstants.CHANGE_TYPES.REMOVE_RELATION);
  private String _changeType;

  private ChangeType(String changerType)
  {
    setChangeType(changerType);
    _instances.put(getChangeType(), this);
  }

  protected Object doReadResolve() throws ObjectStreamException {
    return _instances.get(getChangeType());
  }

  private String getChangeType() {
    return this._changeType;
  }

  private void setChangeType(String changeType) {
    if (changeType == null)
      throw new IllegalArgumentException("change type is null!!!");

    this._changeType = changeType;
  }

  public String getType() {
    return getChangeType();
  }

  public static ChangeType getChangeTypeByString(String type) {
    return ((ChangeType)_instances.get(type));
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if (!(o instanceof ChangeType)) {
      return false;
    }

    ChangeType changeType = (ChangeType)o;

    if (this._changeType != null) if (this._changeType.equals(changeType._changeType)) break label54;
    label54: return (changeType._changeType == null);
  }

  public int hashCode()
  {
    return ((this._changeType != null) ? this._changeType.hashCode() : 0);
  }

  public String toString() {
    return getChangeType().toString();
  }
}