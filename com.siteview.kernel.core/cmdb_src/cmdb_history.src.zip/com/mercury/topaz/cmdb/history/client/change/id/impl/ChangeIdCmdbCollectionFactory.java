package com.mercury.topaz.cmdb.history.client.change.id.impl;

import com.mercury.topaz.cmdb.history.client.change.id.ChangeIdCmdbCollection;
import java.util.List;

public class ChangeIdCmdbCollectionFactory
{
  public static ChangeIdCmdbCollection createChangeIdCmdbCollection()
  {
    return new ChangeIdCmdbCollectionImpl(); }

  public static ChangeIdCmdbCollection createChangeIdCmdbCollection(List<Long> ids) {
    return new ChangeIdCmdbCollectionImpl(ids);
  }
}