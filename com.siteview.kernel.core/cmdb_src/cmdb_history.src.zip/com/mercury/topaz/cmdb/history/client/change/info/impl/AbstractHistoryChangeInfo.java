package com.mercury.topaz.cmdb.history.client.change.info.impl;

import com.mercury.topaz.cmdb.history.client.change.info.HistoryChangeInfo;
import com.mercury.topaz.cmdb.shared.bean.AbstractCmdbImmutableBean;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.digest.CmdbDigest;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.ObjectStreamException;
import java.util.Date;

abstract class AbstractHistoryChangeInfo extends AbstractCmdbImmutableBean
  implements HistoryChangeInfo
{
  private Date _changeTime;
  private Changer _changer;
  private CmdbProperties _layoutProperties;
  private CmdbProperties _previousValues;
  private Long _changeId;

  protected AbstractHistoryChangeInfo(Date changeTime, Changer changer, CmdbProperties layoutProperties, CmdbProperties previousValues)
  {
    setChangeTime(changeTime);
    setChanger(changer);
    setLayoutProperties(layoutProperties);
    setPreviousValues(previousValues);
  }

  protected AbstractHistoryChangeInfo(Date changeTime, Changer changer, CmdbProperties layoutProperties, CmdbProperties previousValues, Long changeId) {
    this(changeTime, changer, layoutProperties, previousValues);
    setChangeId(changeId);
  }

  public Object getPropertyPreviousValue(String key) {
    if ((getPreviousValues() != null) && 
      (getPreviousValues().contains(key))) {
      return getPreviousValues().get(key).getValue();
    }

    return null;
  }

  public Date getChangeTime() {
    return this._changeTime;
  }

  public void setChangeTime(Date changeTime) {
    if (changeTime == null)
      throw new IllegalArgumentException("change time is null");

    this._changeTime = changeTime;
  }

  public Changer getChanger() {
    return this._changer;
  }

  public void setChanger(Changer changer) {
    if (changer == null)
      throw new IllegalArgumentException("changer is null");

    this._changer = changer;
  }

  protected Object doReadResolve() throws ObjectStreamException {
    return this;
  }

  public CmdbDigest getDigest() {
    throw new UnsupportedOperationException("wasn't implemented");
  }

  public ReadOnlyIterator getLayoutPropertiesIterator() {
    return getLayoutProperties().getPropertiesIterator();
  }

  public int getLayoutPropertiesSize() {
    return ((getLayoutProperties() == null) ? 0 : getLayoutProperties().size());
  }

  public CmdbProperty getLayoutProperty(String key) {
    return getLayoutProperties().get(key);
  }

  public boolean hasLayoutProperty(String key) {
    return getLayoutProperties().contains(key);
  }

  private CmdbProperties getLayoutProperties() {
    return this._layoutProperties;
  }

  public void setLayoutProperties(CmdbProperties layoutProperties) {
    if (layoutProperties == null)
      throw new IllegalArgumentException("layout props is null");

    this._layoutProperties = layoutProperties;
  }

  private CmdbProperties getPreviousValues() {
    return this._previousValues;
  }

  public void setPreviousValues(CmdbProperties previousValues) {
    if (previousValues == null)
      throw new IllegalArgumentException("previous values is null");

    this._previousValues = previousValues;
  }

  public String toString() {
    StringBuilder desc = new StringBuilder();
    String ChangerStr = (getChanger() == null) ? "" : getChanger().toString();
    String ChangeTimeStr = getChangeTime() + "(" + getChangeTime().getTime() + ")";
    desc.append("Changer-").append(ChangerStr).append(". Time-").append(ChangeTimeStr).append(". Data-").append(getData()).append(".");

    return desc.toString();
  }

  public void setChangeId(Long id) {
    this._changeId = id;
  }

  public Long getChangeId() {
    return this._changeId;
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;

    if ((o == null) || (getClass() != o.getClass())) {
      return false;
    }

    AbstractHistoryChangeInfo that = (AbstractHistoryChangeInfo)o;

    if (this._changeId != null) if (this._changeId.equals(that._changeId)) break label62; 
    else if (that._changeId == null) break label62;
    return false;

    if (this._changeTime != null) label62: if (this._changeTime.equals(that._changeTime)) break label95; 
    else if (that._changeTime == null) break label95;
    return false;

    if (this._changer != null) label95: if (this._changer.equals(that._changer)) break label128; 
    else if (that._changer == null) break label128;
    return false;

    if (this._layoutProperties != null) label128: if (this._layoutProperties.equals(that._layoutProperties)) break label161; 
    else if (that._layoutProperties == null) break label161;
    return false;

    if (this._previousValues != null) label161: if (this._previousValues.equals(that._previousValues)) break label194;
    label194: return (that._previousValues == null);
  }

  public int hashCode()
  {
    int result = (this._changeTime != null) ? this._changeTime.hashCode() : 0;
    result = 29 * result + ((this._changer != null) ? this._changer.hashCode() : 0);
    result = 29 * result + ((this._layoutProperties != null) ? this._layoutProperties.hashCode() : 0);
    result = 29 * result + ((this._previousValues != null) ? this._previousValues.hashCode() : 0);
    result = 29 * result + ((this._changeId != null) ? this._changeId.hashCode() : 0);
    return result;
  }
}