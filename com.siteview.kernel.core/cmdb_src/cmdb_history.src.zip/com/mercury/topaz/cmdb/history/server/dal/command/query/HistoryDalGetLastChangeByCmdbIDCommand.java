package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.topaz.cmdb.history.client.change.HistoryChange;
import com.mercury.topaz.cmdb.history.client.change.HistoryChanges;
import com.mercury.topaz.cmdb.history.client.change.HistoryData;
import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.client.change.impl.HistoryChangesFactory;
import com.mercury.topaz.cmdb.history.client.change.impl.HistoryDataFactory;
import com.mercury.topaz.cmdb.history.client.change.impl.HistoryDatasFactory;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.SimpleDataLayout;
import com.mercury.topaz.cmdb.history.shared.layout.impl.DataLayoutFactory;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalPreparedStatement;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.id.CmdbIDsCollection;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.util.CmdbCollection;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.collections.MultiHashMap;
import org.apache.commons.collections.MultiMap;

public class HistoryDalGetLastChangeByCmdbIDCommand extends AbstractHistoryDalQueryHistoryChanges<HistoryDatas>
{
  private CmdbIDsCollection _cmdbDataIDs;

  public HistoryDalGetLastChangeByCmdbIDCommand(CmdbIDsCollection cmdbDataIDs, HistoryFilter historyFilter)
  {
    super(historyFilter);
    setCmdbDataID(cmdbDataIDs);
  }

  protected CmdbIDsCollection getCmdbDataIDs() {
    return this._cmdbDataIDs;
  }

  private void setCmdbDataID(CmdbIDsCollection cmdbDataIDs) {
    if ((cmdbDataIDs == null) || (cmdbDataIDs.size() == 0))
      throw new IllegalArgumentException("cmdb data ids is null or empty");

    this._cmdbDataIDs = cmdbDataIDs;
  }

  protected void createIDTempTable() throws SQLException
  {
    createCmdbIDTempTable(getConnection(), elementsToIDsAsBytes(getCmdbDataIDs()));
  }

  protected StringBuilder createInSqlStringForIdTempTable() {
    return createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", "e", HISTORY_CHANGES_CI_ID_COLUMN_NAME);
  }

  protected StringBuilder createInSqlStringForEnd1IdTempTable() {
    return createInSqlStringForTempTable("CDM_TMP_OBJID", "CMDB_ID", "e", HISTORY_CHANGES_END1_COLUMN_NAME);
  }

  protected void addIdsToInList(CmdbCollection dataIDs, List variables, int numOfIDs) {
    addCmdbIdsToInList((CmdbIDsCollection)dataIDs, variables, numOfIDs);
  }

  protected void fillPreparedStatementWithIDs(CmdbDalPreparedStatement preparedStatement, List variables) throws SQLException {
    for (Iterator i$ = variables.iterator(); i$.hasNext(); ) { Object variable = i$.next();
      preparedStatement.setBytes((byte[])(byte[])variable);
    }
  }

  protected CmdbCollection getFilterIDs() {
    return getCmdbDataIDs();
  }

  protected CmdbCollection copyIDs(CmdbCollection ids, int startFromIndex) {
    return removeIDsFromCollection((CmdbIDsCollection)ids, startFromIndex);
  }

  protected StringBuilder getCustomizeWhereClauseForEventsQueryPart1()
  {
    StringBuilder whereQuery = new StringBuilder(" and e.").append(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME).append(" in (select max(").append(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME).append(") from ").append(HISTORY_CHANGES_TABLE_NAME).append(" e2 where e2.").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME).append("=e.").append(HISTORY_CHANGES_CI_ID_COLUMN_NAME);

    whereQuery.append(super.getCustomizeWhereClauseForEventsQueryPart1());
    whereQuery.append(" and ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?");
    whereQuery.append(")");

    return whereQuery;
  }

  protected StringBuilder getCustomizeWhereClauseForEventsQueryPart2() {
    StringBuilder whereQuery = new StringBuilder(" and e.").append(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME).append(" in (select max(").append(HISTORY_CHANGES_CHANGE_ID_COLUMN_NAME).append(") from ").append(HISTORY_CHANGES_TABLE_NAME).append(" e2 where e2.").append(HISTORY_CHANGES_END1_COLUMN_NAME).append("=e.").append(HISTORY_CHANGES_END1_COLUMN_NAME);

    whereQuery.append(super.getCustomizeWhereClauseForEventsQueryPart2());
    whereQuery.append(" and ").append(HISTORY_CHANGES_CUSTOMER_ID_COLUMN_NAME).append("=?");
    whereQuery.append(")");

    return whereQuery;
  }

  protected void fillCustomPreparedStatementForEventsQueryPart1(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    super.fillCustomPreparedStatementForEventsQueryPart1(preparedStatement);
    preparedStatement.setInt(getCustomerID().getID());
  }

  protected void fillCustomPreparedStatementForEventsQueryPart2(CmdbDalPreparedStatement preparedStatement) throws SQLException {
    super.fillCustomPreparedStatementForEventsQueryPart2(preparedStatement);
    preparedStatement.setInt(getCustomerID().getID());
  }

  protected HistoryDatas perform() throws Exception
  {
    return queryTables(DataLayoutFactory.createFullDataLayout());
  }

  protected void validateInput()
  {
  }

  protected HistoryDatas createHistoryChangesFromMap(Map<Long, AbstractHistoryDalQueryHistoryChanges<HistoryDatas>.DataChanges> changeIDChanges, List<Long> changeIDsOrderByDate, SimpleDataLayout simpleDataLayout)
  {
    HistoryDatas historyDatas = HistoryDatasFactory.create();

    if (changeIDsOrderByDate.size() > 0)
    {
      Map dataChangesByDataID = new HashMap();
      for (Iterator i$ = changeIDsOrderByDate.iterator(); i$.hasNext(); ) { Long changeID = (Long)i$.next();
        AbstractHistoryDalQueryHistoryChanges.DataChanges dataChanges = (AbstractHistoryDalQueryHistoryChanges.DataChanges)changeIDChanges.get(changeID);
        CmdbDataID curDataID = dataChanges.getDataID();
        dataChangesByDataID.put(curDataID, dataChanges);
      }

      Map datasMap = new HashMap();
      CmdbDataIDs idsForLayout = CmdbDataIdsFactory.create();
      MultiMap idsToDatesMap = new MultiHashMap();
      for (Iterator i$ = dataChangesByDataID.keySet().iterator(); i$.hasNext(); ) { CmdbDataID curDataID = (CmdbDataID)i$.next();
        AbstractHistoryDalQueryHistoryChanges.DataChanges dataChanges = (AbstractHistoryDalQueryHistoryChanges.DataChanges)dataChangesByDataID.get(curDataID);
        if (dataChanges != null) {
          Date layoutDate = new Date(dataChanges.getChangeDate().getTime() - 1L);
          idsToDatesMap.put(curDataID, layoutDate);
          idsForLayout.add(curDataID);
        }
      }
      HistoryDalGetDataLayoutInDifferentDatesCommand getLayout = new HistoryDalGetDataLayoutInDifferentDatesCommand(idsToDatesMap, idsForLayout, simpleDataLayout);
      CmdbDalCommandResult result = getLayout.execute();
      CmdbDatas datas = (CmdbDatas)result.getResult();
      ReadOnlyIterator datasIt = datas.getDatasIterator();
      while (datasIt.hasNext()) {
        CmdbData curData = (CmdbData)datasIt.next();
        datasMap.put(curData.getDataID(), curData);
      }

      for (Iterator i$ = dataChangesByDataID.keySet().iterator(); i$.hasNext(); ) { CmdbDataID cmdbDataID = (CmdbDataID)i$.next();
        HistoryChanges historyChanges = HistoryChangesFactory.createHistoryChanges();
        CmdbData initialData = (CmdbData)datasMap.get(cmdbDataID);
        AbstractHistoryDalQueryHistoryChanges.DataChanges dataChanges = (AbstractHistoryDalQueryHistoryChanges.DataChanges)dataChangesByDataID.get(cmdbDataID);
        if (dataChanges != null) {
          CmdbProperties oldProperties = CmdbPropertyFactory.createProperties();
          if (initialData != null) {
            ReadOnlyIterator propsIt = initialData.getPropertiesIterator();
            while (propsIt.hasNext())
              oldProperties.add((CmdbProperty)propsIt.next());
          }

          HistoryChange historyChange = dataChanges.createHistoryChangeFromChanges(oldProperties);
          if (historyChange != null) {
            historyChanges.add(historyChange);
            HistoryData historyData = HistoryDataFactory.create(cmdbDataID, initialData, historyChanges);
            historyDatas.addHistoryData(historyData);
          }
        }
      }
    }
    return historyDatas; }

  protected StringBuilder createInSqlStringForIdColumn(StringBuilder inSql) {
    return createInSqlString("e", HISTORY_CHANGES_CI_ID_COLUMN_NAME, inSql);
  }

  protected StringBuilder createInSqlStringForEnd1IdColumn(StringBuilder inSql) {
    return createInSqlString("e", HISTORY_CHANGES_END1_COLUMN_NAME, inSql);
  }

  protected boolean useUnion() {
    return isRelationInFilter();
  }

  protected boolean shouldGetChangeDate() {
    return true;
  }

  protected boolean shouldGetChanger() {
    return true;
  }

  protected boolean shouldGetEnd2Info() {
    return true;
  }

  protected boolean shouldGetPrevValue() {
    return true;
  }
}