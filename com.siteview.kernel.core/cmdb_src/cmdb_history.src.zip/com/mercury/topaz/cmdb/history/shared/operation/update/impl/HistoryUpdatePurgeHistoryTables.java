package com.mercury.topaz.cmdb.history.shared.operation.update.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.dal.dao.CmdbDalHistoryDAO;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.server.base.cfg.SettingsReader;
import com.mercury.topaz.cmdb.server.util.time.CmdbTime;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import java.util.Calendar;
import java.util.Date;

public class HistoryUpdatePurgeHistoryTables extends AbstractHistoryUpdate
{
  private Date _lastDateToSave;

  public HistoryUpdatePurgeHistoryTables(int daysToSaveBack)
  {
    setLastDateAccordingToSavedDays(daysToSaveBack);
  }

  public String getOperationName() {
    return "history update - purge history tables";
  }

  public void historyUpdateExecute(HistoryUpdateManager historyUpdateManager, CmdbResponse response)
    throws CmdbException
  {
    if (getLastDateToSave() == null) {
      int daysToSaveBack = historyUpdateManager.getLocalSettings().getInt("history.purging.days.to.save.back", 90);
      setLastDateAccordingToSavedDays(daysToSaveBack);
    }
    if (_logger.isInfoEnabled())
      _logger.info("Purging will be done. The last date that will be saved is: " + getLastDateToSave());

    historyUpdateManager.getHistoryDAO().purgeHistoryTables(getLastDateToSave());
  }

  private void setLastDateAccordingToSavedDays(int daysToSaveBack) {
    Date currentDate = new Date(CmdbTime.currentTimeMillis());
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(currentDate);
    calendar.add(5, -daysToSaveBack);
    setLastDateToSave(calendar.getTime());
  }

  private Date getLastDateToSave() {
    return this._lastDateToSave;
  }

  private void setLastDateToSave(Date lastDateToSave) {
    if (lastDateToSave == null)
      throw new IllegalArgumentException("last date to save is null");

    this._lastDateToSave = lastDateToSave;
  }
}