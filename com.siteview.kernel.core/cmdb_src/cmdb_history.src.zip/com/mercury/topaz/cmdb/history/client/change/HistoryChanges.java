package com.mercury.topaz.cmdb.history.client.change;

import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.io.Serializable;

public abstract interface HistoryChanges extends Serializable
{
  public abstract ReadOnlyIterator getChangesIterator();

  public abstract void add(HistoryChange paramHistoryChange);

  public abstract int size();
}