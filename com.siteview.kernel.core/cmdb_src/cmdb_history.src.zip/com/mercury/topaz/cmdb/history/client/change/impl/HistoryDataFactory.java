package com.mercury.topaz.cmdb.history.client.change.impl;

import com.mercury.topaz.cmdb.history.client.change.HistoryChanges;
import com.mercury.topaz.cmdb.history.client.change.HistoryData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;

public class HistoryDataFactory
{
  public static HistoryData create(CmdbDataID id, CmdbData initialData, HistoryChanges historyChanges)
  {
    return new HistoryDataImpl(id, initialData, historyChanges);
  }
}