package com.mercury.topaz.cmdb.history.server.rawevent.listener;

import com.mercury.topaz.cmdb.shared.change.CmdbChangeListenerFineGrained;

public abstract interface ModelChangeListenerFineGrained extends CmdbChangeListenerFineGrained
{
}