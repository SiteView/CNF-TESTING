package com.mercury.topaz.cmdb.history.server.dal.command.update.object;

import com.mercury.topaz.cmdb.history.server.dal.command.update.AbstractHistoryDalAddChangeCommand;
import com.mercury.topaz.cmdb.shared.model.changer.Changer;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.impl.CmdbObjectFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Date;

public abstract class AbstractHistoryDalObjectChangeCommand extends AbstractHistoryDalAddChangeCommand<CmdbObject>
{
  private CmdbObjects _objects;

  public AbstractHistoryDalObjectChangeCommand(Changer changer, Date changeDate, CmdbObjects objects)
  {
    super(changer, changeDate);
    setObjects(objects);
  }

  public AbstractHistoryDalObjectChangeCommand(Changer changer, Date changeDate, CmdbObject object) {
    super(changer, changeDate);
    CmdbObjects objects = CmdbObjectFactory.createObjects();
    objects.add(object);
    setObjects(objects);
  }

  protected boolean isObject() {
    return true;
  }

  protected ReadOnlyIterator<CmdbObject> getDatasIterator() {
    return getObjects().getObjectsIterator();
  }

  protected CmdbDataID getEnd1(CmdbObject data) {
    return null;
  }

  protected CmdbDataID getEnd2(CmdbObject data) {
    return null;
  }

  protected CmdbObjects getObjects() {
    return this._objects;
  }

  private void setObjects(CmdbObjects objects) {
    this._objects = objects;
  }
}