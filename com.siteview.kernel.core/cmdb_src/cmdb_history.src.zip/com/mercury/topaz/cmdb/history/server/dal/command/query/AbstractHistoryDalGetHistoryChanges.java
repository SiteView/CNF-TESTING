package com.mercury.topaz.cmdb.history.server.dal.command.query;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.client.change.HistoryChange;
import com.mercury.topaz.cmdb.history.client.change.HistoryChanges;
import com.mercury.topaz.cmdb.history.client.change.HistoryData;
import com.mercury.topaz.cmdb.history.client.change.HistoryDatas;
import com.mercury.topaz.cmdb.history.client.change.base.ChangeType;
import com.mercury.topaz.cmdb.history.client.change.impl.HistoryChangesFactory;
import com.mercury.topaz.cmdb.history.client.change.impl.HistoryDataFactory;
import com.mercury.topaz.cmdb.history.client.change.impl.HistoryDatasFactory;
import com.mercury.topaz.cmdb.history.shared.filter.HistoryFilter;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayout;
import com.mercury.topaz.cmdb.history.shared.layout.DataLayoutVisitor;
import com.mercury.topaz.cmdb.history.shared.layout.SimpleDataLayout;
import com.mercury.topaz.cmdb.server.manage.dal.CmdbDalCommandResult;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.data.CmdbDatas;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataID;
import com.mercury.topaz.cmdb.shared.model.data.id.CmdbDataIDs;
import com.mercury.topaz.cmdb.shared.model.data.id.impl.CmdbDataIdsFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.collections.MultiHashMap;
import org.apache.commons.collections.MultiMap;

public abstract class AbstractHistoryDalGetHistoryChanges extends AbstractHistoryDalQueryHistoryChanges<HistoryDatas>
{
  private DataLayout _dataLayout;

  public AbstractHistoryDalGetHistoryChanges(HistoryFilter historyFilter, DataLayout dataLayout)
  {
    super(historyFilter);
    setDataLayout(dataLayout);
  }

  private void setDataLayout(DataLayout dataLayout) {
    if (dataLayout == null)
      throw new IllegalArgumentException("data layout is null");

    this._dataLayout = dataLayout;
  }

  protected DataLayout getDataLayout()
  {
    return this._dataLayout;
  }

  protected HistoryDatas perform() throws Exception {
    QueryTablesByLayoutVisitor queryVisitor = new QueryTablesByLayoutVisitor(this, null);
    getDataLayout().accept(queryVisitor);
    return QueryTablesByLayoutVisitor.access$100(queryVisitor);
  }

  protected void validateInput()
  {
  }

  protected HistoryDatas createHistoryChangesFromMap(Map<Long, AbstractHistoryDalQueryHistoryChanges<HistoryDatas>.DataChanges> changeIDChanges, List<Long> changeIDsOrderByDate, SimpleDataLayout simpleDataLayout)
  {
    List changes;
    HistoryDatas historyDatas = HistoryDatasFactory.create();

    if (changeIDsOrderByDate.size() == 0) {
      return historyDatas;
    }

    Map dataChangesByDataID = mapDataIDsToDataChanges(changeIDsOrderByDate, changeIDChanges);

    Map datasMap = new HashMap();
    if ((getDataLayout().isIncludePrevValue()) || (getDataLayout().isAllLayer())) {
      CmdbDataIDs idsForLayout = CmdbDataIdsFactory.create();
      MultiMap idsToDatesMap = new MultiHashMap();
      for (Iterator i$ = dataChangesByDataID.keySet().iterator(); i$.hasNext(); ) { CmdbDataID dataID = (CmdbDataID)i$.next();
        changes = (List)dataChangesByDataID.get(dataID);
        Date layoutDate = null;
        boolean objectAdditionFound = false;
        for (Iterator i$ = changes.iterator(); i$.hasNext(); ) { AbstractHistoryDalQueryHistoryChanges.DataChanges change = (AbstractHistoryDalQueryHistoryChanges.DataChanges)i$.next();
          if (change.getChangeType().equals(ChangeType.ADD_OBJECT.getType())) {
            objectAdditionFound = true;
            break;
          }

          layoutDate = change.getChangeDate();
          if (change.getChangeType().equals(ChangeType.UPDATE_OBJECT.getType())) {
            layoutDate = new Date(change.getChangeDate().getTime() - 1L);
            break;
          }
        }

        if (!(objectAdditionFound)) {
          idsToDatesMap.put(dataID, layoutDate);
          idsForLayout.add(dataID);
        }
      }
      HistoryDalGetDataLayoutInDifferentDatesCommand getLayout = new HistoryDalGetDataLayoutInDifferentDatesCommand(idsToDatesMap, idsForLayout, simpleDataLayout);
      CmdbDalCommandResult result = getLayout.execute();
      CmdbDatas datas = (CmdbDatas)result.getResult();
      ReadOnlyIterator datasIt = datas.getDatasIterator();
      while (datasIt.hasNext()) {
        CmdbData curData = (CmdbData)datasIt.next();
        datasMap.put(curData.getDataID(), curData);
      }
    }

    for (Iterator i$ = dataChangesByDataID.keySet().iterator(); i$.hasNext(); ) { CmdbDataID cmdbDataID = (CmdbDataID)i$.next();
      HistoryChanges historyChanges = HistoryChangesFactory.createHistoryChanges();
      CmdbData initialData = (CmdbData)datasMap.get(cmdbDataID);
      changes = (List)dataChangesByDataID.get(cmdbDataID);
      CmdbProperties oldProperties = CmdbPropertyFactory.createProperties();
      if (initialData != null) {
        ReadOnlyIterator propsIt = initialData.getPropertiesIterator();
        while (propsIt.hasNext())
          oldProperties.add((CmdbProperty)propsIt.next());
      }

      for (Iterator i$ = changes.iterator(); i$.hasNext(); ) { AbstractHistoryDalQueryHistoryChanges.DataChanges dataChanges = (AbstractHistoryDalQueryHistoryChanges.DataChanges)i$.next();
        HistoryChange historyChange = dataChanges.createHistoryChangeFromChanges(oldProperties);
        if (historyChange != null)
          historyChanges.add(historyChange);
      }

      if (historyChanges.size() > 0) {
        HistoryData historyData = HistoryDataFactory.create(cmdbDataID, initialData, historyChanges);
        historyDatas.addHistoryData(historyData);
      }
    }
    return historyDatas;
  }

  private Map<CmdbDataID, List<AbstractHistoryDalQueryHistoryChanges<HistoryDatas>.DataChanges>> mapDataIDsToDataChanges(List<Long> changeIDsOrderByDate, Map<Long, AbstractHistoryDalQueryHistoryChanges<HistoryDatas>.DataChanges> changeIDChanges) {
    Map dataChangesByDataID = new HashMap();
    for (Iterator i$ = changeIDsOrderByDate.iterator(); i$.hasNext(); ) { Long changeID = (Long)i$.next();
      AbstractHistoryDalQueryHistoryChanges.DataChanges dataChanges = (AbstractHistoryDalQueryHistoryChanges.DataChanges)changeIDChanges.get(changeID);
      CmdbDataID dataID = dataChanges.getDataID();
      if (!(dataChangesByDataID.containsKey(dataID)))
        dataChangesByDataID.put(dataID, new ArrayList());

      ((List)dataChangesByDataID.get(dataID)).add(dataChanges);
    }
    return dataChangesByDataID;
  }

  protected boolean shouldGetChangeDate()
  {
    return ((getDataLayout().isIncludeChangeDate()) || (getDataLayout().isAllLayer()) || (getDataLayout().isIncludePrevValue()));
  }

  protected boolean shouldGetChanger() {
    return ((getDataLayout().isIncludeChanger()) || (getDataLayout().isAllLayer()));
  }

  protected boolean shouldGetEnd2Info() {
    return ((getDataLayout().isIncludeEnd2Info()) || (getDataLayout().isAllLayer()));
  }

  protected boolean shouldGetPrevValue() {
    return ((getDataLayout().isIncludePrevValue()) || (getDataLayout().isAllLayer()));
  }

  private class QueryTablesByLayoutVisitor
  implements DataLayoutVisitor
  {
    private HistoryDatas _historyDatas;

    public void visitSimpleLayout() {
      HistoryDatas historyDatas = HistoryDatasFactory.create();
      try {
        historyDatas = this.this$0.queryTables(simpleDataLayout);
      }
      catch (SQLException e) {
        AbstractHistoryDalGetHistoryChanges.access$200().error("Error while trying to get history changes: " + e);
      }
      setHistoryDatas(historyDatas);
    }

    private HistoryDatas getHistoryDatas() {
      return this._historyDatas;
    }

    private void setHistoryDatas() {
      this._historyDatas = historyDatas;
    }
  }
}