package com.mercury.topaz.cmdb.history.server.operation.command.impl;

import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.history.server.manager.HistoryManager;
import com.mercury.topaz.cmdb.history.server.manager.HistoryUpdateManager;
import com.mercury.topaz.cmdb.history.server.operation.command.HistoryCommand;
import com.mercury.topaz.cmdb.history.shared.base.HistoryLogFactory;
import com.mercury.topaz.cmdb.history.shared.operation.impl.AbstractHistoryOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;

public abstract class AbstractHistoryCommand extends AbstractHistoryOperation
  implements HistoryCommand
{
  protected static Log _logger = HistoryLogFactory.getHistoryLog();

  public final void historyExecute(HistoryManager historyManager, CmdbResponse response)
    throws CmdbException
  {
    historyCommandExecute((HistoryUpdateManager)historyManager, response);
  }

  public String getExecutionTaskQueueName() {
    return "History Update Task";
  }
}