package com.mercury.topaz.cmdb.history.shared.operation.query;

import com.mercury.topaz.cmdb.history.server.manager.HistoryQueryManager;
import com.mercury.topaz.cmdb.history.shared.operation.HistoryOperation;
import com.mercury.topaz.cmdb.shared.base.CmdbException;
import com.mercury.topaz.cmdb.shared.manage.CmdbResponse;
import com.mercury.topaz.cmdb.shared.manage.operation.query.CmdbQuery;

public abstract interface HistoryQuery
{
  public abstract void historyQueryExecute(HistoryQueryManager paramHistoryQueryManager, CmdbResponse paramCmdbResponse)
    throws CmdbException;
}