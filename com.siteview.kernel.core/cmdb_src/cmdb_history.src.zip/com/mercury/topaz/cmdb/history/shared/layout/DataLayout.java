package com.mercury.topaz.cmdb.history.shared.layout;

public abstract interface DataLayout
{
  public abstract void accept(DataLayoutVisitor paramDataLayoutVisitor);

  public abstract boolean isAllLayer();

  public abstract void setAllLayer(boolean paramBoolean);

  public abstract boolean isIncludePrevValue();

  public abstract void setIncludePrevValue(boolean paramBoolean);

  public abstract boolean isIncludeChangeDate();

  public abstract void setIncludeChangeDate(boolean paramBoolean);

  public abstract boolean isIncludeChanger();

  public abstract void setIncludeChanger(boolean paramBoolean);

  public abstract boolean isIncludeEnd2Info();

  public abstract void setIncludeEnd2Info(boolean paramBoolean);
}