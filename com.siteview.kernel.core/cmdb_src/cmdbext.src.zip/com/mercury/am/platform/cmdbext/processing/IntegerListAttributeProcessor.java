package com.mercury.am.platform.cmdbext.processing;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyValuesFactory;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbIntegerPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;

public class IntegerListAttributeProcessor extends TypedListAttributeProcessor
{
  public IntegerListAttributeProcessor()
  {
    super(CmdbIntegerPropertyValues.class);
  }

  protected void addValueToProperties(String value, CmdbPropertyValues values)
  {
    ((CmdbIntegerPropertyValues)values).add(new Integer(value));
  }

  protected CmdbPropertyValues createPropertyValueByType() {
    return CmdbPropertyValuesFactory.createCmdbIntegerPropertyValues();
  }

  protected String getErrorCode(CmdbAttribute attribute) {
    return "processor.error.not.integer.list";
  }
}