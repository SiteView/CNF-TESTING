package com.mercury.am.platform.cmdbext.validation.attribute;

import com.mercury.am.platform.cmdbext.validation.utils.ValidationUtils;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbListEntry;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public class ListAttributeValueValidator extends DefaultAttributeValueValidator
{
  public void validateType(CmdbAttribute attribute, Object value)
    throws AttributeTypeValidationException
  {
    ValidationUtils.validateAttributeType(attribute, CmdbList.class, value);

    CmdbList cmdbList = (CmdbList)attribute.getResolvedType();
    Class javaClass = new DefaultAttributeValueValidator.CmdbType2JavaClassConverter(this, cmdbList.getType()).getJavaClass();
    if ((value != null) && (((javaClass == null) || (!(javaClass.isInstance(value))))))
      throw ValidationUtils.createAttributeTypeValidationException(attribute, value, value.getClass(), javaClass);
  }

  public void validateNew(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, BasicUserData user)
    throws AttributeValidationException
  {
    validate(attribute, containerClass, value, attributeValues, null, user);
  }

  public void validateUpdated(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, CmdbData cmdbData, BasicUserData user)
    throws AttributeValidationException
  {
    validate(attribute, containerClass, value, attributeValues, cmdbData, user);
  }

  private void validate(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, CmdbData cmdbData, BasicUserData user) throws AttributeValidationException {
    if (value == null)
      return;

    validateType(attribute, value);

    CmdbList cmdbList = (CmdbList)attribute.getResolvedType();

    for (ReadOnlyIterator iterator = cmdbList.getValuesIterator(); iterator.hasNext(); ) {
      CmdbListEntry listEntry = (CmdbListEntry)iterator.next();
      if (value.toString().equals(listEntry.getListValue().toString()))
      {
        if (cmdbData == null)
          super.validateNew(attribute, containerClass, value, attributeValues, user);
        else
          super.validateUpdated(attribute, containerClass, value, attributeValues, cmdbData, user);

        return;
      }
    }

    throw ValidationUtils.createAttributeValidationException("cmdb.validation.WRONG_LIST_VALUE", attribute, value);
  }
}