package com.mercury.am.platform.cmdbext.validation.classes;

import com.mercury.am.platform.cmdbext.validation.attribute.AttributeValidationException;
import com.mercury.am.platform.cmdbext.validation.attribute.AttributeValueValidator;
import com.mercury.am.platform.cmdbext.validation.attribute.AttributeValueValidatorFactory;
import com.mercury.am.platform.cmdbext.validation.attribute.CustomAttributeValueValidator;
import com.mercury.am.platform.cmdbext.validation.classes.qualifier.QualifierValidator;
import com.mercury.am.platform.cmdbext.validation.classes.qualifier.QualifierValidatorFactory;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbClassQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbClassQualifiers;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

public class DefaultClassValidator
  implements ClassValidator
{
  private static Log LOGGER = LogFactory.getEasyLog(DefaultClassValidator.class);

  public void validateNew(Map attributeValues, CmdbClassModel classModel, CmdbClass cmdbClass, BasicUserData user)
    throws ClassValidationException, NullPointerException
  {
    if (LOGGER.isInfoEnabled())
      LOGGER.info("Start call to validateNew: attributes values = " + ((attributeValues == null) ? "null" : attributeValues.toString()) + " , cmdb class = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()) + " , user = " + ((user == null) ? "null" : user.toString()));

    validate(classModel, attributeValues, cmdbClass, null, user);
  }

  public void validateUpdated(Map attributeValues, CmdbClassModel classModel, CmdbClass cmdbClass, CmdbData toUpdate, BasicUserData user)
    throws ClassValidationException, NullPointerException
  {
    if (LOGGER.isInfoEnabled())
      LOGGER.info("Start call to validateUpdated: attributes values = " + ((attributeValues == null) ? "null" : attributeValues.toString()) + " , cmdb class = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()) + " , user = " + ((user == null) ? "null" : user.toString()) + " updated data = " + ((toUpdate == null) ? "null" : toUpdate.toString()));

    validate(classModel, attributeValues, cmdbClass, toUpdate, user);
  }

  private void validate(CmdbClassModel classModel, Map attributeValues, CmdbClass cmdbClass, CmdbData toUpdate, BasicUserData user) throws ClassValidationException, NullPointerException
  {
    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start call to validate: attributes values = " + ((attributeValues == null) ? "null" : attributeValues.toString()) + " , cmdb class = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()) + " , user = " + ((user == null) ? "null" : user.toString()) + " updated data = " + ((toUpdate == null) ? "null" : toUpdate.toString()));
    }

    Vector attributeExceptions = new Vector();
    Vector invalidClassQualifiers = new Vector();

    CmdbClassQualifiers classQualifiers = cmdbClass.getClassQualifiers();
    if (classQualifiers != null)
      for (ReadOnlyIterator iterator = classQualifiers.getIterator(); iterator.hasNext(); ) {
        CmdbClassQualifier qualifier = null;
        qualifier = (CmdbClassQualifier)iterator.next();

        QualifierValidator validator = QualifierValidatorFactory.createQualifierValidator(qualifier);
        if (validator != null)
          try
          {
            if (toUpdate == null)
              validator.validateNew(qualifier, cmdbClass, classModel, attributeValues);
            else
              validator.validateUpdated(qualifier, cmdbClass, classModel, attributeValues, toUpdate);
          } catch (ClassValidationException ex) {
            if (LOGGER.isDebugEnabled())
              LOGGER.debug("Data is not valid according to class qualifier: qualifier = " + ((qualifier == null) ? "null" : qualifier.getName()) + " , cmdb class = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()), ex);

            invalidClassQualifiers.add(qualifier.getName());
          }

      }


    for (Iterator i = attributeValues.keySet().iterator(); i.hasNext(); ) {
      String attributeName = i.next().toString();
      CmdbAttribute cmdbAttribute = null;
      if (cmdbClass.getAllAttributes().hasAttribute(attributeName))
        try
        {
          AttributeValueValidator attributeValidator = getAttributeValidatorsFactory().create(cmdbClass, cmdbClass.getAllAttributes().getAttributeByName(attributeName), attributeValues.get(attributeName));

          cmdbAttribute = cmdbClass.getAllAttributes().getAttributeByName(attributeName);
          invokeAttributeValidator(toUpdate, attributeValidator, cmdbAttribute, cmdbClass, attributeValues, attributeName, user);

          if (attributeValidator instanceof CustomAttributeValueValidator) {
            CustomAttributeValueValidator customAttributeValueValidator = (CustomAttributeValueValidator)attributeValidator;
            if (customAttributeValueValidator.toPerformDefaultValidation()) {
              attributeValidator = getAttributeValidatorsFactory().createDefault(cmdbAttribute, cmdbClass);
              invokeAttributeValidator(toUpdate, attributeValidator, cmdbAttribute, cmdbClass, attributeValues, attributeName, user);
            }
          }
        } catch (AttributeValidationException ave) {
          if (LOGGER.isDebugEnabled())
            LOGGER.debug("Data is not valid according to attribute validator: attribute = " + ((cmdbAttribute == null) ? "null" : cmdbAttribute.getName()) + " , cmdb class = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()) + " , attributes values = " + ((attributeValues == null) ? "null" : attributeValues.toString()), ave);

          attributeExceptions.add(ave);
        }

    }

    if ((!(attributeExceptions.isEmpty())) || (!(invalidClassQualifiers.isEmpty()))) {
      if (LOGGER.isDebugEnabled())
        LOGGER.debug("Data is not valid, some attributes are not valid: cmdb class = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()) + " , attributes values = " + ((attributeValues == null) ? "null" : attributeValues.toString()));

      throw new ClassValidationException(cmdbClass, attributeExceptions, invalidClassQualifiers);
    }

    if (LOGGER.isInfoEnabled())
      LOGGER.info("End call to validate: attributes values = " + ((attributeValues == null) ? "null" : attributeValues.toString()) + " , cmdb class = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()) + " , user = " + ((user == null) ? "null" : user.toString()) + " updated data = " + ((toUpdate == null) ? "null" : toUpdate.toString()));
  }

  private void invokeAttributeValidator(CmdbData toUpdate, AttributeValueValidator attributeValidator, CmdbAttribute cmdbAttribute, CmdbClass cmdbClass, Map attributeValues, String attributeName, BasicUserData user) throws AttributeValidationException
  {
    if (toUpdate == null)
      attributeValidator.validateNew(cmdbAttribute, cmdbClass, attributeValues.get(attributeName), attributeValues, user);
    else
      attributeValidator.validateUpdated(cmdbAttribute, cmdbClass, attributeValues.get(attributeName), attributeValues, toUpdate, user);
  }

  public AttributeValueValidatorFactory getAttributeValidatorsFactory()
  {
    return AttributeValueValidatorFactory.getInstance();
  }
}