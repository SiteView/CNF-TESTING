package com.mercury.am.platform.cmdbext.access;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.tql.definition.Pattern;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementTypeLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Iterator;
import java.util.Set;

public class PatternLayoutUtil
{
  private static Log LOGGER = LogFactory.getEasyLog(PatternLayoutUtil.class);

  public static ElementSimpleLayout createBasicLayout()
  {
    ElementSimpleLayout basicLayout = PatternLayoutFactory.createElementSimpleLayout();
    basicLayout.addKey("data_name");
    basicLayout.addKey("data_description");
    basicLayout.addKey("display_label");
    basicLayout.addKey("data_source");

    return basicLayout;
  }

  public static PatternLayout createBasicLayoutForPattern(Pattern pattern)
  {
    return createLayoutForPattern(pattern, createBasicLayout());
  }

  public static ElementTypeLayout createBasicTypeLayoutForPattern(Pattern pattern)
  {
    ElementSimpleLayout basicLayout = createBasicLayout();
    ElementTypeLayout layout = PatternLayoutFactory.createTypeLayout();

    for (ReadOnlyIterator i = pattern.getPatternGraph().getNodesIterator(); i.hasNext(); ) {
      PatternNode node = (PatternNode)i.next();
      if ((node.getCondition() != null) && (node.getCondition().getClassCondition() != null) && (node.getCondition().getClassCondition().getClassName() != null))
        layout.addSimpleLayout(node.getCondition().getClassCondition().getClassName(), basicLayout);
    }

    return layout;
  }

  public static ElementTypeLayout createFullTypeLayout(Set types, CmdbClassModel classModel)
  {
    ElementTypeLayout layout = PatternLayoutFactory.createTypeLayout();

    if ((((types == null) || (classModel == null))) && 
      (LOGGER.isDebugEnabled())) {
      LOGGER.debug("Method createFullTypeLayout returns empty ElementTypeLayout because one of its parametes is null: Set types = " + types + " , CmdbClassModel classModel = " + classModel);
      return layout;
    }

    for (Iterator i = types.iterator(); i.hasNext(); ) {
      String nextType = i.next().toString();

      if (classModel.getClass(nextType) != null)
        layout.addSimpleLayout(nextType, createObjectDetailedLayout(classModel, nextType));
    }

    return layout;
  }

  public static ElementTypeLayout createBasicTypeLayout(String type)
  {
    if (type == null)
      type = "it_world";

    ElementSimpleLayout basicLayout = createBasicLayout();
    ElementTypeLayout layout = PatternLayoutFactory.createTypeLayout();

    layout.addSimpleLayout(type, basicLayout);

    return layout;
  }

  public static ElementTypeLayout createBasicTypesLayout(String[] types)
  {
    if (types == null) {
      types = { "it_world", "it_world_links" };
    }

    ElementSimpleLayout basicLayout = createBasicLayout();
    ElementTypeLayout layout = PatternLayoutFactory.createTypeLayout();
    for (int i = 0; i < types.length; ++i)
    {
      layout.addSimpleLayout(types[i], basicLayout);
    }

    return layout;
  }

  public static PatternLayout createEmptyLayoutForPattern(Pattern pattern)
  {
    return createLayoutForPattern(pattern, PatternLayoutFactory.createElementSimpleLayout());
  }

  public static PatternLayout createLayoutForPattern(Pattern pattern, ElementSimpleLayout elementLayout)
  {
    if (elementLayout == null)
      elementLayout = createBasicLayout();

    PatternLayout layout = PatternLayoutFactory.createLayout();

    for (ReadOnlyIterator i = pattern.getPatternGraph().getElementNumbersIterator(); i.hasNext(); ) {
      PatternElementNumber elementPatternNumber = (PatternElementNumber)i.next();
      layout.setElementLayout(elementPatternNumber, elementLayout);
    }
    return layout;
  }

  public static PatternLayout createLayoutForPattern(Pattern pattern, ElementSimpleLayout objectLayout, ElementSimpleLayout linkLayout)
  {
    if (objectLayout == null)
      objectLayout = createBasicLayout();

    if (linkLayout == null)
      linkLayout = createBasicLayout();

    PatternLayout layout = PatternLayoutFactory.createLayout();

    for (ReadOnlyIterator i = pattern.getPatternGraph().getNodeNumbersIterator(); i.hasNext(); ) {
      PatternElementNumber nodePatternNumber = (PatternElementNumber)i.next();
      layout.setElementLayout(nodePatternNumber, objectLayout);
    }

    for (i = pattern.getPatternGraph().getLinkNumbersIterator(); i.hasNext(); ) {
      PatternElementNumber linkPatternNumber = (PatternElementNumber)i.next();
      layout.setElementLayout(linkPatternNumber, objectLayout);
    }
    return layout;
  }

  public static ElementSimpleLayout createObjectDetailedLayout(CmdbClassModel classModel, String className)
  {
    String[] detailsAttributeNames = CmdbClassModelUtil.getAttributesForCmdbDataDetails(classModel.getClass(className));
    return createSimpleLayoutForAttributes(detailsAttributeNames);
  }

  public static ElementSimpleLayout createSimpleLayoutForAttributes(String[] attributeNames)
  {
    ElementSimpleLayout layout = PatternLayoutFactory.createElementSimpleLayout();
    for (int i = 0; i < attributeNames.length; ++i)
      layout.addKey(attributeNames[i]);

    return layout;
  }

  public static ElementSimpleLayout getLinkDetailedLayout(CmdbClassModel classModel, String className)
  {
    return createObjectDetailedLayout(classModel, className);
  }

  public static void getDataAttributesLayout(PatternLayout origin)
  {
    ElementSimpleLayout dataLayout = createBasicLayout();

    for (ReadOnlyIterator i = origin.getElementNumbers(); i.hasNext(); ) {
      Integer nodePatternNumber = (Integer)i.next();
      origin.setElementLayout(PatternElementNumberFactory.createElementNumber(nodePatternNumber.intValue()), dataLayout);
    }
  }
}