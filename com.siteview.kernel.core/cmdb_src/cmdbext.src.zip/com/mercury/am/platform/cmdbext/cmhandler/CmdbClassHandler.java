package com.mercury.am.platform.cmdbext.cmhandler;

import com.mercury.am.platform.cmdbext.processing.ClassInputProcessor;
import com.mercury.am.platform.cmdbext.processing.ClassOutputProcessor;
import com.mercury.am.platform.cmdbext.validation.classes.CustomClassValidator;

public abstract interface CmdbClassHandler
{
  public abstract String getRender();

  public abstract boolean hasRender();

  public abstract CustomClassValidator getValidator();

  public abstract boolean hasValidator();

  public abstract ClassInputProcessor getInputProcessor();

  public abstract boolean hasInputProcessor();

  public abstract ClassOutputProcessor getOutputProcessor();

  public abstract boolean hasOutputProcessor();
}