package com.mercury.am.platform.cmdbext.access;

import appilog.framework.shared.manage.customer.id.MamCustomerID;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.PatternState;
import com.mercury.topaz.cmdb.shared.tql.definition.Priority.PatternPriorityType;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class CmdbCipher
{
  private static Log logger = LogFactory.getEasyLog(CmdbCipher.class);
  private byte[] key = null;

  public CmdbCipher(CmdbContext context)
  {
    this.key = getEncryptionKey(context);
  }

  public byte[] encrypt(String clearText)
    throws Exception
  {
    if ((this.key == null) || (this.key.length == 0))
      return clearText.getBytes();

    SecretKeySpec skeySpec = new SecretKeySpec(this.key, "DESede");
    Cipher cipher = Cipher.getInstance("DESede");
    cipher.init(1, skeySpec);

    return cipher.doFinal(clearText.getBytes());
  }

  public String decrypt(byte[] encriptedText)
    throws Exception
  {
    if ((this.key == null) || (this.key.length == 0))
      return new String(encriptedText);

    SecretKeySpec skeySpec = new SecretKeySpec(this.key, "DESede");
    Cipher cipher = Cipher.getInstance("DESede");
    cipher.init(2, skeySpec);

    return new String(cipher.doFinal(encriptedText));
  }

  private byte[] getEncryptionKey(CmdbContext cmdbContext)
  {
    PatternElementNumber keyNodeId = PatternElementNumberFactory.createElementNumber(1);

    ElementClassCondition classCon = PatternConditionFactory.createElementClassCondition("key", true);
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(classCon);

    PatternNode node = PatternGraphFactory.createPatternNode(keyNodeId, elementCondition, true, null);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(node);

    PatternGroupId patternGroup = PatternGroupId.PATTERN_GROUP_ALL;
    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("", "ITUKeyRetrieverPattren", patternGroup, patternGraph);
    PatternState patternState = PatternDefinitionFactory.createPatternState(false, true, PatternPriorityType.EXPRESS_PRIORITY, false);
    pattern.setState(patternState);

    ElementSimpleLayout layout = PatternLayoutFactory.createElementSimpleLayout();
    layout.addKey("key_key");

    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    patternLayout.setElementLayout(keyNodeId, layout);
    pattern.setDefaultLayout(patternLayout);

    TqlQueryGetAdHocMap getAdHocMap = new TqlQueryGetAdHocMap(pattern, patternLayout);
    try {
      CmdbApi api = CmdbApiFactoryThinWrapper.getInstance();
      api.executeCMDBOperation(getAdHocMap, cmdbContext);
    } catch (CmdbResponseException cre) {
      logger.error("Error getting encryption key: customer id = " + cmdbContext.getCustomerID().getID(), cre);
      return null;
    }
    TqlResultMap adHocMap = getAdHocMap.getResultMap();

    if ((adHocMap != null) && (adHocMap.containsElementNumber(keyNodeId))) {
      CmdbObjects resObjects = adHocMap.getObjects(keyNodeId);

      if ((resObjects != null) && (!(resObjects.isEmpty()))) {
        CmdbObject keyObject = (CmdbObject)resObjects.getObjectsIterator().next();

        if ((keyObject.hasProperties()) && (keyObject.getProperty("key_key") != null))
          return ((byte[])(byte[])keyObject.getProperty("key_key").getValue());
      }
    }

    return null;
  }
}