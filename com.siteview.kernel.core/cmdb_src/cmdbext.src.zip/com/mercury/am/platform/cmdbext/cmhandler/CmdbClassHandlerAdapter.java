package com.mercury.am.platform.cmdbext.cmhandler;

import com.mercury.am.platform.cmdbext.processing.ClassInputProcessor;
import com.mercury.am.platform.cmdbext.processing.ClassOutputProcessor;
import com.mercury.am.platform.cmdbext.validation.classes.CustomClassValidator;

public class CmdbClassHandlerAdapter
  implements CmdbClassHandler
{
  public String getRender()
  {
    return null;
  }

  public boolean hasRender()
  {
    return (getRender() != null);
  }

  public CustomClassValidator getValidator()
  {
    return null;
  }

  public boolean hasValidator()
  {
    return (getValidator() != null);
  }

  public ClassInputProcessor getInputProcessor()
  {
    return null;
  }

  public boolean hasInputProcessor()
  {
    return (getInputProcessor() != null);
  }

  public ClassOutputProcessor getOutputProcessor()
  {
    return null;
  }

  public boolean hasOutputProcessor()
  {
    return false;
  }
}