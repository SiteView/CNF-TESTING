package com.mercury.am.platform.cmdbext.validation.attribute.qualifier;

public class ValidationErrorRecordFactory
{
  public static ValidationErrorRecord createQualifierValidatorRecord(String errorCode, String attributeName, Object wrongValue)
  {
    ValidationErrorRecord validatorRecord = new ValidationErrorRecord(errorCode, attributeName, wrongValue);
    return validatorRecord;
  }

  public static ValidationErrorRecord createQualifierValidatorRecord(String errorCode, String attributeName, Object wrongValue, String paramName, Object paramValue)
  {
    ValidationErrorRecord validatorRecord = new ValidationErrorRecord(errorCode, attributeName, wrongValue);
    validatorRecord.addErrorMessageParam(paramName, paramValue);
    return validatorRecord;
  }

  public static ValidationErrorRecord createQualifierValidatorRecord(String errorCode, String attributeName, Object wrongValue, String param1Name, Object param1Value, String param2Name, Object param2Value)
  {
    ValidationErrorRecord validatorRecord = new ValidationErrorRecord(errorCode, attributeName, wrongValue);
    validatorRecord.addErrorMessageParam(param1Name, param1Value);
    validatorRecord.addErrorMessageParam(param2Name, param2Value);
    return validatorRecord;
  }
}