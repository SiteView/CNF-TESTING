package com.mercury.am.platform.cmdbext.validation.classes.qualifier;

import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDefs;
import java.util.HashMap;
import java.util.Map;

public class QualifierValidatorFactory
{
  private static Map qualifierValidatorMap = new HashMap();

  public static QualifierValidator createQualifierValidator(ClassModelQualifier qualifier)
  {
    if (qualifier == null)
      return null;

    return ((QualifierValidator)qualifierValidatorMap.get(qualifier.getName()));
  }

  static
  {
    qualifierValidatorMap.put("HANDLER", new EmptyQualifierValidator());
    qualifierValidatorMap.put(CmdbClassQualifierDefs.ABSTRACT_CLASS.getName(), new EmptyQualifierValidator());
    qualifierValidatorMap.put(CmdbClassQualifierDefs.FINAL_CLASS.getName(), new EmptyQualifierValidator());
    qualifierValidatorMap.put(CmdbClassQualifierDefs.HIDDEN_CLASS.getName(), new EmptyQualifierValidator());
    qualifierValidatorMap.put(CmdbClassQualifierDefs.RANDOM_GENERATED_ID_CLASS.getName(), new EmptyQualifierValidator());
  }
}