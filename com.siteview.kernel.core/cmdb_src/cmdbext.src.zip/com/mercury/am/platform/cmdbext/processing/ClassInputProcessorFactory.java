package com.mercury.am.platform.cmdbext.processing;

import com.mercury.am.platform.cmdbext.cmhandler.CmdbClassHandler;
import com.mercury.am.platform.cmdbext.cmhandler.HandlerUtil;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;

public class ClassInputProcessorFactory
{
  private static ClassInputProcessorFactory singleton = new ClassInputProcessorFactory();
  private DefaultClassInputProcessor defaultProcessor;

  public static ClassInputProcessorFactory getInstance()
  {
    return singleton;
  }

  private ClassInputProcessorFactory()
  {
    this.defaultProcessor = new DefaultClassInputProcessor();
  }

  public ClassInputProcessor createProcessorForClass(CmdbClassModel classModel, CmdbClass cmdbClass)
  {
    CmdbClassHandler classHandler = HandlerUtil.findClassHandlerQualifier(cmdbClass);
    if ((classHandler != null) && (classHandler.hasInputProcessor()))
    {
      return classHandler.getInputProcessor();
    }

    return this.defaultProcessor;
  }

  public ClassInputProcessor createProcessorForClass(String cmdbClassName, CmdbClassModel classModel) {
    return createProcessorForClass(classModel, classModel.getClass(cmdbClassName));
  }
}