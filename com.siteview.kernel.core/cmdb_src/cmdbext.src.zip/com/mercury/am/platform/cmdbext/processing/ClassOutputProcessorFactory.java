package com.mercury.am.platform.cmdbext.processing;

import com.mercury.am.platform.cmdbext.cmhandler.CmdbClassHandler;
import com.mercury.am.platform.cmdbext.cmhandler.HandlerUtil;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;

public class ClassOutputProcessorFactory
{
  private static ClassOutputProcessorFactory singleton = new ClassOutputProcessorFactory();
  private DefaultClassOutputProcessor defaultProcessor;

  public static ClassOutputProcessorFactory getInstance()
  {
    return singleton;
  }

  private ClassOutputProcessorFactory()
  {
    this.defaultProcessor = new DefaultClassOutputProcessor();
  }

  public ClassOutputProcessor createProcessorForClass(CmdbClassModel classModel, CmdbClass cmdbClass)
  {
    CmdbClassHandler classHandler = HandlerUtil.findClassHandlerQualifier(cmdbClass);
    if ((classHandler != null) && (classHandler.hasOutputProcessor()))
    {
      return classHandler.getOutputProcessor();
    }

    return this.defaultProcessor;
  }

  public ClassOutputProcessor createProcessorForClass(String cmdbClassName, CmdbClassModel classModel) {
    return createProcessorForClass(classModel, classModel.getClass(cmdbClassName));
  }
}