package com.mercury.am.platform.cmdbext.validation.dnode;

import com.mercury.am.platform.cmdbext.cmhandler.CmdbAttributeHandler;
import com.mercury.am.platform.cmdbext.processing.AttributeInputProcessor;
import com.mercury.am.platform.cmdbext.processing.AttributeOutputProcessor;
import com.mercury.am.platform.cmdbext.validation.attribute.CustomAttributeValueValidator;

public class DNodeItumHandler
  implements CmdbAttributeHandler
{
  public String getRender()
  {
    return null;
  }

  public boolean hasRender()
  {
    return false;
  }

  public CustomAttributeValueValidator getValidator()
  {
    return new DNodeDefinitionValidator();
  }

  public boolean hasValidator()
  {
    return true;
  }

  public AttributeInputProcessor getInputProcessor()
  {
    return null;
  }

  public boolean hasInputProcessor()
  {
    return false;
  }

  public AttributeOutputProcessor getOutputProcessor()
  {
    return null;
  }

  public boolean hasOutputProcessor()
  {
    return false;
  }
}