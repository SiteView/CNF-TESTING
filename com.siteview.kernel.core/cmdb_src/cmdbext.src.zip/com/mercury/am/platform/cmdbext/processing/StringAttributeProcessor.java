package com.mercury.am.platform.cmdbext.processing;

import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;

public class StringAttributeProcessor extends SimpleAttributeProcessor
{
  public StringAttributeProcessor()
  {
    super(String.class);
  }

  protected Object processStringValue(CmdbAttribute attribute, String valueAsString, CmdbData currentCmdbData, BasicUserData userContext) throws AttributeProcessingException, Exception
  {
    return valueAsString;
  }

  protected String getErrorCode() {
    return "processor.error.not.string";
  }

  protected Object manipulateValue(CmdbAttribute attribute, Object value, CmdbData currentCmdbData, BasicUserData userContext)
  {
    if (StringUtils.isEmpty(value.toString()))
      return null;

    return value.toString();
  }
}