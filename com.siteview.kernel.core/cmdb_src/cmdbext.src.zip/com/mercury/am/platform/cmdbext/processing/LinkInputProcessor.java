package com.mercury.am.platform.cmdbext.processing;

import com.mercury.am.platform.cmdbext.validation.classes.ClassValidationException;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;
import java.util.Set;

public abstract interface LinkInputProcessor
{
  public abstract Map processNew(Set paramSet, CmdbClass paramCmdbClass, CmdbClassModel paramCmdbClassModel, CmdbObjectID paramCmdbObjectID1, CmdbObjectID paramCmdbObjectID2, Map paramMap, BasicUserData paramBasicUserData, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws ClassProcessingException, NullPointerException;

  public abstract Map processUpdated(Set paramSet, CmdbClass paramCmdbClass, CmdbClassModel paramCmdbClassModel, Map paramMap, CmdbLink paramCmdbLink, BasicUserData paramBasicUserData, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws ClassProcessingException, NullPointerException;

  public abstract Map processAndValidateNew(Set paramSet, String paramString, CmdbClassModel paramCmdbClassModel, CmdbObjectID paramCmdbObjectID1, CmdbObjectID paramCmdbObjectID2, Map paramMap, BasicUserData paramBasicUserData, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws ClassProcessingException, ClassValidationException, NullPointerException;

  public abstract Map processAndValidateUpdated(Set paramSet, String paramString, CmdbLink paramCmdbLink, CmdbClassModel paramCmdbClassModel, Map paramMap, BasicUserData paramBasicUserData, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws ClassProcessingException, ClassValidationException, NullPointerException;

  public abstract AttributeInputProcessorFactory getAttributeProcessorsFactory();

  public abstract void postProcessNew(CmdbClass paramCmdbClass, CmdbClassModel paramCmdbClassModel, CmdbLink paramCmdbLink1, CmdbLink paramCmdbLink2, Map paramMap, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws ClassProcessingException, NullPointerException;

  public abstract void postProcessUpdated(CmdbClass paramCmdbClass, CmdbClassModel paramCmdbClassModel, CmdbLink paramCmdbLink1, CmdbLink paramCmdbLink2, Map paramMap, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws ClassProcessingException, NullPointerException;
}