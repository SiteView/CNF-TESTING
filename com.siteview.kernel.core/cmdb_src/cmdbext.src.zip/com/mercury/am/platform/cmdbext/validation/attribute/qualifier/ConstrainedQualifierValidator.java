package com.mercury.am.platform.cmdbext.validation.attribute.qualifier;

import com.mercury.am.platform.cmdbext.validation.attribute.AttributeValidationException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItem;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItems;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.TypeVisitor;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBytesType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDateType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDoubleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbFloatType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.Numeric;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.apache.commons.lang.StringUtils;

public class ConstrainedQualifierValidator
  implements QualifierValidator
{
  private static Log LOGGER = LogFactory.getEasyLog(ConstrainedQualifierValidator.class);

  public void validateUpdated(ClassModelQualifier qualifier, CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, CmdbData cmdbData)
    throws AttributeValidationException
  {
    validateNew(qualifier, attribute, containerClass, value, attributeValues);
  }

  public void validateNew(ClassModelQualifier qualifier, CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues)
    throws AttributeValidationException
  {
    List unqualifiedList = new ArrayList();
    DataItems dataItems = qualifier.getDataItems();

    DefaultConstrainValidator constrainValidator = new CmdbType2ConstrainValidator(this, attribute, attribute.getResolvedType()).getConstrainValidator();

    if (dataItems != null)
      for (ReadOnlyIterator dataItemsIterator = dataItems.getIterator(); dataItemsIterator.hasNext(); ) {
        DataItem dataItem = (DataItem)dataItemsIterator.next();
        if ("MAX_LENGTH".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyMaxLength(attribute.getName(), dataItem, value, unqualifiedList);
        else if ("MIN_LENGTH".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyMinLength(attribute.getName(), dataItem, value, unqualifiedList);
        else if ("MAX_VALUE".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyMaxValue(attribute.getName(), dataItem, value, unqualifiedList);
        else if ("MIN_VALUE".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyMinValue(attribute.getName(), dataItem, value, unqualifiedList);
        else if ("ALPHANUMERIC".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyAlphaNumeric(attribute.getName(), value, unqualifiedList);
        else if ("SPACES".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyWord(attribute.getName(), value, unqualifiedList);
        else if ("HTTPURL".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyHTTP_URL(attribute.getName(), value, unqualifiedList);
        else if ("FTPURL".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyFTP_URL(attribute.getName(), value, unqualifiedList);
        else if ("EMAIL_ADDRESS".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyEmailAddress(attribute.getName(), value, unqualifiedList);
        else if ("LDAP_IDENTIFIER".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyLDAP_URL(attribute.getName(), value, unqualifiedList);
        else if ("HOST_NAME".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyHostName(attribute.getName(), value, unqualifiedList);
        else if ("IP_ADDRESS".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyIPAddress(attribute.getName(), value, unqualifiedList);
        else if ("PORT".equalsIgnoreCase(dataItem.getName()))
          constrainValidator.qualifyIPPort(attribute.getName(), value, unqualifiedList);

      }


    if (!(unqualifiedList.isEmpty())) {
      AttributeValidationException validationException = new AttributeValidationException(attribute, value);
      validationException.addValidationErrors(unqualifiedList);

      throw validationException;
    }
  }

  private void qualifyAlphaNumericString(String attributeName, String value, List unqualifiedList)
  {
    if (value == null)
      return;

    if (!(Pattern.matches("^\\p{Alnum}*$", value)))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.ALPHANUMERIC", attributeName, value));
  }

  private void qualifyWordString(String attributeName, String value, List unqualifiedList)
  {
    if ((StringUtils.isEmpty(value)) || (!(Pattern.matches("^[\\p{Graph}\\p{Space}]+$", value.trim()))))
    {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.SPACES", attributeName, value));
    }
  }

  private void qualifyHTTP_URLString(String attributeName, String value, List unqualifiedList)
  {
    if (value == null) {
      return;
    }

    if (!(Pattern.matches("^(http|https)://(([a-zA-Z]+[a-zA-Z0-9]*([-_][a-zA-Z0-9]+)*([=#%/&.~\\?\\(\\)]{1,3}[a-zA-Z0-9]+)*)+)$", value)))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.HTTPURL", attributeName, value));
  }

  private void qualifyFTP_URLString(String attributeName, String value, List unqualifiedList)
  {
    if (value == null) {
      return;
    }

    if (!(Pattern.matches("^ftp://(([a-zA-Z]+[a-zA-Z0-9]*([-_][a-zA-Z0-9]+)*([@%/:.]{1,3}[a-zA-Z0-9]+)*)+)$", value)))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.FTPURL", attributeName, value));
  }

  private void qualifyEmailAddressString(String attributeName, String value, List unqualifiedList)
  {
    if (value == null)
      return;

    if (!(Pattern.matches("^(([a-zA-Z0-9]+[-._]?[a-zA-Z0-9]+)+@([a-zA-Z]+[a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+(.)?)+)$", value)))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.EMAIL_ADDRESS", attributeName, value));
  }

  private void qualifyLDAP_URLString(String attributeName, String value, List unqualifiedList)
  {
    if (value == null)
      return;

    if (!(Pattern.matches("^ldap://[/]?[\\?]*(([a-zA-Z0-9]+([-_][a-zA-Z0-9]+)*[%~\\p{Punct}]*)+)$", value)))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.LDAP_IDENTIFIER", attributeName, value));
  }

  private void qualifyHostNameString(String attributeName, String value, List unqualifiedList)
  {
    if (value == null)
      return;

    if (!(Pattern.matches("^(([a-zA-Z]+[a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+(.)?)+)$", value)))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.HOST_NAME", attributeName, value));
  }

  private void qualifyIPAddressString(String attributeName, String value, List unqualifiedList)
  {
    if (value == null)
      return;

    if (!(Pattern.matches("^((((2(([0-4][0-9])|(5[0-5])))|([01]?[0-9]?[0-9]))\\.){3}((2(([0-4][0-9])|(5[0-5])))|([01]?[0-9]?[0-9])))$", value)))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.IP_ADDRESS", attributeName, value));
  }

  private void qualifyIPPortValue(String attributeName, Object value, List unqualifiedList)
  {
    if (value == null)
      return;
    try
    {
      int intValue = -1;

      if (value instanceof String == true) {
        if (StringUtils.isEmpty((String)value)) {
          return;
        }

        intValue = Integer.parseInt((String)value);
      } else if (value instanceof Number) {
        intValue = ((Number)value).intValue();
      }

      if ((intValue > 0) && (intValue < 65536))
        return;
    }
    catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }

    unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.PORT", attributeName, value));
  }

  private void qualifyStringMinLength(String attributeName, DataItem dataItem, String value, List unqualifiedList)
  {
    Object minLengthValue = dataItem.getValue();
    if (minLengthValue == null) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MIN_LENGTH", attributeName, value, "MIN_LENGTH", null));

      return;
    }

    int minLength = ((Integer)minLengthValue).intValue();
    if (((value == null) && (minLength > 0)) || (value.length() < minLength))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MIN_LENGTH", attributeName, value, "MIN_LENGTH", "" + minLength));
  }

  private void qualifyListMinLength(String attributeName, DataItem dataItem, List value, List unqualifiedList)
  {
    Object maxLengthValue = dataItem.getValue();
    if (maxLengthValue == null) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_LENGTH", attributeName, value, "MAX_LENGTH", null));

      return;
    }

    int maxLength = ((Integer)maxLengthValue).intValue();
    if ((value != null) && (value.size() > maxLength))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_LENGTH", attributeName, value, "MAX_LENGTH", "" + maxLength));
  }

  private void qualifyStringMaxLength(String attributeName, DataItem dataItem, String value, List unqualifiedList)
  {
    Object maxLengthValue = dataItem.getValue();
    if (maxLengthValue == null) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_LENGTH", attributeName, value, "MAX_LENGTH", null));

      return;
    }

    int maxLength = ((Integer)maxLengthValue).intValue();
    if ((value != null) && (value.length() > maxLength))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_LENGTH", attributeName, value, "MAX_LENGTH", "" + maxLength));
  }

  private void qualifyListMaxLength(String attributeName, DataItem dataItem, List value, List unqualifiedList)
  {
    Object maxLengthValue = dataItem.getValue();
    if (maxLengthValue == null) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_LENGTH", attributeName, value, "MAX_LENGTH", null));

      return;
    }

    int maxLength = ((Integer)maxLengthValue).intValue();
    if ((value != null) && (value.size() > maxLength))
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_LENGTH", attributeName, value, "MAX_LENGTH", "" + maxLength));
  }

  protected class CmdbType2ConstrainValidator
  implements TypeVisitor
  {
    private ConstrainedQualifierValidator.DefaultConstrainValidator constrainValidator;
    private CmdbAttribute attribute;

    protected CmdbType2ConstrainValidator(, CmdbAttribute paramCmdbAttribute, CmdbType paramCmdbType)
    {
      this.attribute = paramCmdbAttribute;
      if (paramCmdbType != null)
        paramCmdbType.accept(this);
    }

    public ConstrainedQualifierValidator.DefaultConstrainValidator getConstrainValidator()
    {
      return this.constrainValidator;
    }

    public void visit()
    {
    }

    public void visit()
    {
      this.constrainValidator = new ConstrainedQualifierValidator.NumericConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.NumericConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.NumericConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.NumericConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.NumericConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.StringConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.DefaultConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.DefaultConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.DefaultConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.BytesConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.StringListConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.IntegerListConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.DefaultConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.DefaultConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.DefaultConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.DefaultConstrainValidator(this.this$0);
    }

    public void visit() {
      this.constrainValidator = new ConstrainedQualifierValidator.DefaultConstrainValidator(this.this$0);
    }
  }

  protected class NumericConstrainValidator extends ConstrainedQualifierValidator.DefaultConstrainValidator
  {
    protected NumericConstrainValidator()
    {
      super(paramConstrainedQualifierValidator); }

    protected void qualifyIPPort(, Object value, List unqualifiedList) { ConstrainedQualifierValidator.access$800(this.this$0, attributeName, value, unqualifiedList);
    }
  }

  protected class IntegerListConstrainValidator extends ConstrainedQualifierValidator.DefaultConstrainValidator
  {
    protected IntegerListConstrainValidator()
    {
      super(paramConstrainedQualifierValidator); }

    protected void qualifyMinLength(, DataItem dataItem, Object value, List unqualifiedList) { ConstrainedQualifierValidator.access$1100(this.this$0, attributeName, dataItem, (List)value, unqualifiedList);
    }

    protected void qualifyMaxLength(, DataItem dataItem, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$1200(this.this$0, attributeName, dataItem, (List)value, unqualifiedList);
    }

    protected void qualifyIPPort(, Object value, List unqualifiedList) {
      if (value == null)
        return;

      List list = (List)value;
      for (int i = 0; i < list.size(); ++i)
        ConstrainedQualifierValidator.access$800(this.this$0, attributeName, list.get(i), unqualifiedList);
    }
  }

  protected class StringListConstrainValidator extends ConstrainedQualifierValidator.DefaultConstrainValidator
  {
    protected StringListConstrainValidator()
    {
      super(paramConstrainedQualifierValidator); }

    protected void qualifyAlphaNumeric(, Object value, List unqualifiedList) { if (value == null)
        return;

      List list = (List)value;
      for (int i = 0; i < list.size(); ++i)
        ConstrainedQualifierValidator.access$000(this.this$0, attributeName, (String)list.get(i), unqualifiedList);
    }

    protected void qualifyWord(, Object value, List unqualifiedList)
    {
      if (value == null)
        return;

      List list = (List)value;
      for (int i = 0; i < list.size(); ++i)
        ConstrainedQualifierValidator.access$100(this.this$0, attributeName, (String)list.get(i), unqualifiedList);
    }

    protected void qualifyHTTP_URL(, Object value, List unqualifiedList)
    {
      if (value == null)
        return;

      List list = (List)value;
      for (int i = 0; i < list.size(); ++i)
        ConstrainedQualifierValidator.access$200(this.this$0, attributeName, (String)list.get(i), unqualifiedList);
    }

    protected void qualifyFTP_URL(, Object value, List unqualifiedList)
    {
      if (value == null)
        return;

      List list = (List)value;
      for (int i = 0; i < list.size(); ++i)
        ConstrainedQualifierValidator.access$300(this.this$0, attributeName, (String)list.get(i), unqualifiedList);
    }

    protected void qualifyEmailAddress(, Object value, List unqualifiedList)
    {
      if (value == null)
        return;

      List list = (List)value;
      for (int i = 0; i < list.size(); ++i)
        ConstrainedQualifierValidator.access$400(this.this$0, attributeName, (String)list.get(i), unqualifiedList);
    }

    protected void qualifyLDAP_URL(, Object value, List unqualifiedList)
    {
      if (value == null)
        return;

      List list = (List)value;
      for (int i = 0; i < list.size(); ++i)
        ConstrainedQualifierValidator.access$500(this.this$0, attributeName, (String)list.get(i), unqualifiedList);
    }

    protected void qualifyHostName(, Object value, List unqualifiedList)
    {
      if (value == null)
        return;

      List list = (List)value;
      for (int i = 0; i < list.size(); ++i)
        ConstrainedQualifierValidator.access$600(this.this$0, attributeName, (String)list.get(i), unqualifiedList);
    }

    protected void qualifyIPAddress(, Object value, List unqualifiedList)
    {
      if (value == null)
        return;

      List list = (List)value;
      for (int i = 0; i < list.size(); ++i)
        ConstrainedQualifierValidator.access$700(this.this$0, attributeName, (String)list.get(i), unqualifiedList);
    }

    protected void qualifyIPPort(, Object value, List unqualifiedList)
    {
      if (value == null)
        return;

      List list = (List)value;
      for (int i = 0; i < list.size(); ++i)
        ConstrainedQualifierValidator.access$800(this.this$0, attributeName, list.get(i), unqualifiedList);
    }

    protected void qualifyMinLength(, DataItem dataItem, Object value, List unqualifiedList)
    {
      ConstrainedQualifierValidator.access$1100(this.this$0, attributeName, dataItem, (List)value, unqualifiedList);
    }

    protected void qualifyMaxLength(, DataItem dataItem, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$1200(this.this$0, attributeName, dataItem, (List)value, unqualifiedList);
    }
  }

  protected class BytesConstrainValidator extends ConstrainedQualifierValidator.DefaultConstrainValidator
  {
    protected BytesConstrainValidator()
    {
      super(paramConstrainedQualifierValidator); }

    protected void qualifyMinLength(, DataItem dataItem, Object value, List unqualifiedList) { Object minLengthValue = dataItem.getValue();
      if (minLengthValue == null) {
        unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MIN_LENGTH", attributeName, value, "MIN_LENGTH", null));

        return;
      }

      int minLength = ((Integer)minLengthValue).intValue();
      if ((!(value instanceof Object[])) || ((value == null) && (minLength > 0)) || (((Object[])(Object[])value).length < minLength))
      {
        unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MIN_LENGTH", attributeName, value, "MIN_LENGTH", "" + minLength));
      }
    }

    protected void qualifyMaxLength(, DataItem dataItem, Object value, List unqualifiedList)
    {
      Object maxLengthValue = dataItem.getValue();
      if (maxLengthValue == null) {
        unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_LENGTH", attributeName, value, "MAX_LENGTH", null));

        return;
      }

      int maxLength = ((Integer)maxLengthValue).intValue();
      if ((!(value instanceof Object[])) || ((value != null) && (((Object[])(Object[])value).length > maxLength)))
      {
        unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_LENGTH", attributeName, value, "MAX_LENGTH", "" + maxLength));
      }
    }
  }

  protected class StringConstrainValidator extends ConstrainedQualifierValidator.DefaultConstrainValidator
  {
    protected StringConstrainValidator()
    {
      super(paramConstrainedQualifierValidator); }

    protected void qualifyAlphaNumeric(, Object value, List unqualifiedList) { ConstrainedQualifierValidator.access$000(this.this$0, attributeName, (String)value, unqualifiedList);
    }

    protected void qualifyWord(, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$100(this.this$0, attributeName, (String)value, unqualifiedList);
    }

    protected void qualifyHTTP_URL(, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$200(this.this$0, attributeName, (String)value, unqualifiedList);
    }

    protected void qualifyFTP_URL(, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$300(this.this$0, attributeName, (String)value, unqualifiedList);
    }

    protected void qualifyEmailAddress(, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$400(this.this$0, attributeName, (String)value, unqualifiedList);
    }

    protected void qualifyLDAP_URL(, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$500(this.this$0, attributeName, (String)value, unqualifiedList);
    }

    protected void qualifyHostName(, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$600(this.this$0, attributeName, (String)value, unqualifiedList);
    }

    protected void qualifyIPAddress(, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$700(this.this$0, attributeName, (String)value, unqualifiedList);
    }

    protected void qualifyIPPort(, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$800(this.this$0, attributeName, value, unqualifiedList);
    }

    protected void qualifyMinValue(, DataItem dataItem, Object value, List unqualifiedList) {
      super.qualifyMinValue(attributeName, dataItem, value, unqualifiedList);
    }

    protected void qualifyMaxValue(, DataItem dataItem, Object value, List unqualifiedList) {
      super.qualifyMaxValue(attributeName, dataItem, value, unqualifiedList);
    }

    protected void qualifyMinLength(, DataItem dataItem, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$900(this.this$0, attributeName, dataItem, (String)value, unqualifiedList);
    }

    protected void qualifyMaxLength(, DataItem dataItem, Object value, List unqualifiedList) {
      ConstrainedQualifierValidator.access$1000(this.this$0, attributeName, dataItem, (String)value, unqualifiedList);
    }
  }

  protected class DefaultConstrainValidator
  {
    protected void qualifyAlphaNumeric(, Object value, List unqualifiedList)
    {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.ALPHANUMERIC", attributeName, value));
    }

    protected void qualifyWord(, Object value, List unqualifiedList) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.SPACES", attributeName, value));
    }

    protected void qualifyHTTP_URL(, Object value, List unqualifiedList) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.HTTPURL", attributeName, value));
    }

    protected void qualifyFTP_URL(, Object value, List unqualifiedList) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.FTPURL", attributeName, value));
    }

    protected void qualifyEmailAddress(, Object value, List unqualifiedList) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.EMAIL_ADDRESS", attributeName, value));
    }

    protected void qualifyLDAP_URL(, Object value, List unqualifiedList) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.LDAP_IDENTIFIER", attributeName, value));
    }

    protected void qualifyHostName(, Object value, List unqualifiedList) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.HOST_NAME", attributeName, value));
    }

    protected void qualifyIPAddress(, Object value, List unqualifiedList) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.IP_ADDRESS", attributeName, value));
    }

    protected void qualifyIPPort(, Object value, List unqualifiedList) {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.PORT", attributeName, value));
    }

    protected void qualifyMinValue(, DataItem dataItem, Object value, List unqualifiedList) {
      Object minValue = dataItem.getValue();
      if (minValue == null) {
        unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MIN_VALUE", attributeName, value, "MIN_VALUE", null));

        return;
      }

      if ((value != null) && (value instanceof Comparable)) {
        Comparable compValue = (Comparable)value;
        if (compValue.compareTo(minValue) < 0)
          unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MIN_VALUE", attributeName, value, "MIN_VALUE", minValue));
      }
    }

    protected void qualifyMaxValue(, DataItem dataItem, Object value, List unqualifiedList)
    {
      Object maxValue = dataItem.getValue();
      if (maxValue == null) {
        unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_VALUE", attributeName, value, "MAX_VALUE", null));

        return;
      }

      if ((value != null) && (value instanceof Comparable)) {
        Comparable compValue = (Comparable)value;
        if (compValue.compareTo(maxValue) > 0)
          unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_VALUE", attributeName, value, "MAX_VALUE", maxValue));
      }
    }

    protected void qualifyMinLength(, DataItem dataItem, Object value, List unqualifiedList)
    {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MIN_LENGTH", attributeName, value, "MIN_LENGTH", null));
    }

    protected void qualifyMaxLength(, DataItem dataItem, Object value, List unqualifiedList)
    {
      unqualifiedList.add(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.MAX_LENGTH", attributeName, value, "MAX_LENGTH", null));
    }
  }
}