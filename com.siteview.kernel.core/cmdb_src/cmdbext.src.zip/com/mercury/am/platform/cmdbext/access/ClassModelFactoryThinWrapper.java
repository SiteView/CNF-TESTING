package com.mercury.am.platform.cmdbext.access;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.ClassModelProvider;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID;
import com.mercury.topaz.cmdb.shared.manage.customer.id.CmdbCustomerID.Factory;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;
import com.mercury.topaz.util.session.BasicUserData;

public class ClassModelFactoryThinWrapper
  implements ClassModelFactoryProxy
{
  private static ClassModelFactoryThinWrapper singleton = new ClassModelFactoryThinWrapper();
  private static Log logger = LogFactory.getEasyLog(ClassModelFactoryThinWrapper.class);

  public static ClassModelFactoryProxy getInstance()
  {
    return singleton;
  }

  public void refresh()
  {
  }

  public void reset()
  {
  }

  public CmdbClassModel getClassModelForTestCustomer()
  {
    return getClassModel(CmdbContext.EMPTY);
  }

  /**
   * @deprecated
   */
  public CmdbClassModel getClassModelForCustomer(Object userSettings)
  {
    if ((userSettings != null) && (userSettings instanceof BasicUserData))
      return getClassModelByUserData((BasicUserData)userSettings);

    return getClassModelForTestCustomer();
  }

  public CmdbClassModel getClassModelByUserData(BasicUserData userData)
  {
    CmdbContext cmdbContext = CmdbContextFactory.createCmdbContext(CmdbCustomerID.Factory.createCMDBCustomerID(userData.getActiveCustomerID()), userData.getUserID(), "CmdbExt");

    return getClassModel(cmdbContext);
  }

  public CmdbClassModel getClassModelByCmdbContext(CmdbContext cmdbContext)
  {
    return getClassModel(cmdbContext);
  }

  private CmdbClassModel getClassModel(CmdbContext cmdbContext) {
    return ClassModelProvider.getInstance(cmdbContext.getCustomerID()).getClassModel();
  }

  public CmdbCipher getCmdbCipherByUserData(BasicUserData userData)
  {
    if (userData == null) {
      return null;
    }

    CmdbContext cmdbContext = CmdbContextFactory.createCmdbContext(CmdbCustomerID.Factory.createCMDBCustomerID(userData.getActiveCustomerID()), userData.getUserID(), "CmdbExt");

    return getCmdbCipherByCmdbContext(cmdbContext);
  }

  public CmdbCipher getCmdbCipherByCmdbContext(CmdbContext cmdbContext)
  {
    return null;
  }
}