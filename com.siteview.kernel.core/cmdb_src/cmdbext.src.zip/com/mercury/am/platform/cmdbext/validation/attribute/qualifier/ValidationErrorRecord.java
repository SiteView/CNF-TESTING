package com.mercury.am.platform.cmdbext.validation.attribute.qualifier;

import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

public class ValidationErrorRecord
{
  String errorCode;
  TreeMap errorMessageParams = new TreeMap();
  Object wrongValue;
  String attributeName;

  public ValidationErrorRecord(String errorCode, String attributeName, Object wrongValue)
  {
    this.errorCode = errorCode;
    this.wrongValue = wrongValue;
    this.attributeName = attributeName;

    addErrorMessageParam("ATTR_NAME", attributeName);
    if (wrongValue == null)
      addErrorMessageParam("ATTR_VALUE", null);
    else
      addErrorMessageParam("ATTR_VALUE", wrongValue.toString());
  }

  public String getErrorCode() {
    return this.errorCode;
  }

  public Map getErrorMessageParamsMap()
  {
    return this.errorMessageParams;
  }

  public Object[] getErrorMessageParams()
  {
    if (this.errorMessageParams != null)
      return this.errorMessageParams.values().toArray();

    return null;
  }

  public Object getWrongValue()
  {
    return this.wrongValue;
  }

  public void addErrorMessageParam(String name, Object value) {
    this.errorMessageParams.put(name, value);
  }

  public void addErrorMessageParams(Map addMessageParams) {
    this.errorMessageParams.putAll(addMessageParams);
  }
}