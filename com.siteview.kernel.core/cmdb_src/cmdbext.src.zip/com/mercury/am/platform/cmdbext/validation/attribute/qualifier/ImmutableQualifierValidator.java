package com.mercury.am.platform.cmdbext.validation.attribute.qualifier;

import com.mercury.am.platform.cmdbext.validation.attribute.AttributeValidationException;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import java.util.Map;

public class ImmutableQualifierValidator extends ReadonlyQualifierValidator
{
  public void validateNew(ClassModelQualifier qualifier, CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues)
    throws AttributeValidationException
  {
  }
}