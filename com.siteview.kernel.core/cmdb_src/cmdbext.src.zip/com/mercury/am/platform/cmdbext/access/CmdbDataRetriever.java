package com.mercury.am.platform.cmdbext.access;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.mig.runtime.MessageRepository;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbResponseException;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLinks;
import com.mercury.topaz.cmdb.shared.model.link.id.CmdbLinkID;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObjects;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectIds;
import com.mercury.topaz.cmdb.shared.model.object.id.impl.CmdbObjectIdsFactory;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;
import com.mercury.topaz.cmdb.shared.tql.definition.ModifiablePattern;
import com.mercury.topaz.cmdb.shared.tql.definition.PatternState;
import com.mercury.topaz.cmdb.shared.tql.definition.Priority.PatternPriorityType;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.ModifiablePatternGraph;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternLink;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.PatternNode;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementClassCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ElementCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.ModifiableNodeLinksCondition;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.condition.impl.PatternConditionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.graph.impl.PatternGraphFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.group.PatternGroupId;
import com.mercury.topaz.cmdb.shared.tql.definition.id.PatternElementNumber;
import com.mercury.topaz.cmdb.shared.tql.definition.id.impl.PatternElementNumberFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.impl.PatternDefinitionFactory;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.ElementSimpleLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.PatternLayout;
import com.mercury.topaz.cmdb.shared.tql.definition.layout.impl.PatternLayoutFactory;
import com.mercury.topaz.cmdb.shared.tql.operation.query.impl.TqlQueryGetAdHocMap;
import com.mercury.topaz.cmdb.shared.tql.result.TqlResultMap;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CmdbDataRetriever
{
  private static Log LOGGER = LogFactory.getEasyLog(CmdbDataRetriever.class);

  public static CmdbObject getObject(ElementLayout layout, CmdbObjectID id, CmdbContext context)
  {
    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start call to getObject: CmdbObjectID = " + ((id == null) ? "null" : id.toString()) + " , context = " + ((context == null) ? "null" : context.toString()));
    }

    PatternElementNumber objectNodeID = PatternElementNumberFactory.createElementNumber(1);
    CmdbObjectIds ids = CmdbObjectIdsFactory.create();
    ids.add(id);
    ElementClassCondition classCon = PatternConditionFactory.createElementClassCondition(CMDBConstants.OBJECT_CLASS.getName(), true);
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(classCon, null, ids);
    PatternNode node = PatternGraphFactory.createPatternNode(objectNodeID, elementCondition, true, null);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(node);

    PatternGroupId patternGroup = PatternGroupId.PATTERN_GROUP_ALL;
    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("", "ITUSingleObjectPattren", patternGroup, patternGraph);
    PatternState patternState = PatternDefinitionFactory.createPatternState(false, true, PatternPriorityType.EXPRESS_PRIORITY, false);
    pattern.setState(patternState);

    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    patternLayout.setElementLayout(objectNodeID, layout);
    pattern.setDefaultLayout(patternLayout);

    TqlQueryGetAdHocMap getAdHocMap = new TqlQueryGetAdHocMap(pattern, patternLayout);
    try
    {
      if (LOGGER.isInfoEnabled())
        LOGGER.info("Before calling  CmdbApi.executeCMDBOperation: operation = TqlQueryGetAdHocMap, CmdbContext = " + ((context == null) ? "null" : context.toString()));

      CmdbApi api = CmdbApiFactoryThinWrapper.getInstance();
      api.executeCMDBOperation(getAdHocMap, context);
      if (LOGGER.isInfoEnabled())
        LOGGER.info("After calling  CmdbApi.executeCMDBOperation: operation = TqlQueryGetAdHocMap, CmdbContext = " + ((context == null) ? "null" : context.toString()));

    }
    catch (CmdbResponseException cre)
    {
      LOGGER.error(MessageRepository.getMessage("120266"), cre);
      return null;
    }
    TqlResultMap adHocMap = getAdHocMap.getResultMap();
    if ((adHocMap != null) && (adHocMap.containsElementNumber(objectNodeID)))
    {
      CmdbObjects resObjects = adHocMap.getObjects(objectNodeID);
      if (resObjects != null)
      {
        if (LOGGER.isInfoEnabled())
          LOGGER.info("End call to getObject: CmdbObjectID = " + ((id == null) ? "null" : id.toString()) + " CmdbContext = " + context.toString() + ". return cmdb object = " + resObjects.toString());

        return ((CmdbObject)resObjects.get(id));
      }
    }
    if (LOGGER.isDebugEnabled())
      LOGGER.debug("End call to getObject, could not find cmdb object with CmdbObjectID = " + ((id == null) ? "null" : id.toString()) + " CmdbContext = " + context.toString() + ". return null");

    return null;
  }

  public static CmdbLinkDataHolder getLink(CmdbLinkID linkId, String classType, ElementSimpleLayout linkLayout, CmdbObjectID endOneId, CmdbObjectID endTwoId, CmdbContext context)
  {
    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start call to getLink: endOneId = " + ((endOneId == null) ? "null" : endOneId.toString()) + " , endTwoId = " + ((endTwoId == null) ? "null" : endTwoId.toString()) + " , link class = " + classType + " , context = " + ((context == null) ? "null" : context.toString()));
    }

    if (classType == null)
    {
      classType = CMDBConstants.LINK_CLASS.getName();
    }

    PatternElementNumber end1Number = PatternElementNumberFactory.createElementNumber(1);
    PatternElementNumber end2Number = PatternElementNumberFactory.createElementNumber(2);
    PatternElementNumber linkNumber = PatternElementNumberFactory.createElementNumber(3);

    CmdbObjectIds oneIds = CmdbObjectIdsFactory.create();
    CmdbObjectIds twoIds = CmdbObjectIdsFactory.create();
    oneIds.add(endOneId);
    twoIds.add(endTwoId);
    ElementClassCondition classObjCon = PatternConditionFactory.createElementClassCondition(CMDBConstants.OBJECT_CLASS.getName(), true);
    ElementCondition elementOneCondition = PatternConditionFactory.createElementCondition(classObjCon, null, oneIds);
    ElementCondition elementTwoCondition = PatternConditionFactory.createElementCondition(classObjCon, null, twoIds);

    ElementClassCondition classlinkCon = PatternConditionFactory.createElementClassCondition(classType, true);
    ElementCondition linkNodeCondition = PatternConditionFactory.createElementCondition(classlinkCon);

    ModifiableNodeLinksCondition linkCondition = PatternConditionFactory.createNodeLinksCondition();
    linkCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(linkNumber.getNumber(), 1, -1));

    PatternNode end1Node = PatternGraphFactory.createPatternNode(end1Number, elementOneCondition, true, linkCondition);
    PatternNode end2Node = PatternGraphFactory.createPatternNode(end2Number, elementTwoCondition, true, linkCondition);
    PatternLink linkNode = PatternGraphFactory.createPatternLink(linkNumber, end1Number, end2Number, linkNodeCondition, true, false);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(end1Node);
    patternGraph.addNode(end2Node);
    patternGraph.addLink(linkNode);

    PatternGroupId patternGroup = PatternGroupId.PATTERN_GROUP_ALL;
    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("", "ITULinkObjectPattren", patternGroup, patternGraph);
    PatternState patternState = PatternDefinitionFactory.createPatternState(false, true, PatternPriorityType.EXPRESS_PRIORITY, false);
    pattern.setState(patternState);

    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    patternLayout.setElementLayout(end1Number, PatternLayoutUtil.createBasicLayout());
    patternLayout.setElementLayout(end2Number, PatternLayoutUtil.createBasicLayout());
    patternLayout.setElementLayout(linkNumber, linkLayout);
    pattern.setDefaultLayout(patternLayout);

    TqlQueryGetAdHocMap getAdHocMap = new TqlQueryGetAdHocMap(pattern, patternLayout);
    try
    {
      if (LOGGER.isInfoEnabled())
        LOGGER.info("Before calling  CmdbApi.executeCMDBOperation in getLink: operation = TqlQueryGetAdHocMap, CmdbContext = " + ((context == null) ? "null" : context.toString()));

      CmdbApi api = CmdbApiFactoryThinWrapper.getInstance();
      api.executeCMDBOperation(getAdHocMap, context);
      if (LOGGER.isInfoEnabled())
        LOGGER.info("After calling  CmdbApi.executeCMDBOperation in getLink: operation = TqlQueryGetAdHocMap, CmdbContext = " + ((context == null) ? "null" : context.toString()));

    }
    catch (CmdbResponseException cre)
    {
      LOGGER.error(MessageRepository.getMessage("120267"), cre);
      return null;
    }
    TqlResultMap adHocMap = getAdHocMap.getResultMap();
    CmdbObject end1Object = (CmdbObject)adHocMap.getObjects(end1Number).get(endOneId);
    CmdbObject end2Object = (CmdbObject)adHocMap.getObjects(end2Number).get(endTwoId);

    CmdbLink linkObject = null;
    ReadOnlyIterator links = adHocMap.getLinks(linkNumber).getLinksIterator();
    while (links.hasNext())
    {
      CmdbLink link = (CmdbLink)links.next();
      if (((CmdbLinkID)link.getID()).equals(linkId))
      {
        linkObject = link;
        break;
      }
    }
    if (LOGGER.isInfoEnabled())
      LOGGER.info("End call getLink: returned link id = " + ((linkObject == null) ? "null" : ((CmdbLinkID)linkObject.getID()).toString()) + " , link type = " + ((linkObject == null) ? "null" : linkObject.getType()));

    CmdbLinkDataHolder retVal = new CmdbLinkDataHolder(end1Object, end2Object, linkObject);
    return retVal;
  }

  public static CmdbObjects getObjectsNotInInstanceView(CmdbObjectIds objectsIds, String viewID, CmdbContext context)
  {
    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start call to getObjectsNotInInstanceView: objectsIds = " + ((objectsIds == null) ? "null" : new StringBuilder().append(objectsIds.toString()).append(" , viewId = ").append(viewID).append(" , context = ").append((context == null) ? "null" : context.toString()).toString()));
    }

    PatternElementNumber objectNodeID = PatternElementNumberFactory.createElementNumber(1);
    ElementClassCondition classCon = PatternConditionFactory.createElementClassCondition(CMDBConstants.OBJECT_CLASS.getName(), true);

    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(classCon, null, objectsIds);
    PatternNode node = PatternGraphFactory.createPatternNode(objectNodeID, elementCondition, true, null);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(node);

    PatternGroupId patternGroup = PatternGroupId.PATTERN_GROUP_ALL;
    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("", "ITUSingleObjectPattren", patternGroup, patternGraph);
    PatternState patternState = PatternDefinitionFactory.createPatternState(false, true, PatternPriorityType.EXPRESS_PRIORITY, false);
    pattern.setState(patternState);

    ElementLayout layout = PatternLayoutUtil.createSimpleLayoutForAttributes(new String[] { "view_ids" });
    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    patternLayout.setElementLayout(objectNodeID, layout);
    pattern.setDefaultLayout(patternLayout);

    TqlQueryGetAdHocMap getAdHocMap = new TqlQueryGetAdHocMap(pattern, patternLayout);
    try
    {
      if (LOGGER.isInfoEnabled())
        LOGGER.info("Before calling  CmdbApi.executeCMDBOperation in getObjectsNotInInstanceView: operation = TqlQueryGetAdHocMap, context = " + ((context == null) ? "null" : context.toString()));

      CmdbApi api = CmdbApiFactoryThinWrapper.getInstance();
      api.executeCMDBOperation(getAdHocMap, context);
      if (LOGGER.isInfoEnabled())
        LOGGER.info("After calling  CmdbApi.executeCMDBOperation in getObjectsNotInInstanceView: operation = TqlQueryGetAdHocMap, context = " + ((context == null) ? "null" : context.toString()));

    }
    catch (CmdbResponseException cre)
    {
      LOGGER.error(MessageRepository.getMessage("120300"), cre);
      return null;
    }
    TqlResultMap adHocMap = getAdHocMap.getResultMap();
    if ((adHocMap != null) && (adHocMap.containsElementNumber(objectNodeID)))
    {
      CmdbObjects objects = adHocMap.getObjects(objectNodeID);

      List tempList = new ArrayList();
      for (ReadOnlyIterator i = objects.getObjectsIterator(); i.hasNext(); )
      {
        CmdbObject one = (CmdbObject)i.next();
        CmdbProperty prop = one.getProperty("view_ids");
        if ((prop != null) && (!(prop.isValueEmpty())))
        {
          CmdbPropertyValues viewsID = (CmdbPropertyValues)prop.getValue();
          if (viewsID.contains(viewID))
          {
            tempList.add(one.getID());
          }
        }
      }
      if (tempList.size() > 0)
      {
        for (int i = 0; i < tempList.size(); ++i)
        {
          objects.remove((CmdbObjectID)tempList.get(i));
        }
      }
      if (LOGGER.isInfoEnabled())
        LOGGER.info("End call to getObjectsNotInInstanceView: objectsIds = " + ((objectsIds == null) ? "null" : new StringBuilder().append(objectsIds.toString()).append(" , viewId = ").append(viewID).append(" , context = ").append((context == null) ? "null" : context.toString()).toString()) + " , result size = " + objects.size());

      return objects;
    }
    if (LOGGER.isInfoEnabled())
      LOGGER.info("End call to getObjectsNotInInstanceView: objectsIds = " + ((objectsIds == null) ? "null" : new StringBuilder().append(objectsIds.toString()).append(" , viewId = ").append(viewID).append(" , context = ").append((context == null) ? "null" : context.toString()).toString()) + " , result = null");

    return null;
  }

  public static CmdbObject[] getObjetcs(ElementLayout layout, CmdbObjectIds objectsIds, CmdbContext context)
  {
    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start call to getObjetcs: objectsIds = " + ((objectsIds == null) ? "null" : new StringBuilder().append(objectsIds.toString()).append(" , context = ").append((context == null) ? "null" : context.toString()).toString()));
    }

    PatternElementNumber objectNodeID = PatternElementNumberFactory.createElementNumber(1);
    ElementClassCondition classCon = PatternConditionFactory.createElementClassCondition("object", true);
    ElementCondition elementCondition = PatternConditionFactory.createElementCondition(classCon, null, objectsIds);
    PatternNode node = PatternGraphFactory.createPatternNode(objectNodeID, elementCondition, true, null);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(node);

    PatternGroupId patternGroup = PatternGroupId.PATTERN_GROUP_ALL;
    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("", "ITUGetObjectPattren", patternGroup, patternGraph);
    PatternState patternState = PatternDefinitionFactory.createPatternState(false, true, PatternPriorityType.EXPRESS_PRIORITY, false);
    pattern.setState(patternState);

    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    patternLayout.setElementLayout(objectNodeID, layout);
    pattern.setDefaultLayout(patternLayout);

    TqlQueryGetAdHocMap getAdHocMap = new TqlQueryGetAdHocMap(pattern, patternLayout);
    try
    {
      if (LOGGER.isInfoEnabled())
        LOGGER.info("Before calling  CmdbApi.executeCMDBOperation in getObjetcs: operation = TqlQueryGetAdHocMap, context = " + ((context == null) ? "null" : context.toString()));

      CmdbApi api = CmdbApiFactoryThinWrapper.getInstance();
      api.executeCMDBOperation(getAdHocMap, context);
      if (LOGGER.isInfoEnabled())
        LOGGER.info("After calling  CmdbApi.executeCMDBOperation in getObjetcs: operation = TqlQueryGetAdHocMap, context = " + ((context == null) ? "null" : context.toString()));

    }
    catch (CmdbResponseException cre)
    {
      LOGGER.error(MessageRepository.getMessage("120304"), cre);
      return null;
    }
    CmdbObject[] retVal = new CmdbObject[0];
    TqlResultMap adHocMap = getAdHocMap.getResultMap();
    if ((adHocMap != null) && (adHocMap.containsElementNumber(objectNodeID)))
    {
      CmdbObjects objects = adHocMap.getObjects(objectNodeID);
      if ((objects != null) && (objects.size() > 0))
      {
        retVal = new CmdbObject[objects.size()];
        int z = 0;
        for (ReadOnlyIterator i = objects.getObjectsIterator(); i.hasNext(); )
        {
          retVal[z] = ((CmdbObject)i.next());
          ++z;
        }
      }
    }
    if (LOGGER.isInfoEnabled())
      LOGGER.info("Start call to getObjetcs: objectsIds = " + ((objectsIds == null) ? "null" : new StringBuilder().append(objectsIds.toString()).append(" , context = ").append((context == null) ? "null" : context.toString()).toString()) + " , result size = " + retVal.length);

    return retVal;
  }

  public static Map getLinks(Map linksIds2End1, Map linksIds2End2, ElementSimpleLayout linkLayout, CmdbContext context)
  {
    String classType = "it_world_links";

    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start call to getLinks: linksIds2End1 = " + ((linksIds2End1 == null) ? "null" : linksIds2End1.toString()) + ", link class = " + classType + " , context = " + ((context == null) ? "null" : context.toString()));
    }

    CmdbObjectIds oneIds = getCmdbObjectIds(linksIds2End1);
    CmdbObjectIds twoIds = getCmdbObjectIds(linksIds2End2);

    PatternElementNumber end1Number = PatternElementNumberFactory.createElementNumber(1);
    PatternElementNumber end2Number = PatternElementNumberFactory.createElementNumber(2);
    PatternElementNumber linkNumber = PatternElementNumberFactory.createElementNumber(3);

    ElementClassCondition classObjCon = PatternConditionFactory.createElementClassCondition(CMDBConstants.OBJECT_CLASS.getName(), true);
    ElementCondition elementOneCondition = PatternConditionFactory.createElementCondition(classObjCon, null, oneIds);
    ElementCondition elementTwoCondition = PatternConditionFactory.createElementCondition(classObjCon, null, twoIds);

    ElementClassCondition classlinkCon = PatternConditionFactory.createElementClassCondition(classType, true);
    ElementCondition linkNodeCondition = PatternConditionFactory.createElementCondition(classlinkCon);

    ModifiableNodeLinksCondition linkCondition = PatternConditionFactory.createNodeLinksCondition();
    linkCondition.addLinkCardinality(PatternConditionFactory.createLinkCardinality(linkNumber.getNumber(), 0, -1));

    PatternNode end1Node = PatternGraphFactory.createPatternNode(end1Number, elementOneCondition, true, linkCondition);
    PatternNode end2Node = PatternGraphFactory.createPatternNode(end2Number, elementTwoCondition, true, linkCondition);
    PatternLink linkNode = PatternGraphFactory.createPatternLink(linkNumber, end1Number, end2Number, linkNodeCondition, true, false);

    ModifiablePatternGraph patternGraph = PatternGraphFactory.createModifiableGraph();
    patternGraph.addNode(end1Node);
    patternGraph.addNode(end2Node);
    patternGraph.addLink(linkNode);

    PatternGroupId patternGroup = PatternGroupId.PATTERN_GROUP_ALL;
    ModifiablePattern pattern = PatternDefinitionFactory.createPattern("", "ITULinkObjectPattren", patternGroup, patternGraph);
    PatternState patternState = PatternDefinitionFactory.createPatternState(false, true, PatternPriorityType.EXPRESS_PRIORITY, false);
    pattern.setState(patternState);

    PatternLayout patternLayout = PatternLayoutFactory.createLayout();
    patternLayout.setElementLayout(end1Number, PatternLayoutUtil.createBasicLayout());
    patternLayout.setElementLayout(end2Number, PatternLayoutUtil.createBasicLayout());
    patternLayout.setElementLayout(linkNumber, linkLayout);
    pattern.setDefaultLayout(patternLayout);

    TqlQueryGetAdHocMap getAdHocMap = new TqlQueryGetAdHocMap(pattern, patternLayout);
    try
    {
      if (LOGGER.isInfoEnabled())
        LOGGER.info("Before calling  CmdbApi.executeCMDBOperation in getLink: operation = TqlQueryGetAdHocMap, CmdbContext = " + ((context == null) ? "null" : context.toString()));

      CmdbApi api = CmdbApiFactoryThinWrapper.getInstance();
      api.executeCMDBOperation(getAdHocMap, context);
      if (LOGGER.isInfoEnabled())
        LOGGER.info("After calling  CmdbApi.executeCMDBOperation in getLink: operation = TqlQueryGetAdHocMap, CmdbContext = " + ((context == null) ? "null" : context.toString()));

    }
    catch (CmdbResponseException cre)
    {
      LOGGER.error(MessageRepository.getMessage("120267"), cre);
      return null;
    }
    TqlResultMap adHocMap = getAdHocMap.getResultMap();

    Map linksDataHolder = new HashMap();
    ReadOnlyIterator links = adHocMap.getLinks(linkNumber).getLinksIterator();
    while (links.hasNext())
    {
      CmdbLink link = (CmdbLink)links.next();
      CmdbObjectID end1Id = (CmdbObjectID)linksIds2End1.get(link.getID());
      CmdbObjectID end2Id = (CmdbObjectID)linksIds2End2.get(link.getID());
      if ((end1Id != null) && (end2Id != null)) {
        CmdbObject end1Object = (CmdbObject)adHocMap.getObjects(end1Number).get(end1Id);
        CmdbObject end2Object = (CmdbObject)adHocMap.getObjects(end2Number).get(end2Id);
        CmdbLinkDataHolder dataHolder = new CmdbLinkDataHolder(end1Object, end2Object, link);
        linksDataHolder.put(link.getID(), dataHolder);
      }
    }
    if (LOGGER.isInfoEnabled())
      LOGGER.info("End call to getLinks: linksIds2End1 = " + ((linksIds2End1 == null) ? "null" : linksIds2End1.toString()) + ", link class = " + classType + " , context = " + ((context == null) ? "null" : context.toString()));

    return linksDataHolder;
  }

  private static CmdbObjectIds getCmdbObjectIds(Map linkId2End)
  {
    CmdbObjectIds ids = CmdbObjectIdsFactory.create();
    for (Iterator iterator = linkId2End.keySet().iterator(); iterator.hasNext(); ) {
      CmdbLinkID cmdbLinkID = (CmdbLinkID)iterator.next();
      CmdbObjectID cmdbObjectID = (CmdbObjectID)linkId2End.get(cmdbLinkID);
      ids.add(cmdbObjectID);
    }
    return ids;
  }
}