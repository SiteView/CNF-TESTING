package com.mercury.am.platform.cmdbext.processing;

import com.mercury.am.platform.cmdbext.cmhandler.CmdbAttributeHandler;
import com.mercury.am.platform.cmdbext.cmhandler.HandlerUtil;
import com.mercury.am.platform.cmdbext.validation.utils.ValidationUtils;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.TypeVisitor;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBytesType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDateType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDoubleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbFloatType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.Numeric;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;
import java.util.List;
import java.util.Vector;

public class DefaultAttributeInputProcessorFactory
  implements AttributeInputProcessorFactory
{
  private static Log LOGGER = LogFactory.getEasyLog(DefaultAttributeInputProcessorFactory.class);
  private static DefaultAttributeInputProcessorFactory singleton = new DefaultAttributeInputProcessorFactory();
  private static StringAttributeProcessor stringAttributeProcessor = new StringAttributeProcessor();
  private static AttributeInputProcessor intAttributeProcessor = new NumericAttributeProcessor(Integer.class);
  private static AttributeInputProcessor longAttributeProcessor = new NumericAttributeProcessor(Long.class);
  private static AttributeInputProcessor floatAttributeProcessor = new NumericAttributeProcessor(Float.class);
  private static BooleanAttributeProcessor booleanAttributeProcessor = new BooleanAttributeProcessor();
  private static DateAttributeProcessor dateAttributeProcessor = new DateAttributeProcessor();
  private static AttributeInputProcessor doubleAttributeProcessor = new NumericAttributeProcessor(Double.class);
  private static StringListAttributeProcessor stringListAttributeProcessor = new StringListAttributeProcessor();
  private static IntegerListAttributeProcessor integerListAttributeProcessor = new IntegerListAttributeProcessor();
  private static PasswordAttributeProcessor passwordAttributeProcessor = new PasswordAttributeProcessor();

  public static DefaultAttributeInputProcessorFactory getInstance()
  {
    return singleton;
  }

  public AttributeInputProcessor create(CmdbAttribute attribute, CmdbClass cmdbClass, CmdbClassModel classModel)
    throws AttributeProcessingException
  {
    CmdbAttributeHandler attributeHandler = HandlerUtil.findAttributeHandlerQualifier(attribute);
    if ((attributeHandler != null) && (attributeHandler.hasInputProcessor())) {
      AttributeInputProcessor inputProcessor = attributeHandler.getInputProcessor();
      if (inputProcessor != null) {
        return inputProcessor;
      }

    }

    AttributeInputProcessor result = new ProcessorByTypeCreator(this, attribute).createProcessor();

    if (result == null) {
      if (LOGGER.isDebugEnabled())
        LOGGER.debug("Could not create processor for attribute: attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " cmdb class name = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()));

      AttributeProcessingException exception = new AttributeProcessingException(attribute, null, "no.processor.for.attribute");
      List errorMessageArguments = new Vector();
      errorMessageArguments.add(attribute.getName());
      errorMessageArguments.add(attribute.getResolvedType().getName());
      exception.setErrorParams(errorMessageArguments);
      throw exception;
    }
    return result;
  }

  private class ProcessorByTypeCreator
  implements TypeVisitor
  {
    private AttributeInputProcessor processor;
    private CmdbAttribute attribute;

    public ProcessorByTypeCreator(, CmdbAttribute paramCmdbAttribute)
    {
      this.attribute = attribute;
    }

    public AttributeInputProcessor createProcessor() {
      this.attribute.getResolvedType().accept(this);
      return this.processor;
    }

    public void visit()
    {
    }

    public void visit()
    {
    }

    public void visit()
    {
      this.processor = DefaultAttributeInputProcessorFactory.access$000();
    }

    public void visit() {
      this.processor = DefaultAttributeInputProcessorFactory.access$100();
    }

    public void visit() {
      this.processor = DefaultAttributeInputProcessorFactory.access$200();
    }

    public void visit() {
      this.processor = DefaultAttributeInputProcessorFactory.access$300();
    }

    public void visit() {
      this.processor = DefaultAttributeInputProcessorFactory.access$400();
    }

    public void visit()
    {
      this.processor = DefaultAttributeInputProcessorFactory.access$400();
    }

    public void visit() {
      this.processor = DefaultAttributeInputProcessorFactory.access$500();
    }

    public void visit() {
      this.processor = DefaultAttributeInputProcessorFactory.access$600();
    }

    public void visit() {
      if (ValidationUtils.findAttributeQualifierByName(this.attribute, CmdbAttributeQualifierDefs.ENCRYPTED_ATTRIBUTE.getName()) != null) {
        this.processor = DefaultAttributeInputProcessorFactory.access$700();
      }
      else
        this.processor = new SimpleAttributeProcessor(cmdbBytesType.getJavaClass());
    }

    public void visit()
    {
    }

    public void visit()
    {
      this.processor = DefaultAttributeInputProcessorFactory.access$800();
    }

    public void visit() {
      this.processor = DefaultAttributeInputProcessorFactory.access$900();
    }

    public void visit()
    {
    }

    public void visit()
    {
      this.processor = DefaultAttributeInputProcessorFactory.access$000();
    }

    public void visit()
    {
      cmdbList.getType().accept(this);
    }

    public void visit() {
      this.processor = DefaultAttributeInputProcessorFactory.access$400();
    }
  }
}