package com.mercury.am.platform.cmdbext.access.jmx.classmodelcache;

import com.mercury.am.platform.cmdbext.access.ClassModelFactoryThinWrapper;

public class ClassModelCacheJMX
  implements ClassModelCacheJMXMBean
{
  public void init()
  {
  }

  public void start()
  {
  }

  public void stop()
  {
  }

  public void destroy()
    throws Exception
  {
    reset();
  }

  public void refresh()
    throws Exception
  {
    ((ClassModelFactoryThinWrapper)ClassModelFactoryThinWrapper.getInstance()).refresh();
  }

  public void reset()
    throws Exception
  {
    ((ClassModelFactoryThinWrapper)ClassModelFactoryThinWrapper.getInstance()).reset();
  }
}