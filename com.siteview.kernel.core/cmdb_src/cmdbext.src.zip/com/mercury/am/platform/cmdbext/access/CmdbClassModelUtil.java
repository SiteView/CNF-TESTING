package com.mercury.am.platform.cmdbext.access;

import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.base.entity.ClassModelEntity;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.util.Date;
import java.util.LinkedList;
import org.apache.commons.lang.StringUtils;

public class CmdbClassModelUtil
{
  public static final HistoryCmdbAttributeQualifierDef HISTORY_QUALIFIER = new HistoryCmdbAttributeQualifierDef(null);
  public static final ITUHiddenCmdbAttributeQualifierDef ITU_HIDDEN_ATTRIBUTE_QUALIFIER = new ITUHiddenCmdbAttributeQualifierDef(null);
  public static final ITUHiddenCmdbClassQualifierDef ITU_HIDDEN_CLASS_QUALIFIER = new ITUHiddenCmdbClassQualifierDef(null);
  public static final ITURandomIdAttributeQualifierDef ITU_RANDOM_ID_ATTRIBUTE_QUALIFIER = new ITURandomIdAttributeQualifierDef(null);
  public static final ITUClassHandlerQualifierDef ITU_CLASS_HANDLER_QUALIFIER = new ITUClassHandlerQualifierDef(null);
  public static final CmdbAttributeQualifierDef[] NON_VIEW_QUALIFIERS = { CmdbAttributeQualifierDefs.STATIC_ATTRIBUTE, CmdbAttributeQualifierDefs.HIDDEN_ATTRIBUTE, HISTORY_QUALIFIER, ITU_HIDDEN_ATTRIBUTE_QUALIFIER };
  public static final CmdbAttributeQualifierDef[] NON_EDIT_QUALIFIERS = { CmdbAttributeQualifierDefs.STATIC_ATTRIBUTE, CmdbAttributeQualifierDefs.HIDDEN_ATTRIBUTE, CmdbAttributeQualifierDefs.ID_ATTRIBUTE, CmdbAttributeQualifierDefs.READ_ONLY_ATTRIBUTE, HISTORY_QUALIFIER, ITU_HIDDEN_ATTRIBUTE_QUALIFIER };
  public static final CmdbAttributeQualifierDef[] NON_NEW_QUALIFIERS = { CmdbAttributeQualifierDefs.STATIC_ATTRIBUTE, CmdbAttributeQualifierDefs.HIDDEN_ATTRIBUTE, HISTORY_QUALIFIER, CmdbAttributeQualifierDefs.READ_ONLY_ATTRIBUTE, ITU_HIDDEN_ATTRIBUTE_QUALIFIER };
  public static final CmdbAttributeQualifierDef[] NON_DETAILS_QUALIFIERS = { CmdbAttributeQualifierDefs.STATIC_ATTRIBUTE, HISTORY_QUALIFIER };

  public static String[] getAttributesForViewCmdbDataForm(CmdbClass cmdbClass)
  {
    return getFilteredAttributesByQualifiers(cmdbClass, NON_VIEW_QUALIFIERS);
  }

  public static String[] getAttributesForUpdateCmdbData(CmdbClass cmdbClass)
  {
    return getFilteredAttributesByQualifiers(cmdbClass, NON_EDIT_QUALIFIERS);
  }

  public static String[] getAttributesForNewCmdbDataForm(CmdbClass cmdbClass)
  {
    return getFilteredAttributesByQualifiers(cmdbClass, NON_NEW_QUALIFIERS);
  }

  public static String[] getAttributesForCmdbDataDetails(CmdbClass cmdbClass)
  {
    return getFilteredAttributesByQualifiers(cmdbClass, NON_DETAILS_QUALIFIERS);
  }

  public static String[] getFilteredAttributesByQualifiers(CmdbClass cmdbClass, CmdbAttributeQualifierDef[] qualifiers)
  {
    CmdbAttributes allAttributes = cmdbClass.getAllAttributes();
    LinkedList attributesNames = new LinkedList();
    for (ReadOnlyIterator iterator = allAttributes.getIterator(); iterator.hasNext(); ) {
      CmdbAttribute attribute = (CmdbAttribute)iterator.next();
      if (!(isAttributeMatchQualifiers(cmdbClass, attribute, qualifiers)))
        attributesNames.add(attribute.getName());
    }

    return ((String[])(String[])attributesNames.toArray(new String[attributesNames.size()]));
  }

  public static boolean isAttributeMatchQualifiers(CmdbClass cmdbClass, CmdbAttribute attribute, CmdbAttributeQualifierDef[] qualifiers)
  {
    if (qualifiers == null)
      return false;

    for (int i = 0; i < qualifiers.length; ++i)
    {
      if (cmdbClass.getAttributesByQualifier(qualifiers[i]).hasAttribute(attribute.getName()))
        return true;

    }

    return false;
  }

  private static CmdbProperties genareteProperties(CmdbClass cmdbClass)
  {
    CmdbProperties properties = CmdbPropertyFactory.createProperties();

    for (ReadOnlyIterator attributeIterator = cmdbClass.getAllAttributes().getIterator(); attributeIterator.hasNext(); ) {
      CmdbAttribute cmdbAttribute = (CmdbAttribute)attributeIterator.next();
      Object defaultValue = cmdbAttribute.getDefaultValue();
      if (defaultValue == null) {
        CmdbType cmdbType = cmdbAttribute.getResolvedType();
        if (cmdbType != null) {
          CmdbProperty cmdbProperty = createDefaultProperty(cmdbAttribute, cmdbType);
          if (cmdbProperty != null)
            properties.add(cmdbProperty);
        }
      }
      if ((defaultValue instanceof String) && (!(StringUtils.isEmpty((String)defaultValue))))
        if (cmdbAttribute.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbString.getName()))
          properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), (String)defaultValue));
        else if (cmdbAttribute.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbInteger.getName()))
          properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), Integer.valueOf((String)defaultValue)));
        else if (cmdbAttribute.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbLong.getName()))
          properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), Long.valueOf((String)defaultValue)));
        else if (cmdbAttribute.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbFloat.getName()))
          properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), Float.valueOf((String)defaultValue)));
        else if (cmdbAttribute.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbDouble.getName()))
          properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), Double.valueOf((String)defaultValue)));
        else if (cmdbAttribute.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbBoolean.getName()))
          properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), Boolean.valueOf((String)defaultValue)));
      else if (defaultValue instanceof Integer)
        properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), (Integer)defaultValue));
      else if (defaultValue instanceof Long)
        properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), (Long)defaultValue));
      else if (defaultValue instanceof Float)
        properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), (Float)defaultValue));
      else if (defaultValue instanceof Double)
        properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), (Double)defaultValue));
      else if (defaultValue instanceof Boolean)
        properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), (Boolean)defaultValue));
      else if (defaultValue instanceof Date)
        properties.add(CmdbPropertyFactory.createProperty(cmdbAttribute.getName(), (Date)defaultValue));
    }

    return properties;
  }

  private static CmdbProperty createDefaultProperty(CmdbAttribute attribute, CmdbType cmdbType)
  {
    CmdbAttributeQualifiers attributeQualifiers = attribute.getQualifiers();

    if (((attributeQualifiers != null) && (attributeQualifiers.containsQualifier(CmdbAttributeQualifierDefs.ID_ATTRIBUTE.getName()))) || (attributeQualifiers.containsQualifier(CmdbAttributeQualifierDefs.REQUIRED_ATTRIBUTE.getName())))
    {
      if (cmdbType.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbBoolean.getName()))
        return CmdbPropertyFactory.createProperty(attribute.getName(), Boolean.TRUE);
      if (cmdbType.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbDate.getName()))
        return CmdbPropertyFactory.createProperty(attribute.getName(), new Date());
      if (cmdbType.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbFloat.getName()))
        return CmdbPropertyFactory.createProperty(attribute.getName(), new Float(new Date().getTime() / 3.1415926535897931D));
      if (cmdbType.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbDouble.getName()))
        return CmdbPropertyFactory.createProperty(attribute.getName(), new Double(new Date().getTime() / 3.1415926535897931D));
      if (cmdbType.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbInteger.getName()))
        return CmdbPropertyFactory.createProperty(attribute.getName(), new Integer((int)new Date().getTime()));
      if (cmdbType.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbLong.getName()))
        return CmdbPropertyFactory.createProperty(attribute.getName(), new Long(new Date().getTime()));
      if (cmdbType.getName().equalsIgnoreCase(CmdbSimpleTypes.CmdbString.getName())) {
        String stringVal = "" + new Date().getTime();

        int sizeLimit = attribute.getSizeLimit().intValue();
        if ((sizeLimit > 0) && (stringVal.length() > sizeLimit))
          return CmdbPropertyFactory.createProperty(attribute.getName(), stringVal.substring(0, sizeLimit));

        return CmdbPropertyFactory.createProperty(attribute.getName(), stringVal);
      }
    }

    return null;
  }

  public static CmdbObject createDefaultCmdbObject(CmdbClassModel classModel, CmdbClass cmdbClass)
  {
    DataFactory dataFactory = DataFactoryCreator.create(classModel);
    return dataFactory.createObject(cmdbClass.getName(), genareteProperties(cmdbClass));
  }

  public static CmdbLink createDefaultCmdbLink(CmdbClassModel classModel, CmdbClass cmdbClass, CmdbObjectID end1, CmdbObjectID end2)
  {
    DataFactory dataFactory = DataFactoryCreator.create(classModel);
    return dataFactory.createLink(cmdbClass.getName(), end1, end2, genareteProperties(cmdbClass));
  }

  public static class ITUClassHandlerQualifierDef
  implements CmdbClassQualifierDef
  {
    String name = "HANDLER";
    String displayName = "HANDLER";
    String description = "Special class handlers";

    public String getDisplayName()
    {
      return this.displayName;
    }

    public String getDescription() {
      return this.description;
    }

    public String getName() {
      return this.name;
    }

    public ClassModelEntity getDeepReadOnlyCopy() {
      return this; }

    public Boolean isModifiedByUser() {
      return Boolean.FALSE; }

    public Boolean isCreatedByFactory() {
      return Boolean.FALSE;
    }
  }

  public static class ITURandomIdAttributeQualifierDef
  implements CmdbAttributeQualifierDef
  {
    String name = "ITU_RANDOM_GENERATED_ATTRIBUTE";
    String displayName = "ITU_RANDOM_GENERATED_ATTRIBUTE";
    String description = "For Id attributes that ITU should generate random value for";

    public String getDisplayName()
    {
      return this.displayName;
    }

    public String getDescription() {
      return this.description;
    }

    public String getName() {
      return this.name;
    }

    public ClassModelEntity getDeepReadOnlyCopy() {
      return this; }

    public Boolean isModifiedByUser() {
      return Boolean.FALSE; }

    public Boolean isCreatedByFactory() {
      return Boolean.FALSE;
    }
  }

  public static class ITUHiddenCmdbClassQualifierDef
  implements CmdbClassQualifierDef
  {
    String name = "ITU_HIDDEN_CLASS";
    String displayName = "ITU HIDDEN CLASS";
    String description = "Users can not create instance of this class in ITUM application";

    public String getDisplayName()
    {
      return this.displayName;
    }

    public String getDescription() {
      return this.description;
    }

    public String getName() {
      return this.name;
    }

    public ClassModelEntity getDeepReadOnlyCopy() {
      return this; }

    public Boolean isModifiedByUser() {
      return Boolean.FALSE; }

    public Boolean isCreatedByFactory() {
      return Boolean.FALSE;
    }
  }

  public static class ITUHiddenCmdbAttributeQualifierDef
  implements CmdbAttributeQualifierDef
  {
    String name = "ITU_HIDDEN_ATTRIBUTE";
    String displayName = "ITU HIDDEN ATTRIBUTE";
    String description = "instance of this attribute should not be displayed in ITUM application";

    public String getDisplayName()
    {
      return this.displayName;
    }

    public String getDescription() {
      return this.description;
    }

    public String getName() {
      return this.name;
    }

    public ClassModelEntity getDeepReadOnlyCopy() {
      return this; }

    public Boolean isModifiedByUser() {
      return Boolean.FALSE; }

    public Boolean isCreatedByFactory() {
      return Boolean.FALSE;
    }
  }

  public static class HistoryCmdbAttributeQualifierDef
  implements CmdbAttributeQualifierDef
  {
    String name = "SAVE_HISTORY";
    String displayName = "SAVE HISTORY";
    String description = "instance of this attribute is historical ";

    public String getDisplayName()
    {
      return this.displayName;
    }

    public String getDescription() {
      return this.description;
    }

    public String getName() {
      return this.name;
    }

    public ClassModelEntity getDeepReadOnlyCopy() {
      return this; }

    public Boolean isModifiedByUser() {
      return Boolean.FALSE; }

    public Boolean isCreatedByFactory() {
      return Boolean.FALSE;
    }
  }
}