package com.mercury.am.platform.cmdbext.processing;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Date;

public class DateAttributeProcessor extends SimpleAttributeProcessor
{
  private static Log LOGGER = LogFactory.getEasyLog(DateAttributeProcessor.class);

  public DateAttributeProcessor()
  {
    super(Date.class);
  }

  protected Object processStringValue(CmdbAttribute attribute, String valueAsString, CmdbData currentData, BasicUserData userContext) throws AttributeProcessingException, Exception
  {
    if (valueAsString.trim().length() == 0) {
      return null;
    }

    try
    {
      return new Date(Long.parseLong(valueAsString));
    } catch (Exception e) {
      LOGGER.error("failed to process value -'" + valueAsString + "' for attribute " + attribute.getName());
    }

    return super.processStringValue(attribute, valueAsString, currentData, userContext);
  }

  protected String getErrorCode(CmdbAttribute attribute) {
    return "processor.error.not.date";
  }
}