package com.mercury.am.platform.cmdbext.cmhandler;

import com.mercury.am.platform.cmdbext.access.CmdbClassModelUtil;
import com.mercury.am.platform.cmdbext.access.CmdbClassModelUtil.ITUClassHandlerQualifierDef;
import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItem;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItems;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbClassQualifier;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class HandlerUtil
{
  public static Log LOGGER = LogFactory.getEasyLog(HandlerUtil.class);

  public static CmdbClassHandler findClassHandlerQualifier(CmdbClass cmdbClass)
  {
    CmdbClassQualifier qualifier = findClassQualifierByName(cmdbClass, CmdbClassModelUtil.ITU_CLASS_HANDLER_QUALIFIER.getName());
    if (qualifier == null) return null;
    try
    {
      return fetchClassHandler(qualifier);
    } catch (Exception e) {
      if (LOGGER.isDebugEnabled())
        LOGGER.debug("Could not get handler for class = " + cmdbClass.getName(), e);
    }
    return null;
  }

  public static CmdbAttributeHandler findAttributeHandlerQualifier(CmdbAttribute cmdbAttribute)
  {
    CmdbAttributeQualifier qualifier = findAttributeQualifierByName(cmdbAttribute, CmdbAttributeQualifierDefs.HANDLED_ATTRIBUTE.getName());
    if (qualifier == null) return null;
    try
    {
      return fetchAttributeHandler(qualifier);
    } catch (Exception e) {
      if (LOGGER.isDebugEnabled())
        LOGGER.debug("Could not get handler for attribute = " + cmdbAttribute.getName(), e);
    }
    return null;
  }

  public static CmdbClassQualifier findClassQualifierByName(CmdbClass cmdbClass, String qualifierName)
  {
    return ((cmdbClass.hasQualifier(qualifierName)) ? cmdbClass.getQualifierByName(qualifierName) : null);
  }

  public static CmdbAttributeQualifier findAttributeQualifierByName(CmdbAttribute cmdbAttribute, String qualifierName)
  {
    return ((cmdbAttribute.hasQualifier(qualifierName)) ? cmdbAttribute.getQualifierByName(qualifierName) : null);
  }

  public static CmdbClassHandler fetchClassHandler(CmdbClassQualifier qualifier)
    throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
  {
    DataItem handlerDataItem = findDataItemByName(qualifier, CmdbClassModelUtil.ITU_CLASS_HANDLER_QUALIFIER.getName());

    String handlerClassName = (handlerDataItem == null) ? null : (String)handlerDataItem.getValue();
    if (StringUtils.isEmpty(handlerClassName)) {
      return null;
    }

    Class handlerClass = Class.forName(handlerClassName);
    Constructor handlerConstructor = handlerClass.getConstructor(new Class[0]);
    return ((CmdbClassHandler)handlerConstructor.newInstance(null));
  }

  public static CmdbAttributeHandler fetchAttributeHandler(CmdbAttributeQualifier qualifier)
    throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
  {
    DataItem handlerDataItem = findDataItemByName(qualifier, "HANDLER");

    String handlerClassName = (handlerDataItem == null) ? null : (String)handlerDataItem.getValue();
    if (StringUtils.isEmpty(handlerClassName)) {
      return null;
    }

    Class handlerClass = Class.forName(handlerClassName);
    Constructor handlerConstructor = handlerClass.getConstructor(new Class[0]);
    return ((CmdbAttributeHandler)handlerConstructor.newInstance(null));
  }

  public static DataItem findDataItemByName(ClassModelQualifier qualifier, String dataItemName)
  {
    DataItems dataItems = qualifier.getDataItems();
    if (dataItems != null)
      for (ReadOnlyIterator dataItemsIterator = dataItems.getIterator(); dataItemsIterator.hasNext(); ) {
        DataItem dataItem = (DataItem)dataItemsIterator.next();
        if (dataItem.getName().equalsIgnoreCase(dataItemName))
          return dataItem;

      }


    return null;
  }
}