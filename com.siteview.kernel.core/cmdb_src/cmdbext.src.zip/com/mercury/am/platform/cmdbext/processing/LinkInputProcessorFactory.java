package com.mercury.am.platform.cmdbext.processing;

import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;

public class LinkInputProcessorFactory
{
  private static LinkInputProcessorFactory singleton = new LinkInputProcessorFactory();
  private DefaultLinkInputProcessor defaultLinkProcessor;

  public static LinkInputProcessorFactory getInstance()
  {
    return singleton;
  }

  private LinkInputProcessorFactory()
  {
    this.defaultLinkProcessor = new DefaultLinkInputProcessor();
  }

  public LinkInputProcessor createProcessorForLink(CmdbClassModel classModel, CmdbClass cmdbClass)
  {
    return this.defaultLinkProcessor;
  }

  public LinkInputProcessor createProcessorForLink(String cmdbClassName, CmdbClassModel classModel) {
    return createProcessorForLink(classModel, classModel.getClass(cmdbClassName));
  }
}