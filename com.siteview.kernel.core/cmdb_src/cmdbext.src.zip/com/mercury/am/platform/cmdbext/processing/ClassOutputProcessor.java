package com.mercury.am.platform.cmdbext.processing;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public abstract interface ClassOutputProcessor
{
  public abstract Map processNew(CmdbData paramCmdbData, String paramString, CmdbClassModel paramCmdbClassModel, Map paramMap, BasicUserData paramBasicUserData, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws ClassProcessingException, NullPointerException;

  public abstract Map processExisting(CmdbData paramCmdbData, String paramString, CmdbClassModel paramCmdbClassModel, Map paramMap, BasicUserData paramBasicUserData, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws ClassProcessingException, NullPointerException;

  public abstract AttributeOutputProcessorFactory getAttributeProcessorsFactory();
}