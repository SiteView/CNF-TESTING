package com.mercury.am.platform.cmdbext.processing;

import com.mercury.am.platform.cmdbext.access.CmdbClassModelUtil;
import com.mercury.am.platform.cmdbext.validation.classes.ClassValidationException;
import com.mercury.am.platform.cmdbext.validation.classes.ClassValidator;
import com.mercury.am.platform.cmdbext.validation.classes.ClassValidatorFactory;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

public class DefaultClassInputProcessor
  implements ClassInputProcessor
{
  private static Log LOGGER = LogFactory.getEasyLog(DefaultClassInputProcessor.class);

  public Map processNew(Set attributes, CmdbClass cmdbClass, CmdbClassModel classModel, Map input, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws ClassProcessingException, NullPointerException
  {
    CmdbObject defaultCmdbObject = CmdbClassModelUtil.createDefaultCmdbObject(classModel, cmdbClass);
    return process(attributes, cmdbClass, classModel, input, defaultCmdbObject, userContext, true, cmdbContext, cmdbApi);
  }

  public Map processUpdated(Set attributes, CmdbClass cmdbClass, CmdbClassModel classModel, Map input, CmdbData currentCmdbData, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws ClassProcessingException, NullPointerException
  {
    return process(attributes, cmdbClass, classModel, input, currentCmdbData, userContext, false, cmdbContext, cmdbApi);
  }

  public Map processAndValidateNew(Set attributes, String cmdbClassName, CmdbClassModel classModel, Map input, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws ClassProcessingException, ClassValidationException, NullPointerException
  {
    if (LOGGER.isInfoEnabled())
      LOGGER.info("Start call to processAndValidateNew  for new  object/link. cmdb class = " + cmdbClassName + " input = " + ((input == null) ? "null" : input.toString()) + " , user = " + ((userContext == null) ? "null" : userContext.toString()));

    CmdbClass cmdbClass = classModel.getClass(cmdbClassName);
    Map processedInput = processNew(attributes, cmdbClass, classModel, input, userContext, cmdbContext, cmdbApi);
    ClassValidatorFactory.getInstance().create(cmdbClass, classModel).validateNew(processedInput, classModel, cmdbClass, userContext);
    if (LOGGER.isInfoEnabled())
      LOGGER.info("End call to processAndValidateNew  for new object/link. cmdb class = " + cmdbClassName + " input = " + ((input == null) ? "null" : input.toString()) + " precessed and validate output = " + ((processedInput == null) ? "null" : processedInput.toString()) + " , user = " + ((userContext == null) ? "null" : userContext.toString()));

    return processedInput;
  }

  public Map processAndValidateUpdated(Set attributes, String cmdbClassName, CmdbData cmdbData, CmdbClassModel classModel, Map input, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws ClassProcessingException, ClassValidationException, NullPointerException
  {
    if (LOGGER.isInfoEnabled())
      LOGGER.info("Start call to processAndValidateUpdated  for updating  object/link. cmdb class = " + cmdbClassName + " input = " + ((input == null) ? "null" : input.toString()) + " , user = " + ((userContext == null) ? "null" : userContext.toString()));

    CmdbClass cmdbClass = classModel.getClass(cmdbClassName);
    Map processedInput = processUpdated(attributes, cmdbClass, classModel, input, cmdbData, userContext, cmdbContext, cmdbApi);
    ClassValidatorFactory.getInstance().create(cmdbClass, classModel).validateUpdated(processedInput, classModel, cmdbClass, cmdbData, userContext);
    if (LOGGER.isInfoEnabled())
      LOGGER.info("End call to processAndValidateUpdated  for updating object/link. cmdb class = " + cmdbClassName + " input = " + ((input == null) ? "null" : input.toString()) + " precessed and validate output = " + ((processedInput == null) ? "null" : processedInput.toString()) + " , user = " + ((userContext == null) ? "null" : userContext.toString()));

    return processedInput;
  }

  public Map process(Set attributes, CmdbClass cmdbClass, CmdbClassModel classModel, Map input, CmdbData currentCmdbData, BasicUserData userContext, boolean isNew, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws ClassProcessingException, NullPointerException
  {
    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start processing input for " + ((currentCmdbData == null) ? "new " : "updating ") + " object. cmdb class = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()) + " input = " + ((input == null) ? "null" : input.toString()) + " , user = " + ((userContext == null) ? "null" : userContext.toString()));
    }

    Vector unprocessed = new Vector();

    Map result = new HashMap();

    for (Iterator i = attributes.iterator(); i.hasNext(); ) {
      String attributeName = (String)i.next();

      if (cmdbClass.getAllAttributes().hasAttribute(attributeName))
        try {
          AttributeInputProcessor attributeProcessor = getAttributeProcessorsFactory().create(cmdbClass.getAllAttributes().getAttributeByName(attributeName), cmdbClass, classModel);
          if (isNew)
            result.put(attributeName, attributeProcessor.processNew(input, cmdbClass.getAllAttributes().getAttributeByName(attributeName), cmdbClass, currentCmdbData, userContext, cmdbContext, cmdbApi));
          else
            result.put(attributeName, attributeProcessor.processExisting(input, cmdbClass.getAllAttributes().getAttributeByName(attributeName), cmdbClass, currentCmdbData, userContext, cmdbContext, cmdbApi));
        } catch (AttributeProcessingException ape) {
          if (LOGGER.isDebugEnabled())
            LOGGER.debug("Error processing attribute: attribute name = " + attributeName + " cmdb class name = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()), ape);

          unprocessed.add(ape);
        }

    }

    if (!(unprocessed.isEmpty())) {
      if (LOGGER.isDebugEnabled())
        LOGGER.debug("Error processing input for " + ((currentCmdbData == null) ? "new " : "updating ") + " object. cmdb class = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()) + " input = " + ((input == null) ? "null" : input.toString()));

      throw new ClassProcessingException(cmdbClass, unprocessed, result);
    }

    if (LOGGER.isInfoEnabled())
      LOGGER.info("Finish processing input for " + ((currentCmdbData == null) ? "new " : "updating ") + " object. cmdb class = " + cmdbClass.getName() + " input = " + input.toString() + " processed input = " + result.toString() + " , user = " + ((userContext == null) ? "null" : userContext.toString()));

    return result;
  }

  public AttributeInputProcessorFactory getAttributeProcessorsFactory()
  {
    return DefaultAttributeInputProcessorFactory.getInstance();
  }

  public void postProcessNew(CmdbClass cmdbClass, CmdbClassModel classModel, CmdbData defaultCmdbData, CmdbData updatedCmdbData, Map params, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws ClassProcessingException, NullPointerException
  {
  }

  public void postProcessUpdated(CmdbClass cmdbClass, CmdbClassModel classModel, CmdbData oldCmdbData, CmdbData updatedCmdbData, Map params, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws ClassProcessingException, NullPointerException
  {
  }
}