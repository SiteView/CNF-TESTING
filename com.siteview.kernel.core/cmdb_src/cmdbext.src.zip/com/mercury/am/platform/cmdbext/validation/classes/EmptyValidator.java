package com.mercury.am.platform.cmdbext.validation.classes;

import com.mercury.am.platform.cmdbext.validation.attribute.AttributeValueValidatorFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public class EmptyValidator
  implements ClassValidator
{
  public void validateNew(Map attribteValues, CmdbClassModel classModel, CmdbClass classToValidate, BasicUserData user)
    throws ClassValidationException, NullPointerException
  {
  }

  public void validateUpdated(Map attribteValues, CmdbClassModel classModel, CmdbClass cmdbClass, CmdbData toUpdate, BasicUserData user)
    throws ClassValidationException, NullPointerException
  {
  }

  public AttributeValueValidatorFactory getAttributeValidatorsFactory()
  {
    return null;
  }
}