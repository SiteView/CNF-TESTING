package com.mercury.am.platform.cmdbext.validation.attribute;

import com.mercury.am.platform.cmdbext.validation.attribute.qualifier.ValidationErrorRecord;
import com.mercury.am.platform.cmdbext.validation.attribute.qualifier.ValidationErrorRecordFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.TypeVisitor;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBytesType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDateType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDoubleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbFloatType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleTypes;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.Numeric;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.List;
import java.util.Map;

public class AttributeSizeValidator
  implements AttributeValueValidator
{
  public String getName()
  {
    return "SIZE_VALIDATOR";
  }

  public void validateType(CmdbAttribute attribute, Object value)
    throws AttributeTypeValidationException
  {
  }

  public void validateNew(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, BasicUserData user)
    throws AttributeValidationException
  {
    validateAttributeSize(attribute, value);
  }

  private void validateAttributeSize(CmdbAttribute attribute, Object value)
    throws AttributeValidationException
  {
    if (attribute.getSizeLimit() != null)
      new SizeValidator(this, attribute, value, attribute.getSizeLimit().intValue()).validate();
  }

  public void validateUpdated(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, CmdbData cmdbData, BasicUserData user)
    throws AttributeValidationException
  {
    validateAttributeSize(attribute, value);
  }

  private class SizeValidator
  implements TypeVisitor
  {
    private int sizeToValidate = 0;
    private int attributeSize = 0;
    Object attributeValue;
    CmdbAttribute attribute;

    public SizeValidator(, CmdbAttribute paramCmdbAttribute, Object paramObject, int paramInt) {
      this.sizeToValidate = paramInt;
      this.attributeValue = attributeValue;
      this.attribute = paramCmdbAttribute;
      if (this.attribute.getResolvedType() != null)
        this.attribute.getResolvedType().accept(this);
    }

    public void validate()
      throws AttributeValidationException
    {
      if (this.sizeToValidate >= this.attributeSize)
        return;

      ValidationErrorRecord validatorRecord = ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.WRONG_SIZE", this.attribute.getName(), this.attributeValue, "EXPECTED_SIZE", "" + this.sizeToValidate, "WRONG_SIZE", "" + this.attributeSize);

      AttributeValidationException validationException = new AttributeValidationException(this.attribute, this.attributeValue);
      validationException.addUnqualifiedRecord(validatorRecord);
      throw validationException;
    }

    public void visit() {
    }

    public void visit() {
    }

    public void visit() {
    }

    public void visit() {
    }

    public void visit() {
    }

    public void visit() {
    }

    public void visit() {
      if ((this.attributeValue != null) && (this.attributeValue instanceof String))
        this.attributeSize = ((String)this.attributeValue).length();
    }

    public void visit()
    {
      if ((this.attributeValue != null) && (this.attributeValue instanceof String))
        this.attributeSize = ((String)this.attributeValue).length();
    }

    public void visit()
    {
    }

    public void visit() {
    }

    public void visit() {
      if ((this.attributeValue != null) && (this.attributeValue instanceof byte[]))
        this.attributeSize = ((byte[])(byte[])this.attributeValue).length;
    }

    public void visit()
    {
    }

    public void visit() {
      if ((this.attributeValue != null) && (this.attributeValue instanceof List))
        this.attributeSize = ((List)this.attributeValue).size();
    }

    public void visit()
    {
      if ((this.attributeValue != null) && (this.attributeValue instanceof List))
        this.attributeSize = ((List)this.attributeValue).size();
    }

    public void visit()
    {
    }

    public void visit() {
    }

    public void visit() {
      if ((this.attributeValue != null) && (this.attributeValue instanceof String))
        visit((CmdbStringType)CmdbSimpleTypes.CmdbString);
    }

    public void visit()
    {
    }
  }
}