package com.mercury.am.platform.cmdbext.validation.attribute;

import com.mercury.am.platform.cmdbext.validation.attribute.qualifier.ValidationErrorRecordFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;

public class AttributeTypeValidationException extends AttributeValidationException
{
  Class invalidType;
  Class expectedType;

  public AttributeTypeValidationException(CmdbAttribute attribute, Object unvalidValue, Class invalidType, Class expectedType)
  {
    super(attribute, unvalidValue);
    this.invalidType = invalidType;
    this.expectedType = expectedType.getClass();
    addUnqualifiedRecord(ValidationErrorRecordFactory.createQualifierValidatorRecord("cmdb.validation.WRONG_TYPE", attribute.getName(), unvalidValue, "EXPECTED_TYPE", expectedType, "WRONG_TYPE", invalidType));
  }

  public Class getExpectedType()
  {
    return this.expectedType;
  }

  public Class getInvalidType() {
    return this.invalidType;
  }
}