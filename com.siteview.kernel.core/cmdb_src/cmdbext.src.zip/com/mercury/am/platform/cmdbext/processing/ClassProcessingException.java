package com.mercury.am.platform.cmdbext.processing;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.util.List;
import java.util.Map;

public class ClassProcessingException extends Exception
{
  private CmdbClass cmdbClass;
  private List unprocessedAttributes;
  private Map processedAttributes;

  public ClassProcessingException(CmdbClass cmdbClass, List unprocessedAttributes, Map processedAttributes)
  {
    this.cmdbClass = cmdbClass;
    this.unprocessedAttributes = unprocessedAttributes;
    this.processedAttributes = processedAttributes;
  }

  public ClassProcessingException(String message, CmdbClass cmdbClass, List unprocessedAttributes, Map processedAttributes)
  {
    super(message);
    this.cmdbClass = cmdbClass;
    this.unprocessedAttributes = unprocessedAttributes;
    this.processedAttributes = processedAttributes;
  }

  public ClassProcessingException(Throwable cause, CmdbClass cmdbClass, List unprocessedAttributes, Map processedAttributes)
  {
    super(cause);
    this.cmdbClass = cmdbClass;
    this.unprocessedAttributes = unprocessedAttributes;
    this.processedAttributes = processedAttributes;
  }

  public ClassProcessingException(String message, Throwable cause, CmdbClass cmdbClass, List unprocessedAttributes, Map processedAttributes)
  {
    super(message, cause);
    this.cmdbClass = cmdbClass;
    this.unprocessedAttributes = unprocessedAttributes;
    this.processedAttributes = processedAttributes;
  }

  public CmdbClass getCmdbClass() {
    return this.cmdbClass;
  }

  public List getUnprocessedAttributes()
  {
    return this.unprocessedAttributes;
  }

  public Map getProcessedAttributes() {
    return this.processedAttributes;
  }
}