package com.mercury.am.platform.cmdbext.creation;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactory;
import com.mercury.topaz.cmdb.shared.classmodel.util.DataFactoryCreator;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;
import com.mercury.topaz.cmdb.shared.model.object.id.CmdbObjectID;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperties;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyFactory;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;

public class DataFactoryExtension
{
  private static Log LOGGER = LogFactory.getEasyLog(DataFactoryExtension.class);
  protected CmdbClassModel classModel;
  protected DataFactory dataFactory;

  public DataFactoryExtension(CmdbClassModel classModel)
    throws NullPointerException
  {
    this.classModel = classModel;
    this.dataFactory = DataFactoryCreator.create(classModel);
  }

  public CmdbObject createUpdatedCmdbObject(CmdbObject originalObject, CmdbProperties updatedProperties)
  {
    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start calling to createUpdatedCmdbObject: object id  = " + ((originalObject == null) ? "null" : ((CmdbObjectID)originalObject.getID()).toString()) + " , object = " + ((originalObject == null) ? "null" : originalObject.toString()) + " updated properties = " + ((updatedProperties == null) ? "null" : updatedProperties.toString()));
    }

    if (originalObject == null) { return null;
    }

    if ((updatedProperties == null) || (updatedProperties.isEmpty()))
    {
      return this.dataFactory.restoreObject((CmdbObjectID)originalObject.getID(), originalObject.getType());
    }

    StringBuffer updatedPropertiesMessage = new StringBuffer();

    CmdbProperties filteredProperties = CmdbPropertyFactory.createProperties();

    for (ReadOnlyIterator i = updatedProperties.getPropertiesIterator(); i.hasNext(); )
    {
      CmdbProperty updatedProperty = (CmdbProperty)i.next();
      try
      {
        CmdbProperty originalProperty;
        while (true) {
          originalProperty = originalObject.getProperty(updatedProperty.getKey());

          if (originalProperty != null) break;
          if (LOGGER.isDebugEnabled())
            LOGGER.debug("Original object does not have property, adding property to updated object: property name = " + updatedProperty.getKey());

          filteredProperties.add(updatedProperty);
          updatedPropertiesMessage.append(updatedProperty.getKey()).append(" , ");
        }

        if (!(updatedProperty.getValue().equals(originalProperty.getValue()))) {
          if (LOGGER.isDebugEnabled())
            LOGGER.debug("Original object property value has changed, adding property to updated object: property name = " + updatedProperty.getKey() + " original value = " + ((originalProperty == null) ? "null" : originalProperty.getValue()) + " updated value = " + ((updatedProperty == null) ? "null" : updatedProperty.getValue()));

          filteredProperties.add(updatedProperty);
          updatedPropertiesMessage.append(updatedProperty.getKey()).append(" , ");
        }
      }
      catch (Exception e)
      {
        filteredProperties.add(updatedProperty);
        updatedPropertiesMessage.append(updatedProperty.getKey()).append(" , ");
        LOGGER.error("Failed while comparing updated property value with irginal property value: Object Type = " + originalObject.getType() + " , Property Key = " + updatedProperty.getKey(), e);
      }
    }

    if (LOGGER.isDebugEnabled())
    {
      LOGGER.debug("Updated properties for Object: Object ID = " + originalObject.getID() + " ObjectType = " + originalObject.getType() + " Updated Properties Keys = " + updatedPropertiesMessage.toString());
    }

    CmdbObject updatedObject = this.dataFactory.restoreObject((CmdbObjectID)originalObject.getID(), originalObject.getType(), filteredProperties);

    return updatedObject;
  }

  public CmdbObject createFullUpdatedCmdbObject(CmdbObject originalObject, CmdbProperties updatedProperties)
  {
    CmdbProperties mergedProperties = CmdbPropertyFactory.createProperties();
    ReadOnlyIterator it = originalObject.getPropertiesIterator();
    while (true) { while (true) { if (!(it.hasNext())) break label101;
        updatedProperty = (CmdbProperty)it.next();

        if (!("display_label".equals(updatedProperty.getKey())))
          break;
      }
      if (updatedProperties.contains(updatedProperty.getKey())) {
        mergedProperties.add(updatedProperties.get(updatedProperty.getKey()));
      }
      else {
        mergedProperties.add(updatedProperty);
      }

    }

    for (it = updatedProperties.getPropertiesIterator(); it.hasNext(); ) {
      label101: updatedProperty = (CmdbProperty)it.next();

      if ((!(mergedProperties.contains(updatedProperty.getKey()))) && (!("display_label".equals(updatedProperty.getKey()))))
      {
        mergedProperties.add(updatedProperty);
      }

    }

    CmdbObject fictiveObject = this.dataFactory.createObject(originalObject.getType(), mergedProperties);
    CmdbProperty updatedProperty = fictiveObject.getProperty("display_label");
    mergedProperties.add(updatedProperty);

    CmdbObject updatedObject = this.dataFactory.restoreObject((CmdbObjectID)originalObject.getID(), originalObject.getType(), mergedProperties);

    return updatedObject;
  }
}