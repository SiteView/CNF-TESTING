package com.mercury.am.platform.cmdbext.access;

import com.mercury.topaz.cmdb.shared.common.qualifiedname.CmdbQualifiedNameFactory;

public class CMDBConstants
{
  public static final ConstantClass DATA_CLASS = new ConstantClass("data", null, null);
  public static final ConstantClass OBJECT_CLASS = new ConstantClass("it_world", "Mercury", null);
  public static final ConstantClass LINK_CLASS = new ConstantClass("link", null, null);
  public static final ConstantClass SIEBEL_APP_SERVER = new ConstantClass("siebel_app_server", "Mercury", null);
  public static final ConstantClass SIEBEL_WEB_SERVER = new ConstantClass("siebel_wse", "Mercury", null);
  public static final ConstantClass SIEBEL_APPLICATION = new ConstantClass("siebel_application", "Mercury", null);
  public static final ConstantClass SAP_R3_SERVER = new ConstantClass("sap_r3_server", "Mercury", null);
  public static final ConstantClass CONTAINER_F = new ConstantClass("container_f", "", null);
  public static final ConstantClass KPI = new ConstantClass("dimension", "Mercury", null);
  public static final ConstantClass OBJECTIVE = new ConstantClass("objective", "Mercury", null);
  public static final ConstantAttribute NAME_ATTR = new ConstantAttribute("data_name", DATA_CLASS);
  public static final ConstantAttribute DESCRIPTION_ATTR = new ConstantAttribute("data_description", DATA_CLASS);
  public static final ConstantAttribute COMMENT_ATTR = new ConstantAttribute("data_comment", DATA_CLASS);
  public static final ConstantAttribute ORIGIN_ATTR = new ConstantAttribute("data_origin", DATA_CLASS);
  public static final ConstantAttribute CREATE_TIME_ATTR = new ConstantAttribute("root_createtime", null);
  public static final ConstantAttribute UPDATE_TIME_ATTR = new ConstantAttribute("root_updatetime", null);
  public static final ConstantAttribute UPDATE_BY_ATTR = new ConstantAttribute("data_updated_by", DATA_CLASS);
  public static final ConstantAttribute WEIGHT_ATTR = new ConstantAttribute("weight", LINK_CLASS);
  public static final ConstantAttribute ROOT_CONTAINER_ATTR = new ConstantAttribute("root_container", DATA_CLASS);
  public static final ConstantAttribute CONTAINED_ID_ATTR = new ConstantAttribute("contained_id", null);
  public static final ConstantAttribute COUNTRY_ATTR = new ConstantAttribute("country", OBJECT_CLASS);
  public static final ConstantAttribute STATE_ATTR = new ConstantAttribute("state", OBJECT_CLASS);
  public static final ConstantAttribute CITY_ATTR = new ConstantAttribute("city", OBJECT_CLASS);
  public static final String HANDLER = "HANDLER";
  public static final String COUNTRY_ATTR_NAME = "country";
  public static final String STATE_ATTR_NAME = "state";
  public static final String CITY_ATTR_NAME = "city";
  public static final String LATITUDE_ATTR_NAME = "latitude";
  public static final String LONGITUDE_ATTR_NAME = "longitude";
  public static final String SIEBEL_APP_SERVER_CLASS = "com.mercury.topaz.siebel.manualconfig.classHandlers.AppServerClassHandler";
  public static final String SIEBEL_WEB_SERVER_CLASS = "com.mercury.topaz.siebel.manualconfig.classHandlers.WebServerClassHandler";
  public static final String SIEBEL_WEB_APPLICATION_CLASS = "com.mercury.topaz.siebel.manualconfig.classHandlers.ApplicationClassHandler";
  public static final String SAP_R3_SERVER_CLASS = "com.mercury.am.bac.vertical.sap.manualconfig.classhandlers.R3ServerClassHandler";
  public static final String CMDB_RESOURCE_NAME = "ITU_CMDB";
  public static final String PASSWORD_DISPLAY_VALUE = "349594359834089843";

  public static class ConstantAttribute
  {
    public final String name;
    public final CMDBConstants.ConstantClass containedClass;

    public ConstantAttribute(String name, CMDBConstants.ConstantClass containedClass)
    {
      this.name = name;
      this.containedClass = containedClass;
    }

    public boolean createdInOneClassOnly() {
      return (this.containedClass != null);
    }

    public String toString() {
      return this.name;
    }

    public String getName() {
      return this.name;
    }

    public CMDBConstants.ConstantClass getContainedClass() {
      return this.containedClass;
    }
  }

  public static class ConstantClass
  {
    public final String namespace;
    private final String name;

    private ConstantClass(String name, String namespace)
    {
      this.name = name;
      this.namespace = namespace;
    }

    public String toString() {
      return getName();
    }

    public String getName() {
      return CmdbQualifiedNameFactory.createCmdbQualifiedName(this.namespace, this.name).toString();
    }

    public String getNamespace() {
      return this.namespace;
    }
  }
}