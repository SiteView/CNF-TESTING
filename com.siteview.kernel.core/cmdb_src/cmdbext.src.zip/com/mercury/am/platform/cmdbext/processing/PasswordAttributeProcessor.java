package com.mercury.am.platform.cmdbext.processing;

import com.mercury.am.platform.cmdbext.access.ClassModelFactoryProxy;
import com.mercury.am.platform.cmdbext.access.ClassModelFactoryThinWrapper;
import com.mercury.am.platform.cmdbext.access.CmdbCipher;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;

public class PasswordAttributeProcessor extends SimpleAttributeProcessor
{
  private static Log LOGGER = LogFactory.getEasyLog(PasswordAttributeProcessor.class);

  public PasswordAttributeProcessor()
  {
    super(String.class);
  }

  protected Object processStringValue(CmdbAttribute attribute, String valueAsString, CmdbData currentCmdbData, BasicUserData userContext)
    throws AttributeProcessingException, Exception
  {
    if ((valueAsString == null) || (valueAsString.equals("349594359834089843"))) {
      if (currentCmdbData == null)
        return null;

      return currentCmdbData.getProperty(attribute.getName());
    }

    if (LOGGER.isInfoEnabled())
      LOGGER.info("Encrypt password for " + ((currentCmdbData == null) ? "new" : "update") + " object: attribute name = " + ((attribute == null) ? "null" : attribute.getName()));

    CmdbCipher cmdbCipher = ClassModelFactoryThinWrapper.getInstance().getCmdbCipherByUserData(userContext);
    return cmdbCipher.encrypt(valueAsString);
  }

  protected Object manipulateValue(CmdbAttribute attribute, Object value, CmdbData currentCmdbData, BasicUserData userContext)
    throws AttributeProcessingException, Exception
  {
    if ((value == null) || (value instanceof String)) {
      return processStringValue(attribute, (String)value, currentCmdbData, userContext);
    }

    throw new AttributeProcessingException(attribute, value, "processor.error.not.string");
  }
}