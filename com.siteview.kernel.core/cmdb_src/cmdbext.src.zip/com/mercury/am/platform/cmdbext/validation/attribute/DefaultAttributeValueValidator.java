package com.mercury.am.platform.cmdbext.validation.attribute;

import com.mercury.am.platform.cmdbext.validation.attribute.qualifier.QualifierValidator;
import com.mercury.am.platform.cmdbext.validation.attribute.qualifier.QualifierValidatorFactory;
import com.mercury.am.platform.cmdbext.validation.attribute.qualifier.ValidationErrorRecord;
import com.mercury.am.platform.cmdbext.validation.utils.ValidationUtils;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.TypeVisitor;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBytesType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDateType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDoubleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbFloatType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.Numeric;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DefaultAttributeValueValidator
  implements AttributeValueValidator
{
  public String getName()
  {
    return super.getClass().getName();
  }

  public void validateType(CmdbAttribute attribute, Object value)
    throws AttributeTypeValidationException
  {
    Class javaClass = new CmdbType2JavaClassConverter(this, attribute).getJavaClass();
    if ((value != null) && (((javaClass == null) || (!(javaClass.isInstance(value))))))
      throw ValidationUtils.createAttributeTypeValidationException(attribute, value, value.getClass(), javaClass);
  }

  public void validateNew(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, BasicUserData user)
    throws AttributeValidationException
  {
    validate(attribute, containerClass, value, attributeValues, null, user);
  }

  public void validateUpdated(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, CmdbData cmdbData, BasicUserData user)
    throws AttributeValidationException
  {
    validate(attribute, containerClass, value, attributeValues, cmdbData, user);
  }

  private void validate(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, CmdbData cmdbData, BasicUserData user)
    throws AttributeValidationException
  {
    validateType(attribute, value);
    CmdbAttributeQualifiers qualifiers = attribute.getQualifiers();
    if (qualifiers == null)
      return;

    List exceptionsList = new ArrayList();

    ReadOnlyIterator iterator = qualifiers.getIterator(); if (iterator.hasNext());
    try {
      ClassModelQualifier qualifier = (ClassModelQualifier)iterator.next();
      QualifierValidator validator = QualifierValidatorFactory.createQualifierValidator(qualifier);
      invokeQualifierValidator(validator, cmdbData, qualifier, attribute, containerClass, value, attributeValues);
    }
    catch (AttributeValidationException i) {
      while (true) { exceptionsList.add(e);
      }

      try
      {
        if (cmdbData == null)
          AttributeValueValidatorFactory.SIZE_VALIDATOR.validateNew(attribute, containerClass, value, attributeValues, user);
        else
          AttributeValueValidatorFactory.SIZE_VALIDATOR.validateUpdated(attribute, containerClass, value, attributeValues, cmdbData, user);
      }
      catch (AttributeValidationException e) {
        exceptionsList.add(e);
      }

      if (exceptionsList.size() == 0) {
        return;
      }

      AttributeValidationException validationException = new AttributeValidationException(attribute, value);

      for (int i = 0; i < exceptionsList.size(); ++i) {
        AttributeValidationException currException = (AttributeValidationException)exceptionsList.get(i);
        List unqualifiedList = currException.getValidationErrors();
        if ((unqualifiedList != null) && (unqualifiedList.size() > 0)) {
          Iterator iterator = unqualifiedList.iterator();
          while (iterator.hasNext())
            validationException.addUnqualifiedRecord((ValidationErrorRecord)iterator.next());
        }

      }

      throw validationException; }
  }

  private void invokeQualifierValidator(QualifierValidator validator, CmdbData cmdbData, ClassModelQualifier qualifier, CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues) throws AttributeValidationException {
    if (validator != null)
      if (cmdbData == null)
        validator.validateNew(qualifier, attribute, containerClass, value, attributeValues);
      else
        validator.validateUpdated(qualifier, attribute, containerClass, value, attributeValues, cmdbData);
  }

  public class CmdbType2JavaClassConverter
  implements TypeVisitor
  {
    Class javaClass = null;
    private CmdbAttribute attribute;

    public Class getJavaClass() {
      return this.javaClass;
    }

    public CmdbType2JavaClassConverter(, CmdbAttribute attribute) {
      this.attribute = attribute;
      CmdbType cmdbType = attribute.getResolvedType();
      if (cmdbType != null)
        cmdbType.accept(this);
    }

    public CmdbType2JavaClassConverter(, CmdbType paramCmdbType)
    {
      if (cmdbType != null)
        cmdbType.accept(this);
    }

    public void visit()
    {
    }

    public void visit() {
      this.javaClass = List.class;
    }

    public void visit() {
      this.javaClass = Number.class;
    }

    public void visit()
    {
      this.javaClass = Integer.class;
    }

    public void visit() {
      this.javaClass = Long.class;
    }

    public void visit() {
      this.javaClass = Float.class;
    }

    public void visit()
    {
      this.javaClass = Double.class;
    }

    public void visit() {
      this.javaClass = String.class;
    }

    public void visit() {
      this.javaClass = String.class;
    }

    public void visit() {
      this.javaClass = Boolean.class;
    }

    public void visit() {
      this.javaClass = Date.class;
    }

    public void visit() {
      this.javaClass = [B.class;
    }

    public void visit() {
      this.javaClass = List.class;
    }

    public void visit() {
      this.javaClass = List.class;
    }

    public void visit()
    {
    }

    public void visit() {
      this.javaClass = Number.class;
    }

    public void visit()
    {
      this.javaClass = Object.class;
    }

    public void visit()
    {
    }
  }
}