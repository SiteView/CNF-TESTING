package com.mercury.am.platform.cmdbext.classmodel.parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Parser
{
  private static List ignoreList = new ArrayList();
  private static Map classTypes = new LinkedHashMap();
  private static Set qualifiers = new HashSet();
  private static Set namespaces = new HashSet();

  public static void main(String[] args)
  {
    FileWriter writer = null;
    try {
      Properties p = new Properties();
      p.load(new FileInputStream("directories.properties"));
      String xmlDir = p.getProperty("packages.classes.root.dir");
      String outputDir = p.getProperty("output.dir");
      String packageName = p.getProperty("java.package");
      String ignoreListStr = p.getProperty("ignore.list");

      createIngnoreList(ignoreListStr);
      extractClassTypes(xmlDir);
      writer = createFile(outputDir, packageName);
      writeNamesapces(writer);
      writeQualifiers(writer);
      writeClasses(classTypes, writer);
      writer.write("}\n");
    }
    catch (Exception e) {
      e.printStackTrace();
    } finally {
      if (writer != null)
        try {
          writer.close();
        } catch (Exception e) {
          e.printStackTrace();
        }
    }
  }

  private static void createIngnoreList(String ignoreListStr)
  {
    StringTokenizer st = new StringTokenizer(ignoreListStr, ";");
    while (st.hasMoreTokens())
      ignoreList.add(st.nextToken());
  }

  public static void extractClassTypes(String fileName) throws Exception
  {
    File file = new File(fileName);
    if (fileIsInIgnoreList(file.getName()))
      return;

    if (file.isDirectory()) {
      String[] children = file.list();
      for (int i = 0; i < children.length; ++i) {
        String childFileName = children[i];
        extractClassTypes(fileName + "/" + childFileName);
      }
    }
    else if (file.getName().endsWith(".xml")) {
      addClassTypeToList(file);
    }
  }

  private static void extractQualifiers(ClassType curClass)
  {
    qualifiers.addAll(curClass.getQualifiers());
  }

  private static void extractNameSpace(ClassType classType) {
    String ns = classType.getNamespace();
    if ((ns != null) && (!(ns.trim().equals(""))))
      namespaces.add(ns);
  }

  public static void addClassTypeToList(File classFile) throws Exception {
    DocumentBuilderFactory factory;
    try {
      factory = DocumentBuilderFactory.newInstance();
      DocumentBuilder builder = factory.newDocumentBuilder();
      Document document = builder.parse(classFile);
      NodeList classNodes = document.getElementsByTagName("Class");
      for (int i = 0; i < classNodes.getLength(); ++i) {
        Node curNode = classNodes.item(i);
        if (curNode != null) {
          ClassType newClassType = new ClassType(curNode, classFile.getName());
          extractQualifiers(newClassType);
          extractNameSpace(newClassType);
          Object existingClassObj = classTypes.put(newClassType.getName(), newClassType);
          if (existingClassObj != null) {
            ClassType existingClass = (ClassType)existingClassObj;
            System.out.println("Duplication! class-name[" + existingClass.getName() + "] overriding-file[" + newClassType.getFileName() + "] prev-file[" + existingClass.getFileName() + "]");
          }
        }
      }
    } catch (Exception e) {
      System.out.println("Error: Failed parsing file[" + classFile.getPath() + "] : " + e.getMessage());
    }
  }

  private static FileWriter createFile(String fileDir, String packageName) throws IOException {
    File classFile = new File(fileDir + "/CMConstants.java");
    FileWriter writer = new FileWriter(classFile);
    writer.write("package " + packageName + ";\n\n");
    writer.write("public class CMConstants {\n");
    return writer;
  }

  private static void writeClasses(Map classTypes, FileWriter writer) throws IOException {
    Iterator classTypesIt = classTypes.values().iterator();
    while (classTypesIt.hasNext()) {
      ClassType curClass = (ClassType)classTypesIt.next();
      writeClass(curClass, writer);
    }
  }

  private static void writeClass(ClassType curClass, FileWriter writer) throws IOException {
    writer.write("\n\tpublic class " + formatClassName(curClass.getName()));
    String drivedFrom = curClass.getDerivedFrom();
    if ((drivedFrom != null) && (!(drivedFrom.trim().equals("none"))))
      writer.write(" extends " + formatClassName(drivedFrom));

    writer.write(" {\n");
    writer.write("\t\tpublic static final String CLASS_NAME  = \"" + curClass.getName() + "\";\n");
    String namespace = curClass.getNamespace();
    if (namespace == null)
      namespace = "";

    writer.write("\t\tpublic static final String NAME_SPACE  = \"" + namespace + "\";\n");
    writeAttributes(curClass, writer);
    writer.write("\t}\n");
  }

  private static void writeNamesapces(FileWriter writer) throws IOException {
    writer.write("\n\tpublic class NAMESPACE  {\n");
    Iterator namespacesIt = namespaces.iterator();
    while (namespacesIt.hasNext()) {
      String namespace = (String)namespacesIt.next();
      if (namespace != null)
        writer.write("\t\tpublic static final String " + namespace.toUpperCase() + " = \"" + namespace + "\";\n");
    }

    writer.write("\t}\n");
  }

  private static void writeQualifiers(FileWriter writer) throws IOException
  {
    writer.write("\n\tpublic class CLASS_QUALIFIERS  {\n");
    Iterator qualifiersIt = qualifiers.iterator();
    while (qualifiersIt.hasNext()) {
      String qualifier = (String)qualifiersIt.next();
      if (qualifier != null)
        writer.write("\t\tpublic static final String " + qualifier.toUpperCase() + " = \"" + qualifier + "\";\n");
    }

    writer.write("\t}\n");
  }

  private static void writeAttributes(ClassType curClass, FileWriter writer) throws IOException
  {
    Iterator attrs = curClass.getAttributes().iterator();
    while (attrs.hasNext()) {
      String attr = (String)attrs.next();
      writer.write("\t\tpublic static final String " + attr.toUpperCase() + " = \"" + attr + "\";\n");
    }
  }

  private static String formatClassName(String name) {
    StringBuffer chars = new StringBuffer();
    for (int i = 0; i < name.length(); ++i) {
      char curChar = name.charAt(i);
      if ((i > 0) && (Character.isUpperCase(curChar)))
        chars.append("_");

      chars.append(curChar);
    }
    return chars.toString().toUpperCase();
  }

  private static boolean fileIsInIgnoreList(String fileName) {
    Iterator ignoreListIt = ignoreList.iterator();
    while (ignoreListIt.hasNext()) {
      String s = (String)ignoreListIt.next();
      if ((s != null) && (s.equals(fileName)))
        return true;
    }

    return false;
  }
}