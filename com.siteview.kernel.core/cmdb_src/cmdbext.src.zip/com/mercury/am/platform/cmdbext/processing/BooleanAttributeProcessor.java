package com.mercury.am.platform.cmdbext.processing;

import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public class BooleanAttributeProcessor extends SimpleAttributeProcessor
{
  public BooleanAttributeProcessor()
  {
    super(Boolean.class);
  }

  protected Object process(Map input, CmdbAttribute attribute, CmdbClass containedClass, CmdbData currentCmdbData, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws AttributeProcessingException
  {
    Object value = input.get(attribute.getName());

    if ((value == null) || ((value instanceof String) && (StringUtils.isEmpty((String)value))))
    {
      return Boolean.FALSE;
    }
    if (value.getClass().equals(getProcessedValueClass())) {
      return value;
    }

    if (value instanceof String)
      try {
        return processStringValue(attribute, (String)value, currentCmdbData, userContext);
      }
      catch (Exception e) {
        throw new AttributeProcessingException(e, attribute, value, getErrorCode(attribute));
      }

    throw new AttributeProcessingException(attribute, value, getErrorCode());
  }

  protected Object processStringValue(CmdbAttribute attribute, String valueAsString, CmdbData currentCmdbData, BasicUserData userContext)
    throws AttributeProcessingException, Exception
  {
    return ((Boolean.FALSE.toString().equalsIgnoreCase(valueAsString)) ? Boolean.FALSE : Boolean.TRUE);
  }

  protected String getErrorCode() {
    return "processor.error.not.boolean";
  }
}