package com.mercury.am.platform.cmdbext.cmhandler;

import com.mercury.am.platform.cmdbext.processing.AttributeInputProcessor;
import com.mercury.am.platform.cmdbext.processing.AttributeOutputProcessor;
import com.mercury.am.platform.cmdbext.validation.attribute.CustomAttributeValueValidator;

public abstract interface CmdbAttributeHandler
{
  public abstract String getRender();

  public abstract boolean hasRender();

  public abstract CustomAttributeValueValidator getValidator();

  public abstract boolean hasValidator();

  public abstract AttributeInputProcessor getInputProcessor();

  public abstract boolean hasInputProcessor();

  public abstract AttributeOutputProcessor getOutputProcessor();

  public abstract boolean hasOutputProcessor();
}