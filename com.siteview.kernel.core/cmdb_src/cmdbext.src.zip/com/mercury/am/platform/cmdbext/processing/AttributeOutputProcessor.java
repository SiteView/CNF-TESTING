package com.mercury.am.platform.cmdbext.processing;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public abstract interface AttributeOutputProcessor
{
  public abstract Object processNew(CmdbAttribute paramCmdbAttribute, CmdbClass paramCmdbClass, CmdbData paramCmdbData, Map paramMap, BasicUserData paramBasicUserData, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws AttributeProcessingException;

  public abstract Object processExisting(CmdbAttribute paramCmdbAttribute, CmdbClass paramCmdbClass, CmdbData paramCmdbData, Map paramMap, BasicUserData paramBasicUserData, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws AttributeProcessingException;
}