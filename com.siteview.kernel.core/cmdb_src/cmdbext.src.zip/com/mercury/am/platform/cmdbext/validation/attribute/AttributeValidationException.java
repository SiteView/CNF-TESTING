package com.mercury.am.platform.cmdbext.validation.attribute;

import com.mercury.am.platform.cmdbext.validation.attribute.qualifier.ValidationErrorRecord;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import java.util.ArrayList;
import java.util.List;

public class AttributeValidationException extends Exception
{
  private CmdbAttribute attribute;
  private Object wrongValue;
  private List validationErrors = new ArrayList();

  public AttributeValidationException(CmdbAttribute attribute, Object unvalidValue)
  {
    this.attribute = attribute;
    this.wrongValue = unvalidValue;
  }

  public CmdbAttribute getAttribute() {
    return this.attribute;
  }

  public Object getWrongValue() {
    return this.wrongValue;
  }

  public List getValidationErrors() {
    return this.validationErrors;
  }

  public void addUnqualifiedRecord(ValidationErrorRecord record) {
    this.validationErrors.add(record);
  }

  public void addValidationErrors(List newValidationErrors) {
    this.validationErrors.addAll(newValidationErrors);
  }
}