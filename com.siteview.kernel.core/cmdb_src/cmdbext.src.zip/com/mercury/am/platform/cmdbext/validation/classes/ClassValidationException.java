package com.mercury.am.platform.cmdbext.validation.classes;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import java.util.List;
import java.util.Vector;

public class ClassValidationException extends Exception
{
  private CmdbClass cmdbClass;
  private String errorCode;
  private List errorMessageParams;
  private List attributeValidationExceptions = null;
  private List validationErrors = null;

  public ClassValidationException(CmdbClass cmdbClass, List invalidAttributes)
  {
    this.cmdbClass = cmdbClass;
    this.attributeValidationExceptions = invalidAttributes;
  }

  public ClassValidationException(CmdbClass cmdbClass, String errorCode, List errorMessageParams)
  {
    this.cmdbClass = cmdbClass;
    this.errorCode = errorCode;
    this.errorMessageParams = errorMessageParams;
  }

  public ClassValidationException(CmdbClass cmdbClass, List attributeValidationExceptions, List validationErrors)
  {
    this.cmdbClass = cmdbClass;
    this.attributeValidationExceptions = attributeValidationExceptions;
    this.validationErrors = validationErrors;
  }

  public ClassValidationException(String message, CmdbClass cmdbClass, Vector invalidAttributes)
  {
    super(message);
    this.cmdbClass = cmdbClass;
    this.attributeValidationExceptions = invalidAttributes;
  }

  public ClassValidationException(Throwable cause, CmdbClass cmdbClass, Vector invalidAttributes)
  {
    super(cause);
    this.cmdbClass = cmdbClass;
    this.attributeValidationExceptions = invalidAttributes;
  }

  public ClassValidationException(String message, Throwable cause, CmdbClass cmdbClass, List invalidAttributes)
  {
    super(message, cause);
    this.cmdbClass = cmdbClass;
    this.attributeValidationExceptions = invalidAttributes;
  }

  public CmdbClass getCmdbClass() {
    return this.cmdbClass;
  }

  public List getAttributeValidationExceptions() {
    return this.attributeValidationExceptions;
  }

  public List getValidationErrors() {
    return this.validationErrors;
  }

  public String getErrorCode() {
    return this.errorCode;
  }

  public List getErrorMessageParams() {
    return this.errorMessageParams;
  }

  public void addAttributeValidationExceptions(List newAttributeValidationExceptions) {
    this.attributeValidationExceptions.addAll(newAttributeValidationExceptions);
  }

  public void addValidationErrors(List newValidationErrors) {
    this.validationErrors.addAll(newValidationErrors);
  }
}