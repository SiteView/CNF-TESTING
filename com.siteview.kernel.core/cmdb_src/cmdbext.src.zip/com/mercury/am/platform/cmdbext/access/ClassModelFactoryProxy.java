package com.mercury.am.platform.cmdbext.access;

import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.util.session.BasicUserData;

public abstract interface ClassModelFactoryProxy
{
  /**
   * @deprecated
   */
  public abstract CmdbClassModel getClassModelForCustomer(Object paramObject);

  public abstract CmdbClassModel getClassModelByUserData(BasicUserData paramBasicUserData);

  public abstract CmdbClassModel getClassModelByCmdbContext(CmdbContext paramCmdbContext);

  public abstract CmdbCipher getCmdbCipherByUserData(BasicUserData paramBasicUserData);

  public abstract CmdbCipher getCmdbCipherByCmdbContext(CmdbContext paramCmdbContext);
}