package com.mercury.am.platform.cmdbext.validation.classes;

import com.mercury.am.platform.cmdbext.validation.attribute.AttributeValueValidatorFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public abstract class CustomClassValidator
  implements ClassValidator
{
  public abstract void validateNew(Map paramMap, CmdbClassModel paramCmdbClassModel, CmdbClass paramCmdbClass, BasicUserData paramBasicUserData)
    throws ClassValidationException, NullPointerException;

  public abstract void validateUpdated(Map paramMap, CmdbClassModel paramCmdbClassModel, CmdbClass paramCmdbClass, CmdbData paramCmdbData, BasicUserData paramBasicUserData)
    throws ClassValidationException, NullPointerException;

  public abstract AttributeValueValidatorFactory getAttributeValidatorsFactory();

  public boolean toPerformDefaultValidation()
  {
    return true;
  }
}