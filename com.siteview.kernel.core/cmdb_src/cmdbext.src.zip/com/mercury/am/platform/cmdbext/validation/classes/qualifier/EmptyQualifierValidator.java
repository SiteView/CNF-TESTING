package com.mercury.am.platform.cmdbext.validation.classes.qualifier;

import com.mercury.am.platform.cmdbext.validation.classes.ClassValidationException;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import java.util.Map;

public class EmptyQualifierValidator
  implements QualifierValidator
{
  public void validateNew(ClassModelQualifier qualifier, CmdbClass containerClass, CmdbClassModel classModel, Map attributeValues)
    throws ClassValidationException
  {
  }

  public void validateUpdated(ClassModelQualifier qualifier, CmdbClass containerClass, CmdbClassModel classModel, Map attributeValues, CmdbData cmdbData)
    throws ClassValidationException
  {
  }
}