package com.mercury.am.platform.cmdbext.processing;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.model.property.impl.CmdbPropertyValuesFactory;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbStringPropertyValues;

public class StringListAttributeProcessor extends TypedListAttributeProcessor
{
  public StringListAttributeProcessor()
  {
    super(CmdbStringPropertyValues.class);
  }

  protected String getErrorCode(CmdbAttribute attribute)
  {
    return "processor.error.not.string.list";
  }

  protected void addValueToProperties(String value, CmdbPropertyValues values) {
    ((CmdbStringPropertyValues)values).add(value);
  }

  protected CmdbPropertyValues createPropertyValueByType() {
    return CmdbPropertyValuesFactory.createCmdbStringPropertyValues();
  }
}