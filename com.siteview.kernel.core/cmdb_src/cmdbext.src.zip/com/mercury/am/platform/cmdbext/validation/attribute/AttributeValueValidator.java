package com.mercury.am.platform.cmdbext.validation.attribute;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public abstract interface AttributeValueValidator
{
  public abstract String getName();

  public abstract void validateType(CmdbAttribute paramCmdbAttribute, Object paramObject)
    throws AttributeTypeValidationException;

  public abstract void validateNew(CmdbAttribute paramCmdbAttribute, CmdbClass paramCmdbClass, Object paramObject, Map paramMap, BasicUserData paramBasicUserData)
    throws AttributeValidationException;

  public abstract void validateUpdated(CmdbAttribute paramCmdbAttribute, CmdbClass paramCmdbClass, Object paramObject, Map paramMap, CmdbData paramCmdbData, BasicUserData paramBasicUserData)
    throws AttributeValidationException;
}