package com.mercury.am.platform.cmdbext.processing;

import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;

public class NumericAttributeProcessor extends SimpleAttributeProcessor
{
  public NumericAttributeProcessor(Class numericClass)
  {
    super(numericClass);
  }

  protected Object processStringValue(CmdbAttribute attribute, String valueAsString, CmdbData currentCmdbData, BasicUserData userContext) throws Exception {
    if (StringUtils.isEmpty(valueAsString)) {
      return null;
    }

    valueAsString = valueAsString.trim();

    return super.processStringValue(attribute, valueAsString, currentCmdbData, userContext);
  }

  protected String getErrorCode(CmdbAttribute attribute)
  {
    CmdbSimpleType simpleType = (CmdbSimpleType)attribute.getResolvedType();

    if (Long.class.equals(simpleType.getJavaClass()))
      return "processor.error.not.long";

    if (Integer.class.equals(simpleType.getJavaClass()))
      return "processor.error.not.integer";

    if (Float.class.equals(simpleType.getJavaClass()))
      return "processor.error.not.float";

    if (Double.class.equals(simpleType.getJavaClass())) {
      return "processor.error.not.double";
    }

    return "processor.error.general";
  }
}