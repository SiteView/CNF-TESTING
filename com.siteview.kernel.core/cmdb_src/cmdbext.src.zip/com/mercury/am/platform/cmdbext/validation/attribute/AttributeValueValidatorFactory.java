package com.mercury.am.platform.cmdbext.validation.attribute;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;

public abstract class AttributeValueValidatorFactory
{
  public static Log logger = LogFactory.getEasyLog(AttributeValueValidatorFactory.class);
  private static AttributeValueValidatorFactory instance = new AttributeValueValidatorFactoryImpl();
  public static final AttributeValueValidator SIZE_VALIDATOR = new AttributeSizeValidator();

  public static AttributeValueValidatorFactory getInstance()
  {
    return instance;
  }

  public abstract AttributeValueValidator create(CmdbClass paramCmdbClass, CmdbAttribute paramCmdbAttribute, Object paramObject)
    throws AttributeValidationException;

  public abstract AttributeValueValidator createDefault(CmdbAttribute paramCmdbAttribute, CmdbClass paramCmdbClass);
}