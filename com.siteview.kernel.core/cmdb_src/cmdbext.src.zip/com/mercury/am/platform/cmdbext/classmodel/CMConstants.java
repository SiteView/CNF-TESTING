package com.mercury.am.platform.cmdbext.classmodel;

public class CMConstants
{
  public class UDX_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "udx_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String MONITOR_ID = "monitor_id";
    public static final String NAME = "name";
    public static final String DATA_TYPE = "data_type";
    public static final String IS_FAILURE_RELATED = "is_failure_related";
    public static final String SEVERITY_CONDITION = "severity_condition";

    public UDX_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class DIAGNOSTICS_WEBSERVICE_MONITOR extends CMConstants.SOA_MONITOR
  {
    public static final String CLASS_NAME = "diagnostics_webservice_monitor";
    public static final String NAME_SPACE = "";
    public static final String THRESHOLD_VALUE = "threshold_value";
    public static final String TARGET_NAMESPACE = "target_namespace";
    public static final String WEB_SERVICE_NAME = "web_service_name";
    public static final String OPERATION_NAME = "operation_name";

    public DIAGNOSTICS_WEBSERVICE_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class BPM_WEBSERVICE_MONITOR extends CMConstants.SOA_MONITOR
  {
    public static final String CLASS_NAME = "bpm_webservice_monitor";
    public static final String NAME_SPACE = "";
    public static final String THRESHOLD_VALUE = "threshold_value";
    public static final String TARGET_NAMESPACE = "target_namespace";
    public static final String WEB_SERVICE_NAME = "web_service_name";
    public static final String OPERATION_NAME = "operation_name";

    public BPM_WEBSERVICE_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class SOA_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "soa_monitor";
    public static final String NAME_SPACE = "";

    public SOA_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class TRACKING_PERIOD extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "tracking_period";
    public static final String NAME_SPACE = "Mercury";
    public static final String TYPE = "type";
    public static final String TERM = "term";
    public static final String FACTOR = "factor";
    public static final String START_DATE = "start_date";

    public TRACKING_PERIOD()
    {
      super(paramCMConstants);
    }
  }

  public class SLA extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "sla";
    public static final String NAME_SPACE = "Mercury";
    public static final String VIEW_ID = "view_id";
    public static final String TIME_ZONE_ID = "time_zone_id";
    public static final String CREATOR = "creator";
    public static final String STATE = "state";
    public static final String START_DATE = "start_date";
    public static final String END_DATE = "end_date";
    public static final String TYPE = "type";
    public static final String CREATED_BY = "created_by";
    public static final String CLASSIFICATION = "classification";
    public static final String CUSTOMER = "customer";
    public static final String PROVIDER = "provider";
    public static final String CONTRACTDETAILS = "contractDetails";
    public static final String OWNER = "owner";
    public static final String INCLUDELOCATIONS = "includeLocations";
    public static final String TARGETS = "targets";
    public static final String BLE_DELTA_BETWEEN_CALC = "ble_delta_between_calc";

    public SLA()
    {
      super(paramCMConstants);
    }
  }

  public class OUTAGE_CATEGORY extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "outage_category";
    public static final String NAME_SPACE = "Mercury";

    public OUTAGE_CATEGORY()
    {
      super(paramCMConstants);
    }
  }

  public class OFFERING_LEVEL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "offering_level";
    public static final String NAME_SPACE = "Mercury";
    public static final String DISPLAY_NAME = "display_name";
    public static final String ITEM_ID = "item_id";
    public static final String TYPE = "type";

    public OFFERING_LEVEL()
    {
      super(paramCMConstants);
    }
  }

  public class OBJECTIVE extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "objective";
    public static final String NAME_SPACE = "Mercury";
    public static final String CRITICAL = "critical";
    public static final String MAJOR = "major";
    public static final String MINOR = "minor";
    public static final String WARNING = "warning";
    public static final String INFORMATIONAL = "informational";
    public static final String OPERATOR = "operator";
    public static final String ASSOCIATED_ALERT_IDS = "associated_alert_ids";

    public OBJECTIVE()
    {
      super(paramCMConstants);
    }
  }

  public class SLM_OBJECTIVE extends CMConstants.OBJECTIVE
  {
    public static final String CLASS_NAME = "slm_objective";
    public static final String NAME_SPACE = "Mercury";
    public static final String SCHEDULER_ID = "scheduler_id";
    public static final String TRACKING_PERIOD_ID = "tracking_period_id";

    public SLM_OBJECTIVE()
    {
      super(paramCMConstants);
    }
  }

  public class DIMENSION extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "dimension";
    public static final String NAME_SPACE = "Mercury";
    public static final String CONTEXT_ID = "context_id";
    public static final String ITEM_ID = "item_id";
    public static final String TYPE = "type";
    public static final String RULE = "rule";
    public static final String RULE_ARGUMENTS = "rule_arguments";
    public static final String SELECTOR_EXPRESSION = "selector_expression";

    public DIMENSION()
    {
      super(paramCMConstants);
    }
  }

  public class SCHEDULE extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "schedule";
    public static final String NAME_SPACE = "Mercury";
    public static final String START_DATE = "start_date";
    public static final String END_DATE = "end_date";
    public static final String TYPE = "type";
    public static final String SUBTYPE = "subtype";
    public static final String FAMILY = "family";
    public static final String RECURSIVE = "recursive";
    public static final String EXCLUDED = "excluded";
    public static final String TIME_ZONE_ID = "time_zone_id";

    public SCHEDULE()
    {
      super(paramCMConstants);
    }
  }

  public class SIMPLE_SCHEDULE extends CMConstants.SCHEDULE
  {
    public static final String CLASS_NAME = "simple_schedule";
    public static final String NAME_SPACE = "Mercury";
    public static final String DEFINITION_PROPERTIES = "definition_properties";

    public SIMPLE_SCHEDULE()
    {
      super(paramCMConstants);
    }
  }

  public class COMPOUND_SCHEDULE extends CMConstants.SCHEDULE
  {
    public static final String CLASS_NAME = "compound_schedule";
    public static final String NAME_SPACE = "Mercury";

    public COMPOUND_SCHEDULE()
    {
      super(paramCMConstants);
    }
  }

  public class NOTIFICATION_TEMPLATE extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "notification_template";
    public static final String NAME_SPACE = "Mercury";
    public static final String BODY = "body";
    public static final String CONTEXT_TYPE = "context_type";
    public static final String SUBJECT = "subject";
    public static final String CONTENT_TYPE = "content_type";

    public NOTIFICATION_TEMPLATE()
    {
      super(paramCMConstants);
    }
  }

  public class EMAIL_NOTIFICATION_TEMPLATE extends CMConstants.NOTIFICATION_TEMPLATE
  {
    public static final String CLASS_NAME = "email_notification_template";
    public static final String NAME_SPACE = "Mercury";
    public static final String EMAIL_SUBJECT = "email_subject";
    public static final String EMAIL_CONTENT_TYPE = "email_content_type";

    public EMAIL_NOTIFICATION_TEMPLATE()
    {
      super(paramCMConstants);
    }
  }

  public class ALERT_RECIPIENT extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "alert_recipient";
    public static final String NAME_SPACE = "Mercury";
    public static final String RECIPIENT_ID = "recipient_id";
    public static final String SAME_TEMPLATES = "same_templates";

    public ALERT_RECIPIENT()
    {
      super(paramCMConstants);
    }
  }

  public class ALERT_CONDITION extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "alert_condition";
    public static final String NAME_SPACE = "Mercury";

    public ALERT_CONDITION()
    {
      super(paramCMConstants);
    }
  }

  public class STATUS_WORSE_ALERT_CONDITION extends CMConstants.ALERT_CONDITION
  {
    public static final String CLASS_NAME = "status_worse_alert_condition";
    public static final String NAME_SPACE = "Mercury";
    public static final String CONDITION_TYPE = "condition_type";

    public STATUS_WORSE_ALERT_CONDITION()
    {
      super(paramCMConstants);
    }
  }

  public class STATUS_FOR_TIME_ALERT_CONDITION extends CMConstants.ALERT_CONDITION
  {
    public static final String CLASS_NAME = "status_for_time_alert_condition";
    public static final String NAME_SPACE = "Mercury";
    public static final String TRIGGERING_STATUS = "triggering_status";
    public static final String BETTER_OR_WORSE = "better_or_worse";
    public static final String TIME_INTERVAL = "time_interval";

    public STATUS_FOR_TIME_ALERT_CONDITION()
    {
      super(paramCMConstants);
    }
  }

  public class STATUS_CHANGE_ALERT_CONDITION extends CMConstants.ALERT_CONDITION
  {
    public static final String CLASS_NAME = "status_change_alert_condition";
    public static final String NAME_SPACE = "Mercury";
    public static final String PREVIOUS_STATUS = "previous_status";
    public static final String NEXT_STATUS = "next_status";

    public STATUS_CHANGE_ALERT_CONDITION()
    {
      super(paramCMConstants);
    }
  }

  public class STATUS_BETTER_ALERT_CONDITION extends CMConstants.ALERT_CONDITION
  {
    public static final String CLASS_NAME = "status_better_alert_condition";
    public static final String NAME_SPACE = "Mercury";
    public static final String CONDITION_TYPE = "condition_type";

    public STATUS_BETTER_ALERT_CONDITION()
    {
      super(paramCMConstants);
    }
  }

  public class FROM_ANY_STATUS_CHANGE_ALERT_CONDITION extends CMConstants.ALERT_CONDITION
  {
    public static final String CLASS_NAME = "from_any_status_change_alert_condition";
    public static final String NAME_SPACE = "Mercury";
    public static final String NEXT_STATUS = "next_status";

    public FROM_ANY_STATUS_CHANGE_ALERT_CONDITION()
    {
      super(paramCMConstants);
    }
  }

  public class ALERT extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "alert";
    public static final String NAME_SPACE = "Mercury";
    public static final String ALERT_TYPE = "alert_type";
    public static final String ENABLED = "enabled";
    public static final String DESCRIPTION = "description";
    public static final String RECIPIENTS = "recipients";
    public static final String URLS = "urls";
    public static final String EXECUTABLES = "executables";
    public static final String SNMPS = "snmps";
    public static final String FREQUENCY = "frequency";
    public static final String ACTIONS_XML = "actions_xml";
    public static final String WEBSERVICES = "webServices";

    public ALERT()
    {
      super(paramCMConstants);
    }
  }

  public class SLM_ALERT extends CMConstants.ALERT
  {
    public static final String CLASS_NAME = "slm_alert";
    public static final String NAME_SPACE = "Mercury";
    public static final String ALERT_CONTEXT = "alert_context";

    public SLM_ALERT()
    {
      super(paramCMConstants);
    }
  }

  public class FORECAST_ALERT extends CMConstants.ALERT
  {
    public static final String CLASS_NAME = "forecast_alert";
    public static final String NAME_SPACE = "Mercury";
    public static final String ALERT_CONTEXT = "alert_context";

    public FORECAST_ALERT()
    {
      super(paramCMConstants);
    }
  }

  public class EVENT_ALERT extends CMConstants.ALERT
  {
    public static final String CLASS_NAME = "event_alert";
    public static final String NAME_SPACE = "Mercury";
    public static final String SEVERITY = "severity";
    public static final String CONTINUOUS = "continuous";
    public static final String GROUP_BY = "group_by";
    public static final String VALIDATOR_CONFIG = "validator_config";
    public static final String FOLLOW_UP = "follow_up";
    public static final String FOLLOW_UP_ACTIONS_XML = "follow_up_actions_xml";
    public static final String CONTEXT_ID = "context_id";
    public static final String TYPE = "type";
    public static final String RULE = "rule";
    public static final String RULE_ARGUMENTS = "rule_arguments";
    public static final String SELECTOR_EXPRESSION = "selector_expression";

    public EVENT_ALERT()
    {
      super(paramCMConstants);
    }
  }

  public class DASHBOARD_ALERT extends CMConstants.ALERT
  {
    public static final String CLASS_NAME = "dashboard_alert";
    public static final String NAME_SPACE = "Mercury";
    public static final String ALERT_CONTEXT = "alert_context";

    public DASHBOARD_ALERT()
    {
      super(paramCMConstants);
    }
  }

  public class SUB_SCHEDULE extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "sub_schedule";
    public static final String NAME_SPACE = "Mercury";
    public static final String INCLUDE = "include";

    public SUB_SCHEDULE()
    {
      super(paramCMConstants);
    }
  }

  public class SUBORDINATE_ALERT_OF extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "subordinate_alert_of";
    public static final String NAME_SPACE = "Mercury";
    public static final String TIMEOUT = "timeout";

    public SUBORDINATE_ALERT_OF()
    {
      super(paramCMConstants);
    }
  }

  public class SLA_OFFERING_OF extends CMConstants.OFFERING_OF
  {
    public static final String CLASS_NAME = "sla_offering_of";
    public static final String NAME_SPACE = "Mercury";
    public static final String CONTEXT_ID = "context_id";

    public SLA_OFFERING_OF()
    {
      super(paramCMConstants);
    }
  }

  public class OFFERING_OF extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "offering_of";
    public static final String NAME_SPACE = "Mercury";

    public OFFERING_OF()
    {
      super(paramCMConstants);
    }
  }

  public class OFFERING_DIMENSION_OF extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "offering_dimension_of";
    public static final String NAME_SPACE = "Mercury";

    public OFFERING_DIMENSION_OF()
    {
      super(paramCMConstants);
    }
  }

  public class ASSOCIATION extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "association";
    public static final String NAME_SPACE = "Mercury";
    public static final String CONTEXT_ID = "context_id";

    public ASSOCIATION()
    {
      super(paramCMConstants);
    }
  }

  public class OBJECTIVE_OF extends CMConstants.ASSOCIATION
  {
    public static final String CLASS_NAME = "objective_of";
    public static final String NAME_SPACE = "Mercury";

    public OBJECTIVE_OF()
    {
      super(paramCMConstants);
    }
  }

  public class PHYSICAL_EVENT_OF extends CMConstants.EVENT_OF
  {
    public static final String CLASS_NAME = "physical_event_of";
    public static final String NAME_SPACE = "Mercury";

    public PHYSICAL_EVENT_OF()
    {
      super(paramCMConstants);
    }
  }

  public class LOGICAL_EVENT_OF extends CMConstants.EVENT_OF
  {
    public static final String CLASS_NAME = "logical_event_of";
    public static final String NAME_SPACE = "Mercury";
    public static final String EVENT_TYPE = "event_type";
    public static final String IS_RECURSIVE = "is_recursive";

    public LOGICAL_EVENT_OF()
    {
      super(paramCMConstants);
    }
  }

  public class EVENT_OF extends CMConstants.ASSOCIATION
  {
    public static final String CLASS_NAME = "event_of";
    public static final String NAME_SPACE = "Mercury";

    public EVENT_OF()
    {
      super(paramCMConstants);
    }
  }

  public class DIMENSION_OF extends CMConstants.ASSOCIATION
  {
    public static final String CLASS_NAME = "dimension_of";
    public static final String NAME_SPACE = "Mercury";

    public DIMENSION_OF()
    {
      super(paramCMConstants);
    }
  }

  public class NOTIFICATION_TEMPLATE_OF extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "notification_template_of";
    public static final String NAME_SPACE = "Mercury";
    public static final String NOTIFICATION_TYPE = "notification_type";

    public NOTIFICATION_TEMPLATE_OF()
    {
      super(paramCMConstants);
    }
  }

  public class FOLLOW_UP_TEMPLATE_OF extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "follow_up_template_of";
    public static final String NAME_SPACE = "Mercury";

    public FOLLOW_UP_TEMPLATE_OF()
    {
      super(paramCMConstants);
    }
  }

  public class ALERT_RECIPIENT_OF extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "alert_recipient_of";
    public static final String NAME_SPACE = "Mercury";

    public ALERT_RECIPIENT_OF()
    {
      super(paramCMConstants);
    }
  }

  public class ALERT_OF extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "alert_of";
    public static final String NAME_SPACE = "Mercury";

    public ALERT_OF()
    {
      super(paramCMConstants);
    }
  }

  public class ALERT_CONDITION_OF extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "alert_condition_of";
    public static final String NAME_SPACE = "Mercury";

    public ALERT_CONDITION_OF()
    {
      super(paramCMConstants);
    }
  }

  public class SITESCOPE_TARGET extends CMConstants.SYSTEM
  {
    public static final String CLASS_NAME = "sitescope_target";
    public static final String NAME_SPACE = "Mercury";
    public static final String HOST_KEY = "host_key";
    public static final String SESSION_ID = "session_id";
    public static final String HOST_DNSNAME = "host_dnsname";
    public static final String HOST_HOSTNAME = "host_hostname";

    public SITESCOPE_TARGET()
    {
      super(paramCMConstants);
    }
  }

  public class SITESCOPE_WEBSERVICE_MONITOR extends CMConstants.SITESCOPE_MONITOR
  {
    public static final String CLASS_NAME = "sitescope_webservice_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String TARGET_NAMESPACE = "target_namespace";
    public static final String WEB_SERVICE_NAME = "web_service_name";
    public static final String OPERATION_NAME = "operation_name";

    public SITESCOPE_WEBSERVICE_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class SITESCOPE_PROFILE_MONITOR extends CMConstants.SYSTEM_MONITOR
  {
    public static final String CLASS_NAME = "sitescope_profile_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String SESSION_ID = "session_id";
    public static final String MANAGED_BY = "managed_by";

    public SITESCOPE_PROFILE_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class SITESCOPE_MONITOR extends CMConstants.SYSTEM_MONITOR
  {
    public static final String CLASS_NAME = "sitescope_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String MONITOR_ID = "monitor_id";
    public static final String SESSION_ID = "session_id";
    public static final String GROUP_ID = "group_id";
    public static final String TOPOLOGY_VERSION = "topology_version";
    public static final String SESSION_NAME = "session_name";
    public static final String INTERNAL_NAME = "internal_name";
    public static final String MONITOR_TYPE = "monitor_type";
    public static final String TARGET_HOST = "target_host";
    public static final String LOGGING_OPTION = "logging_option";
    public static final String MANAGED_BY = "managed_by";

    public SITESCOPE_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class SITESCOPE_MEASUREMENT extends CMConstants.SYSTEM_MONITOR
  {
    public static final String CLASS_NAME = "sitescope_measurement";
    public static final String NAME_SPACE = "Mercury";
    public static final String MEASUREMENT_ID = "measurement_id";
    public static final String SESSION_ID = "session_id";
    public static final String GROUP_ID = "group_id";
    public static final String DIMENSION_ID = "dimension_id";
    public static final String SESSION_NAME = "session_name";
    public static final String MONITOR_TYPE = "monitor_type";
    public static final String TARGET_HOST = "target_host";
    public static final String MANAGED_BY = "managed_by";

    public SITESCOPE_MEASUREMENT()
    {
      super(paramCMConstants);
    }
  }

  public class SITESCOPE_PROFILE extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "sitescope_profile";
    public static final String NAME_SPACE = "Mercury";
    public static final String SESSION_ID = "session_id";
    public static final String MANAGED_BY = "managed_by";
    public static final String TOPOLOGY_VERSION = "topology_version";

    public SITESCOPE_PROFILE()
    {
      super(paramCMConstants);
    }
  }

  public class SITESCOPE_MEASUREMENT_GROUP extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "sitescope_measurement_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String MONITOR_ID = "monitor_id";
    public static final String SESSION_ID = "session_id";
    public static final String GROUP_ID = "group_id";
    public static final String SESSION_NAME = "session_name";
    public static final String INTERNAL_NAME = "internal_name";
    public static final String MONITOR_TYPE = "monitor_type";
    public static final String TARGET_HOST = "target_host";
    public static final String LOGGING_OPTION = "logging_option";
    public static final String MANAGED_BY = "managed_by";

    public SITESCOPE_MEASUREMENT_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class SITESCOPE_GROUP extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "sitescope_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String GROUP_ID = "group_id";
    public static final String SESSION_ID = "session_id";
    public static final String SESSION_NAME = "session_name";
    public static final String INTERNAL_NAME = "internal_name";
    public static final String MANAGED_BY = "managed_by";

    public SITESCOPE_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class MONITORED_BY_FOR_SIEBEL extends CMConstants.MONITORED_BY
  {
    public static final String CLASS_NAME = "monitored_by_for_siebel";
    public static final String NAME_SPACE = "Mercury";
    public static final String SIEBEL_LINKAGE = "siebel_linkage";

    public MONITORED_BY_FOR_SIEBEL()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_ALERT_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "sap_alert_monitor";
    public static final String NAME_SPACE = "";
    public static final String MSEGNAME = "msegname";
    public static final String ALERTTIME = "alerttime";
    public static final String ALERTDATE = "alertdate";
    public static final String SZTARGETHOSTIP = "sztargethostip";
    public static final String SZTARGETHOSTNAME = "sztargethostname";
    public static final String MSG = "msg";
    public static final String ALSYSID = "alsysid";
    public static final String ALUNIQNUM = "aluniqnum";
    public static final String ALINDEX = "alindex";
    public static final String IS_COMPLETED = "is_completed";

    public SAP_ALERT_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class MONITORED_BY_FOR_SAP extends CMConstants.MONITORED_BY
  {
    public static final String CLASS_NAME = "monitored_by_for_sap";
    public static final String NAME_SPACE = "Mercury";
    public static final String SAP_LINKAGE = "sap_linkage";

    public MONITORED_BY_FOR_SAP()
    {
      super(paramCMConstants);
    }
  }

  public class KPI_ENRICHMENT_BUNDLE extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "kpi_enrichment_bundle";
    public static final String NAME_SPACE = "";
    public static final String BUNDLE_ID = "bundle_id";
    public static final String BUNDLE_TYPE = "bundle_type";
    public static final String BUNDLE_VIEW_NAME = "bundle_view_name";
    public static final String APPLICATION_SPECIFIC_DATA = "application_specific_data";
    public static final String IS_RUNNING = "is_running";
    public static final String IS_COMPLETE = "is_complete";
    public static final String IS_CUSTOM = "is_custom";
    public static final String MENU = "MENU";

    public KPI_ENRICHMENT_BUNDLE()
    {
      super(paramCMConstants);
    }
  }

  public class KPI_ASSIGNMENT_CONFIGURATION extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "kpi_assignment_configuration";
    public static final String NAME_SPACE = "";
    public static final String ASSIGNMENT_CONDITION = "assignment_condition";
    public static final String ASSIGNMENT_TASK = "assignment_task";
    public static final String ASSIGNMENT_APPLICATION_TYPE = "assignment_application_type";
    public static final String BUNDLE_ID = "bundle_id";
    public static final String IS_RUNNING = "is_running";
    public static final String IS_SYNCHRONIZING = "is_synchronizing";
    public static final String ASSIGNMENT_ID = "assignment_id";
    public static final String LAST_PERFORMED = "last_performed";
    public static final String MENU = "MENU";
    public static final String LISTEN_TO_PROPERTIES_CONDITION_CHANGES = "listen_to_properties_condition_changes";
    public static final String EXCLUSIVE_CONDITION = "exclusive_condition";

    public KPI_ASSIGNMENT_CONFIGURATION()
    {
      super(paramCMConstants);
    }
  }

  public class DUMMY_SITESCOPE_PROFILE extends CMConstants.DUMMY_MONITOR
  {
    public static final String CLASS_NAME = "dummy_sitescope_profile";
    public static final String NAME_SPACE = "Mercury";
    public static final String SESSION_ID = "session_id";

    public DUMMY_SITESCOPE_PROFILE()
    {
      super(paramCMConstants);
    }
  }

  public class DUMMY_SITESCOPE_MONITOR extends CMConstants.DUMMY_MONITOR
  {
    public static final String CLASS_NAME = "dummy_sitescope_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String MONITOR_ID = "monitor_id";
    public static final String SESSION_ID = "session_id";

    public DUMMY_SITESCOPE_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class DUMMY_SITESCOPE_GROUP extends CMConstants.DUMMY_MONITOR
  {
    public static final String CLASS_NAME = "dummy_sitescope_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String GROUP_ID = "group_id";
    public static final String SESSION_ID = "session_id";

    public DUMMY_SITESCOPE_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class WEBSPHEREPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "websphereprotocol";
    public static final String NAME_SPACE = "";
    public static final String WEBSPHEREPROTOCOL_TRUSTSTOREPASS = "websphereprotocol_truststorepass";
    public static final String WEBSPHEREPROTOCOL_TRUSTSTORE = "websphereprotocol_truststore";
    public static final String WEBSPHEREPROTOCOL_KEYSTOREPASS = "websphereprotocol_keystorepass";
    public static final String WEBSPHEREPROTOCOL_KEYSTORE = "websphereprotocol_keystore";

    public WEBSPHEREPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class WEBSPHEREAS extends CMConstants.J2EESERVER
  {
    public static final String CLASS_NAME = "websphereas";
    public static final String NAME_SPACE = "";
    public static final String WEBSPHERE_CELLNAME = "websphere_cellname";
    public static final String WEBSPHERE_KEYSTOREPASSWORD = "websphere_keystorepassword";
    public static final String WEBSPHERE_NODENAME = "websphere_nodename";
    public static final String WEBSPHERE_KEYSTORE = "websphere_keystore";
    public static final String WEBSPHERE_TRUSTSTOREPASSWORD = "websphere_truststorepassword";
    public static final String WEBSPHERE_TRUSTSTORE = "websphere_truststore";
    public static final String WEBSPHERE_PLATFORMNAME = "websphere_platformname";
    public static final String WEBSPHERE_PLATFORMVERSION = "websphere_platformversion";

    public WEBSPHEREAS()
    {
      super(paramCMConstants);
    }
  }

  public class WEBMODULE extends CMConstants.J2EEMODULE
  {
    public static final String CLASS_NAME = "webmodule";
    public static final String NAME_SPACE = "";

    public WEBMODULE()
    {
      super(paramCMConstants);
    }
  }

  public class WEBLOGICPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "weblogicprotocol";
    public static final String NAME_SPACE = "";
    public static final String PROTOCOL = "protocol";
    public static final String KEYPEMPATH = "keyPemPath";
    public static final String CERTPEMPATH = "certPemPath";
    public static final String TRUSTFILENAME = "trustFileName";
    public static final String TRUSTFILEPASSWORD = "trustFilePassword";
    public static final String KEYFILENAME = "keyFileName";
    public static final String KEYFILEPASSWORD = "keyFilePassword";

    public WEBLOGICPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class WEBLOGICAS extends CMConstants.J2EESERVER
  {
    public static final String CLASS_NAME = "weblogicas";
    public static final String NAME_SPACE = "";
    public static final String WEBLOGIC_CERTPEMPATH = "weblogic_certPemPath";
    public static final String WEBLOGIC_KEYPEMPATH = "weblogic_keyPemPath";
    public static final String WEBLOGIC_TRUSTFILENAME = "weblogic_trustFileName";
    public static final String WEBLOGIC_KEYFILENAME = "weblogic_keyFileName";
    public static final String WEBLOGIC_ISADMINSERVER = "weblogic_isadminserver";

    public WEBLOGICAS()
    {
      super(paramCMConstants);
    }
  }

  public class WEBAPPLICATION extends CMConstants.J2EEDEPLOYEDOBJECT
  {
    public static final String CLASS_NAME = "webapplication";
    public static final String NAME_SPACE = "";
    public static final String WEBAPPLICATION_DEPLOYMENTDESCRIPTOR = "webapplication_deploymentdescriptor";
    public static final String WEBAPPLICATION_URI = "webapplication_uri";
    public static final String WEBAPPLICATION_SESSIONSOPENEDTOTALCOUNT = "webapplication_sessionsopenedtotalcount";
    public static final String WEBAPPLICATION_DOCUMENTROOT = "webapplication_documentroot";
    public static final String WEBAPPLICATION_OPENSESSIONSCURRENTCOUNT = "webapplication_opensessionscurrentcount";

    public WEBAPPLICATION()
    {
      super(paramCMConstants);
    }
  }

  public class VERITASCLUSTER extends CMConstants.FAILOVERCLUSTER
  {
    public static final String CLASS_NAME = "veritascluster";
    public static final String NAME_SPACE = "";

    public VERITASCLUSTER()
    {
      super(paramCMConstants);
    }
  }

  public class VCSRESOURCE extends CMConstants.CLUSTERRESOURCE
  {
    public static final String CLASS_NAME = "vcsresource";
    public static final String NAME_SPACE = "";

    public VCSRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class VCSGROUP extends CMConstants.CLUSTERGROUP
  {
    public static final String CLASS_NAME = "vcsgroup";
    public static final String NAME_SPACE = "";

    public VCSGROUP()
    {
      super(paramCMConstants);
    }
  }

  public class UDDIREGISTRY extends CMConstants.SYSTEM
  {
    public static final String CLASS_NAME = "uddiregistry";
    public static final String NAME_SPACE = "";
    public static final String DESCRIPTION = "description";
    public static final String IP_DOMAIN = "ip_domain";

    public UDDIREGISTRY()
    {
      super(paramCMConstants);
    }
  }

  public class SIEBEL_WSE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "siebel_wse";
    public static final String NAME_SPACE = "Mercury";
    public static final String DISPLAY_NAME = "display_name";
    public static final String SARM_LOG_FOLDER = "sarm_log_folder";
    public static final String ANON_USER_NAME = "anon_user_name";
    public static final String DO_COMPRESS = "do_compress";
    public static final String GUEST_SESSION_TIMEOUT = "guest_session_timeout";
    public static final String HTTP_PORT = "http_port";
    public static final String HTTPS_PORT = "https_port";
    public static final String INSTALL_PATH = "install_path";
    public static final String SESSION_TIME_OUT = "session_time_out";

    public SIEBEL_WSE()
    {
      super(paramCMConstants);
    }
  }

  public class SIEBEL_WEB_APP extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "siebel_web_app";
    public static final String NAME_SPACE = "Mercury";
    public static final String SUFFIX = "suffix";
    public static final String APP_SRV_NAME = "app_srv_name";
    public static final String APP_SRV_IP = "app_srv_ip";
    public static final String COMPONENT_NAME = "component_name";
    public static final String SITE = "site";

    public SIEBEL_WEB_APP()
    {
      super(paramCMConstants);
    }
  }

  public class SIEBEL_COMP_GRP extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "siebel_comp_grp";
    public static final String NAME_SPACE = "Mercury";
    public static final String DESC = "desc";
    public static final String ALIAS = "alias";
    public static final String ENABLED = "enabled";

    public SIEBEL_COMP_GRP()
    {
      super(paramCMConstants);
    }
  }

  public class SIEBEL_COMPONENT extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "siebel_component";
    public static final String NAME_SPACE = "Mercury";
    public static final String ALIAS = "alias";
    public static final String RUN_MODE = "run_mode";
    public static final String DESC = "desc";
    public static final String MAX_MTS = "max_mts";
    public static final String MAX_TASK = "max_task";
    public static final String SERVER_IP = "server_ip";
    public static final String SITE = "site";
    public static final String LOG_FOLDER = "log_folder";
    public static final String SARM_LOG_FOLDER = "sarm_log_folder";

    public SIEBEL_COMPONENT()
    {
      super(paramCMConstants);
    }
  }

  public class SIEBEL_APPLICATION extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "siebel_application";
    public static final String NAME_SPACE = "";
    public static final String EMULATED_TRX_USER_NAME = "emulated_trx_user_name";

    public SIEBEL_APPLICATION()
    {
      super(paramCMConstants);
    }
  }

  public class SIEBELGTWYPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "siebelgtwyprotocol";
    public static final String NAME_SPACE = "";
    public static final String SIEBELGTWYPROTOCOL_SITE = "siebelgtwyprotocol_site";
    public static final String SIEBELGTWYPROTOCOL_SRVRMGRPATH = "siebelgtwyprotocol_srvrmgrpath";

    public SIEBELGTWYPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class SIEBEL_SITE extends CMConstants.APPLICATIONSYSTEM
  {
    public static final String CLASS_NAME = "siebel_site";
    public static final String NAME_SPACE = "Mercury";
    public static final String DISPLAY_NAME = "display_name";
    public static final String ADMIN_PASSWORD = "admin_password";
    public static final String ADMIN_USER_NAME = "admin_user_name";
    public static final String SARM_SCRIPT_PATH = "sarm_script_path";
    public static final String SCRIPT_PATH = "script_path";
    public static final String SARM_PLATFORM = "sarm_platform";
    public static final String GATEWAY_ADDRESS = "gateway_address";

    public SIEBEL_SITE()
    {
      super(paramCMConstants);
    }
  }

  public class ORACLESYSTEM extends CMConstants.APPLICATIONSYSTEM
  {
    public static final String CLASS_NAME = "oraclesystem";
    public static final String NAME_SPACE = "";
    public static final String ORACLESYSTEM_DBADDRESS = "oraclesystem_dbaddress";
    public static final String ORACLESYSTEM_FORMSSESSIONS = "oraclesystem_formssessions";
    public static final String ORACLESYSTEM_DATABASESESSIONS = "oraclesystem_databasesessions";
    public static final String ORACLESYSTEM_REQUESTS = "oraclesystem_requests";
    public static final String ORACLESYSTEM_PROCESSES = "oraclesystem_processes";
    public static final String ORACLESYSTEM_SERVICESUP = "oraclesystem_servicesup";
    public static final String ORACLESYSTEM_SERVICESDOWN = "oraclesystem_servicesdown";
    public static final String ORACLESYSTEM_INVALIDDATAOBJECTS = "oraclesystem_invaliddataobjects";
    public static final String ORACLESYSTEM_UNSENTMAILS = "oraclesystem_unsentmails";
    public static final String ORACLESYSTEM_SENTMAILS = "oraclesystem_sentmails";
    public static final String ORACLESYSTEM_COMPLETEDREQUESTS = "oraclesystem_completedrequests";

    public ORACLESYSTEM()
    {
      super(paramCMConstants);
    }
  }

  public class WEBSERVICE_RESOURCE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "webservice_resource";
    public static final String NAME_SPACE = "";

    public WEBSERVICE_RESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class WEBSERVICE_OPERATION extends CMConstants.WEBSERVICE_RESOURCE
  {
    public static final String CLASS_NAME = "webservice_operation";
    public static final String NAME_SPACE = "";

    public WEBSERVICE_OPERATION()
    {
      super(paramCMConstants);
    }
  }

  public class WEBSERVICE extends CMConstants.WEBSERVICE_RESOURCE
  {
    public static final String CLASS_NAME = "webservice";
    public static final String NAME_SPACE = "";
    public static final String SERVICE_NAME = "service_name";
    public static final String WSDL_URL = "wsdl_url";
    public static final String MESSAGE_PROTOCOL = "message_protocol";

    public WEBSERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class SAPPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "sapprotocol";
    public static final String NAME_SPACE = "";
    public static final String SAPPROTOCOL_CLIENT = "sapprotocol_client";
    public static final String SAPPROTOCOL_SYSNUMBER = "sapprotocol_sysnumber";
    public static final String SAPPROTOCOL_ROUTER = "sapprotocol_router";

    public SAPPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class SAPJMXPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "sapjmxprotocol";
    public static final String NAME_SPACE = "";

    public SAPJMXPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class ORACLEAPPSRESOURCE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "oracleappsresource";
    public static final String NAME_SPACE = "";

    public ORACLEAPPSRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class ORACLEWEBCOMPONENT extends CMConstants.ORACLEAPPSRESOURCE
  {
    public static final String CLASS_NAME = "oraclewebcomponent";
    public static final String NAME_SPACE = "";
    public static final String ORACLEWEBCOMPONENT_DESCRIPTION = "oraclewebcomponent_description";
    public static final String ORACLEWEBCOMPONENT_DISPLAYNAME = "oraclewebcomponent_displayname";
    public static final String ORACLEWEBCOMPONENT_STATUS = "oraclewebcomponent_status";

    public ORACLEWEBCOMPONENT()
    {
      super(paramCMConstants);
    }
  }

  public class ORACLEAPPSERVICEMANAGER extends CMConstants.ORACLEAPPSRESOURCE
  {
    public static final String CLASS_NAME = "oracleappservicemanager";
    public static final String NAME_SPACE = "";
    public static final String ORACLEAPPSERVICEMANAGER_DESCRIPTION = "oracleappservicemanager_description";

    public ORACLEAPPSERVICEMANAGER()
    {
      super(paramCMConstants);
    }
  }

  public class ORACLEAPPSERVICE extends CMConstants.ORACLEAPPSRESOURCE
  {
    public static final String CLASS_NAME = "oracleappservice";
    public static final String NAME_SPACE = "";
    public static final String ORACLEAPPSERVICE_DESCRIPTION = "oracleappservice_description";
    public static final String ORACLEAPPSERVICE_MAXPROCESSES = "oracleappservice_maxprocesses";
    public static final String ORACLEAPPSERVICE_RUNNINGPROCESSES = "oracleappservice_runningprocesses";
    public static final String ORACLEAPPSERVICE_DISPLAYNAME = "oracleappservice_displayname";

    public ORACLEAPPSERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class ORACLEAPPLICATION extends CMConstants.ORACLEAPPSRESOURCE
  {
    public static final String CLASS_NAME = "oracleapplication";
    public static final String NAME_SPACE = "";
    public static final String ORACLEAPPLICATION_BASEPATH = "oracleapplication_basepath";
    public static final String ORACLEAPPLICATION_SHORTNAME = "oracleapplication_shortname";
    public static final String ORACLEAPPLICATION_STATUS = "oracleapplication_status";
    public static final String ORACLEAPPLICATION_PATCHSET = "oracleapplication_patchset";
    public static final String ORACLEAPPLICATION_INDEXTABLESPACE = "oracleapplication_indextablespace";
    public static final String ORACLEAPPLICATION_VERSION = "oracleapplication_version";
    public static final String ORACLEAPPLICATION_SIZING = "oracleapplication_sizing";
    public static final String ORACLEAPPLICATION_TABLESPACE = "oracleapplication_tablespace";
    public static final String ORACLEAPPLICATION_DESCRIPTION = "oracleapplication_description";
    public static final String ORACLEAPPLICATION_TEMPTABLESPACE = "oracleapplication_temptablespace";

    public ORACLEAPPLICATION()
    {
      super(paramCMConstants);
    }
  }

  public class SIEBEL_GATEWAY extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "siebel_gateway";
    public static final String NAME_SPACE = "Mercury";
    public static final String DISPLAY_NAME = "display_name";
    public static final String SVR_DS_TYPE = "svr_ds_type";
    public static final String CONFIG_FILE = "config_file";
    public static final String GTWY_DS_CONN_STR = "gtwy_ds_conn_str";
    public static final String GTWY_DS_TYPE = "gtwy_ds_type";
    public static final String SITE = "site";
    public static final String SRVRMGR_PATH = "srvrmgr_path";

    public SIEBEL_GATEWAY()
    {
      super(paramCMConstants);
    }
  }

  public class SIEBEL_APP_SERVER extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "siebel_app_server";
    public static final String NAME_SPACE = "Mercury";
    public static final String VERSION = "version";
    public static final String DISPLAY_NAME = "display_name";
    public static final String LOG_FOLDER = "log_folder";
    public static final String SVR_ID = "svr_id";
    public static final String SARM_LOG_FOLDER = "sarm_log_folder";
    public static final String BUILD = "build";
    public static final String INSTALL_DIR = "install_dir";
    public static final String LANG = "lang";
    public static final String ODBC_DSN = "odbc_dsn";
    public static final String SRV_DS_CONN_STR = "srv_ds_conn_str";
    public static final String SVR_DS_TYPE = "svr_ds_type";

    public SIEBEL_APP_SERVER()
    {
      super(paramCMConstants);
    }
  }

  public class ORACLEIAS extends CMConstants.J2EESERVER
  {
    public static final String CLASS_NAME = "oracleias";
    public static final String NAME_SPACE = "";
    public static final String ORACLEIAS_ADMIN = "oracleias_admin";
    public static final String ORACLEIAS_WEB = "oracleias_web";
    public static final String ORACLEIAS_CONCURRENTPROCESSING = "oracleias_concurrentprocessing";
    public static final String ORACLEIAS_FORM = "oracleias_form";

    public ORACLEIAS()
    {
      super(paramCMConstants);
    }
  }

  public class STORAGEPROCESSOR extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "storageprocessor";
    public static final String NAME_SPACE = "";
    public static final String STORAGEPROCESSOR_SERIALNUMBER = "storageprocessor_serialnumber";
    public static final String STORAGEPROCESSOR_RESETCAPABILITY = "storageprocessor_resetcapability";
    public static final String STORAGEPROCESSOR_STATUS = "storageprocessor_status";
    public static final String STORAGEPROCESSOR_VENDOR = "storageprocessor_vendor";
    public static final String STORAGEPROCESSOR_POWERMANAGEMENT = "storageprocessor_powermanagement";
    public static final String STORAGEPROCESSOR_DOMAINID = "storageprocessor_domainid";
    public static final String STORAGEPROCESSOR_MODEL = "storageprocessor_model";
    public static final String STORAGEPROCESSOR_VERSION = "storageprocessor_version";
    public static final String STORAGEPROCESSOR_DNS = "storageprocessor_dns";
    public static final String STORAGEPROCESSOR_WWN = "storageprocessor_wwn";
    public static final String STORAGEPROCESSOR_ROLES = "storageprocessor_roles";
    public static final String STORAGEPROCESSOR_IP = "storageprocessor_ip";
    public static final String STORAGEPROCESSOR_PROVIDERTAG = "storageprocessor_providertag";

    public STORAGEPROCESSOR()
    {
      super(paramCMConstants);
    }
  }

  public class STORAGEPOOL extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "storagepool";
    public static final String NAME_SPACE = "";
    public static final String STORAGEPOOL_POOLTYPE = "storagepool_pooltype";
    public static final String STORAGEPOOL_MBPROVISIONED = "storagepool_mbprovisioned";
    public static final String STORAGEPOOL_NOSINGLEPTOFFAILURE = "storagepool_nosingleptoffailure";
    public static final String STORAGEPOOL_DEFAULTNOSINGLEPTOFFAILURE = "storagepool_defaultnosingleptoffailure";
    public static final String STORAGEPOOL_CAPABILITYCOMMONNAME = "storagepool_capabilitycommonname";
    public static final String STORAGEPOOL_CAPACITYNUM = "storagepool_capacitynum";
    public static final String STORAGEPOOL_MBUNEXPORTED = "storagepool_mbunexported";
    public static final String STORAGEPOOL_CAPABILITYDESCRIPTION = "storagepool_capabilitydescription";
    public static final String STORAGEPOOL_MAXSPINDLEREDUNDANCY = "storagepool_maxspindleredundancy";
    public static final String STORAGEPOOL_MAXDATAREDUNDANCY = "storagepool_maxdataredundancy";
    public static final String STORAGEPOOL_CAPACITYTYPE = "storagepool_capacitytype";
    public static final String STORAGEPOOL_MINSPINDLEREDUNDANCY = "storagepool_minspindleredundancy";
    public static final String STORAGEPOOL_MBAVAILABLE = "storagepool_mbavailable";
    public static final String STORAGEPOOL_POOLID = "storagepool_poolid";
    public static final String STORAGEPOOL_MBTOTAL = "storagepool_mbtotal";
    public static final String STORAGEPOOL_CAPABILITYNAME = "storagepool_capabilityname";
    public static final String STORAGEPOOL_CIMPOOLID = "storagepool_cimpoolid";
    public static final String STORAGEPOOL_DEFAULTSPINDLEREDUNDANCY = "storagepool_defaultspindleredundancy";
    public static final String STORAGEPOOL_MBEXPORTED = "storagepool_mbexported";
    public static final String STORAGEPOOL_MINDATAREDUNDANCY = "storagepool_mindataredundancy";

    public STORAGEPOOL()
    {
      super(paramCMConstants);
    }
  }

  public class STORAGEFABRIC extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "storagefabric";
    public static final String NAME_SPACE = "";
    public static final String STORAGEFABRIC_WWN = "storagefabric_wwn";

    public STORAGEFABRIC()
    {
      super(paramCMConstants);
    }
  }

  public class STORAGEARRAY extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "storagearray";
    public static final String NAME_SPACE = "";
    public static final String STORAGEARRAY_PROVIDERTAG = "storagearray_providertag";
    public static final String STORAGEARRAY_STATUS = "storagearray_status";
    public static final String STORAGEARRAY_DOMAINID = "storagearray_domainid";
    public static final String STORAGEARRAY_HOSTRESOURCELIST = "storagearray_hostresourcelist";
    public static final String STORAGEARRAY_SERIALNUMBER = "storagearray_serialnumber";
    public static final String STORAGEARRAY_VENDOR = "storagearray_vendor";
    public static final String STORAGEARRAY_MODEL = "storagearray_model";
    public static final String STORAGEARRAY_VERSION = "storagearray_version";
    public static final String STORAGEARRAY_IP = "storagearray_ip";

    public STORAGEARRAY()
    {
      super(paramCMConstants);
    }
  }

  public class STATELESSSESSIONBEAN extends CMConstants.SESSIONBEAN
  {
    public static final String CLASS_NAME = "statelesssessionbean";
    public static final String NAME_SPACE = "";

    public STATELESSSESSIONBEAN()
    {
      super(paramCMConstants);
    }
  }

  public class STATEFULSESSIONBEAN extends CMConstants.SESSIONBEAN
  {
    public static final String CLASS_NAME = "statefulsessionbean";
    public static final String NAME_SPACE = "";
    public static final String STATEFULSESSIONBEAN_CACHEHITCOUNT = "statefulsessionbean_cachehitcount";
    public static final String STATEFULSESSIONBEAN_ACTIVATIONCOUNT = "statefulsessionbean_activationcount";
    public static final String STATEFULSESSIONBEAN_CACHEDBEANSCURRENTCOUNT = "statefulsessionbean_cachedbeanscurrentcount";
    public static final String STATEFULSESSIONBEAN_PASSIVATIONCOUNT = "statefulsessionbean_passivationcount";

    public STATEFULSESSIONBEAN()
    {
      super(paramCMConstants);
    }
  }

  public class SM_SWAP_FILE extends CMConstants.SM_RESOURCE
  {
    public static final String CLASS_NAME = "sm_swap_file";
    public static final String NAME_SPACE = "";
    public static final String FILE_NAME = "file_name";
    public static final String FILE_SIZE = "file_size";

    public SM_SWAP_FILE()
    {
      super(paramCMConstants);
    }
  }

  public class SM_RESOURCE extends CMConstants.SM_CI
  {
    public static final String CLASS_NAME = "sm_resource";
    public static final String NAME_SPACE = "";

    public SM_RESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class SM_PRINTER_RESOURCE extends CMConstants.SM_RESOURCE
  {
    public static final String CLASS_NAME = "sm_printer_resource";
    public static final String NAME_SPACE = "";
    public static final String DRIVER_VERSION = "driver_version";
    public static final String DRIVER_NAME = "driver_name";
    public static final String SERVER_NAME = "server_name";

    public SM_PRINTER_RESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class SM_PRINTER extends CMConstants.SM_DEVICE
  {
    public static final String CLASS_NAME = "sm_printer";
    public static final String NAME_SPACE = "";
    public static final String MANUFACTURER = "manufacturer";
    public static final String SYSTEM_NAME = "system_name";

    public SM_PRINTER()
    {
      super(paramCMConstants);
    }
  }

  public class SM_NETWORK_COMPONENT_EXT extends CMConstants.SM_BASE_NETWORK_COMPONENT
  {
    public static final String CLASS_NAME = "sm_network_component_ext";
    public static final String NAME_SPACE = "";

    public SM_NETWORK_COMPONENT_EXT()
    {
      super(paramCMConstants);
    }
  }

  public class SM_NETWORK_COMPONENT extends CMConstants.SM_BASE_NETWORK_COMPONENT
  {
    public static final String CLASS_NAME = "sm_network_component";
    public static final String NAME_SPACE = "";
    public static final String OS_VERSION = "os_version";
    public static final String DNS_NAME = "dns_name";
    public static final String OS = "os";
    public static final String MODEL = "model";
    public static final String VENDOR = "vendor";

    public SM_NETWORK_COMPONENT()
    {
      super(paramCMConstants);
    }
  }

  public class SM_MODEM extends CMConstants.SM_NETWORK_COMPONENT
  {
    public static final String CLASS_NAME = "sm_modem";
    public static final String NAME_SPACE = "";

    public SM_MODEM()
    {
      super(paramCMConstants);
    }
  }

  public class SM_LINK extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "sm_link";
    public static final String NAME_SPACE = "";

    public SM_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class SM_HUB extends CMConstants.SM_NETWORK_COMPONENT
  {
    public static final String CLASS_NAME = "sm_hub";
    public static final String NAME_SPACE = "";

    public SM_HUB()
    {
      super(paramCMConstants);
    }
  }

  public class SM_HOST extends CMConstants.SM_DEVICE
  {
    public static final String CLASS_NAME = "sm_host";
    public static final String NAME_SPACE = "";
    public static final String BIOS_MANUFACTURER = "bios_manufacturer";
    public static final String BIOS_MODEL = "bios_model";

    public SM_HOST()
    {
      super(paramCMConstants);
    }
  }

  public class SM_GATEWAY extends CMConstants.SM_NETWORK_COMPONENT
  {
    public static final String CLASS_NAME = "sm_gateway";
    public static final String NAME_SPACE = "";

    public SM_GATEWAY()
    {
      super(paramCMConstants);
    }
  }

  public class SM_DISK extends CMConstants.SM_RESOURCE
  {
    public static final String CLASS_NAME = "sm_disk";
    public static final String NAME_SPACE = "";
    public static final String DISK_FREE_SPACE = "disk_free_space";

    public SM_DISK()
    {
      super(paramCMConstants);
    }
  }

  public class SM_DEVICE extends CMConstants.SM_CI
  {
    public static final String CLASS_NAME = "sm_device";
    public static final String NAME_SPACE = "";
    public static final String ROOM = "room";
    public static final String BUILDING = "building";
    public static final String DEVICE_ID = "device_id";
    public static final String FLOOR = "floor";
    public static final String DEFAULT_GATEWAY = "default_gateway";
    public static final String ASSET_TAG = "asset_tag";
    public static final String CONTACT_NAME = "contact_name";
    public static final String CONTACT_CELLPHONE = "contact_cellphone";
    public static final String CONTACT_TELEPHONE = "contact_telephone";
    public static final String COST_CENTER = "cost_center";
    public static final String TELEPHONE_EXTENSION = "telephone_extension";
    public static final String LOCATION = "location";
    public static final String TITLE = "title";
    public static final String NET_BIOS = "net_bios";
    public static final String BIOS_SERIAL_NUMBER = "bios_serial_number";
    public static final String DOMAIN_SUFFIX = "domain_suffix";
    public static final String DEPARTMENT = "department";

    public SM_DEVICE()
    {
      super(paramCMConstants);
    }
  }

  public class SM_CI extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "sm_ci";
    public static final String NAME_SPACE = "";

    public SM_CI()
    {
      super(paramCMConstants);
    }
  }

  public class SM_BASE_NETWORK_COMPONENT extends CMConstants.SM_DEVICE
  {
    public static final String CLASS_NAME = "sm_base_network_component";
    public static final String NAME_SPACE = "";
    public static final String SYSTEM_NAME = "system_name";
    public static final String NUMBER_OF_PORTS = "number_of_ports";
    public static final String MANUFACTURER = "manufacturer";

    public SM_BASE_NETWORK_COMPONENT()
    {
      super(paramCMConstants);
    }
  }

  public class SGRESOURCE extends CMConstants.CLUSTERRESOURCE
  {
    public static final String CLASS_NAME = "sgresource";
    public static final String NAME_SPACE = "";

    public SGRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class SGPACKAGE extends CMConstants.CLUSTERGROUP
  {
    public static final String CLASS_NAME = "sgpackage";
    public static final String NAME_SPACE = "";

    public SGPACKAGE()
    {
      super(paramCMConstants);
    }
  }

  public class SESSIONBEAN extends CMConstants.EJB
  {
    public static final String CLASS_NAME = "sessionbean";
    public static final String NAME_SPACE = "";

    public SESSIONBEAN()
    {
      super(paramCMConstants);
    }
  }

  public class SERVLET extends CMConstants.J2EEMANAGEDOBJECT
  {
    public static final String CLASS_NAME = "servlet";
    public static final String NAME_SPACE = "";
    public static final String SERVLET_INVOCATIONTOTALCOUNT = "servlet_invocationtotalcount";
    public static final String SERVLET_POOLMAXCAPACITY = "servlet_poolmaxcapacity";
    public static final String SERVLET_SERVLETPATH = "servlet_servletpath";
    public static final String SERVLET_EXECUTIONTIMEHIGH = "servlet_executiontimehigh";
    public static final String SERVLET_RELOADTOTALCOUNT = "servlet_reloadtotalcount";
    public static final String SERVLET_EXECUTIONTIMEAVERAGE = "servlet_executiontimeaverage";
    public static final String SERVLET_URL = "servlet_url";

    public SERVLET()
    {
      super(paramCMConstants);
    }
  }

  public class SERVICEGUARDCLUSTER extends CMConstants.FAILOVERCLUSTER
  {
    public static final String CLASS_NAME = "serviceguardcluster";
    public static final String NAME_SPACE = "";

    public SERVICEGUARDCLUSTER()
    {
      super(paramCMConstants);
    }
  }

  public class SERVICE_DESK_LINK extends CMConstants.IT_PROCESS_LINK
  {
    public static final String CLASS_NAME = "service_desk_link";
    public static final String NAME_SPACE = "";

    public SERVICE_DESK_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class SCHEMAMASTER extends CMConstants.DOMAINCONTROLLERROLE
  {
    public static final String CLASS_NAME = "schemamaster";
    public static final String NAME_SPACE = "";

    public SCHEMAMASTER()
    {
      super(paramCMConstants);
    }
  }

  public class WEBRESOURCE extends CMConstants.SYSTEM
  {
    public static final String CLASS_NAME = "webresource";
    public static final String NAME_SPACE = "";

    public WEBRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class URL extends CMConstants.WEBRESOURCE
  {
    public static final String CLASS_NAME = "url";
    public static final String NAME_SPACE = "";
    public static final String URL_CONNECTSTRING = "url_connectstring";
    public static final String URL_TIMEOUT = "url_timeout";
    public static final String URL_PROTOCOL = "url_protocol";
    public static final String TYPE = "type";
    public static final String URL_RESPONSETIME = "url_responsetime";

    public URL()
    {
      super(paramCMConstants);
    }
  }

  public class WATCH extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "watch";
    public static final String NAME_SPACE = "Mercury";
    public static final String MODEL = "model";
    public static final String TQL = "tql";
    public static final String AUTO = "auto";
    public static final String START_TIME = "start_time";
    public static final String INTERVAL = "interval";
    public static final String CIS = "cis";
    public static final String SUPPRESSED = "suppressed";
    public static final String CHECKPOINT = "checkpoint";
    public static final String TO_DELETE = "to_delete";

    public WATCH()
    {
      super(paramCMConstants);
    }
  }

  public class VMWARE_ESX_SERVER extends CMConstants.HOST_NODE
  {
    public static final String CLASS_NAME = "vmware_esx_server";
    public static final String NAME_SPACE = "";

    public VMWARE_ESX_SERVER()
    {
      super(paramCMConstants);
    }
  }

  public class VMWARE_CLUSTER extends CMConstants.FAILOVERCLUSTER
  {
    public static final String CLASS_NAME = "vmware_cluster";
    public static final String NAME_SPACE = "";
    public static final String DRS_BEHAVIOR = "drs_behavior";
    public static final String DPM_ENABLED = "dpm_enabled";
    public static final String DAS_RESTART_PRIORITY = "das_restart_priority";
    public static final String DPM_BEHAVIOR = "dpm_behavior";
    public static final String DRS_VMOTION_RATE = "drs_vmotion_rate";
    public static final String DRS_ENABLED = "drs_enabled";
    public static final String DAS_ADMISSION_CONTROL_ENABLED = "das_admission_control_enabled";
    public static final String DAS_ENABLED = "das_enabled";
    public static final String TOTAL_CPU = "total_cpu";
    public static final String DAS_FAILOVER_LEVEL = "das_failover_level";
    public static final String DAS_ISOLATION_RESPONSE = "das_isolation_response";
    public static final String CLUSTER_STATUS = "cluster_status";
    public static final String TOTAL_MEMORY = "total_memory";

    public VMWARE_CLUSTER()
    {
      super(paramCMConstants);
    }
  }

  public class TICKET extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "ticket";
    public static final String NAME_SPACE = "";
    public static final String TICKET_TICKETNUMBER = "ticket_ticketnumber";
    public static final String TICKET_ASSIGNEDTO = "ticket_assignedto";
    public static final String TICKET_PRIORITY = "ticket_priority";
    public static final String TICKET_ENDDATE = "ticket_enddate";
    public static final String TICKET_CATEGORY = "ticket_category";
    public static final String TICKET_STATUS = "ticket_status";
    public static final String TICKET_TYPE = "ticket_type";
    public static final String TICKET_DESCRIPTION = "ticket_description";
    public static final String TICKET_STARTDATE = "ticket_startdate";
    public static final String TICKET_CHANGEINITIATOR = "ticket_changeinitiator";
    public static final String IMPACT_CATEGORY = "impact_category";
    public static final String IMPACT_SEVERITY = "impact_severity";

    public TICKET()
    {
      super(paramCMConstants);
    }
  }

  public class SAPTRANSPORT extends CMConstants.TICKET
  {
    public static final String CLASS_NAME = "saptransport";
    public static final String NAME_SPACE = "Mercury";
    public static final String SAPTRANSPORT_TARGETSYSTEM = "saptransport_targetsystem";

    public SAPTRANSPORT()
    {
      super(paramCMConstants);
    }
  }

  public class SYMBOL_ADDITIONAL_INFO extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "symbolAdditionalInfo";
    public static final String NAME_SPACE = "";
    public static final String SYMBOLID = "symbolID";
    public static final String SYMBOLDISPLAYINFO = "symbolDisplayInfo";
    public static final String MAPVIEW_NAME = "mapview_name";

    public SYMBOL_ADDITIONAL_INFO()
    {
      super(paramCMConstants);
    }
  }

  public class SYMBOL_NODE_ADDITIONAL_INFO extends CMConstants.SYMBOL_ADDITIONAL_INFO
  {
    public static final String CLASS_NAME = "symbolNodeAdditionalInfo";
    public static final String NAME_SPACE = "";

    public SYMBOL_NODE_ADDITIONAL_INFO()
    {
      super(paramCMConstants);
    }
  }

  public class SYMBOL_LINK_ADDITIONAL_INFO extends CMConstants.SYMBOL_ADDITIONAL_INFO
  {
    public static final String CLASS_NAME = "symbolLinkAdditionalInfo";
    public static final String NAME_SPACE = "";

    public SYMBOL_LINK_ADDITIONAL_INFO()
    {
      super(paramCMConstants);
    }
  }

  public class SNAPSHOT extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "snapshot";
    public static final String NAME_SPACE = "";
    public static final String SNAPSHOT_TQLNAME = "snapshot_tqlname";
    public static final String SNAPSHOT_DESCRIPTION = "snapshot_description";
    public static final String SNAPSHOT_SIZE = "snapshot_size";
    public static final String SNAPSHOT_TQLVERSION = "snapshot_tqlversion";
    public static final String SNAPSHOT_NOTE = "snapshot_note";
    public static final String SNAPSHOT_TIME = "snapshot_time";
    public static final String SNAPSHOT_OWNER = "snapshot_owner";
    public static final String SNAPSHOT_TQLRESULTS = "snapshot_tqlresults";

    public SNAPSHOT()
    {
      super(paramCMConstants);
    }
  }

  public class REPORT_RESULT extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "ReportResult";
    public static final String NAME_SPACE = "";
    public static final String REPORT_NAME = "report_name";
    public static final String REPORT_TIME = "report_time";
    public static final String REPORT_TYPE = "report_type";
    public static final String REPORT_OWNER = "report_owner";
    public static final String REPORT_DESCRIPTION = "report_description";
    public static final String TQL_RESULT = "tql_result";

    public REPORT_RESULT()
    {
      super(paramCMConstants);
    }
  }

  public class UDDIREGISTRYPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "uddiregistryprotocol";
    public static final String NAME_SPACE = "";
    public static final String UDDIREGISTRYPROTOCOL_URL = "uddiregistryprotocol_url";

    public UDDIREGISTRYPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class PAGE_DEFINITION extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "PageDefinition";
    public static final String NAME_SPACE = "";
    public static final String PAGE_NAME = "page_name";
    public static final String PAGE_DESCRIPTION = "page_description";
    public static final String PAGE_DEF = "page_def";
    public static final String REPORT_NAMES = "report_names";

    public PAGE_DEFINITION()
    {
      super(paramCMConstants);
    }
  }

  public class NETWORKRESOURCE extends CMConstants.SYSTEM
  {
    public static final String CLASS_NAME = "networkresource";
    public static final String NAME_SPACE = "";
    public static final String ISVIRTUAL = "isvirtual";

    public NETWORKRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class VLAN extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "vlan";
    public static final String NAME_SPACE = "";
    public static final String VLAN_ALIASNAME = "vlan_aliasname";
    public static final String VLAN_BRIDGEMAC = "vlan_bridgemac";
    public static final String VLAN_NUMBER = "vlan_number";

    public VLAN()
    {
      super(paramCMConstants);
    }
  }

  public class TRAIL extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "trail";
    public static final String NAME_SPACE = "";
    public static final String TRAIL_DESTNETMASK = "trail_destnetmask";
    public static final String TRAIL_COMPLETE = "trail_complete";
    public static final String TRAIL_DESTNETADDR = "trail_destnetaddr";
    public static final String TRAIL_DESTNETDOMAIN = "trail_destnetdomain";
    public static final String TRAIL_SRCNETDOMAIN = "trail_srcnetdomain";
    public static final String TRAIL_TOTALRESPONSETIME = "trail_totalresponsetime";
    public static final String TRAIL_SRCNETMASK = "trail_srcnetmask";
    public static final String TRAIL_SRCNETADDR = "trail_srcnetaddr";

    public TRAIL()
    {
      super(paramCMConstants);
    }
  }

  public class SYSPLEX extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "sysplex";
    public static final String NAME_SPACE = "";

    public SYSPLEX()
    {
      super(paramCMConstants);
    }
  }

  public class PORT extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "port";
    public static final String NAME_SPACE = "";
    public static final String PORT_NUMBER = "port_number";
    public static final String PORT_REMOTESTPPTID = "port_remotestpptid";
    public static final String PORT_TYPE = "port_type";
    public static final String PORT_SLOT = "port_slot";
    public static final String PORT_DISCOVERYLASTRUN = "port_discoverylastrun";
    public static final String PORT_NEXTMAC = "port_nextmac";
    public static final String PORT_VLAN = "port_vlan";
    public static final String PORT_INTFCINDEX = "port_intfcindex";
    public static final String PORT_REMOTESTPBGID = "port_remotestpbgid";
    public static final String PORT_HOSTBGID = "port_hostbgid";
    public static final String PORT_DISPLAYNAME = "port_displayName";
    public static final String L2HELP = "l2help";

    public PORT()
    {
      super(paramCMConstants);
    }
  }

  public class OSPF extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "ospf";
    public static final String NAME_SPACE = "";
    public static final String OSPF_AREAID = "ospf_areaid";

    public OSPF()
    {
      super(paramCMConstants);
    }
  }

  public class NETWORK extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "network";
    public static final String NAME_SPACE = "";
    public static final String NETWORK_COUNT = "network_count";
    public static final String NETWORK_NETTYPE = "network_nettype";
    public static final String NETWORK_MANAGED = "network_managed";
    public static final String NETWORK_PROBENAME = "network_probename";
    public static final String NETWORK_DOMAIN = "network_domain";
    public static final String NETWORK_NETMASK = "network_netmask";
    public static final String NETWORK_NETADDR = "network_netaddr";
    public static final String NETWORK_NETCLASS = "network_netclass";
    public static final String NETWORK_ISMANAGED = "network_ismanaged";
    public static final String NETWORK_BROADCASTADDRESS = "network_broadcastaddress";

    public NETWORK()
    {
      super(paramCMConstants);
    }
  }

  public class MSDOMAIN extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "msdomain";
    public static final String NAME_SPACE = "";
    public static final String MSDOMAIN_TYPE = "msdomain_type";
    public static final String MSDOMAIN_FOREST = "msdomain_forest";
    public static final String PROBE_NAME = "probe_name";

    public MSDOMAIN()
    {
      super(paramCMConstants);
    }
  }

  public class IPSERVER extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "ipserver";
    public static final String NAME_SPACE = "";
    public static final String IPSERVER_ADDRESS = "ipserver_address";
    public static final String IPPORT_TYPE = "ipport_type";
    public static final String IPPORT_NUMBER = "ipport_number";
    public static final String IPSERVER_CLIENTS = "ipserver_clients";
    public static final String IPSERVER_BANNER = "ipserver_banner";
    public static final String IP_ADDRESS = "ip_address";

    public IPSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class IPPORT extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "ipport";
    public static final String NAME_SPACE = "";
    public static final String IPPORT_TYPE = "ipport_type";
    public static final String IPPORT_NUMBER = "ipport_number";

    public IPPORT()
    {
      super(paramCMConstants);
    }
  }

  public class IPUNKNOWN extends CMConstants.IPPORT
  {
    public static final String CLASS_NAME = "ipunknown";
    public static final String NAME_SPACE = "";

    public IPUNKNOWN()
    {
      super(paramCMConstants);
    }
  }

  public class IPCLIENT extends CMConstants.IPPORT
  {
    public static final String CLASS_NAME = "ipclient";
    public static final String NAME_SPACE = "";
    public static final String IPCLIENT_REMOTEIP = "ipclient_remoteip";
    public static final String IPCLIENT_REMOTEPORT = "ipclient_remoteport";

    public IPCLIENT()
    {
      super(paramCMConstants);
    }
  }

  public class IP extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "ip";
    public static final String NAME_SPACE = "";
    public static final String IP_ADDRESS = "ip_address";
    public static final String IP_DNSNAME = "ip_dnsname";
    public static final String IP_NETMASK = "ip_netmask";
    public static final String IP_NETCLASS = "ip_netclass";
    public static final String IP_NETADDR = "ip_netaddr";
    public static final String IP_ISDHCP = "ip_isdhcp";
    public static final String IP_PROBENAME = "ip_probename";
    public static final String IP_DOMAIN = "ip_domain";
    public static final String IP_DHCPDOMAINNAME = "ip_dhcpdomainname";
    public static final String IP_NETTYPE = "ip_nettype";
    public static final String IP_ISMANAGED = "ip_ismanaged";
    public static final String IP_ISBROADCAST = "ip_isbroadcast";

    public IP()
    {
      super(paramCMConstants);
    }
  }

  public class IPFW extends CMConstants.IP
  {
    public static final String CLASS_NAME = "ipfw";
    public static final String NAME_SPACE = "";
    public static final String IPFW_HOPNUMBER = "ipfw_hopnumber";
    public static final String IPFW_TRAILID = "ipfw_trailid";

    public IPFW()
    {
      super(paramCMConstants);
    }
  }

  public class INTERFACEINDEX extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "interfaceindex";
    public static final String NAME_SPACE = "";
    public static final String INTERFACEINDEX_PORT = "interfaceindex_port";
    public static final String INTERFACEINDEX_USAGE = "interfaceindex_usage";
    public static final String INTERFACEINDEX_SPEED = "interfaceindex_speed";
    public static final String INTERFACEINDEX_VENDOR = "interfaceindex_vendor";
    public static final String INTERFACEINDEX_DESCRIPTION = "interfaceindex_description";
    public static final String INTERFACEINDEX_INBYTES = "interfaceindex_inbytes";
    public static final String INTERFACEINDEX_INERROR = "interfaceindex_inerror";
    public static final String INTERFACEINDEX_ADMINSTATUS = "interfaceindex_adminstatus";
    public static final String INTERFACEINDEX_INDEX = "interfaceindex_index";
    public static final String INTERFACEINDEX_TYPE = "interfaceindex_type";
    public static final String INTERFACEINDEX_OPERSTATUS = "interfaceindex_operstatus";
    public static final String INTERFACEINDEX_OUTBYTES = "interfaceindex_outbytes";
    public static final String INTERFACEINDEX_OUTERROR = "interfaceindex_outerror";

    public INTERFACEINDEX()
    {
      super(paramCMConstants);
    }
  }

  public class INTERFACE extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "interface";
    public static final String NAME_SPACE = "";
    public static final String INTERFACE_DESCRIPTION = "interface_description";
    public static final String INTERFACE_MACADDR = "interface_macaddr";
    public static final String ISPSEUDO = "isPseudo";
    public static final String L2HELP = "l2help";

    public INTERFACE()
    {
      super(paramCMConstants);
    }
  }

  public class ELAN extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "elan";
    public static final String NAME_SPACE = "";

    public ELAN()
    {
      super(paramCMConstants);
    }
  }

  public class DNSZONE extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "dnszone";
    public static final String NAME_SPACE = "";
    public static final String SOA = "soa";
    public static final String INTERVALS = "intervals";
    public static final String ADMIN = "admin";

    public DNSZONE()
    {
      super(paramCMConstants);
    }
  }

  public class BRIDGE extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "bridge";
    public static final String NAME_SPACE = "";
    public static final String BRIDGE_CONNECTED = "bridge_connected";
    public static final String BRIDGE_BASEMACADDR = "bridge_basemacaddr";
    public static final String BRIDGE_VLANCOMMUNITY = "bridge_vlancommunity";
    public static final String BRIDGE_ROOTMACADDR = "bridge_rootmacaddr";

    public BRIDGE()
    {
      super(paramCMConstants);
    }
  }

  public class ATMSWITCHING extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "atmswitching";
    public static final String NAME_SPACE = "";
    public static final String ATMSWITCHING_PNNINODEADDRESS = "atmswitching_pnninodeaddress";

    public ATMSWITCHING()
    {
      super(paramCMConstants);
    }
  }

  public class ATMPORT extends CMConstants.NETWORKRESOURCE
  {
    public static final String CLASS_NAME = "atmport";
    public static final String NAME_SPACE = "";
    public static final String ATMPORT_PNNIPORTNUMBER = "atmport_pnniportnumber";
    public static final String ATMPORT_IFNAME = "atmport_ifname";

    public ATMPORT()
    {
      super(paramCMConstants);
    }
  }

  public class LAYER_ADDITIONAL_INFO extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "LayerAdditionalInfo";
    public static final String NAME_SPACE = "";
    public static final String LAYERID = "layerID";
    public static final String LAYERDISPLAYINFO = "layerDisplayInfo";
    public static final String MAPVIEW_NAME = "mapview_name";

    public LAYER_ADDITIONAL_INFO()
    {
      super(paramCMConstants);
    }
  }

  public class REAL_TIME_KPI extends CMConstants.KPI
  {
    public static final String CLASS_NAME = "real_time_kpi";
    public static final String NAME_SPACE = "";
    public static final String CALCULATION_METHOD = "calculation_method";
    public static final String THRESHOLD_WARNING = "threshold_warning";
    public static final String STATUS = "status";
    public static final String THRESHOLD_OK = "threshold_ok";
    public static final String THRESHOLD_MAJOR = "threshold_major";
    public static final String THRESHOLD_MINOR = "threshold_minor";
    public static final String THRESHOLD_CRITICAL = "threshold_critical";
    public static final String LAST_STATUS_CHANGE = "last_status_change";
    public static final String NUMERIC_VALUE = "numeric_value";
    public static final String THRESHOLD_OPERATOR = "threshold_operator";
    public static final String VALUE_UNITS = "value_units";
    public static final String ADDITIONAL_INFO = "additional_info";

    public REAL_TIME_KPI()
    {
      super(paramCMConstants);
    }
  }

  public class KPI extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "kpi";
    public static final String NAME_SPACE = "";
    public static final String KPI_SOURCE = "kpi_source";
    public static final String KPI_NAME = "kpi_name";

    public KPI()
    {
      super(paramCMConstants);
    }
  }

  public class LOGICAL_GROUP extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "logical_group";
    public static final String NAME_SPACE = "Mercury";

    public LOGICAL_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class BUSINESS_UNIT extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "business_unit";
    public static final String NAME_SPACE = "Mercury";
    public static final String DISPLAY_NAME = "display_name";
    public static final String CONTACT_INFO = "contact_info";

    public BUSINESS_UNIT()
    {
      super(paramCMConstants);
    }
  }

  public class HOST_NODE extends CMConstants.HOST
  {
    public static final String CLASS_NAME = "host_node";
    public static final String NAME_SPACE = "";

    public HOST_NODE()
    {
      super(paramCMConstants);
    }
  }

  public class HOSTRESOURCE extends CMConstants.SYSTEM
  {
    public static final String CLASS_NAME = "hostresource";
    public static final String NAME_SPACE = "";
    public static final String FAMILY_ICON = "FAMILY_ICON";
    public static final String BODY_ICON = "BODY_ICON";
    public static final String ISVIRTUAL = "isvirtual";

    public HOSTRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class VMWARE_HOST_RESOURCE extends CMConstants.VIRTUAL_HOST_RESOURCE
  {
    public static final String CLASS_NAME = "vmware_host_resource";
    public static final String NAME_SPACE = "";
    public static final String VM_CPU_SHARES_LEVEL = "vm_cpu_shares_level";
    public static final String VM_TOOLS_STATUS = "vm_tools_status";
    public static final String VM_MEMORY_SIZE = "vm_memory_size";
    public static final String VM_MEMORY_LIMIT = "vm_memory_limit";
    public static final String VM_MEMORY_RESERVATION = "vm_memory_reservation";
    public static final String VM_NUM_CPUS = "vm_num_cpus";
    public static final String VM_CPU_LIMIT = "vm_cpu_limit";
    public static final String VM_CPU_RESERVATION = "vm_cpu_reservation";
    public static final String VM_CPU_SHARES = "vm_cpu_shares";
    public static final String VM_STATUS = "vm_status";
    public static final String VM_MEMORY_SHARES_LEVEL = "vm_memory_shares_level";
    public static final String VM_UUID = "vm_uuid";
    public static final String VM_MEMORY_SHARES = "vm_memory_shares";
    public static final String VM_IS_TEMPLATE = "vm_is_template";

    public VMWARE_HOST_RESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class VIRTUAL_HOST_RESOURCE extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "virtual_host_resource";
    public static final String NAME_SPACE = "";

    public VIRTUAL_HOST_RESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class SOFTWARE extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "software";
    public static final String NAME_SPACE = "";
    public static final String SOFTWARE_VENDOR = "software_vendor";
    public static final String SOFTWARE_VERSION = "software_version";
    public static final String SOFTWARE_PRODUCTID = "software_productid";
    public static final String SOFTWARE_DATA = "software_data";
    public static final String SOFTWARE_INSTALLPATH = "software_installpath";
    public static final String SOFTWARE_TYPE = "software_type";

    public SOFTWARE()
    {
      super(paramCMConstants);
    }
  }

  public class SERVICE extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "service";
    public static final String NAME_SPACE = "";
    public static final String SERVICE_OPERATINGSTATUS = "service_operatingstatus";
    public static final String SERVICE_INSTALLSTATUS = "service_installstatus";
    public static final String SERVICE_PARAMETERS = "service_parameters";
    public static final String SERVICE_STARTTYPE = "service_starttype";
    public static final String SERVICE_CANBEPAUSED = "service_canbepaused";
    public static final String SERVICE_CANBEUNINSTALLED = "service_canbeuninstalled";
    public static final String SERVICE_PATHTOEXEC = "service_pathtoexec";
    public static final String SERVICE_DESCRIPTION = "service_description";
    public static final String SERVICE_COMMANDLINE = "service_commandline";

    public SERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class PROCESS extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "process";
    public static final String NAME_SPACE = "";
    public static final String PROCESS_PARAMETERS = "process_parameters";
    public static final String PROCESS_CPUUSED = "process_cpuused";
    public static final String PROCESS_PID = "process_pid";
    public static final String PROCESS_PATH = "process_path";
    public static final String PROCESS_USER = "process_user";
    public static final String PROCESS_MEMUSED = "process_memused";
    public static final String PROCESS_CMDLINE = "process_cmdline";
    public static final String PROCESS_CONNECTIONCOUNT = "process_connectioncount";
    public static final String PROCESS_STARTUPTIME = "process_startuptime";

    public PROCESS()
    {
      super(paramCMConstants);
    }
  }

  public class PRINTQ extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "printq";
    public static final String NAME_SPACE = "";
    public static final String PRINTQ_WAITINGJOBS = "printq_waitingjobs";
    public static final String PRINTQ_ISLOCAL = "printq_islocal";

    public PRINTQ()
    {
      super(paramCMConstants);
    }
  }

  public class PRINTER extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "printer";
    public static final String NAME_SPACE = "";
    public static final String PRINTER_ISOUTOFPAPER = "printer_isoutofpaper";
    public static final String PRINTER_STATUS = "printer_status";
    public static final String PRINTER_ERRORSTATE = "printer_errorstate";

    public PRINTER()
    {
      super(paramCMConstants);
    }
  }

  public class OSUSER extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "osuser";
    public static final String NAME_SPACE = "";
    public static final String OSUSER_GID = "osuser_gid";
    public static final String OSUSER_UID = "osuser_uid";

    public OSUSER()
    {
      super(paramCMConstants);
    }
  }

  public class WINOSUSER extends CMConstants.OSUSER
  {
    public static final String CLASS_NAME = "winosuser";
    public static final String NAME_SPACE = "";
    public static final String WINOSUSER_ISLOCAL = "winosuser_islocal";
    public static final String WINOSUSER_DOMAIN = "winosuser_domain";
    public static final String WINOSUSER_ISDISABLED = "winosuser_isdisabled";
    public static final String WINOSUSER_ISLOCKED = "winosuser_islocked";
    public static final String WINOSUSER_FULL_NAME = "winosuser_full_name";

    public WINOSUSER()
    {
      super(paramCMConstants);
    }
  }

  public class NETWORKSHARE extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "networkshare";
    public static final String NAME_SPACE = "";
    public static final String SHARE_PATH = "share_path";

    public NETWORKSHARE()
    {
      super(paramCMConstants);
    }
  }

  public class MEMORY extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "memory";
    public static final String NAME_SPACE = "";
    public static final String MEMORY_SIZE = "memory_size";

    public MEMORY()
    {
      super(paramCMConstants);
    }
  }

  public class FILE extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "file";
    public static final String NAME_SPACE = "";
    public static final String FILE_LINES = "file_lines";
    public static final String FILE_MONITORED = "file_monitored";
    public static final String FILE_PATH = "file_path";
    public static final String FILE_SIZE = "file_size";
    public static final String FILE_LASTMODIFYDATE = "file_lastmodifydate";
    public static final String FILE_INCREASERATE = "file_increaserate";
    public static final String FILE_LASTACCESS = "file_lastaccess";

    public FILE()
    {
      super(paramCMConstants);
    }
  }

  public class LOGFILE extends CMConstants.FILE
  {
    public static final String CLASS_NAME = "logfile";
    public static final String NAME_SPACE = "";
    public static final String LOGFILE_EVENTRULE = "logfile_eventrule";
    public static final String LOGFILE_LASTTRIGGER = "logfile_lasttrigger";
    public static final String LOGFILE_SEARCHPATTERN = "logfile_searchpattern";

    public LOGFILE()
    {
      super(paramCMConstants);
    }
  }

  public class DIR extends CMConstants.FILE
  {
    public static final String CLASS_NAME = "dir";
    public static final String NAME_SPACE = "";
    public static final String DIR_FREESPACE = "dir_freespace";
    public static final String DIR_QUOTA = "dir_quota";
    public static final String DIR_USED = "dir_used";

    public DIR()
    {
      super(paramCMConstants);
    }
  }

  public class LOGDIR extends CMConstants.DIR
  {
    public static final String CLASS_NAME = "logdir";
    public static final String NAME_SPACE = "";
    public static final String LOGDIR_LOGPATTERN = "logdir_logpattern";

    public LOGDIR()
    {
      super(paramCMConstants);
    }
  }

  public class EVENTLOG extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "eventlog";
    public static final String NAME_SPACE = "";
    public static final String EVENTLOG_TYPE = "eventlog_type";
    public static final String EVENTLOG_APPLICATION = "eventlog_application";
    public static final String EVENTLOG_SEVERITY = "eventlog_severity";

    public EVENTLOG()
    {
      super(paramCMConstants);
    }
  }

  public class DISK extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "disk";
    public static final String NAME_SPACE = "";
    public static final String DISK_TYPE = "disk_type";
    public static final String FILESYSTEM_TYPE = "filesystem_type";
    public static final String DISK_SIZE = "disk_size";
    public static final String DISK_FAILURES = "disk_failures";

    public DISK()
    {
      super(paramCMConstants);
    }
  }

  public class DAEMON extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "daemon";
    public static final String NAME_SPACE = "";
    public static final String DAEMON_PATH = "daemon_path";
    public static final String DAEMON_PARAMETERS = "daemon_parameters";
    public static final String DAEMON_PID = "daemon_pid";
    public static final String DAEMON_INSTANCES = "daemon_instances";
    public static final String DAEMON_REQUIRED = "daemon_required";

    public DAEMON()
    {
      super(paramCMConstants);
    }
  }

  public class CPU extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "cpu";
    public static final String NAME_SPACE = "";
    public static final String CPU_SPEED = "cpu_speed";
    public static final String CORE_NUMBER = "core_number";
    public static final String CPU_USAGE = "cpu_usage";
    public static final String CPU_CID = "cpu_cid";
    public static final String CPU_VENDOR = "cpu_vendor";

    public CPU()
    {
      super(paramCMConstants);
    }
  }

  public class HOST extends CMConstants.SYSTEM
  {
    public static final String CLASS_NAME = "host";
    public static final String NAME_SPACE = "";
    public static final String HOST_KEY = "host_key";
    public static final String HOST_OS = "host_os";
    public static final String HOST_OSACCURACY = "host_osaccuracy";
    public static final String HOST_OSVERSION = "host_osversion";
    public static final String HOST_OSRELEASE = "host_osrelease";
    public static final String HOST_OSINSTALLTYPE = "host_osinstalltype";
    public static final String HOST_SERIALNUMBER = "host_serialnumber";
    public static final String HOST_DNSNAME = "host_dnsname";
    public static final String HOST_SYSTEMASSETTAG = "host_systemassettag";
    public static final String HOST_OSDOMAIN = "host_osdomain";
    public static final String HOST_HOSTNAME = "host_hostname";
    public static final String HOST_SNMPSYSNAME = "host_snmpsysname";
    public static final String HOST_MANUFACTURER = "host_manufacturer";
    public static final String HOST_BIOSUUID = "host_biosuuid";
    public static final String HOST_ISCOMPLETE = "host_iscomplete";
    public static final String HOST_ISROUTE = "host_isroute";
    public static final String HOST_ISVIRTUAL = "host_isvirtual";
    public static final String HOST_SERVERTYPE = "host_servertype";
    public static final String HOST_VENDOR = "host_vendor";
    public static final String HOST_MODEL = "host_model";
    public static final String INTERNAL_NAME = "internal_name";
    public static final String HOST_LAST_BOOT_TIME = "host_last_boot_time";
    public static final String HOST_ISDESKTOP = "host_isdesktop";
    public static final String HOST_NNM_UID = "host_nnm_uid";

    public HOST()
    {
      super(paramCMConstants);
    }
  }

  public class VAX extends CMConstants.HOST_NODE
  {
    public static final String CLASS_NAME = "vax";
    public static final String NAME_SPACE = "";

    public VAX()
    {
      super(paramCMConstants);
    }
  }

  public class UNIX extends CMConstants.HOST_NODE
  {
    public static final String CLASS_NAME = "unix";
    public static final String NAME_SPACE = "";
    public static final String UNIX_DESCRIPTION = "unix_description";

    public UNIX()
    {
      super(paramCMConstants);
    }
  }

  public class TERMINALSERVER extends CMConstants.HOST_NODE
  {
    public static final String CLASS_NAME = "terminalserver";
    public static final String NAME_SPACE = "";

    public TERMINALSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class SWITCH extends CMConstants.NETDEVICE
  {
    public static final String CLASS_NAME = "switch";
    public static final String NAME_SPACE = "";

    public SWITCH()
    {
      super(paramCMConstants);
    }
  }

  public class SWITCHROUTER extends CMConstants.SWITCH
  {
    public static final String CLASS_NAME = "switchrouter";
    public static final String NAME_SPACE = "";

    public SWITCHROUTER()
    {
      super(paramCMConstants);
    }
  }

  public class ROUTER extends CMConstants.NETDEVICE
  {
    public static final String CLASS_NAME = "router";
    public static final String NAME_SPACE = "";

    public ROUTER()
    {
      super(paramCMConstants);
    }
  }

  public class RAS extends CMConstants.NETDEVICE
  {
    public static final String CLASS_NAME = "ras";
    public static final String NAME_SPACE = "";

    public RAS()
    {
      super(paramCMConstants);
    }
  }

  public class NT extends CMConstants.HOST_NODE
  {
    public static final String CLASS_NAME = "nt";
    public static final String NAME_SPACE = "";
    public static final String NT_REGISTEREDOWNER = "nt_registeredowner";
    public static final String NT_PROCESSORSNUMBER = "nt_processorsnumber";
    public static final String NT_MAINPROCESSORSPEED = "nt_mainprocessorspeed";
    public static final String NT_IEVERSION = "nt_ieversion";
    public static final String NT_PHYSICALMEMORY = "nt_physicalmemory";
    public static final String NT_KERNEL = "nt_kernel";
    public static final String NT_SERVICEPACK = "nt_servicepack";
    public static final String NT_MAINPROCESSORTYPE = "nt_mainprocessortype";
    public static final String NT_REGISTRATIONORG = "nt_registrationorg";

    public NT()
    {
      super(paramCMConstants);
    }
  }

  public class NETDEVICE extends CMConstants.HOST
  {
    public static final String CLASS_NAME = "netdevice";
    public static final String NAME_SPACE = "";

    public NETDEVICE()
    {
      super(paramCMConstants);
    }
  }

  public class NETPRINTER extends CMConstants.NETDEVICE
  {
    public static final String CLASS_NAME = "netprinter";
    public static final String NAME_SPACE = "";

    public NETPRINTER()
    {
      super(paramCMConstants);
    }
  }

  public class MAINFRAME extends CMConstants.HOST_NODE
  {
    public static final String CLASS_NAME = "mainframe";
    public static final String NAME_SPACE = "";

    public MAINFRAME()
    {
      super(paramCMConstants);
    }
  }

  public class LPAR extends CMConstants.HOST_NODE
  {
    public static final String CLASS_NAME = "lpar";
    public static final String NAME_SPACE = "";

    public LPAR()
    {
      super(paramCMConstants);
    }
  }

  public class LB extends CMConstants.NETDEVICE
  {
    public static final String CLASS_NAME = "lb";
    public static final String NAME_SPACE = "";
    public static final String LB_FEATURES = "lb_features";
    public static final String LB_REDUNDANTOPERSTATUS = "lb_redundantoperstatus";

    public LB()
    {
      super(paramCMConstants);
    }
  }

  public class FIREWALL extends CMConstants.NETDEVICE
  {
    public static final String CLASS_NAME = "firewall";
    public static final String NAME_SPACE = "";

    public FIREWALL()
    {
      super(paramCMConstants);
    }
  }

  public class CONCENTRATOR extends CMConstants.NETDEVICE
  {
    public static final String CLASS_NAME = "concentrator";
    public static final String NAME_SPACE = "";
    public static final String CONCENTRATOR_DISCOVERYLASTRUN = "concentrator_discoverylastrun";
    public static final String L2HELP = "l2help";

    public CONCENTRATOR()
    {
      super(paramCMConstants);
    }
  }

  public class CHASSIS extends CMConstants.NETDEVICE
  {
    public static final String CLASS_NAME = "chassis";
    public static final String NAME_SPACE = "";
    public static final String CHASSIS_VENDOR = "chassis_vendor";
    public static final String CHASSIS_MODEL = "chassis_model";
    public static final String CHASSIS_UNIQUEID = "chassis_uniqueid";

    public CHASSIS()
    {
      super(paramCMConstants);
    }
  }

  public class ATMSWITCH extends CMConstants.NETDEVICE
  {
    public static final String CLASS_NAME = "atmswitch";
    public static final String NAME_SPACE = "";

    public ATMSWITCH()
    {
      super(paramCMConstants);
    }
  }

  public class MARCONIATMSWITCH extends CMConstants.ATMSWITCH
  {
    public static final String CLASS_NAME = "marconiatmswitch";
    public static final String NAME_SPACE = "";
    public static final String MARCONIATMSWITCH_EVMTMGTBDSERIAL = "marconiatmswitch_evmtmgtbdserial";

    public MARCONIATMSWITCH()
    {
      super(paramCMConstants);
    }
  }

  public class EMAIL_RECIPIENT extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "EmailRecipient";
    public static final String NAME_SPACE = "";
    public static final String RECIPIENT_EMAIL = "recipient_email";
    public static final String RECIPIENT_NAME = "recipient_name";
    public static final String RECIPIENT_CUSTOMER_ID = "recipient_customer_id";
    public static final String RECIPIENT_TIMEDIFF = "recipient_timeDiff";
    public static final String RECIPIENT_ID = "recipient_id";

    public EMAIL_RECIPIENT()
    {
      super(paramCMConstants);
    }
  }

  public class DATACENTER extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "datacenter";
    public static final String NAME_SPACE = "";
    public static final String DATACENTER_STATUS = "datacenter_status";

    public DATACENTER()
    {
      super(paramCMConstants);
    }
  }

  public class DATABASE_INSTANCE extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "database_instance";
    public static final String NAME_SPACE = "";
    public static final String CREATEDATE = "createdate";

    public DATABASE_INSTANCE()
    {
      super(paramCMConstants);
    }
  }

  public class DATABASERESOURCE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "databaseresource";
    public static final String NAME_SPACE = "";

    public DATABASERESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class SYBASEDB extends CMConstants.DATABASE_INSTANCE
  {
    public static final String CLASS_NAME = "sybasedb";
    public static final String NAME_SPACE = "";

    public SYBASEDB()
    {
      super(paramCMConstants);
    }
  }

  public class SQLSERVERRESOURCE extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "sqlserverresource";
    public static final String NAME_SPACE = "";

    public SQLSERVERRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class SQLSERVERSUBSCRIPTION extends CMConstants.SQLSERVERRESOURCE
  {
    public static final String CLASS_NAME = "sqlserversubscription";
    public static final String NAME_SPACE = "";

    public SQLSERVERSUBSCRIPTION()
    {
      super(paramCMConstants);
    }
  }

  public class SQLSERVERPUBLISHER extends CMConstants.SQLSERVERRESOURCE
  {
    public static final String CLASS_NAME = "sqlserverpublisher";
    public static final String NAME_SPACE = "";

    public SQLSERVERPUBLISHER()
    {
      super(paramCMConstants);
    }
  }

  public class SQLSERVERPUBLICATION extends CMConstants.SQLSERVERRESOURCE
  {
    public static final String CLASS_NAME = "sqlserverpublication";
    public static final String NAME_SPACE = "";
    public static final String PUBLICATIONTYPE = "publicationType";

    public SQLSERVERPUBLICATION()
    {
      super(paramCMConstants);
    }
  }

  public class SQLSERVERMODULE extends CMConstants.SQLSERVERRESOURCE
  {
    public static final String CLASS_NAME = "sqlservermodule";
    public static final String NAME_SPACE = "";

    public SQLSERVERMODULE()
    {
      super(paramCMConstants);
    }
  }

  public class SQLSERVERMAINTENANCEPLAN extends CMConstants.SQLSERVERRESOURCE
  {
    public static final String CLASS_NAME = "sqlservermaintenanceplan";
    public static final String NAME_SPACE = "";
    public static final String PLANID = "planId";

    public SQLSERVERMAINTENANCEPLAN()
    {
      super(paramCMConstants);
    }
  }

  public class SQLSERVERDISTRIBUTOR extends CMConstants.SQLSERVERRESOURCE
  {
    public static final String CLASS_NAME = "sqlserverdistributor";
    public static final String NAME_SPACE = "";
    public static final String MINTXRETENTION = "minTxRetention";
    public static final String MAXTXRETENTION = "maxTxRetention";
    public static final String HISTORYRETENTION = "historyRetention";
    public static final String CLEANUPAGENTPROFILE = "cleanupAgentProfile";

    public SQLSERVERDISTRIBUTOR()
    {
      super(paramCMConstants);
    }
  }

  public class SQLPERFORMANCEMONITOR extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "sqlperformancemonitor";
    public static final String NAME_SPACE = "";
    public static final String SQLPERFORMANCEMONITOR_VALUE = "sqlperformancemonitor_value";

    public SQLPERFORMANCEMONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class SQLJOBSTEP extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "sqljobstep";
    public static final String NAME_SPACE = "";
    public static final String SQLJOBSTEP_MESSAGE = "sqljobstep_message";
    public static final String SQLJOBSTEP_RUNSTATUS = "sqljobstep_runstatus";
    public static final String SQLJOBSTEP_RUNTIME = "sqljobstep_runtime";
    public static final String SQLJOBSTEP_INSTANCEID = "sqljobstep_instanceid";
    public static final String SQLJOBSTEP_JOBID = "sqljobstep_jobid";
    public static final String SQLJOBSTEP_RUNDURATION = "sqljobstep_runduration";
    public static final String SQLJOBSTEP_STEPID = "sqljobstep_stepid";

    public SQLJOBSTEP()
    {
      super(paramCMConstants);
    }
  }

  public class SQLJOB extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "sqljob";
    public static final String NAME_SPACE = "";
    public static final String SQLJOB_ENABLED = "sqljob_enabled";
    public static final String SQLJOB_JOBID = "sqljob_jobid";

    public SQLJOB()
    {
      super(paramCMConstants);
    }
  }

  public class SQLFILE extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "sqlfile";
    public static final String NAME_SPACE = "";
    public static final String SQLFILE_PATH = "sqlfile_path";
    public static final String SQLFILE_SIZE = "sqlfile_size";
    public static final String SQLFILE_GROWTH = "sqlfile_growth";
    public static final String SQLFILE_MAXSIZE = "sqlfile_maxsize";

    public SQLFILE()
    {
      super(paramCMConstants);
    }
  }

  public class SQLDATABASE extends CMConstants.DATABASE_INSTANCE
  {
    public static final String CLASS_NAME = "sqldatabase";
    public static final String NAME_SPACE = "";

    public SQLDATABASE()
    {
      super(paramCMConstants);
    }
  }

  public class SQLBACKUP extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "sqlbackup";
    public static final String NAME_SPACE = "";
    public static final String SQLBACKUP_USERNAME = "sqlbackup_username";
    public static final String SQLBACKUP_DURATIONINDAYS = "sqlbackup_durationindays";
    public static final String SQLBACKUP_FINISHDATE = "sqlbackup_finishdate";
    public static final String SQLBACKUP_STARTDATE = "sqlbackup_startdate";
    public static final String SQLBACKUP_CREATIONDATE = "sqlbackup_creationdate";

    public SQLBACKUP()
    {
      super(paramCMConstants);
    }
  }

  public class SQLALERT extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "sqlalert";
    public static final String NAME_SPACE = "";
    public static final String SQLALERT_DATABASENAME = "sqlalert_databasename";
    public static final String SQLALERT_SEVERITY = "sqlalert_severity";
    public static final String SQLALERT_ALERTID = "sqlalert_alertid";

    public SQLALERT()
    {
      super(paramCMConstants);
    }
  }

  public class ORACLE_SCHEMA extends CMConstants.DATABASE_INSTANCE
  {
    public static final String CLASS_NAME = "oracle_schema";
    public static final String NAME_SPACE = "";

    public ORACLE_SCHEMA()
    {
      super(paramCMConstants);
    }
  }

  public class DB_REDOFILEGROUP extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "db_redofilegroup";
    public static final String NAME_SPACE = "";

    public DB_REDOFILEGROUP()
    {
      super(paramCMConstants);
    }
  }

  public class DB_REDOFILE extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "db_redofile";
    public static final String NAME_SPACE = "";
    public static final String DB_REDOFILE_MEMBERS = "db_redofile_members";
    public static final String DB_REDOFILE_GROUP = "db_redofile_group";
    public static final String DB_REDOFILE_STATUS = "db_redofile_status";
    public static final String DB_REDOFILE_SIZE = "db_redofile_size";

    public DB_REDOFILE()
    {
      super(paramCMConstants);
    }
  }

  public class DB_CONTROLFILE extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "db_controlfile";
    public static final String NAME_SPACE = "";
    public static final String DB_CONTROLFILE_STATUS = "db_controlfile_status";

    public DB_CONTROLFILE()
    {
      super(paramCMConstants);
    }
  }

  public class DB_ARCHIVEFILE extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "db_archivefile";
    public static final String NAME_SPACE = "";
    public static final String DB_ARCHIVEFILE_LOGMODE = "db_archivefile_logmode";
    public static final String DB_ARCHIVEFILE_FORMAT = "db_archivefile_format";

    public DB_ARCHIVEFILE()
    {
      super(paramCMConstants);
    }
  }

  public class DBUSER extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbuser";
    public static final String NAME_SPACE = "";
    public static final String DBUSER_CREATED = "dbuser_created";
    public static final String DBUSER_ACCOUNTSTATUS = "dbuser_accountstatus";
    public static final String DBUSER_DEFAULTTABLESPACE = "dbuser_defaulttablespace";
    public static final String DBUSER_TEMPORARYTABLESPACE = "dbuser_temporarytablespace";

    public DBUSER()
    {
      super(paramCMConstants);
    }
  }

  public class DBTNS extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbtns";
    public static final String NAME_SPACE = "";
    public static final String DBTNS_DEFAULTDOMAIN = "dbtns_defaultdomain";
    public static final String DBTNS_SHORTNAME = "dbtns_shortname";
    public static final String DBTNS_REMOTEDBNAME = "dbtns_remotedbname";
    public static final String DBTNS_HOST = "dbtns_host";

    public DBTNS()
    {
      super(paramCMConstants);
    }
  }

  public class DBTABLESPACE extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbtablespace";
    public static final String NAME_SPACE = "";
    public static final String DBTABLESPACE_CONTENTS = "dbtablespace_contents";
    public static final String DBTABLESPACE_EXTENTMANAGEMENT = "dbtablespace_extentmanagement";
    public static final String DBTABLESPACE_SEGMENTSPACEMANAGEMENT = "dbtablespace_segmentspacemanagement";
    public static final String DBTABLESPACE_NEXTEXTENT = "dbtablespace_nextextent";
    public static final String DBTABLESPACE_MINEXTLEN = "dbtablespace_minextlen";
    public static final String DBTABLESPACE_STATUS = "dbtablespace_status";
    public static final String DBTABLESPACE_INITIALEXTENT = "dbtablespace_initialextent";
    public static final String DBTABLESPACE_MAXEXTENTS = "dbtablespace_maxextents";
    public static final String DBTABLESPACE_MINEXTENTS = "dbtablespace_minextents";

    public DBTABLESPACE()
    {
      super(paramCMConstants);
    }
  }

  public class DBTABLE extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbtable";
    public static final String NAME_SPACE = "";
    public static final String DBTABLE_OWNER = "dbtable_owner";
    public static final String DBTABLE_TABLESPACENAME = "dbtable_tablespacename";

    public DBTABLE()
    {
      super(paramCMConstants);
    }
  }

  public class DBSNAPSHOT extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbsnapshot";
    public static final String NAME_SPACE = "";
    public static final String DBSNAPSHOT_TABLENAME = "dbsnapshot_tablename";
    public static final String DBSNAPSHOT_OWNER = "dbsnapshot_owner";
    public static final String DBSNAPSHOT_DBLINKNAME = "dbsnapshot_dblinkname";
    public static final String DBSNAPSHOT_DBLINKTABLENAME = "dbsnapshot_dblinktablename";

    public DBSNAPSHOT()
    {
      super(paramCMConstants);
    }
  }

  public class DBSEGMENT extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbsegment";
    public static final String NAME_SPACE = "";
    public static final String DBSEGMENT_OWNER = "dbsegment_owner";
    public static final String DBSEGMENT_BYTE = "dbsegment_byte";
    public static final String DBSEGMENT_TABLESPACENAME = "dbsegment_tablespacename";
    public static final String DBSEGMENT_SEGMENTTYPE = "dbsegment_segmenttype";

    public DBSEGMENT()
    {
      super(paramCMConstants);
    }
  }

  public class DBSCHEDULERJOB extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbschedulerjob";
    public static final String NAME_SPACE = "";
    public static final String SCHEDULERJOB_OWNER = "schedulerjob_owner";
    public static final String SCHEDULERJOB_JOBNAME = "schedulerjob_jobname";
    public static final String SCHEDULERJOB_ENABLED = "schedulerjob_enabled";
    public static final String SCHEDULERJOB_JOBTYPE = "schedulerjob_jobtype";
    public static final String SCHEDULERJOB_PROGRAMNAME = "schedulerjob_programname";
    public static final String SCHEDULERJOB_JOBACTION = "schedulerjob_jobaction";
    public static final String SCHEDULERJOB_SCHEDULETYPE = "schedulerjob_scheduletype";
    public static final String SCHEDULERJOB_SCHEDULENAME = "schedulerjob_schedulename";
    public static final String SCHEDULERJOB_REPEATINTERVAL = "schedulerjob_repeatinterval";
    public static final String SCHEDULERJOB_JOBCLASS = "schedulerjob_jobclass";

    public DBSCHEDULERJOB()
    {
      super(paramCMConstants);
    }
  }

  public class DBLINKOBJ extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dblinkobj";
    public static final String NAME_SPACE = "";
    public static final String DBLINKOBJ_OWNER = "dblinkobj_owner";
    public static final String DBLINKOBJ_HOST = "dblinkobj_host";
    public static final String DBLINKOBJ_CREATED = "dblinkobj_created";

    public DBLINKOBJ()
    {
      super(paramCMConstants);
    }
  }

  public class DBJOB extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbjob";
    public static final String NAME_SPACE = "";
    public static final String DBJOB_JOBID = "dbjob_jobid";
    public static final String DBJOB_LASTDATE = "dbjob_lastdate";
    public static final String DBJOB_INTERVAL = "dbjob_interval";
    public static final String DBJOB_NEXTDATE = "dbjob_nextdate";
    public static final String DBJOB_THISDATE = "dbjob_thisdate";
    public static final String DBJOB_BROKEN = "dbjob_broken";
    public static final String DBJOB_FAILURES = "dbjob_failures";
    public static final String DBJOB_WHAT = "dbjob_what";
    public static final String DBJOB_OWNER = "dbjob_owner";

    public DBJOB()
    {
      super(paramCMConstants);
    }
  }

  public class DBINDEX extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbindex";
    public static final String NAME_SPACE = "";
    public static final String DBINDEX_INDEXTYPE = "dbindex_indextype";
    public static final String DBINDEX_TABLENAME = "dbindex_tablename";
    public static final String DBINDEX_TABLEOWNER = "dbindex_tableowner";
    public static final String DBINDEX_TABLESPACENAME = "dbindex_tablespacename";
    public static final String DBINDEX_OWNER = "dbindex_owner";

    public DBINDEX()
    {
      super(paramCMConstants);
    }
  }

  public class DBEXTENT extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbextent";
    public static final String NAME_SPACE = "";
    public static final String DBEXTENT_FILEID = "dbextent_fileid";
    public static final String DBEXTENT_SEGMENTTYPE = "dbextent_segmenttype";
    public static final String DBEXTENT_OWNER = "dbextent_owner";
    public static final String DBEXTENT_SEGMENTNAME = "dbextent_segmentname";
    public static final String DBEXTENT_EXTENTID = "dbextent_extentid";
    public static final String DBEXTENT_TABLESPACENAME = "dbextent_tablespacename";
    public static final String DBEXTENT_BYTE = "dbextent_byte";

    public DBEXTENT()
    {
      super(paramCMConstants);
    }
  }

  public class DBDATAFILE extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbdatafile";
    public static final String NAME_SPACE = "";
    public static final String DBDATAFILE_ERRORS = "dbdatafile_errors";
    public static final String DBDATAFILE_STATUS = "dbdatafile_status";
    public static final String DBDATAFILE_FILEID = "dbdatafile_fileid";
    public static final String DBDATAFILE_BYTE = "dbdatafile_byte";
    public static final String DBDATAFILE_TABLESPACENAME = "dbdatafile_tablespacename";
    public static final String DBDATAFILE_BACKUPSTATUS = "dbdatafile_backupstatus";
    public static final String DBDATAFILE_MAXBYTES = "dbdatafile_maxbytes";
    public static final String DBDATAFILE_AUTOEXTENSIBLE = "dbdatafile_autoextensible";
    public static final String DBDATAFILE_INCREMENTBY = "dbdatafile_incrementby";

    public DBDATAFILE()
    {
      super(paramCMConstants);
    }
  }

  public class DBAOBJECTS extends CMConstants.DATABASERESOURCE
  {
    public static final String CLASS_NAME = "dbaobjects";
    public static final String NAME_SPACE = "";
    public static final String DBAOBJECTS_TYPE = "dbaobjects_type";
    public static final String DBAOBJECTS_TIMESTAMP = "dbaobjects_timestamp";
    public static final String DBAOBJECTS_OWNER = "dbaobjects_owner";
    public static final String DBAOBJECTS_STATUS = "dbaobjects_status";
    public static final String DBAOBJECTS_LASTDDLTIME = "dbaobjects_lastddltime";
    public static final String DBAOBJECTS_CREATED = "dbaobjects_created";

    public DBAOBJECTS()
    {
      super(paramCMConstants);
    }
  }

  public class DB2_SCHEMA extends CMConstants.DATABASE_INSTANCE
  {
    public static final String CLASS_NAME = "db2_schema";
    public static final String NAME_SPACE = "";

    public DB2_SCHEMA()
    {
      super(paramCMConstants);
    }
  }

  public class CORRELATION_RULE extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "correlationRule";
    public static final String NAME_SPACE = "";
    public static final String RULENAME = "ruleName";
    public static final String TQLNAME = "tqlName";
    public static final String ISACTIVE = "isActive";
    public static final String RULEDATA = "ruleData";

    public CORRELATION_RULE()
    {
      super(paramCMConstants);
    }
  }

  public class PROTOCOL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "protocol";
    public static final String NAME_SPACE = "";
    public static final String PROTOCOL_PASSWORD = "protocol_password";
    public static final String PROTOCOL_NETADDRESS = "protocol_netaddress";
    public static final String PROTOCOL_TIMEOUT = "protocol_timeout";
    public static final String PROTOCOL_INDEX = "protocol_index";
    public static final String PROTOCOL_PORT = "protocol_port";
    public static final String PROTOCOL_NOTE = "protocol_note";
    public static final String PROTOCOL_USERNAME = "protocol_username";

    public PROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class DOMAIN extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "domain";
    public static final String NAME_SPACE = "";
    public static final String DOMAIN_SCOPELIST = "domain_scopelist";
    public static final String DOMAIN_ISACTIVE = "domain_isactive";
    public static final String DOMAIN_DESCRIPTION = "domain_description";
    public static final String DOMAIN_TYPE = "domain_type";

    public DOMAIN()
    {
      super(paramCMConstants);
    }
  }

  public class DISCOVERYWIZARD extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "discoverywizard";
    public static final String NAME_SPACE = "";
    public static final String IS_ACTIVE = "is_active";
    public static final String TITLE = "title";
    public static final String DESCRIPTION = "description";
    public static final String WIZARD_ICON = "wizard_icon";
    public static final String RESOURCE_BOUNDLE = "resource_boundle";
    public static final String STEPS = "steps";
    public static final String ACTIVEJOBS = "activeJobs";
    public static final String WIZARD_INDEX = "wizard_index";

    public DISCOVERYWIZARD()
    {
      super(paramCMConstants);
    }
  }

  public class DISCOVERYTQL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "discoverytql";
    public static final String NAME_SPACE = "";
    public static final String DISCOVERYTQL_DESCRIPTION = "discoverytql_description";
    public static final String DISCOVERYTQL_OUTPUTCLASS = "discoverytql_outputclass";

    public DISCOVERYTQL()
    {
      super(paramCMConstants);
    }
  }

  public class DISCOVERYRESOURCE extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "discoveryresource";
    public static final String NAME_SPACE = "";
    public static final String PACKAGE_NAME = "package_name";
    public static final String SUBSYSTEM = "subsystem";
    public static final String EXT = "ext";
    public static final String PATH = "path";
    public static final String CONTENT = "content";
    public static final String ISMODIFIED = "isModified";
    public static final String RESOURCE_SIZE = "resource_size";

    public DISCOVERYRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class DISCOVERYPROBEMANAGER extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "discoveryprobemanager";
    public static final String NAME_SPACE = "";
    public static final String DISCOVERYPROBEMANAGER_IP = "discoveryprobemanager_ip";
    public static final String DISCOVERYPROBEMANAGER_DOMAIN = "discoveryprobemanager_domain";
    public static final String DISCOVERYPROBEMANAGER_DOMAINNAME = "discoveryprobemanager_domainName";
    public static final String DISCOVERYPROBEMANAGER_PROBENAME = "discoveryprobemanager_probeName";
    public static final String DISCOVERYPROBEMANAGER_RMIPORT = "discoveryprobemanager_rmiport";
    public static final String DISCOVERYPROBEMANAGER_ACTIVE = "discoveryprobemanager_active";
    public static final String DISCOVERYPROBEMANAGER_HTMLPORT = "discoveryprobemanager_htmlport";

    public DISCOVERYPROBEMANAGER()
    {
      super(paramCMConstants);
    }
  }

  public class DISCOVERYPROBEGATEWAY extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "discoveryprobegateway";
    public static final String NAME_SPACE = "";
    public static final String DISCOVERYPROBEGATEWAY_DOMAIN = "discoveryprobegateway_domain";
    public static final String DISCOVERYPROBEGATEWAY_DOMAIN_TYPE = "discoveryprobegateway_domain_type";
    public static final String DISCOVERYPROBEGATEWAY_LASTCHANGE = "discoveryprobegateway_lastchange";
    public static final String DISCOVERYPROBEGATEWAY_IP = "discoveryprobegateway_ip";
    public static final String DISCOVERYPROBEGATEWAY_PORT = "discoveryprobegateway_port";
    public static final String DISCOVERYPROBEGATEWAY_PROTOCOL = "discoveryprobegateway_protocol";
    public static final String DISCOVERYPROBEGATEWAY_HTMLPORT = "discoveryprobegateway_htmlport";
    public static final String DISCOVERYPROBEGATEWAY_HOMEDIR = "discoveryprobegateway_homedir";
    public static final String DISCOVERYPROBEGATEWAY_OS = "discoveryprobegateway_os";
    public static final String DISCOVERYPROBEGATEWAY_VERSION = "discoveryprobegateway_version";
    public static final String DISCOVERYPROBEGATEWAY_BUILD = "discoveryprobegateway_build";
    public static final String DISCOVERYPROBEGATEWAY_LASTTASKS = "discoveryprobegateway_lasttasks";

    public DISCOVERYPROBEGATEWAY()
    {
      super(paramCMConstants);
    }
  }

  public class DISCOVERYPATTERN extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "discoverypattern";
    public static final String NAME_SPACE = "";
    public static final String DISCOVERYPATTERN_PROTOCOLS = "discoverypattern_protocols";
    public static final String DISCOVERYPATTERN_DESCRIPTION = "discoverypattern_description";
    public static final String DISCOVERYPATTERN_ISACTIVE = "discoverypattern_isactive";
    public static final String DISCOVERYPATTERN_ISDELETABLE = "discoverypattern_isdeletable";
    public static final String DISCOVERYPATTERN_DISCOVEREDCLASSES = "discoverypattern_discoveredclasses";
    public static final String DISCOVERYPATTERN_CONFIGFILES = "discoverypattern_configfiles";
    public static final String DISCOVERYPATTERN_SCRIPTS = "discoverypattern_scripts";
    public static final String DISCOVERYPATTERN_PARAMETERS = "discoverypattern_parameters";
    public static final String DISCOVERYPATTERN_INPUTCLASS = "discoverypattern_inputclass";
    public static final String DISCOVERYPATTERN_PATTERNDATA = "discoverypattern_patterndata";
    public static final String DISCOVERYPATTERN_VERSION = "discoverypattern_version";
    public static final String DISCOVERYPATTERN_INPUTTQL = "discoverypattern_inputtql";
    public static final String DISCOVERYPATTERN_PACKAGE = "discoverypattern_package";

    public DISCOVERYPATTERN()
    {
      super(paramCMConstants);
    }
  }

  public class DISCOVERYMODULE extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "discoverymodule";
    public static final String NAME_SPACE = "";
    public static final String DISCOVERYMODULE_JOBS = "discoverymodule_jobs";
    public static final String DISCOVERYMODULE_PATTERNS = "discoverymodule_patterns";
    public static final String DISCOVERYMODULE_DESCRIPTION = "discoverymodule_description";
    public static final String DISCOVERYMODULE_ISOBSELETE = "discoverymodule_isobselete";

    public DISCOVERYMODULE()
    {
      super(paramCMConstants);
    }
  }

  public class DISCOVERYJOB extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "discoveryjob";
    public static final String NAME_SPACE = "";
    public static final String DISCOVERYJOB_DESCRIPTION = "discoveryjob_description";
    public static final String DISCOVERYJOB_ISACTIVE = "discoveryjob_isactive";
    public static final String INVOKEONARRIVAL = "InvokeOnArrival";
    public static final String DISCOVERYJOB_EXECUTION_TEMPLATE = "discoveryjob_execution_template";
    public static final String DISCOVERYJOB_PATTERN = "discoveryjob_pattern";
    public static final String DISCOVERYJOB_SCHEDULING = "discoveryjob_scheduling";
    public static final String DISCOVERYJOB_PACKAGE = "discoveryjob_package";
    public static final String DISCOVERYJOB_PARAMETERS = "discoveryjob_parameters";

    public DISCOVERYJOB()
    {
      super(paramCMConstants);
    }
  }

  public class CMDBCLASS extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "cmdbclass";
    public static final String NAME_SPACE = "";

    public CMDBCLASS()
    {
      super(paramCMConstants);
    }
  }

  public class RAC extends CMConstants.LOADBALANCECLUSTER
  {
    public static final String CLASS_NAME = "rac";
    public static final String NAME_SPACE = "";
    public static final String RAC_SERVICENAME = "rac_servicename";
    public static final String RAC_INSTANCESCOUNT = "rac_instancescount";

    public RAC()
    {
      super(paramCMConstants);
    }
  }

  public class BUSINESS_SERVICE extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "BusinessService";
    public static final String NAME_SPACE = "";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";

    public BUSINESS_SERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class APPLICATIONSYSTEM extends CMConstants.SYSTEM
  {
    public static final String CLASS_NAME = "applicationsystem";
    public static final String NAME_SPACE = "";

    public APPLICATIONSYSTEM()
    {
      super(paramCMConstants);
    }
  }

  public class APPLICATIONRESOURCE extends CMConstants.SYSTEM
  {
    public static final String CLASS_NAME = "applicationresource";
    public static final String NAME_SPACE = "";
    public static final String RESOURCE_PATH = "resource_path";

    public APPLICATIONRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class WEBVIRTUALHOST extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "webvirtualhost";
    public static final String NAME_SPACE = "";
    public static final String SCRIPTALIAS = "scriptalias";
    public static final String DOCUMENTROOT = "documentroot";
    public static final String SERVERNAME = "servername";

    public WEBVIRTUALHOST()
    {
      super(paramCMConstants);
    }
  }

  public class VMWARE_RESOURCE_POOL extends CMConstants.RESOURCE_POOL
  {
    public static final String CLASS_NAME = "vmware_resource_pool";
    public static final String NAME_SPACE = "";
    public static final String CPU_LIMIT = "cpu_limit";
    public static final String CPU_SHARES = "cpu_shares";
    public static final String MEMORY_SHARES = "memory_shares";
    public static final String CPU_EXPANDABLE_RESERVATION = "cpu_expandable_reservation";
    public static final String CPU_SHARES_LEVEL = "cpu_shares_level";
    public static final String RESOURCE_POOL_STATUS = "resource_pool_status";
    public static final String MEMORY_RESERVATION = "memory_reservation";
    public static final String MEMORY_LIMIT = "memory_limit";
    public static final String MEMORY_SHARES_LEVEL = "memory_shares_level";
    public static final String MEMORY_EXPANDABLE_RESERVATION = "memory_expandable_reservation";
    public static final String CPU_RESERVATION = "cpu_reservation";

    public VMWARE_RESOURCE_POOL()
    {
      super(paramCMConstants);
    }
  }

  public class RESOURCE_POOL extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "resource_pool";
    public static final String NAME_SPACE = "";

    public RESOURCE_POOL()
    {
      super(paramCMConstants);
    }
  }

  public class WMIPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "wmiprotocol";
    public static final String NAME_SPACE = "";
    public static final String WMIPROTOCOL_WMIDOMAIN = "wmiprotocol_wmidomain";

    public WMIPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class VMWAREPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "vmwareprotocol";
    public static final String NAME_SPACE = "";
    public static final String VMWAREPROTOCOL_USE_SSL = "vmwareprotocol_use_ssl";

    public VMWAREPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class TELNETPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "telnetprotocol";
    public static final String NAME_SPACE = "";
    public static final String TELNETPROTOCOL_AUTHMODE = "telnetprotocol_authmode";
    public static final String TELNETPROTOCOL_PROMPTS = "telnetprotocol_prompts";
    public static final String TELNETPROTOCOL_RESPONCES = "telnetprotocol_responces";
    public static final String TELNETPROTOCOL_SUDO_PATHS = "telnetprotocol_sudo_paths";
    public static final String TELNETPROTOCOL_SUDO_COMMANDS = "telnetprotocol_sudo_commands";

    public TELNETPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class SSHPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "sshprotocol";
    public static final String NAME_SPACE = "";
    public static final String SSHPROTOCOL_KEYPATH = "sshprotocol_keypath";
    public static final String SSHPROTOCOL_AUTHMODE = "sshprotocol_authmode";
    public static final String SSHPROTOCOL_SHELL_ENV_SEP_CHAR = "sshprotocol_shell_env_sep_char";
    public static final String SSHPROTOCOL_PROMPTS = "sshprotocol_prompts";
    public static final String SSHPROTOCOL_VERSION = "sshprotocol_version";
    public static final String SSHPROTOCOL_RESPONCES = "sshprotocol_responces";
    public static final String SSHPROTOCOL_SUDO_PATHS = "sshprotocol_sudo_paths";
    public static final String SSHPROTOCOL_SUDO_COMMANDS = "sshprotocol_sudo_commands";

    public SSHPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class SQLPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "sqlprotocol";
    public static final String NAME_SPACE = "";
    public static final String SQLPROTOCOL_DBNAME = "sqlprotocol_dbname";
    public static final String SQLPROTOCOL_DBSID = "sqlprotocol_dbsid";
    public static final String SQLPROTOCOL_DBTYPE = "sqlprotocol_dbtype";

    public SQLPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class SNMPPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "snmpprotocol";
    public static final String NAME_SPACE = "";
    public static final String SNMPPROTOCOL_COMMUNITY = "snmpprotocol_community";
    public static final String SNMPPROTOCOL_RETRY = "snmpprotocol_retry";
    public static final String SNMPPROTOCOL_VERSION = "snmpprotocol_version";
    public static final String SNMPPROTOCOL_AUTHMETHOD = "snmpprotocol_authmethod";
    public static final String SNMPPROTOCOL_AUTHALG = "snmpprotocol_authalg";
    public static final String SNMPPROTOCOL_PRIVALG = "snmpprotocol_privalg";
    public static final String SNMPPROTOCOL_PRIVKEY = "snmpprotocol_privkey";

    public SNMPPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class NTADMINPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "ntadminprotocol";
    public static final String NAME_SPACE = "";
    public static final String NTADMINPROTOCOL_NTDOMAIN = "ntadminprotocol_ntdomain";

    public NTADMINPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class LICENSE_RESOURCE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "license_resource";
    public static final String NAME_SPACE = "";

    public LICENSE_RESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class LICENSE_FEATURE extends CMConstants.LICENSE_RESOURCE
  {
    public static final String CLASS_NAME = "license_feature";
    public static final String NAME_SPACE = "";
    public static final String FEATURE_IS_EDITION = "feature_is_edition";
    public static final String LICENSES_TOTAL = "licenses_total";
    public static final String FEATURE_NAME = "feature_name";
    public static final String LICENSE_COST_UNIT = "license_cost_unit";
    public static final String LICENSES_AVAILABLE = "licenses_available";

    public LICENSE_FEATURE()
    {
      super(paramCMConstants);
    }
  }

  public class HTTPCONTEXT extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "httpcontext";
    public static final String NAME_SPACE = "";
    public static final String HTTPCONTEXT_WEBAPPLICATIONHOST = "httpcontext_webapplicationhost";
    public static final String HTTPCONTEXT_WEBAPPLICATIONIP = "httpcontext_webapplicationip";
    public static final String HTTPCONTEXT_WEBAPPLICATIONCONTEXT = "httpcontext_webapplicationcontext";
    public static final String HTTPCONTEXT_WEBAPPLICATIONSERVER = "httpcontext_webapplicationserver";

    public HTTPCONTEXT()
    {
      super(paramCMConstants);
    }
  }

  public class DOCUMENT extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "document";
    public static final String NAME_SPACE = "";
    public static final String MENU = "MENU";
    public static final String DOCUMENT_DATA = "document_data";
    public static final String DOCUMENT_DESCRIPTION = "document_description";
    public static final String DOCUMENT_LASTMODIFIED = "document_lastmodified";
    public static final String DOCUMENT_PERMISSIONS = "document_permissions";
    public static final String DOCUMENT_CHECKSUM = "document_checksum";
    public static final String DOCUMENT_PATH = "document_path";
    public static final String DOCUMENT_SIZE = "document_size";
    public static final String DOCUMENT_EXTENSION = "document_extension";
    public static final String DOCUMENT_OSOWNER = "document_osowner";

    public DOCUMENT()
    {
      super(paramCMConstants);
    }
  }

  public class CONFIGFILE extends CMConstants.DOCUMENT
  {
    public static final String CLASS_NAME = "configfile";
    public static final String NAME_SPACE = "";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";

    public CONFIGFILE()
    {
      super(paramCMConstants);
    }
  }

  public class APPLICATION extends CMConstants.SYSTEM
  {
    public static final String CLASS_NAME = "application";
    public static final String NAME_SPACE = "";
    public static final String APPLICATION_TIMEOUT = "application_timeout";
    public static final String APPLICATION_PORT = "application_port";
    public static final String APPLICATION_PASSWORD = "application_password";
    public static final String APPLICATION_USERNAME = "application_username";
    public static final String APPLICATION_CATEGORY = "application_category";
    public static final String VENDOR = "vendor";
    public static final String APPLICATION_IP = "application_ip";
    public static final String APPLICATION_VERSION = "application_version";
    public static final String APPLICATION_PATH = "application_path";
    public static final String HAS_CONFIG_FILES = "has_config_files";
    public static final String ROOT_CONTAINER_NAME = "root_container_name";

    public APPLICATION()
    {
      super(paramCMConstants);
    }
  }

  public class WEBSERVER extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "webserver";
    public static final String NAME_SPACE = "";
    public static final String WEBSERVER_VERSION = "webserver_version";
    public static final String WEBSERVER_CONFIGFILE = "webserver_configfile";
    public static final String WEBSERVER_TYPE = "webserver_type";

    public WEBSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class SUNONESERVER extends CMConstants.WEBSERVER
  {
    public static final String CLASS_NAME = "sunoneserver";
    public static final String NAME_SPACE = "";

    public SUNONESERVER()
    {
      super(paramCMConstants);
    }
  }

  public class IIS extends CMConstants.WEBSERVER
  {
    public static final String CLASS_NAME = "iis";
    public static final String NAME_SPACE = "";

    public IIS()
    {
      super(paramCMConstants);
    }
  }

  public class IBMHTTPSERVER extends CMConstants.WEBSERVER
  {
    public static final String CLASS_NAME = "ibmhttpserver";
    public static final String NAME_SPACE = "";

    public IBMHTTPSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class APACHE extends CMConstants.WEBSERVER
  {
    public static final String CLASS_NAME = "apache";
    public static final String NAME_SPACE = "";

    public APACHE()
    {
      super(paramCMConstants);
    }
  }

  public class VMWARE_VIRTUAL_CENTER extends CMConstants.VIRTUAL_MANAGEMENT_SOFTWARE
  {
    public static final String CLASS_NAME = "vmware_virtual_center";
    public static final String NAME_SPACE = "";
    public static final String VIRTUALCENTER_STATUS = "virtualcenter_status";

    public VMWARE_VIRTUAL_CENTER()
    {
      super(paramCMConstants);
    }
  }

  public class VIRTUAL_MANAGEMENT_SOFTWARE extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "virtual_management_software";
    public static final String NAME_SPACE = "";
    public static final String CONNECTION_URL = "connection_url";

    public VIRTUAL_MANAGEMENT_SOFTWARE()
    {
      super(paramCMConstants);
    }
  }

  public class SHELL extends CMConstants.AGENT
  {
    public static final String CLASS_NAME = "shell";
    public static final String NAME_SPACE = "";

    public SHELL()
    {
      super(paramCMConstants);
    }
  }

  public class TELNET extends CMConstants.SHELL
  {
    public static final String CLASS_NAME = "telnet";
    public static final String NAME_SPACE = "";
    public static final String TELNET_ADMINUSERNAME = "telnet_adminusername";
    public static final String TELNET_ADMINPASSWORD = "telnet_adminpassword";

    public TELNET()
    {
      super(paramCMConstants);
    }
  }

  public class SSH extends CMConstants.SHELL
  {
    public static final String CLASS_NAME = "ssh";
    public static final String NAME_SPACE = "";
    public static final String SSH_KEYPATH = "ssh_keypath";

    public SSH()
    {
      super(paramCMConstants);
    }
  }

  public class NTCMD extends CMConstants.SHELL
  {
    public static final String CLASS_NAME = "ntcmd";
    public static final String NAME_SPACE = "";

    public NTCMD()
    {
      super(paramCMConstants);
    }
  }

  public class NAMESERVER extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "nameserver";
    public static final String NAME_SPACE = "";

    public NAMESERVER()
    {
      super(paramCMConstants);
    }
  }

  public class DNSSERVER extends CMConstants.NAMESERVER
  {
    public static final String CLASS_NAME = "dnsserver";
    public static final String NAME_SPACE = "";

    public DNSSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class LICENSE_SERVER extends CMConstants.LICENSES_MANAGEMENT_SOFTWARE
  {
    public static final String CLASS_NAME = "license_server";
    public static final String NAME_SPACE = "";

    public LICENSE_SERVER()
    {
      super(paramCMConstants);
    }
  }

  public class LICENSES_MANAGEMENT_SOFTWARE extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "licenses_management_software";
    public static final String NAME_SPACE = "";

    public LICENSES_MANAGEMENT_SOFTWARE()
    {
      super(paramCMConstants);
    }
  }

  public class HYPERVISOR extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "hypervisor";
    public static final String NAME_SPACE = "";
    public static final String CONNECTION_STATE = "connection_state";
    public static final String CONNECTION_URL = "connection_url";
    public static final String HYPERVISOR_NAME = "hypervisor_name";
    public static final String MAINTENANCE_MODE = "maintenance_mode";
    public static final String STATUS = "status";
    public static final String VMOTION_ENABLED = "vmotion_enabled";

    public HYPERVISOR()
    {
      super(paramCMConstants);
    }
  }

  public class VIRTUALIZATION_LAYER extends CMConstants.HYPERVISOR
  {
    public static final String CLASS_NAME = "virtualization_layer";
    public static final String NAME_SPACE = "";

    public VIRTUALIZATION_LAYER()
    {
      super(paramCMConstants);
    }
  }

  public class DATABASE extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "database";
    public static final String NAME_SPACE = "";
    public static final String DATABASE_DBVERSION = "database_dbversion";
    public static final String DATABASE_DBINSTALLPATH = "database_dbinstallpath";
    public static final String DATABASE_DBTYPE = "database_dbtype";
    public static final String DATABASE_DBCONNECTSTRING = "database_dbconnectstring";
    public static final String DATABASE_DBSID = "database_dbsid";
    public static final String DATABASE_DBPORT = "database_dbport";

    public DATABASE()
    {
      super(paramCMConstants);
    }
  }

  public class SYBASE extends CMConstants.DATABASE
  {
    public static final String CLASS_NAME = "sybase";
    public static final String NAME_SPACE = "";

    public SYBASE()
    {
      super(paramCMConstants);
    }
  }

  public class SQLSERVER extends CMConstants.DATABASE
  {
    public static final String CLASS_NAME = "sqlserver";
    public static final String NAME_SPACE = "";

    public SQLSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class ORACLE extends CMConstants.DATABASE
  {
    public static final String CLASS_NAME = "oracle";
    public static final String NAME_SPACE = "";
    public static final String ORACLE_TNSNAMES = "oracle_tnsnames";
    public static final String ORACLE_FILETYPE = "oracle_filetype";
    public static final String ORACLE_INSTANCENUMBER = "oracle_instancenumber";
    public static final String ORACLE_UNDOTABLESPACE = "oracle_undotablespace";

    public ORACLE()
    {
      super(paramCMConstants);
    }
  }

  public class DB2 extends CMConstants.DATABASE
  {
    public static final String CLASS_NAME = "db2";
    public static final String NAME_SPACE = "";

    public DB2()
    {
      super(paramCMConstants);
    }
  }

  public class AGENT extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "agent";
    public static final String NAME_SPACE = "";

    public AGENT()
    {
      super(paramCMConstants);
    }
  }

  public class WMI extends CMConstants.AGENT
  {
    public static final String CLASS_NAME = "wmi";
    public static final String NAME_SPACE = "";
    public static final String WMI_NTDOMAIN = "wmi_ntdomain";

    public WMI()
    {
      super(paramCMConstants);
    }
  }

  public class SNMP extends CMConstants.AGENT
  {
    public static final String CLASS_NAME = "snmp";
    public static final String NAME_SPACE = "";
    public static final String SNMP_DESCRIPTION = "snmp_description";
    public static final String SNMP_SYSNAME = "snmp_sysname";
    public static final String SNMP_RETRY = "snmp_retry";
    public static final String SNMP_COMMUNITY = "snmp_community";
    public static final String SNMP_TIMEOUT = "snmp_timeout";
    public static final String SNMP_OID = "snmp_oid";
    public static final String SNMP_PORT = "snmp_port";
    public static final String SNMP_SUPPORTMULTIOID = "snmp_supportmultioid";

    public SNMP()
    {
      super(paramCMConstants);
    }
  }

  public class VIRTUAL extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "virtual";
    public static final String NAME_SPACE = "";

    public VIRTUAL()
    {
      super(paramCMConstants);
    }
  }

  public class USE extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "use";
    public static final String NAME_SPACE = "";

    public USE()
    {
      super(paramCMConstants);
    }
  }

  public class USB extends CMConstants.USE
  {
    public static final String CLASS_NAME = "usb";
    public static final String NAME_SPACE = "";

    public USB()
    {
      super(paramCMConstants);
    }
  }

  public class UNNUMBERED extends CMConstants.USE
  {
    public static final String CLASS_NAME = "unnumbered";
    public static final String NAME_SPACE = "";

    public UNNUMBERED()
    {
      super(paramCMConstants);
    }
  }

  public class TRAFFIC extends CMConstants.USE
  {
    public static final String CLASS_NAME = "traffic";
    public static final String NAME_SPACE = "";
    public static final String IS_TWO_SIDED = "is_two_sided";
    public static final String TRAFFIC_OCTETS = "traffic_octets";
    public static final String TRAFFIC_PKTS = "traffic_pkts";
    public static final String TRAFFIC_PORTLIST = "traffic_portlist";

    public TRAFFIC()
    {
      super(paramCMConstants);
    }
  }

  public class TCP extends CMConstants.USE
  {
    public static final String CLASS_NAME = "tcp";
    public static final String NAME_SPACE = "";
    public static final String IS_TWO_SIDED = "is_two_sided";
    public static final String TCP_PORTSLIST = "tcp_portslist";
    public static final String TCP_TYPE = "tcp_type";

    public TCP()
    {
      super(paramCMConstants);
    }
  }

  public class TALK extends CMConstants.USE
  {
    public static final String CLASS_NAME = "talk";
    public static final String NAME_SPACE = "";
    public static final String IS_TWO_SIDED = "is_two_sided";

    public TALK()
    {
      super(paramCMConstants);
    }
  }

  public class ROUTE extends CMConstants.USE
  {
    public static final String CLASS_NAME = "route";
    public static final String NAME_SPACE = "";
    public static final String ROUTE_NETADDRESS = "route_netaddress";

    public ROUTE()
    {
      super(paramCMConstants);
    }
  }

  public class PRINT extends CMConstants.USE
  {
    public static final String CLASS_NAME = "print";
    public static final String NAME_SPACE = "";

    public PRINT()
    {
      super(paramCMConstants);
    }
  }

  public class NFS extends CMConstants.USE
  {
    public static final String CLASS_NAME = "nfs";
    public static final String NAME_SPACE = "";

    public NFS()
    {
      super(paramCMConstants);
    }
  }

  public class LAYERTWO extends CMConstants.USE
  {
    public static final String CLASS_NAME = "layertwo";
    public static final String NAME_SPACE = "";

    public LAYERTWO()
    {
      super(paramCMConstants);
    }
  }

  public class DBLINK extends CMConstants.USE
  {
    public static final String CLASS_NAME = "dblink";
    public static final String NAME_SPACE = "";

    public DBLINK()
    {
      super(paramCMConstants);
    }
  }

  public class CLIENTSERVER extends CMConstants.USE
  {
    public static final String CLASS_NAME = "clientserver";
    public static final String NAME_SPACE = "";
    public static final String CLIENTSERVER_COUNT = "clientserver_count";
    public static final String CLIENTSERVER_DESTPORT = "clientserver_destport";
    public static final String CLIENTSERVER_OCTETS = "clientserver_octets";
    public static final String CLIENTSERVER_PKTS = "clientserver_pkts";
    public static final String CLIENTSERVER_TAG = "clientserver_tag";
    public static final String CLIENTSERVER_PROTOCOL = "clientserver_protocol";
    public static final String CLIENTSERVER_TYPE = "clientserver_type";

    public CLIENTSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class BACKBONE extends CMConstants.USE
  {
    public static final String CLASS_NAME = "backbone";
    public static final String NAME_SPACE = "";
    public static final String IS_TWO_SIDED = "is_two_sided";
    public static final String BACKBONE_CLIENTPORT = "backbone_clientport";
    public static final String BACKBONE_SPEED = "backbone_speed";
    public static final String BACKBONE_UTILIZATION = "backbone_utilization";

    public BACKBONE()
    {
      super(paramCMConstants);
    }
  }

  public class TICKETCONTENT extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "ticketcontent";
    public static final String NAME_SPACE = "Mercury";

    public TICKETCONTENT()
    {
      super(paramCMConstants);
    }
  }

  public class SOCKET extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "socket";
    public static final String NAME_SPACE = "";

    public SOCKET()
    {
      super(paramCMConstants);
    }
  }

  public class RUN extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "run";
    public static final String NAME_SPACE = "";

    public RUN()
    {
      super(paramCMConstants);
    }
  }

  public class RESOURCE extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "resource";
    public static final String NAME_SPACE = "";

    public RESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class REPLICATED extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "replicated";
    public static final String NAME_SPACE = "";

    public REPLICATED()
    {
      super(paramCMConstants);
    }
  }

  public class POTENTIALLY_RUN extends CMConstants.RUN
  {
    public static final String CLASS_NAME = "potentially_run";
    public static final String NAME_SPACE = "";
    public static final String IS_OWNER = "is_owner";

    public POTENTIALLY_RUN()
    {
      super(paramCMConstants);
    }
  }

  public class PNNICONNECTION extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "pnniconnection";
    public static final String NAME_SPACE = "";
    public static final String IS_TWO_SIDED = "is_two_sided";

    public PNNICONNECTION()
    {
      super(paramCMConstants);
    }
  }

  public class PARENT extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "parent";
    public static final String NAME_SPACE = "";

    public PARENT()
    {
      super(paramCMConstants);
    }
  }

  public class OWNER extends CMConstants.PARENT
  {
    public static final String CLASS_NAME = "owner";
    public static final String NAME_SPACE = "";

    public OWNER()
    {
      super(paramCMConstants);
    }
  }

  public class MEMBER extends CMConstants.PARENT
  {
    public static final String CLASS_NAME = "member";
    public static final String NAME_SPACE = "";

    public MEMBER()
    {
      super(paramCMConstants);
    }
  }

  public class DEPEND extends CMConstants.PARENT
  {
    public static final String CLASS_NAME = "depend";
    public static final String NAME_SPACE = "";
    public static final String DEPEND_RESPONSETIME = "depend_responsetime";

    public DEPEND()
    {
      super(paramCMConstants);
    }
  }

  public class HSRP extends CMConstants.DEPEND
  {
    public static final String CLASS_NAME = "hsrp";
    public static final String NAME_SPACE = "";
    public static final String HSRP_ISCONFIG = "hsrp_isconfig";
    public static final String HSRP_STATE = "hsrp_state";

    public HSRP()
    {
      super(paramCMConstants);
    }
  }

  public class DBCLIENT extends CMConstants.PARENT
  {
    public static final String CLASS_NAME = "dbclient";
    public static final String NAME_SPACE = "";
    public static final String DBCLIENT_CONNECTIONCOUNT = "dbclient_connectioncount";

    public DBCLIENT()
    {
      super(paramCMConstants);
    }
  }

  public class MANAGE extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "manage";
    public static final String NAME_SPACE = "";

    public MANAGE()
    {
      super(paramCMConstants);
    }
  }

  public class LICENSE_RESERVATION extends CMConstants.USE
  {
    public static final String CLASS_NAME = "license_reservation";
    public static final String NAME_SPACE = "";
    public static final String STATE = "state";
    public static final String RESERVED = "reserved";

    public LICENSE_RESERVATION()
    {
      super(paramCMConstants);
    }
  }

  public class KPI_OF extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "kpi_of";
    public static final String NAME_SPACE = "";

    public KPI_OF()
    {
      super(paramCMConstants);
    }
  }

  public class ELANVLANMAP extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "elanvlanmap";
    public static final String NAME_SPACE = "";

    public ELANVLANMAP()
    {
      super(paramCMConstants);
    }
  }

  public class DEPLOYED extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "deployed";
    public static final String NAME_SPACE = "";

    public DEPLOYED()
    {
      super(paramCMConstants);
    }
  }

  public class DEPENDENCY extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "dependency";
    public static final String NAME_SPACE = "";
    public static final String DEPENDENCY_NAME = "dependency_name";
    public static final String DEPENDENCY_SOURCE = "dependency_source";

    public DEPENDENCY()
    {
      super(paramCMConstants);
    }
  }

  public class CONTAINED extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "contained";
    public static final String NAME_SPACE = "";

    public CONTAINED()
    {
      super(paramCMConstants);
    }
  }

  public class TRIGGERS extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "triggers";
    public static final String NAME_SPACE = "";
    public static final String TRIGGERS_DOMAINLIMIT = "triggers_domainlimit";

    public TRIGGERS()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERNSTATS extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "patternstats";
    public static final String NAME_SPACE = "";
    public static final String PATTERNSTATS_CREATEDCOUNT = "patternstats_createdcount";
    public static final String PATTERNSTATS_UPDATEDCOUNT = "patternstats_updatedcount";
    public static final String PATTERNSTATS_REMOVEDCOUNT = "patternstats_removedcount";
    public static final String PATTERNSTATS_TOTALCOUNT = "patternstats_totalcount";

    public PATTERNSTATS()
    {
      super(paramCMConstants);
    }
  }

  public class MANAGEMENT extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "management";
    public static final String NAME_SPACE = "";

    public MANAGEMENT()
    {
      super(paramCMConstants);
    }
  }

  public class CHASSISVLANMAP extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "chassisvlanmap";
    public static final String NAME_SPACE = "";

    public CHASSISVLANMAP()
    {
      super(paramCMConstants);
    }
  }

  public class CHASSISELANMAP extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "chassiselanmap";
    public static final String NAME_SPACE = "";

    public CHASSISELANMAP()
    {
      super(paramCMConstants);
    }
  }

  public class BUSINESS_UNITLINK extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "business_unitlink";
    public static final String NAME_SPACE = "";
    public static final String CATEGORY = "category";

    public BUSINESS_UNITLINK()
    {
      super(paramCMConstants);
    }
  }

  public class BCASTDOMAIN extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "bcastdomain";
    public static final String NAME_SPACE = "";
    public static final String TAGS = "TAGS";

    public BCASTDOMAIN()
    {
      super(paramCMConstants);
    }
  }

  public class APPLICATION_LINK extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "applicationLink";
    public static final String NAME_SPACE = "";
    public static final String APPLICATIONLINK_VIEWNAME = "applicationLink_viewName";
    public static final String APPLICATIONLINK_APPLICATIONLINKID = "applicationLink_applicationLinkId";

    public APPLICATION_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class RELATIVEIDMASTER extends CMConstants.DOMAINCONTROLLERROLE
  {
    public static final String CLASS_NAME = "relativeidmaster";
    public static final String NAME_SPACE = "";

    public RELATIVEIDMASTER()
    {
      super(paramCMConstants);
    }
  }

  public class PROVIDER_OF extends CMConstants.BUSINESS_LINKS
  {
    public static final String CLASS_NAME = "provider_of";
    public static final String NAME_SPACE = "Mercury";

    public PROVIDER_OF()
    {
      super(paramCMConstants);
    }
  }

  public class IT_PROBLEM extends CMConstants.IT_PROCESS
  {
    public static final String CLASS_NAME = "it_problem";
    public static final String NAME_SPACE = "";
    public static final String PROBLEM_ID = "problem_id";
    public static final String PROBLEM_BRIEF_DESCRIPTION = "problem_brief_description";
    public static final String PROBLEM_STATUS = "problem_status";
    public static final String PROBLEM_EXPECTED_RESOLUTION_DAY = "problem_expected_resolution_day";
    public static final String PROBLEM_CATEGORY = "problem_category";
    public static final String PROBLEM_IMPACT = "problem_impact";
    public static final String PROBLEM_URGENCY = "problem_urgency";
    public static final String PROBLEM_PRIORITY = "problem_priority";
    public static final String PROBLEM_ASSIGNMENT_GROUP = "problem_assignment_group";

    public IT_PROBLEM()
    {
      super(paramCMConstants);
    }
  }

  public class PRIMARYDOMAINCONTROLLERMASTER extends CMConstants.DOMAINCONTROLLERROLE
  {
    public static final String CLASS_NAME = "primarydomaincontrollermaster";
    public static final String NAME_SPACE = "";

    public PRIMARYDOMAINCONTROLLERMASTER()
    {
      super(paramCMConstants);
    }
  }

  public class PLANNED_CHANGE extends CMConstants.IT_CHANGE
  {
    public static final String CLASS_NAME = "planned_change";
    public static final String NAME_SPACE = "";
    public static final String CHANGE_NUMBER = "change_number";
    public static final String CHANGE_BRIEF_DESCRIPTION = "change_brief_description";
    public static final String CHANGE_CATEGORY = "change_category";
    public static final String CHANGE_STATUS = "change_status";
    public static final String CHANGE_APPROVAL_STATUS = "change_approval_status";
    public static final String CHANGE_REASON = "change_reason";
    public static final String CHANGE_PLANNED_START = "change_planned_start";
    public static final String CHANGE_PLANNED_END = "change_planned_end";
    public static final String CHANGE_RISK_ASSESMENT = "change_risk_assesment";
    public static final String CHANGE_IMPACT_ASSESMENT = "change_impact_assesment";
    public static final String CHANGE_URGENCY = "change_urgency";
    public static final String CHANGE_PRIORITY = "change_priority";
    public static final String CREATING_SERVICE_DESK = "creating_service_desk";
    public static final String ACTUAL_START_TIME = "actual_start_time";
    public static final String ACTUAL_END_TIME = "actual_end_time";
    public static final String OPENED_BY = "opened_by";
    public static final String CONTACT_PERSON = "contact_person";

    public PLANNED_CHANGE()
    {
      super(paramCMConstants);
    }
  }

  public class PERSON extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "person";
    public static final String NAME_SPACE = "";
    public static final String MIDDLE_NAME = "middle_name";
    public static final String OFFICE_PHONE = "office_phone";
    public static final String IDENTIFICATION_TYPE = "identification_type";
    public static final String FULL_NAME = "full_name";
    public static final String LAST_NAME = "last_name";
    public static final String EMAIL = "email";
    public static final String MOBILE_PHONE = "mobile_phone";
    public static final String IDENTIFICATION_KEY = "identification_key";
    public static final String PAGER_PHONE = "pager_phone";
    public static final String TITLE = "title";
    public static final String HOME_PHONE = "home_phone";
    public static final String FAX_PHONE = "fax_phone";

    public PERSON()
    {
      super(paramCMConstants);
    }
  }

  public class ORACLEASRESOURCE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "oracleasresource";
    public static final String NAME_SPACE = "";

    public ORACLEASRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class OC4JGROUP extends CMConstants.ORACLEASRESOURCE
  {
    public static final String CLASS_NAME = "oc4jgroup";
    public static final String NAME_SPACE = "";

    public OC4JGROUP()
    {
      super(paramCMConstants);
    }
  }

  public class OC4J extends CMConstants.ORACLEASRESOURCE
  {
    public static final String CLASS_NAME = "oc4j";
    public static final String NAME_SPACE = "";

    public OC4J()
    {
      super(paramCMConstants);
    }
  }

  public class IISRESOURCE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "iisresource";
    public static final String NAME_SPACE = "";

    public IISRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class IISWEBSITE extends CMConstants.IISRESOURCE
  {
    public static final String CLASS_NAME = "iiswebsite";
    public static final String NAME_SPACE = "";
    public static final String PATH = "path";
    public static final String APP_POOL_ID = "app_pool_id";

    public IISWEBSITE()
    {
      super(paramCMConstants);
    }
  }

  public class IISWEBDIR extends CMConstants.IISRESOURCE
  {
    public static final String CLASS_NAME = "iiswebdir";
    public static final String NAME_SPACE = "";
    public static final String APPLICATION_NAME = "application_name";
    public static final String PATH = "path";
    public static final String APP_ROOT = "app_root";

    public IISWEBDIR()
    {
      super(paramCMConstants);
    }
  }

  public class IISVIRTUALDIR extends CMConstants.IISWEBDIR
  {
    public static final String CLASS_NAME = "iisvirtualdir";
    public static final String NAME_SPACE = "";

    public IISVIRTUALDIR()
    {
      super(paramCMConstants);
    }
  }

  public class IISSERVICE extends CMConstants.IISRESOURCE
  {
    public static final String CLASS_NAME = "iisservice";
    public static final String NAME_SPACE = "";

    public IISSERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class IISWEBSERVICE extends CMConstants.IISSERVICE
  {
    public static final String CLASS_NAME = "iiswebservice";
    public static final String NAME_SPACE = "";
    public static final String ALLOW_KEEP_ALIVE = "allow_keep_alive";
    public static final String APP_POOL_ID = "app_pool_id";
    public static final String ANONYMOUS_PASSWORD_SYNC = "anonymous_password_sync";

    public IISWEBSERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class IISSMTPSERVICE extends CMConstants.IISSERVICE
  {
    public static final String CLASS_NAME = "iissmtpservice";
    public static final String NAME_SPACE = "";
    public static final String MAX_CONNECTIONS = "max_connections";

    public IISSMTPSERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class IISFTPSERVICE extends CMConstants.IISSERVICE
  {
    public static final String CLASS_NAME = "iisftpservice";
    public static final String NAME_SPACE = "";
    public static final String MAX_CONNECTIONS = "max_connections";
    public static final String ANONYMOUS_PASSWORD_SYNC = "anonymous_password_sync";

    public IISFTPSERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class IISFTPSITE extends CMConstants.IISRESOURCE
  {
    public static final String CLASS_NAME = "iisftpsite";
    public static final String NAME_SPACE = "";
    public static final String PATH = "path";

    public IISFTPSITE()
    {
      super(paramCMConstants);
    }
  }

  public class IISAPPPOOL extends CMConstants.IISRESOURCE
  {
    public static final String CLASS_NAME = "iisapppool";
    public static final String NAME_SPACE = "";

    public IISAPPPOOL()
    {
      super(paramCMConstants);
    }
  }

  public class NNMPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "nnmprotocol";
    public static final String NAME_SPACE = "";
    public static final String NNMPROTOCOL_UCMDBPROTOCOL = "nnmprotocol_ucmdbprotocol";
    public static final String NNMPROTOCOL_PROTOCOL = "nnmprotocol_protocol";
    public static final String NNMPROTOCOL_UCMDBPASSWORD = "nnmprotocol_ucmdbpassword";
    public static final String NNMPROTOCOL_PASSWORD = "nnmprotocol_password";
    public static final String NNMPROTOCOL_USER = "nnmprotocol_user";
    public static final String NNMPROTOCOL_PORT = "nnmprotocol_port";
    public static final String NNMPROTOCOL_UCMDBUSER = "nnmprotocol_ucmdbuser";
    public static final String NNMPROTOCOL_UCMDBPORT = "nnmprotocol_ucmdbport";

    public NNMPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class MS_EXCHANGE_SERVER extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "ms_exchange_server";
    public static final String NAME_SPACE = "";
    public static final String GUID = "guid";
    public static final String FQDN = "fqdn";
    public static final String EXCHANGE_SERVER_NAME = "exchange_server_name";
    public static final String CREATION_DATE = "creation_date";
    public static final String SITE_NAME = "site_name";
    public static final String MTA_DATA_PATH = "mta_data_path";
    public static final String BUILD_NUMBER = "build_number";
    public static final String IS_MONITORING_ENABLED = "is_monitoring_enabled";
    public static final String LOG_FILE_LIFETYME = "log_file_lifetyme";
    public static final String MESSAGE_TRACKING_ENABLED = "message_tracking_enabled";
    public static final String TYPE = "type";
    public static final String LOG_FILE_PATH = "log_file_path";

    public MS_EXCHANGE_SERVER()
    {
      super(paramCMConstants);
    }
  }

  public class MS_EXCHANGE_ROLE extends CMConstants.MS_EXCHANGE_RESOURCE
  {
    public static final String CLASS_NAME = "ms_exchange_role";
    public static final String NAME_SPACE = "";
    public static final String LDAP_PORT = "ldap_port";

    public MS_EXCHANGE_ROLE()
    {
      super(paramCMConstants);
    }
  }

  public class MS_EXCHANGE_RESOURCE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "ms_exchange_resource";
    public static final String NAME_SPACE = "";

    public MS_EXCHANGE_RESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class MS_EXCHANGE_MESSAGE_QUEUE extends CMConstants.MS_EXCHANGE_RESOURCE
  {
    public static final String CLASS_NAME = "ms_exchange_message_queue";
    public static final String NAME_SPACE = "";
    public static final String VIRTUAL_SERVER_NUMBER = "virtual_server_number";
    public static final String LINK_NAME = "link_name";
    public static final String QUEUE_ID = "queue_id";
    public static final String PROTOCOL = "protocol";
    public static final String GLOBAL_STOP = "global_stop";
    public static final String VIRTUAL_MACHINE_NAME = "virtual_machine_name";
    public static final String LINK_ID = "link_id";
    public static final String SIZE = "size";

    public MS_EXCHANGE_MESSAGE_QUEUE()
    {
      super(paramCMConstants);
    }
  }

  public class MS_EXCHANGE_LINK extends CMConstants.MS_EXCHANGE_RESOURCE
  {
    public static final String CLASS_NAME = "ms_exchange_link";
    public static final String NAME_SPACE = "";
    public static final String STATE_ACTIVE = "state_active";
    public static final String STATE_FROZEN = "state_frozen";
    public static final String PROTOCOL = "protocol";
    public static final String GLOBAL_STOP = "global_stop";
    public static final String VIRTUAL_MACHINE_NAME = "virtual_machine_name";
    public static final String VIRTUAL_SERVER_NAME = "virtual_server_name";
    public static final String HOLD_UNREACHABLE = "hold_unreachable";
    public static final String LINK_ID = "link_id";
    public static final String SIZE = "size";
    public static final String STATE_READY = "state_ready";

    public MS_EXCHANGE_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class MS_EXCHANGE_FOLDER_TREE extends CMConstants.MS_EXCHANGE_RESOURCE
  {
    public static final String CLASS_NAME = "ms_exchange_folder_tree";
    public static final String NAME_SPACE = "";
    public static final String ROOT_FOLDER_URL = "root_folder_url";
    public static final String GUID = "guid";
    public static final String ADMINISTRATIVE_NOTE = "administrative_note";
    public static final String CREATION_TIME = "creation_time";

    public MS_EXCHANGE_FOLDER_TREE()
    {
      super(paramCMConstants);
    }
  }

  public class MS_EXCHANGE_FOLDER extends CMConstants.MS_EXCHANGE_RESOURCE
  {
    public static final String CLASS_NAME = "ms_exchange_folder";
    public static final String NAME_SPACE = "";
    public static final String CONTACT_COUNT = "contact_count";
    public static final String IS_MAIL_ENABLED = "is_mail_enabled";
    public static final String ADMINISTRATIVE_NOTE = "administrative_note";
    public static final String FRIENDLY_URL = "friendly_url";
    public static final String URL = "url";
    public static final String ADDRESS_BOOK_NAME = "address_book_name";

    public MS_EXCHANGE_FOLDER()
    {
      super(paramCMConstants);
    }
  }

  public class MSCSRESOURCE extends CMConstants.CLUSTERRESOURCE
  {
    public static final String CLASS_NAME = "mscsresource";
    public static final String NAME_SPACE = "";
    public static final String DEBUGPREFIX = "debugPrefix";
    public static final String SEPARATEMONITOR = "separateMonitor";
    public static final String PERSISTENTSTATE = "persistentState";
    public static final String LOOKSALIVEPOLLINTERVAL = "looksAlivePollInterval";
    public static final String ISALIVEPOLLINTERVAL = "isAlivePollInterval";
    public static final String RESTARTACTION = "restartAction";
    public static final String RESTARTTHRESHOLD = "restartThreshold";
    public static final String RESTARTPERIOD = "restartPeriod";
    public static final String PENDINGTIMEOUT = "pendingTimeout";
    public static final String RETRYPERIODONFAILURE = "retryPeriodonFailure";

    public MSCSRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class MSCSGROUP extends CMConstants.CLUSTERGROUP
  {
    public static final String CLASS_NAME = "mscsgroup";
    public static final String NAME_SPACE = "";
    public static final String PERSISTENTSTATE = "persistentstate";
    public static final String FAILOVERTHRESHOLD = "failoverthreshold";
    public static final String FAILOVERPERIOD = "failoverperiod";
    public static final String AUTOFAILBACKTYPE = "autofailbacktype";

    public MSCSGROUP()
    {
      super(paramCMConstants);
    }
  }

  public class MSCLUSTER extends CMConstants.FAILOVERCLUSTER
  {
    public static final String CLASS_NAME = "mscluster";
    public static final String NAME_SPACE = "";
    public static final String DEFAULTNETWORKROLE = "defaultNetworkRole";
    public static final String ENABLEEVENTLOGREPLICATION = "enableEventLogReplication";
    public static final String ENABLERESOURCEDLLDEADLOCKDETECTION = "enableResourceDllDeadlockDetection";
    public static final String QUORUMARBITRATIONTIMEMIN = "quorumArbitrationTimeMin";
    public static final String RESOURCEDLLDEADLOCKTHRESHOLD = "resourceDllDeadlockThreshold";
    public static final String RESOURCEDLLDEADLOCKTIMEOUT = "resourceDllDeadlockTimeout";
    public static final String HANGRECOVERYACTION = "hangRecoveryAction";
    public static final String CLUSSVCHEARTBEATTIMEOUT = "clusSvcHeartbeatTimeout";
    public static final String QUORUMARBITRATIONTIMEMAX = "quorumArbitrationTimeMax";
    public static final String RESOURCEDLLDEADLOCKPERIOD = "resourceDllDeadlockPeriod";

    public MSCLUSTER()
    {
      super(paramCMConstants);
    }
  }

  public class MESSAGEDRIVENBEAN extends CMConstants.EJB
  {
    public static final String CLASS_NAME = "messagedrivenbean";
    public static final String NAME_SPACE = "";

    public MESSAGEDRIVENBEAN()
    {
      super(paramCMConstants);
    }
  }

  public class LOGICAL_SERVICE extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "logical_service";
    public static final String NAME_SPACE = "Mercury";

    public LOGICAL_SERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class LOGICALVOLUME extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "logicalvolume";
    public static final String NAME_SPACE = "";
    public static final String LOGICALVOLUME_FREE = "logicalvolume_free";
    public static final String LOGICALVOLUME_USED = "logicalvolume_used";
    public static final String LOGICALVOLUME_AVAILABILITY = "logicalvolume_availability";
    public static final String LOGICALVOLUME_SHARENAME = "logicalvolume_sharename";
    public static final String LOGICALVOLUME_SIZE = "logicalvolume_size";
    public static final String LOGICALVOLUME_ID = "logicalvolume_id";
    public static final String LOGICALVOLUME_ACCESSTYPE = "logicalvolume_accesstype";
    public static final String LOGICALVOLUME_DOMAINID = "logicalvolume_domainid";
    public static final String LOGICALVOLUME_STATUS = "logicalvolume_status";
    public static final String LOGICALVOLUME_FSTYPE = "logicalvolume_fstype";
    public static final String LOGICALVOLUME_STORAGECAPABILITIES = "logicalvolume_storagecapabilities";

    public LOGICALVOLUME()
    {
      super(paramCMConstants);
    }
  }

  public class LOADBALANCECLUSTER extends CMConstants.CLUSTER
  {
    public static final String CLASS_NAME = "loadbalancecluster";
    public static final String NAME_SPACE = "";

    public LOADBALANCECLUSTER()
    {
      super(paramCMConstants);
    }
  }

  public class MQRESOLVE extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "mqresolve";
    public static final String NAME_SPACE = "";

    public MQRESOLVE()
    {
      super(paramCMConstants);
    }
  }

  public class MQREPOSITORY extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "mqrepository";
    public static final String NAME_SPACE = "";

    public MQREPOSITORY()
    {
      super(paramCMConstants);
    }
  }

  public class MQMSGLINK extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "mqmsglink";
    public static final String NAME_SPACE = "";

    public MQMSGLINK()
    {
      super(paramCMConstants);
    }
  }

  public class MQMQILINK extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "mqmqilink";
    public static final String NAME_SPACE = "";

    public MQMQILINK()
    {
      super(paramCMConstants);
    }
  }

  public class MQCHANNELOF extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "mqchannelof";
    public static final String NAME_SPACE = "";

    public MQCHANNELOF()
    {
      super(paramCMConstants);
    }
  }

  public class MQALIAS extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "mqalias";
    public static final String NAME_SPACE = "";

    public MQALIAS()
    {
      super(paramCMConstants);
    }
  }

  public class LINE_OF_BUSINESS extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "line_of_business";
    public static final String NAME_SPACE = "Mercury";

    public LINE_OF_BUSINESS()
    {
      super(paramCMConstants);
    }
  }

  public class LB_SOFTWARE extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "lb_software";
    public static final String NAME_SPACE = "";

    public LB_SOFTWARE()
    {
      super(paramCMConstants);
    }
  }

  public class JVM extends CMConstants.J2EEMANAGEDOBJECT
  {
    public static final String CLASS_NAME = "jvm";
    public static final String NAME_SPACE = "";
    public static final String JVM_HEAPSIZE = "jvm_heapsize";
    public static final String JVM_INITIALHEAPSIZE = "jvm_initialheapsize";
    public static final String JVM_MAXIMUMHEAPSIZE = "jvm_maximumheapsize";
    public static final String JVM_VERSION = "jvm_version";
    public static final String JVM_OSVERSION = "jvm_osversion";
    public static final String JVM_OSNAME = "jvm_osname";
    public static final String JVM_HEAPFREE = "jvm_heapfree";
    public static final String JVM_VENDOR = "jvm_vendor";

    public JVM()
    {
      super(paramCMConstants);
    }
  }

  public class JMSSERVER extends CMConstants.JMSRESOURCE
  {
    public static final String CLASS_NAME = "jmsserver";
    public static final String NAME_SPACE = "";
    public static final String JMSSERVER_MESSAGESCURRENT = "jmsserver_messagescurrent";
    public static final String JMSSERVER_MESSAGESRECEIVED = "jmsserver_messagesreceived";
    public static final String JMSSERVER_DESTINATIONSCURRENT = "jmsserver_destinationscurrent";
    public static final String JMSSERVER_SESSIONPOOLSTOTAL = "jmsserver_sessionpoolstotal";
    public static final String JMSSERVER_MESSAGESPENDING = "jmsserver_messagespending";
    public static final String JMSSERVER_MESSAGESMAXIMUM = "jmsserver_messagesmaximum";
    public static final String JMSSERVER_SESSIONPOOLSCURRENT = "jmsserver_sessionpoolscurrent";

    public JMSSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class JMSRESOURCE extends CMConstants.J2EEMANAGEDOBJECT
  {
    public static final String CLASS_NAME = "jmsresource";
    public static final String NAME_SPACE = "";

    public JMSRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class JMSDESTINATION extends CMConstants.JMSRESOURCE
  {
    public static final String CLASS_NAME = "jmsdestination";
    public static final String NAME_SPACE = "";
    public static final String JMSDESTINATION_CONSUMERSCURRENT = "jmsdestination_consumerscurrent";
    public static final String JMSDESTINATION_MESSAGESPENDING = "jmsdestination_messagespending";
    public static final String JMSDESTINATION_MESSAGESRECEIVED = "jmsdestination_messagesreceived";
    public static final String JMSDESTINATION_TYPE = "jmsdestination_type";
    public static final String JMSDESTINATION_MESSAGESCURRENT = "jmsdestination_messagescurrent";
    public static final String JMSDESTINATION_DURABLESUBSCRIBERS = "jmsdestination_durablesubscribers";

    public JMSDESTINATION()
    {
      super(paramCMConstants);
    }
  }

  public class JMSDATASTORE extends CMConstants.JMSRESOURCE
  {
    public static final String CLASS_NAME = "jmsdatastore";
    public static final String NAME_SPACE = "";
    public static final String JMSDATASTORE_POOLNAME = "jmsdatastore_poolname";

    public JMSDATASTORE()
    {
      super(paramCMConstants);
    }
  }

  public class JDBCDATASOURCE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "jdbcdatasource";
    public static final String NAME_SPACE = "";
    public static final String JDBCDATASOURCE_POOLNAME = "jdbcdatasource_poolname";
    public static final String JDBCDATASOURCE_ISTRANSACTION = "jdbcdatasource_istransaction";
    public static final String JDBCDATASOURCE_DATABASENAME = "jdbcdatasource_databasename";
    public static final String JDBCDATASOURCE_DATABASEIP = "jdbcdatasource_databaseip";
    public static final String JDBCDATASOURCE_JNDINAME = "jdbcdatasource_jndiname";
    public static final String JDBCDATASOURCE_OBJECTNAME = "jdbcdatasource_objectname";
    public static final String JDBCDATASOURCE_TESTCONNECTIONSONRELEASE = "jdbcdatasource_testconnectionsonrelease";
    public static final String JDBCDATASOURCE_FAILURESTORECONNECT = "jdbcdatasource_failurestoreconnect";
    public static final String JDBCDATASOURCE_WAITFORCONNECTIONCURRENT = "jdbcdatasource_waitforconnectioncurrent";
    public static final String JDBCDATASOURCE_ACTIVECONNECTIONSCURRENT = "jdbcdatasource_activeconnectionscurrent";
    public static final String JDBCDATASOURCE_INITIALCAPACITY = "jdbcdatasource_initialcapacity";
    public static final String JDBCDATASOURCE_CAPACITYINCREMENT = "jdbcdatasource_capacityincrement";
    public static final String JDBCDATASOURCE_URL = "jdbcdatasource_url";
    public static final String JDBCDATASOURCE_MAXCAPACITY = "jdbcdatasource_maxcapacity";
    public static final String JDBCDATASOURCE_CONNECTIONDELAYTIME = "jdbcdatasource_connectiondelaytime";
    public static final String JDBCDATASOURCE_DRIVERNAME = "jdbcdatasource_drivername";

    public JDBCDATASOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class JBOSSPROTOCOL extends CMConstants.PROTOCOL
  {
    public static final String CLASS_NAME = "jbossprotocol";
    public static final String NAME_SPACE = "";

    public JBOSSPROTOCOL()
    {
      super(paramCMConstants);
    }
  }

  public class JBOSSAS extends CMConstants.J2EESERVER
  {
    public static final String CLASS_NAME = "jbossas";
    public static final String NAME_SPACE = "";

    public JBOSSAS()
    {
      super(paramCMConstants);
    }
  }

  public class J2EESERVER extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "j2eeserver";
    public static final String NAME_SPACE = "";
    public static final String J2EESERVER_FULLNAME = "j2eeserver_fullname";
    public static final String J2EESERVER_PROTOCOL = "j2eeserver_protocol";
    public static final String J2EESERVER_SSLPORT = "j2eeserver_sslport";
    public static final String J2EESERVER_VENDOR = "j2eeserver_vendor";
    public static final String J2EESERVER_VERSION = "j2eeserver_version";
    public static final String J2EESERVER_STARTTIME = "j2eeserver_starttime";
    public static final String J2EESERVER_OBJECTNAME = "j2eeserver_objectname";
    public static final String J2EESERVER_LISTENADRESS = "j2eeserver_listenadress";
    public static final String J2EESERVER_SERVERNAME = "j2eeserver_servername";
    public static final String J2EESERVER_ISADMINSERVER = "j2eeserver_isadminserver";

    public J2EESERVER()
    {
      super(paramCMConstants);
    }
  }

  public class J2EEMODULE extends CMConstants.J2EEDEPLOYEDOBJECT
  {
    public static final String CLASS_NAME = "j2eemodule";
    public static final String NAME_SPACE = "";

    public J2EEMODULE()
    {
      super(paramCMConstants);
    }
  }

  public class J2EEMANAGEDOBJECT extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "j2eemanagedobject";
    public static final String NAME_SPACE = "";
    public static final String J2EEMANAGEDOBJECT_RESERVED1 = "j2eemanagedobject_reserved1";
    public static final String J2EEMANAGEDOBJECT_CONTEXTROOT = "j2eemanagedobject_contextroot";
    public static final String J2EEMANAGEDOBJECT_JNDINAME = "j2eemanagedobject_jndiname";
    public static final String J2EEMANAGEDOBJECT_DATASOURCENAME = "j2eemanagedobject_datasourcename";
    public static final String J2EEMANAGEDOBJECT_OBJECTNAME = "j2eemanagedobject_objectname";

    public J2EEMANAGEDOBJECT()
    {
      super(paramCMConstants);
    }
  }

  public class J2EEDOMAIN extends CMConstants.APPLICATIONSYSTEM
  {
    public static final String CLASS_NAME = "j2eedomain";
    public static final String NAME_SPACE = "";
    public static final String J2EEDOMAIN_ACTIVATIONTIME = "j2eedomain_activationtime";

    public J2EEDOMAIN()
    {
      super(paramCMConstants);
    }
  }

  public class J2EEDEPLOYEDOBJECT extends CMConstants.J2EEMANAGEDOBJECT
  {
    public static final String CLASS_NAME = "j2eedeployedobject";
    public static final String NAME_SPACE = "";
    public static final String J2EEDEPLOYEDOBJECT_SERVERNAME = "j2eedeployedobject_servername";
    public static final String J2EEDEPLOYEDOBJECT_DEPLOYMENTDESCRIPTOR = "j2eedeployedobject_deploymentdescriptor";
    public static final String J2EEDEPLOYEDOBJECT_SERVERIP = "j2eedeployedobject_serverip";
    public static final String J2EEDEPLOYEDOBJECT_REDEPLOYDATE = "j2eedeployedobject_redeploydate";

    public J2EEDEPLOYEDOBJECT()
    {
      super(paramCMConstants);
    }
  }

  public class J2EECLUSTER extends CMConstants.LOADBALANCECLUSTER
  {
    public static final String CLASS_NAME = "j2eecluster";
    public static final String NAME_SPACE = "";
    public static final String J2EECLUSTER_CLUSTERADDRESS = "j2eecluster_clusteraddress";
    public static final String J2EECLUSTER_CLUSTERNAME = "j2eecluster_clustername";
    public static final String J2EECLUSTER_DEFAULTLOADALGORITHM = "j2eecluster_defaultloadalgorithm";
    public static final String J2EECLUSTER_MULTICASTADDRESS = "j2eecluster_multicastaddress";

    public J2EECLUSTER()
    {
      super(paramCMConstants);
    }
  }

  public class J2EEAPPLICATION extends CMConstants.J2EEDEPLOYEDOBJECT
  {
    public static final String CLASS_NAME = "j2eeapplication";
    public static final String NAME_SPACE = "";
    public static final String J2EEAPPLICATION_FULLPATH = "j2eeapplication_fullpath";
    public static final String J2EEAPPLICATION_ISEAR = "j2eeapplication_isear";

    public J2EEAPPLICATION()
    {
      super(paramCMConstants);
    }
  }

  public class INFRASTRUCTUREMASTER extends CMConstants.DOMAINCONTROLLERROLE
  {
    public static final String CLASS_NAME = "infrastructuremaster";
    public static final String NAME_SPACE = "";

    public INFRASTRUCTUREMASTER()
    {
      super(paramCMConstants);
    }
  }

  public class IT_INCIDENT extends CMConstants.IT_PROCESS
  {
    public static final String CLASS_NAME = "it_incident";
    public static final String NAME_SPACE = "";
    public static final String INCIDENT_ID = "incident_id";
    public static final String INCIDENT_BRIEF_DESCRIPTION = "incident_brief_description";
    public static final String INCIDENT_CATEGORY = "incident_category";
    public static final String INCIDENT_SEVERITY = "incident_severity";
    public static final String INCIDENT_OPEN_TIME = "incident_open_time";
    public static final String INCIDENT_UPDATE_TIME = "incident_update_time";
    public static final String INCIDENT_CLOSE_TIME = "incident_close_time";
    public static final String INCIDENT_STATUS = "incident_status";

    public IT_INCIDENT()
    {
      super(paramCMConstants);
    }
  }

  public class GLOBALCATALOGSERVER extends CMConstants.DOMAINCONTROLLERROLE
  {
    public static final String CLASS_NAME = "globalcatalogserver";
    public static final String NAME_SPACE = "";

    public GLOBALCATALOGSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class FCSWITCH extends CMConstants.SWITCH
  {
    public static final String CLASS_NAME = "fcswitch";
    public static final String NAME_SPACE = "";
    public static final String FCSWITCH_CONNECTEDPORTS = "fcswitch_connectedports";
    public static final String FCSWITCH_DOMAINID = "fcswitch_domainid";
    public static final String FCSWITCH_ROLE = "fcswitch_role";
    public static final String FCSWITCH_FREEPORTS = "fcswitch_freeports";
    public static final String FCSWITCH_LASTCONTACTED = "fcswitch_lastcontacted";
    public static final String FCSWITCH_VERSION = "fcswitch_version";
    public static final String FCSWITCH_WWN = "fcswitch_wwn";
    public static final String FCSWITCH_STATUS = "fcswitch_status";
    public static final String FCSWITCH_STATE = "fcswitch_state";
    public static final String FCSWITCH_AVAILABLEPORTS = "fcswitch_availableports";

    public FCSWITCH()
    {
      super(paramCMConstants);
    }
  }

  public class FCPORT extends CMConstants.PORT
  {
    public static final String CLASS_NAME = "fcport";
    public static final String NAME_SPACE = "";
    public static final String FCPORT_WWN = "fcport_wwn";
    public static final String FCPORT_MAXSPEED = "fcport_maxspeed";
    public static final String FCPORT_SCSIPORT = "fcport_scsiport";
    public static final String FCPORT_CONNECTEDTOWWN = "fcport_connectedtowwn";
    public static final String FCPORT_TRUNKEDSTATE = "fcport_trunkedstate";
    public static final String FCPORT_TYPE = "fcport_type";
    public static final String FCPORT_SPEED = "fcport_speed";
    public static final String FCPORT_FIBERTYPE = "fcport_fibertype";
    public static final String FCPORT_PORTID = "fcport_portid";
    public static final String FCPORT_SYMBOLICNAME = "fcport_symbolicname";
    public static final String FCPORT_DOMAINID = "fcport_domainid";
    public static final String FCPORT_STATE = "fcport_state";
    public static final String FCPORT_STATUS = "fcport_status";

    public FCPORT()
    {
      super(paramCMConstants);
    }
  }

  public class FCHBA extends CMConstants.HOSTRESOURCE
  {
    public static final String CLASS_NAME = "fchba";
    public static final String NAME_SPACE = "";
    public static final String FCHBA_FIRMWARE = "fchba_firmware";
    public static final String FCHBA_MODEL = "fchba_model";
    public static final String FCHBA_TYPE = "fchba_type";
    public static final String FCHBA_DRIVERVERSION = "fchba_driverversion";
    public static final String FCHBA_DOMAINID = "fchba_domainid";
    public static final String FCHBA_IP = "fchba_ip";
    public static final String FCHBA_VERSION = "fchba_version";
    public static final String FCHBA_WWN = "fchba_wwn";
    public static final String FCHBA_SERIALNUMBER = "fchba_serialnumber";
    public static final String FCHBA_TARGETPORTWWN = "fchba_targetportwwn";
    public static final String FCHBA_VENDOR = "fchba_vendor";

    public FCHBA()
    {
      super(paramCMConstants);
    }
  }

  public class FCCONNECT extends CMConstants.USE
  {
    public static final String CLASS_NAME = "fcconnect";
    public static final String NAME_SPACE = "";

    public FCCONNECT()
    {
      super(paramCMConstants);
    }
  }

  public class FAILOVERCLUSTERSOFTWARE extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "failoverclustersoftware";
    public static final String NAME_SPACE = "";

    public FAILOVERCLUSTERSOFTWARE()
    {
      super(paramCMConstants);
    }
  }

  public class FAILOVERCLUSTER extends CMConstants.CLUSTER
  {
    public static final String CLASS_NAME = "failovercluster";
    public static final String NAME_SPACE = "";

    public FAILOVERCLUSTER()
    {
      super(paramCMConstants);
    }
  }

  public class F5_LTM extends CMConstants.LB_SOFTWARE
  {
    public static final String CLASS_NAME = "f5_ltm";
    public static final String NAME_SPACE = "";

    public F5_LTM()
    {
      super(paramCMConstants);
    }
  }

  public class EXECUTEQUEUE extends CMConstants.J2EEMANAGEDOBJECT
  {
    public static final String CLASS_NAME = "executequeue";
    public static final String NAME_SPACE = "";
    public static final String EXECUTEQUEUE_QUEUELENGTH = "executequeue_queuelength";
    public static final String EXECUTEQUEUE_THREADPRIORITY = "executequeue_threadpriority";
    public static final String EXECUTEQUEUE_THREADCOUNT = "executequeue_threadcount";
    public static final String EXECUTEQUEUE_THREADINCREASE = "executequeue_threadincrease";
    public static final String EXECUTEQUEUE_THREADMAXIMUM = "executequeue_threadmaximum";
    public static final String EXECUTEQUEUE_THREADMINIMUM = "executequeue_threadminimum";

    public EXECUTEQUEUE()
    {
      super(paramCMConstants);
    }
  }

  public class EXCHANGE_ROUTING_GROUP extends CMConstants.EXCHANGE
  {
    public static final String CLASS_NAME = "exchange_routing_group";
    public static final String NAME_SPACE = "";

    public EXCHANGE_ROUTING_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class EXCHANGE_ADMINISTRATIVE_GROUP extends CMConstants.EXCHANGE
  {
    public static final String CLASS_NAME = "exchange_administrative_group";
    public static final String NAME_SPACE = "";

    public EXCHANGE_ADMINISTRATIVE_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class EXCHANGEUNIFIEDMESSAGINGSERVER extends CMConstants.MS_EXCHANGE_ROLE
  {
    public static final String CLASS_NAME = "exchangeunifiedmessagingserver";
    public static final String NAME_SPACE = "";

    public EXCHANGEUNIFIEDMESSAGINGSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class EXCHANGETRANSPORTSERVER extends CMConstants.MS_EXCHANGE_ROLE
  {
    public static final String CLASS_NAME = "exchangetransportserver";
    public static final String NAME_SPACE = "";

    public EXCHANGETRANSPORTSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class EXCHANGESYSTEM extends CMConstants.EXCHANGE
  {
    public static final String CLASS_NAME = "exchangesystem";
    public static final String NAME_SPACE = "";

    public EXCHANGESYSTEM()
    {
      super(paramCMConstants);
    }
  }

  public class EXCHANGEMAILSERVER extends CMConstants.MS_EXCHANGE_ROLE
  {
    public static final String CLASS_NAME = "exchangemailserver";
    public static final String NAME_SPACE = "";

    public EXCHANGEMAILSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class EXCHANGEHUBSERVER extends CMConstants.EXCHANGETRANSPORTSERVER
  {
    public static final String CLASS_NAME = "exchangehubserver";
    public static final String NAME_SPACE = "";

    public EXCHANGEHUBSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class EXCHANGEEDGESERVER extends CMConstants.EXCHANGETRANSPORTSERVER
  {
    public static final String CLASS_NAME = "exchangeedgeserver";
    public static final String NAME_SPACE = "";

    public EXCHANGEEDGESERVER()
    {
      super(paramCMConstants);
    }
  }

  public class EXCHANGECLIENTACCESSSERVER extends CMConstants.MS_EXCHANGE_ROLE
  {
    public static final String CLASS_NAME = "exchangeclientaccessserver";
    public static final String NAME_SPACE = "";

    public EXCHANGECLIENTACCESSSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class EXCHANGE extends CMConstants.APPLICATIONSYSTEM
  {
    public static final String CLASS_NAME = "exchange";
    public static final String NAME_SPACE = "";

    public EXCHANGE()
    {
      super(paramCMConstants);
    }
  }

  public class ENTITYBEAN extends CMConstants.EJB
  {
    public static final String CLASS_NAME = "entitybean";
    public static final String NAME_SPACE = "";

    public ENTITYBEAN()
    {
      super(paramCMConstants);
    }
  }

  public class EJBMODULE extends CMConstants.J2EEMODULE
  {
    public static final String CLASS_NAME = "ejbmodule";
    public static final String NAME_SPACE = "";

    public EJBMODULE()
    {
      super(paramCMConstants);
    }
  }

  public class EJB extends CMConstants.J2EEMANAGEDOBJECT
  {
    public static final String CLASS_NAME = "ejb";
    public static final String NAME_SPACE = "";
    public static final String EJB_BEANSINUSECOUNT = "ejb_beansinusecount";
    public static final String EJB_TIMEOUTTOTALCOUNT = "ejb_timeouttotalcount";
    public static final String EJB_IDLEBEANSCOUNT = "ejb_idlebeanscount";

    public EJB()
    {
      super(paramCMConstants);
    }
  }

  public class DS_ACCESS_DC extends CMConstants.MS_EXCHANGE_RESOURCE
  {
    public static final String CLASS_NAME = "ds_access_dc";
    public static final String NAME_SPACE = "";
    public static final String LDAP_PORT = "ldap_port";
    public static final String DC_TYPE = "dc_type";

    public DS_ACCESS_DC()
    {
      super(paramCMConstants);
    }
  }

  public class DOMAINNAMINGMASTER extends CMConstants.DOMAINCONTROLLERROLE
  {
    public static final String CLASS_NAME = "domainnamingmaster";
    public static final String NAME_SPACE = "";

    public DOMAINNAMINGMASTER()
    {
      super(paramCMConstants);
    }
  }

  public class DOMAINCONTROLLERROLE extends CMConstants.DOMAINCONTROLLERRESOURCE
  {
    public static final String CLASS_NAME = "domaincontrollerrole";
    public static final String NAME_SPACE = "";
    public static final String DOMAINCONTROLLERNAME = "domaincontrollername";

    public DOMAINCONTROLLERROLE()
    {
      super(paramCMConstants);
    }
  }

  public class DOMAINCONTROLLERRESOURCE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "domaincontrollerresource";
    public static final String NAME_SPACE = "";

    public DOMAINCONTROLLERRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class DOMAINCONTROLLER extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "domaincontroller";
    public static final String NAME_SPACE = "";
    public static final String DOMAINNAME = "domainname";
    public static final String SITENAME = "sitename";

    public DOMAINCONTROLLER()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_RESOURCE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "sap_resource";
    public static final String NAME_SPACE = "";

    public SAP_RESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_WORK_PROCESS extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_work_process";
    public static final String NAME_SPACE = "Mercury";
    public static final String TYPE = "type";
    public static final String NUMBER_WP = "number_wp";

    public SAP_WORK_PROCESS()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_TRANSPORT_CHANGE extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_transport_change";
    public static final String NAME_SPACE = "Mercury";
    public static final String OBJECT_TYPE = "object_type";
    public static final String OBJECT_NAME = "object_name";

    public SAP_TRANSPORT_CHANGE()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_TRANSPORT extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_transport";
    public static final String NAME_SPACE = "Mercury";
    public static final String DATE = "date";
    public static final String USER = "user";
    public static final String TARGET_SYSTEM = "target_system";
    public static final String DESCRIPTION = "description";
    public static final String STATUS = "status";

    public SAP_TRANSPORT()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_TRANSACTION extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_transaction";
    public static final String NAME_SPACE = "Mercury";
    public static final String DEVCLASS = "devclass";
    public static final String SYSTEM_NAME = "system_name";
    public static final String PROGRAM = "program";
    public static final String SCREEN = "screen";
    public static final String VERSION = "version";
    public static final String DIALOG_STEPS = "dialog_steps";
    public static final String TOTAL_RESPONSE_TIME = "total_response_time";
    public static final String AVERAGE_RESPONSE_TIME = "average_response_time";
    public static final String TOTAL_CPU_TIME = "total_cpu_time";
    public static final String AVERAGE_CPU_TIME = "average_cpu_time";
    public static final String TOTAL_DB_TIME = "total_db_time";
    public static final String AVERAGE_DB_TIME = "average_db_time";

    public SAP_TRANSACTION()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_PROCESS_STEP extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_process_step";
    public static final String NAME_SPACE = "";
    public static final String LOGICAL_COMPONENT = "logical_component";

    public SAP_PROCESS_STEP()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_J2EE_SERVER_PROCESS extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_j2ee_server_process";
    public static final String NAME_SPACE = "";
    public static final String DISPLAY_NAME = "display_name";
    public static final String VERSION = "version";
    public static final String OBJECT_NAME = "object_name";
    public static final String JAVA_HOME = "java_home";
    public static final String JAVA_VM_PARAMS = "java_vm_params";
    public static final String JAVA_VM_VERSION = "java_vm_version";
    public static final String CLUSTER_ID = "cluster_id";

    public SAP_J2EE_SERVER_PROCESS()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_J2EE_DISPATCHER extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_j2ee_dispatcher";
    public static final String NAME_SPACE = "";
    public static final String DISPLAY_NAME = "display_name";
    public static final String VERSION = "version";
    public static final String OBJECT_NAME = "object_name";
    public static final String JAVA_HOME = "java_home";
    public static final String JAVA_VM_PARAMS = "java_vm_params";
    public static final String JAVA_VM_VERSION = "java_vm_version";
    public static final String CLUSTER_ID = "cluster_id";
    public static final String TAGS = "TAGS";

    public SAP_J2EE_DISPATCHER()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_ITS_WGATE extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_its_wgate";
    public static final String NAME_SPACE = "Mercury";

    public SAP_ITS_WGATE()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_CLIENT extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_client";
    public static final String NAME_SPACE = "";
    public static final String DESCRIPTION = "description";
    public static final String ROLE = "role";

    public SAP_CLIENT()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_BUSINESS_SCENARIO extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_business_scenario";
    public static final String NAME_SPACE = "";

    public SAP_BUSINESS_SCENARIO()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_BUSINESS_PROCESS extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_business_process";
    public static final String NAME_SPACE = "";

    public SAP_BUSINESS_PROCESS()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_BP_PROJECT extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_bp_project";
    public static final String NAME_SPACE = "";
    public static final String RESPONSIBLE = "responsible";

    public SAP_BP_PROJECT()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_APPLICATION_COMPONENT extends CMConstants.SAP_RESOURCE
  {
    public static final String CLASS_NAME = "sap_application_component";
    public static final String NAME_SPACE = "Mercury";
    public static final String SITE = "site";
    public static final String TYPE = "type";
    public static final String SHORT_NAME = "short_name";
    public static final String DESCRIPTION = "description";

    public SAP_APPLICATION_COMPONENT()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_SYSTEM extends CMConstants.APPLICATIONSYSTEM
  {
    public static final String CLASS_NAME = "sap_system";
    public static final String NAME_SPACE = "Mercury";
    public static final String LICENSE_NUMBER = "license_number";
    public static final String LICENSE_EXP_DATE = "license_exp_date";
    public static final String SYSTEM_NUMBER = "system_number";
    public static final String ROUTER = "router";
    public static final String CONNECTION_CLIENT = "connection_client";
    public static final String PASSWORD = "password";
    public static final String USERNAME = "username";
    public static final String IP_ADDRESS = "ip_address";
    public static final String IP_DOMAIN = "ip_domain";

    public SAP_SYSTEM()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_ITS_AGATE extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "sap_its_agate";
    public static final String NAME_SPACE = "Mercury";

    public SAP_ITS_AGATE()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_GATEWAY extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "sap_gateway";
    public static final String NAME_SPACE = "";

    public SAP_GATEWAY()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_APP_SERVER extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "sap_app_server";
    public static final String NAME_SPACE = "";
    public static final String SAP_INSTANCE_PROFILE = "sap_instance_profile";
    public static final String SAP_HOME_DIRECTORY = "sap_home_directory";

    public SAP_APP_SERVER()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_R3_SERVER extends CMConstants.SAP_APP_SERVER
  {
    public static final String CLASS_NAME = "sap_r3_server";
    public static final String NAME_SPACE = "Mercury";
    public static final String VERSION = "version";
    public static final String START_PROFILE = "start_profile";
    public static final String IS_CENTRAL = "is_central";
    public static final String START_DATE = "start_date";
    public static final String NUMBER_PROCESSES = "number_processes";
    public static final String INSTANCE_PROFILE = "instance_profile";
    public static final String RELEASE = "release";
    public static final String MACHINE_TYPE = "machine_type";
    public static final String DB_LIBRARY = "db_library";
    public static final String HOME_DIRECTORY = "home_directory";
    public static final String OS = "os";
    public static final String PATCH_LEVEL = "patch_level";
    public static final String INSTANCE_NUMBER = "instance_number";

    public SAP_R3_SERVER()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_J2EE_APP_SERVER extends CMConstants.SAP_APP_SERVER
  {
    public static final String CLASS_NAME = "sap_j2ee_app_server";
    public static final String NAME_SPACE = "Mercury";

    public SAP_J2EE_APP_SERVER()
    {
      super(paramCMConstants);
    }
  }

  public class J2EE_SAP_CENTRAL_SERVICES extends CMConstants.SAP_APP_SERVER
  {
    public static final String CLASS_NAME = "j2ee_sap_central_services";
    public static final String NAME_SPACE = "Mercury";
    public static final String START_PROFILE = "start_profile";

    public J2EE_SAP_CENTRAL_SERVICES()
    {
      super(paramCMConstants);
    }
  }

  public class ABAP_SAP_CENTRAL_SERVICES extends CMConstants.SAP_APP_SERVER
  {
    public static final String CLASS_NAME = "abap_sap_central_services";
    public static final String NAME_SPACE = "Mercury";
    public static final String START_PROFILE = "start_profile";
    public static final String INSTANCE_NUMBER = "instance_number";

    public ABAP_SAP_CENTRAL_SERVICES()
    {
      super(paramCMConstants);
    }
  }

  public class SAP_RFC_CONNECTION extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "sap_rfc_connection";
    public static final String NAME_SPACE = "";
    public static final String DESCRIPTION = "description";
    public static final String CLIENT = "client";
    public static final String SYSTEM_NUMBER = "system_number";
    public static final String PROGRAM = "program";
    public static final String CONNECTION_TYPE = "connection_type";

    public SAP_RFC_CONNECTION()
    {
      super(paramCMConstants);
    }
  }

  public class CLUSTERRESOURCE extends CMConstants.VIRTUAL_HOST_RESOURCE
  {
    public static final String CLASS_NAME = "clusterresource";
    public static final String NAME_SPACE = "";
    public static final String RESOURCE_PROPERTIES = "resource_properties";
    public static final String TYPE = "type";

    public CLUSTERRESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class CLUSTERGROUP extends CMConstants.VIRTUAL_HOST_RESOURCE
  {
    public static final String CLASS_NAME = "clustergroup";
    public static final String NAME_SPACE = "";

    public CLUSTERGROUP()
    {
      super(paramCMConstants);
    }
  }

  public class CLUSTEREDSERVICE extends CMConstants.HOST_NODE
  {
    public static final String CLASS_NAME = "clusteredservice";
    public static final String NAME_SPACE = "";

    public CLUSTEREDSERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class CLUSTER extends CMConstants.APPLICATIONSYSTEM
  {
    public static final String CLASS_NAME = "cluster";
    public static final String NAME_SPACE = "";
    public static final String INSTANCESCOUNT = "instancescount";
    public static final String VERSION = "version";
    public static final String VENDOR = "vendor";

    public CLUSTER()
    {
      super(paramCMConstants);
    }
  }

  public class CISCO_CSS extends CMConstants.LB_SOFTWARE
  {
    public static final String CLASS_NAME = "cisco_css";
    public static final String NAME_SPACE = "";

    public CISCO_CSS()
    {
      super(paramCMConstants);
    }
  }

  public class BUSINESS_SERVICE_FOR_CATALOG extends CMConstants.LOGICAL_SERVICE
  {
    public static final String CLASS_NAME = "business_service_for_catalog";
    public static final String NAME_SPACE = "Mercury";
    public static final String DISPLAY_NAME = "display_name";
    public static final String PROVIDER = "provider";
    public static final String PROVISION = "provision";

    public BUSINESS_SERVICE_FOR_CATALOG()
    {
      super(paramCMConstants);
    }
  }

  public class BRIDGEHEADSERVER extends CMConstants.DOMAINCONTROLLERROLE
  {
    public static final String CLASS_NAME = "bridgeheadserver";
    public static final String NAME_SPACE = "";

    public BRIDGEHEADSERVER()
    {
      super(paramCMConstants);
    }
  }

  public class MQQUEUEMANAGER extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "mqqueuemanager";
    public static final String NAME_SPACE = "";
    public static final String MQQUEUEMANAGER_CCSID = "mqqueuemanager_ccsid";
    public static final String MQQUEUEMANAGER_LISTENERPORT = "mqqueuemanager_listenerport";
    public static final String MQQUEUEMANAGER_DEFAULTXMITQNAME = "mqqueuemanager_defaultxmitqname";
    public static final String MQQUEUEMANAGER_DESCRIPTION = "mqqueuemanager_description";
    public static final String MQQUEUEMANAGER_STATUS = "mqqueuemanager_status";
    public static final String MQQUEUEMANAGER_DLQNAME = "mqqueuemanager_dlqname";

    public MQQUEUEMANAGER()
    {
      super(paramCMConstants);
    }
  }

  public class MQQUEUE extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "mqqueue";
    public static final String NAME_SPACE = "";
    public static final String MQQUEUE_DESCRIPTION = "mqqueue_description";
    public static final String MQQUEUE_TYPE = "mqqueue_type";

    public MQQUEUE()
    {
      super(paramCMConstants);
    }
  }

  public class MQQUEUELOCAL extends CMConstants.MQQUEUE
  {
    public static final String CLASS_NAME = "mqqueuelocal";
    public static final String NAME_SPACE = "";
    public static final String MQQUEUELOCAL_ISDEADLETTER = "mqqueuelocal_isdeadletter";

    public MQQUEUELOCAL()
    {
      super(paramCMConstants);
    }
  }

  public class MQXMITQ extends CMConstants.MQQUEUELOCAL
  {
    public static final String CLASS_NAME = "mqxmitq";
    public static final String NAME_SPACE = "";
    public static final String MQXMITQ_ISDEFAULT = "mqxmitq_isdefault";

    public MQXMITQ()
    {
      super(paramCMConstants);
    }
  }

  public class MQQUEUEREMOTE extends CMConstants.MQQUEUE
  {
    public static final String CLASS_NAME = "mqqueueremote";
    public static final String NAME_SPACE = "";
    public static final String MQQUEUEREMOTE_RNAME = "mqqueueremote_rname";
    public static final String MQQUEUEREMOTE_XMITQNAME = "mqqueueremote_xmitqname";
    public static final String MQQUEUEREMOTE_RQMNAME = "mqqueueremote_rqmname";

    public MQQUEUEREMOTE()
    {
      super(paramCMConstants);
    }
  }

  public class MQALIASQ extends CMConstants.MQQUEUE
  {
    public static final String CLASS_NAME = "mqaliasq";
    public static final String NAME_SPACE = "";

    public MQALIASQ()
    {
      super(paramCMConstants);
    }
  }

  public class MQCLUSTER extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "mqcluster";
    public static final String NAME_SPACE = "";
    public static final String MQCLUSTER_TEMP = "mqcluster_temp";
    public static final String MQCLUSTER_STATUS = "mqcluster_status";

    public MQCLUSTER()
    {
      super(paramCMConstants);
    }
  }

  public class MQCHANNEL extends CMConstants.APPLICATIONRESOURCE
  {
    public static final String CLASS_NAME = "mqchannel";
    public static final String NAME_SPACE = "";
    public static final String MQCHANNEL_CONNAME = "mqchannel_conname";
    public static final String MQCHANNEL_TRPTYPE = "mqchannel_trptype";
    public static final String MQCHANNEL_DESCRIPTION = "mqchannel_description";
    public static final String MQCHANNEL_CONNIP = "mqchannel_connip";
    public static final String MQCHANNEL_CONNPORT = "mqchannel_connport";

    public MQCHANNEL()
    {
      super(paramCMConstants);
    }
  }

  public class MQMSGCHANNEL extends CMConstants.MQCHANNEL
  {
    public static final String CLASS_NAME = "mqmsgchannel";
    public static final String NAME_SPACE = "";

    public MQMSGCHANNEL()
    {
      super(paramCMConstants);
    }
  }

  public class MQMSGSENDERCHANNEL extends CMConstants.MQMSGCHANNEL
  {
    public static final String CLASS_NAME = "mqmsgsenderchannel";
    public static final String NAME_SPACE = "";

    public MQMSGSENDERCHANNEL()
    {
      super(paramCMConstants);
    }
  }

  public class MQCHSVR extends CMConstants.MQMSGSENDERCHANNEL
  {
    public static final String CLASS_NAME = "mqchsvr";
    public static final String NAME_SPACE = "";

    public MQCHSVR()
    {
      super(paramCMConstants);
    }
  }

  public class MQCHSDR extends CMConstants.MQMSGSENDERCHANNEL
  {
    public static final String CLASS_NAME = "mqchsdr";
    public static final String NAME_SPACE = "";

    public MQCHSDR()
    {
      super(paramCMConstants);
    }
  }

  public class MQCHCLUSSDR extends CMConstants.MQMSGSENDERCHANNEL
  {
    public static final String CLASS_NAME = "mqchclussdr";
    public static final String NAME_SPACE = "";

    public MQCHCLUSSDR()
    {
      super(paramCMConstants);
    }
  }

  public class MQMSGRECEIVERCHANNEL extends CMConstants.MQMSGCHANNEL
  {
    public static final String CLASS_NAME = "mqmsgreceiverchannel";
    public static final String NAME_SPACE = "";

    public MQMSGRECEIVERCHANNEL()
    {
      super(paramCMConstants);
    }
  }

  public class MQCHRQSTR extends CMConstants.MQMSGRECEIVERCHANNEL
  {
    public static final String CLASS_NAME = "mqchrqstr";
    public static final String NAME_SPACE = "";

    public MQCHRQSTR()
    {
      super(paramCMConstants);
    }
  }

  public class MQCHRCVR extends CMConstants.MQMSGRECEIVERCHANNEL
  {
    public static final String CLASS_NAME = "mqchrcvr";
    public static final String NAME_SPACE = "";

    public MQCHRCVR()
    {
      super(paramCMConstants);
    }
  }

  public class MQCHCLUSRCVR extends CMConstants.MQMSGRECEIVERCHANNEL
  {
    public static final String CLASS_NAME = "mqchclusrcvr";
    public static final String NAME_SPACE = "";

    public MQCHCLUSRCVR()
    {
      super(paramCMConstants);
    }
  }

  public class MQMQICHANNEL extends CMConstants.MQCHANNEL
  {
    public static final String CLASS_NAME = "mqmqichannel";
    public static final String NAME_SPACE = "";

    public MQMQICHANNEL()
    {
      super(paramCMConstants);
    }
  }

  public class MQCHSVRCONN extends CMConstants.MQMQICHANNEL
  {
    public static final String CLASS_NAME = "mqchsvrconn";
    public static final String NAME_SPACE = "";

    public MQCHSVRCONN()
    {
      super(paramCMConstants);
    }
  }

  public class MQCHCLNTCONN extends CMConstants.MQMQICHANNEL
  {
    public static final String CLASS_NAME = "mqchclntconn";
    public static final String NAME_SPACE = "";

    public MQCHCLNTCONN()
    {
      super(paramCMConstants);
    }
  }

  public class WEBSPHEREMQ extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "webspheremq";
    public static final String NAME_SPACE = "";

    public WEBSPHEREMQ()
    {
      super(paramCMConstants);
    }
  }

  public class ALTEON_APP_SWITCH extends CMConstants.LB_SOFTWARE
  {
    public static final String CLASS_NAME = "alteon_app_switch";
    public static final String NAME_SPACE = "";

    public ALTEON_APP_SWITCH()
    {
      super(paramCMConstants);
    }
  }

  public class ADAM extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "adam";
    public static final String NAME_SPACE = "";
    public static final String EXCHANGE_SERVER_NAME = "exchange_server_name";
    public static final String ADAM_INSTANCENAME = "adam_instancename";

    public ADAM()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIVEDIRECTORYSYSTEM extends CMConstants.ACTIVEDIRECTORY
  {
    public static final String CLASS_NAME = "activedirectorysystem";
    public static final String NAME_SPACE = "";

    public ACTIVEDIRECTORYSYSTEM()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIVEDIRECTORYSITE extends CMConstants.ACTIVEDIRECTORY
  {
    public static final String CLASS_NAME = "activedirectorysite";
    public static final String NAME_SPACE = "";

    public ACTIVEDIRECTORYSITE()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIVEDIRECTORYFOREST extends CMConstants.ACTIVEDIRECTORY
  {
    public static final String CLASS_NAME = "activedirectoryforest";
    public static final String NAME_SPACE = "";

    public ACTIVEDIRECTORYFOREST()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIVEDIRECTORYDOMAIN extends CMConstants.ACTIVEDIRECTORY
  {
    public static final String CLASS_NAME = "activedirectorydomain";
    public static final String NAME_SPACE = "";

    public ACTIVEDIRECTORYDOMAIN()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIVEDIRECTORY extends CMConstants.APPLICATIONSYSTEM
  {
    public static final String CLASS_NAME = "activedirectory";
    public static final String NAME_SPACE = "";

    public ACTIVEDIRECTORY()
    {
      super(paramCMConstants);
    }
  }

  public class IMPACT_DEPENDENCY extends CMConstants.IMPACT_LINK
  {
    public static final String CLASS_NAME = "impact_dependency";
    public static final String NAME_SPACE = "";

    public IMPACT_DEPENDENCY()
    {
      super(paramCMConstants);
    }
  }

  public class IMPACT_CONTAINMENT extends CMConstants.IMPACT_LINK
  {
    public static final String CLASS_NAME = "impact_containment";
    public static final String NAME_SPACE = "";

    public IMPACT_CONTAINMENT()
    {
      super(paramCMConstants);
    }
  }

  public class DUMMY_RUM_TX_MONITOR extends CMConstants.DUMMY_MONITOR
  {
    public static final String CLASS_NAME = "dummy_rum_tx_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String RUM_TX_MONITOR_ID = "rum_tx_monitor_id";
    public static final String APP_ID = "app_id";

    public DUMMY_RUM_TX_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class DUMMY_RUM_PAGE_MONITOR extends CMConstants.DUMMY_MONITOR
  {
    public static final String CLASS_NAME = "dummy_rum_page_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String RUM_PAGE_MONITOR_ID = "rum_page_monitor_id";
    public static final String APP_ID = "app_id";

    public DUMMY_RUM_PAGE_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class DUMMY_BP_STEP extends CMConstants.DUMMY_MONITOR
  {
    public static final String CLASS_NAME = "dummy_bp_step";
    public static final String NAME_SPACE = "Mercury";
    public static final String BP_STEP_ID = "bp_step_id";
    public static final String BP_GROUP_ID = "bp_group_id";
    public static final String APP_ID = "app_id";

    public DUMMY_BP_STEP()
    {
      super(paramCMConstants);
    }
  }

  public class DUMMY_BP_GROUP extends CMConstants.DUMMY_MONITOR
  {
    public static final String CLASS_NAME = "dummy_bp_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String ID = "id";
    public static final String APP_ID = "app_id";

    public DUMMY_BP_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class DUMMY_BPM_TX_FROM_LOCATION extends CMConstants.DUMMY_MONITOR
  {
    public static final String CLASS_NAME = "dummy_bpm_tx_from_location";
    public static final String NAME_SPACE = "Mercury";
    public static final String SESSION_NAME = "session_name";
    public static final String TX_NAME = "tx_name";
    public static final String LOCATION_NAME = "location_name";

    public DUMMY_BPM_TX_FROM_LOCATION()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_SERVER_MONITOR extends CMConstants.EUM_MONITOR
  {
    public static final String CLASS_NAME = "rum_server_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String SERVER_IP = "server_ip";

    public RUM_SERVER_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_SERVERS extends CMConstants.NODE_FACTORY
  {
    public static final String CLASS_NAME = "rum_servers";
    public static final String NAME_SPACE = "Mercury";

    public RUM_SERVERS()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_LOC_MONITOR extends CMConstants.EUM_MONITOR
  {
    public static final String CLASS_NAME = "rum_loc_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String RUM_COUNTRY = "rum_country";
    public static final String RUM_STATE = "rum_state";
    public static final String RUM_CITY = "rum_city";

    public RUM_LOC_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_LOCATION_CONTAINER extends CMConstants.LOCATION
  {
    public static final String CLASS_NAME = "rum_location_container";
    public static final String NAME_SPACE = "Mercury";
    public static final String RUM_COUNTRY = "rum_country";
    public static final String RUM_STATE = "rum_state";
    public static final String RUM_CITY = "rum_city";

    public RUM_LOCATION_CONTAINER()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_LOCATIONS extends CMConstants.NODE_FACTORY
  {
    public static final String CLASS_NAME = "rum_locations";
    public static final String NAME_SPACE = "Mercury";

    public RUM_LOCATIONS()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_END_USER_GROUP_MONITOR extends CMConstants.EUM_MONITOR
  {
    public static final String CLASS_NAME = "rum_end_user_group_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String START_IP = "start_ip";
    public static final String END_IP = "end_ip";
    public static final String ID = "id";
    public static final String DISPLAY_NAME = "display_name";

    public RUM_END_USER_GROUP_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_END_USER_GROUP_FACTORY extends CMConstants.NODE_FACTORY
  {
    public static final String CLASS_NAME = "rum_end_user_group_factory";
    public static final String NAME_SPACE = "Mercury";
    public static final String IDS = "ids";
    public static final String SHORT_NAME = "short_name";
    public static final String START_IP = "start_ip";
    public static final String END_IP = "end_ip";

    public RUM_END_USER_GROUP_FACTORY()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_END_USER_GROUP_CONTAINER extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "rum_end_user_group_container";
    public static final String NAME_SPACE = "Mercury";
    public static final String ID = "id";
    public static final String DISPLAY_NAME = "display_name";

    public RUM_END_USER_GROUP_CONTAINER()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_END_USER_GROUPS extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "rum_end_user_groups";
    public static final String NAME_SPACE = "Mercury";

    public RUM_END_USER_GROUPS()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_END_USER_GROUP extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "rum_end_user_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String IDS = "ids";
    public static final String SHORT_NAME = "short_name";
    public static final String START_IP = "start_ip";
    public static final String END_IP = "end_ip";

    public RUM_END_USER_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_TX_MONITOR extends CMConstants.EUM_MONITOR
  {
    public static final String CLASS_NAME = "rum_tx_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String RUM_TX_MONITOR_ID = "rum_tx_monitor_id";
    public static final String APP_ID = "app_id";
    public static final String NET_TIME = "net_time";
    public static final String AVAILABILITY = "availability";

    public RUM_TX_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_PAGE_MONITOR extends CMConstants.EUM_MONITOR
  {
    public static final String CLASS_NAME = "rum_page_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String RUM_PAGE_MONITOR_ID = "rum_page_monitor_id";
    public static final String APP_ID = "app_id";
    public static final String DOWNLOAD_TIME = "download_time";
    public static final String AVAILABILITY = "availability";

    public RUM_PAGE_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_INFO_EVENT_MONITOR extends CMConstants.RUM_EVENT_MONITOR
  {
    public static final String CLASS_NAME = "rum_info_event_monitor";
    public static final String NAME_SPACE = "Mercury";

    public RUM_INFO_EVENT_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_INFO_EVENTS extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "rum_info_events";
    public static final String NAME_SPACE = "Mercury";
    public static final String APP_ID = "app_id";

    public RUM_INFO_EVENTS()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_HTTP_ERROR_MONITOR extends CMConstants.RUM_EVENT_MONITOR
  {
    public static final String CLASS_NAME = "rum_http_error_monitor";
    public static final String NAME_SPACE = "Mercury";

    public RUM_HTTP_ERROR_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_EVENT_MONITOR extends CMConstants.EUM_MONITOR
  {
    public static final String CLASS_NAME = "rum_event_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String ID = "id";
    public static final String APP_ID = "app_id";

    public RUM_EVENT_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_ERRORS extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "rum_errors";
    public static final String NAME_SPACE = "Mercury";
    public static final String APP_ID = "app_id";

    public RUM_ERRORS()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_APP_SESSION_MONITOR extends CMConstants.EUM_MONITOR
  {
    public static final String CLASS_NAME = "rum_app_session_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String APP_ID = "app_id";

    public RUM_APP_SESSION_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class RUM_APP_ERROR_MONITOR extends CMConstants.RUM_EVENT_MONITOR
  {
    public static final String CLASS_NAME = "rum_app_error_monitor";
    public static final String NAME_SPACE = "Mercury";

    public RUM_APP_ERROR_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class EUM_GROUP extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "eum_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String ID = "id";

    public EUM_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class EUM_APP_GROUP extends CMConstants.EUM_GROUP
  {
    public static final String CLASS_NAME = "eum_app_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String APP_ID = "app_id";

    public EUM_APP_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class DUMMY_MONITOR extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "dummy_monitor";
    public static final String NAME_SPACE = "Mercury";

    public DUMMY_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class BP_GROUP_LOCATION extends CMConstants.EUM_APP_GROUP
  {
    public static final String CLASS_NAME = "bp_group_location";
    public static final String NAME_SPACE = "Mercury";
    public static final String LOCATION_ID = "location_id";

    public BP_GROUP_LOCATION()
    {
      super(paramCMConstants);
    }
  }

  public class BP_GROUP extends CMConstants.EUM_APP_GROUP
  {
    public static final String CLASS_NAME = "bp_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String IS_DIAGNOSTIC_ENABLED = "is_diagnostic_enabled";
    public static final String IGNORE_OUTLIER_DATA = "ignore_outlier_data";

    public BP_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class BPM_TX_FROM_LOCATION extends CMConstants.EUM_MONITOR
  {
    public static final String CLASS_NAME = "bpm_tx_from_location";
    public static final String NAME_SPACE = "Mercury";
    public static final String TX_ID = "tx_id";
    public static final String LOCATION_ID = "location_id";
    public static final String SESSION_ID = "session_id";
    public static final String TX_NAME = "tx_name";
    public static final String LOCATION_NAME = "location_name";
    public static final String SESSION_NAME = "session_name";
    public static final String DIMENSION_ID = "dimension_id";
    public static final String BAM_NODE_STATUS_KEY = "bam_node_status_key";
    public static final String BASELINE_MODE = "baseline_mode";
    public static final String SCRIPT_ID = "script_id";
    public static final String SCRIPT_NAME = "script_name";
    public static final String RANK_1_FROM = "rank_1_from";
    public static final String RANK_1_TO = "rank_1_to";
    public static final String IS_DIAGNOSTIC_ENABLED = "is_diagnostic_enabled";
    public static final String NO_DATA_TIMEOUT = "no_data_timeout";

    public BPM_TX_FROM_LOCATION()
    {
      super(paramCMConstants);
    }
  }

  public class BMC_APPLICATION extends CMConstants.APPLICATION
  {
    public static final String CLASS_NAME = "bmc_application";
    public static final String NAME_SPACE = "Mercury";

    public BMC_APPLICATION()
    {
      super(paramCMConstants);
    }
  }

  public class HPOV_NODE_FACTORY extends CMConstants.NODE_FACTORY
  {
    public static final String CLASS_NAME = "hpov_node_factory";
    public static final String NAME_SPACE = "Mercury";
    public static final String FULL_MEASUREMENT_NAME = "full_measurement_name";

    public HPOV_NODE_FACTORY()
    {
      super(paramCMConstants);
    }
  }

  public class EMS_TICKET extends CMConstants.SYSTEM_MONITOR
  {
    public static final String CLASS_NAME = "ems_ticket";
    public static final String NAME_SPACE = "Mercury";

    public EMS_TICKET()
    {
      super(paramCMConstants);
    }
  }

  public class EMS_MONITOR extends CMConstants.SYSTEM_MONITOR
  {
    public static final String CLASS_NAME = "ems_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String MONITOR_ID = "monitor_id";
    public static final String MONITOR_ID_NAMESPACE = "monitor_id_namespace";
    public static final String MONITORED_CI_TYPE = "monitored_ci_type";

    public EMS_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class EMS_MEASUREMENT extends CMConstants.SYSTEM_MONITOR
  {
    public static final String CLASS_NAME = "ems_measurement";
    public static final String NAME_SPACE = "Mercury";
    public static final String MEASUREMENT_ID = "measurement_id";

    public EMS_MEASUREMENT()
    {
      super(paramCMConstants);
    }
  }

  public class REMEDY_ASSET extends CMConstants.EMS_MEASUREMENT
  {
    public static final String CLASS_NAME = "remedy_asset";
    public static final String NAME_SPACE = "Mercury";
    public static final String ASSET_ID = "asset_id";
    public static final String SERIAL_NUMBER = "serial_number";
    public static final String STATUS = "status";
    public static final String LOCATION = "location";

    public REMEDY_ASSET()
    {
      super(paramCMConstants);
    }
  }

  public class HPOV_MEASUREMENT extends CMConstants.EMS_MEASUREMENT
  {
    public static final String CLASS_NAME = "hpov_measurement";
    public static final String NAME_SPACE = "Mercury";
    public static final String FULL_MEASUREMENT_NAME = "full_measurement_name";

    public HPOV_MEASUREMENT()
    {
      super(paramCMConstants);
    }
  }

  public class BMC_MEASUREMENT extends CMConstants.EMS_MEASUREMENT
  {
    public static final String CLASS_NAME = "bmc_measurement";
    public static final String NAME_SPACE = "Mercury";
    public static final String AGENT_IP = "agent_ip";
    public static final String APPLICATION_NAME = "application_name";
    public static final String GROUP_NAME = "group_name";

    public BMC_MEASUREMENT()
    {
      super(paramCMConstants);
    }
  }

  public class CUSTOM_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "custom_monitor";
    public static final String NAME_SPACE = "Mercury";

    public CUSTOM_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class HPOV_SERVICE extends CMConstants.LOGICAL_SERVICE
  {
    public static final String CLASS_NAME = "hpov_service";
    public static final String NAME_SPACE = "Mercury";
    public static final String FULL_SERVICE_NAME = "full_service_name";

    public HPOV_SERVICE()
    {
      super(paramCMConstants);
    }
  }

  public class REMEDY_GROUP extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "remedy_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String FULL_NAME = "full_name";

    public REMEDY_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class EMS_GROUP extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "ems_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String GROUP_ID = "group_id";

    public EMS_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class BMC_MEASUREMENT_GROUP extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "bmc_measurement_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String AGENT_IP = "agent_ip";
    public static final String APPLICATION_NAME = "application_name";

    public BMC_MEASUREMENT_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class DIAGNOSTICS_PROBE extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "diagnostics_probe";
    public static final String NAME_SPACE = "Mercury";
    public static final String APP_SERVER_HOST = "app_server_host";
    public static final String PROBE_INSTANCE = "probe_instance";

    public DIAGNOSTICS_PROBE()
    {
      super(paramCMConstants);
    }
  }

  public class DIAGNOSTICS_PROBE_GROUP extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "diagnostics_probe_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String PROBE_GROUP_NAME = "probe_group_name";

    public DIAGNOSTICS_PROBE_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class BPI_VALUE_MONITOR extends CMConstants.BPI_MONITOR
  {
    public static final String CLASS_NAME = "bpi_value_monitor";
    public static final String NAME_SPACE = "";

    public BPI_VALUE_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class BPI_STEP_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "bpi_step_monitor";
    public static final String NAME_SPACE = "";
    public static final String COLLECTION_INTERVAL = "collection_interval";
    public static final String BPI_SERVER_NAME = "bpi_server_name";
    public static final String BPS_CMDB_ID = "bps_cmdb_id";
    public static final String DATA_UNITS = "data_units";

    public BPI_STEP_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class BPI_PROCESS_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "bpi_process_monitor";
    public static final String NAME_SPACE = "";
    public static final String COLLECTION_INTERVAL = "collection_interval";
    public static final String BPI_SERVER_NAME = "bpi_server_name";
    public static final String BP_CMDB_ID = "bp_cmdb_id";
    public static final String DATA_UNITS = "data_units";

    public BPI_PROCESS_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class BPI_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "bpi_monitor";
    public static final String NAME_SPACE = "";
    public static final String BPI_SERVER_NAME = "bpi_server_name";
    public static final String DATA_UNITS = "data_units";
    public static final String COLLECTION_INTERVAL = "collection_interval";
    public static final String THRESHOLD_OPERATOR = "threshold_operator";
    public static final String MAJOR_LIMIT = "major_limit";
    public static final String MINOR_LIMIT = "minor_limit";
    public static final String WARNING_LIMIT = "warning_limit";
    public static final String NORMAL_LIMIT = "normal_limit";

    public BPI_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class BPI_DURATION_MONITOR extends CMConstants.BPI_MONITOR
  {
    public static final String CLASS_NAME = "bpi_duration_monitor";
    public static final String NAME_SPACE = "";

    public BPI_DURATION_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class BPI_CUSTOM_MONITOR extends CMConstants.BPI_MONITOR
  {
    public static final String CLASS_NAME = "bpi_custom_monitor";
    public static final String NAME_SPACE = "";
    public static final String CUSTOM_DATA_UNITS = "custom_data_units";

    public BPI_CUSTOM_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class LOGICAL_OWNER extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "logical_owner";
    public static final String NAME_SPACE = "Mercury";

    public LOGICAL_OWNER()
    {
      super(paramCMConstants);
    }
  }

  public class CONTAINED_GROUP extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "contained_group";
    public static final String NAME_SPACE = "Mercury";

    public CONTAINED_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class CONTAINED_LOCATION extends CMConstants.CONTAINED_GROUP
  {
    public static final String CLASS_NAME = "contained_location";
    public static final String NAME_SPACE = "Mercury";

    public CONTAINED_LOCATION()
    {
      super(paramCMConstants);
    }
  }

  public class LOCATION extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "location";
    public static final String NAME_SPACE = "Mercury";
    public static final String LOCATION_ID = "location_id";

    public LOCATION()
    {
      super(paramCMConstants);
    }
  }

  public class CUSTOMER extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "customer";
    public static final String NAME_SPACE = "Mercury";

    public CUSTOMER()
    {
      super(paramCMConstants);
    }
  }

  public class CUSTOM extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "custom";
    public static final String NAME_SPACE = "Mercury";

    public CUSTOM()
    {
      super(paramCMConstants);
    }
  }

  public class BUSINESS_PROCESS extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "business_process";
    public static final String NAME_SPACE = "";

    public BUSINESS_PROCESS()
    {
      super(paramCMConstants);
    }
  }

  public class BP_STEP extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "bp_step";
    public static final String NAME_SPACE = "Mercury";
    public static final String BP_STEP_ID = "bp_step_id";
    public static final String BP_GROUP_ID = "bp_group_id";
    public static final String APP_ID = "app_id";
    public static final String BUSINESS_PROCESSES_ID = "business_processes_id";
    public static final String IS_DIAGNOSTIC_ENABLED = "is_diagnostic_enabled";

    public BP_STEP()
    {
      super(paramCMConstants);
    }
  }

  public class BPI_STEP extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "bpi_step";
    public static final String NAME_SPACE = "";

    public BPI_STEP()
    {
      super(paramCMConstants);
    }
  }

  public class CUSTOMER_OF extends CMConstants.BUSINESS_LINKS
  {
    public static final String CLASS_NAME = "customer_of";
    public static final String NAME_SPACE = "Mercury";

    public CUSTOMER_OF()
    {
      super(paramCMConstants);
    }
  }

  public class TV_TX_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "tv_tx_monitor";
    public static final String NAME_SPACE = "";
    public static final String THRESHOLD = "threshold";
    public static final String EXCEPTIONRULEDEFINED = "exceptionRuleDefined";
    public static final String VALUERULEDEFINED = "valueRuleDefined";
    public static final String FAILURERULEDEFINED = "failureRuleDefined";
    public static final String UNIT = "unit";
    public static final String TV_ID = "tv_id";
    public static final String COLLECTION_INTERVAL = "collection_interval";
    public static final String AGGREGATION_DELTA = "aggregation_delta";

    public TV_TX_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class BUSINESS_TRANSACTION extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "business_transaction";
    public static final String NAME_SPACE = "Mercury";

    public BUSINESS_TRANSACTION()
    {
      super(paramCMConstants);
    }
  }

  public class NODE_FACTORY extends CMConstants.IT_WORLD
  {
    public static final String CLASS_NAME = "node_factory";
    public static final String NAME_SPACE = "Mercury";
    public static final String DNODE_ID = "dnode_id";
    public static final String ENABLE = "enable";
    public static final String QUOTA = "quota";
    public static final String DNODE_DEFINITION_KEY = "dnode_definition_key";
    public static final String SELECTOR_EXPRESSION = "selector_expression";
    public static final String DNODE_GROUPING_VALUE_MANDATORY = "dnode_grouping_value_mandatory";
    public static final String DNODE_CLEAN_STATUS_KEY = "dnode_clean_status_key";
    public static final String DNODE_CLEAN_STATUS_VALUE = "dnode_clean_status_value";
    public static final String DNODE_CLEAN_TIMESTAMP_KEY = "dnode_clean_timestamp_key";
    public static final String DNODE_CLEAN_COOLING_OFF_PERIOD = "dnode_clean_cooling_off_period";

    public NODE_FACTORY()
    {
      super(paramCMConstants);
    }
  }

  public class DNODE_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "dnode_monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String GROUP_KEY = "group_key";

    public DNODE_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class DNODE_GROUP extends CMConstants.LOGICAL_GROUP
  {
    public static final String CLASS_NAME = "dnode_group";
    public static final String NAME_SPACE = "Mercury";
    public static final String GROUP_KEY = "group_key";

    public DNODE_GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class RECONCILIATION_CONFIGURATION extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "reconciliation_configuration";
    public static final String NAME_SPACE = "";
    public static final String CONFIGURATION = "configuration";

    public RECONCILIATION_CONFIGURATION()
    {
      super(paramCMConstants);
    }
  }

  public class VIEWPROFILE extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "viewprofile";
    public static final String NAME_SPACE = "";
    public static final String TAGS = "TAGS";
    public static final String LABEL = "LABEL";
    public static final String VIEWPROFILE_GETEVETNS = "viewprofile_getevetns";

    public VIEWPROFILE()
    {
      super(paramCMConstants);
    }
  }

  public class ACL_ROLE extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "acl_role";
    public static final String NAME_SPACE = "";
    public static final String NAME = "name";
    public static final String IS_USER = "is_user";
    public static final String DESCRIPTION = "description";
    public static final String RESOURCE_LIST = "resource_list";

    public ACL_ROLE()
    {
      super(paramCMConstants);
    }
  }

  public class ACL_ATTACHMENT extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "acl_attachment";
    public static final String NAME_SPACE = "";

    public ACL_ATTACHMENT()
    {
      super(paramCMConstants);
    }
  }

  public class USER extends CMConstants.ACL_ROLE
  {
    public static final String CLASS_NAME = "user";
    public static final String NAME_SPACE = "";
    public static final String USER_PASSWORD = "user_password";
    public static final String USER_FIRSTNAME = "user_firstname";
    public static final String USER_LASTNAME = "user_lastname";
    public static final String USER_LOCATION = "user_location";
    public static final String USER_DEPARTMENT = "user_department";
    public static final String USER_FILEAS = "user_fileas";
    public static final String USER_WEBPAGEADDRESS = "user_webpageaddress";
    public static final String USER_MOBILE = "user_mobile";
    public static final String USER_COMPANY = "user_company";
    public static final String USER_TELHOME = "user_telhome";
    public static final String USER_FULLNAME = "user_fullname";
    public static final String USER_ADDRESS = "user_address";
    public static final String USER_TELBUSINESS = "user_telbusiness";
    public static final String USER_EMAIL = "user_email";
    public static final String USER_JOBTITLE = "user_jobtitle";
    public static final String USER_BUSINESSFAX = "user_businessfax";
    public static final String USER_PROFILE = "user_profile";

    public USER()
    {
      super(paramCMConstants);
    }
  }

  public class INTEGRATION_USER extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "integration_user";
    public static final String NAME_SPACE = "";
    public static final String NAME = "name";
    public static final String DESCRIPTION = "description";
    public static final String USER_PASSWORD = "user_password";
    public static final String DATASTORE_ORIGIN = "datastore_origin";

    public INTEGRATION_USER()
    {
      super(paramCMConstants);
    }
  }

  public class USERFILTER extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "userfilter";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String USERFILTER_NAME = "userfilter_name";
    public static final String USERFILTER_OWNER = "userfilter_owner";
    public static final String USERFILTER_DESCRIPTION = "userfilter_description";
    public static final String USERFILTER_TYPE = "userfilter_type";

    public USERFILTER()
    {
      super(paramCMConstants);
    }
  }

  public class TRIGGERNODES extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "triggernodes";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String TRIGGERNODES_NODENUMBER = "triggernodes_nodenumber";
    public static final String TRIGGERNODES_CLASSNAME = "triggernodes_classname";

    public TRIGGERNODES()
    {
      super(paramCMConstants);
    }
  }

  public class TRIGGERCONDITION extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "triggercondition";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String TRIGGERCONDITION_LOWLIMIT = "triggercondition_lowlimit";
    public static final String TRIGGERCONDITION_RANGETYPE = "triggercondition_rangetype";
    public static final String TRIGGERCONDITION_DESCRIPTION = "triggercondition_description";
    public static final String TRIGGERCONDITION_HIGHLIMIT = "triggercondition_highlimit";

    public TRIGGERCONDITION()
    {
      super(paramCMConstants);
    }
  }

  public class SCHEDULER_JOB extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "scheduler_job";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String SCHEDULER_JOBNAME = "scheduler_jobname";
    public static final String SCHEDULER_JOBGROUP = "scheduler_jobgroup";
    public static final String SCHEDULER_SCHEDULABLE = "scheduler_schedulable";
    public static final String SCHEDULER_TIME = "scheduler_time";
    public static final String SCHEDULER_ISACTIVE = "scheduler_isactive";

    public SCHEDULER_JOB()
    {
      super(paramCMConstants);
    }
  }

  public class SCHEDULERJOB extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "schedulerjob";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String SCHEDULERJOB_NAME = "schedulerjob_name";
    public static final String SCHEDULERJOB_DATA = "schedulerjob_data";
    public static final String SCHEDULERJOB_UPDATESTATUS = "schedulerjob_updatestatus";

    public SCHEDULERJOB()
    {
      super(paramCMConstants);
    }
  }

  public class RULENAME extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "rulename";
    public static final String NAME_SPACE = "";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";

    public RULENAME()
    {
      super(paramCMConstants);
    }
  }

  public class ABSTRACT_REPORT_DEFINITION extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "AbstractReportDefinition";
    public static final String NAME_SPACE = "";
    public static final String REPORT_NAME = "report_name";
    public static final String REPORT_TYPE = "report_type";
    public static final String REPORT_TQL = "report_tql";
    public static final String REPORT_DESCRIPTION = "report_description";
    public static final String REPORT_DATA = "report_data";

    public ABSTRACT_REPORT_DEFINITION()
    {
      super(paramCMConstants);
    }
  }

  public class REPORTRULE extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "reportrule";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String REPORTRULE_TYPE = "reportrule_type";
    public static final String REPORTRULE_END2 = "reportrule_end2";
    public static final String REPORTRULE_END1 = "reportrule_end1";

    public REPORTRULE()
    {
      super(paramCMConstants);
    }
  }

  public class REPORTNODE extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "reportnode";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String REPORTNODE_PQLNODEID = "reportnode_pqlnodeid";
    public static final String REPORTNODE_LABEL = "reportnode_label";
    public static final String REPORTNODE_ORDER = "reportnode_order";
    public static final String REPORTNODE_MAXROWNUM = "reportnode_maxrownum";
    public static final String REPORTNODE_STARTNEWPAGE = "reportnode_startnewpage";

    public REPORTNODE()
    {
      super(paramCMConstants);
    }
  }

  public class REPORTFUNCTIONPARAM extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "reportfunctionparam";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String REPORTFUNCTIONPARAM_VALUE = "reportfunctionparam_value";
    public static final String REPORTFUNCTIONPARAM_TYPE = "reportfunctionparam_type";
    public static final String REPORTFUNCTIONPARAM_NAME = "reportfunctionparam_name";

    public REPORTFUNCTIONPARAM()
    {
      super(paramCMConstants);
    }
  }

  public class REPORTFUNCTION extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "reportfunction";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String REPORTFUNCTION_NAME = "reportfunction_name";

    public REPORTFUNCTION()
    {
      super(paramCMConstants);
    }
  }

  public class REPORTFUNCPARAMDEF extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "reportfuncparamdef";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String REPORTFUNCPARAMDEF_TYPE = "reportfuncparamdef_type";
    public static final String REPORTFUNCPARAMDEF_ORDER = "reportfuncparamdef_order";
    public static final String REPORTFUNCPARAMDEF_NAME = "reportfuncparamdef_name";

    public REPORTFUNCPARAMDEF()
    {
      super(paramCMConstants);
    }
  }

  public class REPORTFUNCDEF extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "reportfuncdef";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String REPORTFUNCDEF_NAME = "reportfuncdef_name";

    public REPORTFUNCDEF()
    {
      super(paramCMConstants);
    }
  }

  public class REPORTCOLUMN extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "reportcolumn";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String REPORTCOLUMN_SORTDESCEND = "reportcolumn_sortdescend";
    public static final String REPORTCOLUMN_ORDER = "reportcolumn_order";
    public static final String REPORTCOLUMN_TITLE = "reportcolumn_title";
    public static final String REPORTCOLUMN_SORTORDER = "reportcolumn_sortorder";

    public REPORTCOLUMN()
    {
      super(paramCMConstants);
    }
  }

  public class REPORT extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "report";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String REPORT_TITLE = "report_title";
    public static final String REPORT_DESCRIPTION = "report_description";
    public static final String REPORT_HEADER = "report_header";
    public static final String REPORT_NAME = "report_name";
    public static final String REPORT_OWNER = "report_owner";
    public static final String REPORT_SUBTITLE = "report_subtitle";
    public static final String REPORT_PQLNAME = "report_pqlname";
    public static final String REPORT_BUNUMBER = "report_bunumber";
    public static final String REPORT_FOOTER = "report_footer";

    public REPORT()
    {
      super(paramCMConstants);
    }
  }

  public class RAWEVENT extends CMConstants.EVENTBASE
  {
    public static final String CLASS_NAME = "rawevent";
    public static final String NAME_SPACE = "";
    public static final String TAGS = "TAGS";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String RAWEVENT_PARAM = "rawevent_param";
    public static final String RAWEVENT_SUBSYSTEM = "rawevent_subsystem";

    public RAWEVENT()
    {
      super(paramCMConstants);
    }
  }

  public class PROVIDERREPOSITORY extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "providerrepository";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String PROVIDERREPOSITORY_PROVIDER = "providerrepository_provider";

    public PROVIDERREPOSITORY()
    {
      super(paramCMConstants);
    }
  }

  public class PANELINSTRUCTION extends CMConstants.INSTRUCTION
  {
    public static final String CLASS_NAME = "panelinstruction";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String PANELINSTRUCTION_DESCRIPTION = "panelinstruction_description";
    public static final String PANELINSTRUCTION_ISSELECTEDLIST = "panelinstruction_isselectedlist";
    public static final String PANELINSTRUCTION_TITLE = "panelinstruction_title";
    public static final String PANELINSTRUCTION_EDITOR = "panelinstruction_editor";
    public static final String PANELINSTRUCTION_TYPE = "panelinstruction_type";

    public PANELINSTRUCTION()
    {
      super(paramCMConstants);
    }
  }

  public class OUTPUT extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "output";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String OUTPUT_NAME = "output_name";

    public OUTPUT()
    {
      super(paramCMConstants);
    }
  }

  public class JOB extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "job";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String JOB_NAME = "job_name";
    public static final String JOB_DATA = "job_data";

    public JOB()
    {
      super(paramCMConstants);
    }
  }

  public class INTERNALID extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "internalid";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String INTERNALID_ISINTERNAL = "internalid_isinternal";
    public static final String INTERNALID_INTERNALID = "internalid_internalid";

    public INTERNALID()
    {
      super(paramCMConstants);
    }
  }

  public class INSTRUCTION extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "instruction";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String INSTRUCTION_CLASS = "instruction_class";

    public INSTRUCTION()
    {
      super(paramCMConstants);
    }
  }

  public class INPUT extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "input";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String INPUT_NAME = "input_name";
    public static final String INPUT_SOURCE = "input_source";

    public INPUT()
    {
      super(paramCMConstants);
    }
  }

  public class GROUP extends CMConstants.DATA
  {
    public static final String CLASS_NAME = "group";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String GROUP_NAME = "group_name";
    public static final String GROUP_DESCRIPTION = "group_description";

    public GROUP()
    {
      super(paramCMConstants);
    }
  }

  public class EVENTTOPOLOGYRULES extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "eventtopologyrules";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String EVENTTOPOLOGYRULES_DESCRIPTION = "eventtopologyrules_description";
    public static final String EVENTTOPOLOGYRULES_NAME = "eventtopologyrules_name";
    public static final String EVENTTOPOLOGYRULES_PQLNAME = "eventtopologyrules_pqlname";
    public static final String EVENTTOPOLOGYRULES_ISACTIVE = "eventtopologyrules_isactive";
    public static final String EVENTTOPOLOGYRULES_OWNER = "eventtopologyrules_owner";
    public static final String EVENTTOPOLOGYRULES_AFFECTEDNODES = "eventtopologyrules_affectednodes";

    public EVENTTOPOLOGYRULES()
    {
      super(paramCMConstants);
    }
  }

  public class EVENTTIMERULES extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "eventtimerules";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String EVENTTIMERULES_DESCRIPTION = "eventtimerules_description";
    public static final String EVENTTIMERULES_CLASSNAME = "eventtimerules_classname";
    public static final String EVENTTIMERULES_INTERVAL = "eventtimerules_interval";
    public static final String EVENTTIMERULES_ORDER = "eventtimerules_order";
    public static final String EVENTTIMERULES_ISACTIVE = "eventtimerules_isactive";
    public static final String EVENTTIMERULES_NAME = "eventtimerules_name";
    public static final String EVENTTIMERULES_NEXTTIME = "eventtimerules_nexttime";

    public EVENTTIMERULES()
    {
      super(paramCMConstants);
    }
  }

  public class EVENTRULES extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "eventrules";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String EVENTRULES_DESCRIPTION = "eventrules_description";
    public static final String EVENTRULES_ORDER = "eventrules_order";
    public static final String EVENTRULES_NAME = "eventrules_name";
    public static final String EVENTRULES_CLASSNAME = "eventrules_classname";
    public static final String EVENTRULES_ISACTIVE = "eventrules_isactive";

    public EVENTRULES()
    {
      super(paramCMConstants);
    }
  }

  public class TIMERULES extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "timerules";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String NAME = "name";
    public static final String DATA = "data";

    public TIMERULES()
    {
      super(paramCMConstants);
    }
  }

  public class RULES extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "rules";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String NAME = "name";
    public static final String DATA = "data";

    public RULES()
    {
      super(paramCMConstants);
    }
  }

  public class EVENTBASE extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "eventbase";
    public static final String NAME_SPACE = "";
    public static final String TAGS = "TAGS";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String EVENTBASE_SEVERITY = "eventbase_severity";
    public static final String EVENTBASE_CLASSNAME = "eventbase_classname";
    public static final String EVENTBASE_TYPE = "eventbase_type";
    public static final String EVENTBASE_DATA9 = "eventbase_data9";
    public static final String EVENTBASE_DATA8 = "eventbase_data8";
    public static final String EVENTBASE_DATA7 = "eventbase_data7";
    public static final String EVENTBASE_DATA6 = "eventbase_data6";
    public static final String EVENTBASE_DATA5 = "eventbase_data5";
    public static final String EVENTBASE_ISCORR = "eventbase_iscorr";
    public static final String EVENTBASE_DATA4 = "eventbase_data4";
    public static final String EVENTBASE_EVENTID = "eventbase_eventid";
    public static final String EVENTBASE_DATA3 = "eventbase_data3";
    public static final String EVENTBASE_USERTIME = "eventbase_usertime";
    public static final String EVENTBASE_CATEGORY = "eventbase_category";
    public static final String EVENTBASE_DATA2 = "eventbase_data2";
    public static final String EVENTBASE_DATA10 = "eventbase_data10";
    public static final String EVENTBASE_DATA1 = "eventbase_data1";
    public static final String EVENTBASE_ORIGIN = "eventbase_origin";
    public static final String EVENTBASE_MESSAGE = "eventbase_message";
    public static final String EVENTBASE_ATTRIBUTEVALUE = "eventbase_attributevalue";
    public static final String EVENTBASE_ATTRIBUTENAME = "eventbase_attributename";

    public EVENTBASE()
    {
      super(paramCMConstants);
    }
  }

  public class CHART extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "chart";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String CHART_TYPE = "chart_type";
    public static final String CHART_DESCRIPTION = "chart_description";
    public static final String CHART_NAME = "chart_name";
    public static final String CHART_OWNER = "chart_owner";

    public CHART()
    {
      super(paramCMConstants);
    }
  }

  public class AFFECTEDNODES extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "affectednodes";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String AFFECTEDNODES_NODENUMBER = "affectednodes_nodenumber";
    public static final String AFFECTEDNODES_AFFECTEDTYPE = "affectednodes_affectedtype";
    public static final String AFFECTEDNODES_STATEMODETYPE = "affectednodes_statemodetype";

    public AFFECTEDNODES()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIVEEVENT extends CMConstants.EVENTBASE
  {
    public static final String CLASS_NAME = "activeevent";
    public static final String NAME_SPACE = "";
    public static final String TAGS = "TAGS";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String ACTIVEEVENT_LABEL = "activeevent_label";
    public static final String ACTIVEEVENT_ISSUPPRESS = "activeevent_issuppress";
    public static final String ACTIVEEVENT_ISACK = "activeevent_isack";
    public static final String ACTIVEEVENT_RULETRACING = "activeevent_ruletracing";
    public static final String ACTIVEEVENT_ISACTIVE = "activeevent_isactive";
    public static final String ACTIVEEVENT_NOTE = "activeevent_note";
    public static final String ACTIVEEVENT_SYSTEMTIME = "activeevent_systemtime";
    public static final String ACTIVEEVENT_LASTUSERTIME = "activeevent_lastusertime";
    public static final String ACTIVEEVENT_LASTSYSTEMTIME = "activeevent_lastsystemtime";
    public static final String ACTIVEEVENT_ACTIVETIME = "activeevent_activetime";
    public static final String ACTIVEEVENT_COUNTER = "activeevent_counter";
    public static final String ACTIVEEVENT_ACKBY = "activeevent_ackby";
    public static final String ACTIVEEVENT_CREATECOUNTER = "activeevent_createcounter";
    public static final String ACTIVEEVENT_SUPPRESSTIME = "activeevent_suppresstime";
    public static final String ACTIVEEVENT_REPLACECOUNTER = "activeevent_replacecounter";
    public static final String ACTIVEEVENT_ACKTIME = "activeevent_acktime";

    public ACTIVEEVENT()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIONREPOSITORY extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "actionrepository";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String ACTIONREPOSITORY_DISPLAYNAME = "actionrepository_displayname";
    public static final String ACTIONREPOSITORY_ISINTERNAL = "actionrepository_isinternal";
    public static final String ACTIONREPOSITORY_DESCRIPTION = "actionrepository_description";
    public static final String ACTIONREPOSITORY_GUIJOB = "actionrepository_guijob";
    public static final String ACTIONREPOSITORY_ACTION = "actionrepository_action";
    public static final String ACTIONREPOSITORY_CATEGORY = "actionrepository_category";

    public ACTIONREPOSITORY()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIONKEY extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "actionkey";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String ACTIONKEY_ISINTERNAL = "actionkey_isinternal";
    public static final String ACTIONKEY_NAME = "actionkey_name";
    public static final String ACTIONKEY_PROVIDER = "actionkey_provider";

    public ACTIONKEY()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIONINVOCATIONDATA extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "actioninvocationdata";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String ACTIONINVOCATIONDATA_ORDER = "actioninvocationdata_order";

    public ACTIONINVOCATIONDATA()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIONINSTRUCTION extends CMConstants.INSTRUCTION
  {
    public static final String CLASS_NAME = "actioninstruction";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";

    public ACTIONINSTRUCTION()
    {
      super(paramCMConstants);
    }
  }

  public class ACTIONDEFINITION extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "actiondefinition";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String ACTIONDEFINITION_ISINTERNAL = "actiondefinition_isinternal";
    public static final String ACTIONDEFINITION_EXE = "actiondefinition_exe";
    public static final String ACTIONDEFINITION_SUBSYSTEM = "actiondefinition_subsystem";
    public static final String ACTIONDEFINITION_NAME = "actiondefinition_name";
    public static final String ACTIONDEFINITION_DESCRIPTION = "actiondefinition_description";

    public ACTIONDEFINITION()
    {
      super(paramCMConstants);
    }
  }

  public class ACTION extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "action";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String ACTION_ORDER = "action_order";
    public static final String ACTION_NAME = "action_name";

    public ACTION()
    {
      super(paramCMConstants);
    }
  }

  public class ACL extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "acl";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String ACL_MENULIST = "acl_menulist";
    public static final String ACL_CREATELIST = "acl_createlist";
    public static final String ACL_EDITLIST = "acl_editlist";
    public static final String ACL_MANAGERLIST = "acl_managerlist";

    public ACL()
    {
      super(paramCMConstants);
    }
  }

  public class FOLDER extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "folder";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MENU = "MENU";
    public static final String FOLDER_SUBSYSTEM = "folder_subSystem";
    public static final String FOLDER_ISUSEROBJECTNAME = "folder_isUserObjectName";
    public static final String FOLDER_PARENTID = "folder_parentId";
    public static final String FOLDER_NAME = "folder_name";

    public FOLDER()
    {
      super(paramCMConstants);
    }
  }

  public class TAILOR extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "tailor";
    public static final String NAME_SPACE = "";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String TAILOR_NAMEKEY = "tailor_nameKey";
    public static final String TAILOR_MAPKEY = "tailor_mapKey";
    public static final String TAILOR_IDENTIFIER = "tailor_identifier";
    public static final String TAILOR_VALUE = "tailor_value";

    public TAILOR()
    {
      super(paramCMConstants);
    }
  }

  public class SYMBOL_ALERT_DEF extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "symbolAlertDef";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String SYMBOLALERTDEF_ATTRNAME = "symbolAlertDef_attrName";

    public SYMBOL_ALERT_DEF()
    {
      super(paramCMConstants);
    }
  }

  public class SYMBOL_ALERT extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "symbolAlert";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String SYMBOLALERT_ISACTIVE = "symbolAlert_isActive";
    public static final String SYMBOLALERT_LOWLIMIT = "symbolAlert_lowLimit";
    public static final String SYMBOLALERT_HIGHLIMIT = "symbolAlert_highLimit";

    public SYMBOL_ALERT()
    {
      super(paramCMConstants);
    }
  }

  public class SUBCHART extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "subchart";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String SUBCHART_SOURCEDATA = "subchart_sourcedata";
    public static final String SUBCHART_XVALUES = "subchart_xvalues";
    public static final String SUBCHART_YVALUES = "subchart_yvalues";
    public static final String SUBCHART_TYPE = "subchart_type";
    public static final String SUBCHART_SEGMENTATION = "subchart_segmentation";
    public static final String SUBCHART_COLUMNNAME = "subchart_columnname";
    public static final String SUBCHART_LABELTYPE = "subchart_labeltype";
    public static final String SUBCHART_GROUPBY = "subchart_groupby";
    public static final String SUBCHART_ORDER = "subchart_order";
    public static final String SUBCHART_YTITLE = "subchart_ytitle";
    public static final String SUBCHART_XTITLE = "subchart_xtitle";
    public static final String SUBCHART_LABELVALUE = "subchart_labelvalue";
    public static final String SUBCHART_SCALE = "subchart_scale";
    public static final String SUBCHART_TITLE = "subchart_title";
    public static final String SUBCHART_INSTANCELIST = "subchart_instancelist";

    public SUBCHART()
    {
      super(paramCMConstants);
    }
  }

  public class PROFILE extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "profile";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String PROFILE_PMTIMERANGE = "profile_pmtimerange";
    public static final String PROFILE_CHART2D = "profile_chart2d";
    public static final String PROFILE_LABELXLENGTH = "profile_labelxlength";
    public static final String PROFILE_LABELYLENGTH = "profile_labelylength";
    public static final String PROFILE_ACTIVEFILTERLIST = "profile_activefilterlist";
    public static final String PROFILE_CHARTTABLIST = "profile_charttablist";
    public static final String PROFILE_BROWSERTABLIST = "profile_browsertablist";
    public static final String PROFILE_EVENTFILTERLIST = "profile_eventfilterlist";
    public static final String PROFILE_LOGFILTERLIST = "profile_logfilterlist";

    public PROFILE()
    {
      super(paramCMConstants);
    }
  }

  public class PQLNODEINFO extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "pqlnodeinfo";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String PQLNODEINFO_ACKMAPPING = "pqlnodeinfo_ackmapping";
    public static final String PQLNODEINFO_PQLGROUP = "pqlnodeinfo_pqlgroup";
    public static final String PQLNODEINFO_STATUSMAPPING = "pqlnodeinfo_statusmapping";
    public static final String PQLNODEINFO_COMPOUNDFUNCTION = "pqlnodeinfo_compoundfunction";
    public static final String PQLNODEINFO_COMPOUNDSTATUSMAPPING = "pqlnodeinfo_compoundstatusmapping";
    public static final String PQLNODEINFO_LABELFUNCTON = "pqlnodeinfo_labelfuncton";
    public static final String PQLNODEINFO_STATUSBLOCK = "pqlnodeinfo_statusblock";
    public static final String PQLNODEINFO_ISCONNECTEDTOBUSINESSSERVICE = "pqlnodeinfo_isConnectedToBusinessService";
    public static final String PQLNODEINFO_PQLNODETAGS = "pqlnodeinfo_pqlnodetags";

    public PQLNODEINFO()
    {
      super(paramCMConstants);
    }
  }

  public class PARAMDEFINITION extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "paramdefinition";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String PARAMDEFINITION_NAME = "paramdefinition_name";
    public static final String PARAMDEFINITION_ORDER = "paramdefinition_order";
    public static final String PARAMDEFINITION_TYPE = "paramdefinition_type";
    public static final String PARAMDEFINITION_DESCRIPTION = "paramdefinition_description";

    public PARAMDEFINITION()
    {
      super(paramCMConstants);
    }
  }

  public class PARAM extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "param";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String PARAM_TYPE = "param_type";
    public static final String PARAM_NAME = "param_name";
    public static final String PARAM_VALUE = "param_value";

    public PARAM()
    {
      super(paramCMConstants);
    }
  }

  public class PACKAGE_DEPENDENCY extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "PackageDependency";
    public static final String NAME_SPACE = "";

    public PACKAGE_DEPENDENCY()
    {
      super(paramCMConstants);
    }
  }

  public class MESSAGECATALOG extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "messagecatalog";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MESSAGECATALOG_CLASSNAME = "messagecatalog_classname";
    public static final String MESSAGECATALOG_ISACTIVE = "messagecatalog_isactive";
    public static final String MESSAGECATALOG_SEVERITY = "messagecatalog_severity";
    public static final String MESSAGECATALOG_FORMAT = "messagecatalog_format";
    public static final String MESSAGECATALOG_DESCRIPTION = "messagecatalog_description";
    public static final String MESSAGECATALOG_NAME = "messagecatalog_name";
    public static final String MESSAGECATALOG_INTERNALID = "messagecatalog_internalid";

    public MESSAGECATALOG()
    {
      super(paramCMConstants);
    }
  }

  public class INSTANCE_VIEW extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "instanceView";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String INSTANCEVIEW_KEY = "instanceView_key";
    public static final String INSTANCEVIEW_DATA = "instanceView_data";

    public INSTANCE_VIEW()
    {
      super(paramCMConstants);
    }
  }

  public class MODEL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "model";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MODEL_KEY = "model_key";
    public static final String MODEL_DATA = "model_data";

    public MODEL()
    {
      super(paramCMConstants);
    }
  }

  public class REFVIEW extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "refview";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String REFVIEW_TYPE = "refview_type";
    public static final String REFVIEW_TQLPARAMETERS = "refview_tqlParameters";
    public static final String REFVIEW_LABEL = "refview_label";
    public static final String REFVIEW_ACTIVE = "refview_active";
    public static final String REFVIEW_PERSISTENT = "refview_persistent";
    public static final String REFVIEW_MERGELAYERS = "refview_mergelayers";
    public static final String REFVIEW_TRACKCHANGES = "refview_trackChanges";
    public static final String REFVIEW_VIEWID = "refview_viewID";
    public static final String REFVIEW_NAME = "refview_name";
    public static final String REFVIEW_TEMPLATENAME = "refview_templatename";
    public static final String REFVIEW_DESCRIPTION = "refview_description";
    public static final String REFVIEW_OWNER = "refview_owner";
    public static final String REFVIEW_SUPPORTLEVEL = "refview_supportlevel";

    public REFVIEW()
    {
      super(paramCMConstants);
    }
  }

  public class BAC_FOLDER extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "bac_folder";
    public static final String NAME_SPACE = "Mercury";
    public static final String DELETABLE = "deletable";
    public static final String NAME = "name";
    public static final String CONTEXT = "context";
    public static final String BODY_ICON = "BODY_ICON";
    public static final String MENU = "MENU";

    public BAC_FOLDER()
    {
      super(paramCMConstants);
    }
  }

  public class BAC_VIEW extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "bac_view";
    public static final String NAME_SPACE = "";
    public static final String DESCRIPTION = "description";
    public static final String APPLICATIONS = "applications";
    public static final String DELETABLE = "deletable";
    public static final String GRAPH_VIEW_ID = "graph_view_id";
    public static final String LABEL = "LABEL";
    public static final String BODY_ICON = "BODY_ICON";
    public static final String TREE_VIEW_ID = "tree_view_id";
    public static final String NAME = "name";
    public static final String TQL_ID = "tql_id";
    public static final String TYPE = "type";
    public static final String CONTEXT = "context";
    public static final String ADVANCED = "advanced";
    public static final String MENU = "MENU";

    public BAC_VIEW()
    {
      super(paramCMConstants);
    }
  }

  public class MAPVIEW extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "mapview";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MAPVIEW_SERVICENAME = "mapview_servicename";
    public static final String MAPVIEW_MERGELAYERS = "mapview_mergelayers";
    public static final String MAPVIEW_TYPE = "mapview_type";
    public static final String MAPVIEW_TQLPARAMETERS = "mapview_tqlParameters";
    public static final String MAPVIEW_LINKSPROCESSORDER = "mapview_linksProcessOrder";
    public static final String MAPVIEW_LABEL = "mapview_label";
    public static final String MAPVIEW_USEMETALINKS = "mapview_usemetalinks";
    public static final String MAPVIEW_SUPPORTLEVEL = "mapview_supportlevel";
    public static final String MAPVIEW_ISCONTAINERRULE = "mapview_iscontainerrule";
    public static final String MAPVIEW_ORGANIZATIONNAME = "mapview_organizationname";
    public static final String MAPVIEW_LOGICALID = "mapview_logicalId";
    public static final String MAPVIEW_INTEGRATIONVENDOR = "mapview_integrationVendor";
    public static final String MAPVIEW_EVENTFILTER = "mapview_eventfilter";
    public static final String MAPVIEW_ACTIVE = "mapview_active";
    public static final String MAPVIEW_PERSISTENT = "mapview_persistent";
    public static final String MAPVIEW_OWNER = "mapview_owner";
    public static final String MAPVIEW_ICON = "mapview_icon";
    public static final String MAPVIEW_VIEWID = "mapview_viewID";
    public static final String MAPVIEW_GETEVENTS = "mapview_getevents";
    public static final String MAPVIEW_SENDRAWDELETE = "mapview_sendRawDelete";
    public static final String MAPVIEW_PQLID = "mapview_pqlID";
    public static final String MAPVIEW_DESCRIPTION = "mapview_description";
    public static final String MAPVIEW_NAME = "mapview_name";
    public static final String MAPVIEW_USERICON = "mapview_usericon";
    public static final String MAPVIEW_SENDRAWADD = "mapview_sendRawAdd";
    public static final String MAPVIEW_TAGS = "mapview_tags";
    public static final String MAPVIEW_ICONFUNCTION = "mapview_iconfunction";

    public MAPVIEW()
    {
      super(paramCMConstants);
    }
  }

  public class MAPRULEPQLHIRARCHI extends CMConstants.MAPRULEHIRARCHI
  {
    public static final String CLASS_NAME = "maprulepqlhirarchi";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MAPRULEPQLHIRARCHI_LINKGROUP = "maprulepqlhirarchi_linkgroup";
    public static final String MAPRULEPQLHIRARCHI_OBJPQLGROUP1 = "maprulepqlhirarchi_objpqlgroup1";
    public static final String MAPRULEPQLHIRARCHI_OBJPQLGROUP2 = "maprulepqlhirarchi_objpqlgroup2";

    public MAPRULEPQLHIRARCHI()
    {
      super(paramCMConstants);
    }
  }

  public class MAPRULEHIRARCHI extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "maprulehirarchi";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MAPRULEHIRARCHI_VIEWID = "maprulehirarchi_viewid";
    public static final String MAPRULEHIRARCHI_OBJCLASS2 = "maprulehirarchi_objclass2";
    public static final String MAPRULEHIRARCHI_LINKTYPE = "maprulehirarchi_linktype";
    public static final String MAPRULEHIRARCHI_OBJCLASS1 = "maprulehirarchi_objclass1";
    public static final String MAPRULEHIRARCHI_RELATIONS = "maprulehirarchi_relations";

    public MAPRULEHIRARCHI()
    {
      super(paramCMConstants);
    }
  }

  public class MAPNODE extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "mapnode";
    public static final String NAME_SPACE = "";
    public static final String MAPNODE_VIEWID = "mapnode_viewID";
    public static final String MAPNODE_VIEWNAME = "mapnode_viewName";
    public static final String MAPNODE_PQLGROUP = "mapnode_pqlgroup";
    public static final String MAPNODE_NODEID = "mapnode_nodeId";
    public static final String MAPNODE_PARENTID = "mapnode_parentId";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MAPNODE_NOTE = "mapnode_note";
    public static final String MAPNODE_COMPOUNDSTATUS = "mapnode_compoundstatus";
    public static final String MAPNODE_STATUS = "mapnode_status";
    public static final String MAPNODE_LABEL = "mapnode_label";
    public static final String MAPNODE_OPERSTATE = "mapnode_operstate";
    public static final String MAPNODE_CORRSTATE = "mapnode_corrstate";
    public static final String MAPNODE_CURRENTLAYOUT = "mapnode_currentlayout";
    public static final String MAPNODE_REALCLASS = "mapnode_realclass";
    public static final String MAPNODE_ACKSTATE = "mapnode_ackstate";
    public static final String MAPNODE_ADMINSTATE = "mapnode_adminstate";
    public static final String MAPNODE_ICON = "mapnode_icon";
    public static final String MAPNODE_LOGICALID = "mapnode_logicalId";
    public static final String MAPNODE_MANUALCORD = "mapnode_manualCord";
    public static final String MAPNODE_SONSNUMBER = "mapnode_sonsNumber";
    public static final String MAPNODE_COMPOUNDACK = "mapnode_compoundack";
    public static final String MAPNODE_TAGS = "mapnode_tags";

    public MAPNODE()
    {
      super(paramCMConstants);
    }
  }

  public class MAPLINKMETA extends CMConstants.MAPLINK
  {
    public static final String CLASS_NAME = "maplinkmeta";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MAPLINKMETA_REALEND2 = "maplinkmeta_realend2";
    public static final String MAPLINKMETA_REALEND1 = "maplinkmeta_realend1";

    public MAPLINKMETA()
    {
      super(paramCMConstants);
    }
  }

  public class MAPLINK extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "maplink";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MAPLINK_VIEWNAME = "maplink_viewName";
    public static final String MAPLINK_LABEL = "maplink_label";
    public static final String MAPLINK_NODEID = "maplink_nodeId";
    public static final String MAPLINK_VIEWID = "maplink_viewID";
    public static final String MAPLINK_MANUALCORDLC = "maplink_manualCordLC";
    public static final String MAPLINK_BROTHERS = "maplink_brothers";
    public static final String MAPLINK_OPERSTATE = "maplink_operstate";
    public static final String MAPLINK_CORRSTATE = "maplink_corrstate";
    public static final String MAPLINK_ADMINSTATE = "maplink_adminstate";
    public static final String MAPLINK_MANUALCORD = "maplink_manualCord";
    public static final String MAPLINK_REALCLASS = "maplink_realclass";
    public static final String MAPLINK_LABELEND2 = "maplink_labelEnd2";
    public static final String MAPLINK_LABELEND1 = "maplink_labelEnd1";
    public static final String MAPLINK_COMPOUNDSTATE = "maplink_compoundstate";
    public static final String MAPLINK_STATUS = "maplink_status";
    public static final String MAPLINK_LOGICALID = "maplink_logicalId";
    public static final String MAPLINK_ICON = "maplink_icon";
    public static final String MAPLINK_ISNEW = "maplink_isnew";
    public static final String MAPLINK_COMPOUNDACK = "maplink_compoundack";
    public static final String MAPLINK_HIDDEN = "maplink_hidden";
    public static final String MAPLINK_PQLGROUP = "maplink_pqlgroup";
    public static final String MAPLINK_TAGS = "maplink_tags";

    public MAPLINK()
    {
      super(paramCMConstants);
    }
  }

  public class BAC_CONTAINS extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "bac_contains";
    public static final String NAME_SPACE = "";

    public BAC_CONTAINS()
    {
      super(paramCMConstants);
    }
  }

  public class MAPLAYER extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "maplayer";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MAPLAYER_VIEWID = "maplayer_viewID";
    public static final String MAPLAYER_CIRCULARCORDRECT = "maplayer_circularCordRect";
    public static final String MAPLAYER_ZOOM = "maplayer_zoom";
    public static final String MAPLAYER_VIEWNAME = "maplayer_viewName";
    public static final String MAPLAYER_MAXLABELLENGTH = "maplayer_maxLabelLength";
    public static final String MAPLAYER_HIERARCHICORDRECT = "maplayer_hierarchiCordRect";
    public static final String MAPLAYER_SYMETRICCORDRECT = "maplayer_symetricCordRect";
    public static final String MAPLAYER_MANUALCORDRECT = "maplayer_manualCordRect";
    public static final String MAPLAYER_TYPE = "maplayer_type";
    public static final String MAPLAYER_ORTHOGONALCORDRECT = "maplayer_orthogonalCordRect";
    public static final String MAPLAYER_LOGICALID = "maplayer_logicalId";
    public static final String MAPLAYER_CURLAYOUT = "maplayer_curlayout";
    public static final String MAPLAYER_BG_IMAGE = "maplayer_bg_image";
    public static final String MAPLAYER_ISDIRTY = "maplayer_isdirty";
    public static final String MAPLAYER_ISFIRST = "maplayer_isfirst";

    public MAPLAYER()
    {
      super(paramCMConstants);
    }
  }

  public class MAPGROUPLINK extends CMConstants.MAPLINK
  {
    public static final String CLASS_NAME = "mapgrouplink";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MAPGROUPLINK_MINIMUMINGROUP = "mapgrouplink_minimumingroup";
    public static final String MAPGROUPLINK_KEY = "mapgrouplink_key";

    public MAPGROUPLINK()
    {
      super(paramCMConstants);
    }
  }

  public class MAPGROUP extends CMConstants.MAPNODE
  {
    public static final String CLASS_NAME = "mapgroup";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String MAPGROUP_MINIMUMINGROUP = "mapgroup_minimumingroup";
    public static final String MAPGROUP_KEY = "mapgroup_key";

    public MAPGROUP()
    {
      super(paramCMConstants);
    }
  }

  public class LAYERPROPERTIES extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "layerproperties";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String LAYERPROPERTIES_LOGICALID = "layerproperties_logicalId";
    public static final String LAYERPROPERTIES_LABELMAXSIZE = "layerproperties_labelmaxsize";
    public static final String LAYERPROPERTIES_VIEWNAME = "layerproperties_viewName";
    public static final String LAYERPROPERTIES_CURRENTLAYOUT = "layerproperties_currentlayout";

    public LAYERPROPERTIES()
    {
      super(paramCMConstants);
    }
  }

  public class KEY extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "key";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String KEY_KEY = "key_key";

    public KEY()
    {
      super(paramCMConstants);
    }
  }

  public class HIERARCHICALPROPERTIES extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "hierarchicalproperties";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String HIERARCHICALPROPERTIES_STYLE = "hierarchicalproperties_style";
    public static final String HIERARCHICALPROPERTIES_LEVELSPACING = "hierarchicalproperties_levelSpacing";
    public static final String HIERARCHICALPROPERTIES_ISPORTSHARINGENABLED = "hierarchicalproperties_isPortSharingEnabled";
    public static final String HIERARCHICALPROPERTIES_MINSLOPEPERCENT = "hierarchicalproperties_minSlopePercent";
    public static final String HIERARCHICALPROPERTIES_NODEFRAMEPERCENT = "hierarchicalproperties_nodeFramePercent";
    public static final String HIERARCHICALPROPERTIES_FRAMEPERCENT = "hierarchicalproperties_framePercent";
    public static final String HIERARCHICALPROPERTIES_LEVELORIENTATION = "hierarchicalproperties_levelOrientation";
    public static final String HIERARCHICALPROPERTIES_ROUTECOLUMNSPACING = "hierarchicalproperties_routeColumnSpacing";
    public static final String HIERARCHICALPROPERTIES_ROUTEROWSPACING = "hierarchicalproperties_routeRowSpacing";
    public static final String HIERARCHICALPROPERTIES_ISMERGINGENABLED = "hierarchicalproperties_isMergingEnabled";
    public static final String HIERARCHICALPROPERTIES_NODESPACING = "hierarchicalproperties_nodeSpacing";

    public HIERARCHICALPROPERTIES()
    {
      super(paramCMConstants);
    }
  }

  public class GUI_RULE_STAT_ELEMENT extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "guiRuleStatElement";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String GUIRULESTATELEMENT_PRIORITY = "guiRuleStatElement_priority";
    public static final String GUIRULESTATELEMENT_CATEGOREIS = "guiRuleStatElement_categoreis";

    public GUI_RULE_STAT_ELEMENT()
    {
      super(paramCMConstants);
    }
  }

  public class GUIRULESTATE extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "guirulestate";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";

    public GUIRULESTATE()
    {
      super(paramCMConstants);
    }
  }

  public class GROUPBY_DEFINITION extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "groupbyDefinition";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String GROUPBYDEFINITION_GROUPBYTYPE = "groupbyDefinition_groupbytype";
    public static final String GROUPBYDEFINITION_GROUPBYLABEL = "groupbyDefinition_groupbylabel";
    public static final String GROUPBYDEFINITION_GROUPBYORDER = "groupbyDefinition_groupbyorder";
    public static final String GROUPBYDEFINITION_GROUPBYMINIMUM = "groupbyDefinition_groupbyminimum";
    public static final String GROUPBYDEFINITION_GROUPBYPARAMS = "groupbyDefinition_groupbyparams";
    public static final String GROUPBYDEFINITION_GROUPBYNOTDIRECTED = "groupbyDefinition_groupbynotdirected";
    public static final String GROUPBYDEFINITION_GROUPBYICON = "groupbyDefinition_groupbyicon";

    public GROUPBY_DEFINITION()
    {
      super(paramCMConstants);
    }
  }

  public class EVENTMESSAGE extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "eventmessage";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String EVENTMESSAGE_OBJECTID = "eventmessage_objectid";
    public static final String EVENTMESSAGE_USERTIME = "eventmessage_usertime";
    public static final String EVENTMESSAGE_PRIORITY = "eventmessage_priority";
    public static final String EVENTMESSAGE_SYSTEMTIME = "eventmessage_systemtime";
    public static final String EVENTMESSAGE_INDEX = "eventmessage_index";
    public static final String EVENTMESSAGE_SUBSYSTEM = "eventmessage_subsystem";
    public static final String EVENTMESSAGE_SEVERITY = "eventmessage_severity";
    public static final String EVENTMESSAGE_CLASSNAME = "eventmessage_classname";
    public static final String EVENTMESSAGE_EVENTID = "eventmessage_eventid";
    public static final String EVENTMESSAGE_GROUPID = "eventmessage_groupid";
    public static final String EVENTMESSAGE_MESSAGE = "eventmessage_message";

    public EVENTMESSAGE()
    {
      super(paramCMConstants);
    }
  }

  public class DISCONNECTEDPROPERTIES extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "disconnectedproperties";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String DISCONNECTEDPROPERTIES_CONSTANTCOLUMNSPACING = "disconnectedproperties_constantColumnSpacing";
    public static final String DISCONNECTEDPROPERTIES_CONSTANTROWSPACING = "disconnectedproperties_constantRowSpacing";
    public static final String DISCONNECTEDPROPERTIES_MAGNIFIEDROWSPACING = "disconnectedproperties_magnifiedRowSpacing";
    public static final String DISCONNECTEDPROPERTIES_MAGNIFIEDCOLUMNSPACING = "disconnectedproperties_magnifiedColumnSpacing";

    public DISCONNECTEDPROPERTIES()
    {
      super(paramCMConstants);
    }
  }

  public class DEPLOYED_RESOURCE extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "deployedResource";
    public static final String NAME_SPACE = "";
    public static final String PACKAGE_NAME = "package_name";
    public static final String NAME = "name";
    public static final String SUBSYSTEM = "subsystem";
    public static final String EXT = "ext";
    public static final String PATH = "path";
    public static final String CMDBVERSION = "cmdbVersion";
    public static final String CONTENT = "content";
    public static final String UPDATETIME = "updateTime";

    public DEPLOYED_RESOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class DEPLOYED_PACKAGE extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "deployedPackage";
    public static final String NAME_SPACE = "";
    public static final String NAME = "name";
    public static final String READONLY = "readOnly";
    public static final String UPDATETIME = "updateTime";
    public static final String VERSION = "version";
    public static final String CATEGORY = "category";
    public static final String DESCRIPTION = "description";
    public static final String UPDATEDVERSION = "updatedVersion";
    public static final String UPDATEDBY = "updatedBy";
    public static final String README = "readme";
    public static final String ISFACTORY = "isFactory";
    public static final String ISHIDDEN = "isHidden";

    public DEPLOYED_PACKAGE()
    {
      super(paramCMConstants);
    }
  }

  public class CONDITION extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "condition";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String CONDITION_OPERATOR = "condition_operator";
    public static final String CONDITION_LOGICALOPERATOR = "condition_logicaloperator";
    public static final String CONDITION_ORDER = "condition_order";

    public CONDITION()
    {
      super(paramCMConstants);
    }
  }

  public class COLUMN extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "column";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String COLUMN_VISIBILITY = "column_visibility";
    public static final String COLUMN_WIDTH = "column_width";
    public static final String COLUMN_NAME = "column_name";
    public static final String COLUMN_ORDER = "column_order";

    public COLUMN()
    {
      super(paramCMConstants);
    }
  }

  public class CIRCULARPROPERTIES extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "circularproperties";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String CIRCULARPROPERTIES_MINNODEINCLUSTER = "circularproperties_minNodeInCluster";
    public static final String CIRCULARPROPERTIES_MAXNODEINCLUSTER = "circularproperties_maxNodeInCluster";
    public static final String CIRCULARPROPERTIES_NODESPACING = "circularproperties_nodeSpacing";
    public static final String CIRCULARPROPERTIES_DEGREE = "circularproperties_degree";

    public CIRCULARPROPERTIES()
    {
      super(paramCMConstants);
    }
  }

  public class HISTORY_LINK extends CMConstants.IT_CHANGE_LINK
  {
    public static final String CLASS_NAME = "history_link";
    public static final String NAME_SPACE = "";

    public HISTORY_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class HISTORY_RELATION_CHANGE extends CMConstants.HISTORY_TOPOLOGICAL_CHANGE
  {
    public static final String CLASS_NAME = "HistoryRelationChange";
    public static final String NAME_SPACE = "";
    public static final String RELATION_CLASS_NAME = "relation_class_name";
    public static final String END2_ID = "end2_id";
    public static final String END2_CLASS_NAME = "end2_class_name";
    public static final String END2_DISPLAY_LABEL = "end2_display_label";
    public static final String RELATION_DISPLAY_LABEL = "relation_display_label";

    public HISTORY_RELATION_CHANGE()
    {
      super(paramCMConstants);
    }
  }

  public class HISTORY_TOPOLOGICAL_CHANGE extends CMConstants.HISTORY_CHANGE
  {
    public static final String CLASS_NAME = "HistoryTopologicalChange";
    public static final String NAME_SPACE = "";
    public static final String CHANGE_TYPE = "change_type";

    public HISTORY_TOPOLOGICAL_CHANGE()
    {
      super(paramCMConstants);
    }
  }

  public class HISTORY_ATTRIBUTE_CHANGE extends CMConstants.HISTORY_CHANGE
  {
    public static final String CLASS_NAME = "HistoryAttributeChange";
    public static final String NAME_SPACE = "";
    public static final String ATTRIBUTE_VALUE_TYPE = "attribute_value_type";
    public static final String ATTRIBUTE_OLD_VALUE_REPRESENTATION = "attribute_old_value_representation";
    public static final String ATTRIBUTE_NEW_VALUE_REPRESENTATION = "attribute_new_value_representation";
    public static final String ATTRIBUTE_NAME = "attribute_name";

    public HISTORY_ATTRIBUTE_CHANGE()
    {
      super(paramCMConstants);
    }
  }

  public class HISTORY_CHANGE extends CMConstants.IT_CHANGE
  {
    public static final String CLASS_NAME = "HistoryChange";
    public static final String NAME_SPACE = "";
    public static final String CHANGE_CREATE_TIME = "change_create_time";
    public static final String CHANGER_INFO = "changer_info";
    public static final String CHANGER_TYPE = "changer_type";
    public static final String DATASTORE_ORIGIN = "datastore_origin";

    public HISTORY_CHANGE()
    {
      super(paramCMConstants);
    }
  }

  public class TARGET extends CMConstants.FCMDB_CONFIG
  {
    public static final String CLASS_NAME = "target";
    public static final String NAME_SPACE = "";
    public static final String DESTINATION_ID = "destination_id";

    public TARGET()
    {
      super(paramCMConstants);
    }
  }

  public class SYNCH_UNIT_INFO extends CMConstants.FCMDB_INFO
  {
    public static final String CLASS_NAME = "synch_unit_info";
    public static final String NAME_SPACE = "";
    public static final String SYNCH_UNIT_ID = "synch_unit_id";
    public static final String CURRENT_STATE = "current_state";
    public static final String CURRENT_SYNCH_START_TIME = "current_synch_start_time";

    public SYNCH_UNIT_INFO()
    {
      super(paramCMConstants);
    }
  }

  public class SYNCH_INFO extends CMConstants.FCMDB_INFO
  {
    public static final String CLASS_NAME = "synch_info";
    public static final String NAME_SPACE = "";

    public SYNCH_INFO()
    {
      super(paramCMConstants);
    }
  }

  public class SYNCH_CONFIG_UNIT extends CMConstants.FCMDB_CONFIG
  {
    public static final String CLASS_NAME = "synch_config_unit";
    public static final String NAME_SPACE = "";
    public static final String ISACTIVE = "isActive";
    public static final String SYNCH_CONFIG_UNIT_ID = "synch_config_unit_id";

    public SYNCH_CONFIG_UNIT()
    {
      super(paramCMConstants);
    }
  }

  public class SYNCH_CONFIG extends CMConstants.FCMDB_CONFIG
  {
    public static final String CLASS_NAME = "synch_config";
    public static final String NAME_SPACE = "";

    public SYNCH_CONFIG()
    {
      super(paramCMConstants);
    }
  }

  public class SUPPORTED_CLASS_CONFIG extends CMConstants.FCMDB_CONFIG
  {
    public static final String CLASS_NAME = "supported_class_config";
    public static final String NAME_SPACE = "";
    public static final String IS_DERIVED = "is_derived";
    public static final String SUPPORTED_CLASS_NAME = "supported_class_name";

    public SUPPORTED_CLASS_CONFIG()
    {
      super(paramCMConstants);
    }
  }

  public class SOURCE_QUERY_CONFIG extends CMConstants.FCMDB_CONFIG
  {
    public static final String CLASS_NAME = "source_query_config";
    public static final String NAME_SPACE = "";
    public static final String IS_EXCLUSIVE = "is_exclusive";
    public static final String QUERY_NAME = "query_name";

    public SOURCE_QUERY_CONFIG()
    {
      super(paramCMConstants);
    }
  }

  public class SOURCE extends CMConstants.FCMDB_CONFIG
  {
    public static final String CLASS_NAME = "source";
    public static final String NAME_SPACE = "";
    public static final String DESTINATION_ID = "destination_id";

    public SOURCE()
    {
      super(paramCMConstants);
    }
  }

  public class LAST_SYNCH_UNIT_INFO extends CMConstants.FCMDB_INFO
  {
    public static final String CLASS_NAME = "last_synch_unit_info";
    public static final String NAME_SPACE = "";
    public static final String SYNCH_STATUS = "synch_status";
    public static final String IS_FULL_SYNCH = "is_full_synch";
    public static final String IS_ADHOC = "is_adhoc";
    public static final String SYNCH_UNIT_ID = "synch_unit_id";

    public LAST_SYNCH_UNIT_INFO()
    {
      super(paramCMConstants);
    }
  }

  public class LAST_CONCRETE_SYNCH_INFO extends CMConstants.FCMDB_INFO
  {
    public static final String CLASS_NAME = "last_concrete_synch_info";
    public static final String NAME_SPACE = "";
    public static final String SYNCH_START_TIME = "synch_start_time";
    public static final String SYNCH_STOP_TIME = "synch_stop_time";
    public static final String LAST_SUCCESSFUL_START_TIME = "last_successful_start_time";
    public static final String SYNCH_STATUS = "synch_status";
    public static final String NUM_CIS_ADDED = "num_cis_added";
    public static final String NUM_CIS_REMOVED = "num_cis_removed";
    public static final String NUM_CIS_UPDATED = "num_cis_updated";
    public static final String ERROR_DESCRIPTION = "error_description";
    public static final String SYNCH_TOPOLOGY = "synch_topology";
    public static final String TARGET_DESTINATION_ID = "target_destination_id";
    public static final String SOURCE_DESTINATION_ID = "source_destination_id";
    public static final String QUERY_NAME = "query_name";

    public LAST_CONCRETE_SYNCH_INFO()
    {
      super(paramCMConstants);
    }
  }

  public class FEDERATION_INFO extends CMConstants.FCMDB_INFO
  {
    public static final String CLASS_NAME = "federation_info";
    public static final String NAME_SPACE = "";

    public FEDERATION_INFO()
    {
      super(paramCMConstants);
    }
  }

  public class FEDERATION_CONFIG extends CMConstants.FCMDB_CONFIG
  {
    public static final String CLASS_NAME = "federation_config";
    public static final String NAME_SPACE = "";
    public static final String UCMDB_SUPPORTED_CLASSES = "ucmdb_supported_classes";

    public FEDERATION_CONFIG()
    {
      super(paramCMConstants);
    }
  }

  public class FCMDB_INFO_COMPOSITION extends CMConstants.FCMDB_CONFIGURATION_LINK
  {
    public static final String CLASS_NAME = "fcmdb_info_composition";
    public static final String NAME_SPACE = "";

    public FCMDB_INFO_COMPOSITION()
    {
      super(paramCMConstants);
    }
  }

  public class FCMDB_INFO extends CMConstants.FCMDB_CONFIGURATION
  {
    public static final String CLASS_NAME = "fcmdb_info";
    public static final String NAME_SPACE = "";

    public FCMDB_INFO()
    {
      super(paramCMConstants);
    }
  }

  public class FCMDB_CONFIGURATION_LINK extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "fcmdb_configuration_link";
    public static final String NAME_SPACE = "";

    public FCMDB_CONFIGURATION_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class FCMDB_CONFIGURATION extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "fcmdb_configuration";
    public static final String NAME_SPACE = "";

    public FCMDB_CONFIGURATION()
    {
      super(paramCMConstants);
    }
  }

  public class FCMDB_CONFIG extends CMConstants.FCMDB_CONFIGURATION
  {
    public static final String CLASS_NAME = "fcmdb_config";
    public static final String NAME_SPACE = "";

    public FCMDB_CONFIG()
    {
      super(paramCMConstants);
    }
  }

  public class FCMDB_CONF_COMPOSITION extends CMConstants.FCMDB_CONFIGURATION_LINK
  {
    public static final String CLASS_NAME = "fcmdb_conf_composition";
    public static final String NAME_SPACE = "";

    public FCMDB_CONF_COMPOSITION()
    {
      super(paramCMConstants);
    }
  }

  public class FCMDB_CONF_AGGREGATION extends CMConstants.FCMDB_CONFIGURATION_LINK
  {
    public static final String CLASS_NAME = "fcmdb_conf_aggregation";
    public static final String NAME_SPACE = "";

    public FCMDB_CONF_AGGREGATION()
    {
      super(paramCMConstants);
    }
  }

  public class DESTINATION_CONFIG extends CMConstants.FCMDB_CONFIG
  {
    public static final String CLASS_NAME = "destination_config";
    public static final String NAME_SPACE = "";
    public static final String HOST = "host";
    public static final String PORT = "port";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String CUSTOMER_ID = "customer_id";
    public static final String DESTINATION_ID = "destination_id";
    public static final String QUERIES = "queries";
    public static final String CLASSES = "classes";
    public static final String URL = "url";
    public static final String CLASSES_ATTRIBUTES = "classes_attributes";

    public DESTINATION_CONFIG()
    {
      super(paramCMConstants);
    }
  }

  public class ADAPTER_CONFIG extends CMConstants.FCMDB_CONFIG
  {
    public static final String CLASS_NAME = "adapter_config";
    public static final String NAME_SPACE = "";
    public static final String ADAPTER_ID = "adapter_id";
    public static final String JAVA_CLASS_NAME = "java_class_name";
    public static final String ADAPTER_CAPABILITIES = "adapter_capabilities";
    public static final String ADAPTER_CAPABILITIES_XML = "adapter_capabilities_xml";
    public static final String CONNECT_FIELDS = "connect_fields";
    public static final String DEFAULT_MAPPING_ENGINE = "default_mapping_engine";

    public ADAPTER_CONFIG()
    {
      super(paramCMConstants);
    }
  }

  public class FUNCTION extends CMConstants.CONFIGURATION_LINKS
  {
    public static final String CLASS_NAME = "function";
    public static final String NAME_SPACE = "";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";

    public FUNCTION()
    {
      super(paramCMConstants);
    }
  }

  public class COMPOUND_F extends CMConstants.FUNCTION
  {
    public static final String CLASS_NAME = "compound_f";
    public static final String NAME_SPACE = "";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";

    public COMPOUND_F()
    {
      super(paramCMConstants);
    }
  }

  public class JOIN_F extends CMConstants.FUNCTION
  {
    public static final String CLASS_NAME = "join_f";
    public static final String NAME_SPACE = "";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";

    public JOIN_F()
    {
      super(paramCMConstants);
    }
  }

  public class INHERITANCE_F extends CMConstants.FUNCTION
  {
    public static final String CLASS_NAME = "inheritance_f";
    public static final String NAME_SPACE = "";
    public static final String LABEL = "LABEL";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";

    public INHERITANCE_F()
    {
      super(paramCMConstants);
    }
  }

  public class CONTAINS_CMDB extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "contains_cmdb";
    public static final String NAME_SPACE = "cmdb";

    public CONTAINS_CMDB()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_SIMPLE_OPERAND_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentSimpleOperandImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String SIMPLEOPERAND = "simpleOperand";
    public static final String SIMPLEOPERANDTYPE = "simpleOperandType";

    public ENRICHMENT_SIMPLE_OPERAND_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_COMPLEX_OPERAND_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentComplexOperandImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String NODENUMBER = "nodeNumber";
    public static final String ATTRIBUTENAME = "attributeName";

    public ENRICHMENT_COMPLEX_OPERAND_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_SINGLE_EXPRESSION_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentSingleExpressionImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String INDEX = "index";
    public static final String LOGICALOPERATOR = "logicalOperator";

    public ENRICHMENT_SINGLE_EXPRESSION_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_REGULAR_EXPRESSION_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentRegularExpressionImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String REGULAREXPRESSION = "regularExpression";
    public static final String GROUP = "group";

    public ENRICHMENT_REGULAR_EXPRESSION_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_AGGREGATE_EXPRESSION_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentAggregateExpressionImpl";
    public static final String NAME_SPACE = "Mercury";

    public ENRICHMENT_AGGREGATE_EXPRESSION_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_ATTRIBUTE_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentAttributeImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String ATTRIBUTENAME = "attributeName";
    public static final String INDEX = "index";

    public ENRICHMENT_ATTRIBUTE_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_ATTRIBUTES_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentAttributesImpl";
    public static final String NAME_SPACE = "Mercury";

    public ENRICHMENT_ATTRIBUTES_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_LINK_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentLinkImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String ACTION = "action";
    public static final String CLASSNAME = "className";
    public static final String INDEX = "index";
    public static final String NODENUMBER = "nodeNumber";
    public static final String NODENUMBEREND1 = "nodeNumberEnd1";
    public static final String NODENUMBEREND2 = "nodeNumberEnd2";

    public ENRICHMENT_LINK_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_OBJECT_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentObjectImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String ACTION = "action";
    public static final String CLASSNAME = "className";
    public static final String INDEX = "index";
    public static final String NODENUMBER = "nodeNumber";

    public ENRICHMENT_OBJECT_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_ACTIONS_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentActionsImpl";
    public static final String NAME_SPACE = "Mercury";

    public ENRICHMENT_ACTIONS_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_DEFINITION_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentDefinitionImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String ENRICHMENTNAME = "enrichmentName";
    public static final String INDEX = "index";
    public static final String ISACTIVE = "isActive";
    public static final String ORIGINALPATTERNID = "originalPatternId";
    public static final String DESCRIPTION = "description";
    public static final String ISCALCULATED = "isCalculated";
    public static final String ENRICHMENTTYPE = "enrichmentType";

    public ENRICHMENT_DEFINITION_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ENRICHMENT_DEFINITIONS_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "EnrichmentDefinitionsImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String ENRICHMENTSNAME = "enrichmentsName";

    public ENRICHMENT_DEFINITIONS_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class EXTENDED_PROPERTY_LINK extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "extended_property_link";
    public static final String NAME_SPACE = "Mercury";

    public EXTENDED_PROPERTY_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class JOINF_PROPERTY_CONDITION_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "JoinfPropertyConditionImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String END1_NAME = "end1_name";
    public static final String END2_NAME = "end2_name";
    public static final String OPERATOR = "operator";

    public JOINF_PROPERTY_CONDITION_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_LINK_JOINF_PARAMETER_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "PatternLinkJoinfParameterImpl";
    public static final String NAME_SPACE = "Mercury";

    public PATTERN_LINK_JOINF_PARAMETER_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_LINK_JOINF_IMPL extends CMConstants.PATTERN_LINK_IMPL
  {
    public static final String CLASS_NAME = "PatternLinkJoinfImpl";
    public static final String NAME_SPACE = "Mercury";

    public PATTERN_LINK_JOINF_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_LINK_COMPOUND_PARAMETER_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "PatternLinkCompoundParameterImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String DEPTH = "depth";
    public static final String MIN_DEPTH = "min_depth";
    public static final String NAME = "name";
    public static final String INNERLINKSELEMENTNUMBER = "innerLinksElementNumber";
    public static final String FROMSOURCEINNERLINKSELEMENTNUMBER = "fromSourceInnerLinksElementNumber";
    public static final String TOTARGETINNERLINKSELEMENTNUMBER = "toTargetInnerLinksElementNumber";
    public static final String SOURCETOTARGETINNERLINKSELEMENTNUMBER = "sourceToTargetInnerLinksElementNumber";
    public static final String INNEROBJECTSELEMENTNUMBER = "innerObjectsElementNumber";
    public static final String STOP_SEARCH_AT_TARGET = "stop_search_at_target";
    public static final String SHOULD_RETURN_PATHS = "should_return_paths";

    public PATTERN_LINK_COMPOUND_PARAMETER_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_LINK_COMPOUND_IMPL extends CMConstants.PATTERN_LINK_IMPL
  {
    public static final String CLASS_NAME = "PatternLinkCompoundImpl";
    public static final String NAME_SPACE = "Mercury";

    public PATTERN_LINK_COMPOUND_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_LINK_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "PatternLinkImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String ELEMENT_CLASS = "element_class";
    public static final String ELEMENT_NAME = "element_name";
    public static final String INDEX = "index";
    public static final String ELEMENT_ISDERIVED = "element_isderived";
    public static final String SHOULD_BE_CALCULATED_ONLY_IN_MODEL = "should_be_calculated_only_in_model";
    public static final String SHOULD_NEGATE_QUALIFIERS = "should_negate_qualifiers";
    public static final String ELEMENT_ISVISIBLE = "element_isvisible";
    public static final String ELEMENT_NUMBER = "element_number";
    public static final String ELEMENT_IDSCONDITION = "element_idscondition";
    public static final String NEGATE_ELEMENT_IDSCONDITION = "negate_element_idscondition";
    public static final String ELEMENT_PROPERTIESCONDITION = "element_propertiescondition";
    public static final String PATTERN_LINKEND1 = "pattern_linkend1";
    public static final String PATTERN_LINKEND2 = "pattern_linkend2";
    public static final String ELEMENT_QULIFIER = "element_qulifier";
    public static final String ELEMENT_LIMIT_QULIFIERS = "element_limit_qulifiers";
    public static final String ALLOWED_LINKS_TYPE = "allowed_links_type";

    public PATTERN_LINK_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_TRIPLE_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "PatternTripleImpl";
    public static final String NAME_SPACE = "Mercury";

    public PATTERN_TRIPLE_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_NODE_SUB_GRAPH_PARAMETER_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "PatternNodeSubGraphParameterImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String DEPTH = "depth";
    public static final String GRAPHTOSRCLINKNUMBER = "graphTosrcLinkNumber";
    public static final String INNERLINKSELEMENTNUMBER = "innerLinksElementNumber";
    public static final String INNEROBJECTSELEMENTNUMBER = "innerObjectsElementNumber";
    public static final String SRCTOGRAPHLINKNUMBER = "srcToGraphLinkNumber";
    public static final String NAME = "name";

    public PATTERN_NODE_SUB_GRAPH_PARAMETER_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_NODE_WITH_SUB_GRAPH_IMPL extends CMConstants.PATTERN_NODE_IMPL
  {
    public static final String CLASS_NAME = "PatternNodeWithSubGraphImpl";
    public static final String NAME_SPACE = "Mercury";

    public PATTERN_NODE_WITH_SUB_GRAPH_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_NODE_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "PatternNodeImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String ELEMENT_CLASS = "element_class";
    public static final String ELEMENT_NAME = "element_name";
    public static final String INDEX = "index";
    public static final String ELEMENT_ISDERIVED = "element_isderived";
    public static final String SHOULD_BE_CALCULATED_ONLY_IN_MODEL = "should_be_calculated_only_in_model";
    public static final String SHOULD_NEGATE_QUALIFIERS = "should_negate_qualifiers";
    public static final String ELEMENT_ISVISIBLE = "element_isvisible";
    public static final String ELEMENT_NUMBER = "element_number";
    public static final String ELEMENT_IDSCONDITION = "element_idscondition";
    public static final String NEGATE_ELEMENT_IDSCONDITION = "negate_element_idscondition";
    public static final String PATTERN_NODE_LINKSCONDITION = "pattern_node_linkscondition";
    public static final String ELEMENT_PROPERTIESCONDITION = "element_propertiescondition";
    public static final String ELEMENT_QULIFIER = "element_qulifier";
    public static final String ELEMENT_LIMIT_QULIFIERS = "element_limit_qulifiers";

    public PATTERN_NODE_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ELEMENT_PROPERTIES_CONDITION_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "ElementPropertiesConditionImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String ELEMENT_PROPERTIESCONDITION = "element_propertiescondition";

    public ELEMENT_PROPERTIES_CONDITION_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class ELEMENT_SIMPLE_LAYOUT_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "ElementSimpleLayoutImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String ALLLAYOUT = "allLayout";
    public static final String ELEMENTNUMBER = "elementNumber";
    public static final String PROPERTIES = "properties";
    public static final String QULIFIERNAMES = "qulifierNames";

    public ELEMENT_SIMPLE_LAYOUT_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_LAYOUT_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "PatternLayoutImpl";
    public static final String NAME_SPACE = "Mercury";

    public PATTERN_LAYOUT_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_GRAPH_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "PatternGraphImpl";
    public static final String NAME_SPACE = "Mercury";

    public PATTERN_GRAPH_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class PATTERN_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "PatternImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String PATTERN_NAME = "pattern_name";
    public static final String INDEX = "index";
    public static final String PATTERN_DESCRIPTION = "pattern_description";
    public static final String PATTERN_GROUPID = "pattern_groupid";
    public static final String PATTERN_ISACTIVE = "pattern_isactive";
    public static final String PATTERN_ISNOTIFICATIONONLY = "pattern_isnotificationonly";
    public static final String PATTERN_ISPRESIST = "pattern_ispresist";
    public static final String PATTERN_LABEL = "pattern_label";
    public static final String PATTERN_OWNER = "pattern_owner";
    public static final String PATTERN_PRIORITY = "pattern_priority";
    public static final String PATTERN_SOURCE = "pattern_source";
    public static final String PATTERN_VERSION = "pattern_version";
    public static final String PATTERN_ACCESSORY_INFO = "pattern_accessory_info";

    public PATTERN_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class TQL_DEFINITIONS_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "TqlDefinitionsImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String TQLID = "TqlId";

    public TQL_DEFINITIONS_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class MODEL_NOTIFICATION_DEFINITION_IMPL extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "ModelNotificationDefinitionImpl";
    public static final String NAME_SPACE = "Mercury";
    public static final String MODEL_NOTIFICATION_NAME = "model_notification_name";
    public static final String MODEL_NOTIFICATION_DEF = "model_notification_def";

    public MODEL_NOTIFICATION_DEFINITION_IMPL()
    {
      super(paramCMConstants);
    }
  }

  public class IMPACT_LINK extends CMConstants.CALCULATED_LINK
  {
    public static final String CLASS_NAME = "impact_link";
    public static final String NAME_SPACE = "";

    public IMPACT_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class CALCULATED_LINK extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "calculated_link";
    public static final String NAME_SPACE = "";

    public CALCULATED_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class INCLUDES extends CMConstants.IT_WORLD_LINKS
  {
    public static final String CLASS_NAME = "includes";
    public static final String NAME_SPACE = "Mercury";

    public INCLUDES()
    {
      super(paramCMConstants);
    }
  }

  public class CONTAINS extends CMConstants.SYSTEM_LINKS
  {
    public static final String CLASS_NAME = "contains";
    public static final String NAME_SPACE = "";

    public CONTAINS()
    {
      super(paramCMConstants);
    }
  }

  public class CONTAINER_F extends CMConstants.IT_WORLD_LINKS
  {
    public static final String CLASS_NAME = "container_f";
    public static final String NAME_SPACE = "";

    public CONTAINER_F()
    {
      super(paramCMConstants);
    }
  }

  public class DEPENDS_ON extends CMConstants.IT_WORLD_LINKS
  {
    public static final String CLASS_NAME = "depends_on";
    public static final String NAME_SPACE = "Mercury";

    public DEPENDS_ON()
    {
      super(paramCMConstants);
    }
  }

  public class MONITORED_BY extends CMConstants.MONITOR_LINKS
  {
    public static final String CLASS_NAME = "monitored_by";
    public static final String NAME_SPACE = "Mercury";

    public MONITORED_BY()
    {
      super(paramCMConstants);
    }
  }

  public class EUM_LINKS extends CMConstants.MONITOR_LINKS
  {
    public static final String CLASS_NAME = "eum_links";
    public static final String NAME_SPACE = "Mercury";

    public EUM_LINKS()
    {
      super(paramCMConstants);
    }
  }

  public class SYSTEM_MONITOR_LINKS extends CMConstants.MONITOR_LINKS
  {
    public static final String CLASS_NAME = "system_monitor_links";
    public static final String NAME_SPACE = "Mercury";

    public SYSTEM_MONITOR_LINKS()
    {
      super(paramCMConstants);
    }
  }

  public class EUM_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "eum_monitor";
    public static final String NAME_SPACE = "Mercury";

    public EUM_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class SYSTEM_MONITOR extends CMConstants.MONITOR
  {
    public static final String CLASS_NAME = "system_monitor";
    public static final String NAME_SPACE = "Mercury";

    public SYSTEM_MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class BUSINESS_LINKS extends CMConstants.IT_WORLD_LINKS
  {
    public static final String CLASS_NAME = "business_links";
    public static final String NAME_SPACE = "Mercury";

    public BUSINESS_LINKS()
    {
      super(paramCMConstants);
    }
  }

  public class SYSTEM_LINKS extends CMConstants.IT_WORLD_LINKS
  {
    public static final String CLASS_NAME = "system_links";
    public static final String NAME_SPACE = "Mercury";

    public SYSTEM_LINKS()
    {
      super(paramCMConstants);
    }
  }

  public class MONITOR_LINKS extends CMConstants.IT_WORLD_LINKS
  {
    public static final String CLASS_NAME = "monitor_links";
    public static final String NAME_SPACE = "Mercury";

    public MONITOR_LINKS()
    {
      super(paramCMConstants);
    }
  }

  public class IT_CHANGE_LINK extends CMConstants.IT_PROCESS_LINK
  {
    public static final String CLASS_NAME = "it_change_link";
    public static final String NAME_SPACE = "Mercury";

    public IT_CHANGE_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class IT_PROCESS_LINK extends CMConstants.IT_WORLD_LINKS
  {
    public static final String CLASS_NAME = "it_process_link";
    public static final String NAME_SPACE = "Mercury";

    public IT_PROCESS_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class IT_WORLD_LINKS extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "it_world_links";
    public static final String NAME_SPACE = "Mercury";

    public IT_WORLD_LINKS()
    {
      super(paramCMConstants);
    }
  }

  public class RECURSIVE_VIEW_LINK extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "recursive_view_link";
    public static final String NAME_SPACE = "Mercury";

    public RECURSIVE_VIEW_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class VIEW_LINK extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "view_link";
    public static final String NAME_SPACE = "Mercury";

    public VIEW_LINK()
    {
      super(paramCMConstants);
    }
  }

  public class IT_CHANGE extends CMConstants.IT_PROCESS
  {
    public static final String CLASS_NAME = "it_change";
    public static final String NAME_SPACE = "Mercury";

    public IT_CHANGE()
    {
      super(paramCMConstants);
    }
  }

  public class IT_PROCESS extends CMConstants.IT_WORLD
  {
    public static final String CLASS_NAME = "it_process";
    public static final String NAME_SPACE = "Mercury";

    public IT_PROCESS()
    {
      super(paramCMConstants);
    }
  }

  public class IT_WORLD extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "it_world";
    public static final String NAME_SPACE = "Mercury";
    public static final String COUNTRY = "country";
    public static final String STATE = "state";
    public static final String CITY = "city";
    public static final String CONTEXTMENU = "contextmenu";
    public static final String LATITUDE = "latitude";
    public static final String LONGITUDE = "longitude";
    public static final String IS_SAVE_PERSISTENCY = "is_save_persistency";
    public static final String TRACK_CHANGES = "track_changes";
    public static final String ACK_ID = "ack_id";
    public static final String ACK_CLEARED_TIME = "ack_cleared_time";

    public IT_WORLD()
    {
      super(paramCMConstants);
    }
  }

  public class CONFIGURATION_LINKS extends CMConstants.LINK
  {
    public static final String CLASS_NAME = "configuration_links";
    public static final String NAME_SPACE = "Mercury";

    public CONFIGURATION_LINKS()
    {
      super(paramCMConstants);
    }
  }

  public class CONFIGURATION_BUNDLE extends CMConstants.CONFIGURATION
  {
    public static final String CLASS_NAME = "configuration_bundle";
    public static final String NAME_SPACE = "Mercury";

    public CONFIGURATION_BUNDLE()
    {
      super(paramCMConstants);
    }
  }

  public class CONFIGURATION extends CMConstants.OBJECT
  {
    public static final String CLASS_NAME = "configuration";
    public static final String NAME_SPACE = "Mercury";

    public CONFIGURATION()
    {
      super(paramCMConstants);
    }
  }

  public class MONITOR extends CMConstants.IT_WORLD
  {
    public static final String CLASS_NAME = "monitor";
    public static final String NAME_SPACE = "Mercury";
    public static final String SELECTOR_EXPRESSION = "selector_expression";

    public MONITOR()
    {
      super(paramCMConstants);
    }
  }

  public class LOGICAL_APPLICATION extends CMConstants.BUSINESS
  {
    public static final String CLASS_NAME = "logical_application";
    public static final String NAME_SPACE = "Mercury";
    public static final String APP_ID = "app_id";

    public LOGICAL_APPLICATION()
    {
      super(paramCMConstants);
    }
  }

  public class BUSINESS extends CMConstants.IT_WORLD
  {
    public static final String CLASS_NAME = "business";
    public static final String NAME_SPACE = "Mercury";
    public static final String BUSINESS_CRITICALITY_LEVEL = "business_criticality_level";

    public BUSINESS()
    {
      super(paramCMConstants);
    }
  }

  public class SYSTEM extends CMConstants.IT_WORLD
  {
    public static final String CLASS_NAME = "system";
    public static final String NAME_SPACE = "Mercury";
    public static final String CREDENTIALS_ID = "credentials_id";
    public static final String LANGUAGE = "language";
    public static final String CODEPAGE = "codepage";

    public SYSTEM()
    {
      super(paramCMConstants);
    }
  }

  public class OBJECT extends CMConstants.DATA
  {
    public static final String CLASS_NAME = "object";
    public static final String NAME_SPACE = "";
    public static final String DOCUMENT_LIST = "document_list";

    public OBJECT()
    {
      super(paramCMConstants);
    }
  }

  public class LINK extends CMConstants.DATA
  {
    public static final String CLASS_NAME = "link";
    public static final String NAME_SPACE = "";
    public static final String DEFAULT_ICON = "DEFAULT_ICON";
    public static final String DEFAULT_SHAPE = "DEFAULT_SHAPE";
    public static final String CLASS_LINK_PATTERN = "CLASS_LINK_PATTERN";
    public static final String CLASS_LINK_WEIGHT = "CLASS_LINK_WEIGHT";
    public static final String CLASS_SHAPE_PROPERTIES = "CLASS_SHAPE_PROPERTIES";
    public static final String MENU = "MENU";
    public static final String WEIGHT = "weight";
    public static final String MUST = "must";

    public LINK()
    {
      super(paramCMConstants);
    }
  }

  public class DATA extends CMConstants.ROOT
  {
    public static final String CLASS_NAME = "data";
    public static final String NAME_SPACE = "";
    public static final String MENU = "MENU";
    public static final String DATA_TESTCORRSTATE = "data_testcorrstate";
    public static final String DATA_TESTSTATE = "data_teststate";
    public static final String DATA_SOURCE = "data_source";
    public static final String DATA_NAME = "data_name";
    public static final String DATA_NOTE = "data_note";
    public static final String DATA_ADMINSTATE = "data_adminstate";
    public static final String DATA_CHANGESTATE = "data_changestate";
    public static final String DATA_OPERATIONSTATE = "data_operationstate";
    public static final String DATA_TESTISNEW = "data_testisnew";
    public static final String DATA_CHANGECORRSTATE = "data_changecorrstate";
    public static final String DATA_EXTERNALID = "data_externalid";
    public static final String DATA_CHANGEISNEW = "data_changeisnew";
    public static final String DATA_OPERATIONCORRSTATE = "data_operationcorrstate";
    public static final String DATA_DESCRIPTION = "data_description";
    public static final String DATA_ORIGIN = "data_origin";
    public static final String DATA_UPDATED_BY = "data_updated_by";
    public static final String DATA_ALLOW_AUTO_DISCOVERY = "data_allow_auto_discovery";
    public static final String DIGEST = "digest";
    public static final String DATA_OPERATIONISNEW = "data_operationisnew";
    public static final String DISPLAY_LABEL = "display_label";
    public static final String USER_LABEL = "user_label";

    public DATA()
    {
      super(paramCMConstants);
    }
  }

  public class ROOT
  {
    public static final String CLASS_NAME = "root";
    public static final String NAME_SPACE = "";
    public static final String FAMILY_ICON = "FAMILY_ICON";
    public static final String BODY_ICON = "BODY_ICON";
    public static final String ROOT_CLASS = "root_class";
    public static final String ROOT_CREATETIME = "root_createtime";
    public static final String ROOT_CONTAINER = "root_container";
    public static final String ROOT_SYSTEM = "root_system";
    public static final String ROOT_UPDATETIME = "root_updatetime";
    public static final String ROOT_LASTACCESSTIME = "root_lastaccesstime";
    public static final String ROOT_CANDIDATEFORDELETETIME = "root_candidatefordeletetime";
    public static final String ROOT_ACTUALDELETETIME = "root_actualdeletetime";
    public static final String ROOT_ENABLEAGEING = "root_enableageing";
    public static final String ROOT_DELETIONCANDIDATEPERIOD = "root_deletioncandidateperiod";
    public static final String ROOT_ACTUALDELETIONPERIOD = "root_actualdeletionperiod";
    public static final String ROOT_ISUPDATEDBYOWNER = "root_isupdatedbyowner";
    public static final String ROOT_ICONPROPERTIES = "root_iconproperties";
  }

  public class CLASS_QUALIFIERS
  {
    public static final String PROTOCOLDIALOG = "ProtocolDialog";
    public static final String ID_CLASS_NAME_OVERRIDE = "ID_CLASS_NAME_OVERRIDE";
    public static final String PM_SUSPECT = "PM_SUSPECT";
    public static final String READ_ONLY_CLASS = "READ_ONLY_CLASS";
    public static final String DOCUMENTED = "DOCUMENTED";
    public static final String RULE_CALCULATING = "RULE_CALCULATING";
    public static final String MODELING_ENABLED = "MODELING_ENABLED";
    public static final String BLE_LINK_CLASS = "BLE_LINK_CLASS";
    public static final String PROTOCOLFIELDS = "ProtocolFields";
    public static final String CALCULATED_LINK = "CALCULATED_LINK";
    public static final String PROTOCOLHELPTOPIC = "ProtocolHelpTopic";
    public static final String HIDDEN_CLASS = "HIDDEN_CLASS";
    public static final String MAJOR_APP = "MAJOR_APP";
    public static final String MODEL = "MODEL";
    public static final String TRACK_LINK_CHANGES = "TRACK_LINK_CHANGES";
    public static final String RECURSIVE_DELETE = "RECURSIVE_DELETE";
    public static final String SITESCOPE_CLASS = "SITESCOPE_CLASS";
    public static final String NETWORK_DEVICES = "NETWORK_DEVICES";
    public static final String CONTAINER = "CONTAINER";
    public static final String ITU_HIDDEN_CLASS = "ITU_HIDDEN_CLASS";
    public static final String HANDLER = "HANDLER";
    public static final String ABSTRACT_CLASS = "ABSTRACT_CLASS";
    public static final String RANDOM_GENERATED_ID_CLASS = "RANDOM_GENERATED_ID_CLASS";
  }

  public class NAMESPACE
  {
    public static final String CMDB = "cmdb";
    public static final String MERCURY = "Mercury";
  }
}