package com.mercury.am.platform.cmdbext.validation.attribute;

import com.mercury.am.platform.cmdbext.cmhandler.CmdbAttributeHandler;
import com.mercury.am.platform.cmdbext.validation.utils.ValidationUtils;
import com.mercury.infra.utils.logger.Log;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.TypeVisitor;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBooleanType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbBytesType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDateType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbDoubleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbFloatType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleList;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringListType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbStringType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbXmlType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.Numeric;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.CmdbTypeDef;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.list.CmdbList;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.resource.CmdbExternalResource;

public class AttributeValueValidatorFactoryImpl extends AttributeValueValidatorFactory
{
  public AttributeValueValidator create(CmdbClass containerClass, CmdbAttribute attribute, Object attributeValue)
    throws AttributeValidationException
  {
    ClassModelQualifier handlerQualifier = ValidationUtils.findAttributeQualifierByName(attribute, CmdbAttributeQualifierDefs.HANDLED_ATTRIBUTE.getName());
    if (handlerQualifier != null) {
      CmdbAttributeHandler handler = null;
      try {
        handler = ValidationUtils.fetchAttributeHandler(handlerQualifier);
      } catch (Exception e) {
        logger.error("Failed to invoke CMDB Attribute Handler for Class " + containerClass.getName() + ", attribute" + attribute.getName() + " . Error: ", e);
        throw ValidationUtils.createAttributeValidationException("cmdb.validation.HANDLER_CREATION_ERROR", attribute, attributeValue);
      }

      if ((handler != null) && (handler.getValidator() != null))
        return handler.getValidator();

    }

    return createDefault(attribute, containerClass);
  }

  public AttributeValueValidator createDefault(CmdbAttribute attribute, CmdbClass containerClass)
  {
    CmdbType cmdbType = attribute.getResolvedType();
    return new ConvertCmdbType2AttrValidator(this, attribute, cmdbType).getAttributeValueValidator();
  }

  private class ConvertCmdbType2AttrValidator
  implements TypeVisitor
  {
    private AttributeValueValidator attributeValueValidator = null;
    private CmdbAttribute attribute;

    public ConvertCmdbType2AttrValidator(, CmdbAttribute paramCmdbAttribute, CmdbType paramCmdbType) {
      this.attribute = paramCmdbAttribute;
      if (paramCmdbType != null)
        paramCmdbType.accept(this);
    }

    public AttributeValueValidator getAttributeValueValidator()
    {
      return this.attributeValueValidator;
    }

    public void visit()
    {
    }

    public void visit()
    {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new DefaultAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new StringListAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new IntegerListAttributeValueValidator();
    }

    public void visit() {
    }

    public void visit() {
      this.attributeValueValidator = new EnumAttributeValueValidator();
    }

    public void visit() {
      this.attributeValueValidator = new ListAttributeValueValidator();
    }

    public void visit()
    {
    }
  }
}