package com.mercury.am.platform.cmdbext.validation.utils;

import com.mercury.am.platform.cmdbext.cmhandler.CmdbAttributeHandler;
import com.mercury.am.platform.cmdbext.cmhandler.CmdbClassHandler;
import com.mercury.am.platform.cmdbext.validation.attribute.AttributeTypeValidationException;
import com.mercury.am.platform.cmdbext.validation.attribute.AttributeValidationException;
import com.mercury.am.platform.cmdbext.validation.attribute.qualifier.ValidationErrorRecordFactory;
import com.mercury.am.platform.cmdbext.validation.classes.ClassValidationException;
import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItem;
import com.mercury.topaz.cmdb.shared.classmodel.base.dataitem.DataItems;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifiers;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.CmdbClassQualifiers;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Vector;

public class ValidationUtils
{
  public static Object getAttributeValue(String attributeName, Map attributeValues, CmdbData cmdbData)
  {
    if ((attributeValues != null) && (attributeValues.containsKey(attributeName)))
      return attributeValues.get(attributeName);
    if ((cmdbData != null) && (cmdbData.getProperty(attributeName) != null)) {
      return cmdbData.getProperty(attributeName).getValue();
    }

    return null;
  }

  public static AttributeValidationException createAttributeValidationException(String errorCode, CmdbAttribute attribute, Object value)
  {
    AttributeValidationException validationException = new AttributeValidationException(attribute, value);
    validationException.addUnqualifiedRecord(ValidationErrorRecordFactory.createQualifierValidatorRecord(errorCode, attribute.getName(), value));

    return validationException;
  }

  public static AttributeValidationException createAttributeValidationException(String errorCode, CmdbAttribute attribute, Object value, String paramName, Object paramValue)
  {
    AttributeValidationException validationException = new AttributeValidationException(attribute, value);
    validationException.addUnqualifiedRecord(ValidationErrorRecordFactory.createQualifierValidatorRecord(errorCode, attribute.getName(), value, paramName, paramValue));

    return validationException;
  }

  public static AttributeValidationException createAttributeValidationException(String errorCode, CmdbAttribute attribute, Object value, String param1Name, Object param1Value, String param2Name, Object param2Value)
  {
    AttributeValidationException validationException = new AttributeValidationException(attribute, value);
    validationException.addUnqualifiedRecord(ValidationErrorRecordFactory.createQualifierValidatorRecord(errorCode, attribute.getName(), value, param1Name, param1Value, param2Name, param2Value));

    return validationException;
  }

  public static AttributeTypeValidationException createAttributeTypeValidationException(CmdbAttribute attribute, Object invalidValue, Class invalidType, Class expectedType)
  {
    AttributeTypeValidationException validationException = new AttributeTypeValidationException(attribute, invalidValue, invalidType, expectedType);
    return validationException;
  }

  public static ClassValidationException createClassValidationException(CmdbClass cmdbClass, String qualifierName) {
    Vector unqualifiedList = new Vector();
    unqualifiedList.add(qualifierName);
    return new ClassValidationException(cmdbClass, new ArrayList(), unqualifiedList);
  }

  public static void validateAttributeType(CmdbAttribute attribute, Class desiredClass, Object value)
    throws AttributeTypeValidationException
  {
    Class attributeType = attribute.getResolvedType().getClass();
    if (!(desiredClass.isAssignableFrom(attributeType)))
      throw createAttributeTypeValidationException(attribute, value, attribute.getResolvedType().getClass(), desiredClass);
  }

  public static ClassModelQualifier findAttributeQualifierByName(CmdbAttribute attribute, String qualifierName)
  {
    CmdbAttributeQualifiers qualifiers = attribute.getQualifiers();
    if (qualifiers == null)
      return null;

    for (ReadOnlyIterator iterator = qualifiers.getIterator(); iterator.hasNext(); ) {
      ClassModelQualifier qualifier = (ClassModelQualifier)iterator.next();
      if (qualifier.getName().equalsIgnoreCase(qualifierName))
        return qualifier;
    }

    return null;
  }

  public static ClassModelQualifier findClassQualifierByName(CmdbClass cmdbClass, String qualifierName)
  {
    CmdbClassQualifiers qualifiers = cmdbClass.getClassQualifiers();
    if (qualifiers == null)
      return null;

    for (ReadOnlyIterator iterator = qualifiers.getIterator(); iterator.hasNext(); ) {
      ClassModelQualifier qualifier = (ClassModelQualifier)iterator.next();
      if (qualifier.getName().equalsIgnoreCase(qualifierName))
        return qualifier;
    }

    return null;
  }

  public static CmdbAttributeHandler fetchAttributeHandler(ClassModelQualifier handlerQualifier)
    throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
  {
    DataItem handlerDataItem = findDataItemByName(handlerQualifier, "HANDLER");

    String handlerClassName = (handlerDataItem == null) ? null : (String)handlerDataItem.getValue();
    if (StringUtils.isEmpty(handlerClassName))
      return null;

    Class handlerClass = Class.forName(handlerClassName);
    Constructor handlerConstructor = handlerClass.getConstructor(new Class[0]);
    return ((CmdbAttributeHandler)handlerConstructor.newInstance(null));
  }

  public static CmdbClassHandler fetchClassHandler(ClassModelQualifier qualifier)
    throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
  {
    DataItem handlerDataItem = findDataItemByName(qualifier, "HANDLER");

    String handlerClassName = (handlerDataItem == null) ? null : (String)handlerDataItem.getValue();
    if (StringUtils.isEmpty(handlerClassName))
      return null;

    Class handlerClass = Class.forName(handlerClassName);
    Constructor handlerConstructor = handlerClass.getConstructor(new Class[0]);
    return ((CmdbClassHandler)handlerConstructor.newInstance(null));
  }

  public static DataItem findDataItemByName(ClassModelQualifier qualifier, String dataItemName)
  {
    DataItems dataItems = qualifier.getDataItems();
    if (dataItems != null)
      for (ReadOnlyIterator dataItemsIterator = dataItems.getIterator(); dataItemsIterator.hasNext(); ) {
        DataItem dataItem = (DataItem)dataItemsIterator.next();
        if (dataItem.getName().equalsIgnoreCase(dataItemName))
          return dataItem;
      }


    return null;
  }
}