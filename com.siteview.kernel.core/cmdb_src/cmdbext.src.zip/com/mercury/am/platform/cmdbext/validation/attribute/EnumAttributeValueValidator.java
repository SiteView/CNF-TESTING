package com.mercury.am.platform.cmdbext.validation.attribute;

import com.mercury.am.platform.cmdbext.validation.utils.ValidationUtils;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnum;
import com.mercury.topaz.cmdb.shared.classmodel.type.typedef.cmdbenum.CmdbEnumEntry;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public class EnumAttributeValueValidator extends DefaultAttributeValueValidator
{
  public void validateType(CmdbAttribute attribute, Object value)
    throws AttributeTypeValidationException
  {
    ValidationUtils.validateAttributeType(attribute, CmdbEnum.class, value);

    if ((value != null) && (!(value instanceof Number)))
      throw ValidationUtils.createAttributeTypeValidationException(attribute, value, value.getClass(), Number.class);
  }

  public void validateNew(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, BasicUserData user)
    throws AttributeValidationException
  {
    validate(attribute, containerClass, value, attributeValues, null, user);
  }

  public void validateUpdated(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, CmdbData cmdbData, BasicUserData user)
    throws AttributeValidationException
  {
    validate(attribute, containerClass, value, attributeValues, cmdbData, user);
  }

  private void validate(CmdbAttribute attribute, CmdbClass containerClass, Object value, Map attributeValues, CmdbData cmdbData, BasicUserData user) throws AttributeValidationException {
    if (value == null)
      return;

    validateType(attribute, value);
    Number intValue = (Number)value;
    CmdbEnum cmdbEnum = (CmdbEnum)attribute.getResolvedType();

    for (ReadOnlyIterator iterator = cmdbEnum.getEnumerators(); iterator.hasNext(); ) {
      CmdbEnumEntry enumEntry = (CmdbEnumEntry)iterator.next();
      if (intValue.intValue() == enumEntry.getEnumKey())
      {
        if (cmdbData == null)
          super.validateNew(attribute, containerClass, value, attributeValues, user);
        else
          super.validateUpdated(attribute, containerClass, value, attributeValues, cmdbData, user);
        return;
      }
    }

    throw ValidationUtils.createAttributeValidationException("cmdb.validation.WRONG_ENUM_VALUE", attribute, value);
  }
}