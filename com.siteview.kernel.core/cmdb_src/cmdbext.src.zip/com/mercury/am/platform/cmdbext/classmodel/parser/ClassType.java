package com.mercury.am.platform.cmdbext.classmodel.parser;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ClassType
{
  private String name;
  private String derivedFrom;
  private String classType;
  private String namespace;
  private String description;
  private String fileName;
  private List qualifiers = new ArrayList();
  private List attributes = new ArrayList();
  private List overrideAttrs = new ArrayList();
  private List methods = new ArrayList();

  public ClassType(Node classNode, String fileName)
  {
    this.fileName = fileName;
    this.name = parseNodeAttribute(classNode, "class-name");
    this.description = parseNodeAttribute(classNode, "description");
    this.namespace = parseNodeAttribute(classNode, "namespace");

    NodeList childNodes = classNode.getChildNodes();
    for (int i = 0; i < childNodes.getLength(); ++i) {
      Node curNode = childNodes.item(i);
      String curNodeName = curNode.getNodeName();
      if (curNodeName.equals("Class-Qualifiers"))
        this.qualifiers = getChildNodesNames(curNode);
      else if (curNodeName.equals("Attributes"))
        this.attributes = getChildNodesNames(curNode);
      else if (curNodeName.equals("Attribute-Overrides"))
        this.overrideAttrs = getChildNodesNames(curNode);
      else if (curNodeName.equals("Methods"))
        this.methods = getChildNodesNames(curNode);
      else if (curNodeName.equals("Class-Type"))
        parseClassType(curNode);
      else if (curNodeName.equals("Derived-From"))
        this.derivedFrom = parseNodeAttribute(curNode, "class-name");
    }
  }

  private String parseNodeAttribute(Node curNode, String attrName)
  {
    NamedNodeMap attrs = curNode.getAttributes();
    if (attrs != null) {
      Node nameNode = attrs.getNamedItem(attrName);
      if (nameNode != null)
        return nameNode.getNodeValue();
    }

    return null;
  }

  private void parseClassType(Node classTypeNode)
  {
    NodeList childNodes = classTypeNode.getChildNodes();
    if (childNodes.getLength() > 0)
      this.classType = childNodes.item(0).getNodeValue();
  }

  private List getChildNodesNames(Node parentNode)
  {
    NodeList childNodes = parentNode.getChildNodes();
    List ret = new ArrayList();
    for (int i = 0; i < childNodes.getLength(); ++i) {
      Node childNode = childNodes.item(i);
      String childName = parseNodeAttribute(childNode, "name");
      if (childName != null)
        ret.add(childName);
    }

    return ret;
  }

  public String toString() {
    String retString = "Class: name[" + this.name + "] derivedFrom[" + this.derivedFrom + "] type[" + this.classType + "] description[" + this.description + "] namespace[" + this.namespace + "]";
    if (this.qualifiers.size() > 0)
      retString = retString + "\n\tqualifers: " + this.qualifiers;

    if (this.attributes.size() > 0)
      retString = retString + "\n\tattributes: " + this.attributes;

    if (this.overrideAttrs.size() > 0)
      retString = retString + "\n\toverrideAttrs: " + this.overrideAttrs;

    if (this.methods.size() > 0)
      retString = retString + "\n\tmethods: " + this.overrideAttrs;

    return retString;
  }

  public String getName() {
    return this.name;
  }

  public String getDerivedFrom() {
    return this.derivedFrom;
  }

  public String getClassType() {
    return this.classType;
  }

  public String getNamespace() {
    return this.namespace;
  }

  public String getDescription() {
    return this.description; }

  public String getFileName() {
    return this.fileName;
  }

  public List getQualifiers() {
    return this.qualifiers;
  }

  public List getAttributes() {
    return this.attributes;
  }

  public List getOverrideAttrs() {
    return this.overrideAttrs;
  }

  public List getMethods() {
    return this.methods;
  }
}