package com.mercury.am.platform.cmdbext.processing;

import com.mercury.am.platform.cmdbext.cmhandler.CmdbAttributeHandler;
import com.mercury.am.platform.cmdbext.cmhandler.HandlerUtil;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;

public class DefaultAttributeOutputProcessorFactory
  implements AttributeOutputProcessorFactory
{
  private static Log LOGGER = LogFactory.getEasyLog(DefaultAttributeOutputProcessorFactory.class);
  private static DefaultAttributeOutputProcessorFactory singleton = new DefaultAttributeOutputProcessorFactory();
  private static DefaultAttributeOutputProcessor defaultAttributeOutputProcessor = new DefaultAttributeOutputProcessor();

  public static DefaultAttributeOutputProcessorFactory getInstance()
  {
    return singleton;
  }

  public AttributeOutputProcessor create(CmdbAttribute attribute, CmdbClass cmdbClass, CmdbClassModel classModel)
    throws AttributeProcessingException
  {
    CmdbAttributeHandler attributeHandler = HandlerUtil.findAttributeHandlerQualifier(attribute);
    if ((attributeHandler != null) && (attributeHandler.hasOutputProcessor())) {
      AttributeOutputProcessor outputProcessor = attributeHandler.getOutputProcessor();
      if (outputProcessor != null)
        return outputProcessor;
    }

    return defaultAttributeOutputProcessor;
  }
}