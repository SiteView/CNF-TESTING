package com.mercury.am.platform.cmdbext.validation.dnode;

import java.util.HashMap;

public class DNodeDefinitionConstants
{
  public static HashMap _errorCode = new HashMap();
  public static final String GENERATOR_TAG = "Generator";
  public static final String GENERATOR_GRP_ATTR = "groupBy";
  public static final String GROUPING_SUBLEVEL_TAG = "Grouping";
  public static final String GENERATOR_NODE_TEMPLATE_ATTR = "itemTemplate";
  public static final String GENERATOR_LINK_TEMPLATE_ATTR = "linkTemplate";
  public static final String NODE_TEMPLATE_TAG = "ItemTemplate";
  public static final String LINK_TEMPLATE_TAG = "LinkTemplate";
  public static final String TEMPLATE_NAME_ATTR = "template";
  public static final String TEMPLATE_CLASSNAME_ATTR = "class-name";
  public static final String TEMPLATE_NAMESPACE_ATTR = "namespace";
  public static final String ATTRIBUTES_TAG = "Attributes";
  public static final String SINGLE_ATTRIBUTE_TAG = "Attribute";
  public static final String ATTRIBUTE_NAME_ATTR = "name";
  public static final String ATTRIBUTE_VALUE_ATTR = "value";
  public static final String ATTRIBUTE_REF_VALUE_ATTR = "ref_value";
  public static final String KPI_TEMPLATE_TAG = "KPI";
  public static final String OBJECTIVE_TEMPLATE_TAG = "Objective";
  public static final String RULE_ARGUMENTS_TAG = "RuleArguments";
  public static final String RULE_PARAMETERS_TAG = "RULE_PARAMS_NAMES";
  public static final String RULE_NAME_ATTRIBUTE = "name";
  public static final String RULE_TYPR_ATTRIBUTE = "type";
  public static final String RULE_VALUE_ATTRIBUTE = "value";
  public static final String SINGLE_PARAMETER_TAG = "parameter";
  public static final String COMPOSITE_SELECTOR_TAG = "CompositeSelector";
  public static final String LOGICAL_OP_ATTR = "logicalOp";
  public static final String SELECTOR_TAG = "Selector";
  public static final String SELECTOR_KEY_ATTR = "key";
  public static final String SELECTOR_OP_ATTR = "op";
  public static final String SELECTOR_TYPE_ATTR = "type";
  public static final String SELECTOR_VALUE_ATTR = "value";
  public static final String SELECTOR_REF_VALUE_ATTR = "ref_value";
  public static final DNodeErrorCode ERRORCODE_WRONG_XML_FORMAT = new DNodeErrorCode("cmdb.validation.dnode.WRONG_XML_FORMAT", "120883");
  public static final DNodeErrorCode ERRORCODE_NO_GENERATORS = new DNodeErrorCode("cmdb.validation.dnode.NO_GENERATORS", "120884");
  public static final DNodeErrorCode ERRORCODE_GENERATOR_NO_GROUPBY = new DNodeErrorCode("cmdb.validation.dnode.GENERATOR_NO_GROUPBY", "120885");
  public static final DNodeErrorCode ERRORCODE_GENERATOR_NO_ITEM_TEMPLATE = new DNodeErrorCode("cmdb.validation.dnode.GENERATOR_NO_ITEM_TEMPALTE", "120886");
  public static final DNodeErrorCode ERRORCODE_GENERATOR_REDUNDANT_ITEM_TEMPLATE = new DNodeErrorCode("cmdb.validation.dnode.GENERATOR_REDUNDANT_ITEM_TEMPALTE", "120887");
  public static final DNodeErrorCode ERRORCODE_GENERATOR_NO_LINK_TEMPLATE = new DNodeErrorCode("cmdb.validation.dnode.GENERATOR_NO_LINK_TEMPLATE", "120888");
  public static final DNodeErrorCode ERRORCODE_NO_TEMPLATE_NAME = new DNodeErrorCode("cmdb.validation.dnode.NO_TEMPLATE_NAME", "120889");
  public static final DNodeErrorCode ERRORCODE_TEMPLATE_DUPLICATE_NAME = new DNodeErrorCode("cmdb.validation.dnode.TEMPLATE_DUPLICATE_NAME", "120890");
  public static final DNodeErrorCode ERRORCODE_TEMPLATE_MISSING_CLASS = new DNodeErrorCode("cmdb.validation.dnode.ITEM_TEMPLATE_MISSING_CLASS", "120891");
  public static final DNodeErrorCode ERRORCODE_TEMPLATE_WRONG_CLASS = new DNodeErrorCode("cmdb.validation.dnode.ITEM_TEMPLATE_WRONG_CLASS", "120892");
  public static final DNodeErrorCode ERRORCODE_MISSING_ITEM_TEMPLATE = new DNodeErrorCode("cmdb.validation.dnode.MISSING_ITEM_TEMPLATE", "120893");
  public static final DNodeErrorCode ERRORCODE_MISSING_LINK_TEMPLATE = new DNodeErrorCode("cmdb.validation.dnode.MISSING_LINK_TEMPLATE", "120894");
  public static final DNodeErrorCode ERRORCODE_ATTRIBUTES_TAG = new DNodeErrorCode("cmdb.validation.dnode.ATTRIBUTES_TAG", "120895");
  public static final DNodeErrorCode ERRORCODE_ATTRIBUTE_NAME = new DNodeErrorCode("cmdb.validation.dnode.ATTRIBUTE_NAME", "120896");
  public static final DNodeErrorCode ERRORCODE_ATTRIBUTE_VALUE = new DNodeErrorCode("cmdb.validation.dnode.ATTRIBUTE_VALUE", "120897");
  public static final DNodeErrorCode ERRORCODE_WRONG_SELECTORS_FORMAT = new DNodeErrorCode("cmdb.validation.dnode.WRONG_SELECTORS_FORMAT", "120898");
  public static final DNodeErrorCode ERRORCODE_SELECTORS_NO_LOGICAL_OP = new DNodeErrorCode("cmdb.validation.dnode.NO_LOGICAL_OP", "120899");
  public static final DNodeErrorCode ERRORCODE_SELECTORS_KEY_OP = new DNodeErrorCode("cmdb.validation.dnode.SELECTORS_KEY_OP", "120900");
  public static final DNodeErrorCode ERRORCODE_SELECTORS_VAUE = new DNodeErrorCode("cmdb.validation.dnode.SELECTORS_VAUE", "120901");
  public static final DNodeErrorCode ERRORCODE_NO_KPI_TEMPLATE = new DNodeErrorCode("cmdb.validation.dnode.NO_KPI_TEMPLATE", "120902");
  public static final DNodeErrorCode ERRORCODE_WRONG_RULE_ARG_FORMAT = new DNodeErrorCode("cmdb.validation.dnode.WRONG_RULE_ARG_FORMAT", "120903");
  public static final DNodeErrorCode ERRORCODE_WRONG_RULE_PARAM_FORMAT = new DNodeErrorCode("cmdb.validation.dnode.WRONG_RULE_PARAM_FORMAT", "120904");
  public static final DNodeErrorCode ERRORCODE_TEMPLATE_CLASS_ID = new DNodeErrorCode("cmdb.validation.dnode.TEMPLATE_CLASS_ID", "120905");
  public static final DNodeErrorCode ERRORCODE_WRONG_ATTRIBUTE = new DNodeErrorCode("cmdb.validation.dnode.WRONG_ATTRIBUTE", "120906");

  public static String getLogErrorCode(String errorCode)
  {
    String returnCode = "";
    DNodeErrorCode dnodeErrorCode = (DNodeErrorCode)_errorCode.get(errorCode);
    if (dnodeErrorCode != null) {
      returnCode = dnodeErrorCode.getLogCode();
    }

    return returnCode;
  }

  public static class DNodeErrorCode {
    private String _uiCode;
    private String _logCode;

    DNodeErrorCode(String uiCode, String logCode) {
      this._uiCode = uiCode;
      this._logCode = logCode;
      DNodeDefinitionConstants._errorCode.put(uiCode, this);
    }

    public String getUiCode()
    {
      return this._uiCode;
    }

    public String getLogCode() {
      return this._logCode;
    }
  }
}