package com.mercury.am.platform.cmdbext.creation;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbLongType;
import java.util.Random;

public class RandomValueCreator
{
  private static int NUMBER_ATTRIBUTE_DEFAULT_SIZE_LIMIT = 10000;
  private static Random rand = new Random();

  public static Object createRandomValue(CmdbAttribute cmdbAttribute)
  {
    int sizeLimit = (cmdbAttribute.getSizeLimit() != null) ? cmdbAttribute.getSizeLimit().intValue() : NUMBER_ATTRIBUTE_DEFAULT_SIZE_LIMIT;

    if (cmdbAttribute.getResolvedType() instanceof CmdbIntegerType) {
      return new Integer(Math.abs(rand.nextInt()) % sizeLimit);
    }

    if (cmdbAttribute.getResolvedType() instanceof CmdbLongType) {
      return new Long(Math.abs(rand.nextLong()) % sizeLimit);
    }

    return Long.toString(Math.abs(rand.nextLong()));
  }
}