package com.mercury.am.platform.cmdbext.processing;

import com.mercury.infra.utils.lang.StringUtils;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.property.value.CmdbPropertyValues;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;
import java.util.StringTokenizer;

public abstract class TypedListAttributeProcessor extends SimpleAttributeProcessor
{
  private static Log LOGGER = LogFactory.getEasyLog(TypedListAttributeProcessor.class);
  public static final String LIST_PERFIX = "[";
  public static final String LIST_SUFFIX = "]";
  public static final String LIST_SEPERATOR = ",";

  protected TypedListAttributeProcessor(Class processedValueClass)
  {
    super(processedValueClass);
  }

  protected Object process(Map input, CmdbAttribute attribute, CmdbClass containedClass, CmdbData currentCmdbData, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi) throws AttributeProcessingException
  {
    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start processing list attribute for " + ((currentCmdbData == null) ? "new" : "updating") + " object. cmdb class name = " + ((containedClass == null) ? "null" : containedClass.getName()) + " attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " input = " + ((input == null) ? "null" : input.toString()) + " , user = " + ((userContext == null) ? "null" : userContext.toString()));
    }

    Object value = input.get(attribute.getName());

    if (value == null) {
      return null;
    }

    if (value instanceof String[])
      try {
        return processStringArrayValue(attribute, (String[])(String[])value, currentCmdbData, userContext);
      } catch (AttributeProcessingException ape) {
        if (LOGGER.isDebugEnabled())
          LOGGER.debug("Error processing value for attribute for " + ((currentCmdbData == null) ? "new" : "updating") + " object. cmdb class = " + ((containedClass == null) ? "null" : containedClass.getName()) + " attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " value = " + value + " input = " + ((input == null) ? "null" : input.toString()), ape);

        throw ape;
      } catch (Exception e) {
        if (LOGGER.isDebugEnabled()) {
          LOGGER.debug("Error processing value for attribute for " + ((currentCmdbData == null) ? "new" : "updating") + " object. cmdb class = " + ((containedClass == null) ? "null" : containedClass.getName()) + " attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " value = " + value + " input = " + ((input == null) ? "null" : input.toString()), e);
        }

        throw new AttributeProcessingException(e, attribute, value, getErrorCode(attribute));
      }


    return super.process(input, attribute, containedClass, currentCmdbData, userContext, cmdbContext, cmdbApi);
  }

  protected Object processStringValue(CmdbAttribute attribute, String valueAsString, CmdbData currentCmdbData, BasicUserData userContext)
    throws AttributeProcessingException, Exception
  {
    if (StringUtils.isEmpty(valueAsString))
      return null;

    CmdbPropertyValues values = createPropertyValueByType();

    if ((valueAsString.startsWith("[")) && (!(valueAsString.endsWith("]")))) {
      if (LOGGER.isDebugEnabled())
        LOGGER.debug("Error processing value for list attribute for " + ((currentCmdbData == null) ? "new" : "updating") + " object, if list value start with '[' it must ends with ']'.  attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " value = " + valueAsString);

      throw new AttributeProcessingException(attribute, valueAsString, getErrorCode(attribute));
    }

    if ((!(valueAsString.startsWith("["))) && (valueAsString.endsWith("]"))) {
      if (LOGGER.isDebugEnabled())
        LOGGER.debug("Error processing value for list attribute for " + ((currentCmdbData == null) ? "new" : "updating") + " object, if list value ends with '[' it must start with ']'.  attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " value = " + valueAsString);

      throw new AttributeProcessingException(attribute, valueAsString, getErrorCode(attribute));
    }

    StringTokenizer tokenizer = new StringTokenizer(valueAsString, "[,]");

    if (!(tokenizer.hasMoreTokens()))
      return null;

    while (tokenizer.hasMoreTokens()) {
      String value = tokenizer.nextToken().trim();

      if (!(StringUtils.isEmpty(value)))
        try
        {
          addValueToProperties(value, values);
        } catch (Exception e) {
          throw new AttributeProcessingException(attribute, valueAsString, getErrorCode(attribute));
        }
    }

    if (LOGGER.isInfoEnabled())
      LOGGER.info("Finish processing list attribute for " + ((currentCmdbData == null) ? "new" : "updating") + " object. attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " value = " + valueAsString + " processed value = " + values.toString());

    return values;
  }

  protected Object processStringArrayValue(CmdbAttribute attribute, String[] valueAsStringArray, CmdbData currentCmdbData, BasicUserData userContext)
    throws AttributeProcessingException, Exception
  {
    if (valueAsStringArray.length == 0)
      return null;

    CmdbPropertyValues values = createPropertyValueByType();

    for (int i = 0; i < valueAsStringArray.length; ++i) {
      String value = valueAsStringArray[i];

      if (!(StringUtils.isEmpty(value)))
        try
        {
          addValueToProperties(value, values);
        } catch (Exception e) {
          if (LOGGER.isDebugEnabled())
            LOGGER.debug("Error processing list attribute. attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " values = " + arrayToString(valueAsStringArray));

          throw new AttributeProcessingException(attribute, arrayToString(valueAsStringArray), getErrorCode(attribute));
        }

    }

    return values;
  }

  private Object arrayToString(String[] valueAsString) {
    StringBuffer result = new StringBuffer().append("[");

    for (int i = 0; i < valueAsString.length; ++i) {
      result.append(valueAsString[i]);
      if (i < valueAsString.length - 1)
        result.append(",");

    }

    result.append("]");
    return result.toString();
  }

  protected abstract void addValueToProperties(String paramString, CmdbPropertyValues paramCmdbPropertyValues)
    throws Exception;

  protected abstract CmdbPropertyValues createPropertyValueByType();
}