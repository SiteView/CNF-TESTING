package com.mercury.am.platform.cmdbext.processing;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.cmdb.shared.model.property.CmdbProperty;
import com.mercury.topaz.cmdb.shared.util.iterator.ReadOnlyIterator;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;
import java.util.Vector;

public class DefaultClassOutputProcessor
  implements ClassOutputProcessor
{
  private static Log LOGGER = LogFactory.getEasyLog(DefaultClassOutputProcessor.class);

  public Map processNew(CmdbData cmdbData, String cmdbClassName, CmdbClassModel classModel, Map outputData, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws ClassProcessingException, NullPointerException
  {
    process(cmdbData, cmdbClassName, classModel, outputData, userContext, true, cmdbContext, cmdbApi);
    return outputData;
  }

  public Map processExisting(CmdbData cmdbData, String cmdbClassName, CmdbClassModel classModel, Map outputData, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws ClassProcessingException, NullPointerException
  {
    process(cmdbData, cmdbClassName, classModel, outputData, userContext, false, cmdbContext, cmdbApi);
    return outputData;
  }

  private void process(CmdbData cmdbData, String cmdbClassName, CmdbClassModel classModel, Map outputData, BasicUserData userContext, boolean isNew, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws ClassProcessingException, NullPointerException
  {
    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start processing output for CMDB object. cmdb class = " + ((cmdbClassName == null) ? "null" : cmdbClassName) + ", user = " + ((userContext == null) ? "null" : userContext.toString()));
    }

    CmdbClass cmdbClass = classModel.getClass(cmdbClassName);

    Vector unprocessed = new Vector();

    for (ReadOnlyIterator propertiesIterator = cmdbData.getPropertiesIterator(); propertiesIterator.hasNext(); ) {
      CmdbProperty cmdbProperty = (CmdbProperty)propertiesIterator.next();
      String key = cmdbProperty.getKey();
      try
      {
        AttributeOutputProcessor attributeProcessor = getAttributeProcessorsFactory().create(cmdbClass.getAllAttributes().getAttributeByName(key), cmdbClass, classModel);
        if (isNew)
          outputData.put(key, attributeProcessor.processNew(cmdbClass.getAttributeByName(key), cmdbClass, cmdbData, outputData, userContext, cmdbContext, cmdbApi));
        else
          outputData.put(key, attributeProcessor.processExisting(cmdbClass.getAttributeByName(key), cmdbClass, cmdbData, outputData, userContext, cmdbContext, cmdbApi));
      } catch (AttributeProcessingException ape) {
        if (LOGGER.isDebugEnabled())
          LOGGER.debug("Error processing attribute: attribute name = " + key + " cmdb class name = " + ((cmdbClass == null) ? "null" : cmdbClass.getName()), ape);

        unprocessed.add(ape);
      }
    }

    if (!(unprocessed.isEmpty())) {
      if (LOGGER.isDebugEnabled())
        LOGGER.info("Error processing output for CMDB object. cmdb class = " + ((cmdbClassName == null) ? "null" : cmdbClassName) + " output data = " + outputData + ", user = " + ((userContext == null) ? "null" : userContext.toString()));

      throw new ClassProcessingException(cmdbClass, unprocessed, outputData);
    }

    if (LOGGER.isInfoEnabled())
      LOGGER.info("Finish processing output for CMDB object. cmdb class = " + ((cmdbClassName == null) ? "null" : cmdbClassName) + " output data = " + outputData + ", user = " + ((userContext == null) ? "null" : userContext.toString()));
  }

  public AttributeOutputProcessorFactory getAttributeProcessorsFactory()
  {
    return DefaultAttributeOutputProcessorFactory.getInstance();
  }
}