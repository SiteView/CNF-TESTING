package com.mercury.am.platform.cmdbext.validation.utils;

public class ValidationConstants
{
  public static final String ATTR_NAME = "ATTR_NAME";
  public static final String ATTR_VALUE = "ATTR_VALUE";
  public static final String WRONG_ENUM_VALUE = "WRONG_ENUM_VALUE";
  public static final String WRONG_LIST_VALUE = "WRONG_LIST_VALUE";
  public static final String WRONG_TYPE = "WRONG_TYPE";
  public static final String EXPECTED_TYPE = "EXPECTED_TYPE";
  public static final String WRONG_SIZE = "WRONG_SIZE";
  public static final String EXPECTED_SIZE = "EXPECTED_SIZE";
  public static final String ERRORCODE_WRONG_COUNTRY = "cmdb.validation.WRONG_COUNTRY";
  public static final String ERRORCODE_WRONG_STATE = "cmdb.validation.WRONG_STATE";
  public static final String ERRORCODE_WRONG_CITY = "cmdb.validation.WRONG_CITY";
  public static final String ERRORCODE_MIN_LENGTH = "cmdb.validation.MIN_LENGTH";
  public static final String ERRORCODE_MAX_LENGTH = "cmdb.validation.MAX_LENGTH";
  public static final String ERRORCODE_MIN_VALUE = "cmdb.validation.MIN_VALUE";
  public static final String ERRORCODE_MAX_VALUE = "cmdb.validation.MAX_VALUE";
  public static final String ERRORCODE_ALPHANUMERIC = "cmdb.validation.ALPHANUMERIC";
  public static final String ERRORCODE_SPACES = "cmdb.validation.SPACES";
  public static final String ERRORCODE_HOST_NAME = "cmdb.validation.HOST_NAME";
  public static final String ERRORCODE_IP_ADDRESS = "cmdb.validation.IP_ADDRESS";
  public static final String ERRORCODE_PORT = "cmdb.validation.PORT";
  public static final String ERRORCODE_HTTPURL = "cmdb.validation.HTTPURL";
  public static final String ERRORCODE_FTPURL = "cmdb.validation.FTPURL";
  public static final String ERRORCODE_EMAIL_ADDRESS = "cmdb.validation.EMAIL_ADDRESS";
  public static final String ERRORCODE_LDAP_IDENTIFIER = "cmdb.validation.LDAP_IDENTIFIER";
  public static final String ERRORCODE_WRONG_SIZE = "cmdb.validation.WRONG_SIZE";
  public static final String ERRORCODE_WRONG_TYPE = "cmdb.validation.WRONG_TYPE";
  public static final String ERRORCODE_HANDLER_CREATION = "cmdb.validation.HANDLER_CREATION_ERROR";
  public static final String ERRORCODE_REQUIRED = "cmdb.validation.REQUIRED";
  public static final String ERRORCODE_READONLY = "cmdb.validation.READONLY";
  public static final String ERRORCODE_WRONG_ENUM_VALUE = "cmdb.validation.WRONG_ENUM_VALUE";
  public static final String ERRORCODE_WRONG_LIST_VALUE = "cmdb.validation.WRONG_LIST_VALUE";
}