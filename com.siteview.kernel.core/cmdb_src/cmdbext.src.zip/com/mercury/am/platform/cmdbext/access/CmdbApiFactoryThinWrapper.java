package com.mercury.am.platform.cmdbext.access;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.client.manage.api.impl.CmdbApiFactory;
import com.mercury.topaz.cmdb.shared.base.FrameworkConstants.Customer.Default;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.manage.impl.CmdbContextFactory;

public class CmdbApiFactoryThinWrapper
{
  public static final String CMDB_HOST_PROPERTY = "cmdbHostName";
  public static final CmdbContext CMDB_CONTEXT = CmdbContextFactory.createCmdbContext(FrameworkConstants.Customer.Default.ID, -1, "CmdbExt");

  public static CmdbApi getInstance()
  {
    return CmdbApiFactory.createCMDBAPI();
  }

  public static boolean isLocalCMDBInstance()
  {
    String value = System.getProperty("cmdbHostName");
    return (value == null);
  }
}