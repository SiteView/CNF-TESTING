package com.mercury.am.platform.cmdbext.validation.classes;

import com.mercury.am.platform.cmdbext.cmhandler.CmdbClassHandler;
import com.mercury.am.platform.cmdbext.validation.attribute.AttributeValueValidatorFactory;
import com.mercury.am.platform.cmdbext.validation.utils.ValidationUtils;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public class ClassValidatorFactory
{
  public static Log logger = LogFactory.getEasyLog(ClassValidatorFactory.class);
  private static ClassValidatorFactory singleton = new ClassValidatorFactory();

  public static ClassValidatorFactory getInstance()
  {
    return singleton;
  }

  public ClassValidator create(String cmdbClassName, CmdbClassModel classModel)
  {
    return new InnerClassValidator(classModel.getClass(cmdbClassName), classModel);
  }

  public ClassValidator create(CmdbClass cmdClass, CmdbClassModel classModel) {
    return new InnerClassValidator(cmdClass, classModel);
  }

  private static class InnerClassValidator
  implements ClassValidator
  {
    ClassValidator validator;

    public InnerClassValidator(CmdbClass cmdbClass, CmdbClassModel classModel)
    {
      ClassModelQualifier handlerQualifier = ValidationUtils.findClassQualifierByName(cmdbClass, "HANDLER");

      if (handlerQualifier != null)
        try {
          CmdbClassHandler cmdbClassHandler = null;
          cmdbClassHandler = ValidationUtils.fetchClassHandler(handlerQualifier);

          if ((cmdbClassHandler != null) && (cmdbClassHandler.getValidator() != null))
          {
            this.validator = cmdbClassHandler.getValidator();
          }
        }
        catch (Exception e) {
          ClassValidatorFactory.logger.error("Failed to invoke CMDB Class Handler for Class " + cmdbClass.getName() + " . Error: " + e.getMessage(), e);
        }


      if (this.validator == null)
        this.validator = new DefaultClassValidator();
    }

    public void validateNew(Map attributeValues, CmdbClassModel classModel, CmdbClass cmdbClass, BasicUserData user) throws ClassValidationException, NullPointerException
    {
      validate(cmdbClass, null, attributeValues, classModel, user);
    }

    public void validateUpdated(Map attributeValues, CmdbClassModel classModel, CmdbClass cmdbClass, CmdbData toUpdate, BasicUserData user) throws ClassValidationException, NullPointerException {
      validate(cmdbClass, toUpdate, attributeValues, classModel, user);
    }

    private void validate(CmdbClass cmdbClass, CmdbData toUpdate, Map attributeValues, CmdbClassModel classModel, BasicUserData user) throws ClassValidationException, NullPointerException
    {
      invokeClassValidator(toUpdate, this.validator, attributeValues, classModel, cmdbClass, user);

      if ((this.validator instanceof CustomClassValidator) && (((CustomClassValidator)this.validator).toPerformDefaultValidation()))
      {
        invokeClassValidator(toUpdate, new DefaultClassValidator(), attributeValues, classModel, cmdbClass, user);
      }
    }

    private void invokeClassValidator(CmdbData toUpdate, ClassValidator validator, Map attributeValues, CmdbClassModel classModel, CmdbClass cmdbClass, BasicUserData user)
      throws ClassValidationException, NullPointerException
    {
      if (toUpdate == null)
        validator.validateNew(attributeValues, classModel, cmdbClass, user);
      else
        validator.validateUpdated(attributeValues, classModel, cmdbClass, toUpdate, user);
    }

    public AttributeValueValidatorFactory getAttributeValidatorsFactory()
    {
      return this.validator.getAttributeValidatorsFactory();
    }
  }
}