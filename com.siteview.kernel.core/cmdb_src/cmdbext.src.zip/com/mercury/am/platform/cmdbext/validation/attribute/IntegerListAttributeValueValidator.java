package com.mercury.am.platform.cmdbext.validation.attribute;

import com.mercury.am.platform.cmdbext.validation.utils.ValidationUtils;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbIntegerListType;
import java.util.List;

public class IntegerListAttributeValueValidator extends DefaultAttributeValueValidator
{
  public void validateType(CmdbAttribute attribute, Object value)
    throws AttributeTypeValidationException
  {
    ValidationUtils.validateAttributeType(attribute, CmdbIntegerListType.class, value);

    if ((value != null) && (!(value instanceof List))) {
      throw ValidationUtils.createAttributeTypeValidationException(attribute, value, value.getClass(), List.class);
    }

    if (value == null) {
      return;
    }

    List list = (List)value;
    for (int i = 0; i < list.size(); ++i) {
      Object entryValue = list.get(i);
      if ((entryValue == null) || (!(entryValue instanceof Integer)))
        throw ValidationUtils.createAttributeTypeValidationException(attribute, value, (entryValue == null) ? NullPointerException.class : entryValue.getClass(), Integer.class);
    }
  }
}