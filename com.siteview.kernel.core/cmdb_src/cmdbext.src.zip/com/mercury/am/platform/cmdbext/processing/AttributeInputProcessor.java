package com.mercury.am.platform.cmdbext.processing;

import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public abstract interface AttributeInputProcessor
{
  public abstract Object processNew(Map paramMap, CmdbAttribute paramCmdbAttribute, CmdbClass paramCmdbClass, CmdbData paramCmdbData, BasicUserData paramBasicUserData, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws AttributeProcessingException;

  public abstract Object processExisting(Map paramMap, CmdbAttribute paramCmdbAttribute, CmdbClass paramCmdbClass, CmdbData paramCmdbData, BasicUserData paramBasicUserData, CmdbContext paramCmdbContext, CmdbApi paramCmdbApi)
    throws AttributeProcessingException;

  public abstract Class getProcessedValueClass();
}