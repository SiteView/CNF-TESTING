package com.mercury.am.platform.cmdbext.processing;

import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.client.manage.api.CmdbApi;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.type.CmdbType;
import com.mercury.topaz.cmdb.shared.classmodel.type.simple.CmdbSimpleType;
import com.mercury.topaz.cmdb.shared.manage.CmdbContext;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.Map;

public class SimpleAttributeProcessor
  implements AttributeInputProcessor
{
  private static Log LOGGER = LogFactory.getEasyLog(SimpleAttributeProcessor.class);
  private Class processedValueClass;

  public SimpleAttributeProcessor(Class processedValueClass)
  {
    this.processedValueClass = processedValueClass;
  }

  public Object processNew(Map input, CmdbAttribute attribute, CmdbClass containedClass, CmdbData defaultCmdbObject, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws AttributeProcessingException
  {
    return process(input, attribute, containedClass, defaultCmdbObject, userContext, cmdbContext, cmdbApi);
  }

  public Object processExisting(Map input, CmdbAttribute attribute, CmdbClass containedClass, CmdbData currentCmdbData, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws AttributeProcessingException
  {
    return process(input, attribute, containedClass, currentCmdbData, userContext, cmdbContext, cmdbApi);
  }

  public Class getProcessedValueClass()
  {
    return this.processedValueClass;
  }

  protected Object process(Map input, CmdbAttribute attribute, CmdbClass containedClass, CmdbData currentCmdbData, BasicUserData userContext, CmdbContext cmdbContext, CmdbApi cmdbApi)
    throws AttributeProcessingException
  {
    if (LOGGER.isInfoEnabled()) {
      LOGGER.info("Start processing value for attribute for " + ((currentCmdbData == null) ? "new" : "updating") + " object. cmdb class = " + ((containedClass == null) ? "null" : containedClass.getName()) + " attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " input = " + ((input == null) ? "null" : input.toString()));
    }

    Object value = input.get(attribute.getName());

    if (value == null) {
      return null;
    }

    if (value.getClass().equals(getProcessedValueClass()))
      try {
        return manipulateValue(attribute, value, currentCmdbData, userContext);
      } catch (AttributeProcessingException e) {
        if (LOGGER.isDebugEnabled())
          LOGGER.debug("Error processing value for attribute for " + ((currentCmdbData == null) ? "new" : "updating") + " object. cmdb class = " + ((containedClass == null) ? "null" : containedClass.getName()) + " attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " value = " + value + " input = " + ((input == null) ? "null" : input.toString()), e);

        throw e;
      }
      catch (Exception e) {
        throw new AttributeProcessingException(e, attribute, value, getErrorCode(attribute));
      }


    if (value.getClass().equals(String.class))
      try {
        return manipulateValue(attribute, processStringValue(attribute, (String)value, currentCmdbData, userContext), currentCmdbData, userContext);
      } catch (AttributeProcessingException e) {
        if (LOGGER.isDebugEnabled())
          LOGGER.debug("Error processing value for attribute for " + ((currentCmdbData == null) ? "new" : "updating") + " object. cmdb class = " + ((containedClass == null) ? "null" : containedClass.getName()) + " attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " value = " + value + " input = " + ((input == null) ? "null" : input.toString()), e);

        throw e;
      }
      catch (Exception e) {
        throw new AttributeProcessingException(e, attribute, value, getErrorCode(attribute));
      }

    try
    {
      return manipulateValue(attribute, processStringValue(attribute, value.toString(), currentCmdbData, userContext), currentCmdbData, userContext);
    } catch (AttributeProcessingException e) {
      if (LOGGER.isDebugEnabled())
        LOGGER.debug("Error processing value for attribute for " + ((currentCmdbData == null) ? "new" : "updating") + " object. cmdb class = " + ((containedClass == null) ? "null" : containedClass.getName()) + " attribute name = " + ((attribute == null) ? "null" : attribute.getName()) + " value = " + value + " input = " + ((input == null) ? "null" : input.toString()), e);

      throw e;
    }
    catch (Exception e) {
      throw new AttributeProcessingException(e, attribute, value, getErrorCode(attribute));
    }
  }

  protected Object processStringValue(CmdbAttribute attribute, String valueAsString, CmdbData currentCmdbData, BasicUserData userContext)
    throws AttributeProcessingException, Exception
  {
    return attribute.getResolvedType().valueOf(valueAsString);
  }

  protected String getErrorCode(CmdbAttribute attribute)
  {
    if (attribute.getResolvedType() instanceof CmdbSimpleType)
    {
      CmdbSimpleType simpleType = (CmdbSimpleType)attribute.getResolvedType();

      if (Long.class.equals(simpleType.getJavaClass()))
        return "processor.error.not.long";

      if (Integer.class.equals(simpleType.getJavaClass()))
        return "processor.error.not.integer";

      if (Float.class.equals(simpleType.getJavaClass()))
        return "processor.error.not.float";

      if (Double.class.equals(simpleType.getJavaClass()))
        return "processor.error.not.double";

    }

    return "processor.error.general";
  }

  protected Object manipulateValue(CmdbAttribute attribute, Object value, CmdbData currentCmdbData, BasicUserData userContext)
    throws AttributeProcessingException, Exception
  {
    return value;
  }
}