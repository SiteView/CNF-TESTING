package com.mercury.am.platform.cmdbext.processing;

import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import java.util.List;
import java.util.Vector;

public class AttributeProcessingException extends Exception
{
  private String errorCode;
  private List errorParams;
  CmdbAttribute attribute;
  Object unprocessedValue;

  public AttributeProcessingException(CmdbAttribute attribute, Object unprocessedValue, String errorCode)
  {
    this.attribute = attribute;
    this.unprocessedValue = unprocessedValue;
    setErrorCode(errorCode);
    setErrorParams(null);
  }

  public AttributeProcessingException(String message, CmdbAttribute attribute, Object unprocessedValue, String errorCode) {
    super(message);
    this.attribute = attribute;
    this.unprocessedValue = unprocessedValue;
    setErrorCode(errorCode);
    setErrorParams(null);
  }

  public AttributeProcessingException(Throwable cause, CmdbAttribute attribute, Object unprocessedValue, String errorCode)
  {
    super(cause);
    this.attribute = attribute;
    this.unprocessedValue = unprocessedValue;
    setErrorCode(errorCode);
    setErrorParams(null);
  }

  public AttributeProcessingException(String message, Throwable cause, CmdbAttribute attribute, Object unprocessedValue, String errorCode) {
    this(message, cause, attribute, unprocessedValue, errorCode, null);
  }

  public AttributeProcessingException(String message, Throwable cause, CmdbAttribute attribute, Object unprocessedValue, String errorCode, List errorParams) {
    super(message, cause);
    this.attribute = attribute;
    this.unprocessedValue = unprocessedValue;
    setErrorCode(errorCode);
    setErrorParams(errorParams);
  }

  public CmdbAttribute getAttribute() {
    return this.attribute;
  }

  public Object getUnprocessedValue() {
    return this.unprocessedValue;
  }

  public String getErrorCode() {
    return this.errorCode;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  public void setErrorParams(List errorParams) {
    this.errorParams = ((errorParams == null) ? new Vector() : errorParams);
  }

  public List getErrorParams() {
    return this.errorParams;
  }
}