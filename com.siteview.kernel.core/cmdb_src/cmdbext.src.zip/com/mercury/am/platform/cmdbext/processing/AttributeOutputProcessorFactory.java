package com.mercury.am.platform.cmdbext.processing;

import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;

public abstract interface AttributeOutputProcessorFactory
{
  public abstract AttributeOutputProcessor create(CmdbAttribute paramCmdbAttribute, CmdbClass paramCmdbClass, CmdbClassModel paramCmdbClassModel)
    throws AttributeProcessingException;
}