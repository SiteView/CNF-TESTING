package com.mercury.am.platform.cmdbext.access.jmx.classmodelcache;

public abstract interface ClassModelCacheJMXMBean
{
  public abstract void init();

  public abstract void start();

  public abstract void stop();

  public abstract void destroy()
    throws Exception;

  public abstract void refresh()
    throws Exception;

  public abstract void reset()
    throws Exception;
}