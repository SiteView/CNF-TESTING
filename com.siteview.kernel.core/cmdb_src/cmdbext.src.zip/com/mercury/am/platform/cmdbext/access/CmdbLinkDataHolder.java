package com.mercury.am.platform.cmdbext.access;

import com.mercury.topaz.cmdb.shared.model.link.CmdbLink;
import com.mercury.topaz.cmdb.shared.model.object.CmdbObject;

public class CmdbLinkDataHolder
{
  CmdbObject end1;
  CmdbObject end2;
  CmdbLink link;

  public CmdbLinkDataHolder(CmdbObject end1, CmdbObject end2, CmdbLink link)
  {
    this.end1 = end1;
    this.end2 = end2;
    this.link = link;
  }

  public CmdbObject getEnd1()
  {
    return this.end1;
  }

  public CmdbObject getEnd2()
  {
    return this.end2;
  }

  public CmdbLink getLink()
  {
    return this.link;
  }
}