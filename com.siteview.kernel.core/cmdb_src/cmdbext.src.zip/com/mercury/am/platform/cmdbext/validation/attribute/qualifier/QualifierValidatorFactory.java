package com.mercury.am.platform.cmdbext.validation.attribute.qualifier;

import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.CmdbAttributeQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.qualifier.definition.CmdbAttributeQualifierDefs;
import java.util.HashMap;
import java.util.Map;

public class QualifierValidatorFactory
{
  private static Map qualifierValidatorMap = new HashMap();

  public static QualifierValidator createQualifierValidator(ClassModelQualifier qualifier)
  {
    if (qualifier == null)
      return null;

    return ((QualifierValidator)qualifierValidatorMap.get(qualifier.getName()));
  }

  public static boolean requireValidation(CmdbAttributeQualifier qualifier)
  {
    return true;
  }

  static
  {
    qualifierValidatorMap.put(CmdbAttributeQualifierDefs.CONSTRAINED_ATTRIBUTE.getName(), new ConstrainedQualifierValidator());
    qualifierValidatorMap.put(CmdbAttributeQualifierDefs.ENCRYPTED_ATTRIBUTE.getName(), new EmptyQualifierValidator());
    qualifierValidatorMap.put(CmdbAttributeQualifierDefs.FINAL_ATTRIBUTE.getName(), new EmptyQualifierValidator());
    qualifierValidatorMap.put(CmdbAttributeQualifierDefs.HANDLED_ATTRIBUTE.getName(), new EmptyQualifierValidator());
    qualifierValidatorMap.put(CmdbAttributeQualifierDefs.HIDDEN_ATTRIBUTE.getName(), new EmptyQualifierValidator());
    qualifierValidatorMap.put(CmdbAttributeQualifierDefs.ID_ATTRIBUTE.getName(), new IDQualifierValidator());
    qualifierValidatorMap.put(CmdbAttributeQualifierDefs.READ_ONLY_ATTRIBUTE.getName(), new ReadonlyQualifierValidator());
    qualifierValidatorMap.put(CmdbAttributeQualifierDefs.REQUIRED_ATTRIBUTE.getName(), new RequiredQualifierValidator());
    qualifierValidatorMap.put(CmdbAttributeQualifierDefs.STATIC_ATTRIBUTE.getName(), new ReadonlyQualifierValidator());
  }
}