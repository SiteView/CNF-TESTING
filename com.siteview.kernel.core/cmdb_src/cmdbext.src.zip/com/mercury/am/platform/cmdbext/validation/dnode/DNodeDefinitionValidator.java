package com.mercury.am.platform.cmdbext.validation.dnode;

import com.mercury.am.platform.cmdbext.access.CMDBConstants;
import com.mercury.am.platform.cmdbext.access.CMDBConstants.ConstantClass;
import com.mercury.am.platform.cmdbext.access.ClassModelFactoryProxy;
import com.mercury.am.platform.cmdbext.access.ClassModelFactoryThinWrapper;
import com.mercury.am.platform.cmdbext.validation.attribute.AttributeTypeValidationException;
import com.mercury.am.platform.cmdbext.validation.attribute.AttributeValidationException;
import com.mercury.am.platform.cmdbext.validation.attribute.CustomAttributeValueValidator;
import com.mercury.am.platform.cmdbext.validation.utils.ValidationUtils;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttribute;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.attribute.CmdbAttributes;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDef;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.qualifier.definition.CmdbClassQualifierDefs;
import com.mercury.topaz.cmdb.shared.common.qualifiedname.CmdbQualifiedNameFactory;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import com.mercury.topaz.util.XMLUtil;
import com.mercury.topaz.util.session.BasicUserData;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DNodeDefinitionValidator extends CustomAttributeValueValidator
{
  public String getName()
  {
    return DNodeDefinitionValidator.class.getName();
  }

  public void validateType(CmdbAttribute attribute, Object value)
    throws AttributeTypeValidationException
  {
    if ((value != null) && (!(value instanceof String)))
      throw ValidationUtils.createAttributeTypeValidationException(attribute, value, value.getClass(), String.class);
  }

  public void validateNew(CmdbAttribute attribute, CmdbClass containerCalss, Object value, Map attributeValues, BasicUserData user)
    throws AttributeValidationException
  {
    CmdbClassModel classModel = getClassModel(user);
    validate(attribute, value, classModel);
  }

  public void validateUpdated(CmdbAttribute attribute, CmdbClass containerCalss, Object value, Map attributeValues, CmdbData cmdbData, BasicUserData user)
    throws AttributeValidationException
  {
    CmdbClassModel classModel = getClassModel(user);
    validate(attribute, value, classModel);
  }

  public void validate(CmdbAttribute attribute, Object value, CmdbClassModel classModel)
    throws AttributeValidationException
  {
    validateType(attribute, value);

    String dnodeDefinitionKey = (String)value;

    if ((dnodeDefinitionKey == null) || (dnodeDefinitionKey.trim().length() == 0)) {
      return;
    }

    Document doc = null;
    try
    {
      doc = XMLUtil.parseXMLString(dnodeDefinitionKey);
      if (doc == null)
        throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_WRONG_XML_FORMAT.getUiCode(), attribute, value);
    }
    catch (Exception e) {
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_WRONG_XML_FORMAT.getUiCode(), attribute, value);
    }

    validateDoc(attribute, value, doc.getDocumentElement(), classModel);
  }

  public void validateDoc(CmdbAttribute attribute, Object value, Element documentElement, CmdbClassModel classModel)
    throws AttributeValidationException
  {
    Set generatorItemTemplates = new HashSet();
    Set generatorLinkTemplates = new HashSet();
    validateGenerators(attribute, value, documentElement, generatorItemTemplates, generatorLinkTemplates);

    Set itemTemplates = new HashSet();
    validateItemTemplates(attribute, value, documentElement, itemTemplates, classModel);

    Set linkTemplates = new HashSet();
    validateLinkTemplates(attribute, value, documentElement, linkTemplates, classModel);

    if (!(itemTemplates.containsAll(generatorItemTemplates)))
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_MISSING_ITEM_TEMPLATE.getUiCode(), attribute, value);

    if (!(linkTemplates.containsAll(generatorLinkTemplates)))
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_MISSING_LINK_TEMPLATE.getUiCode(), attribute, value);
  }

  private void validateItemTemplates(CmdbAttribute attribute, Object value, Element documentElement, Set itemTemplates, CmdbClassModel classModel) throws AttributeValidationException
  {
    List itemTemplateElements = getChildElementsByTagName(documentElement, "ItemTemplate");
    for (int i = 0; i < itemTemplateElements.size(); ++i) {
      Element templateElement = (Element)itemTemplateElements.get(i);
      valiedateBasicTemplate(attribute, value, templateElement, itemTemplates, classModel);
      validateSelectorTemplate(attribute, value, templateElement);
      validateKPITemplate(attribute, value, templateElement, classModel);
    }
  }

  private void validateKPITemplate(CmdbAttribute attribute, Object value, Element templateElement, CmdbClassModel classModel) throws AttributeValidationException
  {
    NodeList dimensionTemplates = templateElement.getElementsByTagName("KPI");
    if ((dimensionTemplates == null) || (dimensionTemplates.getLength() == 0))
    {
      return;
    }

    for (int i = 0; i < dimensionTemplates.getLength(); ++i) {
      Element dimTemplateElement = (Element)dimensionTemplates.item(i);

      String className = dimTemplateElement.getAttribute("class-name");
      if ((className == null) || (className.length() == 0))
        className = CMDBConstants.KPI.getName();

      String nameSpace = dimTemplateElement.getAttribute("namespace");
      if ((nameSpace == null) || (nameSpace.length() == 0))
        nameSpace = CMDBConstants.KPI.getNamespace();

      validateClassAttributes(attribute, value, dimTemplateElement, nameSpace, className, classModel);

      validateRuleArguments(attribute, value, dimTemplateElement);

      validateSelectorTemplate(attribute, value, dimTemplateElement);

      validateObjectiveTempalte(attribute, value, dimTemplateElement, classModel);
    }
  }

  private void validateObjectiveTempalte(CmdbAttribute attribute, Object value, Element dimTemplateElement, CmdbClassModel classModel) throws AttributeValidationException {
    NodeList objectiveTemplates = dimTemplateElement.getElementsByTagName("Objective");
    if ((objectiveTemplates == null) || (objectiveTemplates.getLength() == 0))
      return;

    for (int i = 0; i < objectiveTemplates.getLength(); ++i) {
      Element objectiveTemplateElement = (Element)objectiveTemplates.item(i);

      String className = objectiveTemplateElement.getAttribute("class-name");
      if ((className == null) || (className.length() == 0))
        className = CMDBConstants.OBJECTIVE.getName();

      String nameSpace = objectiveTemplateElement.getAttribute("namespace");
      if ((nameSpace == null) || (nameSpace.length() == 0))
        nameSpace = CMDBConstants.OBJECTIVE.getNamespace();

      validateClassAttributes(attribute, value, objectiveTemplateElement, nameSpace, className, classModel);
    }
  }

  private void validateLinkTemplates(CmdbAttribute attribute, Object value, Element documentElement, Set linkTemplates, CmdbClassModel classModel) throws AttributeValidationException {
    List linkTemplateElements = getChildElementsByTagName(documentElement, "LinkTemplate");
    for (int i = 0; i < linkTemplateElements.size(); ++i) {
      Element itemTemplate = (Element)linkTemplateElements.get(i);
      valiedateBasicTemplate(attribute, value, itemTemplate, linkTemplates, classModel);
    }
  }

  private void valiedateBasicTemplate(CmdbAttribute attribute, Object value, Element itemTemplate, Set templateNames, CmdbClassModel classModel) throws AttributeValidationException
  {
    String templateName = itemTemplate.getAttribute("template");
    if ((templateName == null) || (templateName.length() == 0))
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_NO_TEMPLATE_NAME.getUiCode(), attribute, value);

    if (templateNames.contains(templateName))
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_TEMPLATE_DUPLICATE_NAME.getUiCode(), attribute, value, "template name", templateName);

    templateNames.add(templateName);

    String className = itemTemplate.getAttribute("class-name");
    String nameSpace = itemTemplate.getAttribute("namespace");
    if ((className == null) || (className.length() == 0)) {
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_TEMPLATE_MISSING_CLASS.getUiCode(), attribute, value);
    }

    validateClassAttributes(attribute, value, itemTemplate, nameSpace, className, classModel);
  }

  private void validateClassAttributes(CmdbAttribute attribute, Object value, Element templateElement, String nameSpace, String className, CmdbClassModel classModel)
    throws AttributeValidationException
  {
    String qualifiedName = CmdbQualifiedNameFactory.createCmdbQualifiedName(nameSpace, className);
    CmdbClass cmdbClass = null;
    cmdbClass = classModel.getClass(qualifiedName);
    if (cmdbClass == null) {
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_TEMPLATE_WRONG_CLASS.getUiCode(), attribute, value, "qualified class name", qualifiedName);
    }

    if (cmdbClass.hasQualifier(CmdbClassQualifierDefs.RANDOM_GENERATED_ID_CLASS.getName())) {
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_TEMPLATE_CLASS_ID.getUiCode(), attribute, value, "qualified class name", qualifiedName);
    }

    validateAttributes(attribute, value, templateElement, cmdbClass);
  }

  private void validateAttributes(CmdbAttribute attribute, Object value, Element templateElement, CmdbClass cmdbClass)
    throws AttributeValidationException
  {
    List outerAttributesTagList = getChildElementsByTagName(templateElement, "Attributes");
    if (outerAttributesTagList.size() > 1)
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_ATTRIBUTES_TAG.getUiCode(), attribute, value);

    if (outerAttributesTagList.size() > 0) {
      CmdbAttributes cmdbAttributes = cmdbClass.getAllAttributes();
      Element outAttributesElement = (Element)outerAttributesTagList.get(0);
      NodeList attributeList = outAttributesElement.getElementsByTagName("Attribute");
      if (attributeList == null)
        return;

      for (int i = 0; i < attributeList.getLength(); ++i) {
        Element attributeElement = (Element)attributeList.item(i);
        String attrName = attributeElement.getAttribute("name");
        if (attrName.length() == 0)
          throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_ATTRIBUTE_NAME.getUiCode(), attribute, value);

        if ((!(attributeElement.hasAttribute("ref_value"))) && (!(attributeElement.hasAttribute("value"))))
        {
          throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_ATTRIBUTE_VALUE.getUiCode(), attribute, value);
        }

        if (!(cmdbAttributes.hasAttribute(attrName)))
          throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_WRONG_ATTRIBUTE.getUiCode(), attribute, value, "attribute", attrName, "qualified class name", cmdbClass.getName());
      }
    }
  }

  private void validateRuleArguments(CmdbAttribute attribute, Object value, Element dimTemplateElement) throws AttributeValidationException
  {
    NodeList ruleArguments = dimTemplateElement.getElementsByTagName("RuleArguments");
    if ((ruleArguments == null) || (ruleArguments.getLength() == 0))
      return;

    if (ruleArguments.getLength() > 1)
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_WRONG_RULE_ARG_FORMAT.getUiCode(), attribute, value);

    Element ruleArgumentElement = (Element)ruleArguments.item(0);
    NodeList parmElements = ruleArgumentElement.getElementsByTagName("parameter");
    if (parmElements == null)
      return;

    for (int i = 0; i < parmElements.getLength(); ++i) {
      Element parmElement = (Element)parmElements.item(i);
      if ((!(parmElement.hasAttribute("name"))) || (!(parmElement.hasAttribute("type"))) || (!(parmElement.hasAttribute("value"))))
      {
        throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_WRONG_RULE_PARAM_FORMAT.getUiCode(), attribute, value);
      }
    }
  }

  private void validateSelectorTemplate(CmdbAttribute attribute, Object value, Element templateElement) throws AttributeValidationException {
    List compoistieSelectorElements = getChildElementsByTagName(templateElement, "CompositeSelector");
    if (compoistieSelectorElements.size() > 1)
    {
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_WRONG_SELECTORS_FORMAT.getUiCode(), attribute, value);
    }
    if (compoistieSelectorElements.size() == 1) {
      Element compositeSelectorElement = (Element)compoistieSelectorElements.get(0);
      validateCompositeSelector(attribute, value, compositeSelectorElement);
    }
  }

  private void validateCompositeSelector(CmdbAttribute attribute, Object value, Element compositeSelectorElement) throws AttributeValidationException
  {
    if (!(compositeSelectorElement.hasAttribute("logicalOp"))) {
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_SELECTORS_NO_LOGICAL_OP.getUiCode(), attribute, value);
    }

    List childCompositeSelectorElements = getChildElementsByTagName(compositeSelectorElement, "CompositeSelector");
    for (int i = 0; i < childCompositeSelectorElements.size(); ++i) {
      Element childCompositeElement = (Element)childCompositeSelectorElements.get(i);
      validateCompositeSelector(attribute, value, childCompositeElement);
    }

    List childSelectorElements = getChildElementsByTagName(compositeSelectorElement, "Selector");
    for (int i = 0; i < childSelectorElements.size(); ++i) {
      Element childSelectorElement = (Element)childSelectorElements.get(i);
      validateSelector(attribute, value, childSelectorElement);
    }
  }

  private void validateSelector(CmdbAttribute attribute, Object value, Element selectorElement) throws AttributeValidationException {
    if ((!(selectorElement.hasAttribute("key"))) || (!(selectorElement.hasAttribute("op"))))
    {
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_SELECTORS_KEY_OP.getUiCode(), attribute, value);
    }
    if ((!(selectorElement.hasAttribute("value"))) && (!(selectorElement.hasAttribute("ref_value"))))
    {
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_SELECTORS_VAUE.getUiCode(), attribute, value);
    }
  }

  private void validateGenerators(CmdbAttribute attribute, Object value, Element documentElement, Set generatorItemTemplates, Set generatorLinkTemplates)
    throws AttributeValidationException
  {
    List generatorElements = getChildElementsByTagName(documentElement, "Generator");
    if ((generatorElements == null) || (generatorElements.isEmpty()))
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_NO_GENERATORS.getUiCode(), attribute, value);

    validateGeneratorsLevel(attribute, value, generatorElements, generatorItemTemplates, generatorLinkTemplates, new ArrayList());
  }

  private void validateGeneratorsLevel(CmdbAttribute attribute, Object value, List generatorElements, Set generatorItemTemplates, Set generatorLinkTemplates, List generatorParentsItemTemplates)
    throws AttributeValidationException
  {
    for (int i = 0; i < generatorElements.size(); ++i) {
      Element generator = (Element)generatorElements.get(i);
      validateGenerator(attribute, value, generator, generatorItemTemplates, generatorLinkTemplates, generatorParentsItemTemplates);
    }
  }

  private void validateGenerator(CmdbAttribute attribute, Object value, Element generator, Set generatorItemTemplates, Set generatorLinkTemplates, List generatorParentsItemTemplates)
    throws AttributeValidationException
  {
    if (!(generator.hasAttribute("groupBy"))) {
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_GENERATOR_NO_GROUPBY.getUiCode(), attribute, value);
    }

    String nodeTemplateName = generator.getAttribute("itemTemplate");
    if ((nodeTemplateName == null) || (nodeTemplateName.length() == 0)) {
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_GENERATOR_NO_ITEM_TEMPLATE.getUiCode(), attribute, value);
    }

    if (generatorParentsItemTemplates.contains(nodeTemplateName))
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_GENERATOR_REDUNDANT_ITEM_TEMPLATE.getUiCode(), attribute, value);

    generatorItemTemplates.add(nodeTemplateName);

    String linkTemplateName = generator.getAttribute("linkTemplate");
    if ((linkTemplateName == null) || (linkTemplateName.length() == 0))
      throw ValidationUtils.createAttributeValidationException(DNodeDefinitionConstants.ERRORCODE_GENERATOR_NO_LINK_TEMPLATE.getUiCode(), attribute, value);

    generatorLinkTemplates.add(linkTemplateName);

    generatorParentsItemTemplates.add(nodeTemplateName);
    List childGeneratorElements = getChildElementsByTagName(generator, "Generator");
    validateGeneratorsLevel(attribute, value, childGeneratorElements, generatorItemTemplates, generatorLinkTemplates, generatorParentsItemTemplates);

    generatorParentsItemTemplates.remove(nodeTemplateName);
  }

  List getChildElementsByTagName(Element rootElement, String tagName)
  {
    NodeList childNodes = rootElement.getChildNodes();
    if ((childNodes == null) || (childNodes.getLength() <= 0)) {
      return Collections.EMPTY_LIST;
    }

    int nodeCount = childNodes.getLength();
    List childElements = new ArrayList(nodeCount);
    for (int i = 0; i < nodeCount; ++i) {
      Node currentNode = childNodes.item(i);

      if (currentNode instanceof Element) {
        Element currentElement = (Element)currentNode;

        if (currentElement.getTagName().equals(tagName))
          childElements.add(currentElement);
      }
    }

    return childElements;
  }

  protected CmdbClassModel getClassModel(BasicUserData user) {
    CmdbClassModel classModel = ClassModelFactoryThinWrapper.getInstance().getClassModelByUserData(user);
    return classModel;
  }
}