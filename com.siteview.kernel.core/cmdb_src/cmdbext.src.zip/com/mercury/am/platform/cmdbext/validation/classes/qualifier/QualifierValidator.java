package com.mercury.am.platform.cmdbext.validation.classes.qualifier;

import com.mercury.am.platform.cmdbext.validation.attribute.qualifier.QualifierValidator;
import com.mercury.am.platform.cmdbext.validation.classes.ClassValidationException;
import com.mercury.infra.utils.logger.Log;
import com.mercury.infra.utils.logger.LogFactory;
import com.mercury.topaz.cmdb.shared.classmodel.CmdbClassModel;
import com.mercury.topaz.cmdb.shared.classmodel.base.qualifier.ClassModelQualifier;
import com.mercury.topaz.cmdb.shared.classmodel.cmdbclass.CmdbClass;
import com.mercury.topaz.cmdb.shared.model.data.CmdbData;
import java.util.Map;

public abstract interface QualifierValidator
{
  public static final Log logger = LogFactory.getEasyLog(com.mercury.am.platform.cmdbext.validation.attribute.qualifier.QualifierValidator.class);

  public abstract void validateNew(ClassModelQualifier paramClassModelQualifier, CmdbClass paramCmdbClass, CmdbClassModel paramCmdbClassModel, Map paramMap)
    throws ClassValidationException;

  public abstract void validateUpdated(ClassModelQualifier paramClassModelQualifier, CmdbClass paramCmdbClass, CmdbClassModel paramCmdbClassModel, Map paramMap, CmdbData paramCmdbData)
    throws ClassValidationException;
}